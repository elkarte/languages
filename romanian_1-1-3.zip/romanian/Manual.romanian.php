<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'Ajutor pentru utilizatorii ElkArte';

$txt['manual_welcome'] = 'Bunvenit la %s!';
$txt['manual_introduction'] = 'ElkArte este soluția software pentru un forum elegant, eficient, puternic și gratuit pe care o utilizează această comunitate. ElkArte permite utilizatorilor să comunice în cadrul diverselor subiecte de discuții în mod organizat și inteligent. În plus, pune la dispoziția utilizatorilor câteva funcționalități puternice. Poți obține ajutor și informații privind multr din funcțiile ElkArte fie făcând click pe iconițele „semnul întrebării” din dreptul textului de interes, fie accesând link-urile din pagină. Aceste link-uri te vor conduce la documentația centralizată aflată pe site-ul oficial ElkArte.';
$txt['manual_docs_and_credits'] = 'Pentru informații suplimntare privind utilizara ElkArte, vizitează <a href="%1$s" target="_blank" class="new_win">Documentatia în format Wiki</a> și ariea de <a href="%2$s">credite</a> pentru a afla cine a făcut ElkArte ceea ce este azi.';

$txt['manual_section_registering_title'] = 'Înregistrarea';
$txt['manual_section_logging_in_title'] = 'Conectarea';
$txt['manual_section_profile_title'] = 'Profilul';
$txt['manual_section_search_title'] = 'Căutări';
$txt['manual_section_posting_title'] = 'Postarea';
$txt['manual_section_bbc_title'] = 'Codurile Bulletin Board (BBC)';
$txt['manual_section_personal_messages_title'] = 'Mesaje personale';
$txt['manual_section_memberlist_title'] = 'Lista de membri';
$txt['manual_section_calendar_title'] = 'Calendar';
$txt['manual_section_features_title'] = 'Caracteristici';

$txt['manual_section_registering_desc'] = 'Multe forumuri cer utilizatorilor să se înregistreze pentru a obţine acces complet.';
$txt['manual_section_logging_in_desc'] = 'Odată înregistraţi, utilizatorii trebuie să se autentifice pentru a avea acces la contul lor.';
$txt['manual_section_profile_desc'] = 'Fiecare membru are profilul său personal.';
$txt['manual_section_search_desc'] = 'Căutarea este un instrument util pentru găsirea informaţiei în subiecte şi secţiuni.';
$txt['manual_section_posting_desc'] = 'Esența unui forum, postarea permite utilizatorilor să se exprime.';
$txt['manual_section_bbc_desc'] = 'Postările pot fi îmbunătățite cu puţin cod BBC.';
$txt['manual_section_personal_messages_desc'] = 'Utilizatorii îşi pot trimite mesaje personale.';
$txt['manual_section_memberlist_desc'] = 'Lista de membri conţine toti utilizatorii înregistraţi ai forumului.';
$txt['manual_section_calendar_desc'] = 'Utilizatorii pot ţine şirul evenimentelor, sărbătorilor şi zilelor de naştere folosind Calendarul.';
$txt['manual_section_features_desc'] = 'Iată lista celor mai populare funcții ale ElkArte';