<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Administrează ariile şi categoriile ';
$txt['order'] = 'Ordinea';
$txt['full_name'] = 'Numele complet';
$txt['name_on_display'] = 'Acesta este numele care va fi afişat.';
$txt['boards_and_cats_desc'] = 'Aici editezi categoriile și ariile. Poți introduce mai mulți moderatori sub forma <em>&quot;username&quot;, &quot;username&quot;</em>. (acestea sunt numele de utilizator și *nu* numele afișate)<br />Pentru a crea o arie nouă, apasă butonul Adaugă arie.<br />Pentru a muta o arie o poți trage în noua locație din listă (în orice categorie sau subcategorie)<br />Pentru a crea o arie nouă ca subarie a ariei curente, la momentul creării alege "Subcategorie a..." din meniul drop-down referitor la Ordine.';
$txt['parent_members_only'] = 'Membri obişnuiţi';
$txt['parent_guests_only'] = 'Vizitatori';
$txt['catConfirm'] = 'Ești sigur că vrei să ştergi această categorie?';
$txt['boardConfirm'] = 'Ești sigur că vrei să ştergi această arie?';

$txt['catEdit'] = 'Editează categoria';
$txt['collapse_enable'] = 'Colapsabilă';
$txt['collapse_desc'] = 'Permite utilizatorilor să poată restrânge acestă categorie';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'După ';
$txt['mboards_order_first'] = 'Pe primul loc';
$txt['mboards_board_error'] = 'Nu se poate determina locația pentru mutare.';

$txt['mboards_new_board'] = 'Adaugă arie';
$txt['mboards_new_cat_name'] = 'Categorie nouă';
$txt['mboards_add_cat_button'] = 'Adaugă o categorie';
$txt['mboards_new_board_name'] = 'Arie nouă';

$txt['mboards_modify'] = 'modifică';
$txt['mboards_permissions'] = 'drepturi';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Ești sigur că vrei să modifici aria pentru a o face să folosească drepturi locale?';

$txt['mboards_delete_cat'] = 'Şterge categoria';
$txt['mboards_delete_board'] = 'Şterge aria';

$txt['mboards_delete_cat_contains'] = 'Ştergând această categorie se vor şterge toate ariile din ea, inclusiv subiectele cu mesajele şi ataşamentele conţinute în fiecare arie';
$txt['mboards_delete_option1'] = 'Şterge această categorie cu toate ariile pe care le conţine.';
$txt['mboards_delete_option2'] = 'Şterge această categorie şi mută ariile conţinute în';
$txt['mboards_delete_board_contains'] = 'Ștergerea acestei categorii va determina mutarea sub-ariilor de mai jos, inclusiv a tuturor subiectelor, postărilor și atașamentelor din fiecare arie';
$txt['mboards_delete_board_option1'] = 'Șterge aria și mută sub-ariile conținute de ea la nivelul de categorie.';
$txt['mboards_delete_board_option2'] = 'Șterge aria și mută sub-ariile conținute de ea în ';
$txt['mboards_delete_what_do'] = 'Alege ce vrei să faci cu aceste arii';
$txt['mboards_delete_confirm'] = 'Confimă';
$txt['mboards_delete_cancel'] = 'Anulează';

$txt['mboards_category'] = 'Categorie';
$txt['mboards_description'] = 'Descriere';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Grupurile care au acces';
$txt['mboards_groups_desc'] = 'Grupurile care au acces la această arie.<br /><em>Notă: dacă un utilizator este membru al oricărui grup bifat, acesta va avea acces arie.</em>';
$txt['mboards_groups_regular_members'] = 'Acest grup conţine toţi membrii care nu au definit niciun grup primar.';
$txt['mboards_groups_post_group'] = 'Acesta este un grup bazat pe numărul de mesaje postate.';
$txt['mboards_moderators'] = 'Moderatori';
$txt['mboards_moderators_desc'] = 'Alți utilizatori care să aibă privilegii de moderare în această arie. Nu este nevoie să listezi administratorii.';
$txt['mboards_count_posts'] = 'Numără mesajele';
$txt['mboards_count_posts_desc'] = 'Mesajele şi subiectele noi ale utilizatorilor vor fi contorizate.';
$txt['mboards_unchanged'] = 'Neschimbat';
$txt['mboards_theme'] = 'Tema grafică a ariei';
$txt['mboards_theme_desc'] = 'Această setare permite schimbarea felului în care va arăta aria.';
$txt['mboards_theme_default'] = '(setarea implicită generală a forumului)';
$txt['mboards_override_theme'] = 'Ignoră setările din temele utilizatorilor';
$txt['mboards_override_theme_desc'] = 'Foloseşte tema acestei arii chiar dacă utilizatorii nu au ales să folosească tema implicită.';

$txt['mboards_redirect'] = 'Redirectează către o adresă web';
$txt['mboards_redirect_desc'] = 'Cu această opţiune activată, utilizatorii vor fi redirectaţi către o altă adresă web cand dau clic pe arie.';
$txt['mboards_redirect_url'] = 'Adresa către care se redirectează';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Resetează contorul redirecţionărilor';
$txt['mboards_redirect_reset_desc'] = 'Această setare va reseta contorul redirecţionărilor la zero.';
$txt['mboards_current_redirects'] = 'Acum: %1$s';
$txt['mboards_redirect_disabled'] = 'Notă: aria trebuie să fie goală (fără subiecte) pentru a putea activa această opţiune.';
$txt['mboards_redirect_disabled_recycle'] = 'Notă: aria „coş de gunoi” nu poate fi o arie de redirecţionare.';

$txt['mboards_order_before'] = 'Înainte de';
$txt['mboards_order_child_of'] = 'Subarie a...';
$txt['mboards_order_in_category'] = 'În categoria';
$txt['mboards_current_position'] = 'Poziţia actuală';
$txt['no_valid_parent'] = 'Aria %1$s nu are setată corect aria de care aparţine. Folosiţi funcţia \'găseşte şi repară erorile\' pentru a remedia această eroare.';

$txt['mboards_recycle_disabled_delete'] = 'Trebuie să setezi o altă arie pe post de „coș de gunoi” pentru a putea șterge această arie.';

$txt['mboards_settings_desc'] = 'Editează setările generale ale ariilor şi ale categoriilor.';
$txt['groups_manage_boards'] = 'Grupurile de utilizatori care pot administra categoriile şi ariile';
$txt['recycle_enable'] = 'Activează reciclarea subiectelor şterse';
$txt['recycle_board'] = 'Aria pentru subiectele şterse';
$txt['recycle_board_unselected_notice'] = 'Ai activat reciclarea de subiecte fără specificarea unei arii în care să le trimiți.  Această funcție va fi inactivă până când vei specifica o arie în care să muți subiectele reciclate.';
$txt['countChildPosts'] = 'Numără și mesajele subariilor la totalul ariilor de care aparţin';
$txt['allow_ignore_boards'] = 'Permite utilizatorilor să ignore ariile';
$txt['deny_boards_access'] = 'Validează opțiunea de a refuza accesul utilizatorilor la arii pe baza grupului din care fac parte';
$txt['boardsaccess_option_desc'] = 'Pentru fiecare drept poți alege \'Permite\'  (A), \'Ignoră\' (X), sau <span class="alert">\'Refuză\' (D)</span>.<br /><br />Dacă refuzi accesul, nici un membru al acelui grup (inclusiv moderatorii) nu va mai putea intra. <br />Din acest motiv, trebuie să utilizezi această opțiune cu mare grijă, doar atunci când este <strong>necesar</strong>. Pe de altă parte, setarea \'Ignoră\' refuză accesul doar dacă nu este permis în alt mod.';

$txt['mboards_select_destination'] = 'Alege destinaţia pentru aria \'<strong>%1$s</strong>\' ';
$txt['mboards_cancel_moving'] = 'Anulează mutarea';
$txt['mboards_move'] = 'mută';

$txt['mboards_no_cats'] = 'În prezent nu există categorii sau arii configurate.';
