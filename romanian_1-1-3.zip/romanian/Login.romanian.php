<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Acordul de înregistrare';
$txt['registration_privacy_policy'] = 'Politica de confidențialitate';
$txt['agreement_agree'] = 'Accept termenii acordului.';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Accept termenii acordului şi am cel puţin %1$d ani.';
$txt['agreement_agree_coppa_below'] = 'Accept termenii acordului şi sunt mai tânăr de %1$d ani.';
$txt['agree_coppa_above'] = 'Am cel puțin %1$d ani.';
$txt['agree_coppa_below'] = 'Am mai puțin de %1$d ani.';

// Registration form.
$txt['registration_form'] = 'Formular de Înregistrare';
$txt['error_too_quickly'] = 'Ai trecut prin procesul de înregistrare prea repede, mai repede decât ar trebui să fie posibil în mod normal. Așteaptă puțin și încearcă din nou.';
$txt['error_token_verification'] = 'Verificarea tokenului a eșuat. Încearcă din nou.';
$txt['need_username'] = 'Trebuie să introduci un nume de utilizator.';
$txt['no_password'] = 'Nu ţi-ai introdus parola.';
$txt['improper_password'] = 'Parola introdusă e prea lungă.';
$txt['incorrect_password'] = 'Parolă incorectă';
$txt['openid_not_found'] = 'Identificatorul OpenIDintrodus nu a fost găsit.';
$txt['maintain_mode'] = 'Stare de Mentenanţă';
$txt['registration_successful'] = 'Înregistrare Reușită';
$txt['valid_email_needed'] = 'Te rugăm să introduci o adresă de e-mail validă, %1$s. ';
$txt['required_info'] = 'Informaţii Solicitate';
$txt['additional_information'] = 'Informaţii Suplimentare';
$txt['warning'] = 'Avertizare !';
$txt['only_members_can_access'] = 'Numai membrii înregistraţi au permisiunea de a accesa această secţiune.';
$txt['login_below'] = 'Autentifică-te mai jos';
$txt['login_below_or_register'] = 'Autentifică-te mai jos sau <a href="%1$s">înregistrează un cont</a> pe %2$s';
$txt['checkbox_agreement'] = 'Accept acordul de înregistrare';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Setările de securitate pentru parolă au fost actualizate de curând.<br />Introdu parola din nou.';

$txt['ban_register_prohibited'] = 'Ne pare rău, dar nu aveți permisiunea de a vă înscrie în acest forum.';
$txt['under_age_registration_prohibited'] = 'Ne pare rău, dar utilizatorilor cu vârsta mai mică de %1$d ani nu li se permite să se înscrie în acest forum.';

$txt['activate_account'] = 'Activare cont';
$txt['activate_success'] = 'Contul tău a fost activat cu succes. Te poți autentifica acum.';
$txt['activate_not_completed1'] = 'Adresa ta de email trebuie să fie validată înainte de a te putea autentifica.';
$txt['activate_not_completed2'] = 'Aveţi nevoie de alt email de activare ?';
$txt['activate_after_registration'] = 'Vă mulţumim pentru înregistrare. Veţi primi în curând un mesaj de e-mail cu un link pentru a vă activa contul. Dacă nu primiţi un mesaj de e-mail, după o anumită perioadă de timp, verificaţi-vă folderul de spam.';
$txt['invalid_userid'] = 'Utilizatorul nu există';
$txt['invalid_activation_code'] = 'Cod de activare invalid';
$txt['invalid_activation_username'] = 'Nume de utilizator sau adresa de e-mail';
$txt['invalid_activation_new'] = 'Dacă v-aţi înregistrat cu o adresă de e-mail greşită, tastaţi o adresă nouă şi parola dumneavoastră aici.';
$txt['invalid_activation_new_email'] = 'Adresa nouă de email ';
$txt['invalid_activation_password'] = 'Parola veche';
$txt['invalid_activation_resend'] = 'Retrimite codul de activare';
$txt['invalid_activation_known'] = 'Dacă știți deja codul dumneavoastră de activare, vă rugăm să îl tastați aici.';
$txt['invalid_activation_retry'] = 'Cod de activare';
$txt['invalid_activation_submit'] = 'Activare';

$txt['coppa_no_concent'] = 'Administratorul nu a primit încă consimţământul părintelui / tutorelui  pentru contul dumneavoastră.';
$txt['coppa_need_more_details'] = 'Aveţi nevoie de mai multe detalii ?';

$txt['awaiting_delete_account'] = 'Contul tău a fost marcat pentru ştergere! <br />Dacă dorești să îți restaurezi contul te rog să vizitezi &quot;Reactivarea contului&quot; şi să te autentifici din nou.';
$txt['undelete_account'] = 'Reactivează-mi contul';

$txt['in_maintain_mode'] = 'Această secţiune este în Stare de Mentenanţă.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Vă rugăm să citiţi şi să acceptaţi condiţiile de mai jos înainte de a vă înregistra.';
$txt['register_passwords_differ_js'] = 'Cele două parole pe care le-ai introdus nu sunt identice !';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Vă mulţumim pentru înregistrare. Administratorul trebuie să aprobe înregistrarea dumneavoastră înainte de a putea începe să vă utilizaţi contul, veţi primi în scurt timp un e-mail ce vă va aduce la cunoştinţă decizia administratorilor.';

$txt['admin_settings_desc'] = 'Aici puteţi modifica diverse setări legate de înregistrarea noilor membri.';

$txt['setting_enableOpenID'] = 'Permite utilizatorilor să se înregistreze folosind OpenID';

$txt['setting_registration_method'] = 'Metoda de înregistrare a noilor membri';
$txt['setting_registration_disabled'] = 'Înregistrare Dezactivată';
$txt['setting_registration_standard'] = 'Înregistrare Imediată';
$txt['setting_registration_activate'] = 'E-mail de Activare ';
$txt['setting_registration_approval'] = 'Aprobarea Administratorului ';
$txt['setting_notify_new_registration'] = 'Anunţă administratorii atunci când un nou membru se alatură';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Trimite email de bun venit noilor utilizatori';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Vârsta sub care se aplică restricţiile de înregistrare.';
$txt['setting_coppaAge_desc'] = '(Setează la 0 pentru a dezactiva)';
$txt['setting_coppaType'] = 'Acţiunea care trebuie să fie luată în cazul în care se înregistrează un utilizator sub vârsta minimă ';
$txt['setting_coppaType_reject'] = 'Respinge înregistrarea';
$txt['setting_coppaType_approval'] = 'Solicită aprobarea părintelui / tutorelui';
$txt['setting_coppaPost'] = 'Adresa poștală la care trebuie să fie trimise formularele de aprobare';
$txt['setting_coppaPost_desc'] = 'Se aplică doar în cazul în care restricţia de vârstă este menţionată.';
$txt['setting_coppaFax'] = 'Numărul de fax la care trebuie să fie trimise formularele de aprobare.';
$txt['setting_coppaPhone'] = 'Numărul de contact unde părinţii pot pune întrebări privind restricţia de vârstă.';

$txt['admin_register'] = 'Înregistrare de noi membri';
$txt['admin_register_desc'] = 'De aici poți să înregistrezi noi membri în forum şi dacă doreşti, poți să le trimiti detaliile prin e-mail.';
$txt['admin_register_username'] = 'Nume nou de utilizator';
$txt['admin_register_email'] = 'Adresa de email';
$txt['admin_register_password'] = 'Parola';
$txt['admin_register_username_desc'] = 'Nume de utilizator pentru noul membru';
$txt['admin_register_email_desc'] = 'Adresa de e-mail a membrului';
$txt['admin_register_password_desc'] = 'Parola pentru noul membru';
$txt['admin_register_email_detail'] = 'Trimite prin email noua parolă utilizatorului';
$txt['admin_register_email_detail_desc'] = 'Adresa de e-mail este necesară chiar dacă nu este bifată';
$txt['admin_register_email_activate'] = 'Solicită-i utilizatorului să-și activeze contul';
$txt['admin_register_group'] = 'Grupul primar de utilizatori';
$txt['admin_register_group_desc'] = 'Grupul primar de membrii din care vor face parte noii membri';
$txt['admin_register_group_none'] = '(niciun grup primar)';
$txt['admin_register_done'] = 'Membrul %1$s a fost înregistrat cu succes !';

$txt['coppa_title'] = 'Forum cu resticții de vârstă';
$txt['coppa_after_registration'] = 'Îți mulțumim că te-ai înregistrat pe forumul {forum_name_html_safe}.<br /><br />Pentru că ești sub vârsta minimă de {MINIMUM_AGE} ani, avem obligația legală de a obține încuviințarea expresă a unui părinte sau tutore legal înainte de a-ți da acces la cont. Pentru a ușura acest proces, tipărește formularul de mai jos:';
$txt['coppa_form_link_popup'] = 'Încarcă Formularul într-o Fereastră Nouă';
$txt['coppa_form_link_download'] = 'Descarcă Formularul ca Fişier Text';
$txt['coppa_send_to_one_option'] = 'Apoi ia măsuri ca părintele / tutorele tău să trimită formularul completat prin :';
$txt['coppa_send_to_two_options'] = 'Apoi ia măsuri ca părintele / tutorele tău să trimită formularul completat prin:';
$txt['coppa_send_by_post'] = 'Poştă, la următoarea adresă:';
$txt['coppa_send_by_fax'] = 'Fax, la următorul număr:';
$txt['coppa_send_by_phone'] = 'Alternativ, asigură-te că vor suna administratorul la {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Formular de încuviințare pentru înregistrarea ca utilizator pe forumul {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Adresa';
$txt['coppa_form_date'] = 'Dată';
$txt['coppa_form_body'] = 'Eu, {PARENT_NAME},<br /><br />sunt de acord ca {CHILD_NAME} (numele minorului) să devină membru cu drepturi depline al forumului {forum_name_html_safe}, folosind numele de utilizator {USER_NAME}.<br /><br />Înțeleg că anumite informații personale făcute publice de {USER_NAME} pot fi accesate de alți utilizatori ai forumului.<br /><br />Semnat:<br />{PARENT_NAME} (Părinte/Tutore).';

$txt['visual_verification_sound_again'] = 'Joacă din nou';
$txt['visual_verification_sound_close'] = 'Închide fereastra';
$txt['visual_verification_sound_direct'] = 'Aveţi probleme în ascultarea acestei litere ? Încercaţi o legătură directă către ea.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Numele de utilizator este disponibil';
$txt['registration_username_unavailable'] = 'Numele de utilizator nu este disponibil';
$txt['registration_username_check'] = 'Verificaţi dacă numele de utilizator este disponibil';
$txt['registration_password_short'] = 'Parola este prea scurtă';
$txt['registration_password_reserved'] = 'Parola conţine numele dvs. de utilizator / e-mail-ul';
$txt['registration_password_numbercase'] = 'Parola trebuie să conţină atât litere mici şi mari, cât şi numere';
$txt['registration_password_no_match'] = 'Parolele nu se potrivesc';
$txt['registration_password_valid'] = 'Parola este valabilă';

$txt['registration_errors_occurred'] = 'Următoarele erori au fost detectate în înregistrarea dvs. Vă rugăm să le corectaţi pentru a continua:';

$txt['authenticate_label'] = 'Metoda de Autentificare';
$txt['authenticate_password'] = 'Parola';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'URL de Autentificare OpenID';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'Contactează administratorii';
$txt['contact_your_message'] = 'Mesajul tău';
$txt['errors_contact_form'] = 'La procesarea solicitării tale de contact au apărut următoarele erori';
$txt['contact_subject'] = 'Un vizitator ți-a trimis un mesaj';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
