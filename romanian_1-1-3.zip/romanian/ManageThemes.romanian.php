<?php
// Version: 1.1; ManageThemes

$txt['themeadmin_explain'] = 'Temele oferă forumului un aspect și un comportament personalizat. Zona cu setări globale pentru teme permite administratorilor să selecteze tema implicită a site-ului. Administratorii pot permite membrilor să selecteze dintre temele instalate și să valideze teme selectabile.';
$txt['themeadmin_manage'] = 'Administrează şi instalează';
$txt['theme_forum_theme'] = 'Setările globale pentru teme';
$txt['theme_allow'] = 'Permite membrilor să-şi selecteze propriile teme.';
$txt['theme_guests'] = 'Tema implicită generală a forumului:';
$txt['theme_select'] = 'alege...';
$txt['theme_reset'] = 'Resetează toți membrii la următoarea temă:';
$txt['theme_nochange'] = 'Nicio modificare';
$txt['theme_forum_default'] = 'Implicit pentru forum';

$txt['theme_remove'] = 'Dezinstalează';
$txt['theme_remove_confirm'] = 'Ești sigur că vrei să dezinstalezi această temă?';

$txt['theme_install'] = 'Instalează o temă nouă';
$txt['theme_install_file'] = 'Dintr-o arhivă locală (de ex. .zip sau .tar.gz)';
$txt['theme_install_dir'] = 'Dintr-un director de pe serverul hostului:';
$txt['theme_install_error'] = 'Directorul temei nu poate fi găsit sau nu conține teme.';
$txt['theme_install_write_error'] = 'Directorul temelor trebuie să aibe drepturi de scriere pentru a continua.';
$txt['theme_install_go'] = 'Instalaţi';
$txt['theme_install_new'] = 'Creează o copie a temei implicite a ElkArte, numită:';
$txt['theme_install_new_confirm'] = 'Sunteţi sigur că doriţi să instalaţi această temă nouă ?';
$txt['theme_install_writable'] = 'Atenție - nu poți creea sau instala teme noi deoarece directorul pentru teme nu are drepturi de scriere.';
$txt['theme_install_general'] = 'Tema nu pare a fi unde ar trebui să fie, verifică informațiile introduse.';
$txt['theme_installed'] = 'Instalarea reuşită';
$txt['theme_installed_message'] = 'a fost instalată cu succes.';

$txt['theme_pick'] = 'Alege o temă...';
$txt['theme_preview'] = 'Previzualizare temă';
$txt['theme_set'] = 'Foloseşte această temă';
$txt['theme_user'] = 'persoana foloseşte această temă.';
$txt['theme_users'] = 'persoane folosesc această temă.';
$txt['theme_pick_variant'] = 'Selectează varianta:';

$txt['theme_edit'] = 'Editează Tema';
$txt['theme_edit_style'] = 'Modifică stylesheet-urile (culori, fonturi, etc.)';
$txt['theme_edit_index'] = 'Modifică fişierul index.template. (template principal)';
$txt['theme_edit_no_save'] = 'Acest fișier nu poate fi salvat deoarece nu are drepturi de scriere. Verifică dacă fișierul are drepturile corespunzătoare (777, etc.)';
$txt['theme_edit_save'] = 'Salvează modificările';
$txt['theme_edit_not_writable'] = 'Needitabil';

$txt['theme_global_description'] = 'Acesta este tema implicită, ceea ce înseamnă că tema ta se va schimba odată cu setările administratorilor şi cu secţiunea pe care o citești.';

$txt['theme_url_config'] = 'Adrese URL Teme şi Configurare ';
$txt['theme_variants'] = 'Versiuni Temă ';
$txt['theme_options'] = 'Opţiuni şi Preferinţe Teme';
$txt['actual_theme_name'] = 'Numele acestei teme:';
$txt['actual_theme_dir'] = 'Directorul acestei teme:';
$txt['actual_theme_url'] = 'Adresa URL a acestei teme:';
$txt['actual_images_url'] = 'Adresa URL pentru imaginile asociate cu această temă: ';

$txt['theme_variants_default'] = 'Default theme variant:';
$txt['theme_variants_user_disable'] = 'Disable user variant selection.';

$txt['site_slogan'] = 'Site slogan:';
$txt['site_slogan_desc'] = '(Add your own text for a slogan here.)';
$txt['header_layout'] = 'Header layout:';
$txt['header_layout_desc'] = '(This setting allows you to select one of three layouts for the header.)';
$txt['header_layout_default_name'] = 'Default:';
$txt['header_layout_default_desc'] = 'The logo is placed on the right and the name of the community on the left.';
$txt['header_layout_logo_only_name'] = 'Only logo:';
$txt['header_layout_logo_only_desc'] = 'Only the logo is displayed, in a centered position.';
$txt['header_layout_inverted_name'] = 'Logo on the left:';
$txt['header_layout_inverted_desc'] = 'Similar to Default, but with logo and name inverted (i.e. name on the right, logo on the left).';
$txt['header_layout_default'] = 'Implicit';
$txt['header_layout_logo_only'] = 'Only logo';
$txt['header_layout_inverted'] = 'Logo on the left';
$txt['forum_width'] = 'Forum width:';
$txt['forum_width_desc'] = '(Sets the forum width. Examples: 950px, 80%, 1240px.)';

$txt['enable_news'] = 'News line in the forum header:';
$txt['enable_news_off'] = 'Off';
$txt['enable_news_random'] = 'Random';
$txt['enable_news_fader'] = 'Fader';
$txt['enable_news_off_name'] = 'Off:';
$txt['enable_news_off_desc'] = 'No news shown.';
$txt['enable_news_random_name'] = 'Random:';
$txt['enable_news_random_desc'] = 'One news shown chosen at random.';
$txt['enable_news_fader_name'] = 'Fader:';
$txt['enable_news_fader_desc'] = 'All the news are displayed sequentially.';

$txt['show_group_key'] = 'Show group key on board index.';
$txt['additional_options_collapsible'] = 'Enable collapsible additional post options.';
$txt['who_display_viewing'] = 'Arată cine citește indexul ariii și postările:';
$txt['who_display_viewing_off'] = 'Nu afişa';
$txt['who_display_viewing_numbers'] = 'Afişează doar numerele';
$txt['who_display_viewing_names'] = 'Afişează numele membrilor';
$txt['show_stats_index'] = 'Show statistics on board index.';
$txt['latest_members'] = 'Show latest member on board index.';
$txt['last_modification'] = 'Show last modification date on modified posts.';
$txt['user_avatars'] = 'Show user avatars in message view.';
$txt['member_list_bar'] = 'Afişează bara pentru lista de utilizatori în board index';
$txt['current_pos_text_img'] = 'Show current position in forum as link instead of text.';
$txt['show_view_profile_button'] = 'Show view profile button under post.';
$txt['enable_mark_as_read'] = 'Enable and show \'Mark as Read\' buttons.';
$txt['header_logo_url'] = 'Logo image URL:';
$txt['header_logo_url_desc'] = '(Leave blank to show forum name or default logo.)';

$txt['recent_post_topics'] = 'Show recent posts or recent topics on board index.';
$txt['show_recent_topics'] = 'Show recent topics';
$txt['show_recent_posts'] = 'Show recent posts';
$txt['number_recent_posts'] = 'Number of recent posts or topics to display on board index:';
$txt['number_recent_posts_desc'] = '(To disable the recent posts/topics bar set this value to zero.)';
$txt['hide_post_group'] = 'Hide post group titles for grouped members.';
$txt['hide_post_group_desc'] = '(Enabling this will not display a member\'s post group title on the message view if they are assigned to a non-post based group.)';

$txt['theme_options_defaults'] = 'Acestea sunt valorile implicite pentru unele setări specifice privind membrii.  Schimbarea acestora va afecta doar membrii noi şi vizitatorii.';
$txt['theme_options_title'] = 'Schimbă sau resetează opţiunile implicite';

$txt['themeadmin_title'] = 'Theme Management and Options';
$txt['themeadmin_description'] = 'Aici poţi modifica setările temelor tale, actualiza selecţiile temei, reseta opţiunile membrilor şi altele.';
$txt['themeadmin_admin_desc'] = 'Themes provide the different \'looks and feels\' of your forum. Theme Management and Options allow you to install new site themes, change the default theme, reset all members to use a certain theme, and choose other settings related to theme selection. Remember to look at the theme settings for your different themes for their individual layout options.';
$txt['themeadmin_list_desc'] = 'In the Theme Settings area you can view the list of themes that you have installed, change their directory paths and settings, and uninstall them.';
$txt['themeadmin_reset_desc'] = 'In the Member Options area you have the ability to change theme-specific options that affect all members. You will only see those themes that have their own set of option settings.';
$txt['themeadmin_edit_desc'] = 'In the Modify Themes area you can alter the stylesheet and source code of your installed themes. You will need a basic understanding of CSS and PHP to effectively change a theme and not break your forum at the same time.';
$txt['themeadmin_modify_styles'] = 'Changing a themes style is risky so be certain of what you are doing. Always have a backup copy of the theme directory that you are working in to use to recover from an error with. For help with this before you start, visit the <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">ElkArte Community</a>.';

$txt['themeadmin_list_heading'] = 'Setările temlor';
$txt['themeadmin_list_tip'] = 'The layout settings may be different for each installed theme. Edit the installed themes to set their individual options, change their directory or URL settings, or to find other options.';
$txt['themeadmin_list_theme_dir'] = 'Theme directory: (templates)';
$txt['themeadmin_list_invalid'] = '(Warning! this path is not correct.)';
$txt['themeadmin_list_theme_url'] = 'URL to above directory:';
$txt['themeadmin_list_images_url'] = 'URL to images directory:';
$txt['themeadmin_list_reset'] = 'Resetează adresele URL şi Directoarele Temelor';
$txt['themeadmin_list_reset_dir'] = 'Base path to Themes directory:';
$txt['themeadmin_list_reset_url'] = 'Base URL to the same directory:';
$txt['themeadmin_list_reset_go'] = 'Încercare de a reseta toate temele';

$txt['themeadmin_reset_tip'] = 'Each theme may have custom options available for selection by your members. These include options like &quot;quick reply&quot;, avatars, signatures, layout options and other similar options.  This is where you can change the defaults or reset everyone\'s options.<br /><br />Remember this: A theme may be designed with some settings as the default. In which case you will not see a setting for those options.';
$txt['themeadmin_reset_defaults'] = 'Resetează opţiunile implicite (pentru vizitatori) pentru această tema';
$txt['themeadmin_reset_defaults_current'] = 'opţiuni setate în prezent.';
$txt['themeadmin_reset_members'] = 'Resetează toate opţiunile utilizatorilor din aceste moment pentru această temă';
$txt['themeadmin_reset_remove'] = 'Elimină toate opţiunile utilizatorilor şi foloseşte-le pe cele implicite';
$txt['themeadmin_reset_remove_current'] = 'membri care folosesc în prezent propriile lor opţiuni.';
// Don't use entities in the below string.
$txt['themeadmin_reset_remove_confirm'] = 'Eşti sigur că vrei să elimini toate opţiunile temei?\\nAceast lucru va modifica şi unele câmpuri de profil personalizate.';
$txt['themeadmin_reset_options_info'] = 'The options below will reset options for <em>everyone</em>.  To change an option, select &quot;change&quot; in the box next to it, and then select a value for it.  To use the default, select &quot;default&quot;.  Otherwise, use &quot;don\'t change&quot; to keep it as-is.';
$txt['themeadmin_reset_options_change'] = 'Modifică';
$txt['themeadmin_reset_options_none'] = 'Nu schimba';
$txt['themeadmin_reset_options_default'] = 'Implicit';

$txt['themeadmin_edit_browse'] = 'Vizualizează fişierele şi template-ul din această temă.';
$txt['themeadmin_edit_style'] = 'Editează stylesheet-urile acestei teme.';
$txt['themeadmin_edit_copy_template'] = 'Copiază un fişier template din tema pe care este bazat.';
$txt['themeadmin_edit_exists'] = 'există deja';
$txt['themeadmin_edit_do_copy'] = 'copiază';
$txt['themeadmin_edit_copy_warning'] = 'When the system needs a template or language file which is not in the current theme, it looks in the theme it is based on, or the default theme.<br />Unless you need to modify a template, it\'s better not to copy it.';
$txt['themeadmin_edit_copy_confirm'] = 'Eşti sigur că vrei să copiezi acest template?';
$txt['themeadmin_edit_overwrite_confirm'] = 'Are you sure you want to copy this template over the one that already exists?\nThis will OVERWRITE any changes you\\\'ve made';
$txt['themeadmin_edit_no_copy'] = '<em>nu pot copia</em>';
$txt['themeadmin_edit_filename'] = 'Numele fişierului';
$txt['themeadmin_edit_modified'] = 'Modificat ultima dată';
$txt['themeadmin_edit_size'] = 'Mărime';
$txt['themeadmin_edit_error'] = 'Fişierul pe care ai încercat să-l salvezi a generat următoarea eroare:';
$txt['themeadmin_edit_on_line'] = 'Beginning on line:';
$txt['themeadmin_edit_preview'] = 'Previzualizare';
$txt['themeadmin_selectable'] = 'Themes the user is permitted to select:';
$txt['themeadmin_themelist_link'] = 'Show the list of installed themes';

// Strings for the variants
$txt['variant_light'] = 'ElkArte Light';
$txt['variant_besocial'] = 'ElkArte Be Social!';
