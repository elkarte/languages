<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Bine ai venit';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Verificarea drepturilor de scriere';
$txt['install_step_forum'] = 'Setările forumului';
$txt['install_step_databaseset'] = 'Setările bazei de date';
$txt['install_step_databasechange'] = 'Popularea bazei de date';
$txt['install_step_admin'] = 'Contul de administrator';
$txt['install_step_delete'] = 'Finalizează instalarea';

$txt['installer'] = 'Instalatorul ElkArte';
$txt['installer_language'] = 'Limba';
$txt['installer_language_set'] = 'Setează';
$txt['congratulations'] = 'Felicitări, procesul de instalare este finalizat!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Directorul de instalare are setate în continuare drepturi de scriere. Din motive de securitate, este de preferat să folosești chmod pentru a elimina aceste drepturi.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(nu funcţionează pe toate serverele.)</em>  ';
$txt['go_to_your_forum'] = 'Acum îți poți vizita <a href="%1$s">forumul proaspăt instalat</a> şi poţi începe să-l utilizezi. Ar trebui mai întâi să te asiguri că ești autentificat, după care vei putea accesa centrul de administrare.';
$txt['good_luck'] = 'Mulțumim că ai instalat ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Bine ai venit';
$txt['install_welcome_desc'] = 'Bun venit în ElkArte. Acest script te va ghida în procesul de instalare a %1$s. În următorii pași îți vom solicita câteva detalii despre forumul pe care vrei să-l instalezi și care în câteva minute va fi gata de a fi utilizat.';
$txt['install_all_lovely'] = 'Am finalizat unele teste iniţiale pe serverul tău şi totul pare a fi în ordine. Fă click pe butonul &quot;Continuă&quot; de mai jos pentru a începe.';

$txt['user_refresh_install'] = 'Forumul a fost actualizat';
$txt['user_refresh_install_desc'] = 'În timpul instalării, programul a constatat (cu detaliile pe care le-ai furnizat) că una sau mai multe din tabele pe care acest program de instalare le-ar putea crea există deja.<br />Au fost recreate cu datele implicite toate tabelele lipsă din instalarea existentă dar niciun fel de date nu au fost şterse din tabelele vechi.';

$txt['default_topic_subject'] = 'Bun venit pe ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Discuţii generale';
$txt['default_board_description'] = 'Poți discuta despre orice în această secţiune.';
$txt['default_category_name'] = 'Categorie generală';
$txt['default_time_format'] = '%B %d, %Y, %I:%M:%S %p';
$txt['default_news'] = 'ElkArte - Proaspăt instalat!';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[dezaprobare]';
$txt['default_karmaApplaudLabel'] = '[aprobare]';
$txt['default_reserved_names'] = 'Admin\nWebmaster\nVizitator\nroot';
$txt['default_smileyset_name'] = 'Setul lui Fugue';
$txt['default_theme_name'] = 'Tema implicită ElkArte';

$txt['default_administrator_group'] = 'Administrator';
$txt['default_global_moderator_group'] = 'Moderator global';
$txt['default_moderator_group'] = 'Moderator';
$txt['default_newbie_group'] = 'Nou venit';
$txt['default_junior_group'] = 'Membru junior';
$txt['default_full_group'] = 'Membru cu drepturi depline';
$txt['default_senior_group'] = 'Membru senior';
$txt['default_hero_group'] = 'Membru erou';

$txt['default_smiley_smiley'] = 'Zâmbește';
$txt['default_wink_smiley'] = 'Fă cu ochiul';
$txt['default_cheesy_smiley'] = 'Obraznic';
$txt['default_grin_smiley'] = 'Rânjește';
$txt['default_angry_smiley'] = 'Furios';
$txt['default_sad_smiley'] = 'Trist';
$txt['default_shocked_smiley'] = 'Şocat';
$txt['default_cool_smiley'] = 'Grozav';
$txt['default_huh_smiley'] = 'Ce?';
$txt['default_roll_eyes_smiley'] = 'Dă-ți ochii peste cap';
$txt['default_tongue_smiley'] = 'Scoate limba';
$txt['default_embarrassed_smiley'] = 'Ruşinat';
$txt['default_lips_sealed_smiley'] = 'Buze lipite';
$txt['default_undecided_smiley'] = 'Nehotărât';
$txt['default_kiss_smiley'] = 'Sărută';
$txt['default_cry_smiley'] = 'Plângi';
$txt['default_evil_smiley'] = 'Rău';
$txt['default_azn_smiley'] = 'Azn';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Râzi';
$txt['default_police_smiley'] = 'Poliţia';
$txt['default_angel_smiley'] = 'Înger';

$txt['error_message_click'] = 'Click aici';
$txt['error_message_try_again'] = 'ca să încerci din nou acest pas.';
$txt['error_message_bad_try_again'] = 'ca să încerci instalarea oricum, dar ţine cont de faptul că acest lucru este <em>cu tărie</em> descurajat.';

$txt['install_settings'] = 'Setările forumului';
$txt['install_settings_info'] = 'În această pagină vei defini câteva setări principale ale forumului. ElkArte a detectat automat câteva dintre acestea.';
$txt['install_settings_name'] = 'Numele forumului';
$txt['install_settings_name_info'] = 'Acesta este numele forumului, de ex. &quot;Forumul de Test&quot;.';
$txt['install_settings_name_default'] = 'Comunitatea mea';
$txt['install_settings_url'] = 'URL-ul forumului';
$txt['install_settings_url_info'] = 'Acesta este adresa URL a forumului tău, <strong>fără  \'/\'!</strong>.<br />În cele mai multe cazuri, poți păstra valorile implicite din această casetă - de obicei sunt corecte.';
$txt['install_settings_compress'] = 'Compresie Gzip';
$txt['install_settings_compress_title'] = 'Comprimă paginile de ieşire pentru a reduce lățimea de bandă consumată.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Această facilitate nu funcționează corect pe toate serverele dar ar putea aduce o importantă economisire a benzii.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Fă click aici ca să testezi disponibilitatea ei</a>. (rezultatul ar trebui să fie "PASS".)';
$txt['install_settings_dbsession'] = 'Memorează sesiunile în baza de date';
$txt['install_settings_dbsession_title'] = 'Folosește baza de date pentru memorarea datelor privind sesiunile, în loc să folosești fişiere.';
$txt['install_settings_dbsession_info1'] = 'Această facilitate este aproape întotdeauna indicată, întrucât face ca sesiunile să fie mult mai fiabile.';
$txt['install_settings_dbsession_info2'] = 'Această facilitate este în general o idee bună - dar s-ar putea să nu funcţioneze corect pe acest server.';
$txt['install_settings_proceed'] = 'Continuă';

$txt['db_settings'] = 'Setările serverului bazei de date';
$txt['db_settings_info'] = 'Acestea sunt setările ce vor fi utilizate pentru legătura cu serverul bazei tale de date. Dacă nu știi valorile, întreabă-ți host-ul.';
$txt['db_settings_type'] = 'Tipul bazei de date';
$txt['db_settings_type_info'] = 'A fost detectat suport pentru mai multe tipuri de baze de date. Pe care vrei să îl folosești?';
$txt['db_settings_server'] = 'Numele serverului';
$txt['db_settings_server_info'] = 'Aproape întotdeauna, numele este localhost - deci, dacă nu ştii exact, încearcă localhost.';
$txt['db_settings_port'] = 'Portul';
$txt['db_settings_port_info'] = 'Dacă serverul ascultă pe portul implicit sau dacă nu știi portul, lasă acest câmp necompletat.';
$txt['db_settings_username'] = 'Numele utilizatorului';
$txt['db_settings_username_info'] = 'Completează câmpul cu numele de utilizator cu care trebuie să te conectezi la baza de date.<br />Dacă nu știi acest nume, încearcă cu numele contului de FTP - de cele mai multe ori sunt identice.';
$txt['db_settings_password'] = 'Parola';
$txt['db_settings_password_info'] = 'Completează câmpul cu parola necesară ca să te conectezi la baza de date.<br />Dacă nu o știi, încearcă cu parola contului de FTP.';
$txt['db_settings_database'] = 'Numele bazei de date';
$txt['db_settings_database_info'] = 'Completează cu numele bazei de date pe care vrei ca ElkArte să o folosească pentru stocarea datelor.';
$txt['db_settings_database_info_note'] = 'Dacă această bază de date nu există, programul de instalare va încerca să o creeze.';
$txt['db_settings_database_file'] = 'Numele fișierului bazei de date';
$txt['db_settings_database_file_info'] = 'Acesta este numele fișierului în care se vor stoca datele ElkArte. Îți recomandăm să folosești numele generat aleator și să setezi calea către acest fișier în așa fel încât să fie în afara zonei public accesibile a serverului web.';
$txt['db_settings_prefix'] = 'Prefixul tabelelor';
$txt['db_settings_prefix_info'] = 'Prefixul fiecărei tabele din baza de date. <strong>Nu instala două forumuri cu același prefix!</strong><br />Folosind această setare, devine posibilă folosirea bazei de date de către mai multe aplicații.';
$txt['db_populate'] = 'Baza de date a fost populată';
$txt['db_populate_info'] = 'Setările tale au fost salvate şi baza de date a fost populată cu toate datele necesare pentru a face forumul funcțional. Rezumatul populării :';
$txt['db_populate_info2'] = 'Fă click pe &quot;Continuare&quot; pentru a merge la pagina de creare a contului de administrator.';
$txt['db_populate_inserts'] = 'Au fost inserate %1$d rânduri.';
$txt['db_populate_tables'] = 'Au fost create %1$d tabele.';
$txt['db_populate_insert_dups'] = 'Au fost ignorate %1$d inserări duplicate.';
$txt['db_populate_table_dups'] = 'Aau fost ignorate %1$d tabele duplicate.';

$txt['user_settings'] = 'Creează-ți contul';
$txt['user_settings_info'] = 'Programul de instalare îți va crea acum un cont de administrator.';
$txt['user_settings_username'] = 'Numele de utilizator';
$txt['user_settings_username_info'] = 'Alege numele de utilizator cu care vrei să te autentifici.';
$txt['user_settings_password'] = 'Parola';
$txt['user_settings_password_info'] = 'Completează parola şi memoreaz-o bine!';
$txt['user_settings_again'] = 'Parola';
$txt['user_settings_again_info'] = '(doar pentru verificare)';
$txt['user_settings_email'] = 'Adresa de email';
$txt['user_settings_email_info'] = 'Trebuie să completezi şi adresa de email. <strong>Aceasta trebuie să fie o adresă de email validă!</strong>  ';
$txt['user_settings_database'] = 'Parola pentru baza de date';
$txt['user_settings_database_info'] = 'Din motive de securitate, la crearea contului de administrator programul de instalare necesită introducerea parolei pentru baza de date.';
$txt['user_settings_skip'] = 'Sari peste';
$txt['user_settings_skip_sure'] = 'Ești sigur că vrei să sari peste crearea contului de administrator?';
$txt['user_settings_proceed'] = 'Termină';

$txt['ftp_checking_writable'] = 'Verific dacă fișierele pot fi modificate';
$txt['ftp_setup'] = 'Informaţiile pentru conexiunea FTP';
$txt['ftp_setup_info'] = 'Programul de instalare se poate conecta prin FTP pentru a corecta drepturile de acces la fișerele care trebuie să fie editabile și nu sunt. Dacă conexiunea FTP nu funcționează, va trebui să te conectezi manual și să faci fișierele editabile. Ține cont că SSL nu este suportat în acest moment.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'Adresa și portul serverului de FTP.';
$txt['ftp_port'] = 'Portul';
$txt['ftp_username'] = 'Numele utilizatorului';
$txt['ftp_username_info'] = 'Numele de utilizator pentru autentificare.<em>NU va fi salvat nicăieri!</em>';
$txt['ftp_password'] = 'Parola';
$txt['ftp_password_info'] = 'Parola pentru autentificare. <em>NU va fi salvată nicăieri!</em>';
$txt['ftp_path'] = 'Calea de instalare';
$txt['ftp_path_info'] = 'Aceasta este calea <em>relativă</em> folosită pe serverul FTP.';
$txt['ftp_path_found_info'] = 'Calea din caseta de mai sus a fost detectată în mod automat.';
$txt['ftp_connect'] = 'Conectează';
$txt['ftp_setup_why'] = 'Ce face acest pas ?';
$txt['ftp_setup_why_info'] = 'Pentru ca ElkArte să funcționeze corect, anumite fișiere trebuie să poată fi editabile. Acest pas îți permite să lași programul de instalare să facă modificările necesare în locul tău. Totuși, în anumite situații s-ar putea să nu meargă - în acest caz, modifică drepturile următoare la 777 (editabile; pe unele host-uri e 755):';
$txt['ftp_setup_again'] = 'pentru a testa dacă aceste fișiere sunt din nou editabile.';

$txt['error_php_too_low'] = 'Atenție! Se pare că webserverul tău nu are instalată nici o versiune de PHP care să corespundă cu <strong>cerințele minime pentru instalarea</strong> ElkArte.<br />Dacă nu-ți găzduiești singur site-ul, va trebui fie să-i soliciți host-ului să upgradeze PHP fie să-ți găsești alt host. Dacă ți-l găzduiești singur, te rugăm upgrade-ază-ți PHP-ul la o versiune recentă.<br /><br /> Dacă ești sigur că versiunea de PHP este destul de recentă, poți continua - deși este total contraindicat.';
$txt['error_missing_files'] = 'Nu am găsit fişiere esențiale pentru instalare în directorul acestui script!<br /><br />Asigură-te că ai încărcat întregul pachet de instalare, inclusiv fişierul sql, şi apoi înceracă din nou.';
$txt['error_session_save_path'] = 'Te rugăm să îţi informezi gazda web că variabila <strong>session.save_path specificată în php.ini</strong> nu este valabilă! Ea trebuie să fie schimbată către un director care <strong>există</ strong> şi care<strong>are drepturi de scriere</strong> (este editabil) de către utilizatorul sub care se execută PHP .<br />';
$txt['error_windows_chmod'] = 'Serverul rulează Windows și câteva fișiere cruciale nu pot fi editate. Cere-i host-ului să seteze fișierele din directorul ElkArte cu <strong>drepturi de scriere</strong> pentru utilizatorul sub care se execută PHP. Fișierele sau directoarele care trebuie să fie editabile sunt:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Nu se poate efectua conectarea la serverul FTP cu această combinaţie de detalii.';
$txt['error_db_file'] = 'Nu se poate găsi scriptul sursă al bazei de date! Vă rugăm să verificaţi dacă fişierul %1$s este în directorul sursă al forumului dumneavoastră. ';
$txt['error_db_connect'] = 'Nu se poate efectua conectarea la serverul bazei de date cu detaliiile furnizate.<br /><br />Dacă nu ești sigur ce trebuie completat, te rog să contactezi host-ul.';
$txt['error_db_too_low'] = 'Versiunea serverului bazei de date este foarte veche și nu îndeplinește cerințele minime ale ElkArte.<br /><br />Cere-i host-ului fie să actualizeze serverul fie să-ți ofere unul nou iar dacă refuză, caută alt host.';
$txt['error_db_database'] = 'Programul de instalare nu a putut accesa baza de date &quot;<em>%1$s</em>&quot;. Unele host-uri impun crearea bazei de date din panoul de administrare înainte de a putea fi utilizată de aplicații precum ElkArte. Altele adaugă prefixe - de exemplu, numele de utilizator - la numele bazei de date.';
$txt['error_db_queries'] = 'Unele interogări nu au fost executate corect. Cauza poate fi o versiune nesuportată (veche sau de dezvoltare) a softului bazei de date.<br /><br />Informațiile tehnice despre interogări:';
$txt['error_db_queries_line'] = 'Linia # ';
$txt['error_db_missing'] = 'Programul de instalare nu a putut detecta în PHP suport pentru nici un tip de bază de date pe care ElkArte să îl poată utiliza. Cere-i host-ului să se verifice dacă PHP a fost compilat cu suport pentru tipurile de baze de date dorite sau dacă extensiile necesare ale PHP sunt încărcate. În momentul de față ElkArte suportă extensiile: &quot;%1$s&quot;.';
$txt['error_db_script_missing'] = 'Programul de instalare nu a găsit nici un fișier pentru scripturile de instalare aferente bazei de date detectate. Verifică dacă ai încărcat în directorul forumului tău fișierele cu scripturi necesare, de exemplu &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Programul de instalare nu a detectat suport pentru administrarea sesiunilor în instalarea curentă a PHP-ului de pe server. Cere-i host-ului să verifice dacă PHP a fost compilat cu suport pentru sesiuni (de fapt, ca să lipsească acest suport, PHP ar fi trebut compilat în mod explicit fără...)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Ai tastat două parole complet diferite!';
$txt['error_user_settings_no_password'] = 'Parola trebuie să fie de cel puţin patru caractere.';
$txt['error_user_settings_taken'] = 'Există deja un utilizator înregistrat cu acest nume de utilizator sau cu această adresă de email.<br /><br />Solicitarea ta de creare a contului nu a fost îndeplinită.';
$txt['error_user_settings_query'] = 'A apărut o eroare de bază de date în timpul încercării de a crea un administrator. Eroarea este:';
$txt['error_subs_missing'] = 'Fișierul sources/Subs.php nu a fost găsit. Verifică dacă a fost încărcat corect și încearcă din nou.';
$txt['error_db_alter_priv'] = 'Contul pentru baza de date pe care l-ai specificat nu are drepturi pentru operațiile ALTER, CREATE și/sau DROP asupra tabelelor din baza de date; aceste drepturi sunt necesare pentru funcționarea corectă a ElkArte.';
$txt['error_versions_do_not_match'] = 'Programul de instalare a detectat că există deja instalată o altă versiune de ElkArte cu detaliile specificate. Dacă încerci să actualizezi ElkArte, ar trebui să utilizezi programul de actualizare și nu pe cel de instalare.<br /><br />Alternativ, poți folosi detalii diferite (pentru o instalare nouă) sau să creezi o copie de siguranță a bazei de date curente după care să ștegi datele conținute de aceasta.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'Versiunea curentă a bazei de date nu acceptă utilizarea setului de caractere UTF-8. Nu poți instala ElkArte.';
$txt['error_valid_email_needed'] = 'Nu ai introdus o adresă de e-mail validă.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Avertizare !';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Trebuie să introduci un nume pentru fişierul bazei de date SQLite. ';
$txt['error_db_prefix_numeric'] = 'Tipul de bază de date selectat nu acceptă utilizarea de prefixe numerice.';
$txt['error_invalid_characters_username'] = 'Caracter invalid în numele de utilizator';
$txt['error_username_too_long'] = 'Numele de utilizator trebuie să conțină maxim 25 de caractere.';
$txt['error_username_left_empty'] = 'Câmpul numelui de utilizator este gol.';
$txt['error_db_filename_exists'] = 'Baza de date pe care încerci să o creezi există deja. Şterge baza de date existentă sau foloseşte un alt nume.';
$txt['error_db_prefix_reserved'] = 'Prefixul pe care l-ai introdus este un prefix rezervat. Te rugăm să introduci un alt prefix.';

$txt['upgrade_upgrade_utility'] = 'Utilitarul pentru actualizarea ElkArte';
$txt['upgrade_warning'] = 'Avertizare !';
$txt['upgrade_critical_error'] = 'Eroare critică!';
$txt['upgrade_continue'] = 'Continuă';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Sari peste';
$txt['upgrade_note'] = 'Notă!';
$txt['upgrade_step'] = 'Pas';
$txt['upgrade_steps'] = 'Paşi';
$txt['upgrade_progress'] = 'Progres';
$txt['upgrade_overall_progress'] = 'Progres general';
$txt['upgrade_step_progress'] = 'Progresul pasului curent';
$txt['upgrade_time_elapsed'] = 'Timp trecut';
$txt['upgrade_time_mins'] = 'minute';
$txt['upgrade_time_secs'] = 'secunde';

$txt['upgrade_incomplete'] = 'Incomplet';
$txt['upgrade_not_quite_done'] = 'Nu este gata încă !';
$txt['upgrade_paused_overload'] = 'Actualizarea a intrat în pauză pentru a evita supraîncărcarea serverului. Nu te îngrijora, nu s-a întâmplat nimic. Fă click pe butonul <label for="contbutt">continuă</label> de mai jos pentru a merge mai departe.';

$txt['upgrade_ready_proceed'] = 'Îți mulțumim că ai ales să actualizezi ElkArte la versiunea %1$s. Toate fișierele par a fi la locul lor și suntem gata să ne apucăm de treabă.';

$txt['upgrade_error_script_js'] = 'Scriptul de actualizare nu poate găsi fișierul script.js, sau acesta este învechit. Asigură-te că sunt setate corect căile pentru teme. Poți descărca un script pentru verificare și depanare de pe site-ul cu <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">utilitare pentru ElkArte</a>.';

$txt['upgrade_warning_lots_data'] = 'Scriptul de actualizare a detectat că forumul tău conține multe date care trebuie prelucrate. Acest proces poate lua ceva timp, în funcție de server și de dimensiunea forumului. Pentru forumuri foarte mari (~ 300.000 mesaje) procesul poate dura câteva ore.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';