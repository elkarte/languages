<?php
// Version: 1.1; Maintenance

$txt['repair_zero_ids'] = 'Au fost găsite subiecte şi/sau mesaje cu ID-uri 0. ';
$txt['repair_missing_topics'] = 'Mesajul #%1$d este într-un subiect inexistent #%2$d.';
$txt['repair_missing_messages'] = 'Subiectul #%1$d nu conţine (de fapt) niciun mesaj.';
$txt['repair_stats_topics_1'] = 'Subiectul #%1$d are ID-ul primului mesaj %2$d, ceea ce este incorect.';
$txt['repair_stats_topics_2'] = 'Subiectul #%1$d are ID-ul ultimului mesaj %2$d, ceea ce este incorect.';
$txt['repair_stats_topics_3'] = 'Subiectul #%1$d are un număr greşit de răspunsuri, %2$d.';
$txt['repair_stats_topics_4'] = 'Subiectul #%1$d are un număr greşit de mesaje postate neaprobate, %2$d. ';
$txt['repair_stats_topics_5'] = 'Subiectul #%1$d are marcaj de aprobare greşit.';
$txt['repair_missing_boards'] = 'Subiectul #%1$d este în aria #%2$d, care lipseşte.';
$txt['repair_missing_categories'] = 'Aria #%1$d este în categoria #%2$d, care lipseşte.';
$txt['repair_missing_posters'] = 'Mesajul #%1$d a fost postat de către membrul #%2$d, care acum lipseşte.';
$txt['repair_missing_parents'] = 'Aria #%1$d este o subarie a #%2$d, care lipseşte.';
$txt['repair_missing_polls'] = 'Subiectul #%1$d este legat de un sondaj inexistent #%2$d. ';
$txt['repair_polls_missing_topics'] = 'Sondajul #%1$d este legat de subiectul inexistent #%2$d.';
$txt['repair_missing_calendar_topics'] = 'Evenimentul #%1$d este legat de subiectul #%2$d, care lipseşte.';
$txt['repair_missing_log_topics'] = 'Subiectul #%1$d este marcat ca fiind citit de una sau mai multe persoane, dar nu există.';
$txt['repair_missing_log_topics_members'] = 'Membrul #%1$d a marcat unul sau mai multe subiecte ca fiind citite, dar nu există.';
$txt['repair_missing_log_boards'] = 'Aria #%1$d este marcată ca fiind citită de una sau mai multe persoane, dar nu există.';
$txt['repair_missing_log_boards_members'] = 'Membrul #%1$d a marcat una sau mai multe secţiuni ca fiind citite, dar nu există.';
$txt['repair_missing_log_mark_read'] = 'Aria #%1$d este marcată ca fiind citită de una sau mai multe persoane, dar nu există.';
$txt['repair_missing_log_mark_read_members'] = 'Membrul #%1$d a marcat una sau mai multe secţiuni ca fiind citite, dar nu există.';
$txt['repair_missing_pms'] = 'Mesajul privat #%1$d a fost trimis uneia sau mai multor persoane, dar nu există.';
$txt['repair_missing_recipients'] = 'Membrul #%1$d a primit unul sau mai multe mesaje private, dar nu există.';
$txt['repair_missing_senders'] = 'Mesajul privat #%1$d a fost trimis de către membrul #%2$d, care nu există.';
$txt['repair_missing_notify_members'] = 'Notificările au fost solicitate de către membrul #%1$d, care nu există.';
$txt['repair_missing_cached_subject'] = 'Tema subiectului #%1$d nu este stocată în cache.';
$txt['repair_missing_topic_for_cache'] = 'Cuvântul din cache \'%1$s\' este legat de un subiect inexistent.';
$txt['repair_missing_log_poll_member'] = 'Sondajul #%1$d a primit un vot de la membrul #%2$d , care acum lipseşte.';
$txt['repair_missing_log_poll_vote'] = 'A fost exprimat un vot de către membrul #%1$d în sondajul inexistent #%2$d. ';
$txt['repair_missing_thumbnail_parent'] = 'Există o imagine în miniatură numită %1$s, dar nu are un părinte. ';
$txt['repair_report_missing_comments'] = 'Raportarea #%1$d pentru subiectul: &quot;%2$s&quot; nu are comentarii.';
$txt['repair_comments_missing_report'] = 'Comentariul din raportarea #%1$d trimisă de %2$s nu are niciun raport aferent.';
$txt['repair_group_request_missing_member'] = 'Încă mai există o cerere de aderare la grup pentru membrul şters #%1$d.';
$txt['repair_group_request_missing_group'] = 'Încă există o cerere de aderare la grup pentru grupul sters #%1$d. ';

$txt['repair_currently_checking'] = 'În curs de verificare: &quot;%1$s&quot; ';
$txt['repair_currently_fixing'] = 'În curs de reparare: &quot;%1$s&quot; ';
$txt['repair_operation_zero_topics'] = 'Subiecte cu id_topic incorect setat la zero';
$txt['repair_operation_zero_messages'] = 'Mesaje cu id_msg setat incorect la zero';
$txt['repair_operation_missing_topics'] = 'Mesaje cărora le lipsesc intrările de subiecte';
$txt['repair_operation_missing_messages'] = 'Subiecte fără niciun mesaj ';
$txt['repair_operation_stats_topics'] = 'Subiecte cu primul şi ultimul mesaj incorect.';
$txt['repair_operation_stats_topics2'] = 'Subiecte cu număr greşit de răspunsuri';
$txt['repair_operation_stats_topics3'] = 'Subiecte cu număr greşit de mesaje neaprobate';
$txt['repair_operation_missing_boards'] = 'Subiecte într-o arie inexistentă';
$txt['repair_operation_missing_categories'] = 'Arii în categorii inexistente';
$txt['repair_operation_missing_posters'] = 'Mesaje legate de membri inexistenţi';
$txt['repair_operation_missing_parents'] = 'Sub-arii cu arie-părinte inexistențe';
$txt['repair_operation_missing_polls'] = 'Subiecte legate de sondaje inexistente ';
$txt['repair_operation_missing_calendar_topics'] = 'Evenimente legate de subiecte inexistente';
$txt['repair_operation_missing_log_topics'] = 'Jurnalizări pentru subiecte inexistente';
$txt['repair_operation_missing_log_topics_members'] = 'Jurnalizări de subiect legate de utilizatori inexistenţi';
$txt['repair_operation_missing_log_boards'] = 'Jurnalizări de arie legate de arii inexistente';
$txt['repair_operation_missing_log_boards_members'] = 'Jurnalizări de arie legate de utilizatori inexistenţi';
$txt['repair_operation_missing_log_mark_read'] = 'Date marcate ca fiind citite legate de arii inexistente ';
$txt['repair_operation_missing_log_mark_read_members'] = 'Date marcate ca fiind citite legate de membri inexistenţi';
$txt['repair_operation_missing_pms'] = 'Destinatari ai mesajelor personale care nu au şablonul universal de mesaj';
$txt['repair_operation_missing_recipients'] = 'Destinatari ai mesajelor personale legaţi de un membru inexistent';
$txt['repair_operation_missing_senders'] = 'Mesaje personale legate de membri inexistenţi';
$txt['repair_operation_missing_notify_members'] = 'Jurnalizări de notificare legate de un membru inexistent.';
$txt['repair_operation_missing_cached_subject'] = 'Subiecte cărora le lipsesc înregistrările în cache.';
$txt['repair_operation_missing_topic_for_cache'] = 'Înregistrări în cache-ul de căutări, legate de subiecte inexistente';
$txt['repair_operation_missing_member_vote'] = 'Voturi de sondaj legate de membri inexistenţi';
$txt['repair_operation_missing_log_poll_vote'] = 'Voturi de sondaj legate de sondaje inexistente';
$txt['repair_operation_report_missing_comments'] = 'Raportări de subiecte fără comentarii';
$txt['repair_operation_comments_missing_report'] = 'Comentarii de raportare fără subiectul raportat';
$txt['repair_operation_group_request_missing_member'] = 'Cereri de grup cărora le lipseşte membrul solicitant';
$txt['repair_operation_group_request_missing_group'] = 'Cereri de grup pentru grupuri inexistente';

$txt['salvaged_category_name'] = 'Aria pentru recuperări';
$txt['salvaged_category_error'] = 'Categoria pentru arii recuperate nu poate fi creată!';
$txt['salvaged_board_name'] = 'Subiecte recuperate';
$txt['salvaged_board_description'] = 'Subiecte create pentru mesaje cu subiect inexistent';
$txt['salvaged_board_error'] = 'Aria pentru subiecte recuperate nu poate fi creată!';
$txt['salvaged_poll_topic_name'] = 'Sondaj recuperat';
$txt['salvaged_poll_message_body'] = 'Acest sondaj a fost găsit fără un subiect asociat.';

$txt['database_optimize'] = 'Optimizează baza de date';
$txt['database_numb_tables'] = 'Baza de date conţine %1$d tabele.';
$txt['database_optimize_attempt'] = 'Încerc să optimizez baza de date ...';
$txt['database_optimizing'] = 'Optimizing %1$s... %2$01.2f KB optimized.';
$txt['database_already_optimized'] = 'Toate tabelele au fost deja optimizate.';
$txt['database_optimized'] = 'tabele optimizate.';

$txt['apply_filter'] = 'Aplică filtrul';
$txt['applying_filter'] = 'Se aplică filtrul';
$txt['filter_only_member'] = 'Arată numai mesajele de eroare pentru acest membru';
$txt['filter_only_ip'] = 'Arată doar mesajele de eroare pentru acest IP';
$txt['filter_only_session'] = 'Arată doar mesajele de eroare pentru această sesiune';
$txt['filter_only_url'] = 'Arată numai mesajele de eroare pentru acest URL';
$txt['filter_only_message'] = 'Arată doar erorile cu acelaşi mesaj';
$txt['session'] = 'Sesiune';
$txt['error_url'] = 'URL-ul paginii care cauzează eroarea';
$txt['error_message'] = 'Mesajul de eroare';
$txt['clear_filter'] = 'Resetează filtrul';
$txt['remove_selection'] = 'Șterge rezultatele selectate';
$txt['remove_filtered_results'] = 'Șterge toate rezultatele filtrate';
$txt['sure_about_errorlog_remove'] = 'Ești sigur că vrei să golești complet jurnalul de erori?';
$txt['remove_selection_confirm'] = 'Ești sigur că vrei să ștergi înregistrările selectate?';
$txt['remove_filtered_results_confirm'] = 'Ești sigur că vrei să ștergi înregistrările filtrate?';
$txt['reverse_direction'] = 'Ordonează lista invers cronologic';
$txt['error_type'] = 'Tipul de eroare';
$txt['filter_only_type'] = 'Arată doar erorile de acest tip';
$txt['filter_only_file'] = 'Arată doar erorile din acest fişier';
$txt['apply_filter_of_type'] = 'Filtrează erorile de tip';

$txt['errortype_all'] = 'Toate erorile';
$txt['errortype_general'] = 'General ';
$txt['errortype_general_desc'] = 'Erori generale care nu au fost clasificate în vreun tip';
$txt['errortype_critical'] = '<span class="error">Critic</span>';
$txt['errortype_critical_desc'] = 'Erori critice. Acestea trebuie rezolvate cât mai curând posibil. Ignorarea acestor erori poate duce la căderea forumului şi pot cauza breşe de securitate.';
$txt['errortype_database'] = 'Baza de date';
$txt['errortype_database_desc'] = 'Erori datorate interogărilor defectuoase. Acestea trebuiesc analizate și înaintate echipei de dezvoltare ElkArte.';
$txt['errortype_undefined_vars'] = 'Nedefinit';
$txt['errortype_undefined_vars_desc'] = 'Erori cauzate de utilizarea de variabile, indecşi sau offset-uri nedefinite.';
$txt['errortype_template'] = 'Șablon';
$txt['errortype_template_desc'] = 'Erori legate de încărcarea şabloanelor.';
$txt['errortype_user'] = 'Utilizator';
$txt['errortype_user_desc'] = 'Erori provenite de la utilizatori. Acestea includ: parole greșite, încercări de conectare ale utilizatorilor restricționați și tentative de acţiuni nepermise.';

$txt['maintain_recount'] = 'Recalculează toate totalurile şi statisticile forumului';
$txt['maintain_recount_info'] = 'Dacă numărul total de răspunsuri dintr-un subiect sau numărul toatal de mesaje private primite sunt incorecte această activitate le va renumăra si va salva rezultatele statistice obţinute.
';
$txt['maintain_errors'] = 'Găseşte şi repară toate erorile';
$txt['maintain_errors_info'] = 'Dacă, de exemplu, lipsesc mesaje postate sau subiecte după o avarie a serverului, această activitate vă poate ajuta să le găsiţi din nou.
';
$txt['maintain_logs'] = 'Şterge jurnalele neimportante';
$txt['maintain_logs_info'] = 'Această activitate va goli toate jurnalele neimportante. Nu se recomandă decât dacă este absolut necesar, dar nu strică nimic.';
$txt['maintain_cache'] = 'Golește cache-ul';
$txt['maintain_cache_info'] = 'Aceată funcție va goli cache-ul, în caz de nevoie.';
$txt['maintain_optimize'] = 'Optimizează toate tabelele';
$txt['maintain_optimize_info'] = 'Această activitate îți permite să optimizezi toate tabelele. Acest lucru va elimina timpii morți, făcând tabelele mai mici și forumul mai rapid.';
$txt['maintain_version'] = 'Compară versiunile fişierelor cu cele actuale';
$txt['maintain_version_info'] = 'Această activitate de mentenanţă permite verificarea versiunii fiecărui fişier prin compararea cu lista ultimei versiuni oficiale pentru fiecare fişier în parte.';
$txt['maintain_run_now'] = 'Ruleză activitatea acum';
$txt['maintain_return'] = 'Înapoi la pagina de mentenanţă';

$txt['maintain_backup'] = 'Salvează baza de date';
$txt['maintain_backup_info'] = 'Descarcă o copie de siguranță a bazei de date a forumului pentru cazuri de urgenţă.';
$txt['maintain_backup_struct'] = 'Salvează structura tabelelor.';
$txt['maintain_backup_data'] = 'Salvează datele din tabele (lucrurile importante).';
$txt['maintain_backup_gz'] = 'Comprimă cu gzip.';
$txt['maintain_backup_save'] = 'Descarcă';

$txt['maintain_old'] = 'Şterge postările vechi';
$txt['maintain_old_since_days'] = 'Șterge toate subiectele în care nu s-a postat de %1$s zile, și anume:';
$txt['maintain_old_nothing_else'] = 'Orice fel de subiect.';
$txt['maintain_old_are_moved'] = 'Anunţurile privind subiectele mutate.';
$txt['maintain_old_are_locked'] = 'Închise.';
$txt['maintain_old_are_not_stickied'] = 'Dar nu și subiectele fixate.';
$txt['maintain_old_all'] = 'Din toate ariile (apasă pentru a alege arii specifice)';
$txt['maintain_old_choose'] = 'Arii specifice (apasă pentru a le alege pe toate)';
$txt['maintain_old_remove'] = 'Elimină acum';
$txt['maintain_old_confirm'] = 'Ești ABSOLUT sigur că vrei să ştergi mesajele vechi?\\n\\nAceastă acțiune este ireversiblă!';

$txt['maintain_old_drafts'] = 'Elimină ciornele vechi';
$txt['maintain_old_drafts_days'] = 'Elimină toate ciornele mai vechi %1$s zile';
$txt['maintain_old_drafts_confirm'] = 'Ești ABSOLUT sigur că vrei să ştergi ciornele vechi?\\n\\nAceastă acțiune este ireversiblă!';
$txt['maintain_members'] = 'Şterge membrii inactivi';
$txt['maintain_members_since'] = 'Elimină toți membrii care nu au {select_conditions} de {num_days} zile.';
$txt['maintain_members_activated'] = 'activat contul';
$txt['maintain_members_logged_in'] = 'accesat forumul';
$txt['maintain_members_all'] = 'Din toate grupurile';
$txt['maintain_members_choose'] = 'Din grupurile selectate';
$txt['maintain_members_confirm'] = 'Ești ABSOLUT sigur că vrei să ştergi membrii inactivi?\\n\\nAceastă acțiune este ireversiblă!';

$txt['text_title'] = 'Convertește la TEXT';
$txt['mediumtext_title'] = 'Convertește la MEDIUMTEXT';
$txt['mediumtext_introduction'] = 'Tabelele de mesaje pot stoca implicit texte de până la 65535 de caractere. Pentru a putea stoca texte mai lungi, tipul coloanelor trebuie convertit la "MEDIUMTEXT". Conversia inversă, la "TEXT", poate fi făcută (pentru reducerea spațiului ocupat de baza de date) dar <strong>NUMAI DACĂ</strong> nici unul din mesajele din baza de date nu depășește 65535 caractere. Îndeplinirea acestei condiții va fi verificată înainte de reconversie.';
$txt['body_checking_introduction'] = 'Această funcție va converti coloanele bazei de date ce conțin text, din formatul curent ("MEDIUMTEXT") ]n formatul "TEXT". Acest lucru va duce la o ușoar reducere a spațiului ocupat de mesaje (1 byte pentru fiecare mesaj). Dacă există mesaje mai lungi de 65535 caractere, ACESTEA VOR FI TRUNCHIATE ȘI O PARTE DIN TEXT SE VA PIERDE.';
$txt['exceeding_messages'] = 'Următoarele mesaje sunt mai lungi de 65535 caractere și vor fi trunchiate în acest proces:';
$txt['exceeding_messages_morethan'] = 'Și încă %1$d';
$txt['convert_to_text'] = 'Nu există mesaje mai lungi de 65535 caractere. Poți continua în siguranță cu conversia, fără riscul de a pierde părți din mesaje.';
$txt['convert_to_suggest_text'] = 'Coloana pentru conținutul mesajelor din baza de date este de tipul "MEDIUMTEXT" dar lungimea maximă permisă a mesajelor este setată la mai puțin de 65535 caractere. Poți elibera puțin spațiu prin conversia coloanelor la tipul "TEXT".';
$txt['convert_proceed'] = 'Continuă';

// Move topics out.
$txt['move_topics_maintenance'] = 'Mută subiecte';
$txt['move_topics_from'] = 'Mută subiectele din';
$txt['move_topics_to'] = 'în';
$txt['move_topics_now'] = 'Mută acum';
$txt['move_topics_confirm'] = 'Ești sigur că vrei să muţi TOATE subiectele din &quot;%board_from%&quot; în &quot;%board_to%&quot;? ';

$txt['maintain_reattribute_posts'] = 'Transferă postările utilizatorilor';
$txt['reattribute_guest_posts'] = 'Transferă către "Vizitator" postările făcute cu:';
$txt['reattribute_email'] = 'Adresa de email';
$txt['reattribute_username'] = 'Numele de utilizator';
$txt['reattribute_current_member'] = 'Transferă postările celui menționat la membrul';
$txt['reattribute_increase_posts'] = 'Adună postările transferate la totalul destinatarului';
$txt['reattribute'] = 'Transferă';
// Don't use entities in the below string.
$txt['reattribute_confirm'] = 'Esti sigur că vrei să transferi toate postările vizitatorilor cu %type% "%find%" membrului "%member_to%"?';
$txt['reattribute_confirm_username'] = 'un nume de utilizator';
$txt['reattribute_confirm_email'] = 'o adresa de email';
$txt['reattribute_cannot_find_member'] = 'Nu s-a găsit membrul pentru a reatribui postările.';

$txt['maintain_recountposts'] = 'Renumără postările utilizatorilor';
$txt['maintain_recountposts_info'] = 'Rulează această activitate de mentenanță pentru a actualiza numărul total de postări pentru utilizatori. Va renumăra toate postările (ce pot fi numărate) făcute de fiecare utilizator, după care va actualiza totalul din profilul fiecărui utilizator.';

$txt['safe_mode_enabled'] = 'Pe server este activ <a href="http://php.net/manual/en/features.safe-mode.php">safe_mode</a>!<br />Copia de siguranță obținută prin metoda de față nu poate fi considerată fiabilă!';
$txt['use_external_tool'] = 'Ia în calcul utilizarea unei metode externe pentru obținerea copiei de siguranță a bazei de date, copiile obținute prin metoda de față nu pot fi considerate 100% fiabile.';
$txt['zipped_file'] = 'Poți cere o copie comprimată (arhivată) cu gzip.';
$txt['plain_text'] = 'Cea mai bună metodă de a obține o copie de siguranță este să creezi un fișier plain-text; un pachet comprimat s-ar putea să nu fie complet fiabil.';
$txt['enable_maintenance1'] = 'Datorită mărimii forumului, este recomandat să-l treci în modul "Mentanță" înainte de a începe crearea copiei de siguranță.';
$txt['enable_maintenance2'] = 'Pentru a putea continua, datprită mărimii forumului trebuie să-l treci în modul "Mentanță".';
$txt['security_database_download'] = 'Din motive de securitate, pentru a putea trece la descărcarea copiei de siguranță, trebuie să introduci detaliile contului de FTP:';