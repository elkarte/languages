<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Arată ciornele';
$txt['drafts_show_desc'] = 'Această arie conține toate ciornele pe care le ai momentan salvate. Aici le poți edita înainte de a le publica. Deasemenea la poți șterge.';

// misc
$txt['drafts'] = 'Ciorne';
$txt['draft_save'] = 'Salvează ca ciornă';
$txt['draft_save_note'] = 'Va fi salvat textul ciornei tale dar NU vor fi salvate atalamentele sau informațiile legate de sondaje sau de evenimente.';
$txt['draft_none'] = 'Nu ai nici o ciornă.';
$txt['draft_edit'] = 'Editează ciorna';
$txt['draft_load'] = 'Încarcă ciorna';
$txt['draft_hide'] = 'Ascunde ciornele';
$txt['draft_delete'] = 'Șterge ciorna';
$txt['draft_days_ago'] = 'Acum %s zile';
$txt['draft_retain'] = 'va fi reținută încă %s zile';
$txt['draft_remove'] = 'Elimină această ciornă';
$txt['draft_remove_selected'] = 'Elimini toate ciornele selectate?';
$txt['draft_saved'] = 'Conținutul a fost salvat ca ciornă și va fi disponibil în zona <a href="%1$s">Arată ciorne</a> din profilul tău.';
$txt['draft_pm_saved'] = 'Conținutul a fost salvat ca ciornă și va fi disponibil în zona <a href="%1$s">Arată ciorne</a> din mesagerie.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Activează salvarea automată în ciorne';
$txt['drafts_autosave_enabled_subnote'] = 'Va salva automat ciorne în background cu o frecvență prestabilită. Utilizatorul trebuie să aibe drepturile corespunzătoare';
$txt['drafts_keep_days'] = 'Numărul maxim de zile pentru păstrarea ciornelor';
$txt['drafts_keep_days_subnote'] = 'Introdu 0 pentru păstrarea ciornelor pe termen nelimitat';
$txt['drafts_autosave_frequency'] = 'Cât de des să fie salvate automat ciornele?';
$txt['drafts_autosave_frequency_subnote'] = 'Valoarea minimă permisă este de 30 de secunde';
$txt['drafts_pm_enabled'] = 'Permite salvarea ciornelor pentru MP';
$txt['drafts_post_enabled'] = 'Permite salvarea ciornelor pentru postări';
$txt['drafts_none'] = 'Fără subiect';
$txt['drafts_saved'] = 'Ciorna a fost salvată cu succes';