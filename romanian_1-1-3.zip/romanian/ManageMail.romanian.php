<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'În această pagină poţi configura setările pentru poşta electronică și poţi vedea şi configura lista pentru email-uri, dacă aceasta este activată.';
$txt['mail_settings'] = 'Setările pentru email';

$txt['mail_type'] = 'Tipul de poştă electronică';
$txt['mail_type_default'] = '(PHP implicit)';
$txt['smtp_host'] = 'Server SMTP';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'Port SMTP';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'SMTP nume de utilizator';
$txt['smtp_password'] = 'SMTP parolă';

$txt['mail_queue'] = 'Activează lista de email';
$txt['mail_period_limit'] = 'Numărul maxim de mesaje trimise pe minut';
$txt['mail_period_limit_desc'] = '(Setează la 0 pentru a dezactiva)';
$txt['mail_batch_size'] = 'Numărul maxim de mesaje trimise per pagină';

$txt['mailqueue_stats'] = 'Statistica listei de email';
$txt['mailqueue_oldest'] = 'Cel mai vechi mesaj';
$txt['mailqueue_oldest_not_available'] = 'N/A';
$txt['mailqueue_size'] = 'Lungimea listei';

$txt['mailqueue_age'] = 'Vechime';
$txt['mailqueue_priority'] = 'Prioritate';
$txt['mailqueue_recipient'] = 'Destinatar';
$txt['mailqueue_subject'] = 'Subiect';
$txt['mailqueue_clear_list'] = 'Trimite mesajele din listă acum';
$txt['mailqueue_no_items'] = 'Lista de mesaje este goală';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Sunteţi sigur că doriţi să trimiteţi întreaga listă de mesaje? Aceasta nu va ţine cont de limitele pe care le-aţi setat.';

$txt['mq_day'] = '%1.1f Zi';
$txt['mq_days'] = '%1.1f Zile';
$txt['mq_hour'] = '%1.1f Oră';
$txt['mq_hours'] = '%1.1f Ore';
$txt['mq_minute'] = '%1$d Minut';
$txt['mq_minutes'] = '%1$d Minute';
$txt['mq_second'] = '%1$d Secundă';
$txt['mq_seconds'] = '%1$d Secunde';

$txt['mq_mpriority_5'] = 'Foarte Scăzut';
$txt['mq_mpriority_4'] = 'Scăzut';
$txt['mq_mpriority_3'] = 'Normal';
$txt['mq_mpriority_2'] = 'Ridicat';
$txt['mq_mpriority_1'] = 'Foarte Ridicat';

$txt['birthday_email'] = 'Mesajul pentru aniversări';
$txt['birthday_body'] = 'Corpul email-ului';
$txt['birthday_subject'] = 'Subiectul email-ului';