<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... n-am nici o idee, îmi pare rău</em>';
$txt['who_admin'] = 'Citește portalul de administrare';
$txt['who_moderate'] = 'Citește  portalul de moderare';
$txt['who_generic'] = 'Citește %1$s';
$txt['who_unknown'] = '<em>Acţiune necunoscută</em> ';
$txt['who_user'] = 'Utilizator';
$txt['who_time'] = 'Data/Ora';
$txt['who_action'] = 'Acţiune';
$txt['who_show1'] = 'Afişează';
$txt['who_show_members_only'] = 'Doar membrii autentificați';
$txt['who_show_guests_only'] = 'Doar vizitatorii';
$txt['who_show_spiders_only'] = 'Doar motoarele de căutare';
$txt['who_show_all'] = 'Toţi utilizatorii';
$txt['who_no_online_spiders'] = 'Momentan nu este niciun spider online.';
$txt['who_no_online_guests'] = 'Nu este niciun vizitator online în prezent.';
$txt['who_no_online_members'] = 'Nu este niciun membru online în prezent.';

$txt['whospider_login'] = 'Citește pagina de autentificare.';
$txt['whospider_register'] = 'Citește pagina de înregistrare.';
$txt['whospider_reminder'] = 'Citește pagina de memento.';

$txt['whoall_activate'] = 'Activează contul.';
$txt['whoall_buddy'] = 'Îşi modifică lista de prieteni.';
$txt['whoall_coppa'] = 'Completează formularul conţinând acordul părintelui/tutorelui.';
$txt['whoall_credits'] = 'Vizualizează pagina de credite.';
$txt['whoall_emailuser'] = 'Trimite mesaj de e-mail altui membru.';
$txt['whoall_groups'] = 'Citește pagina grupurilor de membri.';
$txt['whoall_help'] = 'Citește <a href="{help_url}">pagina de ajutor</a>';
$txt['whoall_quickhelp'] = 'Vizualizează o fereastră popup de ajutor.';
$txt['whoall_pm'] = 'Îşi citește mesajele.';
$txt['whoall_auth'] = 'Intră pe forum.';
$txt['whoall_login'] = 'Citește pagina de autentificare.';
$txt['whoall_login2'] = 'Citește pagina de autentificare.';
$txt['whoall_logout'] = 'Iese de pe forum.';
$txt['whoall_markasread'] = 'Marchează subiectele de discuţie ca fiind citite sau necitite.';
$txt['whoall_mentions'] = 'Citește lista de menționări.';
$txt['whoall_modifykarma_applaud'] = 'Aplaudă un membru.';
$txt['whoall_modifykarma_smite'] = 'Plesneşte un membru.';
$txt['whoall_news'] = 'Citește ştirile.';
$txt['whoall_notify'] = 'Îşi schimbă setările de notificare.';
$txt['whoall_notifyboard'] = 'Îşi schimbă setările de notificare.';
$txt['whoall_openidreturn'] = 'Se autentifică folosind OpenID.';
$txt['whoall_quickmod'] = 'Moderează o secţiune.';
$txt['whoall_recent'] = 'Citește <a href="{recent_url}">lista subiectelor recente</a>.';
$txt['whoall_register'] = 'Se înregistrează pentru un cont pe forum.';
$txt['whoall_reminder'] = 'Solicită reamintirea unei parole.';
$txt['whoall_reporttm'] = 'Raportează un subiect unui moderator';
$txt['whoall_spellcheck'] = 'Foloseşte corectorul ortografic';
$txt['whoall_unread'] = 'Citește subiectele necitite de la ultima vizită.';
$txt['whoall_unreadreplies'] = 'Citește răspunsurile necitite de la ultima vizită.';
$txt['whoall_who'] = 'Urmărește <a href="{who_url}">Cine e online</a>.';

$txt['whoall_collapse_collapse'] = 'Restrânge o categorie.';
$txt['whoall_collapse_expand'] = 'Extinde o categorie.';
$txt['whoall_pm_removeall'] = 'Îşi şterge toate mesajele.';
$txt['whoall_pm_send'] = 'Trimite un mesaj.';
$txt['whoall_pm_send2'] = 'Trimite un mesaj.';

$txt['whotopic_announce'] = 'Anunță subiectul &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Aprobă un ataşament.';
$txt['whotopic_dlattach'] = 'Vizualizează un fişier ataşat.';
$txt['whotopic_deletemsg'] = 'Şterge un mesaj.';
$txt['whotopic_editpoll'] = 'Editează sondajul din &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Editează sondajul din &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Modifică postarea din &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Leagă un mesaj din subiectul &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Blochează subiectul &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Blochează sondajul din &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Unește subiectul &quot;<a href="%1$s">%2$s</a>&quot; cu alt subiect.';
$txt['whotopic_movetopic'] = 'Mută subiectul &quot;<a href="%1$s">%2$s</a>&quot; într-o altă arie.';
$txt['whotopic_movetopic2'] = 'Mută subiectul &quot;<a href="%1$s">%2$s</a>&quot; într-o altă arie.';
$txt['whotopic_post'] = 'Postează în <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Postează în <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Tipărește subiectul &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderează subiectul <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Șterge sondajul din &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Șterge subiectul <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Trimite subiectul &quot;<a href="%1$s">%2$s</a>&quot; unui prieten.';
$txt['whotopic_splittopics'] = 'Desparte subiectul &quot;<a href="%1$s">%2$s</a>&quot; în două subiecte.';
$txt['whotopic_sticky'] = 'A fixat subiectul &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'A încetat să mai urmărească un subiect.';
$txt['whotopic_vote'] = 'Votează în <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'A început să urmărească un subiect.';

$txt['whopost_quotefast'] = 'Citează o postare din &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Editează acordul de înregistrare.';
$txt['whoadmin_featuresettings'] = 'Editează facilităţile şi opţiunile forumului.';
$txt['whoadmin_modlog'] = 'Citește jurnalul de moderare.';
$txt['whoadmin_serversettings'] = 'Editează setările forumului.';
$txt['whoadmin_packageget'] = 'Obţine pachete.';
$txt['whoadmin_packages'] = 'Citește pagina de administrare a pachetelor.';
$txt['whoadmin_permissions'] = 'Editează permisiunile în forum';
$txt['whoadmin_pgdownload'] = 'Descarcă un pachet.';
$txt['whoadmin_theme'] = 'Editează setările temei.';
$txt['whoadmin_trackip'] = 'Urmăreşte o adresă IP.';

$txt['whoallow_manageboards'] = 'Editează setările pentru secţiune şi categorie.';
$txt['whoallow_admin'] = 'Citește pagina <a href="{admin_url}">centrului de administrare</a>.';
$txt['whoallow_ban'] = 'Editează lista de interdicţii.';
$txt['whoallow_boardrecount'] = 'Recalculează totalurile din forum';
$txt['whoallow_calendar'] = 'Citește <a href="{calendar_url}">calendarul</a>.';
$txt['whoallow_editnews'] = 'Editează ştirile.';
$txt['whoallow_mailing'] = 'Trimite un mesaj de e-mail pe forum.';
$txt['whoallow_maintain'] = 'Efectuează întreţinerea de rutină a forumului.';
$txt['whoallow_manageattachments'] = 'Gestionează ataşamentele.';
$txt['whoallow_moderate'] = 'Citește pagina <a href="{moderate_url}">centrului de moderare</a>.';
$txt['whoallow_memberlist'] = 'Citește <a href="{memberlist_url}">lista membrilor</a>.';
$txt['whoallow_optimizetables'] = 'Optimizează tabelele bazei de date.';
$txt['whoallow_repairboards'] = 'Repară tabelele bazei de date.';
$txt['whoallow_search'] = '<a href="{search_url}">Caută</a> în forum.';
$txt['whoallow_search_results'] = 'Citește rezultatele unei căutări.';
$txt['whoallow_setcensor'] = 'Editează textul de cenzurat.';
$txt['whoallow_setreserve'] = 'Editează numele rezervate.';
$txt['whoallow_stats'] = 'Citește <a href="{stats_url}">statisticile forumului</a>.';
$txt['whoallow_viewErrorLog'] = 'Citește jurnalul erorilor.';
$txt['whoallow_viewmembers'] = 'Vizualizează o listă de membri.';

$txt['who_topic'] = 'Citește subiectul <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Citește aria <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Citește indexul ariei <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Citește profilul utilizatorului <a href="%1$s">%2$s</a>.';
$txt['who_profile'] = 'Editează profilul utilizatorului <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Postează un subiect nou în <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Postează un sondaj nou în <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Începe un subiect nou prin email în <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Postează prin email în <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Trimite un mesaj personal prin email.';

// Credits text
$txt['credits'] = 'Autori și Credite';
$txt['credits_intro'] = 'ElkArte is 100% free and open-source. We encourage and support an active, open community that accepts contributions from the public.  We want to thank everyone who supported the project by providing code, feedback, bug reports, and opinions, as none of this would have been possible without you.  We also want to specially acknowledge <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, the project that ElkArte was born from.';
$txt['credits_contributors'] = 'Contribuitori';
$txt['credits_and'] = 'şi';
$txt['credits_copyright'] = 'Drepturi de autor';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Add-on-uri';
$txt['credits_software_graphics'] = 'Software/Grafica';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Grafica';
$txt['credits_fonts'] = 'Fonturi';
$txt['credits_groups_contrib'] = 'Contribuitori';
$txt['credits_contrib_list'] = 'For a complete list of the many individuals that contributed to the design and implementation of Elkarte, please refer to the official GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">list of contributors.</a>';
$txt['credits_license'] = 'Licență';
$txt['credits_copyright'] = 'Drepturi de autor';
$txt['credits_version'] = 'Versiune';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Traducători';
$txt['credits_translators_message'] = 'Thank you for your efforts which make it possible for people all around the world to use ElkArte.  For a complete list please refer to the offical Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">list of contributors.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';