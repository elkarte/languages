<?php
// Version: 1.1; ManagePaid

// Symbols.
$txt['usd_symbol'] = '$%1.2f';
$txt['eur_symbol'] = '&euro;%1.2f';
$txt['gbp_symbol'] = '&pound;%1.2f ';

$txt['usd'] = 'USD ($) ';
$txt['eur'] = 'EURO (&euro;) ';
$txt['gbp'] = 'GBP (&pound;) ';
$txt['other'] = 'Altele';

$txt['paid_username'] = 'Numele de utilizator';

$txt['paid_subscriptions_desc'] = 'În această secţiune poţi adăuga, şterge şi edita metodele de înregistrare pe forumul tău.';
$txt['paid_subs_settings'] = 'Setări';
$txt['paid_subs_settings_desc'] = 'Aici poţi edita metodele de plată disponibile utilizatorilor.';
$txt['paid_subs_view'] = 'Vezi Abonamentele';
$txt['paid_subs_view_desc'] = 'Aici poţi vedea toate abonamentele disponibile.';

// Setting type strings.
$txt['paid_enabled'] = 'Activează abonamentele cu plată';
$txt['paid_enabled_desc'] = 'Validează opțiunea pentru a putea utiliza abonamente plătite pentru forum.';
$txt['paid_email'] = 'Trimite notificări pe e-mail';
$txt['paid_email_desc'] = 'Informează administratorul când se modifică automat un abonament.';
$txt['paid_email_to'] = 'Emailul pentru corespondenţă';
$txt['paid_email_to_desc'] = 'Lista cu adresele de e-mail, separate prin virgulă, unde vor fi trimise notificări în plus față de cele ale administratorilor.';
$txt['paidsubs_test'] = 'Activează modul de test';
$txt['paidsubs_test_desc'] = 'Aceasta pune abonamentele în mod &quot;test&quot;, care va folosi, atunci când este posibil, metodele sandbox payment în Paypal, Authorize.net etc. Nu activa decat dacă știi ce faci!';
$txt['paidsubs_test_confirm'] = 'Ești sigur(ă) că vrei să activezi modul de test ?';
$txt['paid_email_no'] = 'Nu trimite notificări';
$txt['paid_email_error'] = 'Informează-mă atunci când plata la un abonament nu reuşeşte';
$txt['paid_email_all'] = 'Informeaza-mă atunci când se modifică abonamentele automat';
$txt['paid_currency'] = 'Selectează moneda';
$txt['paid_currency_code'] = 'Codul monedei';
$txt['paid_currency_code_desc'] = 'Codul folosit de către organizaţia plătitoare';
$txt['paid_currency_symbol'] = 'Simbolul folosit la plată';
$txt['paid_currency_symbol_desc'] = 'Foloseşte \'%1.2f\' pentru a specifica unde sunt plasate numerele, de exemplu $%1.2f, %1.2fRON etc';

$txt['paypal_email'] = 'Adresa de e-mail Paypal';
$txt['paypal_email_desc'] = 'Nu completa dacă nu doreşti să foloseşti paypal.';

$txt['authorize_id'] = 'ID de instalare Authorize.net';
$txt['authorize_id_desc'] = 'ID-ul de instalare generat de Authorize.net. Nu completa dacă nu foloseşti Authorize.net';
$txt['authorize_transid'] = 'ID-ul tranzacţiei Authorize.Net ';

$txt['2co_id'] = 'ID de instalare 2checkout.com';
$txt['2co_id_desc'] = 'ID-ul de instalare generat de 2co.com. Nu completa dacă nu foloseşti 2co.com';
$txt['2co_password'] = 'Cuvântul secret 2chckout.com';
$txt['2co_password_desc'] = 'Cuvântul secret pentru 2checkout.';
$txt['2co_password_wrong'] = 'Cuvântul secret pentru 2checkout introdus nu a fost acceptat.';

$txt['paid_settings_save'] = 'Salvează';

$txt['paid_note'] = '<strong class="alert">Notă:</strong><br />Pentru ca abonamentele utilizatorilor tăi să fie actualizate automat,
⇥va trebui să setezi un URL de retur pentru fiecare metodă de plată. Pentru toate tipurile de plată, acest URL trebuie setat ca<br /><br />
⇥&nbsp;&nbsp;&bull;&nbsp;&nbsp;<strong>{board_url}/subscriptions.php</strong><br /><br />
⇥Poți edita link-ul pentru Paypal direct <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ipn-notify" target="_blank">făcând click aici</a>.<br />
⇥Pentru celelalte portaluri (dacă sunt instalate), în mod normal poți găsi această setare în panoul pentru clienți, sub &quot;Return URL&quot; sau &quot;Callback URL&quot;.';

// View subscription strings.
$txt['paid_name'] = 'Nume';
$txt['paid_status'] = 'Statut';
$txt['paid_cost'] = 'Cost';
$txt['paid_duration'] = 'Durata';
$txt['paid_active'] = 'Activ';
$txt['paid_pending'] = 'Plată in aşteptare';
$txt['paid_finished'] = 'Terminat';
$txt['paid_total'] = 'Total';
$txt['paid_is_active'] = 'Activat';
$txt['paid_none_yet'] = 'Nu ai setat niciun abonament.';
$txt['paid_none_ordered'] = 'Nu ai nici un abonament';
$txt['paid_payments_pending'] = 'În aşteptarea plăților';
$txt['paid_order'] = 'Ordinea';

$txt['yes'] = 'Da';
$txt['no'] = 'Nu';

// Add/Edit/Delete subscription.
$txt['paid_add_subscription'] = 'Adaugă un abonament nou';
$txt['paid_edit_subscription'] = 'Editează abonamentul';
$txt['paid_delete_subscription'] = 'Şterge abonamentul';

$txt['paid_mod_name'] = 'Denumirea Abonamentului';
$txt['paid_mod_desc'] = 'Descriere';
$txt['paid_mod_reminder'] = 'Trimite un mesaj de reamintire via e-mail';
$txt['paid_mod_reminder_desc'] = 'Cu câte zile înainte de expirare trimiţi email de reamintire? (In zile, 0 pentru dezactivare)';
$txt['paid_mod_email'] = 'Email-ul care se trimite la finalizare';
$txt['paid_mod_email_desc'] = 'Unde {NAME} este numele de utilizator; {FORUM} reprezintă numele forumului. Subiectul trebuie să fie pe prima linie. Nu completa dacă nu vrei să trimiţi notificări.';
$txt['paid_mod_cost_usd'] = 'Cost (USD) ';
$txt['paid_mod_cost_eur'] = 'Cost (EUR) ';
$txt['paid_mod_cost_gbp'] = 'Cost (GBP) ';
$txt['paid_mod_cost_blank'] = 'Lasă necompletat dacă nu accepţi plata în aceste monede.';
$txt['paid_mod_span'] = 'Durata abonamentului';
$txt['paid_mod_span_days'] = 'Zile';
$txt['paid_mod_span_weeks'] = 'Săptămâni';
$txt['paid_mod_span_months'] = 'Luni';
$txt['paid_mod_span_years'] = 'Ani';
$txt['paid_mod_active'] = 'Activ';
$txt['paid_mod_active_desc'] = 'Un abonament trebuie să fie activ pentru ca utilizatorii să se poată abona.';
$txt['paid_mod_prim_group'] = 'Grupul primar de utilizatori după abonare';
$txt['paid_mod_prim_group_desc'] = 'Grupul primar de utilizatori la care sunt repartizați  automat utilizatorii abonaţi.';
$txt['paid_mod_add_groups'] = 'Grupul secundar de utilizatori după abonare';
$txt['paid_mod_add_groups_desc'] = 'Grupul secundar de utilizatori la care sunt repartizați automat utilizatorii abonaţi.';
$txt['paid_mod_no_group'] = 'Nu schimba';
$txt['paid_mod_edit_note'] = 'Atenţie: acest grup are deja abonaţi ale căror setări nu pot fi modificate!';
$txt['paid_mod_delete_warning'] = '<strong>ATENŢIE</strong><br /><br />Dacă ştergeţi acest abonament toţi utilizatorii abonaţi în prezent îşi vor pierde drepturile de acces acordate la abonare. Cu excepţia cazului în care sunteţi sigur că doriţi să faceţi acest lucru, este recomandat să dezactivaţi pur şi simplu un abonament în loc să îl ştergeţi.<br />';
$txt['paid_mod_repeatable'] = 'Permite utilizatorului să-și reînnoiască automat acest abonament';
$txt['paid_mod_allow_partial'] = 'Permite abonarea partiala';
$txt['paid_mod_allow_partial_desc'] = 'Dacă această opţiune este activată, în cazul în care utilizatorii plătesc mai puţin decât trebuie, li se va asigna un abonament pe o durată proporţională cu plata efectuată.';
$txt['paid_mod_fixed_price'] = 'Abonament cu preţ fix şi perioadă fixa';
$txt['paid_mod_flexible_price'] = 'Prețul abonamentului variază în funcție de durata comandată.';
$txt['paid_mod_price_breakdown'] = 'Amănunte pentru prețul flexibil';
$txt['paid_mod_price_breakdown_desc'] = 'Defineşte cât costă abonamentul în funcţie de perioada plătită. De exemplu poate costa 12USD pe luna, însă doar 100USD pentru un an. Lasă gol dacă nu doreşti să setezi aceste perioade.';
$txt['flexible'] = 'Flexibil';

$txt['paid_per_day'] = 'Preţul pentru o zi';
$txt['paid_per_week'] = 'Preţul pentru o săptămână';
$txt['paid_per_month'] = 'Preţul pentru o lună';
$txt['paid_per_year'] = 'Preţul pentru un an';
$txt['day'] = 'Ziua';
$txt['week'] = 'Săptămâna';
$txt['month'] = 'Luna';
$txt['year'] = 'Anul';

// View subscribed users.
$txt['viewing_users_subscribed'] = 'Afişează utilizatorii';
$txt['view_users_subscribed'] = 'Afişează utilizatorii abonaţi la: &quot;%1$s&quot; ';
$txt['no_subscribers'] = 'Momentan nu sunt abonați la acest abonament.';
$txt['add_subscriber'] = 'Adaugă abonat nou';
$txt['edit_subscriber'] = 'Editează abonatul';
$txt['delete_selected'] = 'Şterge șabloanele selectate';
$txt['complete_selected'] = 'Finalizează cele selectate';

// @todo These strings are used in conjunction with JavaScript.  Use numeric entities.
$txt['delete_are_sure'] = 'Eşti sigur că vrei să ştergi toate înregistrările aferente acestui abonament?';
$txt['complete_are_sure'] = 'Eşti sigur că vrei să finalizezi abonamentele selectate?';

$txt['start_date'] = 'Data de început';
$txt['end_date'] = 'Data de sfârşit';
$txt['start_date_and_time'] = 'Ziua şi ora de început';
$txt['end_date_and_time'] = 'Ziua şi ora de sfârşit';
$txt['one_username'] = 'Introdu doar un singur nume de utilizator.';
$txt['minute'] = 'Minutul';
$txt['error_member_not_found'] = 'Utilizatorul nu a fost găsit';
$txt['member_already_subscribed'] = 'Acest utilizator este deja abonat aici. Editează abonamentul lui existent dacă doreşti.';
$txt['search_sub'] = 'Caută utilizatorul';

// Make payment.
$txt['paid_confirm_payment'] = 'Confirmă plata';
$txt['paid_confirm_desc'] = 'Pentru a continua plata te rugăm să verifici detaliile de mai jos şi apoi dă click pe &quot;Comandă&quot;';
$txt['paypal'] = 'PayPal';
$txt['paid_confirm_paypal'] = 'Pentru a plăti folosind <a href="http://www.paypal.com">PayPal</a> dă click pe butonul de mai jos. Vei fi transferat pe site-ul PayPal pentru plată.';
$txt['paid_paypal_order'] = 'Comandă prin PayPal';
$txt['authorize'] = 'Authorize.Net';
$txt['paid_confirm_authorize'] = 'Pentru a plăti folosind <a href="http://www.authorize.net">Authorize.Net</a> dă click pe butonul de mai jos. Vei fi transferat pe site-ul Authorize.Net pentru plată.';
$txt['paid_authorize_order'] = 'Comandă prin Authorize.Net';
$txt['2co'] = '2checkout ';
$txt['paid_confirm_2co'] = 'Pentru a plăti folosind <a href="http://www.2co.com">2co.com</a> faceţi click pe butonul de mai jos. Veţi fi direcţionat către site-ul 2co.com pentru plată.';
$txt['paid_2co_order'] = 'Comandă prin 2co.com';
$txt['paid_done'] = 'Plată efectuată';
$txt['paid_done_desc'] = 'Îţi multumim pentru plată. Abonamentul tău va fi activat după verificarea tranzacției.';
$txt['paid_sub_return'] = 'Întoarce-te la abonamente';
$txt['paid_current_desc'] = 'Mai jos este o listă a tuturor abonamentelor actuale și anterioare. Pentru a prelungi un abonament existent selectează-l din lista de mai sus.';
$txt['paid_admin_add'] = 'Adaugă acest abonament';

$txt['paid_not_set_currency'] = 'Nu ai setat moneda de plată. Fă acest lucru în ariea  <a href="%1$s">Setări</a> pentru a putea continua.';
$txt['paid_no_cost_value'] = 'Trebuie să introduceţi un cost şi durata abonamentului.';
$txt['paid_all_freq_blank'] = 'Trebuie să introduceţi un cost pentru cel puţin una din cele patru durate.';

// Some error strings.
$txt['paid_no_data'] = 'Nu a fost trimisă script-ului nici o dată validă.';

$txt['paypal_could_not_connect'] = 'Nu s-a putut efectua conectarea la serverul PayPal';
$txt['paypal_currency_unkown'] = 'Codul monedei transmis de PayPal (%1$s) nu corespunde cu codul setat de tine (%2$s)';
$txt['paid_sub_not_active'] = 'Acel abonament nu mai acceptă utilizatori noi.';
$txt['paid_disabled'] = 'Abonamentele plătite sunt momentan dezactivate.';
$txt['paid_unknown_transaction_type'] = 'Tip de tranzacție necunoscut.';
$txt['paid_empty_member'] = 'Managerul de abonamente nu a putut recupera ID-ul utilizatorului';
$txt['paid_could_not_find_member'] = 'Managerul de abonamente nu a putut găsi utilizatorul cu ID-ul: %1$d ';
$txt['paid_count_not_find_subscription'] = 'Managerul de abonamente nu a putut găsi abonamentele pentru utilizatorul cu ID-ul: %1$s, ID abonament: %2$s';
$txt['paid_count_not_find_subscription_log'] = 'Managerul de abonamente nu a putut găsi în logul de abonare inregistrările despre utilizatorul cu ID: %1$s, abonament ID: %2$s';
$txt['paid_count_not_find_outstanding_payment'] = 'Nu am găsit plăţi în aşteptare pentru utilizatorul cu ID-ul: %1$s,  ID abonament: %2$s deci este ignorat';
$txt['paid_admin_not_setup_gateway'] = 'Ne pare rău dar administratorii nu au terminat încă de setat abonamentele cu plată. Te rugăm să revii mai târziu.';
$txt['paid_make_recurring'] = 'Transformă în plată recurentă';

$txt['subscriptions'] = 'Abonamente';
$txt['subscription'] = 'Abonament';
$txt['subscribers'] = 'Abonați';
$txt['paid_subs_desc'] = 'Mai jos e o listă cu toate abonamentele disponibile pe acest site.';
$txt['paid_subs_none'] = 'Momentan nu sunt disponibile abonamente cu plată.';

$txt['paid_current'] = 'Abonamente existente';
$txt['pending_payments'] = 'În așteptarea plăților';
$txt['pending_payments_desc'] = 'Acest utilizator a încercat să facă o plată pentru abonamentul său, însă confirmarea plătii nu a fost primită de către forum. Dacă eşti sigur că plata a fost efectuată, dă click pe &quot;acceptat&quot; pentru a activa abonamentul său. Sau poţi da click pe &quot;Sterge&quot; pentru a şterge toate înregistrările despre această plată.';
$txt['pending_payments_value'] = 'Valoarea';
$txt['pending_payments_accept'] = 'Acceptă';
$txt['pending_payments_remove'] = 'Elimină';