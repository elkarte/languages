<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Nu ai dreptul să modifici profilul acestui utilizator.';
$txt['website_title'] = 'Numele Website-ului';
$txt['website_url'] = 'Adresa URL a Website-ului';
$txt['signature'] = 'Semnătura';
$txt['profile_posts'] = 'Postări';

$txt['profile_info'] = 'Detalii suplimentare';
$txt['profile_contact'] = 'Informații de contact';
$txt['profile_moderation'] = 'Informații despre moderare';
$txt['profile_more'] = 'Semnătura';
$txt['profile_attachments'] = 'Atașamente recente';
$txt['profile_attachments_no'] = 'Acest membru nu are atașamente';
$txt['profile_recent_posts'] = 'Mesaje recente';
$txt['profile_posts_no'] = 'Acest membru nu a postat mesaje';
$txt['profile_topics'] = 'Subiecte recente';
$txt['profile_topics_no'] = 'Acest membru nu a deschis subiecte';
$txt['profile_buddies_no'] = 'Nu a adăugat nici un amic';
$txt['profile_user_info'] = 'Informații despre utilizator';
$txt['profile_contact_no'] = 'Nu există informații de contact pentru acest membru';
$txt['profile_signature_no'] = 'Acest membru nu are semnătură';
$txt['profile_additonal_no'] = 'Nu sunt informații suplimentare despre acest membru';
$txt['profile_user_summary'] = 'Profilul';
$txt['profile_action'] = 'Acum';
$txt['profile_recent_activity'] = 'Activitatea recentă';
$txt['profile_activity'] = 'Activitate';
$txt['profile_loadavg'] = 'Încearcă mai târziu. Informațiile solicitate nu sunt disponibile momentan datorită încărcării ridicate a serverului.';

$txt['change_profile'] = 'Modificarea profilului';
$txt['preview_signature'] = 'Previzualizează semnătura';
$txt['current_signature'] = 'Semnătura actuală';
$txt['signature_preview'] = 'Previzualizarea semnăturii';
$txt['personal_picture'] = 'Imagine personalizată';
$txt['no_avatar'] = 'Niciun avatar';
$txt['choose_avatar_gallery'] = 'Alege un avatar din galerie';
$txt['preferred_language'] = 'Limba preferată';
$txt['age'] = 'Vechime';
$txt['no_pic'] = '(fără imagine)';
$txt['avatar_by_url'] = 'Specifică URL-ul avatarului tău. (de ex. <em>http://www.paginamea.com/pozamea.png</em>)';
$txt['my_own_pic'] = 'Specifică avatarul prin URL.';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'Formatul definit aici va fi folosit la afişarea datei şi orei în forum.';
$txt['time_format'] = 'Formatul datei şi al orei';
$txt['display_name_desc'] = 'Acesta este numele afişat în forum, pe care îl vor vedea utilizatorii.';
$txt['personal_time_offset'] = 'Numărul de ore +/- pentru a afişa timpul identic cu ora dumneavoastră locală.';
$txt['dob'] = 'Ziua de naştere';
$txt['dob_month'] = 'Luna (LL)';
$txt['dob_day'] = 'Ziua (ZZ)';
$txt['dob_year'] = 'Anul (AAAA)';
$txt['password_strength'] = 'Pentru securitate maximă trebuie să folosiţi minim opt caractere, combinând litere, cifre şi simboluri.';
$txt['include_website_url'] = 'Acest câmp trebuie completat dacă specificaţi un URL mai jos.';
$txt['complete_url'] = 'Aceasta trebuie să fie o adresă URL completă.';
$txt['sig_info'] = 'Semnăturile sunt afişate în partea de jos a fiecărui mesaj postat sau mesaj privat. În semnătură pot fi utilizate coduri BBC şi emoticoane.';
$txt['max_sig_characters'] = 'Maximum de caractere: %1$d; caractere rămase: ';
$txt['send_member_pm'] = 'Trimite un mesaj personal acestui utilizator';
$txt['hidden'] = 'ascuns';
$txt['current_time'] = 'Ora curentă a forumului';

$txt['language'] = 'Limba';
$txt['avatar_too_big'] = 'Avatarul este prea mare, vă rugăm să-l micşoraţi şi să încercaţi din nou (max';
$txt['invalid_registration'] = 'Dată invalidă, exemplu corect:';
$txt['current_password'] = 'Parolă actuală';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Din motive de securitate, trebuie să introduceţi parola actuală pentru a putea modifica contul.';

$txt['timeoffset_autodetect'] = 'auto detect';

$txt['secret_question'] = 'Întrebarea secretă';
$txt['secret_desc'] = 'Pentru cazul în care uiți parola, introdu aici o întrebare al cărei răspuns îl știi <strong>doar</strong> tu.';
$txt['secret_desc2'] = 'Alege cu grijă răspunsul la întrebare, nu vrei să poată fi ghicit de cineva!';
$txt['secret_answer'] = 'Răspuns';
$txt['incorrect_answer'] = 'Nu ai definit o întrebare secretă şi un răspuns în profilul tău.  Mergi înapoi şi alege metoda implicită pentru obţinerea parolei.';
$txt['enter_new_password'] = 'Te rog dă răspunsul la întrebarea secretă şi completează noua parolă dorită.  Dacă răspunzi corect la întrebarea secretă, parola va fi schimbată cu cea nouă aleasă de tine.';
$txt['secret_why_blank'] = 'de ce nu este completat?';

$txt['authentication_reminder'] = 'Reamintire Autentificare';
$txt['password_reminder_desc'] = 'Dacă ai uitat datele pentru autentificare acestea se pot obţine uşor. Pentru început completează mai jos numele de utilizator sau adresa de email.';
$txt['authentication_options'] = 'Selectează una dintre cele două opţiuni de mai jos';
$txt['authentication_openid_email'] = 'Trimite-mi un email care să-mi reamintească de OpenId-ul meu.';
$txt['authentication_openid_secret'] = 'Răspunsul la &quot;întrebarea secretă&quot; pentru a mi se prezenta identitatea OpenID';
$txt['authentication_password_email'] = 'Trimite-mi pe email o nouă parolă';
$txt['authentication_password_secret'] = 'Permite-mi să îmi schimb parola răspunzând la &quot;întrebarea secretă&quot; ';
$txt['openid_secret_reminder'] = 'Introdu răspunsul corect la întrebarea de mai jos. Dacă răspunsul este corect, identitatea ta OpenID va fi afişată.';
$txt['reminder_openid_is'] = 'Identitatea OpenID asociată cu contul tău este :<br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /><br />Notează acest ID pentru a avea o referinţă pe viitor. ';
$txt['reminder_continue'] = 'Continuă';

$txt['accept_agreement_title'] = 'Accept agreement';
$txt['agreement_accepted_title'] = 'Continuă';

$txt['current_theme'] = 'Tema actuală';
$txt['change'] = 'Schimbă tema';
$txt['theme_forum_default'] = 'Tema implicită a forumului sau ariii';
$txt['theme_forum_default_desc'] = 'Aceasta este tema implicită, ceea ce înseamnă că tema ta se va schimba în conform cu setările alese de administrator și cu aria pe care o citești.';

$txt['profileConfirm'] = 'Ești sigur că vrei să stergi acest utilizator?';

$txt['custom_title'] = 'Titlul personalizat';

$txt['lastLoggedIn'] = 'Ultima dată activ';

$txt['notify_settings'] = 'Setare notificări:';
$txt['notify_save'] = 'Salvează setările';
$txt['notify_important_email'] = 'Vreau să primesc buletine de ştiri, anunţuri din forum şi notificări importante pe e-mail.';
$txt['notify_regularity'] = 'Notifică-mă pentru subiectele şi ariile pentru care am cerut notificări';
$txt['notify_regularity_none'] = 'Niciodată';
$txt['notify_regularity_instant'] = 'Instantaneu';
$txt['notify_regularity_first_only'] = 'Instantaneu - dar numai pentru primul răspuns';
$txt['notify_regularity_daily'] = 'Zilnic';
$txt['notify_regularity_weekly'] = 'Săptămânal';
$txt['auto_notify'] = 'Activează notificarea pentru subiectul în care postez când răspund la un subiect.';
$txt['auto_notify_pbe_post'] = '<strong>NU</strong> este recomandat, dacă ai activată notificarea pentru "arie".';
$txt['notify_send_types'] = 'Notifică-mă despre subiectele și ariile pentru care am cerut notificări';
$txt['notify_send_type_everything'] = 'Răspunsuri şi acțiuni de moderare';
$txt['notify_send_type_everything_own'] = 'Acțiuni de  moderare doar dacă eu am deschis subiectul';
$txt['notify_send_type_only_replies'] = 'Doar răspunsuri';
$txt['notify_send_type_only_replies_pbe'] = 'Toate mesajele';
$txt['notify_send_type_nothing'] = 'Nimic';
$txt['notify_send_body'] = 'La notificarea unui răspuns într-un subiect, trimite conținutul mesajului în email (dar te rog nu răspunde la aceste email-uri!)';
$txt['notify_send_body_pbe'] = 'La notificarea unui răspuns într-un subiect, trimite conținutul mesajului în email';
$txt['notify_send_body_pbe_post'] = '<strong>NU</strong> a disponibil la notificare prin rezumat zilnic / săptămânal';

$txt['notify_method'] = 'Notification and:';
$txt['notify_notification'] = 'no email (only mention/alert)';
$txt['notify_email'] = 'Immediate email';
$txt['notify_email_daily'] = 'Daily email';
$txt['notify_email_weekly'] = 'Weekly email';

$txt['notify_type_likemsg'] = 'Notify when one of your messages is liked';
$txt['notify_type_mentionmem'] = 'Notify when you are @mentioned';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Notify when someone adds you as buddy';
$txt['notify_type_quotedmem'] = 'Notify when someone quotes one of your messages';
$txt['notify_type_mailfail'] = 'Notify when email notifications are disabled (mention only)';

$txt['notifications_topics'] = 'Notificările active pentru subiecte';
$txt['notifications_topics_none'] = 'Nu ai cerut notificări pentru nici un subiect.';
$txt['notifications_topics_howto'] = 'Pentru a primi notificări privind un anumit subiect, apasă butonul &quot;Notifică-mă&quot; când îl citești.';

$txt['notifications_boards'] = 'Notificările active pentru arii';
$txt['notifications_boards_none'] = 'Nu aţi cerut notificări pentru nici o arie.';
$txt['notifications_boards_howto'] = 'Pentru a primi notificări privind o anume arie, fie apasă butonul &quot;Notifică-mă&quot; din indexul ariei <strong>fie</strong> folosește bifele de mai jos pentru a activa notificările pentru ariile selectate.';
$txt['notifications_boards_current'] = '
Primești notificări de la ariile afișate <strong>ÎNGROȘAT</strong>. Folosește bifele pentru a opri notificările sau pentru a adăuga și alte arii pe lista ta de notificări';
$txt['notifications_boards_update'] = 'Actualizează';
$txt['notifications_update'] = 'Nu mă notifica';

$txt['statPanel_showStats'] = 'Statistica utilizatorului privind: ';
$txt['statPanel_users_votes'] = 'Numărul de voturi exprimate';
$txt['statPanel_users_polls'] = 'Numărul de sondaje create';
$txt['statPanel_total_time_online'] = 'Timpul petrecut online';
$txt['statPanel_noPosts'] = 'Nu exista mesaje!';
$txt['statPanel_generalStats'] = 'Statistică generală';
$txt['statPanel_posts'] = 'mesaje postate';
$txt['statPanel_topics'] = 'subiecte de discuţie';
$txt['statPanel_total_posts'] = 'Total mesaje postate';
$txt['statPanel_total_topics'] = 'Total subiecte iniţiate';
$txt['statPanel_votes'] = 'voturi';
$txt['statPanel_polls'] = 'sondaje';
$txt['statPanel_topBoards'] = 'Cea mai populară arie după numărul de mesaje';
$txt['statPanel_topBoards_posts'] = '%1$d mesaje postate din cele %2$d mesaje postate ale ariei (%3$01.2f%%) ';
$txt['statPanel_topBoards_memberposts'] = '%1$d mesaje postate din cele %2$d mesaje postate ale membrului (%3$01.2f%%)';
$txt['statPanel_topBoardsActivity'] = 'Cea mai populară arie după activitate';
$txt['statPanel_activityTime'] = 'Graficul de timp pentru mesaje';
$txt['statPanel_activityTime_posts'] = '%1$d mesaje postate (%2$d%%) ';

$txt['deleteAccount_warning'] = 'Atenţie - aceste acţiuni sunt ireversibile!';
$txt['deleteAccount_desc'] = 'Din această pagină poți şterge contul şi mesajele unui utilizator';
$txt['deleteAccount_member'] = 'Şterge contul acestui utilizator';
$txt['deleteAccount_posts'] = 'Şterge mesajele acestui utilizator';
$txt['deleteAccount_none'] = 'Nimic';
$txt['deleteAccount_all_posts'] = 'Doar răspunsurile';
$txt['deleteAccount_topics'] = 'Subiectele și răspunsurile';
$txt['deleteAccount_confirm'] = 'Ești ABSOLUT sigur că vrei să ştergi acest cont?';
$txt['deleteAccount_approval'] = 'Moderatorii vor trebui să aprobe ştergerea acestui cont.';

$txt['profile_of_username'] = 'Profilul lui %1$s';
$txt['profileInfo'] = 'Informaţii despre profil';
$txt['showPosts'] = 'Afişează mesajele';
$txt['showPosts_help'] = 'Aici poţi vedea mesajele utilizatorului. Sunt afişate doar mesajele făcute în arii în care ai acces.';
$txt['showMessages'] = 'Mesaje';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = 'Subiecte';
$txt['showUnwatched'] = 'Subiecte de la care s-a dezabonat';
$txt['showAttachments'] = 'Ataşamente';
$txt['viewWarning_help'] = 'Această arie îți prezintă toate avertismentele acordate acestui membru.';
$txt['statPanel'] = 'Arată statistica';
$txt['editBuddyIgnoreLists'] = 'Lista de amici / utilizatori ignoraţi';
$txt['editBuddies'] = 'Editează lista de amici';
$txt['editIgnoreList'] = 'Editează lista de utilizatorilor ignoraţi';
$txt['trackUser'] = 'Urmărește utilizatorul';
$txt['trackActivity'] = 'Activitate';
$txt['trackIP'] = 'Adresă IP';
$txt['trackLogins'] = 'Autentificări';

$txt['likes_show'] = 'Arată Like-urile';
$txt['likes_given'] = 'Postări care ți-au plăcut';
$txt['likes_profile_received'] = 'primite';
$txt['likes_profile_given'] = 'oferite';
$txt['likes_received'] = 'Postările tale care au plăcut altora';
$txt['likes_none_given'] = 'Nu ți-a plăcut nici o postare';
$txt['likes_none_received'] = 'Nimănui nu i-a plăcut vreo postare de-a ta :\'(';
$txt['likes_confirm_delete'] = 'Elimin acest Like?';
$txt['likes_show_who'] = 'Arată membrii cărora le-a plăcut acest mesaj';
$txt['likes_by'] = 'Plăcut de';
$txt['likes_delete'] = 'Şterge';

$txt['authentication'] = 'Autentificare';
$txt['change_authentication'] = 'În această arie poţi modifica modul în care te autentifici în forum. Poţi alege între o identitate OpenID sau un nume de utilizator cu parolă.';

$txt['profileEdit'] = 'Editează profilul';
$txt['account_info'] = 'Aici sunt setările contului tău. Această pagină conţine informaţii despre identitatea ta pe acest forum. Din motive de securitate trebuie să introduci parola actuală pentru a putea modifica aceste informaţii.';
$txt['forumProfile_info'] = 'Aici îți poți edita informațiile personale. Aceste informații vor fi afișate public pe {forum_name_html_safe}. Dacă nu dorești să faci publice anumite informații, lasă câmpul respectiv necompletat - nici o informație din această pagină nu este obligatorie.';
$txt['theme_info'] = 'Această arie îți permite să modifici felul în care vei să vezi afişat forumul.';
$txt['notification_info'] = 'Asta îți permite să fii notificat despre răspunsuri la postări, subiecte nou deschise și anunțuri generale ale forumului. Aici poți să editezi setările relevante sau să vezi subiectele și ariile de la care primești notificări în acest moment.';
$txt['groupmembership'] = 'Apartenența la grupuri';
$txt['groupMembership_info'] = 'În această arie a profilului poţi alege caror grupuri vrei să aparții.';
$txt['ignoreboards'] = 'Opţiuni pentru ignorarea ariilor';
$txt['ignoreboards_info'] = 'Aici ai la dispoziție opțiuni pentru ignorarea anumitor arii. Când o arie este ignorată, indicatorul de postări noi din indexul forumului nu se va activa în dreptul ariei respective. Postările noi dintr-o arie ignorată nu vor fi afișate când vei folosi link-ul de căutare pentru "mesajele necitite" (căutarea nu se va efectua în ariile respective). Totuși ariile ignorate vor fi afișate în indexul forumului iar DACĂ sunt accesate, vor afișa care subiecte conțin mesaje necitite. Când folosești link-ul "răspunsuri necitite", mesajele noi dintr-o arie ignorată VOR FI afișate.';
$txt['contactprefs'] = 'Mesagerie';

$txt['profileAction'] = 'Acțiuni';
$txt['deleteAccount'] = 'Şterge acest cont';
$txt['profileSendIm'] = 'Trimite un mesaj personal';
$txt['profile_sendpm_short'] = 'Trimite MP';

$txt['profileBanUser'] = 'Restricționează accesul utilizatorului';

$txt['display_name'] = 'Numele afișat';
$txt['enter_ip'] = 'Introduceţi IP-ul (sau clasa)';
$txt['errors_by'] = 'Mesaje de eroare pentru';
$txt['errors_desc'] = 'Mai jos este afişată lista erorilor pe care le-a generat sau întâmpinat utilizatorul.';
$txt['errors_from_ip'] = 'Mesaje de eroare de la IP (sau clasă)';
$txt['errors_from_ip_desc'] = 'Mai jos este afişată lista  mesajelor de eroare generate de acest IP (sau clasă).';
$txt['ip_address'] = 'Adresa IP';
$txt['ips_in_errors'] = 'IP-uri care apar în mesajele de eroare';
$txt['ips_in_messages'] = 'IP-uri care au fost folosite în mesaje recente';
$txt['members_from_ip'] = 'Utilizatori cu acelaşi IP (sau clasă)';
$txt['members_in_range'] = 'Utilizatori din aceeaşi clasă';
$txt['messages_from_ip'] = 'Mesaje scrise de la adresa IP (clasa)';
$txt['messages_from_ip_desc'] = 'Mai jos este afişată lista de mesaje scrise de la acest IP (clasă).';
$txt['trackLogins_desc'] = 'Mai jos este afișată lista tuturor autentificărilor cu acest cont.';
$txt['most_recent_ip'] = 'Ultima adresă IP folosită';
$txt['why_two_ip_address'] = 'De ce sunt listate două adrese IP?';
$txt['no_errors_from_ip'] = 'Nu sunt mesaje de eroare pentru IP-ul (clasa) specificat(a)';
$txt['no_errors_from_user'] = 'Nu sunt mesaje de eroare pentru utilizatorul specificat';
$txt['no_members_from_ip'] = 'Nu s-au gasit alţi utilizatori cu acest IP (clasă)';
$txt['no_messages_from_ip'] = 'Nu s-au găsit mesaje de la acest IP (clasă)';
$txt['trackLogins_none_found'] = 'Nu s-au găsit autentificări recente';
$txt['none'] = 'Nimic';
$txt['own_profile_confirm'] = 'Ești ABSOLUT sigur că vrei să îți ştergi contul?';
$txt['view_ips_by'] = 'IP-urile folosite de';

$txt['avatar_will_upload'] = 'Încarcă un avatar';

$txt['activate_changed_email_title'] = 'Adresa de email a fost schimbată';
$txt['activate_changed_email_desc'] = 'Ai schimbat adresa de e-mail. Vei primi un e-mail la noua adresă pentru a o valida. Accesează link-ul din e-mail pentru a reactiva contul.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Nu poate fi trimis email-ul de reamintire.';
$txt['send_email'] = 'Trimite un email la';
$txt['to_ask_password'] = 'pentru a obţine detaliile necesare autentificării';

$txt['user_email'] = 'Nume de utilizator / E-mail';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'A fost trimis un mesaj la adresa ta de e-mail. Accesează link-ul conţinut în mesaj pentru a seta o nouă parolă.';
$txt['reminder_openid_sent'] = 'OpenID-ul tău actual a fost trimis la adresa ta de e-mail.';
$txt['reminder_set_password'] = 'Setează parola';
$txt['reminder_password_set'] = 'Parola a fost setată';
$txt['reminder_error'] = '%1$s a greşit răspunsul la întrebarea secretă când a încercat să schimbe o parolă uitată.';

$txt['registration_not_approved'] = 'Acest cont nu a fost încă aprobat. Dacă trebuie să schimbi adresa de e-mail, fă click';
$txt['registration_not_activated'] = 'Acest cont nu a fost încă activat. Dacă vrei să primești din nou e-mail-ul de activare, fă click';

$txt['primary_membergroup'] = 'Grupul primar de utilizatori';
$txt['additional_membergroups'] = 'Grupurile suplimentare';
$txt['additional_membergroups_show'] = 'Arată grupurile suplimentare';
$txt['no_primary_membergroup'] = '(niciun grup primar)';
$txt['deadmin_confirm'] = 'Ești ABSOLUT sigur că vrei să renunţi irevocabil la statutul de administrator?';

$txt['account_activate_method_2'] = 'Contul necesită reactivare după schimbarea adresei de e-mail';
$txt['account_activate_method_3'] = 'Contul nu a fost activat';
$txt['account_activate_method_4'] = 'Contul aşteaptă aprobarea pentru ştergere';
$txt['account_activate_method_5'] = 'Contul aşteaptă aprobarea unui părinte sau tutore legal pentru o persoana sub vârsta minimă admisă';
$txt['account_not_activated'] = 'Contul nu este activat';
$txt['account_activate'] = 'activare';
$txt['account_approve'] = 'aprobare';
$txt['user_is_banned'] = 'Utilizatorul este restricționat';
$txt['view_ban'] = 'Vezi';
$txt['user_banned_by_following'] = 'Acestui utilizator i s-au impus următoarele restricţii de acces';
$txt['user_cannot_due_to'] = 'Utilizatorul nu poate să %1$s din cauza interdicţiei: &quot;%2$s&quot;';
$txt['ban_type_post'] = 'posteze mesaje';
$txt['ban_type_register'] = 'se înregistreze';
$txt['ban_type_login'] = 'se autentifice';
$txt['ban_type_access'] = 'acceseze forumul';

$txt['show_online'] = 'Permit altora să vadă că sunt online';

$txt['return_to_post'] = 'Afișează subiectul în care tocmai am postat un mesaj.';
$txt['no_new_reply_warning'] = 'Nu mă avertiza despre mesajele postate în timp ce scriam un răspuns la subiect.';
$txt['recent_pms_at_top'] = 'Afişează mesajele personale cele mai recente deasupra.';
$txt['wysiwyg_default'] = 'Activează implicit afișarea editorului WYSIWYG în pagina de scriere a mesajelor.';

$txt['timeformat_default'] = '(formatul implicit al forumului)';
$txt['timeformat_easy1'] = 'Luna Ziua, Anul, HH:MM:SS am/pm ';
$txt['timeformat_easy2'] = 'Luna Ziua, Anul, HH:MM:SS (24 de ore)';
$txt['timeformat_easy3'] = 'AAAA-LL-ZZ, HH:MM:SS ';
$txt['timeformat_easy4'] = 'ZZ Luna AAAA, HH:MM:SS';
$txt['timeformat_easy5'] = 'ZZ-LL-AAAA, HH:MM:SS';

$txt['poster'] = 'Autor';

$txt['use_sidebar_menu'] = 'Folosește meniul lateral în locul meniului derulant vertical.';
$txt['use_click_menu'] = 'Deschide meniurile cu click și nu la trecerea mouse-ului pe deasupra.';
$txt['show_no_avatars'] = 'Nu afişa avatarurile utilizatorilor.';
$txt['show_no_signatures'] = 'Nu afişa semnăturile utilizatorilor.';
$txt['show_no_censored'] = 'Lasă cuvintele necenzurate.';
$txt['topics_per_page'] = 'Numărul de subiecte afişate pe o pagină:';
$txt['messages_per_page'] = 'Numărul de mesaje afişate pe o pagină:';
$txt['hide_poster_area'] = 'Ascunde zona de informații despre autorii postărilor.';
$txt['per_page_default'] = 'valoarea implicită a forumului';
$txt['calendar_start_day'] = 'Prima zi din săptămână în calendar:';
$txt['display_quick_reply'] = 'Afişează în subiect caseta de răspuns rapid: ';
$txt['use_editor_quick_reply'] = 'Folosește editorul complet pentru caseta de răspuns rapid.';
$txt['display_quick_mod'] = 'Afișează comenzile de moderare rapidă ca:';
$txt['display_quick_mod_none'] = 'nu afişa.';
$txt['display_quick_mod_check'] = 'bife.';
$txt['display_quick_mod_image'] = 'iconiţe.';

$txt['whois_title'] = 'Caută IP-ul pe un server regional WHOIS';
$txt['whois_afrinic'] = 'AfriNIC (Africa)';
$txt['whois_apnic'] = 'APNIC (Asia regiunea pacifică)';
$txt['whois_arin'] = 'ARIN (America de Nord, porţiune din Caraibe şi Africa sub-sahariana)';
$txt['whois_lacnic'] = 'LACNIC (America latină şi regiunea Caraibe)';
$txt['whois_ripe'] = 'RIPE (Europa, Orientul Mijlociu, părţi din Africa şi Asia)';

$txt['moderator_why_missing'] = 'de ce nu este moderatorul aici?';
$txt['username_change'] = 'schimbă';
$txt['username_warning'] = 'Pentru a schimba numele de utilizator, forumul trebuie să reseteze parola, care ți se va trimite prin e-mail alături de noul nume de utilizator.';

$txt['show_member_posts'] = 'Afişează mesajele utilizatorului';
$txt['show_member_topics'] = 'Afişează subiectele utilizatorului';
$txt['show_member_attachments'] = 'Afişează ataşamentele utilizatorului';
$txt['show_posts_none'] = 'Nu au fost încă postate mesaje.';
$txt['show_topics_none'] = 'Nu a fost postat niciun subiect de discuţie încă.';
$txt['unwatched_topics_none'] = 'Nu ai nici un mesaj în lista de subiecte pe care nu le mai urmărești.';
$txt['show_attachments_none'] = 'Nu au fost încă postat niciun ataşament.';
$txt['show_attach_filename'] = 'Numele fişierului';
$txt['show_attach_downloads'] = 'Descărcări';
$txt['show_attach_posted'] = 'Postat';

$txt['showPermissions'] = 'Afişează drepturile';
$txt['showPermissions_status'] = 'Starea drepturilor';
$txt['showPermissions_help'] = 'Aici poți vedea toate drepturile acestui membru (drepturile interzise explicit sunt <del>tăiate</del>).';
$txt['showPermissions_given'] = 'Dat de';
$txt['showPermissions_denied'] = 'Interzis de';
$txt['showPermissions_permission'] = 'Drept (drepturile interzise explicit sunt <del>tăiate</del>)';
$txt['showPermissions_none_general'] = 'Acest utilizator nu are setate drepturi generale.';
$txt['showPermissions_none_board'] = 'Acest utilizator nu are setate drepturi de arie.';
$txt['showPermissions_all'] = 'Ca şi Administrator acest membru are toate drepturile!';
$txt['showPermissions_select'] = 'Drepturi de arie pentru aria';
$txt['showPermissions_general'] = 'Drepturi pentru grupuri';
$txt['showPermissions_global'] = 'Pentru toate ariile';
$txt['showPermissions_restricted_boards'] = 'arii inaccesibile';
$txt['showPermissions_restricted_boards_desc'] = 'Următoarele arii sunt inaccesibile utilizatorului';

$txt['local_time'] = 'Data locală';
$txt['posts_per_day'] = 'pe zi';

$txt['buddy_ignore_desc'] = 'Aici poți administra lista cu amici şi pe cea cu utilizatori ignoraţi. Adăugarea de membri la aceste liste te ajută, printre altele, la ținerea sub control a traficului generat prin mail şi prin mesageria personală, în funcţie de preferinţele tale.';

$txt['buddy_add'] = 'Adaugă la lista cu amici';
$txt['buddy_remove'] = 'Elimină din lista cu amici';
$txt['buddy_add_button'] = 'AdaugăAdaugă';
$txt['no_buddies'] = 'Lista cu amici este goală';

$txt['ignore_add'] = 'Adaugă la lista cu utilizatori ignorați';
$txt['ignore_remove'] = 'Elimină din lista cu utilizatori ignorați';
$txt['ignore_add_button'] = 'AdaugăAdaugă';
$txt['no_ignore'] = 'Lista cu utilizatori ignoraţi este goală.';

$txt['regular_members'] = 'Utilizatori înregistraţi';
$txt['regular_members_desc'] = 'Toţi utilizatorii acestui forum aparţin acestui grup.';
$txt['group_membership_msg_free'] = 'Apartenenţa la grup a fost modificată.';
$txt['group_membership_msg_request'] = 'Cererea a fost trasmisă, te rog așteaptă să fie analizată .';
$txt['group_membership_msg_primary'] = 'Grupul primar de utilizatori a fost schimbat';
$txt['current_membergroups'] = 'Grupuri de utilizatori actuale ';
$txt['available_groups'] = 'Grupuri de utilizatori disponibile ';
$txt['join_group'] = 'Intră în grup';
$txt['leave_group'] = 'Părăseşte grupul';
$txt['request_group'] = 'Aderă la un grup';
$txt['approval_pending'] = 'În aşteaptarea aprobării';
$txt['make_primary'] = 'Transformă acest grup în grupul primar';

$txt['request_group_membership'] = 'Solicită aderarea la un grup de utilizatori';
$txt['request_group_membership_desc'] = 'Înainte de a intra în acest grup de utilizatori, cererea trebuie să fie aprobată de un administrator. Descrie motivul pentru care dorești să faci parte din acest grup.';
$txt['submit_request'] = 'Trimite cererea';

$txt['profile_updated_own'] = 'Profilul a fost actualizat cu succes.';
$txt['profile_updated_else'] = 'Profilul lui <strong>%1$s</strong> a fost actualizat cu succes.';

$txt['profile_error_signature_max_length'] = 'Semnătura nu poate depăşi %1$d caractere';
$txt['profile_error_signature_max_lines'] = 'Semnătura nu poate depăși %1$d linii';
$txt['profile_error_signature_max_image_size'] = 'Imaginile din semnătură nu pot avea mai mult de %1$dx%2$d pixeli';
$txt['profile_error_signature_max_image_width'] = 'Imaginile din semnătură nu pot avea lăţimea mai mare de %1$d pixeli';
$txt['profile_error_signature_max_image_height'] = 'Imaginile din semnătură nu pot avea înălţimea mai mare de %1$d pixeli';
$txt['profile_error_signature_max_image_count'] = 'Nu poți folosi mai mult de %1$d imagini în semnătură';
$txt['profile_error_signature_max_font_size'] = 'Fontul semnăturii trebuie să fie mai mic de %1$s';
$txt['profile_error_signature_allow_smileys'] = 'Nu este permisă folosirea emoticoanelor în semnătură.';
$txt['profile_error_signature_max_smileys'] = 'Nu sunt permise mai mult de %1$d emoticoane în semnătură';
$txt['profile_error_signature_disabled_bbc'] = 'Următorul cod BBC nu este permis în semnătură: %1$s';

$txt['profile_view_warnings'] = 'Afişează avertismentele';
$txt['profile_issue_warning'] = 'Emite un avertisment';
$txt['profile_warning_level'] = 'Nivelul avertismentului';
$txt['profile_warning_desc'] = 'Aici poţi emite avertismente sau poți modifica nivelul lor. Poţi deasemenea urmări istoricul avertismentelor, precum şi efectele produse de nivelul actual al avertismentelor, conform setărilor administratorului.';
$txt['profile_warning_name'] = 'Numele membrului';
$txt['profile_warning_impact'] = 'Rezultat';
$txt['profile_warning_reason'] = 'Motivul avertismentului';
$txt['profile_warning_reason_desc'] = 'Este obligatoriu şi este înregistrat.';
$txt['profile_warning_effect_none'] = 'Niciunul.';
$txt['profile_warning_effect_watch'] = 'Utilizatorul va fi adăugat pe lista de observaţie a moderatorilor.';
$txt['profile_warning_effect_own_watched'] = 'Ești pe lista de supraveghere a moderatorilor.';
$txt['profile_warning_is_watch'] = 'este supravegheat';
$txt['profile_warning_effect_moderate'] = 'Toate mesajele vor fi moderate.';
$txt['profile_warning_effect_own_moderated'] = 'Toate mesajele tale vor fi supuse moderării.';
$txt['profile_warning_is_moderation'] = 'mesajele sunt moderate';
$txt['profile_warning_effect_mute'] = 'Utilizatorul nu poate scrie mesaje.';
$txt['profile_warning_effect_own_muted'] = 'Nu vei putea să postezi.';
$txt['profile_warning_is_muted'] = 'nu mai poate scrie mesaje';
$txt['profile_warning_effect_text'] = 'Nivel >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Trimite notificarea';
$txt['profile_warning_notify_template'] = 'Selectează şablonul:';
$txt['profile_warning_notify_subject'] = 'Subiectul notificării';
$txt['profile_warning_notify_body'] = 'Mesajul notificării';
$txt['profile_warning_notify_template_subject'] = 'Ai primit o avertisment.';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},

Ai primit un avertisment pentru %1$s. Te rugăm să încetezi acest gen de manifestări și să te conformezi regulilor forumului, în caz contrar fiind forțați să luăm măsuri suplimentare.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},

Ai primit un avertisment pentru %1$s referitor la mesajul:
{MESSAGE}.

Te rugăm să încetezi acest gen de manifestări și să te conformezi regulilor forumului, în caz contrar fiind forțați să luăm măsuri suplimentare.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'spam';
$txt['profile_warning_notify_title_spamming'] = 'Spam';
$txt['profile_warning_notify_for_offence'] = 'scriere de mesaje ofensatoare';
$txt['profile_warning_notify_title_offence'] = 'Scriere de mesaje ofensatoare';
$txt['profile_warning_notify_for_insulting'] = 'insultarea utilizatorilor forumului și/sau a membrilor echipei';
$txt['profile_warning_notify_title_insulting'] = 'Insultarea Utilizatorilor/Echipei';
$txt['profile_warning_issue'] = 'Emite avertismentul';
$txt['profile_warning_max'] = '(Max 100)';
$txt['profile_warning_limit_attribute'] = 'Nu poţi ajusta nivelul avertismentului de mai mult de %1$d%% ori în 24 de ore.';
$txt['profile_warning_errors_occurred'] = 'Avertismentul nu a fost emis din următoarele motive';
$txt['profile_warning_success'] = 'Avertsment emis';
$txt['profile_warning_new_template'] = 'Şablon nou';

$txt['profile_warning_previous'] = 'Avertismente anterioare';
$txt['profile_warning_previous_none'] = 'Acest utilizator nu a mai primit avertismente.';
$txt['profile_warning_previous_issued'] = 'Emis de';
$txt['profile_warning_previous_time'] = 'Data/Ora';
$txt['profile_warning_previous_level'] = 'Puncte';
$txt['profile_warning_previous_reason'] = 'Motiv';
$txt['profile_warning_previous_notice'] = 'Vezi notificarea trimisă către utilizator';

$txt['viewwarning'] = 'Afişează avertismentele';
$txt['profile_viewwarning_for_user'] = 'Avertismente pentru %1$s';
$txt['profile_viewwarning_no_warnings'] = 'Nu au mai fost emise avertismente.';
$txt['profile_viewwarning_desc'] = 'Mai jos este afişat un sumar al tuturor avertismentelor emise de echipa de moderatori.';
$txt['profile_viewwarning_previous_warnings'] = 'Avertismente anterioare';
$txt['profile_viewwarning_impact'] = 'Efectul avertismentului';

$txt['subscriptions'] = 'Abonamente plătite';

$txt['pm_settings_desc'] = 'Aici poţi modifica diverse opţiuni privind mesajele personale - inclusiv cum vor fi afişate mesajele şi cine are voie să ți le trimită.';
$txt['email_notify'] = 'Notifică-mă pe email de câte ori primesc un mesaj personal:';
$txt['email_notify_never'] = 'Niciodată';
$txt['email_notify_buddies'] = 'Doar dacă e de la un Amic';
$txt['email_notify_always'] = 'Întotdeauna';

$txt['receive_from'] = 'Membri care au voie să mp contacteze:';
$txt['receive_from_everyone'] = 'Toți membrii';
$txt['receive_from_ignore'] = 'Toţi membrii, cu excepţia celor de pe lista mea de utilizatori ignoraţi';
$txt['receive_from_admins'] = 'Doar administratorii';
$txt['receive_from_buddies'] = 'Doar Amicii și Administratorii';
$txt['receive_from_description'] = 'Această setare se aplică atât Mesajelor Personale cât și email-urilor (dacă opțiunea de trimitere a email-urilor către membri este activă)';

$txt['popup_messages'] = 'Afișează un mesaj de atenţionare când primesc mesaje noi.';
$txt['pm_remove_inbox_label'] = 'Elimină eticheta din inbox când aplic o altă etichetă.';
$txt['pm_display_mode'] = 'Afişează mesajele personale';
$txt['pm_display_mode_all'] = 'Toate';
$txt['pm_display_mode_one'] = 'Câte unul';
$txt['pm_display_mode_linked'] = 'Sub formă de conversaţie';

$txt['history'] = 'Istoric';
$txt['history_description'] = 'Aici poți analiza modificările profilului acestui membru și poți urmări IP-ul și istoricul autentificărilor.';

$txt['trackEdits'] = 'Editările profilului';
$txt['trackEdit_deleted_member'] = 'Utilizator şters';
$txt['trackEdit_no_edits'] = 'Nu s-au înregistrat modificări pentru acest profil.';
$txt['trackEdit_action'] = 'Câmp';
$txt['trackEdit_before'] = 'Valoarea înainte';
$txt['trackEdit_after'] = 'Valuarea după';
$txt['trackEdit_applicator'] = 'Schimbată de';

$txt['trackEdit_action_real_name'] = 'Numele membrului';
$txt['trackEdit_action_usertitle'] = 'Titlul personalizat';
$txt['trackEdit_action_member_name'] = 'Numele de utilizator';
$txt['trackEdit_action_email_address'] = 'Adresa de email';
$txt['trackEdit_action_id_group'] = 'Grupul primar de utilizatori';
$txt['trackEdit_action_additional_groups'] = 'Grupurile suplimentare';

$txt['otp_enabled_help'] = 'Enabling this will add a second factor (one-time password) for authentication.';
$txt['otp_token_help'] = 'This generates a secret token for time-based one-time password  apps such as Authy or Google Authenticator. Once the secret was generated use your favorite authenticator app and scan the qrcode.<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
