<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Notificările mele';
$txt['my_unread_mentions'] = 'Notificările mele ncitite';
$txt['my_mentions_pages'] = 'pagina %1$d';
$txt['no_mentions_yet'] = 'Nu ai fost menționat';
$txt['no_new_mentions'] = 'Nu sunt menționări noi';

$txt['mentions_from'] = 'Membru';
$txt['mentions_when'] = 'Când';
$txt['mentions_what'] = 'Mesaj';
$txt['mentions_all'] = 'Arată tot';
$txt['mentions_unread'] = 'Necitite';
$txt['mentions_action'] = 'Acțiuni';
$txt['mentions_delete_warning'] = 'Ești sigur că vrei să ștergi acestă înregistrare?';
$txt['mentions_markread'] = 'Marchează ca citit(e)';
$txt['mentions_markunread'] = 'Marchează ca necitit(e)';

$txt['mentions_settings'] = 'Notifications Settings';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = 'Enable site notifications';
$txt['mentions_buddy'] = 'Adaugă o menționare când cineva este adăugat într-o listă de amici.';
$txt['mentions_dont_notify_rlike'] = 'Nu informa utilizatorul când se elimină un „Like”';

$txt['mention_mentionmem'] = 'Te-a menționat în mesajul {msg_link}';
$txt['mention_likemsg'] = 'I-a plăcut mesajul tău {msg_link}';
$txt['mention_rlikemsg'] = 'I-a displăcut mesajul tău {msg_link}';
$txt['mention_buddy'] = 'Te-au adăugat la lista lor de amici.';
$txt['mention_quotedmem'] = 'Quoted a message of yours in {msg_link}';
$txt['mention_mailfail'] = 'Disabled email notification due to delivery failure';

$txt['mentions_type_all'] = 'Toate menționările';
$txt['mentions_type_mentionmem'] = 'Menționat';
$txt['mentions_type_likemsg'] = '"Likes"';
$txt['mentions_type_rlikemsg'] = '"Unlikes”';
$txt['mentions_type_buddy'] = 'Amic';
$txt['mentions_type_quotedmem'] = 'Quoted';
$txt['mentions_type_mailfail'] = 'Delivery Failure';

$txt['mentions_mark_all_read'] = 'Marchează aceste menționări ca citite';

$txt['setting_notify_enable_this'] = 'Enable user notifications of this event.';

$txt['setting_buddy'] = 'Amici';
$txt['setting_likemsg'] = '"Likes"';
$txt['setting_rlikemsg'] = 'Removed likes';
$txt['setting_mentionmem'] = '@mentions';
$txt['setting_quotedmem'] = 'Quoting';
$txt['setting_mailfail'] = 'Delivery Failures';