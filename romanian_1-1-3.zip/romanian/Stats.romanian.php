<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Cei mai mulţi utilizatori online';

$txt['stats_center'] = 'Centrul de statistică';
$txt['general_stats'] = 'Statistică generală';
$txt['top_posters'] = 'Top 10 utilizatori (după numărul de mesaje)';
$txt['top_boards'] = 'Top 10 secţiuni';
$txt['forum_history'] = 'Istoricul forumului (folosind fusul orar al forumului)';
$txt['stats_new_topics'] = 'Subiectele noi';
$txt['stats_new_posts'] = 'Mesaje noi';
$txt['stats_new_members'] = 'Membrii noi';
$txt['page_views'] = 'Vizualizările paginii';
$txt['top_topics_replies'] = 'Top 10 subiecte (după răspunsuri)';
$txt['top_topics_views'] = 'Top 10 subiecte (după vizualizări)';
$txt['yearly_summary'] = 'Sumarul anual';
$txt['top_starters'] = 'Topul iniţiatorilor de subiecte de discuţie';
$txt['most_time_online'] = 'Cel mai mult timp online';

$txt['average_members'] = 'Media zilnică a înregistrărilor';
$txt['average_posts'] = 'Media zilnică a mesajelor postate';
$txt['average_topics'] = 'Media zilnică a subiectelor de discuţie deschise';
$txt['average_online'] = 'Media zilnică a utilizatorilor online';
$txt['users_online'] = 'Utilizatorii online';
$txt['emails_sent'] = 'Media zilnică a email-urilor';
$txt['users_online_today'] = 'Online azi';
$txt['num_hits'] = 'Totalul vizualizărilor paginii';
$txt['average_hits'] = 'Media zilnică a vizualizărilor paginii';

$txt['ssi_comment'] = 'comentariu';
$txt['ssi_comments'] = 'comentarii';
$txt['ssi_write_comment'] = 'Scrie comentariu';
$txt['ssi_no_guests'] = 'Nu poți indica o arie care nu acceptă vizitatori. Verifică ID-ul ariei înainte de a încerca din nou.';
$txt['xml_rss_desc'] = 'Informații în timp real de la {forum_name}';