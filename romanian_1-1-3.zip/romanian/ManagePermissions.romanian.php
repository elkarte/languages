<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Administrează setările generale privind drepturile';
$txt['permissions_modify'] = 'Modifică';
$txt['permissions_view'] = 'Vezi';
$txt['permissions_allowed'] = 'Permis';
$txt['permissions_denied'] = 'Interzis';
$txt['permission_cannot_edit'] = '<strong>Notă:</strong> Nu poți edita acest profil de drepturi pentru că este un profil predefinit inclus implicit în software-ul forumului. Dacă vrei să modifici drepturile asociate cu acest profil trebuie mai întâi să creezi o copie a sa. Poți face asta <a href="%1$s">apăsând aici.';

$txt['permissions_for_profile'] = 'Drepturi pentru profilul';
$txt['permissions_boards_desc'] = 'Mai jos sunt afişate profilurile de drepturi care au fost alocate fiecărei arii.<br />Poţi modifica alocările profilurilor la arii fie individual (apăsând pe pictograma "creion" din dreptul numelui profilului sau pe numele ariei), fie multiplu (selectând &quot;editează toate&quot; în josul paginii).<br />Pentru a edita drepturile efective asociate unui profil anume apasă pe numele profilului.';
$txt['permissions_board_all'] = 'Editează tot';
$txt['permission_profile'] = 'Profilul de drepturi';
$txt['permission_profile_desc'] = 'Which <a target="_blank" href="%1$s">permission set</a> the board should use.';
$txt['permission_profile_inherit'] = 'Moştenește de la aria părinte';

$txt['permissions_profile'] = 'Profilul';
$txt['permissions_profiles_desc'] = 'Profilurile de drepturi sunt atribuite individual ariilor pentru a permite administrarea facilă a setărilor de securitate. În această zonă poți crea, edita sau șterge Profiluri de drepturi.';
$txt['permissions_profiles_change_for_board'] = 'Editează profilul de drepturi pentru: &quot;%1$s&quot;';
$txt['permissions_profile_default'] = 'Implicit';
$txt['permissions_profile_no_polls'] = 'Niciun Sondaj';
$txt['permissions_profile_reply_only'] = 'Răspundeţi Numai ';
$txt['permissions_profile_read_only'] = 'Doar Citire ';

$txt['permissions_profile_rename'] = 'Redenumește tot';
$txt['permissions_profile_edit'] = 'Profiluri de drepturi pentri arii';
$txt['permissions_profile_new'] = 'Profil nou';
$txt['permissions_profile_new_create'] = 'Creează';
$txt['permissions_profile_name'] = 'Numele profilului';
$txt['permissions_profile_used_by'] = 'Utilizat de';
$txt['permissions_profile_used_by_one'] = 'o arie';
$txt['permissions_profile_used_by_many'] = '%1$d arii';
$txt['permissions_profile_used_by_none'] = 'nici o arie';
$txt['permissions_profile_do_edit'] = 'Editează';
$txt['permissions_profile_do_delete'] = 'Şterge';
$txt['permissions_profile_copy_from'] = 'Copiază drepturile de la';

$txt['permissions_includes_inherited'] = 'Grupurile moştenite';
$txt['permissions_includes_inherited_from'] = 'Moștenit de la:';

$txt['permissions_all'] = 'toate';
$txt['permissions_none'] = 'nici una';
$txt['permissions_set_permissions'] = 'Setează drepturile';

$txt['permissions_advanced_options'] = 'Opţiuni avansate';
$txt['permissions_with_selection'] = 'Pentru grupurile selectate mai sus ...';
$txt['permissions_apply_pre_defined'] = '... aplică setul predefinit de drepturi ';
$txt['permissions_select_pre_defined'] = 'Selectează un set predefinit';
$txt['permissions_copy_from_board'] = 'Copiază drepturile ariei';
$txt['permissions_select_board'] = 'Selectează o arie';
$txt['permissions_like_group'] = '... copiază drepturile grupului ';
$txt['permissions_select_membergroup'] = 'Selectează un grup de membri';
$txt['permissions_add'] = '... acordă dreptul  ';
$txt['permissions_remove'] = '... revocă dreptul  ';
$txt['permissions_deny'] = '... interzi explicit dreptul  ';
$txt['permissions_select_permission'] = 'Selectează un drept';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Puteţi selecta numai o acţiune pentru a modifica drepturile';
$txt['permissions_no_action'] = 'Nicio acţiune selectată';
$txt['permissions_deny_dangerous'] = 'Eşti pe cale să interzici una sau mai multe drepturi.\\nAcest lucru poate fi periculos şi poate duce la rezultate neaşteptate dacă nu te-ai asigurat că nu există utilizatori alocaţi în mod \\"accidental\\"  la grupul sau grupurile pentru care interzici drepturile. \\n\\nEşti sigur că vrei să continui?';

$txt['permissions_modify_group'] = 'Modificarea Grupului';
$txt['permissions_general'] = 'Drepturi pentru grupuri';
$txt['permissions_board'] = 'Profilul "Implicit" de drepturi de arie';
$txt['permissions_board_desc'] = '<strong>Notă</strong>: schimbarea acestor drepturi ale ariei va afecta toate Ariile care acum au atribuite profilul de drepturi &quot;Implicit&quot;. Ariile care nu folosesc profilul &quot;Implicit&quot; nu vor fi afectate de modificările făcute în această pagină.';
$txt['permissions_commit'] = 'Salvare modificări';
$txt['permissions_on'] = 'în profilul';
$txt['permissions_local_for'] = 'Drepturi de grup';
$txt['permissions_option_on'] = 'P';
$txt['permissions_option_off'] = 'X';
$txt['permissions_option_deny'] = 'I';
$txt['permissions_option_desc'] = 'For each permission you can pick either \'Allow\' (A), \'Disallow\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />Remember that if you deny a permission, any member - whether moderator or otherwise - that is in that group will be denied that as well.<br />For this reason, you should use deny carefully, only when <strong>necessary</strong>. Disallow, on the other hand, denies unless otherwise granted.';

$txt['permissiongroup_general'] = 'General ';
$txt['permissionname_view_stats'] = 'Vizualizare statistici forum';
$txt['permissionhelp_view_stats'] = 'Statisticile forumului din acesta pagină sunt un sumar al tuturor statisticilor cum ar fi numărul de utilizatori, media zilnică de mesaje şi alte câteva clasamente de genul Cele mai multe 10. Activând aceasta permisiune, adaugă o legătură în josul paginii principale (\'[Mai multe statistici]\').';
$txt['permissionname_view_mlist'] = 'View the member list and groups';
$txt['permissionhelp_view_mlist'] = 'The member list shows all members that have registered on your forum. The list can be sorted and searched. The member list is linked from both the board index and the stats page, by clicking on the number of members. It also applies to the groups page which is a mini memberlist of people in that group.';
$txt['permissionname_who_view'] = 'Vezi Cine e Online';
$txt['permissionhelp_who_view'] = 'Opțiunea Cine e Online arată toți membrii care sunt momentan online și ce fac pe forum. Această permisiune va functiona numai dacă ați activat opțiunea din \'Features and Options\'. Puteți accesa aria \'Who\'s Online\' prin apăsarea pe linkul din ariea \'Users Online\' a Indexului Ariilor (pagina principala a forumului). Chiar daca permisiunea este interzisă, utilizatorii tot pot vedea cine este online, dar nu ce face fiecare.';
$txt['permissionname_search_posts'] = 'Căutare de mesaje postate şi subiecte de discuţie';
$txt['permissionhelp_search_posts'] = ' Permisiunea de Căutare permite utilizatorului să caute prin toate Ariile în care îi este permis să intre. Când permisiunea de Căutare este activata, un buton de \'Search\' va fi adăugat barei de meniu a forumului.';
$txt['permissionname_karma_edit'] = 'Modificaţi karma altor persoane ';
$txt['permissionhelp_karma_edit'] = 'Karma is a feature that shows the popularity of a member. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to cast a vote. This permission has no effect on guests.';
$txt['permissionname_like_posts'] = 'Like other users\' posts';
$txt['permissionhelp_like_posts'] = 'Likes is a feature that shows the popularity of a post. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to like a post or unlike one they previously liked.  This permission has no effect on guests.';
$txt['permissionname_like_posts_stats'] = 'See like posts stats';
$txt['permissionhelp_like_posts_stats'] = 'This will allow users to see stats of posts liking';
$txt['permissionname_disable_censor'] = 'Disable word censor';
$txt['permissionhelp_disable_censor'] = 'Allows members the option to disable the word censor.';

$txt['permissiongroup_pm'] = 'Mesaje Personale';
$txt['permissionname_pm_read'] = 'Citire mesaje personale
';
$txt['permissionhelp_pm_read'] = 'Această permisiune le permite utilizatorilor să acceseze secţiunea de Mesaje Personale şi să-şi citească Mesajele Personale. Fără această permisiune un utilizator se află în imposibilitatea de a trimite Mesaje Personale. ';
$txt['permissionname_pm_send'] = 'Trimite mesaje personale';
$txt['permissionhelp_pm_send'] = 'Trimite mesaje personale altor membri înregistraţi. Necesită permisiunea "Citire mesaje personale" . ';
$txt['permissionname_send_email_to_members'] = 'Send emails';
$txt['permissionhelp_send_email_to_members'] = 'Send emails to other registered members.';

$txt['permissiongroup_calendar'] = 'Calendar';
$txt['permissionname_calendar_view'] = 'Vizualizare calendar';
$txt['permissionhelp_calendar_view'] = 'Calendarul afișează zilele de naștere, evenimentele și vacanțele pentru fiecare lună în parte. Această permisiune oferă acces utilizatorilor la acest calendar. Când această permisiune este activată, un buton va fi adăugat la bara de meniu a forumului, iar o listă cu actualele și viitoarele zile de naștere, evenimente sau vacanțe va fi afișată la subsolul indexului ariei. Calendarul trebuie să fie activat din \\\'Configurație - Caracteristici de bază\\\'.';
$txt['permissionname_calendar_post'] = 'Creaţi evenimente în calendar';
$txt['permissionhelp_calendar_post'] = 'Un eveniment este un Subiect legat de o dată anume sau de un șir de date. Crearea evenimentelor se poate face din Calendar. Un eveniment poate fi creat numai dacă utilizatorului care crează evenimentul îi este permis să publice Subiecte noi.';
$txt['permissionname_calendar_edit'] = 'Editare evenimente în calendar';
$txt['permissionhelp_calendar_edit'] = 'Un Eveniment este un subiect de discuție legat de o dată anume sau de un șir de date. Evenimentul poate fi editat prin apăsarea steluței roșii (*) de lângă eveniment, atunci când vizualizați calendarul. Pentru a putea edita un eveniment utilizatorul trebuie să aibă drepturi suficiente de editare a primului mesaj postat în subiectul de discuție legat de acel eveniment.';
$txt['permissionname_calendar_edit_own'] = 'Evenimente Proprii';
$txt['permissionname_calendar_edit_any'] = 'Orice evenimente';

$txt['permissiongroup_maintenance'] = 'Administrare Forum';
$txt['permissionname_admin_forum'] = 'Administrare forum şi bază de date';
$txt['permissionhelp_admin_forum'] = 'Această permisiune permite unui utilizator să:<ul class="normallist"><li>schimbe setările pentru forum, baza de date și temă</li><li>administreze Pachetele de Modificări</li><li>utilizeze uneltele de mentenanță a forumului și a bazei de date</li><li>vizualizeze logurile de erori și logurile de moderare</li></ul> Utilizați această permisiune cu prudență, deoarece dă puteri foarte mari.';
$txt['permissionname_manage_boards'] = 'Administrare secţiuni şi categorii';
$txt['permissionhelp_manage_boards'] = 'Această permisiune permite crearea, editarea şi eliminarea de secţiuni şi categorii.';
$txt['permissionname_manage_attachments'] = 'Gestionaţi fişierele ataşate şi avatarele';
$txt['permissionhelp_manage_attachments'] = 'Această permisiune permite accesul la Centrul de Atașamente, unde toate fișierele  atașate forumului și avatarele sunt listate și pot fi șterse.';
$txt['permissionname_manage_smileys'] = 'Administrează emoticoanele și iconițele de mesaj';
$txt['permissionhelp_manage_smileys'] = 'Aceasta permite accesul la Centrul de Emoticoane. De acolo se pot adăuga, edita, sau șterge emoticoanele și seturile de emoticoane. Dacă ați activat iconițele de mesaj personalizate, cu această permisiune, puteți de asemenea adăuga și edita iconițele de mesaj.';
$txt['permissionname_edit_news'] = 'Editare ştiri';
$txt['permissionhelp_edit_news'] = 'The news function allows a random news line to appear on each screen. In order to use the news function, enable it in the forum settings.';
$txt['permissionname_access_mod_center'] = 'Accesaţi centrul de moderare';
$txt['permissionhelp_access_mod_center'] = 'Cu aceastea permisiune orice membru al acestui grup poate accesa Centrul de Moderare, de unde vor avea acces la funcționalități care ușurează munca de moderare. Notați că această permisiune nu dă de una singură privilegii de moderare.';

$txt['permissiongroup_member_admin'] = 'Administrare membri';
$txt['permissionname_moderate_forum'] = 'Moderează membrii forumului';
$txt['permissionhelp_moderate_forum'] = 'Această permisiune include toate funcțiile impotante de moderare a membrilor:<ul class="normallist"><li>accesarea centrului de administrare a înregistrărilor</li><li>accesarea paginii de vizualizare/ștergere a membrilor</li><li>informații extensive de profil, incluzând urmărirea IP/per utilizator și statusul (ascuns) de stare online</li><li>activează conturi</li><li>primește notificările de aprobare si permite aprobarea conturilor</li><li>imunitate la ignorarea PM-urilor</li><li>multe alte drepturi mici</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Administrare și desemnare Grupuri de Membri';
$txt['permissionhelp_manage_membergroups'] = 'Această permisiune permite unui utilizator să editeze Grupurile de Membri și să atribuie Grupuri de Membri altor utilizatori.';
$txt['permissionname_manage_permissions'] = 'Gestionează drepturi';
$txt['permissionhelp_manage_permissions'] = 'Aceasta permisiune permite unui utilizator să editeze drepturile unui Grup de Membri, în mod global sau pentru fiecare Arie în parte.';
$txt['permissionname_manage_bans'] = 'Administrare lista de banare';
$txt['permissionhelp_manage_bans'] = 'This permission allows a user to add or remove user names, IP addresses, hostnames and email addresses to or from a list of banned users. It also allows a user to view and remove log entries of banned users that attempted to login.';
$txt['permissionname_send_mail'] = 'Broadcast to multiple members';
$txt['permissionhelp_send_mail'] = 'Mass mail all forum members or just a few member groups by email or personal message (the latter requires the \'Send Personal Message\' permission).';
$txt['permissionname_issue_warning'] = 'Issue warnings to members';
$txt['permissionhelp_issue_warning'] = 'Issue a warning to members of the forum and change that members\' warning level. Requires the warning system to be enabled.';

$txt['permissiongroup_profile'] = 'Member Profiles';
$txt['permissionname_profile_view'] = 'View profile summary and stats';
$txt['permissionhelp_profile_view'] = 'This permission allows users clicking on a user name to see a summary of profile settings, some statistics and all posts of the user.';
$txt['permissionname_profile_view_own'] = 'Profilul propriu';
$txt['permissionname_profile_view_any'] = 'Orice profil';
$txt['permissionname_profile_identity'] = 'Editaţi setările contului';
$txt['permissionhelp_profile_identity'] = 'Account settings are the basic settings of a profile, like password, email address, member group and preferred language.';
$txt['permissionname_profile_identity_own'] = 'Profilul propriu';
$txt['permissionname_profile_identity_any'] = 'Orice profil';
$txt['permissionname_profile_extra'] = 'Edit additional profile settings';
$txt['permissionhelp_profile_extra'] = 'Additional profile settings include settings for avatars, theme preferences, notifications and Personal Messages.';
$txt['permissionname_profile_extra_own'] = 'Profilul propriu';
$txt['permissionname_profile_extra_any'] = 'Orice profil';
$txt['permissionname_profile_title'] = 'Editare titlu personalizat';
$txt['permissionhelp_profile_title'] = 'The custom title is shown on the topic display page, under the profile of each user that has a custom title.';
$txt['permissionname_profile_title_own'] = 'Profilul propriu';
$txt['permissionname_profile_title_any'] = 'Orice profil';
$txt['permissionname_profile_remove'] = 'Ştergere cont';
$txt['permissionhelp_profile_remove'] = 'This permission allows a user to delete his account, when set to \'Own Account\'.';
$txt['permissionname_profile_remove_own'] = 'Cont propriu';
$txt['permissionname_profile_remove_any'] = 'Orice cont';
$txt['permissionname_profile_set_avatar'] = 'Alege un avatar';
$txt['permissionhelp_profile_set_avatar'] = 'If enabled this will allow a user to select an avatar.';

$txt['permissiongroup_general_board'] = 'General ';
$txt['permissionname_moderate_board'] = 'Moderate board';
$txt['permissionhelp_moderate_board'] = 'Drepturile pentru moderarea ariilor adaugă câteva mici drepturi care transformă un utilizator obișnuit în moderator. Printre acestea sunt: răspunsul la subiecte închise, schimbarea expirării sondajelor, accesul la rezultatele sondajelor etc.';

$txt['permissiongroup_topic'] = 'Subiecte';
$txt['permissionname_post_new'] = 'Deschide subiecte noi';
$txt['permissionhelp_post_new'] = 'This permission allows users to post new topics. It doesn\'t allow to post replies to topics.';
$txt['permissionname_merge_any'] = 'Merge any topic';
$txt['permissionhelp_merge_any'] = 'Merge two or more topics into one. The order of messages within the merged topic will be based on the time the messages were created. A user can only merge topics on those boards a user is allowed to merge. In order to merge multiple topics at once, a user has to enable quick moderation in their profile settings.';
$txt['permissionname_split_any'] = 'Split any topic';
$txt['permissionhelp_split_any'] = 'Split a topic into two separate topics.';
$txt['permissionname_send_topic'] = 'Trimite subiecte la prieteni';
$txt['permissionhelp_send_topic'] = 'This permission allows a user to mail a topic to a friend, by entering their email address and allows adding a message.';
$txt['permissionname_make_sticky'] = 'Fixează subiecte';
$txt['permissionhelp_make_sticky'] = 'Pinned topics are topics that always remain on top of a board. They can be useful for announcements or other important messages.';
$txt['permissionname_move'] = 'Move topics';
$txt['permissionhelp_move'] = 'Move a topic from one board to the other. Users can only select target boards they are allowed to access.';
$txt['permissionname_move_own'] = 'Subiect propriu de discuţie';
$txt['permissionname_move_any'] = 'Orice subiect de discuţie';
$txt['permissionname_lock'] = 'Blocaţi subiecte';
$txt['permissionhelp_lock'] = 'This permission allows a user to lock a topic. This can be done in order to make sure no one can reply to a topic. Only users with a \'Moderate board\' permission can still post in locked topics.';
$txt['permissionname_lock_own'] = 'Subiect propriu de discuţie';
$txt['permissionname_lock_any'] = 'Orice subiect de discuţie';
$txt['permissionname_remove'] = 'Eliminaţi subiecte';
$txt['permissionhelp_remove'] = 'Delete topics as a whole. Note that this permission doesn\'t allow to delete specific messages within the topic!';
$txt['permissionname_remove_own'] = 'Subiect propriu de discuţie';
$txt['permissionname_remove_any'] = 'Orice subiecte de discuţie';
$txt['permissionname_post_reply'] = 'Postaţi răspunsuri la subiecte';
$txt['permissionhelp_post_reply'] = 'Această permisiune permite să se răspundă la subiectele de discuţie.';
$txt['permissionname_post_reply_own'] = 'Subiect propriu de discuţie';
$txt['permissionname_post_reply_any'] = 'Orice subiect de discuţie';
$txt['permissionname_modify_replies'] = 'Modifică răspunsurile la subiectele proprii';
$txt['permissionhelp_modify_replies'] = 'This permission allows a user that started a topic to modify all replies to their topic.';
$txt['permissionname_delete_replies'] = 'Şterge răspunsurile la propriile subiecte de discuţie';
$txt['permissionhelp_delete_replies'] = 'This permission allows a user that started a topic to remove all replies to their topic.';
$txt['permissionname_announce_topic'] = 'Anunţă subiectul de discuție';
$txt['permissionhelp_announce_topic'] = 'This allows a user to send an announcement email about a topic to all members or to a few member groups.';

$txt['permissionname_approve_emails'] = 'Moderate Post by Email Failures';
$txt['permissionhelp_approve_emails'] = 'Allow moderators to access the Post by Email failure log to perform actions including approve, delete, view and bounce.  Note, since the system may not always know what board a post goes to, this permission should be only be given to members with full board access';
$txt['permissionname_postby_email'] = 'Post by Email';
$txt['permissionhelp_postby_email'] = 'This permission allows users to start new topics as well as reply to topic and PM notifications by email.';

$txt['permissiongroup_post'] = 'Postări';
$txt['permissionname_delete'] = 'Ştergere mesaje postate';
$txt['permissionhelp_delete'] = 'Remove posts. This does not allow a user to delete the first post of a topic.';
$txt['permissionname_delete_own'] = 'Subiect de discuţie propriu';
$txt['permissionname_delete_any'] = 'Orice mesaj postat';
$txt['permissionname_modify'] = 'Modificare mesaje postate';
$txt['permissionhelp_modify'] = 'Editare mesaje postate';
$txt['permissionname_modify_own'] = 'Subiect de discuţie propriu';
$txt['permissionname_modify_any'] = 'Orice mesaj postat';
$txt['permissionname_report_any'] = 'Raportaţi mesajele postate la moderatori';
$txt['permissionhelp_report_any'] = 'This permission adds a link to each message, allowing a user to report a post to a moderator. On reporting, all moderators on that board will receive an email with a link to the reported post and a description of the problem (as given by the reporting user).';

$txt['permissiongroup_poll'] = 'Sondaje';
$txt['permissionname_poll_view'] = 'Vezi sondajele';
$txt['permissionhelp_poll_view'] = 'Această permisiune permite unui utilizator să vizualizeze un sondaj. Fără această permisiune, utilizatorul va vedea doar subiectul de discuţie.';
$txt['permissionname_poll_vote'] = 'Votează în sondaje';
$txt['permissionhelp_poll_vote'] = 'This permission allows a (registered) user to cast one vote. It doesn\'t apply to guests.';
$txt['permissionname_poll_post'] = 'Postaţi sondaje';
$txt['permissionhelp_poll_post'] = 'Această permisiune permite unui utilizator să posteze un nou sondaj de opinie. Utilizatorul trebuie să aibă permisiunea \'Postaţi subiecte noi\' .';
$txt['permissionname_poll_add'] = 'Adăugaţi sondaje la subiecte';
$txt['permissionhelp_poll_add'] = 'Add poll to topics allows a user to add a poll after the topic has been created. This permission requires sufficient rights to edit the first post of a topic.';
$txt['permissionname_poll_add_own'] = 'Subiecte proprii de discuţie';
$txt['permissionname_poll_add_any'] = 'Orice subiecte de discuţie';
$txt['permissionname_poll_edit'] = 'Editare sondaje';
$txt['permissionhelp_poll_edit'] = 'This permission allows a user to edit the options of a poll and to reset the poll. In order to edit the maximum number of votes and the expiration time, a user needs to have the \'Moderate board\' permission.';
$txt['permissionname_poll_edit_own'] = 'Sondaj propriu';
$txt['permissionname_poll_edit_any'] = 'Orice sondaj';
$txt['permissionname_poll_lock'] = 'Blocare sondaje';
$txt['permissionhelp_poll_lock'] = 'Locking polls prevents the poll from accepting any more votes.';
$txt['permissionname_poll_lock_own'] = 'Sondaj propriu';
$txt['permissionname_poll_lock_any'] = 'Orice sondaj';
$txt['permissionname_poll_remove'] = 'Eliminare sondaje';
$txt['permissionhelp_poll_remove'] = 'Această permisiune permite eliminarea sondajelor.';
$txt['permissionname_poll_remove_own'] = 'Sondaj propriu';
$txt['permissionname_poll_remove_any'] = 'Orice sondaj';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Save drafts of new posts';
$txt['permissionname_simple_post_draft'] = 'Save drafts of new posts';
$txt['permissionhelp_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionhelp_simple_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionname_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionname_simple_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionhelp_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionname_simple_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionhelp_pm_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid losing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionname_simple_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionhelp_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';
$txt['permissionhelp_simple_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';

$txt['permissiongroup_approval'] = 'Moderarea postărilor';
$txt['permissionname_approve_posts'] = 'Aprobaţi elementele care aşteaptă moderarea';
$txt['permissionhelp_approve_posts'] = 'This permission allows a user to approve all unapproved items on a board.';
$txt['permissionname_post_unapproved_replies'] = 'Postaţi răspunsurile la subiecte, dar ascundeţi-le până sunt aprobate';
$txt['permissionhelp_post_unapproved_replies'] = 'This permission allows a user to post replies to a topic. The replies will not be shown until approved by a moderator.';
$txt['permissionname_post_unapproved_replies_own'] = 'Subiect propriu de discuţie';
$txt['permissionname_post_unapproved_replies_any'] = 'Orice subiect de discuţie';
$txt['permissionname_post_unapproved_topics'] = 'Postaţi subiecte noi, dar ascundeţi-le până când sunt aprobate';
$txt['permissionhelp_post_unapproved_topics'] = 'This permission allows a user to post a new topic which will require approval before being shown.';
$txt['permissionname_post_unapproved_attachments'] = 'Postaţi ataşamente, dar ascundeţi-le până sunt aprobate';
$txt['permissionhelp_post_unapproved_attachments'] = 'This permission allows a user to attach files to their posts. The attached files will then require approval before being shown to other users.';

$txt['permissiongroup_notification'] = 'Notificări';
$txt['permissionname_mark_any_notify'] = 'Request notification on replies';
$txt['permissionhelp_mark_any_notify'] = 'This feature allows users to receive a notification whenever someone replies to a topic they subscribed to.';
$txt['permissionname_mark_notify'] = 'Request notification on new topics';
$txt['permissionhelp_mark_notify'] = 'Notification on new topics is a feature that allows a user to receive an email every time a new topic is created on the board they subscribe to.';

$txt['permissiongroup_attachment'] = 'Ataşamente';
$txt['permissionname_view_attachments'] = 'Vezi ataşamentele';
$txt['permissionhelp_view_attachments'] = 'Attachments are files that are attached to posted messages. This feature can be enabled and configured in \'Attachments and avatars\'. Since attachments are not directly accessed, you can protect them from being downloaded by users that don\'t have this permission.';
$txt['permissionname_post_attachment'] = 'Adaugă ataşamente';
$txt['permissionhelp_post_attachment'] = 'Attachments are files that are attached to posted messages. One message can contain multiple attachments.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Permission Settings';
$txt['groups_manage_permissions'] = 'Member groups allowed to manage permissions';
$txt['permission_enable_deny'] = 'Activaţi opţiunea de a refuza drepturile
';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Turning off this option will update \\\'Deny\\\'-permissions to \\\'Disallow\\\'.';
$txt['permission_by_board_desc'] = 'Here you can set which permission profile a board uses. You can create new permission profiles from the &quot;Edit Profiles&quot; menu.';
$txt['permission_settings_desc'] = 'Aici puteţi seta cine are permisiunea de a modifica drepturi, precum şi cât de sofisticat ar trebui să fie sistemul de drepturi. ';
$txt['permission_enable_postgroups'] = 'Activaţi drepturile pentru grupurile pe bază de număr de mesaje postate';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Dezactivarea acestei setări va elimina drepturile stabilite în prezent pentru grupurile pe bază de număr de mesaje postate.';

$txt['permissions_post_moderation_desc'] = 'From this page you can easily change which groups have their posts moderated for a particular permission profile.';
$txt['permissions_post_moderation_deny_note'] = 'Reţineţi că, în timp ce aveţi drepturile avansate activate nu se poate aplica permisiunea de a &quot;refuza&quot; pe această pagină. Vă rugăm să editaţi drepturile direct dacă doriţi să aplicaţi o permisiune de refuzare.';
$txt['permissions_post_moderation_select'] = 'Selectează Profil ';
$txt['permissions_post_moderation_new_topics'] = 'Subiectele noi';
$txt['permissions_post_moderation_replies_own'] = 'Răspunsurile Proprii';
$txt['permissions_post_moderation_replies_any'] = 'Orice Răspunsuri';
$txt['permissions_post_moderation_attachments'] = 'Ataşamente';
$txt['permissions_post_moderation_legend'] = 'Legenda';
$txt['permissions_post_moderation_allow'] = 'Pot crea';
$txt['permissions_post_moderation_moderate'] = 'Se poate crea dar necesită aprobare';
$txt['permissions_post_moderation_disallow'] = 'Nu se poate crea';
$txt['permissions_post_moderation_group'] = 'Grup';

$txt['auto_approve_topics'] = 'Post new topics without requiring approval';
$txt['auto_approve_replies'] = 'Post replies to topics without requiring approval';
$txt['auto_approve_attachments'] = 'Post attachments without requiring approval';
