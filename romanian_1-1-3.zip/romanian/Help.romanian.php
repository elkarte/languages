<?php
// Version: 1.1; Help

global $helptxt;

$txt['close_window'] = 'Închide fereastra';

$helptxt['manage_boards'] = '<strong>Editare Secţiuni</strong><br /> În acest meniu poţi crea/reordona/elimina secţiunile şi categoriile de deasupra lor.  De exemplu, dacă ai avea un site care ar oferi informaţii cu privire la  "Sporturi" şi "Maşini" şi "Muzică", acestea ar fi Categoriile principale pe care le-ai crea.  Sub fiecare dintre aceste categorii vei dori probabil să creezi în mod ierarhic "Subcategorii" şi "Arii" pentru subiecte de discuţie în fiecare dintre ele. Este vorba de o simplă ierarhie cu această structură:  <br /> <ul class="normallist"> <li> <strong>Sporturi</strong> &nbsp;- O "categorie" </li> <ul class="normallist"> <li> <strong>Baseball</strong> &nbsp;- O arie în categoria "Sporturi" </li> <ul class="normallist"> <li> <strong>Statistici</strong> &nbsp;- O subarie în aria "Baseball" </li> </ul> <li> <strong>Fotbal</strong> &nbsp;- O arie în categoria of "Sporturi"</li> </ul>
</ul> 	Categoriile iti permit să spargeţi forumul în subiecte vaste ("Maşini, Sporturi") iar "Ariile" din ele sunt de fapt subiectele în care membrii pot posta. Un utilizator interesat de Pintos ar posta un mesaj în "Maşini->Pinto". Categoriile le permit oamenilor să găsească rapid ceea ce îi interesează: În loc de "Magazin" ai magazinele "Hardware" şi "Articole de îmbrăcăminte" la care poţi merge. Aceasta simplifică căutarea pentru "pipe joint compound" pentru că poţi merge la "categoria" Magazinul Hardware  în loc de a merge la Magazinul cu Articole de îmbrăcăminte (unde e puţin probabil să găsesti pipe joint compound).<br /> După cum s-a menţionat mai sus o arie este un subiect-cheie dintr-o categorie vastă. Dacă vrei să discuţi despre "Pintos" va trebui să mergi la categoria "Auto" şi să sari în aria "Pinto" pentru a posta gândurile tale în acea secţiune..<br /> Funcţiile administrative pentru acest element de meniu sunt crearea de noi arii sub fiecare categorie, reordonarea (pune "Pinto" după "Chevy") sau ştergerea ariilor în întregime.';

$helptxt['edit_news'] = '<ul class="normallist">  <li>  <strong>Ştiri</strong><br /> Această arie vă permite să setaţi textul pentru ştirile afişate pe pagina de Index a Forumului. Adăugaţi orice element doriţi (de exemplu &quot;Nu pierdeţi conferinţa de marţi&quot;). Fiecare element de ştiri va fi afişat aleator şi ar trebui să fie plasat într-o casetă separată. </li> <li> <strong>Buletine de ştiri</strong><br />  Această arie vă permite să le trimiteţi buletine de ştiri membrilor forumului prin intermediul mesajelor private sau e-mail-ului. Mai întâi selectaţi grupurile care doriţi să primească buletinul de ştiri şi pe cele care nu doriţi să primească buletinul de ştiri. Dacă doriţi, puteţi adăuga membri suplimentari şi adrese de e-mail care vor primi buletinul de ştiri. În final, introduceţi mesajul pe care doritţi să îl trimiteţi şi selectaţi dacă doriţi să îl trimiteţi membrilor ca mesaj privat sau ca mesaj de e-mail. </li> <li>strong>Setări</strong><br /> Această arie conţine câteva setări privind ştirile şi buletinele de ştiri, inclusiv selectarea grupurilor care pot edita ştirile din forum sau pot trimite buletine de ştiri.  Există acolo şi o setare pentru a configura dacă doriţi activarea feed-urilor de ştiri pe forum, precum şi o setare pentru a configura lungimea (cât de multe caractere sunt afişate) pentru fiecare post de ştiri din feed-ul de ştiri.</li> </ul> ';

$helptxt['view_members'] = '
⇥<ul class="normallist">
⇥⇥<li>
⇥⇥⇥<strong>Vezi toți membrii</strong><br />
⇥⇥⇥Vezi toți membrii de pe forum. Ți se prezintă o listă cu numele membrilor. Poți face click
⇥⇥⇥pe oricare dintre nume penru a accesa detalii despre utilizator (homepage, vârstă etc.), iar ca Administrator
⇥⇥⇥poți modifica toți acești parametri. Ai control complet asupra membrilor, inclusiv
⇥⇥⇥posibilitatea ștergerii acestora.<br /><br />
⇥⇥</li>
⇥⇥<li>
⇥⇥⇥<strong>Așteaptă aprobare</strong><br />
⇥⇥⇥Această arie este vizibilă doar dacă ai activat aprobarea de către admin pentru toate înregistrările noi. Toți cei care se înregistrează
⇥⇥⇥pe forum vor deveni membri cu drepturi depline doar după ce vor fi fost aprobați de către admin. Această arie arată toți membrii care
⇥⇥⇥încă așteaptă aprobarea, împreună cu adrsa de email și IP-ul. Poți alege să accepți sau să refuzi (ștergi)
⇥⇥⇥orice membru din listă, bifând casetele din dreptul numelor și alegând acțiunea respectivă din meniul drop-down de dedsubt.
⇥⇥⇥Când respingi un membru poți alege să o faci cu sau fără notificarea sa privind decizia ta.<br /><br />
⇥⇥</li>
⇥⇥<li>
⇥⇥⇥<strong>Așteaptă activare</strong><br />
⇥⇥⇥Această arie este vizibilă doar dacă ai setat forumul să solicit activarea. Această arie va lista toți
⇥⇥⇥membrii care nu și-au activat conturile încă. De aici poți alege să-i accepți, să-i respingi sau să le reamintești
⇥⇥⇥mmbrilor despre activarea în aștptare. Ca și mai sus, poți alege să informezi prin email membrii privind
⇥⇥⇥decizia pe care ai luat-o.<br /><br />
⇥⇥</li>

⇥</ul>';

$helptxt['ban_members'] = '<strong>Restricționează membri</strong><br />
⇥Aici ai posiblitatea să &quot;banezi&quot; utilizatori, pentru a interzice celor care au încălcat regulile forumului
⇥(spamming, trolling etc.) să mai continue. Poți restricționa utilizatorii careacționează în detrimentul forumului. Ca administrator
⇥vezi IP-ul de la care a fost postat fiecare mesaj pe forum. În lista de criterii de restricționare⏎
⇥introduci IP-ul respectiv, salvezi și de la acea adresă nu se mai poate posta..<br />
⇥Poți introduce restricții și după criteriul adresei de email.';

$helptxt['featuresettings'] = '<strong>Facilităţi şi Opţiuni</strong><br /> Există mai multe facilităţi în această arie care pot fi modificate în funcţie de preferinţele dumneavoastră.';

$helptxt['securitysettings'] = '<strong>Securitate şi Moderare</strong><br />  Această arie conţine setări referitoare la securitatea şi moderarea forumului dumneavoastră. ';

$helptxt['addonsettings'] = '<strong>Setări pentru Add-on-uri</strong><br />
⇥Această arie ar trebui să conțină setările adăugate de Add-on-urile instalate în forum.';

$helptxt['time_format'] = '<strong>Format Timp</strong><br /> Poţi ajusta modul în care sunt afişate ora şi data. Sunt acolo o mulţime de litere mici, dar este foarte simplu. Convenţiile urmăresc funcţia PHP strftime  şi sunt descrise ca mai jos (mai multe detalii pot fi găsite la <a href="http://www.php.net/manual/function.strftime.php" target="_blank" class="new_win">php.net</a>).<br />  <br /> Următoarele caractere sunt recunoscute în formatul şir (string): <br />  <span class="smalltext">  &nbsp;&nbsp;%a - numele abreviat al zilei saptămânii<br /> &nbsp;&nbsp;%A-  numele complet al zilei saptămânii<br /> &nbsp;&nbsp;%b - numele abreviat al lunii<br /> &nbsp;&nbsp;%B - numele complet al lunii<br /> 	&nbsp;&nbsp;%d - zi a lunii (de la 01 la 31) <br /> &nbsp;&nbsp;%D<strong>*</strong> - la fel ca %m/%d/%y <br /> 	&nbsp;&nbsp;%e<strong>*</strong> - zi a lunii (de la 1 la 31) <br /> &nbsp;&nbsp;%H - ora folosind un ceas cu 24 de ore (de la 00 la 23) <br /> &nbsp;&nbsp;%I - ora folosind un ceas cu 12 ore (de la 01 la 12) <br /> &nbsp;&nbsp;%m -  luna ca număr (de la 01 la 12) <br /> &nbsp;&nbsp;%M - minutul ca număr <br /> &nbsp;&nbsp;%p - fie "am" sau "pm" în funcţie de timpul dat<br /> &nbsp;&nbsp;%R<strong>*</strong> - timpul în notaţia de 24 ore <br /> &nbsp;&nbsp;%S - secunda ca număr zecimal <br /> &nbsp;&nbsp;%T<strong>*</strong> - timpul actual, egal cu %H:%M:%S <br /> &nbsp;&nbsp;%y - an cu 2 caractere (de la 00 la 99) <br /> &nbsp;&nbsp;%Y - an cu 4 caractere<br /> &nbsp;&nbsp;%% - un \'%\' caracter literă <br /> <br /> <em>* Nu funcţionează pe serverele bazate pe Windows.</em></span>';

$helptxt['deleteAccount_posts'] = 'Doar răspunsurile: Vor fi eliminate doar mesajele pe care acest membru le-a postat ca răspunsuri la alte postări.<br />
   Subiecte și răspunsuri: Ca mai sus dar în plus va șterge și toate subiectele începute de acest membru.';

$helptxt['live_news'] = '<strong>Live announcements</strong><br />
	This box shows recently updated announcements from <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.
	You should check here every now and then for updates, new releases, and important information from ElkArte.';

$helptxt['registrations'] = '<strong>Registration Management</strong><br />
	This section contains all the functions that could be necessary to manage new registrations on the forum. It contains up to four
	sections which are visible depending on your forum settings. These are:<br /><br />
	<ul class="normallist">
		<li>
			<strong>Register new member</strong><br />
			From this screen you can choose to register accounts for new members on their behalf. This can be useful in forums where registration is closed
			to new members, or in cases where the admin wishes to create a test account. If the option to require activation of the account
			is selected the member will be emailed a activation link which must be clicked before they can use the account. Similarly you can
			select to email the users new password to the stated email address.<br /><br />
		</li>
		<li>
			<strong>Edit Registration Agreement</strong><br />
			This allows you to set the text for the registration agreement displayed when members sign up for your forum.
			You can add or remove anything from the default registration agreement, which is included with ElkArte.<br /><br />
		</li>
		<li>
			<strong>Set Reserved Names</strong><br />
			Using this interface you can specify names which may not be used by your users.<br /><br />
		</li>
		<li>
			<strong>Settings</strong><br />
			This section will only be visible if you have permission to administrate the forum. From this screen you can decide on the registration method
			for use on your forum, as well as other registration related settings.
		</li>
	</ul>';

$helptxt['modlog'] = '<strong>Jurnalul de moderare</strong><br /> Această zonă permite membrilor din echipa de admini să urmărească toate acţiunile de moderare pe care le-au efectuat moderatorii forumului. Pentru a vă asigura că moderatorii nu pot elimina referirile la acţiunile pe care le-au efectuat, intrările nu pot fi şterse decât la 24 de ore după ce acţiunea a fost luată.';
$helptxt['adminlog'] = '<strong>Jurnalul de administrare</strong><br /> Această zonă permite membrilor din echipa de administratori să urmărească toate acţiunile de administrare care au avut loc pe forum. Pentru a vă asigura că nu pot elimina referirile la acţiunile pe care le-au efectuat, intrările nu pot fi şterse decât la 24 de ore după ce acţiunea a fost luată.';
$helptxt['badbehaviorlog'] = '<strong>Jurnalul Bad Behavior</strong><br />Această zonă permite membrilor echipei de administrare să vadă unele dintre activitățile de pe forum semnalate de Bad Behavior. Jurnalul este curățat automat de funcția Bad Behavior în așa fel încât să conțină doar activitatea din ultima săptămână.';
$helptxt['warning_enable'] = '<strong>Sistemul de avertizare a utilizatorilor</strong><br />Această funcționalitate permite membrilor echipelor de administrare și de moderare să emită avertismente membrilor - și să folosească nivelul de avertizare a unui membru pentru determinarea acțiunilor disponibile în forum. După activarea acestei funcționalități, în ariea referitoare la drepturi va apărea o setare care determină ce grupuri pot emite avertismente. Nivelurile de avertizare pot fi ajustate în profilurile membrilor. Sunt disponibile următoarele opțiuni adiționale:';
$helptxt['watch_enable'] = '<strong>Nivelul de avertizare pentru supraveghre</strong><br />Această setare definește procentul punctelor de avertizare peste care utilizatorul avertizat este inclus automat pe lista celor &quot;supravegheați&quot;. Membrii &quot;supravegheați&quot; vor apărea în aria relevantă din centrul de moderare.';
$helptxt['moderate_enable'] = '<strong>Nivelul de avertizare pentru moderarea postărilor</strong><br />Membrii care depășesc acest nivel vor constata că toate postările lor vor necesita aprobarea moderatorilor pentru a fi publicate în forum.⇥Această setare are prioritate față de orice permisiune locală la nivel de arie ce poate exista, referitoare la moderarea postărilor.';
$helptxt['mute_enable'] = '<strong>Nivelul de avertizare pentru interzicerea postării</strong><br />Dacă avertizările unui membru depășesc acest nivel, acesta va constata că nu mai poate posta. Utilizatorul își va pierde toate drepturile de postare, dar poate trimite/primi MP.';
$helptxt['perday_limit'] = '<strong>Numărul maxim de puncte per membru per zi</strong><br />Această setare limitează numărul de puncte de avertizare pe care un anume moderator le poate acorda / retrage unui anume utilizator într-o perioadă de douăzeci și patru de ore. Setarea este folosită pentru a limita puterile moderatorilor pe o perioadă scurtă de timp. Această limitare poate fi dezactivată prin setare la valoarea zero.Reține că membrii cu drepturi de administrator nu sunt afectați de această valoare.';
$helptxt['error_log'] = '<strong>Jurnalul de erori</strong><br />Acest jurnal afișează toate erorile serioase întâlnite de utilizatorii forumului. Erorile sunt listate după dată, putând fi sortate apăsând săgeata neagră de lângă fiecare dată. În plus, poți filtra erorile apăsând imaginea de lângă fiecare statitstică. Astfel poți filtra, de exemplu, după utilizator. Când un filtru este activ, vor fi afișate doar rezultatele care se potrivesc cu criteriile de filtrare.';
$helptxt['theme_settings'] = '<strong>Setări Temă</strong><br /> Ecranul de setări vă permite să schimbaţi setările specifice unei teme. Aceste setări includ opţiuni cum ar fi directorul de teme şi informaţii despre URL, dar şi opţiuni care pot afecta layout-ul (aspectul) unei teme de pe forum. Cele mai multe teme vor avea o varietate de opţiuni configurabile de către utilizator, permiţându-vă să adaptaţi o temă pentru a se potrivi nevoilor individuale ale forumului dumneavoastră.';
$helptxt['smileys'] = '<strong>Centrul de emoticoane</strong><br /> Aici poţi adăuga şi elimina emoticoane şi seturi de emoticone. Reține că dacă un emoticon este într-un set, el trebuie să fie în toate seturile - altfel s-ar putea crea confuzie printre utilizatorii care folosesc seturi diferite.<br /><br />În plus, aici poţi edita iconiţele asociate mesajelor, dacă sunt activate din pagina de setări. ';

$helptxt['calendar'] = '<strong>Administrare Calendar</strong><br /> Aici puteţi modifica setările calendarului curent, precum şi adăuga sau şterge sărbătorile care apar în calendar.';
$helptxt['calendar_settings'] = 'Calendarul poate fi utilizat pentru afișarea zilelor de naștere sau a momentelor importante pentru comunitate.<br /><br />Reține că folosirea calendarului (postarea sau vizualizarea evenimentelor etc.) este controlată prin drepturile definite în pagina pentru drepturi.';
$helptxt['cal_days_for_index'] = 'Numărul maxim de zile în avans pentru indexul ariei:<br />Dacă este setat la 7, vor fi afișate evenimentele săptămânii viitoare';
$helptxt['cal_showevents'] = 'Activează evidențierea evenimentelor în Mini Calendare, în Calendarul principal, în ambele locuri sau dezactivează de tot evidențierea evenimentelor.';
$helptxt['cal_showholidays'] = 'Această setare îți permite să evidențiezi sărbătorile în Mini Calendare, în Calendarul principal, în ambele locuri sau să dezactivezi de tot evidențierea evenimentelor.';
$helptxt['cal_showbdays'] = 'Această setare îți permite să evidențiezi zilele de naștere în Mini Calendare, în Calendarul principal, în ambele locuri sau să dezactivezi de tot evidențierea zilelor de naștere.';
$helptxt['cal_export'] = 'Exportă un fișier text în format iCal pentru a putea fi importat în alte aplicații.';
$helptxt['cal_daysaslink'] = 'Afișează zilele ca link-uri la \'Postează eveniment\':<br />Va permite membrilor să posteze evenimente pentru acea zi când apasă pe acea dată.';
$helptxt['cal_allow_unlinked'] = 'Acceptă evenimente ne-legate de postări:<br />Permite membrilor să posteze evenimente fără a le impune să le lege de o postare în forum.';
$helptxt['cal_defaultboard'] = 'Ariea implicită pentru postare:<br />Introdu ariea implicită pentru publicarea evenimentelor.';
$helptxt['cal_showInTopic'] = 'Arată evenimentele legate la afișarea subiectului:<br />Bifează pentru a afișa un link către evenimente la începutul paginii, atunci când subiectul este citit.';
$helptxt['cal_allowspan'] = 'Acceptă evenimente care se desfășoară pe mai multe zile:<br />Bifează pentru a permite introducerea evenimentelor de lungă durată.';
$helptxt['cal_maxspan'] = 'Numărul maxim de zile pentru evenimente:<br />Introdu numărul maxim de zile pe care se poate întinde orice eveniment.';
$helptxt['cal_minyear'] = 'Anul minim:<br />Selectează &quot;primul&quot; an din lista calendarului.';
$helptxt['cal_maxyear'] = 'Anul maxim:<br />Alege &quot;ultimul&quot; an din lista calendarului';

$helptxt['serversettings'] = '<strong>Setările pentru server</strong><br />
⇥Aici poți configura setările de bază ale forumului. Această arie include baza de date și setările legate de URL precum și alte
⇥configurări importante, cum ar fi setările pentru email și pentru cache. Gândește-te bine de câte ori modifici aceste setări, căci o greșeală
⇥poate face forumul inaccesibil.';
$helptxt['manage_files'] = '
	<ul class="normallist">
		<li>
			<strong>Browse Files</strong><br />
			Browse through all the attachments, avatars and thumbnails stored by the system.<br /><br />
		</li><li>
			<strong>Attachment Settings</strong><br />
			Configure where attachments are stored and set restrictions on the types of attachments.<br /><br />
		</li><li>
			<strong>Avatar Settings</strong><br />
			Configure where avatars are stored and manage resizing of avatars.<br /><br />
		</li><li>
			<strong>File Maintenance</strong><br />
			Check and repair any error in the attachment directory and delete selected attachments.<br /><br />
		</li>
	</ul>';

$helptxt['topicSummaryPosts'] = 'Aceasta îţi permite să setezi numărul mesajelor precedente vizualizate în rezumatul topicului în ecranul de răspuns.';
$helptxt['enableAllMessages'] = 'Setează aceasta la numărul <em>maxim</em> de mesaje postate pe care le poate avea un subiect pentru a afişa link-ul toate.  Setarea acesteia mai jos de &quot;Maximul de mesaje de afişat în pagina unui subiect&quot; va însemna pur şi simplu ca nu va fi afişat niciodată, iar setarea ei prea sus ar putea încetini forumul dvs.';
$helptxt['allow_guestAccess'] = 'Debifarea acestei casete va opri vizitatorii să facă orice altceva decât acţiunile de bază - logare,  înregistrare, reamintire parolă etc. - pe forumul dvs.  Aceasta nu este acelaşi lucru cu a refuza accesul vizitatorilor la forumuri.';
$helptxt['userLanguage'] = 'Turning this option on will allow users to select which language file they use. It will not affect the default selection.';
$helptxt['trackStats'] = 'Stats:<br />This will allow users to see the latest posts and the most popular topics on your forum.
		It will also show several statistics like the most members online, new members and new topics.<hr />
		Page views:<br />Adds another column to the stats page with the number of page views on your forum.';
$helptxt['enable_unwatch'] = 'Enabling this option will allow users to selectively turn off new reply notifications for topics in which they had previously posted.';
$helptxt['titlesEnable'] = 'Switching Custom Titles on will allow members with the relevant permission to create a special title for themselves.
		This will be shown underneath the name.<br /><em>Example:</em><br />Jeff<br />Cool Guy';
$helptxt['onlineEnable'] = 'Aceasta va afişa o imagine pentru a indica dacă membrul este online sau offline';
$helptxt['todayMod'] = 'This will format &quot;Today&quot; or &quot;Yesterday&quot; in a variety of formats instead of the full date.<br /><br />
		<strong>Examples:</strong><br /><br />
		<dl class="settings">
			<dt>Disabled</dt>
			<dd>October 3, 2009 at 12:59:18 am</dd>
			<dt>Relative</dt>
			<dd>2 Hours Ago</dd>
			<dt>Only Today</dt>
			<dd>Today at 12:59:18 am</dd>
			<dt>Today &amp; Yesterday</dt>
			<dd>Yesterday at 09:36:55 pm</dd>
		</dl>';
$helptxt['disableCustomPerPage'] = 'Bifează această optiune pentru a opri utilizatorii sa personalizeze suma mesajelor şi subiectelor de discuţie de afişat per pagină în Message Index şi respectiv în pagina de afişare a Subiectelor de Discuţie.';
$helptxt['enablePreviousNext'] = 'Aceasta va arăta un link către topicul următor şi precedent.';
$helptxt['pollMode'] = 'This selects whether polls are enabled or not. If polls are disabled, the regular topic without their polls are shown.
<br /><br />To choose who can post polls, view polls, and similar, you can allow and disallow those permissions. Remember this if polls don\'t seem to be working.';
$helptxt['enableVBStyleLogin'] = 'Aceasta va afişa un login mai compact pentru vizitatori pe fiecare pagină a forumului.';
$helptxt['enableCompressedOutput'] = 'This option will compress output to lower bandwidth consumption, but it requires zlib to be installed.';
$helptxt['databaseSession_enable'] = 'Această opţiune face uz de baza de date pentru sesiunea de stocare - este cel mai bine pentru servere cu încărcare echilibrată, dar ajută cu toate problemele de expirare de timp şi poate face forumul mai rapid.';
$helptxt['databaseSession_loose'] = 'Această setare va diminua lăţimea de bandă consumată de forum, dar la folosirea butonului înapoi din browser pagina nu se va reîncărca - minusul acestei setări este că icoanele (noi) şi alte lucruri nu se vor reîmprospăta automat. (doar dacă se face clic pe link-ul paginii respective în loc de folosirea butonului înapoi.)';
$helptxt['databaseSession_lifetime'] = 'Acesta este numărul de secunde în care mai pot dura sesiunile după ce nu au mai fost accesate.  Dacă o sesiune nu este accesată prea mult timp, se spune că a &quot;expirat&quot;.  Orice număr mai mare decât 2400 este recomandat.';
$helptxt['cache_enable'] = 'ElkArte performs caching at a variety of levels. The higher the level of caching enabled the more CPU time will be spent retrieving cached information. If caching is available on your machine it is recommended that you try caching at level 1 first.';
$helptxt['cache_memcached'] = 'If you are using memcached you need to provide the server details. This should be entered as a comma separated list as shown in the example below:<br /><br/>&quot;server1,server2,server3:port,server4&quot;<br /><br />Note that if no port is specified the software will use port 11211, set this to 0 when using UNIX domain sockets.';
$helptxt['cache_cachedir'] = 'This setting is only for the filesystem based cache system. It specifies the path to the cache directory.  It is recommended that you place this in /tmp/ if you are going to use this, although it will work in any directory';
$helptxt['cache_uid'] = 'Some cache systems, for example Xcache, require a user ID and password to allow ElkArte access to clear the cache.';
$helptxt['cache_password'] = 'Some cache systems, for example Xcache, require a user ID and password to allow ElkArte access to clear the cache.';
$helptxt['enableErrorLogging'] = 'Aceasta va loga orice erori, cum ar fi o logare nereuşită, ca să poţi vedea ce a mers rău.';
$helptxt['enableErrorQueryLogging'] = 'Aceasta va include întreaga interogare care a fost trimisă către baza de date în jurnalul de erori. Este necesar ca logarea erorilor să fie activată. <br /><br /><strong> Notă: Acest lucru va afecta capacitatea de a filtra jurnalul de erori după mesajul de eroare.</strong> ';
$helptxt['allow_disableAnnounce'] = 'Aceasta le va permite utilizatorilor să opteze să nu primească notificări despre subiectele pe care tu le anunţi bifând căsuţa &quot;anunţă subiect&quot; la postare.';
$helptxt['disallow_sendBody'] = 'This option removes the possibility to receive the text of replies, posts and personal messages in notification emails.<br /><br />Often, members will reply to the notification email, which in most cases means the webmaster receives the reply.';
$helptxt['enable_contactform'] = 'This option adds a contact us button to the registration screen';
$helptxt['jquery_source'] = 'This will determine the source used to load the jQuery Library.  Auto will use the CDN first and if not available fall back to the local source.  Local will only use the local source, CDN will only load it from Google\'s Content Delivery Network';
$helptxt['jquery_default'] = 'If you want to use a version of jQuery different than the one that came with ElkArte, select this box and enter the version numer X.XX.X The local file must follow the naming conventing of jquery-X.XX.X.min.js for it to be loaded.';
$helptxt['jqueryui_default'] = 'If you want to use a version of jQueryUI different than the one that came with ElkArte, select this box and enter the version numer X.XX.X The local file must follow the naming conventing of jquery-ui-X.XX.X.min.js for it to be loaded.';
$helptxt['minify_css_js'] = 'This will combine multiple CSS or JavaScript files per page as needed.  It will also remove unnecessary whitespace and comments from the files to reduce their size.  The combined and minimized files are saved so further requests can instantly serve those files.<br />Note that the first time a compilation is needed/created, there will be a slight delay on that page load in order to create the file (this will also happen after the cache is cleared)';
$helptxt['compactTopicPagesEnable'] = 'This will show the supplied number of surrounding pages.<br /><em>Example:</em>
		&quot;3&quot; to display: 1 ... 4 [5] 6 ... 9 <br />
		&quot;5&quot; to display: 1 ... 3 4 [5] 6 7 ... 9';
$helptxt['timeLoadPageEnable'] = 'This will show the time in seconds taken to create that page at the bottom of the board.';
$helptxt['removeNestedQuotes'] = 'Aceasta va elimina citatele deja incluse intr-un mesaj postat la citarea mesajului în cauză prin intermediul unui link de citat. ';
$helptxt['search_dropdown'] = 'This will show a search selection dropdown next to the quick search box.  From this you can choose to search the current site, current board (if in a board), current topic (if in a topic) or search for members.';
$helptxt['max_image_width'] = 'This allows you to set a maximum size for posted pictures. Pictures smaller than the maximum will not be affected. This also determines how attached images are displayed when a thumbnail is clicked on.';
$helptxt['mail_type'] = 'This setting allows you to choose either PHP\'s default settings, or to override those settings with SMTP.  PHP doesn\'t support using authentication with SMTP (which many hosts require now) so if you want that you should select SMTP.  Please note that SMTP can be slower, and some servers will not take user names and passwords.<br /><br />You don\'t need to fill in the SMTP settings if this is set to PHP\'s default.';
$helptxt['mail_batch_size'] = 'This setting determines how many emails will be sent per page load and can not be set greater than the maximum allowed per minute.<br />Leaving this as 0, the system will automatically determine a batch size to evenly spread the load and fill the quota.<br />If you want to set your own values, setting this to the same value as your limit is a good option for low per minute limits, or 1/6 of the limit for higher per minute limits.';
$helptxt['smtp_client'] = 'Used to identify this client to the SMTP server.<br />The field should contain the fully-qualified domain name (FQDN) of the SMTP client. In situations in which the client system does not have a meaningful domain name you can instead use an address literal formatted as [ipv4] or [IPv6:ipv6 address].<br />If left blank the system will attempt to detect this value for you.';

$helptxt['attachmentEnable'] = 'Enable/Disable the attachment system or disable only new attachments leaving old one available.';
$helptxt['attachmentRecodeLineEndings'] = 'Enabling this will re-code line endings of text based files (txt, css, html, php, xml) based on your server (Windows, Mac or Unix).';
$helptxt['automanage_attachments'] = 'This will create a directory structure based on the selected option.  This can be post date (subdividing attachments by year, or by year and month or by year, month and day) or simply adding a new directory when the space limit is reached.  Each directory created will have the same file count and total size restrictions.  This will help prevent directories from reaching a file or size limit.';
$helptxt['use_sub-directories_for_attachments'] = 'This will create all new directories as sub-directories under the main attachment directory.';
$helptxt['attachmentDirSizeLimit'] = ' Set how large the attachment folder can be.';
$helptxt['attachmentDirFileLimit'] = 'Set the max. number of files an individual attachment directory may contain';
$helptxt['attachmentPostLimit'] = 'Specify how large a single post\'s total upload size can be (in KiB), this is the cumulative size of all attachments made in a post.';
$helptxt['attachmentSizeLimit'] = 'Specify the largest size a single attachment in a post can have.';
$helptxt['attachmentNumPerPostLimit'] = 'Select the number of attachments a member can add per post.';
$helptxt['attachmentCheckExtensions'] = 'Check this box to enable attachment filtering, which will only allow files to be uploaded with the file extensions that you have defined.';
$helptxt['attachmentExtensions'] = 'Specify what attachment types are allowed, for example: jpg,png,gif  Remember to be careful in what you allow as some file extensions can cause a security risk to your website.';
$helptxt['attachment_image_paranoid'] = 'Selecting this option will enable very strict security checks on image attachments. Warning! These extensive checks can fail on valid images too. It is strongly recommended to only use this option together with image re-encoding, in order to have ElkArte try to resample the images which fail the security checks: if successful, they will be sanitized and uploaded. Otherwise, if image re-encoding is not enabled, all attachments failing checks will be rejected.';
$helptxt['attachment_autorotate'] = 'Selecting this option will allow the system to detect rotated images, typical of phone cameras, and automatically adjust the orientation such that the image top is oriented up. Requires either ImageMagick or both GD and Exif modules to be available.';
$helptxt['attachmentShowImages'] = 'If the uploaded file is a picture, this will automatically display it underneath the post.';
$helptxt['attachmentThumbnails'] = 'Enable this to show post images as a smaller thumbnail image, which when selected will expand to the full sized image.';
$helptxt['attachment_thumb_png'] = 'When creating thumbnails to display under a post, this will only create them as png files.';
$helptxt['attachmentThumbWidth'] = 'Only used with the &quot;Resize images when showing under posts&quot; option, the maximum width to resize attachments down from.  They will be resized proportionally.';
$helptxt['attachmentThumbHeight'] = 'Only used with the &quot;Resize images when showing under posts&quot; option, the maximum height to resize attachments down from.  They will be resized proportionally.';
$helptxt['attachment_image_reencode'] = 'Selecting this option will enable trying to re-encode the uploaded image attachments. Image re-encoding offers better security. Note however that image re-encoding also renders all animated images static.<br />This feature is only possible if the GD module is installed on your server.';
$helptxt['attachment_thumb_memory'] = 'The larger the source image (size & width x height), the higher the memory requirements are for the system to successfully create a thumbnail image.<br />With this option checked, the system will estimate the required memory and will then request that amount.  If successful, only then will it attempt to create the thumbnail.<br />This will result in fewer white screen errors but may result in fewer thumbnails being created.  If you leave this option unchecked, the system will always try to create the thumbnail (with a fixed amount of memory).  This may result in more white screen errors.';
$helptxt['max_image_height'] = 'The maximum displayed height of an attached image.';
$helptxt['max_image_width'] = 'This allows you to set a maximum size for posted pictures. Pictures smaller than the maximum will not be affected. This also determines how attached images are displayed when a thumbnail is clicked on.';
$helptxt['attachmentUploadDir'] = 'Select where you want the files uploaded to be stored on your server. This can be located outside your public html directory for additional security.';
$helptxt['attachment_transfer_empty'] = 'Enabling this will move all the files from the source directory to the new location, otherwise only the maximum allowed number of files according to the per-directory setting will be moved.';
$helptxt['avatar_paranoid'] = 'Selecting this option will enable very strict security checks on avatars. Warning! These extensive checks can fail on valid images too. It is strongly recommended to only use this option together with avatars re-encoding, in order to have ElkArte try to resample the images which fail the security checks: if successful, they will be sanitized and uploaded. Otherwise, if re-encoding of avatars is not enabled, all avatars failing checks will be rejected.';
$helptxt['avatar_reencode'] = 'Selectarea acestei opțiuni va activa functia de recodare a avatarelor. Recodarea imaginilor oferă o mai bună securitate. Țineți cont de faptul că recodarea imaginilor le transformă pe acestea în imagini statice. <br /> Această funție este disponibilă doar dacă modulul GD este intalat pe server';
$helptxt['karmaMode'] = 'Karma este o caracteristică care arată popularitatea unui membru. Membrii, dacă li se permite, pot \'applaud\' sau \'smite\' alţi membri, acesta fiind modul în care popularitatea lor este calculată. Aveţi posibilitatea să modificaţi numărul de posturi necesare pentru a avea &quot;karma&quot;, timpul dintre smites sau aplauze şi dacă administratorii trebuie să aştepte în acest timp şi ei.<br /><br />Posibilitatea ca grupurile de membri să poată lovi sau nu pe alţii este controlată printr-o permisiune. Dacă aveţi probleme în a face această facilitate să funcţioneze pentru toată lumea verificaţi-vă din nou drepturile.';
$helptxt['localCookies'] = 'The system uses cookies to store login information on the client computer.
	Cookies can be stored globally (myserver.com) or locally (myserver.com/path/to/forum).<br />
	Check this option if you\'re experiencing problems with users getting logged out automatically.<hr />
	Globally stored cookies are less secure when used on a shared webserver (like Tripod).<hr />
	Local cookies don\'t work outside the forum directory so, if your forum is stored at www.myserver.com/forum, pages like www.myserver.com/index.php cannot access the account information.
	Especially when using SSI.php, global cookies are recommended.';
$helptxt['enableBBC'] = 'Selectarea acestei opţiuni le va permite utilizatorilor tăi să utilizeze Bulletin Board Code (BBC) in forum, permiţându-le utilizatorilor să-şi formateze mesajele cu imagini, tipuri de formatare şi multe altele.';
$helptxt['time_offset'] = 'Nu toţi administratorii de forum vor ca forumul lor să folosească acelaşi timp ca al zonei serverului pe care sunt găzduiţi. Foloseşte această opţiune pentru a specifica o diferenţă de timp (în ore) de la care forumul ar trebui sa opereze faţă de timpul serverului. Valorile negative şi zecimale sunt permise.';
$helptxt['default_timezone'] = 'The server timezone tells PHP where your server is located. You should ensure this is set correctly, preferably to the country/city in which the server is located. You can find out more information on the <a href="http://www.php.net/manual/en/timezones.php" target="_blank">PHP Site</a>.';
$helptxt['spamWaitTime'] = 'Aici puteţi selecta timpul care trebuie să treacă între postări. Acest lucru poate fi folosit pentru a opri oamenii de la "spam" pe forumul dvs prin limitarea a cât de des se poate posta.';

$helptxt['enablePostHTML'] = 'This will allow the posting of some basic HTML tags:
	<ul class="normallist enablePostHTML">
		<li>&lt;b&gt;, &lt;u&gt;, &lt;i&gt;, &lt;s&gt;, &lt;em&gt;, &lt;ins&gt;, &lt;del&gt;</li>
		<li>&lt;a href=&quot;&quot;&gt;</li>
		<li>&lt;img src=&quot;&quot; alt=&quot;&quot; /&gt;</li>
		<li>&lt;br /&gt;, &lt;hr /&gt;</li>
		<li>&lt;pre&gt;, &lt;blockquote&gt;</li>
	</ul>';

// Initial theme settings - Manage and Install
$helptxt['themes'] = 'Here you can select whether the default theme can be chosen, what theme guests will use, as well as other options. Click on a theme to the right to change the settings for it.';
$helptxt['theme_install'] = 'This section permits you to install new themes. You do this by uploading an archived file for the theme from your personal computer, installing from a theme directory on the host server or by copying the default theme and renaming that copied file.<br /><br />Please remember this: the archived file or directory must have a <span class="alert">theme_info.xml</span> definition file as a part of the archive or the directory.';
$helptxt['theme_forum_theme'] = 'Changing the overall forum default does not affect members that have selected another available theme. You must also \'Reset\' all members to force them to the new forum default. You can also set a forum default theme that is seen by guests and then reset members to a different theme. <br /><br />Remember that when permitted to select their own themes, members can overide the theme set by you.';

// Theme Management and Options - Theme settings
$helptxt['themeadmin_list_reset'] = 'On rare occasions the path to the theme will be lost and your forum will not display properly. This may be due to a mistake by an Admin, database errors, failed software updates, mod installations or some other event. Resetting the themes URLs and directories will usually fix this problem.';
$helptxt['themeadmin_delete_help'] = 'The default theme cannot be deleted as doing so would break your forum and would break other themes. However, you can delete any theme that has the red \'X\' next to it by clicking on that \'X\'. <br /><br /> Remember this: Deleting a theme does not remove it from the server, it only removes the themes availability to be used on the forum. You will need to FTP into your server or use the host provided panel to remove the custom theme from the server. Do not ever delete the theme named \'default\'.';

$helptxt['enableVideoEmbeding'] = 'This allows automatic conversion of standard URLs into an embedded video when the post is viewed.  Currently only supports YouTube, Vimeo and Dailymotion video links';
$helptxt['enableCodePrettify'] = 'This will load the Prettify script which will color highlight code used in code tags.  It adds styles to code snippets so that tokens stand out and your users can more easily read the code.';
// @todo Add more information about how to use them here.
$helptxt['xmlnews_enable'] = 'Allows people to link to <a href="%1$s?action=.xml;sa=news" target="_blank" class="new_win">Recent news</a>
	and similar data.  It is also recommended that you limit the number of recent posts/news because, when RSS data
	is displayed in some clients, like Trillian, it is expected to be truncated.';
$helptxt['hotTopicPosts'] = 'Change the number of posts for a topic to reach the state of a &quot;hot&quot; or
	&quot;very hot&quot; topic.  Select the likes option to base this state on the number of likes instead of the number of posts';
$helptxt['globalCookies'] = 'Makes login cookies available across subdomains.  For example, if...<br />
	Your site is at http://www.myserver.com/,<br />
	And your forum is at http://forum.myserver.com/,<br />
	Using this option will allow you to access the forum\'s cookie on your site.  Do not enable this if there are other subdomains (like hacker.elkarte.net) not controlled by you.<br />
	This option does not function when local cookies are enabled.';
$helptxt['globalCookiesDomain'] = 'Define the main domain to be used when login cookies are available across subdomains';
$helptxt['httponlyCookies'] = 'With this setting on, cookies will not be accessible by scripting languages, such as JavaScript. This setting can help to reduce identity theft through XSS attacks. This may cause issues with some third party scripts but is recommended to be on when possible.';
$helptxt['secureCookies'] = 'Activarea acestei opţiuni va forţa cookie-urile create pentru utilizatorii forumului dumneavoastră să fie marcate ca fiind sigure. Activaţi această opţiune doar în cazul în care utilizaţi HTTPS pe tot site-ul dumneavoastră, întrucât va distruge manipularea cookie-urilor altfel! ';
$helptxt['admin_session_lifetime'] = 'Această valoare determină cât timp poate rămâne activă o sesiune de administrare. La expirarea acestei perioade, sesiunea va fi închisă iar continuarea activităților de administrare va necesita reintroducerea credențialelor (parolei) de administrator. Valoarea minimă e de 5 minute iar cea maximă de 14400 minute (adică o zi). Din motive de securitate, este recomandată o valoarea mai mică de 60 de minute.';
$helptxt['auto_admin_session'] = 'Opțiunea controlează dacă sesiunea de administrare este activată automat după autentificare sau nu.';
$helptxt['securityDisable'] = 'Opțiunea <em>dezactivează</em> solicitarea suplimentară a parolei la accesarea zonei de administrare. Nerecomandat!';
$helptxt['securityDisable_why'] = 'Introdu parola ta actuală, pe care o foloseşti pentru autentificare.<br /><br />Introducerea parolei este necesară pentru a asigura forumul că<br />- accesarea zonei de administrare este făcută cu intenție și nu din greșeală<br />- cel care intră în zona de administrare ești chiar <strong>tu</strong> și nu altcineva';
$helptxt['securityDisable_moderate'] = 'Opțiunea <em>dezactivează</em> solicitarea suplimentară a parolei la accesarea zonei de moderare. Nerecomandat!';
$helptxt['securityDisable_moderate_why'] = 'TIntrodu parola ta actuală, pe care o foloseşti pentru autentificare.<br /><br />Introducerea parolei este necesară pentru a asigura forumul că<br />- accesarea zonei de moderare este făcută cu intenție și nu din greșeală<br />- cel care intră în zona de moderare ești chiar <strong>tu</strong> și nu altcineva';
$helptxt['enableOTP'] = 'Enabling this feature allows another layer of security for a member\'s account. Two-factor authentication, or 2FA, is a way of logging into websites that requires more than just a password. Using a password to log into a website is susceptible to security threats, because it represents a single piece of information a malicious person needs to acquire. The added security that 2FA provides is requiring additional information to sign in.<br /><br />A Time-based One-Time Password (TOTP) application such as Google Authenticator or Authy automatically generates an authentication code that changes after a certain period of time.';
$helptxt['emailmembers'] = 'În acest mesaj poți folosi câteva &quot;variabile&quot;:<br />
	{$board_url} - URL-ul forumului.<br />
	{$current_time} - Ora curentă.<br />
	{$member.email} - Email-ul membrului curent.<br />
	{$member.link} - Profilul membrului curent.<br />
	{$member.id} - ID-ul membrului curent.<br />
	{$member.name} - Numele membrului curent.  (for personalization.)<br />
	{$latest_member.link} - Profilul celui mai nou membru.<br />
	{$latest_member.id} - ID-ul celui mai nou membru.<br />
	{$latest_member.name} - Numele celui mai nou membru.';
$helptxt['attachmentEncryptFilenames'] = 'Criptatea NUMELOR fișierelor atașate îți permite să ai mai multe atașamente cu același nume de fișier și în același timp întărește securitatea. Pe de altă parte, poate îngreuna refacerea bazei de date în caz de probleme.';

$helptxt['failed_login_threshold'] = 'Setaţi numărul de încercări de autentificare eşuate înainte de direcţionarea utilizatorului către ecranul de reamintire a parolei.';
$helptxt['loginHistoryDays'] = 'Numărul de zile pentru păstrarea istoricului autentificărilor în cadrul istoricului profilului de utilizator. Valoarea implicită e de 30 de zile.';
$helptxt['oldTopicDays'] = 'Dacă această opţiune este activată, utilizatorul va vedea o avertizare atunci când încearcă să răspundă la un subiect care nu a primit niciun răspuns nou în intervalul (exprimat în zile) prevăzut de această setare. Valoarea zero dezactivează opțiunea (avertizarea nu va fi afișată).';
$helptxt['edit_wait_time'] = 'Intervalul de la momentul postării (în secunde) în care un mesaj poate fi editat fără ca data ultimei editări să fie jurnalizată.';
$helptxt['edit_disable_time'] = 'Numărul de minute de la momentul postării după care utilizatorii nu-și mai pot edita mesajele. Valoarea zero dezactivează opțiunea (mesajele pot fi editate oricând). <br /><br /><em>Reține: Această opțiune nu afectează utilizatorii care au permisiunea de a edita mesajele altor membri.</em>';
$helptxt['preview_characters'] = 'Această opțiune definește numărul de caractere din primul sau din ultimul mesaj al unui subiect, ce vor fi afișate în caseta de previzualizare a subiectului. <strong>Reține</strong> că această opțiune pune informația la dispoziția temei dar pentru a avea efect, tema trebuie să suporte funcția &quot;Previzualizează mesajele în indexul mesajelor&quot;';
$helptxt['posts_require_captcha'] = 'Această setare va forţa utilizatorii să treacă prin verificarea antispam de fiecare dată când postează într-o arie. Numai utilizatorii cu numărul total de mesaje postate MAI MIC decât numărul setat vor fi nevoiţi să introducă codul - acest lucru ar trebui să ajute la combaterea scripturilor de spam automate';
$helptxt['enableSpellChecking'] = 'Enable spell checking. You MUST have the pspell library installed on your server and your PHP configuration set up to use the pspell library. Your server ' . (function_exists('pspell_new') ? 'DOES' : 'DOES NOT') . ' appear to have this set up.';
$helptxt['lastActive'] = 'Definește numărul maxim de minute de la ultima activitate pe forum pentru care un utilizator este considerat a fi încă "on-line" și este afișat în indexul ariilor ca fiind activ. Valoarea implicită e de 15 minute';

$helptxt['customoptions'] = 'Această arie defineşte opţiunile pe care un utilizator le poate alege dintr-o listă derulantă verticală (drop down). Există câteva puncte cheie de reţinut în această arie:
<ul class="normallist">
	<li>
		<strong>Opţiunea implicită:</strong>
			Pentru casete cu opțiuni de tip &quot;butoane radio (radio buttons)&quot;, determină opțiunea care va fi preselectată implicit.</li>
	<li>
		<strong>Opţiuni de ștergere:</strong>
			Pentru a elimina o opţiune, pur şi simplu golește caseta de text pentru opţiunea respectivă - acea opțiune va fi eliminată din lista disponibilă utilizatorilor pentru selecție.</li>
	<li>
		<strong>Opţiuni de ordonare:</strong>
			Poţi ordona opţiunile prin mutarea textului aferent între rubrici. IMPORTANT: Ai grijă ca textul conținut să <strong>NU</strong> fie modificat, altfel datele utilizatorului vor fi pierdute.</li>
</ul>';

$helptxt['autoOptDatabase'] = 'Această opţiune optimizează baza de date la intervalul de zile setat. Valoarea 1 determină o optimizare zilnică. Poţi specifica un număr maxim de utilizatori online, astfel încât optimizarea să nu supraîncarce serverul și să nu derajeze prea mulți utilizatori.';
$helptxt['autoFixDatabase'] = 'Opțiunea repară automat, din mers, tabelele defecte ale bazei de date şi va relua activitatea ca şi cum nimic nu s-a întâmplat. Acest lucru poate fi util pentru că singura cale de stabilizare a forumului este de a REPARA tabela, prevenind situații în care forumul să fie căzut până la observarea problemei. Când au loc operații de acest gen vei fi înștiințat pe mail, pentru a putea lua măsuri suplimentare!';

$helptxt['enableParticipation'] = 'Această opțiune determină afișarea pentru fiecare utilizator a unor mici pictograme atașate tuturor subiectelor în care el însuși a postat.';
$helptxt['enableFollowup'] = 'Opțiunea permite utilizatorilor să deschidă subiecte noi prin citarea unor mesaje esxistente.';

$helptxt['db_persist'] = 'Menține deschisă conexiunea cu baza de date, pentru creşterea performanţei. Dacă nu dispui de un server propriu, activarea acestei opțiuni îți poate crea probleme cu administratorul hostului...';
$helptxt['ssi_db_user'] = 'Opţiunea de a utiliza un alt nume de utilizator al bazei de date (și altă parolă...) atunci când utilizaţi SSI.php.';

$helptxt['queryless_urls'] = 'Opțiunea modifică puțin formatul URL-urilor pentru a le face mai atrăgătoare pentru motoarele de căutare. Vor apărea în genul index.php/topic,1.0.html.';
$helptxt['countChildPosts'] = 'Opțiunea permite includerea în totalul postărilor afișate în indexul ariilor a numărului postărilor tuturor sub-ariilor acestora.<br /><br />Opțiunea încetinește întrucâtva forumul dar face ca ariile fără subiecte directe (doar cu sub-arii) să nu fie afișate ca fiind goale (cu zero postări).';
$helptxt['allow_ignore_boards'] = 'Opţiunea permite utilizatorilor să selecteze ariile pe care doresc să le ignore.';
$helptxt['deny_boards_access'] = 'Opțiunea îți permite să interzici accesul la anumite arii pe baza drepturilor de acces ale grupurilor de membri.';

$helptxt['who_enabled'] = 'Opţiunea îți permite să activezi sau să dezactivezi posibilitatea utilizatorilor de a vedea cine accesează forumul şi ce anume face.';

$helptxt['recycle_enable'] = '&quot;Reciclează&quot; subiectele şi mesajele şterse în aria specificată.';

$helptxt['enableReportPM'] = 'Opţiunea permite utilizatorilor să raporteze echipei de administrare mesajele personale pe care le primesc. Este utilă în urmărirea situațiilor de abuz prin sistemul de mesaje personale.';
$helptxt['max_pm_recipients'] = 'Opțiunea îți permite să setezi numărul maxim permis de destinatari în mesajele personale trimise de membrii forumului. Este utilă pentru combaterea spam-ului prin MP. Reţine că utilizatorii cu drepturi de a trimite buletine de ştiri sunt exceptaţi de la această restricţie. Valoarea zero înseamnă fără limită.';
$helptxt['pm_posts_verification'] = 'Opțiunea forţează utilizatorii să introducă un cod de verificare afişat într-o imagine de fiecare dată când trimit un mesaj personal. Numai utilizatorii cu un număr de mesaje postate SUB  numărul setat vor fi nevoiţi să introducă codul - acest lucru ar trebui să ajute la combaterea scripturilor automate de spam.';
$helptxt['pm_posts_per_hour'] = 'Setarea limitează numărul de mesaje personale care pot fi trimise de către un anume utilizator în decurs de o oră. Setarea nu îi afectează pe administratori şi moderatori.';

$helptxt['default_personal_text'] = 'Definește textul implicit setat ca &quot;text personal&quot; pentru utilizatorii noi. Nu se aplică dacă opțiunea de a avea un text personal este dezactivată sau dacă utilizatorii își pot alege propriul text personal la înregistrare.';

$helptxt['modlog_enabled'] = 'Jurnalizează toate acţiunile de moderare.';

$helptxt['registration_method'] = 'Determină metoda folosită pentru înregistrarea (înscrierea) noilor membri în forum. Opțiunile disponibile sunt:<br /><br />
	<ul class="normallist">
		<li>
			<strong>Înregistrarea e dezactivată</strong><br />
				Dezactivează întregul proces de înregistrare (înscriere), ceea ce înseamnă că nici unutilizator NOU nu se poate alătura forumului.<br />
		</li><li>
			<strong>Înregistrare imediată</strong><br />
				Noii membri se pot înregistra fără alte măsuri suplimentare de verificare și pot posta în forum imediat după înregistrare.<br />
		</li><li>
			<strong>Activare prin email</strong><br />
				Membrilor care se înregistrează li se va trimite un email pe  adresa specificată în formularul de înregistrare. Email-ul va conține un link pe care vor trebui să-l acceseze pentru a finaliza activarea contului și a deveni membri cu drepturi depline.<br />
		</li><li>
			<strong>Aprobare de la administrator</strong><br />
				Conturile membrilor care se înregistrează vor trebui aprobate manual de către un administrator pentru a finaliza activarea contului și a deveni membri cu drepturi depline.
		</li>
	</ul>';
$helptxt['register_openid'] = '<strong>Autentificare cu OpenID</strong><br />
	OpenID permite folosirea acelorași detalii de autentificare pe mai multe site-uri, pentru a simplifica experiența on-line. Pentru a folosi OpenID, mai întâi ai nevoie de un cont OpenID. Lista providerilor de servicii OpenID se află pe <a href="http://openid.net/" target="_blank">site-ul oficial OpenID</a>.<br /><br />
	După obținerea contului OpenID, se introduce URL-ul propriu de identificare în caseta OpenID și se trimite formularul. Se va deschide site-ul providerului (pentru verificarea identității) după care vei fi direcționat automat înapoi în forum.<br /><br />
	La prima accesare a acestui forum ți se vor cere câteva detalii pentru a fi recunoscut, după care te poți autentifica cu drepturi depline și îți poți personaliza profilul, folosind doar identitatea OpenID.<br /><br />
	Pentru mai multe detalii, accesează <a href="http://openid.net/" target="_blank">site-ul oficial OpenID</a>';

$helptxt['send_validation_onChange'] = 'Dacă această opțiune este activă, membrii care își schimbă adresa de email vor trebui să-și reactiveze contul, prin intermediul unui email trimis automat de forum la noua adresă.';
$helptxt['send_welcomeEmail'] = 'Când această opţiune este activă toți membrii noi vor primi un e-mail de bun-venit.';
$helptxt['password_strength'] = 'Opțiunea definește tăria necesară pentru parolele alese de utilizatori. Cu cât o parolă e mai puternică, cu atât mai dificilă va fi compromiterea contului respectiv.
	Variantele posibile sunt:
	<ul class="normallist">
		<li><strong>Slabă:</strong> Parola trebuie să aibă minim patru caractere.</li>
		<li><strong>Medie:</strong> Parola trebuie să aibă minim opt caractere și nu poate fi conținută în numele utilizatorului sau în adresa de email.</li>
		<li><strong>Tare:</strong> Aceleași cerințe ca la Medie; suplimentar, trebuie să conțină o combinație de litere mici și litere mari precum și cel puțin o cifră.</li>
	</ul>';
$helptxt['enable_password_conversion'] = 'Dacă această opțiune e activă, ElkArte va încerca să detecteze parolele stocate în alte formate și să le convertească pentru a putea fi folosite aici. În mod uzual, opțiunea e utilă pentru forumurile convertite la ElkArte din alte softuri dar poate avea și alte întrebuințări. Dezactivarea opțiunii împiedică utilizatorii să se autentifice cu vechile parole după conversie, forțându-i să treacă printr-un proces de resetare a parolei.';

$helptxt['coppaAge'] = 'Valoarea specificată în această casetă va stabili vârsta minimă pe care membrii noi trebuie să o aibă pentru a li se acorda acces imediat la forum.
	La înregistrare li se va solicita să confirme dacă sunt peste această vârstă şi, dacă nu, cererea lor va fi fie respinsă, fie suspendată în aşteapteptarea aprobării părintelui - în funcție de tipul de restricţie ales.
	Dacă se alege valoarea 0, toate setările legate de restricţia de vârstă vor fi ignorate.';
$helptxt['coppaType'] = 'Dacă sunt activate restricţiile de vârstă, atunci această setare va defini ce se întâmplă atunci când un utilizator sub vârsta minimă încearcă să se înregistreze pe forum. Există două opţiuni:
<ul class="normallist">
 <li><strong>Respinge înregistrarea:</strong><br />
	Înregistrarea oricărui membru nou sub vârsta minimă va fi respinsă imediat.<br /></li>
 <li><strong>Solicită aprobarea părintelui/tutorelui</strong><br />
	Orice membru nou care încearcă să se înregistreze şi care este sub vârsta minimă permisă va avea contul pus în coada de aşteaptare a aprobării. I se va prezenta un formular prin intermediul căruia părinţii săi trebuie să îi acorde permisiunea de a deveni membru al forumului. Lor li se vor oferi, de asemenea, detaliile de contact ale forumului (cele introduse în pagina de setări), astfel încât să poată trimite formularul către administrator prin e-mail sau fax.</li>
</ul>';
$helptxt['coppaPost'] = 'Completarea casetelor cu date de contact este obligatorie, pentru ca formularele ce confirmă permisiunea ca minorii să se înscrie pe forum să poată fi expediate administratorului de către părinți. Aceste detalii vor fi afișate tuturor minorilor, fiind necesare pentru exprimarea acordului părintelui / tutorelui legal. Introdu cel puțin o adresă poștală sau un număr de fax.';

$helptxt['allow_hideOnline'] = 'Această opțiune permite membrilor să ascundă prezența în forum față de ceilalți utilizatori (cu excepția administratorilor). Dacă opțiunea nu e activă, doar moderatorii își pot ascunde prezența pe forum. Reține că dezactivarea acestei opțiuni nu modifică statusul curent al nici unui membru - doar previne ascunderea stării on-line în sesiunile viitoare.';

$helptxt['latest_support'] = 'Acest panou îți prezintă câteva din cele mai comune probleme și întrebări legate de configurația serverului tău. Nu e cazul să te îngrijorezi, nici o informație nu este stocată nicăieri.<br /><br /> Dacă textul afișat rămâne &quot;Retrieving support information...&quot;, probabil computerul tău nu se poate conecta la website.';
$helptxt['latest_packages'] = 'Here you can see some of the most popular and some random packages, with quick and easy installations.<br /><br />If this section doesn\'t show up, your computer probably cannot connect to <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.';
$helptxt['latest_themes'] = 'This area shows a few of the latest and most popular themes from <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.  It may not show up properly if your computer can\'t find <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>, though.';

$helptxt['secret_why_blank'] = 'Pentru siguranță, atât parola cât și răspunsul la întrebarea secretă sunt criptate, așa că ElkArte nu-ți va putea spune niciodată, nici ție și nici altcuiva, care sunt acestea.';
$helptxt['moderator_why_missing'] = 'Din moment ce activitatea de moderare se desfășoară la nivel de arie, alocarea statutului de moderator pentru utilizatori se face din <a href="%1$s?action=admin;area=manageboards" target="_blank" class="new_win">interfața de administrare</a> a fiecărei arii.';

$helptxt['permissions'] = 'Drepturile înseamnă modul în care permiţi sau interzici grupurilor să facă anumite lucruri.<br /><br />Poţi modifica simultan mai multe arii folosind bifele sau poți vedea drepturile alocate unui anumit grup apăsând "Modifică" ';
$helptxt['permissions_board'] = 'Dacă o arie este setată la nivel "Global", aceasta înseamnă că aria nu va avea nici o permisiune specială. "Local"  înseamnă că ea va avea propriile drepturi - separate de cele de la nivel global. Acest lucru vă permite să aveţi o arie care are mai multe sau mai puţine drepturi decât alta, fără să fie nevoie să le setaţi pentru fiecare arie în parte.';
$helptxt['permissions_quickgroups'] = 'Această opțiune îți permite să folosești seturi de drepturi &quot;predefinite&quot;. \'Standard\' înseamnă \'nimic special\', \'Restrictiv\' înseamnă \'ca un vizitator\', \'Moderator\' înseamnă \'ca un moderator\', şi în cele din urmă \'Mentenanţă\' înseamnă drepturi foarte aproape de cele ale unui administrator.';
$helptxt['permission_enable_deny'] = 'Negarea drepturilor pot fi utilă atunci când vrei să interzici explicit unele drepturi anumitor membri. Puteţi adăuga un membergroup cu permisiunea de \'deny\' pentru membrii cărora doriţi să le negaţi o permisiune. <br /><br />Folosiţi cu atenţie, o permisiune refuzată va rămâne refuzată indiferent de grupurile de membri în care se află acel membru. ';
$helptxt['permission_enable_postgroups'] = 'Activarea drepturilor pentru grupurile bazate pe numărul de mesaje postate vă va permite să atribuiţi drepturi membrilor care au postat un anumit număr de mesaje. Drepturile pentru grupurile bazate pe numărul de mesaje postate sunt <em>adăugate</em> la drepturile grupurilor obişnuite de membri.';
$helptxt['membergroup_guests'] = 'În grupul de membri Vizitatori sunt toţi utilizatorii care nu sunt autentificaţi.';
$helptxt['membergroup_regular_members'] = 'Membrii Obişnuiţi sunt toţi membri care sunt autentificaţi, dar care nu au niciun membergroup primar asignat.';
$helptxt['membergroup_administrator'] = 'The administrator can, per definition, do anything and see any board. Thus, there are no permission settings for the administrator.';
$helptxt['membergroup_moderator'] = 'The Moderator member group is a special member group. Permissions and settings assigned to this group apply to moderators but only <em>on the boards they moderate</em>. Outside these boards they\'re just like any other member.';
$helptxt['membergroups'] = 'There are two types of groups that your members can be part of. These are:
	<ul class="normallist">
		<li><strong>Regular Groups:</strong> A regular group is a group to which members are not automatically put into. To assign a member to be in a group simply go to their profile and click &quot;Account Settings&quot;. From here you can assign them any number of regular groups to which they will be part.</li>
		<li><strong>Post Groups:</strong> Unlike regular groups post based groups cannot be assigned. Instead, members are automatically assigned to a post based group when they reach the minimum number of posts required to be in that group.</li>
	</ul>';

$helptxt['calendar_how_edit'] = 'Aveţi posibilitatea să editaţi aceste evenimente făcând clic pe asteriscul roşu (*) de lângă numele lor.';

$helptxt['maintenance_backup'] = 'Această zonă vă permite să salvaţi o copie a tuturor mesajelor postate, setărilor, membrilor, precum şi alte informaţii din forumul dvs într-un fişier foarte mare.<br /><br />Este recomandat să faceţi asta de multe ori, poate săptămânal, pentru siguranţă şi securitate.';
$helptxt['maintenance_rot'] = 'Acest lucru vă permite să eliminaţi <strong>complet</strong> şi <strong>irevocabil</strong> subiectele vechi. Este recomandat să încercaţi să faceţi o copie de rezervă mai întâi, pentru eventualitatea în care aţi elimina ceva ce nu aţi vrut să eliminaţi.<br /><br />Folosiţi această opţiune cu grijă.';
$helptxt['maintenance_members'] = 'Acest lucru vă permite să eliminaţi <strong>complet</strong> şi <strong>irevocabil</strong> conturi de membru de pe forumul dumneavoastră. Este <strong>foarte<strong> recomandat să încercaţi să faceţi o copie de siguranţă mai întâi, în caz că veţi şterge ceva ce nu aţi vrut să ştergeţi.<br /><br />Folosiţi această opţiune cu grijă.';

$helptxt['avatar_default'] = 'With this option enabled, a default avatar is shown for all users without their own avatar. The file named \'default_avatar.png\' is located in the images folder inside the themes directory.';
$helptxt['avatar_server_stored'] = 'This allows your members to pick an avatar from a number of avatars stored on your server themselves.  They are, generally, in the same place as the forum under the avatars directory.<br />As a tip, if you create directories in that folder, you can make &quot;categories&quot; of avatars.';
$helptxt['avatar_external'] = 'Cu această opţiune activată, membrii dvs. pot tasta un URL către propriul lor avatar. Dezavantajul este că, în unele cazuri, ei pot folosi avatare care sunt excesiv de mari sau imagini pe care nu le doriţi pe forumul dumneavoastră.';
$helptxt['avatar_download_external'] = 'Cu această opţiune activată, URL-ul dat de utilizator este accesat pentru a descărca avatarul de la acea locaţie. În caz de succes, avatarul va fi tratat ca avatar ce poate fi încărcat.';
$helptxt['avatar_upload'] = 'Această opţiune este asemănătoare cu &quot;Permite membrilor să selecteze un avatar extern&quot;, cu diferenţa că aveţi un control mai bun asupra avatarelor, un timp mai bun de redimensionare şi membrii dumneavoastră nu trebuie să aibă un alt loc unde să-şi pună avatarele.<br /><br /> Cu toate acestea dezavantajul este ca vă poate ocupa mult spaţiu pe server.';
$helptxt['avatar_resize_options'] = 'This set of options apply to any avatar loaded to the server by users, either uploaded or retrieved from an external URL.';
$helptxt['avatar_download_png'] = 'Fişierele PNG sunt mai mari, dar oferă o calitate mai bună de compresie. Dacă acest lucru este nebifat, JPEG va fi folosit în loc - care este de multe ori mai mic, dar de asemenea, de o calitate mai mică sau neclară.';
$helptxt['gravatar'] = 'Gravatar (globally recognized avatar) is a service for providing globally unique avatars. For more details please visit the Gravatar <a href="http://www.gravatar.com" target="_blank"><strong>website</strong>.</a>';
$helptxt['gravatar_rating'] = 'Gravatar allows users to self-rate their images so that they can indicate if an image is appropriate for a certain audience. By default, only \'G\' rated images are displayed unless you indicate that you would like to see higher ratings. <br /><br /><ul><li><strong>g:</strong> suitable for display on all websites with any audience type.</li><li><strong>pg:</strong> may contain rude gestures, provocatively dressed individuals, the lesser swear words, or mild violence.</li><li><strong>r:</strong> may contain such things as harsh profanity, intense violence, nudity, or hard drug use.</li><li><strong>x:</strong> may contain hardcore sexual imagery or extremely disturbing violence.</li></ul>';
$helptxt['custom_avatar_enabled'] = 'Se recomandă activarea acestei opțiuni pentru creșterea perfomanțelor, deoarece reduce atât încărcarea procesorului cât și pe cea a bazei de date la afișarea paginilor ce conți avataruri.<br />Trebuie să introduci atât numele unui director accesibil public pentru salvarea avatarurilor cât și URL-ul accesibil public pentru acel director. De exemplu, directorul /home/forumultău/public_html/DirectoruPentru AvataruriNoi și URL-ul htp://www.forumultău.com/DirectoruPentru AvataruriNoi';
$helptxt['disableHostnameLookup'] = 'Aceasta dezactivează hostname lookups care, la unele servere sunt foarte lente. Reţine că acest lucru va face banarea mai puţin eficientă.';

$helptxt['search_weight_commonheader'] = 'Weight factors are used to determine the relevancy of a search result. Change these weight factors to match the things that are specifically important for your forum. For instance, a forum of a news site might want a relatively high value for \'age of last matching message\'. All values are relative in relation to each other and should be positive integers.';
$helptxt['search_weight_frequency'] = 'This factor counts the amount of matching messages and divides them by the total number of messages within a topic.';
$helptxt['search_weight_age'] = 'This factor rates the age of the last matching message within a topic. The more recent this message is, the higher the score.';
$helptxt['search_weight_length'] = 'This factor is based on the topic size. The more messages are within the topic, the higher the score.';
$helptxt['search_weight_subject'] = 'This factor looks whether a search term can be found within the subject of a topic.';
$helptxt['search_weight_first_message'] = 'This factor looks whether a match can be found in the first message of a topic.';
$helptxt['search_weight_sticky'] = 'This factor looks whether a topic is pinned and increases the relevancy score if it is.';
$helptxt['search_weight_likes'] = 'This factor looks whether a topic has likes and increases the relevancy score based on the number.';
$helptxt['search'] = 'Ajustaţi toate setările pentru funcţia de căutare aici.';
$helptxt['search_why_use_index'] = 'A search index can greatly improve the performance of searches on your forum. Especially when the number of messages on a forum grows bigger, searching without an index can take a long time and increase the pressure on your database. If your forum is bigger than 50,000 messages, you should consider creating a search index to assure peak performance of your forum.<br /><br />Note that a search index can take up quite some space. A fulltext index is a built-in index of the database. It\'s relatively compact (approximately the same size as the message table), but a lot of common words aren\'t indexed and it can, in some wildcard queries, turn out to be slow. The custom index is bigger (depending on your configuration it can be up to 3 times the size of the messages table) but its performance is often better than fulltext and indexes most words.';

$helptxt['see_admin_ip'] = 'Adresele de IP sunt prezentate administratorilor şi moderatorilor pentru a facilita moderarea şi  	
pentru a face mai uşor urmărirea oamenilor ce nu au intenţii bune..  Amintiţi-vă că adresele IP nu pot fi întotdeauna de identificare şi adresele IP ale majorităţii oamenilor se schimbă periodic..<br /><br />Membrilor le este de asemenea permis să-şi vizualizeze propriile IP-uri.';
$helptxt['see_member_ip'] = 'Adresa ta de IP îți este afişată numai ție şi moderatorilor. Reține că această informaţie nu este folosită pentru identificare şi că de cele mai multe IP-urile se schimbă periodic.<br /><br />Nu poţi vedea adresele IP ale altor membri şi ei nu o pot vedea pe a ta.';
$helptxt['whytwoip'] = 'Various methods are used to detect user IP addresses. Usually these two methods result in the same address but in some cases more than one address may be detected. In this case both addresses will be logged, and both will be used for ban checks (etc). You can click on either address to track that IP and ban if necessary.';

$helptxt['ban_cannot_post'] = 'Restricţia \'nu poate posta\' (\'cannot post\') face forumul read-only (poate fi doar citit) pentru utilizatorii cu interdicţii (banaţi). Utilizatorul nu poate crea subiecte noi sau răspunde la cele existente, nu poate trimite mesaje personale sau vota în sondaje. Utilizatorul banat poate citi totuşi mesajele personale sau subiectele.<br /><br />Un mesaj de avertizare este prezentat utilizatorilor care sunt banaţi în acest fel.';

$helptxt['posts_and_topics'] = '
	<ul class="normallist">
		<li>
			<strong>Post Settings</strong><br />
			Modify the settings related to the posting of messages and the way messages are shown. You can also enable the spell check here.
		</li><li>
			<strong>Bulletin Board Code</strong><br />
			Enable the code that allows to format forum messages. Also adjust which BBCodes are allowed and which aren\'t.
		</li><li>
			<strong>Censored Words</strong>
			In order to keep the language on your forum under control, you can censor certain words. This function allows you to convert forbidden words into innocent versions.
		</li><li>
			<strong>Topic Settings</strong>
			Modify the settings related to topics. The number of topics per page, whether pinned topics are enabled or not, the number of messages needed for a topic to be hot, etc.
		</li>
	</ul>';
$helptxt['allow_no_censored'] = 'When checked, this global setting allows members to disable word censoring in their User Profile through the Look and Layout settings. The members\' ablility to disable word censoring is still limited by their permission profile.';
$helptxt['spider_mode'] = 'Sets the logging level.<br />
Standard - Logs minimal spider activity.<br />
Moderate - Provides more accurate statistics.<br />
Aggressive - As for &quot;Moderate&quot; but logs data about each page visited.';

$helptxt['spider_group'] = 'Prin selectarea unui grup cu restricţii, atunci când un vizitator este identificat ca fiind un crawler de căutare, 
acestuia i se va atribui în mod automat orice &quot;deny&quot; negare de drepturi pentru acest grup în plus faţă de drepturile obişnuite ale vizitatorului. Puteţi utiliza acest lucru pentru a limita accesul unui motor de căutare faţă de cel al unui vizitator obişnuit. S-ar putea, de exemplu, să doriţi să creaţi un grup nou denumit &quot;Spiders&quot; şi să-l selectaţi pe acela aici. Aţi putea apoi să refuzaţi permisiunea acelui grup de a vizualiza profilurile pentru a opri antenele motoarelor de căutare (spiders) din indexarea profilurilor membrilor dumneavoastră..<br />De reţinut: detectarea de antene ale motoarelor de căutare (spiders) nu este perfectă şi poate fi simulată de utilizatori, astfel încât această facilitate nu oferă garanţia de a restricţiona doar conţinutul pentru acele motoare de căutare pe care le-aţi adăugat.
';
$helptxt['show_spider_online'] = 'Această setare vă permite să selectaţi dacă roboţeii motoarelor de căutare (spiders) ar trebui să fie enumeraţi în lista cine este online din index-ul ariei şi din pagina &quot;Cine este online&quot;. Opţiunile sunt:<ul class="normallist">  <li>  <strong>Deloc</strong><br />Roboţeii motoarelor de căutare (spiders) vor apărea pur şi simplu ca vizitatori pentru toţi utilizatorii. </li><li>  <strong>Afişează numărul de antene ale motoarelor de căutare (spiders)</strong><br /> Index-ul Ariii va afişa numărul roboţeilor motoarelor de căutare (spiders) care vizitează în prezent forumul. </li><li>  <strong>Afişează denumirea roboţeilor motoarelor de căutare (spiders)</strong><br /> Denumirea fiecărui spider va fi dezvaluită, astfel încât utilizatorii să poată vedea cât de mulţi roboţei din fiecare motor de căutare vizitează în prezent forumul - acest lucru are loc atât în Index-ul Ariii,  cât  şi  în pagina Cine este Online.</li><li>  <strong>Afişează denumirea roboţeilor motoarelor de căutare (spiders) - Doar pentru Administratori</strong><br />Potrivit excepţiei de mai sus doar Administratorii pot vizualiza statutul roboţeilor motoarelor de căutare (spiders) - pentru toţi ceilalţi utilizatori roboţeii motoarelor de căutare (spiders) apar ca vizitatori. </li>  </ul>  ';

$helptxt['birthday_email'] = 'Alege indexul mesajului de e-mail de trimis la ziua de naştere. O previzualizare va fi afişată în subiectul e-mailului şi în câmpurile conţinutului e-mailului. <br /><strong>Notă:</strong> Setarea acestei opţiuni nu activează în mod automat trimiterea e-mailurilor la ziua de nastere. Pentru a activa trimiterea e-mailurilor la ziua de naştere accesează pagina de <a href="%1$s?action=admin;area=scheduledtasks;%3$s=%2$s" target="_blank" class="new_win">Actifități programate</a> şi activează trimiterea de e-mail la ziua de naştere.';
$helptxt['pm_bcc'] = 'La trimiterea unui mesaj personal puteţi alege să adăugaţi un destinatar ca BCC sau &quot;Blind Carbon Copy&quot;. Identitatea destinatarilor BCC nu este dezvăluită altor destinatari ai mesajului.';

$helptxt['move_topics_maintenance'] = 'Acest lucru vă va permite să mutaţi toate mesajele postate dintr-o arie in alta arie.';
$helptxt['maintain_reattribute_posts'] = 'Puteţi utiliza această funcţie pentru a atribui mesajele postate de către un vizitator unui membru înregistrat. Acest lucru este util în cazul în care, de exemplu, un utilizator şi-a şters contul, iar apoi s-a răzgândit şi a dorit să aibă vechile mesaje postate asociate cu contul său.';
$helptxt['chmod_flags'] = 'You can manually set the permissions you wish to set the selected files to. To do this enter the chmod value as a numeric (octet) value. Note that these flags will have no effect on Microsoft Windows operating systems.';

$helptxt['postmod'] = 'Această arie le permite membrilor echipei de moderare (care au suficiente drepturi) să aprobe orice mesaje postate şi subiecte de discuţie înainte ca acestea să fie afişate.';

$helptxt['field_show_enclosed'] = 'Encloses the user input between some text or HTML code.  This will allow you to add more instant message providers, images or an embed, etc. For example:<br /><br />
		&lt;a href="http://website.com/{INPUT}"&gt;&lt;img src="{DEFAULT_IMAGES_URL}/icon.png" alt="{INPUT}" /&gt;&lt;/a&gt;<br /><br />
		You can use the following variables:<br />
		<ul class="normallist">
			<li>{INPUT} - The input specified by the user.</li>
			<li>{KEY} - The key specified for a certain value of select box or radio buttons in the admin panel. Usually to use in case of localization or use in CSS of Javascript elements (e.g. as class name).</li>
			<li>{SCRIPTURL} - Web address of forum.</li>
			<li>{IMAGES_URL} - URI of the images directory of the user\'s current theme.</li>
			<li>{DEFAULT_IMAGES_URL} - URI of the images directory of the default theme.</li>
		</ul>';

$helptxt['custom_mask'] = 'The input mask is important for your forum\'s security. Validating the input from a user can help to ensure that data is not used in a way you do not expect. We have provided some simple regular expressions as hints.<br /><br />
	<div class="smalltext custom_mask">
		&quot;~[A-Za-z]+~&quot; - Match all upper and lower case alphabet characters.<br />
		&quot;~[0-9]+~&quot; - Match all numeric characters.<br />
		&quot;~[A-Za-z0-9]{7}~&quot; - Match all upper and lower case alphabet and numeric characters seven times.<br />
		&quot;~[^0-9]?~&quot; - Forbid any number from being matched.<br />
		&quot;~^([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$~&quot; - Only allow 3 or 6 character hexcodes.<br />
	</div><br /><br />
	Additionally, special metacharacters ?+*^$ and {xx} can be defined.
	<div class="smalltext custom_mask">
		? - None or one match of previous expression.<br />
		+ - One or more of previous expression.<br />
		* - None or more of previous expression.<br />
		{xx} - An exact number of the previous expression.<br />
		{xx,} - An exact number or more of the previous expression.<br />
		{,xx} - An exact number or less of the previous expression.<br />
		{xx,yy} - An exact match between the two numbers from previous expression.<br />
		^ - Start of string.<br />
		$ - End of string.<br />
		\ - Escapes the next character.<br />
	</div><br /><br />
	More information and advanced techniques may be found on the internet.';

$helptxt['badbehavior_reverse_proxy_addresses'] = 'In some server farm configurations, Bad Behavior may be unable to determine whether a remote request originated from your reverse proxy/load balancer or arrived directly. In this case you should add all of the internal IP addresses for your reverse proxy/load balancer servers as seen from the origin server. These can usually be omitted; however if you have a configuration where some requests can bypass the reverse proxy/load balancer and connect to the origin server directly, then you should use this option. You should also use this option when incoming requests pass through two or more reverse proxies before reaching the origin server.<br /><br />Enter each IP address or CIDR netblocks separated by a | (1.2.3.4|5.4.3.2/27)';
$helptxt['badbehavior_reverse_proxy_header'] = 'When a reverse proxy is in use, Bad Behavior looks at this HTTP header to determine the actual source IP address for each web request. Your reverse proxy or load balancer must add an HTTP header containing the remote IP address where the connection originated. Most do this by default; check the configuration for your reverse proxy or load balancer to ensure that this header is sent.<br /><br />If you use the CloudFlare service, you should change this option to CF-Connecting-IP.';
$helptxt['badbehavior_reverse_proxy'] = 'When enabled, Bad Behavior will assume it is receiving a connection from a reverse proxy, when a specific HTTP header is received.';
$helptxt['badbehavior_httpbl_maxage'] = 'This is the number of days since suspicious activity was last observed from an IP address by Project Honey Pot. Bad Behavior will block requests with a maximum age equal to or less than this setting.';
$helptxt['badbehavior_httpbl_threat'] = 'This number provides a measure of how suspicious an IP address is, based on activity observed at Project Honey Pot. Bad Behavior will block requests with a threat level equal or higher to this setting. Project Honey Pot has <a href="http://www.projecthoneypot.org/threat_info.php" target="_blank">more information on this parameter</a>.';
$helptxt['badbehavior_httpbl_key'] = 'Bad Behavior is capable of using data from the <a href="http://www.projecthoneypot.org/faq.php#g" target="_blank">http:BL</a> service provided by <a href="http://www.projecthoneypot.org/" target="_blank">Project Honey Pot</a> to screen requests.<br /><br />This is purely optional; however if you wish to use it, you must <a href="http://www.projecthoneypot.org/httpbl_configure.php" target="_blank">sign up for the service</a> and obtain an API key. To disable http:BL use, remove the API key from your settings.';
$helptxt['badbehavior_verbose'] = 'Enabling verbose mode causes all HTTP requests to be logged. When verbose mode is off, only blocked requests and suspicious requests are logged.<br /><br />Verbose mode is off by default. Using verbose mode is not recommended as it can significantly slow down your site; it exists to capture data from live spammers which are not being blocked.';
$helptxt['badbehavior_logging'] = 'Should Bad Behavior keep a log of requests? On by default, and it is not recommended to disable it, since it will cause additional spam to get through.';
$helptxt['badbehavior_strict'] = 'Bad Behavior operates in two blocking modes: normal and strict.<br />When strict mode is enabled, additional checks for (old) software which have been spam sources are enabled, but occasional legitimate users using the same software may be blocked as well.';
$helptxt['badbehavior_offsite_forms'] = 'Bad Behavior normally prevents your site from receiving data posted from forms on other websites. This prevents spammers from, e.g., using a Google cached version of your website to send you spam. However, some web applications such as OpenID require that your site be able to receive form data in this way. If you are running OpenID, enable this option.';
$helptxt['badbehavior_postcount_wl'] = 'This allows you to bypass bad behavior checks for users over a certain post count.<br />-1 will bypass all registered users, including those with no posts<br />0 will disable bypassing and scan everyone regardless of post count<br />Any number greater than zero sets the post count under which users will be checked.';
$helptxt['badbehavior_ip_wl'] = 'IP address ranges use the CIDR format.  To remove an address just leave it blank and then save';
$helptxt['badbehavior_useragent_wl'] = 'User agents are matched by exact match only.';
$helptxt['badbehavior_url_wl'] = 'URLs are matched from the first / after the server name up to, but not including, the ? (if any). The URL to be whitelisted is a URL on YOUR site. A partial URL match is permitted, so URL whitelist entries should be as specific as possible, but no more specific than necessary.<br />For instance, /example would match /example.php and /example/address';

$helptxt['filter_to'] = 'Replace the found text with this, leave blank to replace with found text with nothing (i.e. remove it)';
$helptxt['filter_from'] = 'Enter the text you want to find/replace.  If type is set to regex then this must be a valid regular expression, including delimiters.  If not regex it will do a simple text match and replace it with the replacement text';
$helptxt['filter_type'] = 'Standard will find the exact phrase and replace it with the text in the replace field.  Regular Expression is a wildcard option, but it must be in a valid regex format.';
$helptxt['pbe_post_enabled'] = 'Enable this to allow users to respond to email notifications and have them post as a reply.  They are still required to have posting permissions.';
$helptxt['pbe_pm_enabled'] = 'Enable this to allow users to reply by email to PM notifications.  They are still required to have PM permissions, this setting only allows them to receive and reply to notifications';
$helptxt['maillist_group_mode'] = 'If enabled outbound post/topic emails will come from the poster\'s display name, otherwise it will come from the site name.  This is simply a envelope, affecting only how the "From name" appears in the receiving mailbox, the actual from email address is unchanged.';
$helptxt['maillist_newtopic_change'] = 'This will allow a user to change the subject of a email notification and have it post as a new topic.  The new topic will be started on the same board as the reply was going to.';
$helptxt['maillist_sitename_address'] = 'This must be the address that is piped to the emailpost.php file or the address of the IMAP mailbox';
$helptxt['maillist_help_short'] = 'This feature allows users of your forum to reply to the site\'s email notifications and have those replies post on the forum.  Please visit the Wiki for full instructions';

$helptxt['frame_security'] = 'The X-Frame-Options HTTP response header can be used to indicate whether or not a browser should be allowed to render a page in a frame or an iframe. You can use this additional security restriction on your site against attempts at clickjacking attacks, by ensuring that the content of your site is not embedded into other sites.
	<br />
	More information about this header may be found on the internet.';

$helptxt['attachment_inline_title'] = '<b>Add an inline attachment</b><br />
		Example:
		<br /><b>[attach align=left width=400]123[/attach]</b>
		<br />This will show a left-aligned image resized to 400 pixels wide with the post text flowing around it. Except for the attachment tag and the attachment id all other parameters are optional
		<br /><b>[attach]123[/attach]</b>
		<br />This will show the attachment as a thumbnail if available, if no thumbnail is available it will use a full sized image. The image will be in line with the text of your post.
		<br /><br />
		<br /><b>Options:</b>
		<br />where x is the attachment id
		<br />align=left, center, right
		<br />width=### (where # is number in pixels)
		<br />height=### (where # is number in pixels)
		<br />
		<h3>Modes available</h3>
		<p>
			You can choose the inline mode you want for your attachment:
			<ul>
				<li>Thumbnail [attach]x[/attach] : Your image will be shown as a thumbnail</li>
				<li>Text Link [attachurl]x[/attachurl] : Only a link is show with size and view details. By clicking on it, the image is displayed.</li>
			</ul>
		</p><br />
		<p>
			You can choose how to align the inline image:
			<ul>
				<li>align=left : The image is aligned to the left and the text will flow around it</li>
				<li>align=right : The image is aligned to the right and the text will flow around it</li>
				<li>align=center : The image is centered and the text will be below it</li>
			</ul>
		</p><br />
		<p>
			You can choose how wide to show the image:
			<ul>
				<li>width=123 : The image is displayed 123 pixels wide</li>
				<li>If the width specified is larger than the image or larger than the forum allows the largest allowable width will be used</li>
				<li>Can be used to shrink a thumbnail as well [attach width=50]x[/attach] will display a 50px wide thumbnail</li>
			</ul>
		</p><br />
		<p>
			You can choose how tall to show the image:
			<ul>
				<li>height=123 : The image is displayed 123 pixels tall</li>
				<li>If the height specified is bigger than the image or bigger than the forum allows the biggest allowable width will be used</li>
				<li>Can be used to shrink a thumbnail as well [attach height=50]x[/attach] will display a 50px tall thumbnail</li>
			</ul>
		</p>';