<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Continuă';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Afişează fişierele pachetului';
$txt['files_archive'] = 'Fişierele din arhivă';
$txt['package_browse'] = 'Răsfoieşte';
$txt['add_server'] = 'Adaugă server';
$txt['server_name'] = 'Numele serverului';
$txt['serverurl'] = 'URL';
$txt['no_packages'] = 'Nu exită pachete.';
$txt['download'] = 'Descarcă';
$txt['download_success'] = 'Pachetul s-a descărcat cu succes';
$txt['package_downloaded_successfully'] = 'Pachetul a fost descărcat cu succes';
$txt['package_manager'] = 'Managerul de pachete';
$txt['install_mod'] = 'Instalează add-on-ul';
$txt['uninstall_mod'] = 'Dezinstalează add-on-ul';
$txt['no_adds_installed'] = 'Momentan nu sunt add-on-uri instalate';
$txt['uninstall'] = 'Dezinstalează';
$txt['delete_list'] = 'Șterge lista de add-on-uri';
$txt['package_delete_list_warning'] = 'Ești sigur că vrei să golești lista addon-urilor instalate?';

$txt['package_manager_desc'] = 'Din această interfață intuitivă poți descărca și instala în forum add-on-uri.';
$txt['installed_packages_desc'] = 'Folosiţi interfaţa de mai jos pentru a vizualiza pachetele instalate şi pentru a dezinstala pachetele de care nu mai aveţi nevoie.';
$txt['download_packages_desc'] = 'În această arie poți adăuga sau elimina servere pentru pachete, poți căuta pachete sau poți descărca pachete noi de pe servere.';
$txt['package_servers_desc'] = 'Prin această interfață intuitivă administrezi serverele de pachete și descarci arhivele cu add-on-uri pentru forum.';
$txt['upload_packages_desc'] = 'În această arie poți încărca fișierele cu pachete direct în forum.';

$txt['upload_new_package'] = 'Încarcă un pachet nou';
$txt['view_and_remove'] = 'Afișează și elimină pachete instalate';
$txt['modification_package'] = 'Pachetele cu add-on-uri';
$txt['avatar_package'] = 'Pachetele cu avataruri';
$txt['language_package'] = 'Pachetele pentru limbă:';
$txt['unknown_package'] = 'Alte pachete';
$txt['smiley_package'] = 'Pachete cu emoticoane';
$txt['use_avatars'] = 'Foloseşte avatarele';
$txt['add_languages'] = 'Adaugă limbă';
$txt['list_files'] = 'Afişează fişierele';
$txt['package_type'] = 'Tip pachet';
$txt['extracting'] = 'Despachetare';
$txt['avatars_extracted'] = 'Avatarurile au fost instalate, acum ar trebui să le poți folosi.';
$txt['language_extracted'] = 'Pachetul de limbă a fost instalat, acum poți să actvezi utilizarea lui în aria de setări pentru limbă din panoul de control pentru administrare.';

$txt['mod_name'] = 'Numele add-on-ului';
$txt['mod_version'] = 'Versiune';
$txt['mod_author'] = 'Autor';
$txt['author_website'] = 'Pagina autorului';
$txt['package_no_description'] = 'No description given';
$txt['package_description'] = 'Descriere';
$txt['file_location'] = 'Descarcă';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'No source edits';
$txt['mod_date'] = 'Last updated';
$txt['mod_section_count'] = 'Browse the (%1d) addons in this section';

// Package Server strings
$txt['package_current'] = '(%s <em>You have the Current version %s</em>)';
$txt['package_update'] = '(%s <em>An update for your %s version is available</em>)';
$txt['package_installed'] = 'installed';
$txt['package_downloaded'] = 'descărcat';

$txt['package_installed_key'] = 'Installed addons:';
$txt['package_installed_current'] = 'versiunea actuală';
$txt['package_installed_old'] = 'versiunea veche';
$txt['package_installed_warning1'] = 'This package is already installed, and no upgrade was found.';
$txt['package_installed_warning2'] = 'Ar trebui să dezinstalaţi mai întâi versiunea veche pentru a evita problemele. Sau rugaţi autorul să creeze un pachet de upgrade pentru versiunea dumneavoastră. ';
$txt['package_installed_warning3'] = 'Nu uitaţi să salvaţi fişierele sursă şi baza de date înainte de a instala pachete de modificări, în special când instalaţi pachete cu versiuni de test (beta).';
$txt['package_installed_extract'] = 'Se extrage pachetul';
$txt['package_installed_done'] = 'Pachetul a fost instalat cu succes. Ar trebui să puteţi folosi funcţiile pe care le adaugă sau modifică sau să nu mai găsiţi funcţiile pe care le înlătură.';
$txt['package_installed_redirecting'] = 'Redirecţionare...';
$txt['package_installed_redirect_go_now'] = 'Redirecţionează acum';
$txt['package_installed_redirect_cancel'] = 'Întoarce-te la managerul de pachete';

$txt['package_upgrade'] = 'Upgrade';
$txt['package_uninstall_readme'] = 'Readme (De Citit) la Dezinstalare';
$txt['package_install_readme'] = 'Instrucţiuni de instalare';
$txt['package_install_license'] = 'Licență';
$txt['package_install_type'] = 'Tip';
$txt['package_install_action'] = 'Acţiune';
$txt['package_install_desc'] = 'Descriere';
$txt['install_actions'] = 'Acţiuni de instalare';
$txt['perform_actions'] = 'This will perform the following actions:';
$txt['corrupt_compatible'] = 'The package you are trying to download or install is either corrupt or not compatible with this version of the software.';
$txt['package_create'] = 'Creează';
$txt['package_move'] = 'Mută';
$txt['package_delete'] = 'Şterge';
$txt['package_extract'] = 'Despachetează';
$txt['package_file'] = 'Fişier';
$txt['package_tree'] = 'Arbore';
$txt['execute_modification'] = 'Execută modificarea';
$txt['execute_code'] = 'Execută codul';
$txt['execute_database_changes'] = 'Execute file';
$txt['execute_hook_add'] = 'Add Hook';
$txt['execute_hook_remove'] = 'Remove Hook';
$txt['execute_hook_action'] = 'Adapting hook %1$s';
$txt['package_requires'] = 'Requires Modification';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Add Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'Acţiuni de instalare pentru';
$txt['package_will_fail_title'] = 'Error in package %1$s';
$txt['package_will_fail_warning'] = 'At least one error was encountered during a test %1$s of this package.<br />It is <strong>strongly</strong> recommended that you do not continue with %1$s unless you know what you are doing, and have made a backup very recently.<br /><br />This error may be caused by a conflict between the package you\'re trying to install and another package you have already installed, an error in the package, a package which requires another package that you have not installed yet, or a package designed for another version of the software.';
$txt['package_will_fail_unknown_action'] = 'The package is trying to perform an unknown action: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Are you sure you wish to continue installing this addon, even though it will not install successfully?';
$txt['package_will_fail_popup_uninstall'] = 'Are you sure you wish to continue uninstalling this addon, even though it will not uninstall successfully?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'removal';
$txt['package_install_now'] = 'Install now';
$txt['package_uninstall_now'] = 'Uninstall now';
$txt['package_other_themes'] = 'Install in other themes';
$txt['package_other_themes_uninstall'] = 'UnInstall in other themes';
$txt['package_other_themes_desc'] = 'To use this addon in themes other than the default, the package manager needs to make additional changes to the other themes. If you\'d like to install this addon in the other themes, please select these themes below.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'A apărut cel puţin o eroare în instalarea de test în această temă. Sunteţi sigur(ă) că vreţi să continuaţi instalarea?';

$txt['package_bytes'] = 'bytes';

$txt['package_action_missing'] = '<strong class="error">Fişierul nu a fost găsit</strong>  ';
$txt['package_action_error'] = '<strong class="error">Eroare în sintaxa pachetului</strong>';
$txt['package_action_failure'] = '<strong class="error">Testul a eşuat</strong>  ';
$txt['package_action_success'] = '<strong>Testul a reuşit</strong>  ';
$txt['package_action_skipping'] = '<strong>Fişier ignorat</strong>  ';

$txt['package_uninstall_actions'] = 'Acţiuni de dezinstalare';
$txt['package_uninstall_done'] = 'The package has been successfully uninstalled.';
$txt['package_uninstall_cannot'] = 'This package cannot be uninstalled, because there is no uninstaller.<br /><br />Please contact the addon author for more information.';

$txt['package_install_options'] = 'Opţiuni de instalare';
$txt['package_install_options_desc'] = 'Set various options for how the package manager installs addons, including backups and ftp access';
$txt['package_install_options_ftp_why'] = 'Folosind funcţia FTP a managerului de pachet este cel mai uşor mod de a evita necesitatea modificării manuale a drepturilor de scriere asupra fişierelor pentru ca pachetul să funcţioneze corect.<br />Aici puteţi seta diferite valori necesare.';
$txt['package_install_options_ftp_server'] = 'Server FTP';
$txt['package_install_options_ftp_port'] = 'Portul';
$txt['package_install_options_ftp_user'] = 'Numele de utilizator';
$txt['package_install_options_make_backups'] = 'Crează salvări ale fişierelor modificate prin adăugarea unei tilde (~) la sfârşitul numelui fişierului.';
$txt['package_install_options_make_full_backups'] = 'Create an entire backup (excluding smileys, avatars and attachments) of the ElkArte install.';

$txt['package_ftp_necessary'] = 'Sunt necesare informaţiile FTP';
$txt['package_ftp_why'] = 'Some of the files the package manager needs to modify are not writable.  This needs to be changed by logging into FTP and using it to chmod or create the files and directories.  Your FTP information may be temporarily cached for proper operation of the package manager. Note you can also do this manually using an FTP client - <a href="#" onclick="%1$s">to view a list of the affected files please click here</a>.';
$txt['package_ftp_why_file_list'] = 'Pentru a continua instalarea trebuie să aveţi drepturi de scriere asupra următoarelor fişiere:';
$txt['package_ftp_why_download'] = 'In order to download packages, the packages directory, and any files in it, must be writable.  Currently the system does not have the needed permissions to write to this directory.  The package manager can use your FTP information to attempt to fix this problem.';
$txt['package_ftp_server'] = 'Server FTP';
$txt['package_ftp_port'] = 'Portul';
$txt['package_ftp_username'] = 'Numele de utilizator';
$txt['package_ftp_password'] = 'Parola';
$txt['package_ftp_path'] = 'Local path to ElkArte';
$txt['package_ftp_test'] = 'Test';
$txt['package_ftp_test_connection'] = 'Testează conexiunea';
$txt['package_ftp_test_success'] = 'Conexiune FTP realizată.';
$txt['package_ftp_test_failed'] = 'Conexiune FTP eşuată.';
$txt['package_ftp_bad_server'] = 'Conexiune FTP eşuată.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Pachetul pe care încercaţi să-l ştergeţi este momentan instalat!  Dacă îl ştergeţi nu veţi mai putea să-l dezinstalaţi mai târziu.\\n\\nSunteţi sigur(ă) că vreţi să faceţi asta?';

$txt['package_examine_file'] = 'Listează fişierele din pachet';
$txt['package_file_contents'] = 'Conţinutul fişierului';

$txt['package_upload_title'] = 'Încarcă un pachet';
$txt['package_upload_select'] = 'Pachet de încărcat';
$txt['package_upload'] = 'Încarcă';
$txt['package_uploaded_success'] = 'Pachet încărcat cu succes';
$txt['package_uploaded_successfully'] = 'Pachetul a fost încărcat cu succes';

$txt['package_modification_malformed'] = 'Malformed or invalid addon file.';
$txt['package_modification_missing'] = 'Fişierul nu a putut fi găsit.';
$txt['package_no_zlib'] = 'Ne pare rău, configuraţia dumneavoastră PHP nu are suport pentru <strong>zlib</strong>.  Fără acest suport managerul de pachete nu poate funcţiona.  Vă rugăm să vă contactaţi gazda (host-ul) cu privire la acest lucru pentru mai multe informaţii. ';

$txt['package_cleanperms_title'] = 'Resetarea permisiunilor';
$txt['package_cleanperms_desc'] = 'Această interfaţă permite resetarea permisiunilor pentru fişiere în timpul instalării pachetelor de modificare, pentru a evita problemele ce pot apărea în timpul instalării şi pentru a creşte securitatea.';
$txt['package_cleanperms_type'] = 'Schimbă permisiunile tuturor fişierelor din forum în acest mod';
$txt['package_cleanperms_standard'] = 'Doar fişierele standard pot fi scrise.';
$txt['package_cleanperms_free'] = 'Toate fişierele pot fi scrise.';
$txt['package_cleanperms_restrictive'] = 'Un număr minim de fişiere pot fi scrise.';
$txt['package_cleanperms_go'] = 'Schimbă permisiunile fişierelor';

$txt['package_download_by_url'] = 'Descarcare pachet prin URL';
$txt['package_download_filename'] = 'Numele fişierului';
$txt['package_download_filename_info'] = 'Valoare opţională.  Trebuie folosită când adresa URL nu se termină cu numele fişierului.  De exemplu: index.php?mod=5';

$txt['package_db_uninstall'] = 'Remove all data associated with this addon.';
$txt['package_db_uninstall_details'] = 'Detalii';
$txt['package_db_uninstall_actions'] = 'Checking this option will result in the following actions';
$txt['package_db_remove_table'] = 'Şterg tabel(ele) &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Şterg coloanele &quot;%2$s&quot; din &quot;%1$s&quot;';
$txt['package_db_remove_index'] = 'Şterg index  &quot;%1$s&quot; din &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Install Emulating:';
$txt['package_emulate_uninstall'] = 'Uninstall Emulating:';

// Operations.
$txt['operation_find'] = 'Caută';
$txt['operation_replace'] = 'Înlocuieşte';
$txt['operation_after'] = 'Adaugă înainte de';
$txt['operation_before'] = 'Adaugă după';
$txt['operation_title'] = 'Operaţiuni';
$txt['operation_ignore'] = 'Ignoră erorile';
$txt['operation_invalid'] = 'Operaţia pe care aţi selectat-o este invalidă.';

$txt['package_file_perms_desc'] = 'Puteţi folosi această secţiune pentru a afla starea de editabilitate a fişierelor şi directoarelor critice ale forumului. Atenţie este vorba doar de fişierele şi folderele cheie ale forumului - folosiţi un client FTP pentru setări suplimentare.';
$txt['package_file_perms_name'] = 'File/Directory Name';
$txt['package_file_perms_status'] = 'Stare actuală';
$txt['package_file_perms_new_status'] = 'Stare nouă';
$txt['package_file_perms_status_read'] = 'Citit de ';
$txt['package_file_perms_status_write'] = 'Editare';
$txt['package_file_perms_status_execute'] = 'Execuţie';
$txt['package_file_perms_status_custom'] = 'Personalizat';
$txt['package_file_perms_status_no_change'] = 'Fără schimbare';
$txt['package_file_perms_writable'] = 'Care poate fi scris';
$txt['package_file_perms_not_writable'] = 'Needitabil';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Mai multe fişiere';

$txt['package_file_perms_change'] = 'Schimbă permisiunile fişierelor';
$txt['package_file_perms_predefined'] = 'Folosiţi profilul de permisiuni predefinite';
$txt['package_file_perms_predefined_note'] = 'Note that this only applies the predefined profile to key directories and files.';
$txt['package_file_perms_apply'] = 'Aplică permisiuni pentru fişiere individual, conform setărilor de mai sus.';
$txt['package_file_perms_custom'] = 'Dacă aţi selectat &quot;Personalizat&quot; foloseşte următoarele valori pentru chmod';
$txt['package_file_perms_pre_restricted'] = 'Restricţionat - minimum de fişiere editabile';
$txt['package_file_perms_pre_standard'] = 'Standard - fişierele cheie sunt editabile';
$txt['package_file_perms_pre_free'] = 'Liber - toate fişerele sunt editabile';
$txt['package_file_perms_ftp_details'] = 'Pe majoritatea serverelor este posibilă schimbarea permisiunilor fişierelor doar folosind un cont FTP. Vă rugăm introduceţi datele contului FTP mai jos';
$txt['package_file_perms_ftp_retain'] = 'Note, the system will only retain the password information temporarily to aid operation of the package manager.';
$txt['package_file_perms_go'] = 'Aplică modificările';

$txt['package_file_perms_applying'] = 'Se aplică modificările';
$txt['package_file_perms_items_done'] = '%1$d din %2$d efectuate';
$txt['package_file_perms_skipping_ftp'] = '<strong>Atenţionare:</strong> Conexiunea FTP cu serverul nu a reuşit, se încearcă efectuarea modificărilor oricum. Este aproape <em>sigur</em> că nu se va reuşi - verificaţi rezultatul după terminarea procesului şi încercaţi din nou cu setările FTP corecte.';

$txt['package_file_perms_dirs_done'] = '%1$d din %2$d directoare modificate';
$txt['package_file_perms_files_done'] = '%1$d din %2$d fişiere modificate în directorul curent';

$txt['chmod_value_invalid'] = 'Aţi introdus o valoare chmod incorectă. CHMOD trebuie să fie între 0444 şi 0777';

$txt['package_restore_permissions'] = 'Restore file permissions';
$txt['package_restore_permissions_desc'] = 'The following file permissions were changed in order to install the selected package(s). You can return these files back to their original status by clicking &quot;Restore&quot; below.';
$txt['package_restore_permissions_restore'] = 'Restaurează';
$txt['package_restore_permissions_filename'] = 'Numele fişierului';
$txt['package_restore_permissions_orig_status'] = 'Starea iniţială';
$txt['package_restore_permissions_cur_status'] = 'Stare actuală';
$txt['package_restore_permissions_result'] = 'Rezultat';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - a fost %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Sărit</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Success</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Nereuşit</span>';
$txt['package_restore_permissions_action_done'] = 'An attempt to restore the selected files back to their original permissions has been completed, the results can be seen below. If a change failed, or for a more detailed view of file permissions, please see the <a href="%1$s">File Permissions</a> section.';

$txt['package_file_perms_warning'] = 'Vă rugăm să ţineţi cont';
$txt['package_file_perms_warning_desc'] = '
	Be careful when changing file permissions from this section - incorrect permissions can adversely affect the operation of your forum!<br />
	On some server configurations selecting the wrong permissions may stop the forum from operating.<br />
	Certain directories such as <em>attachments</em> need to be writable to use that functionality.<br />
	This functionality is mainly applicable on non-Windows based servers - it will not work as expected on Windows in regards to permission flags.<br />
	Before proceeding make sure you have an FTP client installed in case you do make an error and need to FTP into the server to remedy it.';

$txt['package_confirm_view_package_content'] = 'Sunteţi sigur(ă) că vreţi să vedeţi conţinutul pachetului din această locaţie:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Continuă';
$txt['package_confirm_go_back'] = 'Du-te înapoi';

$txt['package_readme_default'] = 'Implicit';
$txt['package_available_readme_language'] = 'Readme este Disponibil în Limbile:';
$txt['package_license_default'] = 'Implicit';
$txt['package_available_license_language'] = 'Available License Languages:';