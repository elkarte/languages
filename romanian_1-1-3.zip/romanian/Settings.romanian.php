<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Tema implicită EkArte.<br /><br />Autor: dezvoltatorii ElkArte';