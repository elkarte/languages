<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Setează parametrii de căutare';
$txt['choose_board'] = 'Alege o arie în care să cauţi sau selectează-le pe toate';
$txt['all_words'] = 'Potriviţi toate cuvintele';
$txt['any_words'] = 'Potriviţi orice cuvinte';
$txt['by_user'] = 'După utilizator';

$txt['search_post_age'] = 'Vechimea mesajului ';
$txt['search_between'] = 'între';
$txt['search_and'] = 'şi';
$txt['search_options'] = 'Opţiuni';
$txt['search_show_complete_messages'] = 'Afişează rezultatele ca şi mesaje';
$txt['search_subject_only'] = 'Caută doar în descrierea subiectelor';
$txt['search_relevance'] = 'Relevanţă';
$txt['search_date_posted'] = 'Data postării';
$txt['search_order'] = 'Ordinea căutării';
$txt['search_orderby_relevant_first'] = 'cel mai relevante primele';
$txt['search_orderby_large_first'] = 'cel mai mari subiecte primele';
$txt['search_orderby_small_first'] = 'cele mai mici subiecte primele';
$txt['search_orderby_recent_first'] = 'cele mai noi subiecte primele';
$txt['search_orderby_old_first'] = 'cele mai vechi subiecte primele';
$txt['search_visual_verification_label'] = 'Verificare';
$txt['search_visual_verification_desc'] = 'Introdu codul din imaginea de mai sus pentru a începe căutarea.';

$txt['search_specific_topic'] = 'Caută doar în mesajele din subiect';

$txt['groups_search_posts'] = 'Grupuri de utilizatori cu acces la funcţia de căutare';
$txt['search_dropdown'] = 'Activează meniul dropdown pentru căutare rapidă';
$txt['search_results_per_page'] = 'Numărul de rezultate găsite per pagină';
$txt['search_weight_frequency'] = 'Importanţa raportată la numărul de coincidenţe într-un subiect';
$txt['search_weight_age'] = 'Importanţa raportată la vârsta ultimului mesaj care se potriveşte';
$txt['search_weight_length'] = 'Importanţa raportată la lungimea subiectului';
$txt['search_weight_subject'] = 'Importanţa raportată la gradul de coincidenţă a subiectului';
$txt['search_weight_first_message'] = 'Importanţa raportată la gradul de potrivire al primului mesaj';
$txt['search_weight_sticky'] = 'Ponderea relativă la căutare pentru un subiect fixat';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Aici poți schimba setările de bază pentru funcția de căutare.';
$txt['search_settings_title'] = 'Setările pentru căutare';

$txt['search_weights_desc'] = 'Aici poți modifica setările individuale legate de clasificarea după relevanță.';
$txt['search_weights_sphinx'] = 'Pentru a actualiza valorile ponderilor din Sphinx, trebuie să generezi și să instalezi un fișier \'sphinx.conf\' nou';
$txt['search_weights_title'] = 'Căutare - pondere';
$txt['search_weights_total'] = 'Total';
$txt['search_weights_save'] = 'Salvează';

$txt['search_method_desc'] = 'Aici puteţi seta parametrii motorului de căutare.';
$txt['search_method_title'] = 'Căutare - metodă';
$txt['search_method_save'] = 'Salvează';
$txt['search_method_messages_table_space'] = 'Spaţiul ocupat de mesajele forumului în baza de date';
$txt['search_method_messages_index_space'] = 'Spaţiul ocupat de către indexul mesajelor în baza de date';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Indexare completă a textului';
$txt['search_method_no_index_exists'] = 'Momentan nu există';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'nu poate fi creat deoarece este depăşită mărimea maximă a mesajelor adică 65,535 sau tipul de tabele nu este MyISAM';
$txt['search_method_index_already_exists'] = 'creat deja';
$txt['search_method_fulltext_remove'] = 'şterge indexul ';
$txt['search_method_index_partial'] = 'creat parţial';
$txt['search_index_custom_resume'] = 'continuă';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'In order to be able to use fulltext search, you\\\'ll have to create a fulltext index first.';
$txt['search_index_custom_warning'] = 'Pentru a utiliza indexarea personalizată a textului în funcţia de căutare, trebuie să o creaţi mai întâi!';

$txt['search_index'] = 'Indexul căutării';
$txt['search_index_none'] = 'Fără indexare';
$txt['search_index_custom'] = 'Indexare personalizată';
$txt['search_index_label'] = 'Index';
$txt['search_index_size'] = 'Mărime';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx ';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Forţează folosirea unei indexări în căutare';
$txt['search_match_words'] = 'Conţinând cu cel puţin unul dintre cuvinte';
$txt['search_max_results'] = 'Numărul maxim de rezultate afişate';
$txt['search_max_results_disable'] = '(0: fără limită)';
$txt['search_floodcontrol_time'] = 'Timpul de aşteptare între două căutări de la acelaşi utilizator';
$txt['search_floodcontrol_time_desc'] = '(0 pentru nicio limită, în secunde)';

$txt['additional_search_engines'] = 'Additional search engines';
$txt['setup_search_engine_add_more'] = 'Add another search engine';

$txt['search_create_index'] = 'Crează indexarea';
$txt['search_create_index_why'] = 'De ce să creăm un index de căutare ?';
$txt['search_create_index_start'] = 'Creează';
$txt['search_predefined'] = 'Profil predefinit';
$txt['search_predefined_small'] = 'Indexare de dimensiuni mici';
$txt['search_predefined_moderate'] = 'Indexare de dimensiuni moderate';
$txt['search_predefined_large'] = 'Indexare de dimensiuni mari';
$txt['search_create_index_continue'] = 'Continuă';
$txt['search_create_index_not_ready'] = 'ElkArte is currently creating a search index of your messages. To avoid overloading your server, the process has been temporarily paused. It should automatically continue in a few seconds. If it doesn\'t, please click continue below.';
$txt['search_create_index_progress'] = 'Progres';
$txt['search_create_index_done'] = 'Custom search index successfully created.';
$txt['search_create_index_done_link'] = 'Continuă';
$txt['search_double_index'] = 'Aţi creat două indexări ale aceluiaşi tabel de mesaje. Pentru o performanţă mai bună este indicat să eliminaţi una dintre indexări.';

$txt['search_error_indexed_chars'] = 'Numărul de caractere indexate este invalid. Este nevoie de minim 3 caractere pentru o indexare funcţională.';
$txt['search_error_max_percentage'] = 'Procentul de cuvinte care vor fi sărite este incorect. Folosiţi o valoare peste 5%.';
$txt['error_string_too_long'] = 'Cuvintele căutate nu trebuie să depăşească în total %1$d caractere.';

$txt['search_warning_ignored_word'] = 'The following term has been ignored in your search';
$txt['search_warning_ignored_words'] = 'The following terms have been ignored in your search';

$txt['search_adjust_query'] = 'Ajustaţi parametrii de căutare';
$txt['search_adjust_submit'] = 'Revizuiţi căutarea';
$txt['search_did_you_mean'] = 'Aţi dorit să căutaţi';

$txt['search_example'] = '<em>de exemplu</em> Orwell "Ferma Animalelor" -film';

$txt['search_engines_description'] = 'În această secţiune puteţi stabili detaliile privind urmărirea motoarelor de căutare care indexează forumul şi să accesaţi înregistrările acestor date.';
$txt['spider_mode'] = 'Search Engine Tracking Level';
$txt['spider_mode_note'] = 'Note higher level tracking increases server resource requirement.';
$txt['spider_mode_off'] = 'Dezactivat';
$txt['spider_mode_standard'] = 'Standard';
$txt['spider_mode_high'] = 'Moderare';
$txt['spider_mode_vhigh'] = 'Aggressive';
$txt['spider_settings_desc'] = 'You can change settings for spider tracking from this page. Note, if you wish to <a href="%1$s">enable automatic pruning of the hit logs you can set this up here</a>';

$txt['spider_group'] = 'Apply restrictive permissions from group';
$txt['spider_group_note'] = 'To enable you to stop spiders indexing some pages.';
$txt['spider_group_none'] = 'Dezactivat';

$txt['show_spider_online'] = 'Afişează motoarele în lista cine este online';
$txt['show_spider_online_no'] = 'Nu afişa';
$txt['show_spider_online_summary'] = 'Afişează numărul roboţilor';
$txt['show_spider_online_detail'] = 'Afişează numele roboţilor';
$txt['show_spider_online_detail_admin'] = 'Afişează numele roboţilor - doar pentru admin';

$txt['spider_name'] = 'Numele motorului de căutare';
$txt['spider_last_seen'] = 'Văzut Ultima Dată';
$txt['spider_last_never'] = 'Niciodată';
$txt['spider_agent'] = 'Numele robotului';
$txt['spider_ip_info'] = 'Adresele IP';
$txt['spiders_add'] = 'Adaugare motor nou';
$txt['spiders_edit'] = 'Editare motor de căutare';
$txt['spiders_remove_selected'] = 'Elimină-le pe cele selectate';
$txt['spider_remove_selected_confirm'] = 'Are you sure you want to remove these spiders?\\n\\nAll associated statistics will also be deleted!';
$txt['spiders_no_entries'] = 'În prezent nu sunt antene ale motoarelor de căutare (spiders) configurate.';

$txt['add_spider_desc'] = 'În această pagină poţi edita parametrii după care sunt clasificate motoarele de indexare. Dacă un agent sau o adresă IP sunt identice cu cele introduse mai jos atunci el va fi detectat ca motor de indexare şi urmărit după preferinţele din forum.';
$txt['spider_name_desc'] = 'Numele care va fi afişat pentru acest motor.';
$txt['spider_agent_desc'] = 'Numele robotului de căutare asociat acestui motor.';
$txt['spider_ip_info_desc'] = 'Lista adreselor IP, despărţite prin virgulă, asociate roboţilor acestui motor de căutare.';

$txt['spider_time'] = 'Data/Ora';
$txt['spider_viewing'] = 'A vizitat';
$txt['spider_logs_empty'] = 'În prezent nu sunt înregistrări în logul antenelor motoarelor de căutare (spiders)';
$txt['spider_logs_info'] = 'Atenţie: înregistrările despre fiecare acţiune a motoarelor apar doar dacă nivelul de urmărire este setat la &quot;Ridicat&quot; sau &quot;Foarte Ridicat&quot;. Detaliile sunt înregistrate doar în cazul &quot;Foarte Ridicat&quot;';
$txt['spider_disabled'] = 'Dezactivat';
$txt['spider_log_empty_log'] = 'Golește jurnalul';
$txt['spider_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log';

$txt['spider_logs_delete'] = 'Şterge Intrările';
$txt['spider_logs_delete_older'] = 'Delete all entries older than %1$s days.';
$txt['spider_logs_delete_submit'] = 'Şterge';

$txt['spider_stats_delete_older'] = 'Delete all spider statistics from spiders not seen in %1$s days.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Sunteţi sigur că doriţi să ştergeţi toate înregistrările?';

$txt['spider_stats_select_month'] = 'Du-te la luna';
$txt['spider_stats_page_hits'] = 'Pagini vizitate ';
$txt['spider_stats_no_entries'] = 'În prezent nu sunt disponibile statistici privind antenele motoarelor de căutare (spiders). ';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'You have not yet selected to use Sphinx or SphinxQL as your Search Method';
$txt['sphinx_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using the Sphinx API.';
$txt['sphinxql_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using SphinxQL commands.';
$txt['sphinx_test_connect_failed'] = 'Unable to connect to the Sphinx daemon. Make sure it is running and configured properly. Sphinx search will not work until you fix the problem.';
$txt['sphinxql_test_connect_failed'] = 'Unable to access SphinxQL. Make sure your sphinx.conf has a separate listen directive for the SphinxQL port. SphinxQL search will not work until you fix the problem';
$txt['sphinx_test_api_missing'] = 'The sphinxapi.php file is missing in your &quot;sources&quot; directory. You need to copy this file from the Sphinx distribution. Sphinx search will not work until you fix the problem.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Index data path:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Log file path:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';