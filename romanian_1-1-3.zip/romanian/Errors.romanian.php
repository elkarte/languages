<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Îmi pare rău, nu poți să accesezi această zonă. Nu pot nici măcar să-ți spun dacă zona există sau nu. Accesează te rog pagina principală și continuă navigarea de acolo.';
$txt['not_guests'] = 'Această acțiune nu este disponibilă vizitatorilor.';

$txt['mods_only'] = 'Doar moderatorii pot folosi funcția de eliminare directă. Elimină acest mesaj utilizând funcția de modificare.';
$txt['no_name'] = 'Nu ai completat câmpul pentru nume. Ne pare rău dar nu poți continua fără un nume.';
$txt['no_email'] = 'Nu ai completat câmpul pentru email. Ne pare rău, nu poți continua fără email.';
$txt['topic_locked'] = 'Acest subiect este închis. Nu ai dreptul să adaugi sau să editezi mesaje...';
$txt['no_password'] = 'Câmpul pentru parolă e gol';
$txt['passwords_dont_match'] = 'Parolele introduse nu sunt identice.';
$txt['register_to_use'] = 'Trebuie să fii înregistrat ca să poți folosi această funcție.';
$txt['username_reserved'] = 'Numele de utilizator propus de tine conține cuvântul rezervat \'%1$s\'. Încearcă alt nume.';
$txt['numbers_one_to_nine'] = 'Acest câmp acceptă doar cifre de la 0 la 9';
$txt['not_a_user'] = 'Nu există nici un utilizator care să corespundă acestui profil.';
$txt['not_a_topic'] = 'Subiectul nu există în această secţiune.';
$txt['not_approved_topic'] = 'Acest subiect de discuţie nu a fost încă aprobat.';
$txt['email_in_use'] = 'Această adresă de e-mail (%1$s) este deja folosită de un membru înregistrat. Dacă crezi că aceasta este o greşeală, mergi la pagina de autentificare şi folosește funcţia de reamintire a parolei cu această adresă de e-mail.';

$txt['didnt_select_vote'] = 'Nu ai selectat nicio opţiune de vot.';
$txt['poll_error'] = 'Ceva nu e în regulă: fie sondajul nu există, fie a fost închis, fie ai încercat să votezi de două ori.';
$txt['locked_by_admin'] = 'A fost închis de un administrator. Nu poți să-l redeschizi.';
$txt['not_enough_posts_karma'] = 'Nu ai destule mesaje ca să modifici karma - ai nevoie de cel puţin %1$d.';
$txt['cant_change_own_karma'] = 'Nu poți modifica propria karmă.';
$txt['karma_wait_time'] = 'Pentru a folosi din nou karma trebuie să astepți %1$s %2$s.';
$txt['feature_disabled'] = 'Aceasta funcție este blocată.';
$txt['feature_no_exists'] = 'Această funcție nu există.';
$txt['couldnt_connect'] = 'Serverul nu poate fi contactat sau fişierul nu a fost găsit';
$txt['no_board'] = 'Secţiunea specificată nu există';
$txt['no_message'] = 'Mesajul nu mai este disponibil';
$txt['no_topic_id'] = 'Ai specificat un ID de subiect invalid.';
$txt['split_first_post'] = 'Nu poţi scinda subiectul la primul mesaj.';
$txt['topic_one_post'] = 'Acest subiect conţine un singur mesaj şi nu poate fi scindat.';
$txt['no_posts_selected'] = 'Nu ai selectat nici un mesaj';
$txt['selected_all_posts'] = 'Scindarea nu se poate face. Ai selectat toate mesajele.';
$txt['cant_find_messages'] = 'Nu găsesc mesaje';
$txt['cant_find_user_email'] = 'Nu găsesc adresa de email a utilizatorului.';
$txt['cant_insert_topic'] = 'Subiectul nu poate fi inserat';
$txt['session_timeout'] = 'Sesiunea ta a expirat în timpul postării. Mergi înapoi și încearcă din nou.';
$txt['session_timeout_file_upload'] = 'Sesiunea ta a expirat în timpul încărcării fișierului. Încearcă din nou.';
$txt['no_files_uploaded'] = 'Nu sunt fișiere de încărcat.';
$txt['session_verify_fail'] = 'Verificarea sesiunii a eșuat. Deloghează-te și autentifică-te din nou apoi mai încearcă o dată.';
$txt['verify_url_fail'] = 'Nu pot verifica URL-ul %1$s. Mergi înapoi și încearcă din nou.';
$txt['token_verify_fail'] = 'Verificarea tokenului a eșuat. Mergi înapoi și încearcă din nou.';
$txt['guest_vote_disabled'] = 'Vizitatorii nu pot vota în acest sondaj.';

$txt['cannot_access_mod_center'] = 'Nu ai dreptul să accesezi centrul de moderare.';
$txt['cannot_admin_forum'] = 'Nu ai dreptul să administrezi acest forum.';
$txt['cannot_announce_topic'] = 'Nu ai dreptul să anunţi subiecte în această secţiune.';
$txt['cannot_approve_posts'] = 'Nu ai dreptul să aprobi postări.';
$txt['cannot_post_unapproved_attachments'] = 'Nu ai dreptul să postezi ataşamente neaprobate.';
$txt['cannot_post_unapproved_topics'] = 'Nu ai dreptul să postezi subiecte neaprobate.';
$txt['cannot_post_unapproved_replies_own'] = 'Nu ai dreptul să postezi răspunsuri neaprobate la subiectele tale.';
$txt['cannot_post_unapproved_replies_any'] = 'Nu ai dreptul să postezi răspunsuri neaprobate la subiectele altor utilizatori.';
$txt['cannot_calendar_edit_any'] = 'Nu ai dreptul să editezi evenimentele din calendar.';
$txt['cannot_calendar_edit_own'] = 'Nu ai dreptul să editezi propriile evenimente.';
$txt['cannot_calendar_post'] = 'Postarea evenimentelor nu este permisă.';
$txt['cannot_calendar_view'] = 'Nu ai dreptul să accesezi calendarul.';
$txt['cannot_remove_any'] = 'Nu ai dreptul să elimini orice subiect.  Verifică dacă acest subiect nu a fost mutat în altă secţiune.';
$txt['cannot_remove_own'] = 'Nu ai dreptul să ştergi subiectele proprii în această secţiune.  Verifică dacă acest subiect nu a fost mutat în alt forum.';
$txt['cannot_edit_news'] = 'Nu ai dreptul să să editezi ştirile.';
$txt['cannot_pm_read'] = 'Nu poți să-ți citești mesajele personale.';
$txt['cannot_pm_send'] = 'Nu ai dreptul să trimiţi mesaje personale.';
$txt['cannot_karma_edit'] = 'Nu ai dreptul să modifici karma altor persoane.';
$txt['cannot_like_posts'] = 'Nu ai dreptul să apreciezi mesajele din această arie.';
$txt['cannot_lock_any'] = 'Nu ai dreptul să închizi orice subiect aici.';
$txt['cannot_lock_own'] = 'Nu ai dreptul să  închizi subiectele proprii aici.';
$txt['cannot_make_sticky'] = 'Nu ai dreptul să fixezi acest subiect.';
$txt['cannot_manage_attachments'] = 'Nu ai dreptul să editezi ataşamente sau avataruri.';
$txt['cannot_manage_bans'] = 'Nu ai dreptul să modifici lista de restricționări.';
$txt['cannot_manage_boards'] = 'Nu ai dreptul să administrezi arii și categorii.';
$txt['cannot_manage_membergroups'] = 'Nu ai dreptul să modifici sau să aloci grupuri de membri.';
$txt['cannot_manage_permissions'] = 'Nu ai dreptul să administrezi drepturile.';
$txt['cannot_manage_smileys'] = 'Nu ai dreptul să editezi emoticoanele şi pictogramele mesajelor.';
$txt['cannot_mark_any_notify'] = 'Nu ai dreptul să primeși notificări despre acest subiect.';
$txt['cannot_mark_notify'] = 'Nu ai dreptul să ceri notificări pentru această secţiune.';
$txt['cannot_merge_any'] = 'Nu ai dreptul să lipești subiecte pe unul din forumurile selectate.';
$txt['cannot_moderate_forum'] = 'Nu ai dreptul să moderezi acest forum.';
$txt['cannot_moderate_board'] = 'Nu ai dreptul să  moderezi această secţiune.';
$txt['cannot_modify_any'] = 'Nu ai dreptul să modifici orice mesaj.';
$txt['cannot_modify_own'] = 'Nu ai dreptul să editezi postările proprii.';
$txt['cannot_modify_replies'] = 'Chiar dacă aceast mesaj este un răspuns la subiectul propriu, nu ai dreptul să îl modifici.';
$txt['cannot_move_own'] = 'Nu ai dreptul să muți subiectele proprii în această secţiune.';
$txt['cannot_move_any'] = 'Nu ai dreptul să muţi subiecte în această secţiune.';
$txt['cannot_poll_add_own'] = 'Nu ai dreptul să adaugi sondaje la subiectele proprii în această secţiune.';
$txt['cannot_poll_add_any'] = 'Nu ai dreptul să adaugi sondaje de opinie la acest subiect.';
$txt['cannot_poll_edit_own'] = 'Nu ai dreptul să editezi acest sondaj de opinie chiar dacă este unul propriu.';
$txt['cannot_poll_edit_any'] = 'Nu ai dreptul să editezi sondaje de opinie  în această secţiune.';
$txt['cannot_poll_lock_own'] = 'Nu ai dreptul să închizi sondajele de opinie proprii în această secţiune.';
$txt['cannot_poll_lock_any'] = 'Nu ai dreptul să închizi orice sondaj de opinie.';
$txt['cannot_poll_post'] = 'Nu ai dreptul să deschizi sondaje de opinie în această secţiune.';
$txt['cannot_poll_remove_own'] = 'Nu ai dreptul să ştergi sondajul de opinie din subiectul propriu.';
$txt['cannot_poll_remove_any'] = 'Nu ai dreptul să ştergi sondaje de opinie din această secţiune.';
$txt['cannot_poll_view'] = 'Nu ai dreptul să consulţi sondajele de opinie în această secţiune.';
$txt['cannot_poll_vote'] = 'Nu ai dreptul să votezi în sondajele de opinie din această secţiune.';
$txt['cannot_post_attachment'] = 'Nu ai dreptul să postezi ataşamente aici.';
$txt['cannot_post_new'] = 'Nu ai dreptul să postezi subiecte noi în această secţiune.';
$txt['cannot_post_new_board'] = 'Nu ai dreptul să postezi subiecte noi în ariea %1$s.';
$txt['cannot_post_reply_any'] = 'Nu ai dreptul să adaugi răspunsuri la subiectele din această secţiune.';
$txt['cannot_post_reply_own'] = 'Nu ai dreptul să adaugi răspunsuri la subiectele proprii în această secţiune.';
$txt['cannot_profile_remove_own'] = 'Nu ai dreptul să-ți ştergi contul de utilizator.';
$txt['cannot_profile_remove_any'] = 'Nu ai dreptul să ștergi conturi de utilizator.';
$txt['cannot_profile_extra_any'] = 'Nu ai dreptul să modifici setările profilului.';
$txt['cannot_profile_identity_any'] = 'Nu ai dreptul să modifici setările contului.';
$txt['cannot_profile_title_any'] = 'Nu ai dreptul să modifici titlurile personalizate ale utilizatorilor.';
$txt['cannot_profile_extra_own'] = 'Nu ai dreptul să modifici datele profilului propriu.';
$txt['cannot_profile_identity_own'] = 'Nu poți să-ți schimbi identitatea în momentul de față.';
$txt['cannot_profile_title_own'] = 'Nu ai dreptul să-ți modifici titlul personalizat.';
$txt['cannot_profile_set_avatar'] = 'Nu ai dreptul să-ți schimbi avatarul.';
$txt['cannot_profile_view_own'] = 'Nu ai dreptul să-ți vezi profilul propriu.';
$txt['cannot_profile_view_any'] = 'Nu ai dreptul să vezi nici un profil.';
$txt['cannot_delete_own'] = 'Nu ai dreptul să-ți ștergi mesajele din această arie.';
$txt['cannot_delete_replies'] = 'Nu ai dreptul să ştergi aceste mesaje, chiar dacă sunt răspunsuri la subiectul propriu.';
$txt['cannot_delete_any'] = 'Nu ai dreptul să ștergi mesaje în această arie.';
$txt['cannot_report_any'] = 'Nu ai dreptul să raportezi mesajele din această secţiune.';
$txt['cannot_search_posts'] = 'Nu ai dreptul să cauţi mesaje în acest forum.';
$txt['cannot_send_mail'] = 'Nu ai dreptul să trimiţi email-uri tuturor.';
$txt['cannot_issue_warning'] = 'Nu ai dreptul să emiţi avertismente către membri.';
$txt['cannot_send_topic'] = 'Ne pare rău, administratorul nu permite trimiterea subiectelor în această secţiune.';
$txt['cannot_send_email_to_members'] = 'Ne pare rău, administratorul nu permite trimiterea de e-mail-uri în această secţiune.';
$txt['cannot_split_any'] = 'Scindarea subiectelor nu este permisă în această secţiune.';
$txt['cannot_view_attachments'] = 'Nu ai dreptul să descarci sau să vezi ataşamentele din această secţiune.';
$txt['cannot_view_mlist'] = 'Nu ai dreptul să vezi lista membrilor.';
$txt['cannot_view_stats'] = 'Nu ai dreptul să vezi statisticile forumului.';
$txt['cannot_who_view'] = 'Nu ai dreptul să vezi lista cu cine este online.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = 'Acea temă nu a fost găsită.';
$txt['theme_dir_wrong'] = 'Directorul implicit al Temelor este greşit, te rog să corectezi acest lucru cu un click pe acest text.';
$txt['registration_disabled'] = 'Ne pare rău, momentan nu se acceptă înregistrări.';
$txt['registration_agreement_missing'] = 'Fișierul cu acordul de înregistrare, agreement.txt, fie lipsește fie este gol. Înregistrările vor fi suspendate până la remedierea acestui aspect.';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Ne pare rău, nu există întrebare secretă pentru acest utilizator.';
$txt['poll_range_error'] = 'Ne pare rău, sondajul de opinie trebuie să dureze mai mult de 0 zile.';
$txt['delFirstPost'] = 'Nu poți șterge primul mesaj dintr-un subiect.<p>Dacă vrei să ștergi sacest subiect, fă click fă click pe link-ul Elimină sau solicită-i acest lucru unui moderator/administrator.</p>';
$txt['login_cookie_error'] = 'Autentificarea a eşuat. Te rog verifică setările pentru cookie.';
$txt['incorrect_answer'] = 'Ne pare rău, dar nu ai răspuns corect la întrebare. Te rog mergi un pas înapoi și încearcă din nou sau mergi doi pași înapoi şi folosește metoda implicită de recuperare a parolei.';
$txt['no_mods'] = 'Nu s-au găsit moderatori!';
$txt['parent_not_found'] = 'Structura ariei este coruptă: imposibil de găsit ariea părinte.';
$txt['modify_post_time_passed'] = 'Nu poţi modifica acest mesaj deoarece a expirat timpul alocat editării.';

$txt['calendar_off'] = 'Nu poţi accesa calendarul deoarece acesta este dezactivat.';
$txt['calendar_export_off'] = 'Nu poți exporta evenimente din calendar pentru că această funcție este dezactivată.';
$txt['invalid_month'] = 'Valoare greşită pentru Lună.';
$txt['invalid_year'] = 'Valoare greșită pentru An.';
$txt['invalid_day'] = 'Valoare greșită pentru Zi.';
$txt['event_month_missing'] = 'Lipseşte luna pentru eveniment.';
$txt['event_year_missing'] = 'Lipseşte anul pentru eveniment.';
$txt['event_day_missing'] = 'Lipseşte ziua pentru eveniment.';
$txt['event_title_missing'] = 'Lipseşte titlul pentru eveniment.';
$txt['invalid_date'] = 'Data este invalidă.';
$txt['no_event_title'] = 'Nu ai introdus nici un titlu pentru eveniment.';
$txt['missing_board_id'] = 'Lipseşte ID-ul ariei.';
$txt['missing_topic_id'] = 'Lipseşte ID-ul subiectului.';
$txt['topic_doesnt_exist'] = 'Subiectul nu există.';
$txt['not_your_topic'] = 'Nu ești iniţiatorul acestui subiect.';
$txt['board_doesnt_exist'] = 'Secţiunea nu există.';
$txt['no_span'] = 'Durata este dezactivată.';
$txt['invalid_days_numb'] = 'Numărul de zile pentru durată nu este valid.';

$txt['moveto_noboards'] = 'Nu există altă secţiune pentru a muta acest subiect!';
$txt['topic_already_moved'] = 'Subiectul %1$s a fost mutat în aria %2$s, Verifică noua locație înainte de a-l muta din nou.';

$txt['already_activated'] = 'Am dori să-ți procesăm solicitarea dar contul tău a fost deja activat.';
$txt['still_awaiting_approval'] = 'Acest cont încă asteaptă aprobarea administratorului.';

$txt['invalid_email'] = 'Adresa / clasa de adrese de email nu este validă.<br />Exemplu de adresă validă: evil.user@badsite.com<br />Exemplu de clasă de adrese validă: *@*.badsite.com';
$txt['invalid_expiration_date'] = 'Data expirării nu este validă';
$txt['invalid_hostname'] = 'Numele domeniului / subdomeniilor nu sunt valide.<br />Exemplu de nume de subdomeniu valid: proxy4.badhost.com<br />Exemplu de nume de domeniu valid: *.badhost.com';
$txt['invalid_ip'] = 'Adresa / clasa de adrese IP este invalidă.<br />Exemplu de adresă IP validă: 127.0.0.1<br />Exemplu de clasă de adrese IP validă: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Adresa / clasa de adrese IP este invalidă.<br />Exemplu de adresă IP validă: 127.0.0.1<br />Exemplu de clasă de adrese IP validă: 127.0.0.*';
$txt['invalid_username'] = 'Numele utilizatorului nu a fost găsit';
$txt['no_user_selected'] = 'Membrul nu a fost găsit';
$txt['no_ban_admin'] = 'Hei, nu poți să banezi un admin! Dacă ești sigur că asta vrei, mai întâi elimină-i drepturile de administrare.';
$txt['no_bantype_selected'] = 'Nu ai ales tipul de interdicție';
$txt['ban_not_found'] = 'Interdicția nu a fost găsită';
$txt['ban_unknown_restriction_type'] = 'Tipul de restricţie este necunoscut';
$txt['ban_name_empty'] = 'Nu a fost completat numele interdicției';
$txt['ban_id_empty'] = 'Nu poate fi găsit acest ID de interdicție';
$txt['ban_group_id_empty'] = 'Un grup de interdicții are nevoie de un ID de grup însă acest grup nu avea.';
$txt['ban_no_triggers'] = 'Ai uitat să alegi declanșatoarele de interdicție? E nevoie de minim unul.';
$txt['ban_ban_item_empty'] = 'Declanșatorul de interdicție nu a fost găsit';
$txt['impossible_insert_new_bangroup'] = 'A apărut o eroare la inserarea noii interdicții';

$txt['like_heading_error'] = 'Eroare la Likes';
$txt['like_wait_time'] = 'Nu poți repeta o acțiune Like fără să aștepți %1$s %2$s.';
$txt['like_unlike_error'] = 'A apărut o eroare la aprecierea unui mesaj.';
$txt['cant_like_yourself'] = 'Să-ți ”placă” propriile postări e ca și cum ai râde de unul singur la propriile glume, LOL...
Stai puțin, tocmai am râs de gluma mea?!';

$txt['ban_name_exists'] = 'Denumirea acestei interdicții (%1$s) există deja. Alege alt nume.';
$txt['ban_trigger_already_exists'] = 'Acest declanşator de interdicție (%1$s) există deja în %2$s. ';
$txt['attach_check_nag'] = 'Nu pot continua din cauză că datele (%1$s) sunt incomplete.';

$txt['recycle_no_valid_board'] = 'Nu ai selectat o secţiune validă pentru subiecte reciclate.';
$txt['post_already_deleted'] = 'Subiectul / mesajul a fost deja mutat în ariea de reciclare. Ești sigur că vrei să-l ștergi permanent?<br />Dacă da, urmează <a href="%1$s">acest link</a>';

$txt['login_threshold_fail'] = 'Ai depaşit numărul de încercări de autentificare. Încearcă mai târziu.';
$txt['login_threshold_brute_fail'] = 'Ai atins pragul de încercări de autentificare. Așteaptă 30 de secunde înainte să încerci din nou.';

$txt['who_off'] = 'Momentan lista ”Cine e Online” este dezafectată.';

$txt['merge_create_topic_failed'] = 'Crearea unui subiect nou a eșuat.';
$txt['merge_need_more_topics'] = 'Contopirea subiectelor necesită cel puțin două subiecte. Mai încearcă.';

$txt['post_WaitTime_broken'] = 'Ultima postare de la IP-ul tău a avut loc cu mai puţin de %1$d secunde în urmă. Încearcă din nou mai târziu. ';
$txt['register_WaitTime_broken'] = 'Te-ai nregistrat deja acum %1$d secunde!';
$txt['login_WaitTime_broken'] = 'Trebuie să mai astepţi %1$d secunde pentru a te autentifica din nou.';
$txt['pm_WaitTime_broken'] = 'Ultimul mesaj personal de la IP-ul tău a avut loc cu mai puţin de %1$d secunde în urmă. Încearcă din nou mai târziu. ';
$txt['reporttm_WaitTime_broken'] = 'Ultima raportare a unui mesaj personal de la IP-ul tău a avut loc cu mai puţin de %1$d secunde în urmă. Încearcă din nou mai târziu. ';
$txt['sendtopic_WaitTime_broken'] = 'Ultimul subiect de discuție înițiat de la IP-ul tău a avut loc cu mai puţin de %1$d secunde în urmă. Încearcă din nou mai târziu. ';
$txt['sendmail_WaitTime_broken'] = 'Ultimul e-mail trimis de la IP-ul tău a fost cu mai puţin de %1$d secunde în urmă. Încearcă din nou mai târziu.
';
$txt['search_WaitTime_broken'] = 'Ultima ta căutare a avut loc cu mai puţin de %1$d secunde în urmă. Încearcă din nou mai târziu. ';
$txt['remind_WaitTime_broken'] = 'Ultimul memento a fost cu mai puțin de %1$d secunde în urmă. Încearcă din nou mai târzu.';
$txt['contact_WaitTime_broken'] = 'Ai folosit formularul de contact cu %1$d secunde în urmă. Încearcă din nu mai târziu.';

$txt['topic_gone'] = 'Ariea pe care o cauți fie nu există fie nu ai dreptul să o vezi.';
$txt['theme_edit_missing'] = 'Nu a fost găsit fișierul pe care vrei să-l editezi.';

$txt['no_dump_database'] = 'Nu poți face copii de siguranță la baza de date. Doar administratorii pot.';
$txt['pm_not_yours'] = 'Mesajul personal pe care vrei îl citaezi nu există sau nu este al tău., Te rog mergi înapoi şi încearcă din nou.';
$txt['mangled_post'] = 'A avut loc o eroare -întoarce-ţe şi să încearcă din nou.';
$txt['too_many_groups'] = 'Ai selectat prea multe grupuri, elimină câteva.';
$txt['post_upload_error'] = 'Lipsesc datele POST. Eroarea poate fi produsă de încercarea de a încărca un fișier mai mare decât limita admisă de server. Contactează administratorul dacă problema persistă.';
$txt['quoted_post_deleted'] = 'Mesajul pe care încerci să-l citezi nu există, a fost șters sau nu îți mai este accesibil.';
$txt['pm_too_many_per_hour'] = 'Ai depăşit limita maximă de %1$d mesaje personale pe oră.';
$txt['labels_too_many'] = 'Ne pare rău, %1$s mesaje au adunat deja numărul maxim de etichete permise !';

$txt['register_only_once'] = 'Nu ai dreptul să înregistrezi mai multe conturi de utilizator de pe acelaşi calculator în acelaşi timp.';
$txt['admin_setting_coppa_require_contact'] = 'Trebuie să introduci o adresă poştală sau un număr de telefon dacă este necesară aprobarea unui părinte / tutore.';

$txt['error_long_name'] = 'Numele pe care încerci să-l folosești este prea lung.';
$txt['error_no_name'] = 'Nu ai introdus nici un nume.';
$txt['error_bad_name'] = 'Numele introdus nu se poate folosi deoarece conţine un nume rezervat.';
$txt['error_no_email'] = 'Nu ai introdus nici o adresă de email.';
$txt['error_bad_email'] = 'Ai introdus o adresă de email greşită.';
$txt['error_email'] = 'adresă de email';
$txt['error_message'] = 'mesaj';
$txt['error_no_event'] = 'Nu ai introdus nici un nume de eveniment.';
$txt['error_no_subject'] = 'Nu ai completat subiectul.';
$txt['error_no_question'] = 'Nu ai introdus nici o întrebare pentru acest sondaj.';
$txt['error_no_message'] = 'Corpul mesajului este gol.';
$txt['error_long_message'] = 'Mesajul depăşeşte numărul maxim de caractere admis (%1$d caractere).';
$txt['error_no_comment'] = 'Câmpul de comentariu a fost lăsat necompletat.';
$txt['error_post_too_long'] = 'Mesajul tău e prea lung. Introdu maxim 255 de caractere.';
$txt['error_session_timeout'] = 'Sesiunea a expirat în timpul scrierii mesajului. Încearcă să retrimiti mesajul.';
$txt['error_no_to'] = 'Nu ai specificat destinatarul.';
$txt['error_bad_to'] = 'Unul sau mai mulţi destinatari \'to\' nu au fost găsiţi.';
$txt['error_bad_bcc'] = 'Unul sau mai mulţi destinatari \'bcc\' nu au fost găsiţi.';
$txt['error_form_already_submitted'] = 'Ai trimis deja această postare! Poate ai dat din greșeală dublu-click sau ai reîmprospătat pagina.';
$txt['error_poll_few'] = 'Trebuie să ai măcar două opţiuni!';
$txt['error_poll_many'] = 'Nu poți avea mai mult de 256 de opțiuni.';
$txt['error_need_qr_verification'] = 'Completează secţiunea de verificare de mai jos pentru a finaliza postarea.';
$txt['error_wrong_verification_code'] = 'Literele pe care le-ai introdus nu corespund cu cele din imagine .';
$txt['error_wrong_verification_answer'] = 'Nu ai răspuns corect la întrebările de verificare .';
$txt['error_need_verification_code'] = 'Introdu codul de verificare de mai jos pentru a vedea rezultatele.';
$txt['error_bad_file'] = 'Fișierul specificat nu poate fi deschis: %1$s';
$txt['error_bad_line'] = 'Linia specificată nu este validă.';
$txt['error_draft_not_saved'] = 'A apărut o eroare la salvarea ciornei';
$txt['error_name_in_use'] = 'Numele %1$s este folosit deja de un alt membru.';

$txt['smiley_not_found'] = 'Emoticonul nu a fost găsit.';
$txt['smiley_has_no_code'] = 'Nu ai introdus un cod pentru acest emoticon.';
$txt['smiley_has_no_filename'] = 'Nu a fost introdus un nume de fișier pentru acest emoticon.';
$txt['smiley_not_unique'] = 'Un emoticon cu acest cod există deja.';
$txt['smiley_set_already_exists'] = 'Există deja un set de emoticoane cu acel URL';
$txt['smiley_set_not_found'] = 'Setul de emoticoane nu a fost găsit';
$txt['smiley_set_dir_not_found'] = 'Directorul pentru setul de emoticoane %1$s fie nu este valid fie nu poate fi accesat';
$txt['smiley_set_path_already_used'] = 'Un alt set de emoticoane foloseşte deja acest URL.';
$txt['smiley_set_unable_to_import'] = 'Imposibil de importat setul de emoticoane. Directorul nu este valid sau nu poate fi accesat.';

$txt['smileys_upload_error'] = 'Încărcarea fișierului a eșuat.';
$txt['smileys_upload_error_blank'] = 'Toate seturile de emoticoane trebuie să aibe o imagine.';
$txt['smileys_upload_error_name'] = 'Toate emoticoanele trebuie să aibe același nume de fișier.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Tip ilegal.';

$txt['search_invalid_weights'] = 'Ponderile de căutare nu sunt configurate corect. Cel puțin o pondere trebuie să fie diferită de zero. Te rog raportează acest incident administratorului!';

$txt['package_no_file'] = 'Fișierul pachetului nu a putut fi găsit!';
$txt['packageget_unable'] = 'Serverul nu poate fi contactat.  Încearcă să folosești  <a href="%1$s" target="_blank" class="new_win">acest URL</a>.';
$txt['not_valid_server'] = 'Pachetele pot fi descărcate în acest mod doar de pe servere pe care mai întâi le-ai autorizat.';
$txt['package_cant_uninstall'] = 'Acest pachet ori nu a fost instalat niciodată ori l-ai dezinstalat deja - este imposibilă dezinstalarea lui în acest moment.';
$txt['package_cant_download'] = 'Nu poți descărca sau instala pachete noi pentru că directorul &quot;pachetelor&quot; sau unul din fișierele pe care le conține nu pot fi deschise cu drept de scriere!';
$txt['package_upload_error_nofile'] = 'Nu ai selectat pachetul pe care să-l încarc.';
$txt['package_upload_error_failed'] = 'Pachetul nu a putut fi încărcat, verifică drepturile directorului !';
$txt['package_upload_error_exists'] = 'Fișierul pe care vrei să-îl încarci există deja pe server. Șterge-l întâi și încearcă din nou.';
$txt['package_upload_already_exists'] = 'Pachetul pe care vrei să-îl încarci există deja pe server, cu numele de fișier: %1$s.';
$txt['package_upload_error_supports'] = 'Managerul de pachete permite doar următoarele tipuri de fişiere: %1$s.';
$txt['package_upload_error_broken'] = 'Încărcarea pachetului a eșuat, cu următoarea eroare:<br />&quot;%1$s&quot;';

$txt['package_get_error_not_found'] = 'Pachetul pe care vrei să-l încarci nu a putut fi localizat. Poți să-l încarci manual, în directorul de &quot;pachete&quot;.';
$txt['package_get_error_missing_xml'] = 'Din pachetul pe care încercaţi să-l instalaţi lipseşte fișierul package-info.xml care trebuie să fie în directorul rădăcină al pachetului.';
$txt['package_get_error_is_zero'] = 'Deși pachetul a fost descărcat pe server, pare să fie gol. Verifică dacă directorul &quot;packages&quot; și subdirectorul &quot;temp&quot; au drepturi de scriere. Dacă mai întâmpini această problemă ar trebui să încerci să dezarhivezi pachetul pe PC, să încarci fișierele dezarhivate într-un subdirector al directorului &quot;packages&quot; și să încerci din nou. De exemplu, dacă packetul se numește shout.tar.gs, va trebui să:<br />1) Descarci pachetul pe PC-ul local și să dezarhivezi conținutul.<br />2) Creezi un nou director în folderul &quot;packages&quot; cu un client FTP (în cazul de față, poți numi directorul creat ”shout”).<br />3) Încarci toate fișierele dezarhivate în acest nou director.<br />4) Accesezi pagina managerului de pachete. Pachetul va fi detectat automat.';
$txt['package_get_error_packageinfo_corrupt'] = 'În fișierul package-info.xml inclus în pachet nu au fost găsite informații valide. Poate fi o eroare a add-on-ului sau pachetul poate fi corupt.';
$txt['package_get_error_is_theme'] = 'Nu poți instala teme de aici, mergi la pagina de <a href="{MANAGETHEMEURL}">Administrare teme</a> pentru a o încărca.';

$txt['no_membergroup_selected'] = 'Nu a fost selectat nici un grup membru';
$txt['membergroup_does_not_exist'] = 'Grupul membru nu există sau nu este valid.';

$txt['at_least_one_admin'] = 'Trebuie să existe cel puţin un administrator pe forum!';

$txt['error_functionality_not_windows'] = 'Ne pare rău, această funcţionalitate nu este disponibilă pentru serverele care rulează Windows. ';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Ataşamentul nu a fost găsit';

$txt['error_no_boards_selected'] = 'Nu a fost selectată o arie validă';
$txt['error_invalid_search_string'] = 'Ai uitat să introduci termenii ce trebuie căutați?';
$txt['error_invalid_search_string_blacklist'] = 'Termenii căutării tale conțin cuvinte comune. Încearcă din nou cu termeni mai specifici.';
$txt['error_search_string_small_words'] = 'Fiecare cuvânt trebuie să conţină minim două litere.';
$txt['error_query_not_specific_enough'] = 'Nu s-a găsit nici un rezultat.';
$txt['error_no_messages_in_time_frame'] = 'Nu s-a găsit nici un mesaj în intervalul de timp selectat.';
$txt['error_no_labels_selected'] = 'Nu a fost selectată nici o etichetă.';
$txt['error_no_search_daemon'] = 'Imposibil de accesat programul de căutare';

$txt['profile_errors_occurred'] = 'Încercarea de actualizare a profilului tău a generat următoarele erori';
$txt['profile_error_bad_offset'] = 'Fusul orar este incorect';
$txt['profile_error_no_name'] = 'Câmpul Nume a rămas gol';
$txt['profile_error_digits_only'] = 'Câmpul \'numărul de mesaje\' poate conţine doar cifre.';
$txt['profile_error_name_taken'] = 'Numele de utilizator/Numele afișat ales de tine este folosit deja de altcineva';
$txt['profile_error_name_too_long'] = 'Numele selectat este prea lung, acesta nu trebuie să depăşească 60 de caractere';
$txt['profile_error_no_email'] = 'Campul email a rămas gol';
$txt['profile_error_bad_email'] = 'Nu ai introdus o adresă de email corectă';
$txt['profile_error_email_taken'] = 'Există deja un alt utilizator înregistrat cu această adresă de email';
$txt['profile_error_no_password'] = 'Nu ai introdus parola';
$txt['profile_error_bad_new_password'] = 'Parolele noi introduse nu se potrivesc';
$txt['profile_error_bad_password'] = 'Parola introdusă nu este corectă';
$txt['profile_error_bad_avatar'] = 'Avatarul pe care l-ai selectat este prea mare sau nu este un avatar';
$txt['profile_error_password_short'] = 'Parola trebuie să conțină minim %1$s caractere.';
$txt['profile_error_password_restricted_words'] = 'Parola ta nu trebuie să conțină numele tău de utilizator, adresa ta de email sau cuvinte comune.';
$txt['profile_error_password_chars'] = 'Parola trebuie să conţină caractere majuscule, minuscule si cifre.';
$txt['profile_error_already_requested_group'] = 'Aveţi deja o cerere depusă pentru acest Grup!';
$txt['profile_error_openid_in_use'] = 'Un alt utilizator foloseşte deja acest URL de autentificare OpenID ';
$txt['profile_error_signature_not_yet_saved'] = 'Semnătura nu a fost salvată.';
$txt['profile_error_personal_text_too_long'] = 'Textul personal este prea lung.';
$txt['profile_error_user_title_too_long'] = 'Titlul personalizat este prea lung.';

$txt['mysql_error_space'] = ' - verificaţi spaţiul de stocare a datelor sau contactaţi administratorul.';

$txt['icon_not_found'] = 'Pictograma nu a fost gasită în tema implictă - verificaţi dacă a fost încărcată si încercaţi din nou.';
$txt['icon_after_itself'] = 'Iconița nu poate fi poziționată după ea însăși.';
$txt['icon_name_too_long'] = 'Numele fișierului cu iconițe nu poate avea mai mult de 16 caractere.';

$txt['name_censored'] = 'Ne pare rău, numele pe care a-ţi încercat să îl folosiţi,  %1$s, conţine cuvinte cenzurate. Vă rugăm să încercaţi să folosiţi un alt nume.';

$txt['poll_already_exists'] = 'Unui subiect nu i se poate asocia mai mult de un sondaj.';
$txt['poll_not_found'] = 'Nu există nici un sondaj asociat cu acest subiect!';

$txt['error_while_adding_poll'] = 'În timpul adăugării sondajului a(u) apărut următoare(le)a ero(ri)are';
$txt['error_while_editing_poll'] = 'În timpul editării sondajului a(u) apărut următoare(le)a ero(ri)are';

$txt['loadavg_search_disabled'] = 'Datorită încărcării mari a serverului, funcţia Căutare a fost automat dezactivată pentru o scurtă perioadă de timp. Vă rugăm să încercaţi un pic mai tărziu.';
$txt['loadavg_generic_disabled'] = 'Datorită încărcării mari a serverului, acestă facilitate este momentan indisponibilă.';
$txt['loadavg_allunread_disabled'] = 'Resursele serverului suferă momentan de o încărcare prea mare, în încercarea de a găsi toate subiectele pe care nu le-ai citit.';
$txt['loadavg_unreadreplies_disabled'] = 'Acest server este momentan foarte încărcat.  Vă rugăm să încercaţi după o scurtă perioadă de timp.';
$txt['loadavg_show_posts_disabled'] = 'Vă rugăm să încercaţi mai tarziu.  Mesajele acestui utilizator nu sunt accesibile datorită încărcării mari a serverului.';
$txt['loadavg_unread_disabled'] = 'Resursele serverului suferă momentan de o încărcare prea mare, în încercarea de a afișa toate subiectele pe care nu le-ai citit.';
$txt['loadavg_userstats_disabled'] = 'Încearcă mai târziu. Statisticile acestui membru nu sunt disponibile momentat datărită încărcării mari a serverului.';

$txt['cannot_edit_permissions_inherited'] = 'Nu poți edita direct drepturile moștenite. Trebuie să editezi fie grupul părinte, fie moștenirea de grup.';

$txt['mc_no_modreport_specified'] = 'Trebuie să specificaţi ce raport doriţi să vizualizaţi.';
$txt['mc_no_modreport_found'] = 'Raportul solicitat fie nu există fie nu aveţi drepturi suficiente pentru a-l vizualiza';

$txt['st_cannot_retrieve_file'] = 'Nu s-a putut obţine fişierul %1$s.';
$txt['admin_file_not_found'] = 'Nu s-a putut încărca fişierul: %1$s.';

$txt['themes_none_selectable'] = 'Trebuie să selectaţi cel puţin o temă.';
$txt['themes_default_selectable'] = 'Tema implicită pentru forum trebuie să fie una selectabilă.';
$txt['ignoreboards_disallowed'] = 'Opţiunea de ignorare a secţiunilor nu este activă.';

$txt['mboards_delete_error'] = 'Nici o categorie selectată.';
$txt['mboards_delete_board_error'] = 'Nici o arie selectată.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'Nu poți transforma un părinte în propriul său copil.';
$txt['mboards_board_own_child_error'] = 'Nu poți transforma o arie în propria sa subarie.';

$txt['smileys_upload_error_notwritable'] = 'Următorul director de stocare a emoticoanelor nu are setate drepturi de scriere: %1$s';
$txt['smileys_upload_error_types'] = 'Emoticoanele pot avea doar următoarele extensii: %1$s.';

$txt['change_email_success'] = 'Adresa ta de email a fost schimbată şi un email de activare a fost trimis către adresa nouă.';
$txt['resend_email_success'] = 'S-a trimis cu succes un email pentru o nouă activare.';

$txt['custom_option_need_name'] = 'Opțiunea pentru profil trebuie să aibă un nume.';
$txt['custom_option_not_unique'] = 'Numele câmpului nu e unic.';
$txt['custom_option_regex_error'] = 'Expresia regulată introdusă nu e validă';

$txt['warning_no_reason'] = 'Trebuie să specifici un motiv pentru care modifici nivelul de avertizare a unui utilizator';
$txt['warning_notify_blank'] = 'Ai ales să notifici utilizatorul, dar nu ai completat câmpurile subiect/mesaj';

$txt['cannot_connect_doc_site'] = 'Site-ul cu documentații nu poate fi contactat. Verifică dacă serverul tău permite conexiuni Internet externe și încearcă mai târziu.';

$txt['movetopic_no_reason'] = 'Trebuie să introduci motivul pentru care muti subiectul de discuţie sau să debifezi opţiunea de a "publica un subiect redirecţionare".';
$txt['movetopic_no_board'] = 'Trebuie să alegi o arie în care să muți subiectul.';

$txt['splittopic_no_reason'] = 'Trebuie să introduci un motiv pentru scindarea subiectului sau să debifezi caseta opțiunii \'postează un mesaj de redirectare\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Identificatorul solicitat nu a returnat informaţiile necesare.';
$txt['openid_return_no_mode'] = 'Providerul de identitate nu a răspuns cu un OpenID.';
$txt['openid_not_resolved'] = 'Providerul de identitate nu a aprobat cererea ta.';
$txt['openid_no_assoc'] = 'Nu s-a găsit asocierea solicitată la providerul de identitate.';
$txt['openid_sig_invalid'] = 'Semnătura de la providerul de identitate este invalidă.';
$txt['openid_load_data'] = 'Nu s-au putut încărca datele pentru cererea de login. Te rog încearcă mai târziu.';
$txt['openid_not_verified'] = 'OpenID-ul furnizat nu a fost verificat încă. Autentifică-te în forum pentru verificare.';

$txt['error_custom_field_too_long'] = 'Câmpul &quot;%1$s&quot; nu poate fi mai mare de %2$d caractere în lungime.';
$txt['error_custom_field_invalid_email'] = 'Câmpul &quot;%1$s&quot; trebuie să fie o adresa de email validă.';
$txt['error_custom_field_not_number'] = 'Câmpul &quot;%1$s&quot; trebuie să fie un număr.';
$txt['error_custom_field_inproper_format'] = 'Câmpul &quot;%1$s&quot; are un format invalid.';
$txt['error_custom_field_empty'] = 'Câmpul &quot;%1$s&quot; nu poate fi lăsat gol.';

$txt['email_no_template'] = 'Nu s-a găsit nici un email cu această structură &quot;%1$s&quot; .';

$txt['search_api_missing'] = 'API-ul de căutare nu a putut fi găsit. Contactează administratorul și verifică dacă a încărcat fișierele corecte.';
$txt['search_api_not_compatible'] = 'API-ul de căutare selectat folosit de forum este depășit - recurg la căutarea standard. Verifică fișierul %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Nu poţi restaura primul mesaj dintr-un subiect.';
$txt['restored_disabled'] = 'Restaurarea subiectelor a fost dezactivată.';
$txt['restore_not_found'] = 'Următoarele mesaje nu au putut fi restaurate; subiectul original e posibil să fi fost eliminat: %1$s Va trebui să muți aceste mesaje manual.';

$txt['error_invalid_dir'] = 'Directorul ales este invalid.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'Sub-acțiunea solicitată nu este definită.';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'Nu au fost găsite elemente care să poată fi sortate';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
