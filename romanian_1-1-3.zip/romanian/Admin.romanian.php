<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Arii';
$txt['admin_back_to'] = 'Înapoi la panoul de administrare';
$txt['admin_users'] = 'Membri';
$txt['admin_newsletters'] = 'Buletine de știri';
$txt['include_these'] = 'Membri incluși ca destinatari';
$txt['exclude_these'] = 'Membri excluși ca destinatari';
$txt['admin_newsletters_select_groups'] = 'Grupuri incluse ca destinatare';
$txt['admin_newsletters_exclude_groups'] = 'Grupuri excluse ca destinatare';
$txt['admin_edit_news'] = 'Știri';
$txt['admin_groups'] = 'Grupuri de membri';
$txt['admin_members'] = 'Gestionează membrii';
$txt['admin_members_list'] = 'Mai jos este lista tuturor membrilor înregistraţi în prezent pe forum.';
$txt['admin_next'] = 'Următorul';
$txt['admin_censored_words'] = 'Cuvinte cenzurate';
$txt['admin_censored_where'] = 'Introdu cuvintele ce trebuiesc cenzurate în caseta din stânga și cuvintele cu care trebuiesc înlocuite în caseta din dreapta. Apoi alege dacă dorești să verifici doar cuvintele intregi și/sau scrierea cu majuscule.';
$txt['admin_censored_desc'] = 'Datorită caracterului public al forumului, poate dorești să previi publicarea de către utilizatori a anumitor cuvinte. Mai jos poți introduce cuvintele care dorești să fie cenzurate atunci când sunt  scrise de membri.<br />Debifează o casetă pentru a elimina cenzurarea cuvântului respectiv. ';
$txt['admin_reserved_names'] = 'Nume rezervate';
$txt['admin_template_edit'] = 'Editează șablonul forumului';
$txt['admin_modifications'] = 'Setări pentru Add-on-uri';
$txt['admin_security_moderation'] = 'Securitate și Moderare';
$txt['admin_server_settings'] = 'Setări pentru server';
$txt['admin_reserved_set'] = 'Definește numele rezervate';
$txt['admin_reserved_line'] = 'Câte un cuvânt rezervat pe fiecare linie.';
$txt['admin_basic_settings'] = 'Această pagină îți permite să modifici setările de bază ale forumului. Ai foarte mare grijă la aceste setări pentru că poți face forumul nefuncțional!';
$txt['admin_maintain'] = 'Intră în modul Mentenanță';
$txt['admin_title'] = 'Titlul forumului';
$txt['admin_url'] = 'URL-ul forumului';
$txt['cookie_name'] = 'Numele cookie-ului';
$txt['admin_webmaster_email'] = 'Adresa de email a administratorului';
$txt['boarddir'] = 'Directorul pentru ElkArte';
$txt['sourcesdir'] = 'Directorul pentru fișiere-sursă (Sources)';
$txt['cachedir'] = 'Directorul pentru cache';
$txt['admin_news'] = 'Permite afișarea știrilor';
$txt['admin_guest_post'] = 'Permite postarea de către vizitatori';
$txt['admin_manage_members'] = 'Membri';
$txt['admin_main'] = 'General';
$txt['admin_config'] = 'Configurare';
$txt['admin_version_check'] = 'Verificarea detaliată a versiunii';
$txt['admin_elkfile'] = 'Fișierul ElkArte';
$txt['admin_elkpackage'] = 'Pachetul ElkArte';
$txt['admin_logoff'] = 'Încheie sesiunea de administrare';
$txt['admin_maintenance'] = 'Mentenanță';
$txt['admin_image_text'] = 'Arată butoanele ca imagini, în loc de text';
$txt['admin_credits'] = 'Autori și Credite';
$txt['admin_agreement'] = 'La înregistrare prezintă scrisoarea de aderare și solicită în mod obligatoriu acceptarea termenilor conținuți de aceasta ';
$txt['admin_checkbox_agreement'] = 'La înregistrare arată o casetă de bifare pentru exprimarea acordului în locul unei pagini întregi';
$txt['admin_checkbox_accept_agreement'] = 'Forțează toți membrii să accepte această nouă versiune a acordului la următoarea accesare a forumului';
$txt['admin_agreement_default'] = 'Implicit';
$txt['admin_agreement_select_language'] = 'Fişierele de traduceri pe care vrei să le modifici.';
$txt['admin_agreement_select_language_change'] = 'Modifică';

$txt['admin_privacypol'] = 'La înregistrare prezintă politica de confidențialitate și solicită în mod obligatoriu aceptarea ei.';
$txt['admin_checkbox_accept_privacypol'] = 'Forțează toți membrii să accepte această nouă versiune a politicii de confidențialitate la următoarea accesare a forumului';

$txt['admin_delete_members'] = 'Șterge membrii selectați';
$txt['admin_change_primary_membergroup'] = 'Schimbă grupul primar';
$txt['admin_change_secondary_membergroup'] = 'Schimbă/adaugă grupuri adiționale';
$txt['confirm_remove_membergroup'] = 'Această selecție va șterge toate grupurile! Ești sigur?';
$txt['confirm_change_primary_membergroup'] = 'Ești sigur că vrei să modifici grupul primar al membrilor selectați?';
$txt['confirm_change_secondary_membergroup'] = 'Ești sigur că vrei să modifici grupul adițional al membrilor selectați?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Repară toate ariile și subiectele de discuție';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Introdu câte o știre în fiecare casetă. În știri sunt permise tag-urile BBC, precum <span>[b]</span>, <span>[i]</span> and <span>[u]</span> precum și smileys. Pentru a înlătura o știre, șterge textul din caseta acesteia.';
$txt['administrators'] = 'Administratorii forumului';
$txt['admin_reserved_desc'] = 'Rezervarea numelor va împiedica membrii să se înregistreze cu anumite nume de utilizator sau să folosească aceste cuvinte în cadrul numelor afișate pe forum. Înainte de finalizare, alege opțiunile pe care vrei să le utilizezi de la sfârșitul paginii.';
$txt['admin_activation_email'] = 'Trimite membrilor noi un email de activare după înregistrare';
$txt['admin_match_whole'] = 'Compară cuvântul întreg. Dacă e debifat, caută în interiorul cuvintelor.';
$txt['admin_match_case'] = 'Ține cont de majuscule. Dacă e debifat, căutarea înterpretează identic literele mari și literele mici.';
$txt['admin_check_user'] = 'Verifică numele de utilizator.';
$txt['admin_check_display'] = 'Verifică numele afișat.';
$txt['admin_newsletter_send'] = 'Din această pagină poți trimite email-uri. Adresele de email ale grupurilor de membri selectate vor apărea mai jos dar poți elimina sau adăuga orice adresă de email dorești. Asigură-te că adresele sunt scrise sub forma: \'adresă1; adresă2\'.';
$txt['admin_fader_delay'] = 'Durata afișării fiecărei știri, pentru fader-ul de știri';
$txt['zero_for_no_limit'] = '(0 pentru nelimitat)';
$txt['zero_to_disable'] = '(0 pentru invalidare)';

$txt['admin_backup_fail'] = 'Efectuarea copiei de rezervă pentru Setings.php a eșuat - verifică dacă Settings_bak.php există și dacă poate fi modificat.';
$txt['modSettings_info'] = 'Setările pentru Funcționalități generale, Karma, Semnături, Likes și multe altele, ce controlează modul de operare al forumului.';
$txt['database_server'] = 'Serverul pentru baza de date';
$txt['database_user'] = 'Utilizatorul pentru baza de date';
$txt['database_password'] = 'Parola pentru baza de date';
$txt['database_name'] = 'Numele bazei de date';
$txt['registration_agreement'] = 'Acordul de înregistrare';
$txt['registration_agreement_desc'] = 'Acest acord este prezentat când un utilizator își înregistrează un cont pe forum; trebuie acceptat de utilizator pentru a putea continua procedura de înregistrare.';
$txt['privacy_policy'] = 'Politica de confidențialitate';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Prefixul bazei de date';
$txt['errors_list'] = 'Lista erorilor forumului';
$txt['errors_found'] = 'Forumul este afectat de următoarele erori';
$txt['errors_fix'] = 'Vrei să încerci repararea acestor erori?';
$txt['errors_do_recount'] = 'Toate erorile au fost corectate - o zonă de recuperare a fost creată! Te rog fă click pe butonul de mai jos pentru a renumăra unele statistici cheie.';
$txt['errors_recount_now'] = 'Refă statisticile';
$txt['errors_fixing'] = 'Repar erorile din forum';
$txt['errors_fixed'] = 'Toate erorile au fost îndepărtate. Verifică toate categoriile, ariile și subiectele create și decide ce dorești să faci cu ele.';
$txt['attachments_avatars'] = 'Atașamente și Avataruri';
$txt['attachments_desc'] = 'De aici poți administra fișierele atașate din sistem. Poți selecta atașamentele pentru ștergere după dimensiune sau după dată. Statistica atașamentelor este prezentate mai jos.';
$txt['attachment_stats'] = 'Statistica fișierelor atașate';
$txt['attachment_integrity_check'] = 'Verifică integritatea atașamentelor';
$txt['attachment_integrity_check_desc'] = 'Această funcție va verifica integritatea și dimensiunea atașamentelor și numelor de fișiere listate în baza de date și, la nevoie, va repara erorile pe care le întâlnește.';
$txt['attachment_check_now'] = 'Verifică acum';
$txt['attachment_pruning'] = 'Curățarea atașamentelor';
$txt['attachment_pruning_message'] = 'Mesajul de adăugat la postare';
$txt['attachment_pruning_warning'] = 'Ești sigur că vrei să ștergi aceste atașamente?\\nAceastă acțiune este ireversiblă!';

$txt['attachment_total'] = 'Numărul total de atașamente';
$txt['attachmentdir_size'] = 'Dimensiunea totală a tuturor directoarelor pentru atașamente';
$txt['attachmentdir_size_current'] = 'Dimensiunea totală a directorului curent pentru atașamente';
$txt['attachmentdir_files_current'] = 'Numărul total de fișiere în directorul pentru atașamente curent';
$txt['attachment_space'] = 'Spațiul disponbil total';
$txt['attachment_files'] = 'Numărul rămas de fișiere';

$txt['attachment_options'] = 'Opțtiuni pentru fișierele atașate';
$txt['attachment_log'] = 'Jurnalul atașamentelor';
$txt['attachment_remove_old'] = 'Șterge atașamentele mai vechi de %1$s zile';
$txt['attachment_remove_size'] = 'Șterge atașamentele mai mari de %1$s KiB';
$txt['attachment_name'] = 'Numele atașamentului';
$txt['attachment_file_size'] = 'Dimensiunea fișierului';
$txt['attachmentdir_size_not_set'] = 'Dimensiunea maximă a directorului nu este setată';
$txt['attachmentdir_files_not_set'] = 'Numărul mazim de fișiere în director nu este setat';
$txt['attachment_delete_admin'] = '[atașament șters de administrator]';
$txt['live'] = 'Ultimele actualizări';
$txt['remove_all'] = 'Golește jurnalul';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(mai detaliat)';

$txt['lfyi'] = 'Nu te poți conecta la fișierul cu ultimele știri ElkArte.';

$txt['manage_calendar'] = 'Calendar';
$txt['manage_search'] = 'Căutări';
$txt['viewmembers_online'] = 'Activ ultima dată';

$txt['smileys_manage'] = 'Emoticoane și Pictograme';
$txt['smileys_manage_info'] = 'Instalează un set nou de emoticoane (smileys), adaugă emoticoane la seturile existente sau administrează pictogramele (icons).';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Instalează, descarcă  și încarcă pachete cu Modificări; verifică setările pentru drepturile de acces la fișiere și pentru FTP.';
$txt['theme_admin'] = 'Administrarea temelor';
$txt['theme_admin_info'] = 'Instalează teme noi, selectează temele disponibile utilizatorilor și setează sau resetează opțiunile temelor';
$txt['registration_center'] = 'Înregistrare';
$txt['member_center_info'] = 'Vezi lista membrilor, caută membri sau administrează aprobările și activările conturilor.';
$txt['viewmembers_online'] = 'Activ ultima dată';

$txt['display_name'] = 'Numele afișat';
$txt['email_address'] = 'Adresa de email';
$txt['ip_address'] = 'Adresa IP';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'necunoscut';
$txt['security_wrong'] = 'Încercare de autentificare ca administrator!<br />
Referer: %1$s<br />
User agent: %2$s<br />
IP: %3$s<br />';

$txt['email_as_html'] = 'Trimite în format HTML. (în acest mot poți pune HTML normal în email).';
$txt['email_parsed_html'] = 'Adaugă &lt;br /&gt; și &amp;nbsp; la acest mesaj.';
$txt['email_variables'] = 'În acest mesaj poți folosi câteva &quot;variabiles&quot;.<a href="{help_emailmembers}" class="help"> Click aici pentru informații suplimentare</a>.';
$txt['email_force'] = 'Trimite acest mesaj la membrei, chiar dacă aceștia au ales să nu primească anunțuri.';
$txt['email_as_pms'] = 'Trimite acest mesaj acestor grupuri folosin Mesaje Personale.';
$txt['email_continue'] = 'Continuă';
$txt['email_done'] = 'gata.';
$txt['email_members_succeeded'] = 'Buletinul informativ a fost trimis cu succes!';

$txt['ban_title'] = 'Lista interdicțiilor';
$txt['ban_ip'] = 'Interdicție IP (de ex. 192.168.12.213 or 128.0.*.*) - o înregistrare per linie';
$txt['ban_email'] = 'Interdicție email (de ex. badguy@somewhere.com) - o înregistrare per linie';
$txt['ban_username'] = 'Interdicție nume utilizator (de ex. l33tuser) - o înregistrare per linie';

$txt['ban_errors_detected'] = 'A apărut următoarea eroare în timpul salvării sau editării interdicției sau a declanșatorului';
$txt['ban_description'] = 'Aici poți restricționa accesu utilizatorilor problematici după IP, numele host-ului, numele de utilizator sau email';
$txt['ban_add_new'] = 'Adaugă o interdicție nouă';
$txt['ban_banned_entity'] = 'Entitatea restricționată';
$txt['ban_on_ip'] = 'Interdicție după IP (de ex. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Interdicție după hostname (de ex. *.mil)';
$txt['ban_on_email'] = 'Interdicție după email (de ex. *@badsite.com)';
$txt['ban_on_username'] = 'Interdicție după nume utilizator';
$txt['ban_notes'] = 'Note';
$txt['ban_restriction'] = 'Restricție';
$txt['ban_full_ban'] = 'Interdicție totală';
$txt['ban_partial_ban'] = 'Interdicție parțială';
$txt['ban_cannot_post'] = 'Nu poate posta';
$txt['ban_cannot_register'] = 'Nu se poate înregistra';
$txt['ban_cannot_login'] = 'Nu se poate autentifica';
$txt['ban_add'] = 'AdaugăAdaugă';
$txt['ban_edit_list'] = 'Lista interdicțiilor';
$txt['ban_type'] = 'Tipul interdicției';
$txt['ban_days'] = 'zi(le)';
$txt['ban_will_expire_within'] = 'Interdicția expiră după';
$txt['ban_added'] = 'Adăugat';
$txt['ban_expires'] = 'Expiră';
$txt['ban_hits'] = 'Încercări';
$txt['ban_actions'] = 'Acțiuni';
$txt['ban_expiration'] = 'Expirare';
$txt['ban_reason_desc'] = 'Motivul interdicției va fi afișat utilizatorului restricționat.';
$txt['ban_notes_desc'] = 'Note ce pot ajuta moderatorii.';
$txt['ban_remove_selected'] = 'Elimină-le pe cele selectate';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Ești sigur că vrei să elimini interdicțiile selectate?';
$txt['ban_modify'] = 'Modifică';
$txt['ban_name'] = 'Numele interdicției';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Editează interdicția';
$txt['ban_add_notes'] = '<strong>Notă</strong>: după crearea interdicției de mai sus, poți adăuga înregistrări suplimentare care declanșează interdicția, precum adrese IP, nume de host-uri și adrese de email.';
$txt['ban_expired'] = 'Expirat / invalidat';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Nici o restricție selectată.';

$txt['ban_triggers'] = 'Declanșatori';
$txt['ban_add_trigger'] = 'Adaugă un declanșator de interdicție';
$txt['ban_add_trigger_submit'] = 'AdaugăAdaugă';
$txt['ban_edit_trigger'] = 'Modifică';
$txt['ban_edit_trigger_title'] = 'Editează declanșatorul de interdicție';
$txt['ban_edit_trigger_submit'] = 'Modifică';
$txt['ban_remove_selected_triggers'] = 'Elimină declanșatoarele de interdicție selectate';
$txt['ban_no_entries'] = 'Momentan nu sunt interdicții în vigoare.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Ești sigur că dorești să elimini declanșatoarele de interdicții selectate?';
$txt['ban_trigger_browse'] = 'Răsfoiește declanșatoarele de interdicții';
$txt['ban_trigger_browse_description'] = 'Această pagină prezintă toate entitățile restricționate, grupate după adresă IP, hostname, adresă email și nume utilizator';

$txt['ban_log'] = 'Jurnalul interdicțiilor';
$txt['ban_log_description'] = 'Jurnalul interdicțiilor prezintă toate tentativele de acces la forum ale utilizatorilor restricționați (doar restricțiile \'Interdicție totală\' și \'Nu se poate înregistra\').';
$txt['ban_log_no_entries'] = 'În prezent nu sunt înregistrări în jurnalul de interdicţii.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'Adresă email';
$txt['ban_log_member'] = 'Membru';
$txt['ban_log_date'] = 'Dată';
$txt['ban_log_remove_all'] = 'Golește jurnalul';
$txt['ban_log_remove_all_confirm'] = 'Ești sigur că dorești șă ștergi toate înregistrările din jurnalul de interdicții?';
$txt['ban_log_remove_selected'] = 'Elimină-le pe cele selectate';
$txt['ban_log_remove_selected_confirm'] = 'Ești sigur că dorești șă ștergi toate înregistrările selectate din jurnalul de interdicții?';
$txt['ban_no_triggers'] = 'Momentan nu există declanșatori de intedicție.';

$txt['settings_not_writable'] = 'Aceste setări nu pot fi modificate pentru că Settings.php este read-only.';

$txt['maintain_title'] = 'Mentenanță forum';
$txt['maintain_info'] = 'Copii de rezervă elementare ale forumului, verificarea erorilor bazei de date, curățarea cache-ului și altele.';
$txt['maintain_sub_database'] = 'Baza de date';
$txt['maintain_sub_routine'] = 'Rutină';
$txt['maintain_sub_members'] = 'Membri';
$txt['maintain_sub_topics'] = 'Subiecte';
$txt['maintain_sub_attachments'] = 'Ataşamente';
$txt['maintain_done'] = 'Activitatea de mentenanță \'%1$s\' a fost executată cu succes.';
$txt['maintain_fail'] = 'Activitatea de mentenanță \'%1$s\' a eșuat.';
$txt['maintain_no_errors'] = 'Felicitări, nu a fost găsită nicio eroare!';

$txt['maintain_tasks'] = 'Activităţi planificate';
$txt['maintain_tasks_desc'] = 'Administrează toate activităţile programate';

$txt['scheduled_log'] = 'Jurnalul de activități';
$txt['scheduled_log_desc'] = 'Afișează jurnalele activităților care au fost rulate.';
$txt['admin_log'] = 'Jurnal de administrare';
$txt['admin_log_desc'] = 'Afișează activitățile administrative efectuate de administratorii forumului.';
$txt['moderation_log'] = 'Jurnalul de moderare';
$txt['moderation_log_desc'] = 'Listează activitătile de moderare efectuate de moderatorii forumului.';
$txt['badbehavior_log'] = 'Jurnalul BadBehavior';
$txt['badbehavior_log_desc'] = 'Listează solicitările care au fost blocate sau marcate ca suspicioase de BadBehavior. Dacă ați activat jurnalizarea detaliată, sunt listate toate solicitările HTTP.';
$txt['spider_log_desc'] = 'Jurnalul intrărilor legate de activitatea roboţilor trimişi de motoarele de căutare pe forum.';
$txt['pruning_log_desc'] = 'Foloseşte aceste unelte pentru a şterge înregistrări mai vechi din diverse jurnale.';

$txt['mailqueue_title'] = 'Mail';

$txt['db_error_send'] = 'Trimite e-mail-uri în caz de eroare de conectare la baza de date.';
$txt['db_persist'] = 'Utilizaţi o conexiune persistentă';
$txt['ssi_db_user'] = 'Numele de utilizator pentru baza de date în modul SSI';
$txt['ssi_db_passwd'] = 'Parola bazei de date pentru folosire în mod SSI';

$txt['default_language'] = 'Limba implicită pentru forum';

$txt['maintenance_subject'] = 'Subiect de afişat ';
$txt['maintenance_message'] = 'Mesaj de afişat';

$txt['errlog_desc'] = 'Jurnalul erorilor înregistrează toate erorile care au loc pe forum. Pentru a şterge toate înregistrările din baza de date, bifează căsuţa de control şi fă clic pe butonul %1$s aflat la baza paginii.';
$txt['errlog_no_entries'] = 'Nu exista înregistrări în jurnale.';

$txt['theme_settings'] = 'Setările temlor';
$txt['theme_edit_settings'] = 'Editează setările temei curente';
$txt['theme_current_settings'] = 'Tema actuală';

$txt['dvc_your'] = 'Versiunea ta';
$txt['dvc_current'] = 'Versiunea curentă';
$txt['dvc_sources'] = 'Surse';
$txt['dvc_admin'] = 'Administrare';
$txt['dvc_controllers'] = 'Controleri';
$txt['dvc_database'] = 'Baze de date';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Șabloane implicite';
$txt['dvc_templates'] = 'Șabloane actuale';
$txt['dvc_languages'] = 'Fişiere de limbă';

$txt['smileys_default_set_for_theme'] = 'Selecteză emoticoanele implicite pentru tema actuală';
$txt['smileys_no_default'] = 'Utilizează setul implicit de emoticoane';

$txt['censor_test'] = 'Testează cuvintele cenzurate';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Ignoră majusculele când cenzurezi.';
$txt['censor_whole_words'] = 'Caută doar cuvintele întregi.';
$txt['censor_allow'] = 'Permite utilizatorilor să afișeze cuvintele cenzurate.';

$txt['admin_confirm_password'] = '(confirmă parola)';
$txt['admin_incorrect_password'] = 'Parolă greşită';

$txt['date_format'] = '(YYYY-MM-DD)';
$txt['undefined_gender'] = 'Nedefinit';
$txt['age'] = 'Vârsta utilizatorului';
$txt['activation_status'] = 'Starea activarării';
$txt['activated'] = 'Activat';
$txt['not_activated'] = 'Neactivat';
$txt['is_banned'] = 'Restricționat';
$txt['primary'] = 'Primar';
$txt['additional'] = 'Suplimentar';
$txt['wild_cards_allowed'] = 'caracterele generale * şi ? sunt permise';
$txt['member_part_of_these_membergroups'] = 'Membrul face parte din aceste grupuri';
$txt['membergroups'] = 'Grupuri de membri';
$txt['confirm_delete_members'] = 'Ești sigur că vrei să ştergi membrii selectaţi ?';

$txt['support_credits_title'] = 'Ajutor și Credit';
$txt['support_credits_info'] = 'Link-urile unde poți cere ajutor privind majoritatea problemelor, informații relevante privind versiunea forumului (care-ți vor fi cerute când vei cere ajutor) și o listă a celor care au contribuit la dezvoltarea proiectului ElkArte.';
$txt['support_title'] = 'Informaţii de sprijin';
$txt['support_versions_current'] = 'Versiunea curentă';
$txt['support_versions_forum'] = 'Această versiune';
$txt['support_versions_db'] = 'versiunea %1$s';
$txt['support_versions_server'] = 'Versiunea de pe server';
$txt['support_versions_gd'] = 'Versiune GD';
$txt['support_versions_imagick'] = 'Versiunea Imagick';
$txt['support_versions'] = 'Informaţii despre versiune';
$txt['support_resources'] = 'Resurse de ajutor';
$txt['support_resources_p1'] = 'Site-ul nostru pentru <a href="%1$s" target="_blank" class="new_win">Documentația în format Wiki</a> găzduiește documentația principală pentru ElkArte. Manualul on-line ElkArte conține multe documente care pot răspunde la problemele tale și care oferă explicații privind <a href="%2$s" target="_blank" class="new_win">funcționalitățile</a>, <a href="%3$s" target="_blank" class="new_win">setările</a>, <a href="%4$s" target="_blank" class="new_win">temele</a>, <a href="%5$s" target="_blank" class="new_win">pachetele</a> etc. Manualul on-line documenteză în amănunt fiecare aspect al aplicației ElkArte și ar trebui să poată răspunde rapid tuturor întrebărilor tale.';
$txt['support_resources_p2'] = 'Dacă nu găsești răspuns la întrebările tale în Documentația în format Wiki, poți cere ajutor în <a href="%1$s" target="_blank" class="new_win">forumul nostru</a>. Poți utiliza forumul pentru a <a href="%2$s" target="_blank" class="new_win">cere sprijin</a>, pentru a-ți <a href="%3$s" target="_blank" class="new_win">personaliza propriul forum</a> și pentru multe alte lucruri precum discuții referitoare la ElkArte, găsirea unui webhost și discutarea problemelor administrative cu alți administratori de forumuri.';

$txt['latest_updates'] = 'Ultimele actualizări notabile';
$txt['new_in_1_0_2'] = 'Cea mai semnificativă modificare în ElkArte 1.0.2 este administrarea drepturilor referitoare la avataruri. În momentul de față toate metodele de stabilire a unui avatar sunt bazate pe permisiuni, necesitând validarea/invalidarea fiecărei metode pentru fiecare grup. În 1.0.2 avatarurile sunt pur și simplu permise/nepermise la nivel de grup de utilizatori. Acest lucru permite membrilor grupurilor abilitate să-și definească un avatar, prin toate metodele disponibile.<br />
Singura setare disponibilă privind drepturile este una generală, care permite sau nu membrilor unui grup să-și schimbe avatarul. Există doar două setări în plus, pentru lățimea și înălțimea maxime ale avatarurilor, aplicabile universal.<br /> <br />
Datorită naturii modificărilor menționate, este imposibil de asigurat migrarea setărilor în noul format. Din acest motiv e recomandat să accesezi pagina <a href="{admin_url};area=manageattachments;sa=avatars">Setărilor pntru avataruri<a /> și să-ți definești opțiunile preferate.';

$txt['edit_permissions_info'] = 'Folosește setările de drepturi pentru administrarea funcționalităților globale și specifice ale forumului precum și acțiunile disponibile vizitatorilor, membrilor și moderatorilor.';
$txt['membergroups_members'] = 'Membri obişnuiţi';
$txt['membergroups_guests'] = 'Vizitatori';
$txt['membergroups_add_group'] = 'Adaugă grup';
$txt['membergroups_permissions'] = 'Permisiuni';

$txt['permitgroups_restrict'] = 'Restrictiv';
$txt['permitgroups_standard'] = 'Standard';
$txt['permitgroups_moderator'] = 'Moderator';
$txt['permitgroups_maintenance'] = 'Mentenanță';

$txt['confirm_delete_attachments'] = 'Ești sigur că vrei să ştergi ataşamentele selectate?';
$txt['attachment_manager_browse_files'] = 'Vezi fişierele';
$txt['attachment_manager_repair'] = 'Întreţine';
$txt['attachment_manager_avatars'] = 'Avatare';
$txt['attachment_manager_attachments'] = 'Ataşamente';
$txt['attachment_manager_thumbs'] = 'Imagini în miniatură';
$txt['attachment_manager_last_active'] = 'Ultima dată activ';
$txt['attachment_manager_member'] = 'Membru';
$txt['attachment_manager_avatars_older'] = 'Elimină avatarurile membrilor care nu au fost activi în ultimele %1$s zile';
$txt['attachment_manager_total_avatars'] = 'Numărul total de avataruri';

$txt['attachment_manager_avatars_no_entries'] = 'Momentan nu există avatare.';
$txt['attachment_manager_attachments_no_entries'] = 'Momentan nu există ataşamente.';
$txt['attachment_manager_thumbs_no_entries'] = 'Momentan nu există pictograme.';

$txt['attachment_manager_settings'] = 'Setări Ataşamente';
$txt['attachment_manager_avatar_settings'] = 'Setări Avatar';
$txt['attachment_manager_browse'] = 'Vezi fişierele';
$txt['attachment_manager_maintenance'] = 'Mentenanţă Fişier';
$txt['attachmentEnable'] = 'Stare ataşamente';
$txt['attachmentEnable_deactivate'] = 'Dezactivaţi ataşamentele';
$txt['attachmentEnable_enable_all'] = 'Activaţi toate ataşamentele';
$txt['attachmentEnable_disable_new'] = 'Dezactivaţi ataşamentele noi ';
$txt['attachmentCheckExtensions'] = 'Verifică extensia fişierelor ataşate';
$txt['attachmentExtensions'] = 'Extensii de ataşamente permise ';
$txt['attachmentRecodeLineEndings'] = 'Recodifică sfârşitul liniilor la ataşamentele de tip text';
$txt['attachmentShowImages'] = 'Afişează ataşamentele imagine ca imagini sub mesaj';
$txt['attachmentUploadDir'] = 'Directorul de ataşamente';
$txt['attachmentUploadDir_multiple_configure'] = 'Administrează directoarele pentru atașamente';
$txt['attachmentDirSizeLimit'] = 'Spațiul maxim pentru directoarele cu atașamente';
$txt['attachmentPostLimit'] = 'Dimensiunea maximă a atașamentelor pentru fiecare postare';
$txt['attachmentSizeLimit'] = 'Dimensiunea maximă a fiecărui atașament';
$txt['attachmentNumPerPostLimit'] = 'Numărul maxim de atașamente per post';
$txt['attachment_img_enc_warning'] = 'Nu sunt instalate nici modulul GD nici ImageMagick. Recodarea imaginiloe nu este posibilă.';
$txt['attachment_postsize_warning'] = 'Setarea curentă \'post_max_size\' din php.ini s-ar putea să nu permită asta.';
$txt['attachment_filesize_warning'] = 'Setarea curentă \'upload_max_size\' din php.ini s-ar putea să nu permită asta.';
$txt['attachment_image_reencode'] = 'Recodifică fişierele imagine ataşate potenţial periculoase';
$txt['attachment_image_reencode_note'] = '(necesită modulul GD sau ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Verificarea extensivă a securităţii poate duce la respingerea multor ataşamente';
$txt['attachment_image_paranoid'] = 'Execută verificări de securitate suplimentare la încărcarea ataşamentelor imagini.';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'Redimensionează imaginile când sunt afişate sub mesaje';
$txt['attachment_thumb_png'] = 'Salvează miniaturile ca şi PNG';
$txt['attachment_thumb_memory'] = 'Memoria adaptivă pentru miniaturi';
$txt['attachment_thumb_memory_note2'] = 'Dacă sistemul nu poate accesa memoria, miniaturile nu vor fi create.';
$txt['attachment_thumb_memory_note1'] = 'Dacă lași caseta debifată, crearea miniaturilor va fi încercată oricum.';
$txt['attachmentThumbWidth'] = 'Lăţimea maximă a miniaturilor';
$txt['attachmentThumbHeight'] = 'Înălţimea maximă a miniaturilor';
$txt['attachment_thumbnail_settings'] = 'Setări pentru miniaturi';
$txt['attachment_security_settings'] = 'Setări de securitate pentru atașamente';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Nu există';
$txt['attach_dir_not_writable'] = 'Needitabil';
$txt['attach_dir_files_missing'] = 'Lipsesc fișiere (<a href="{repair_url}">Repară</a>)';
$txt['attach_dir_unused'] = 'Neutilizat';
$txt['attach_dir_empty'] = 'Gol';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Director de bază';

$txt['attach_dir_desc'] = 'Creează directoare noi sau modifică directorul curent de mai jos. Directoarele pot fi redenumite dacă nu conțin subdirectoare. Dacă trebuie creat un director nou în structura de directoare a forumului, va trebui doar să introduci numele directorului. Pentru a elimina un director, golește câmpul de editare a căii. Directoarele nu pot fi șterse dacă conțin fișiere sau sub-directoare (afișate în paranteze lângă numărul fișierelor).';
$txt['attach_dir_base_desc'] = 'Poți folosi aria de mai jos pentru a schimba directorul de bază curent sau pentu a crea unul nou. Directoarele de bază noi sunt adăugate la lista de Directpare de Atașamente. Poți deasemenea să desemnezi un director existent să fie director de bază.';
$txt['attach_dir_save_problem'] = 'Hopa, se pare că e o problemă.';
$txt['attachments_no_create'] = 'Nu poate fi creat un director nou pentru atașamente. Te rog creează-l folosind un client FTP sau managerul de fișiere al hostului site-ului.';
$txt['attachments_no_write'] = 'Acest director a fost creat dar nu este accesibil pentru scriere. Te rog încearcă să faci asta folosind un client FTP sau managerul de fișiere al hostului site-ului.';
$txt['attach_dir_reserved'] = 'Nu se poate adăuga. Acest director este un director de sistem și nu poate fi utilizat pentru atașamente.';
$txt['attach_dir_duplicate_msg'] = 'Nu se poate adăuga. Directorul există deja.';
$txt['attach_dir_exists_msg'] = 'Nu se poate muta. Deja există un director cu această cale.';
$txt['attach_dir_base_dupe_msg'] = 'Nu se poate adăuga. Directorul de bază a fost deja creat.';
$txt['attach_dir_base_no_create'] = 'Nu se poate crea. Verifică calea introdusă sau creează acest director folosind un client FTP sau managerul de fișiere al hostului site-ului și încearcă din nou.';
$txt['attach_dir_no_rename'] = 'Nu se poate muta sau redenumi. Verifică dacă e corectă calea sau dacă acest director conține vreun subdirector.';
$txt['attach_dir_no_delete'] = 'Nu ste gol și nu poate fi șters. Șterge directorul folosind un client FTP sau managerul de fișiere al hostului site-ului.';
$txt['attach_dir_no_remove'] = 'Conține încă fișiere sau este director de bază și nu poate fi șters.';
$txt['attach_dir_is_current'] = 'Nu poate fi eliminat cât timp este selectat ca director curent.';
$txt['attach_dir_is_current_bd'] = 'Nu poate fi eliminat cât timp este selectat ca director de bază.';
$txt['attach_last_dir'] = 'Ultimul director de atașamente activ';
$txt['attach_current_dir'] = 'Directorul de atașamente curent';
$txt['attach_current'] = 'Curent';
$txt['attach_path_manage'] = 'Administrează căile pentru atașamente';
$txt['attach_directories'] = 'Directoarele pentru atașamente';
$txt['attach_paths'] = 'Căile directoarelor pentru atașamente';
$txt['attach_path'] = 'Cale';
$txt['attach_current_size'] = 'Mărime (KiB)';
$txt['attach_num_files'] = 'Fişiere';
$txt['attach_dir_status'] = 'Statut';
$txt['attach_add_path'] = 'Adaugă calea';
$txt['attach_path_current_bad'] = 'Calea pentru atașamente curentă este invalidă..';
$txt['attachmentDirFileLimit'] = 'Numărul maxim de fișiere într-un director';

$txt['attach_base_paths'] = 'Căile directorului de bază';
$txt['attach_num_dirs'] = 'Directoare';
$txt['max_image_width'] = 'Lățimea maximă de afișare a imaginilor atașate';
$txt['max_image_height'] = 'Înălțimea maximă de afișare a imaginilor atașate';

$txt['automanage_attachments'] = 'Alege metoda de gestionare a directoarelor de atașamente';
$txt['attachments_normal'] = '(Manual) Comportamentul implicit al ElkArte';
$txt['attachments_auto_years'] = '(Auto) Subdivizează pe ani';
$txt['attachments_auto_months'] = '(Auto) Subdivizează pe ani și luni';
$txt['attachments_auto_days'] = '(Auto) Subdivizează pe ani, luni și zle';
$txt['attachments_auto_16'] = '(Auto) 16 directoare aleatoare';
$txt['attachments_auto_16x16'] = '(Auto) 16 directoare aleatoare cu 16 subdirectoare aleatoare';
$txt['attachments_auto_space'] = '(Auto) Când se atinge limita de spațiu a oricărui director';

$txt['use_subdirectories_for_attachments'] = 'Crează directoare noi sub un director de bază';
$txt['use_subdirectories_for_attachments_note'] = '
Altfel, orice director nou va fi creat în directorul principal al forumului.';
$txt['basedirectory_for_attachments'] = 'Definește un director de bază pentru atașamente';
$txt['basedirectory_for_attachments_current'] = 'Directorul de bază curent';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Fii atent că directorul este greșit. <br />(<a href="{attach_repair_url}">Încearcă să corctezi</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">Pare a fi o problemă cu acest director. <br />(<a href="{attach_repair_url}">Încearcă să corectezi</a>)</div>';

$txt['attachment_transfer'] = 'Transferă atașamente';
$txt['attachment_transfer_desc'] = 'Transferă fișiere între directoare';
$txt['attachment_transfer_select'] = 'Selectează directorul';
$txt['attachment_transfer_now'] = 'Transfer';
$txt['attachment_transfer_from'] = 'Transferă fișiere din';
$txt['attachment_transfer_auto'] = 'Mută-le automat în funcție de mărime sau număr de fișiere';
$txt['attachment_transfer_auto_select'] = 'Selectează directorul de bază';
$txt['attachment_transfer_to'] = 'Sau mută-le într-un director specificat.';
$txt['attachment_transfer_empty'] = 'Mută toate fișierle din directorul sursă.';
$txt['attachment_transfer_no_base'] = 'Nu sunt directoare de bază disponibile.';
$txt['attachment_transfer_forum_root'] = 'Directorul rădăcină al forumului';
$txt['attachment_transfer_no_room'] = 'Au fost atinse mărimea sau numărul de fișiere limită.';
$txt['attachment_transfer_no_find'] = 'Nu s-au găsit fișiere de transferat.';
$txt['attachments_transfered'] = '%1$d fișiere au fost transferate în %2$s';
$txt['attachments_not_transfered'] = '%1$d fișiere nu au fost transferate.';
$txt['attachment_transfer_no_dir'] = 'Fie directorul sursă fie una din opțiunile pentru destinație nu au fost selectate.';
$txt['attachment_transfer_same_dir'] = 'Nu poți selecta același director și ca sursă și ca destinație.';
$txt['attachment_transfer_progress'] = 'Te rog așteaptă. Transferul e în derulare.';

$txt['avatar_settings'] = 'Setările generale pentru avataruri';
$txt['avatar_default'] = 'Permite folosirea  unui avatar implicit pentru utilizatorii fără avatar propriu';
$txt['avatar_directory'] = 'Directorul pentru avataruri';
$txt['avatar_url'] = 'URL avatarurilor';
$txt['avatar_max_width'] = 'Lățimea maximă a avatarurilor, în pixeli (px)';
$txt['avatar_max_height'] = 'Înălțimea maximă a avatarurilor, în pixeli (px)';
$txt['avatar_action_too_large'] = 'Dacă avatarul este prea mare...';
$txt['option_refuse'] = 'Refuză-l';
$txt['option_resize'] = 'Permite CSS să-l redimensioneze';
$txt['option_download_and_resize'] = 'Descarcă-l și redimensionează-l (necesită modulul GD sau ImageMagick)';
$txt['gravatar'] = 'Gravataruri';
$txt['avatar_gravatar_enabled'] = 'Permite utilizarea gravatarurilor';
$txt['gravatar_rating'] = 'Clasificarea permisă pentru gravatar';
$txt['avatar_download_png'] = 'Utilizează PNG pentru avatarurile redimensionate';
$txt['avatar_img_enc_warning'] = 'Nu este instalat modulul GD sau ImageMagick. Anumite funcționalități pentru avataruri sunt dezafectate.';
$txt['avatar_external'] = 'Avataruri externe';
$txt['avatar_external_enabled'] = 'Permite utilizarea avatarurilor externe (remote/URL)';
$txt['avatar_upload'] = 'Avataruri încărcabile';
$txt['avatar_resize_options'] = 'Opțiuni de stocare pe server';
$txt['avatar_upload_enabled'] = 'Permite încărcarea avatarurilor';
$txt['avatar_server_stored'] = 'Avataruri stocate pe server';
$txt['avatar_stored_enabled'] = 'Permite selectarea avatarurilor stocate pe server';
$txt['profile_set_avatar'] = 'Grupurile de membri cărora li se permite să selecteze un avatar';
$txt['avatar_select_permission'] = 'Selectează permisiunile pentru fiecare grup';
$txt['avatar_download_external'] = 'Descarcă avatarul de la URL-ul dat';
$txt['custom_avatar_enabled'] = 'Descarcă avatarurile în...';
$txt['option_attachment_dir'] = 'Directorul de ataşamente';
$txt['option_specified_dir'] = 'Directorul specific ...';
$txt['custom_avatar_dir'] = 'Director pentru încărcări';
$txt['custom_avatar_dir_desc'] = 'Ar trebui să fie un director valid și cu drepturi de scriere, diferit de directorul pentru stocare pe server.';
$txt['custom_avatar_url'] = 'Încarcă URL';
$txt['custom_avatar_check_empty'] = 'Directorul pentru avataruri personalizate specificat de tine poate fi gol sau invalid. Te rog verifică dacă setările sunt corecte. ';
$txt['avatar_reencode'] = 'Recodează avatarurile potenţial periculoase';
$txt['avatar_reencode_note'] = '(necesită modulul GD)';
$txt['avatar_paranoid_warning'] = 'Verificarea de securitate extensivă poate duce la respingerea multor avataruri.';
$txt['avatar_paranoid'] = 'Execută verificări de securitate suplimentare la încărcarea avatarelor';

$txt['repair_attachments'] = 'Mentenanţa fişierelor ataşate';
$txt['repair_attachments_complete'] = 'Mentenanţă finalizată';
$txt['repair_attachments_complete_desc'] = 'Toate erorile selectate au fost corectate';
$txt['repair_attachments_no_errors'] = 'Nu au fost găsite erori';
$txt['repair_attachments_error_desc'] = 'Următoarele erori au fost găsite în timpul operațiunilor de mentenanță. Bifează căsuţa de lângă erorile pe care doreşti să le repari apoi apasă Continuă.';
$txt['repair_attachments_continue'] = 'Continuă';
$txt['repair_attachments_cancel'] = 'Anulează';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d miniaturi nu au fișierul ataşamentului-părinte';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d fişiere părinte sunt marcate ca având miniaturi dar nu au';
$txt['attach_repair_file_missing_on_disk'] = '%1$d ataşamente/avataruri sunt înrgistrate în baza de date dar nu mai există pe server';
$txt['attach_repair_file_wrong_size'] = '%1$d ataşamente/avataruri sunt raportate cu dimensiunea de fișier greșită';
$txt['attach_repair_file_size_of_zero'] = '%1$d ataşamente/avataruri au dimensiunea zero pe disc. (Acestea vor fi șterse)';
$txt['attach_repair_attachment_no_msg'] = '%1$d ataşamente nu mai au un mesaj asociat cu ele';
$txt['attach_repair_avatar_no_member'] = '%1$d avataruri nu mai au un utilizator asociat cu ele';
$txt['attach_repair_wrong_folder'] = '%1$d atașamente nu sunt în directorul corect';
$txt['attach_repair_missing_extension'] = '%1$d atașamente nu au extensia corectă și pot fi într-un director greșit';
$txt['attach_repair_files_without_attachment'] = '%1$d fișire nu au înregistrare corespunzătoare în baza de date. (Acestea vor fi șterse)';

$txt['news_title'] = 'Ştiri şi Buletine de știri';
$txt['news_settings_desc'] = 'Aici poţi schimba setările şi permisiunile referitoare la ştiri şi la buletinele de știri.';
$txt['news_mailing_desc'] = 'Din acest meniu poți trimite mesaje tuturor utilizatorilor care s-au înregistrat și și-au introdus adresele de email. Poți edita lista de distribuție sau poți trimite mesaje tuturor. Util pentru actualizări/știri importante.';
$txt['news_error_no_news'] = 'Nimic de revizuit';
$txt['groups_edit_news'] = 'Grupuri cărora le permiţi să editeze ştirile';
$txt['groups_send_mail'] = 'Grupuri cărora le permiţi să trimită buletine de ştiri ale forumului';
$txt['xmlnews_enable'] = 'Activează fluxul XML/RSS pentru ştiri';
$txt['xmlnews_maxlen'] = 'Lungima maximă a mesajului';
$txt['xmlnews_limit'] = 'Limita XML/RSS';
$txt['xmlnews_limit_note'] = 'Numărul de știri dintr-un flux';
$txt['xmlnews_maxlen_note'] = '(0 pentru anulare, o idee proastă!)';
$txt['editnews_clickadd'] = 'Adaugă încă un element';
$txt['editnews_remove_selected'] = 'Elimină-le pe cele selectate';
$txt['editnews_remove_confirm'] = 'Ești sigur că vrei să ştergi ştirile selectate ?';
$txt['censor_clickadd'] = 'Adaugă încă un cuvânt';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Jurnale';
$txt['generate_reports'] = 'Rapoarte';

$txt['update_available'] = 'Actualizare disponibilă';
$txt['update_message'] = 'Folosești o versiune de ElkArte învechită ce conține anumite bug-uri care au fost deja îndepărtate.<br />Este recomandat să-ți <a href="#" id="update-link">actualizezi forumul</a> la ultima versiune cât mai curând posibil. Durează doar un minut!';

$txt['manageposts'] = 'Mesaje şi subiecte';
$txt['manageposts_title'] = 'Administrează mesajele şi subiectele postate';
$txt['manageposts_description'] = 'Aici poţi administra toate setările legate de subiectele de discuţie şi de mesajele postate în acestea.';

$txt['manageposts_seconds'] = 'secunde';
$txt['manageposts_minutes'] = 'minute';
$txt['manageposts_characters'] = 'caractere';
$txt['manageposts_days'] = 'zile';
$txt['manageposts_posts'] = 'mesaje postate';
$txt['manageposts_topics'] = 'subiecte de discuţie';

$txt['pollMode'] = 'Activează sondajele';

$txt['manageposts_settings'] = 'Setările pentru mesaje';
$txt['manageposts_settings_description'] = 'Aici poţi seta totul referitor la mesaje şi la scrierea acestora.';

$txt['manageposts_bbc_settings'] = 'Bulletin Board Code';
$txt['manageposts_bbc_settings_description'] = 'Codurile BBC (Bulletin Board Code) pot fi folosite pentru a adăuga marcaje mesajelor din forum. De exemplu pentru a îngroşa cuvântul \'casă\' poţi tasta [b]casă[/b]. Toate BBC sunt scrise între paranteze pătrate (\'[\' şi \']\').';
$txt['manageposts_bbc_settings_title'] = 'Setările pentru Bulletin Board Code';

$txt['manageposts_topic_settings'] = 'Setările pentru subiecte';
$txt['manageposts_topic_settings_description'] = 'Aici poţi seta opțiunile pentru subiectele de discuții.';

$txt['managedrafts_settings'] = 'Setările pentru ciorne';
$txt['managedrafts_settings_description'] = 'Aici poți face toate setările privind ciornele.';
$txt['manage_drafts'] = 'Ciorne';

$txt['mail_center'] = 'Centrul pentru listele de email';
$txt['mm_emailerror'] = 'Emailuri ratate';
$txt['mm_emailfilters'] = 'Filtre';
$txt['mm_emailparsers'] = 'Analizatori';
$txt['mm_emailtemplates'] = 'Șabloane';
$txt['mm_emailsettings'] = 'Setări';

$txt['removeNestedQuotes'] = 'Elimină citatele imbricate când se citează';
$txt['enableSpellChecking'] = 'Activează corectorul gramatical';
$txt['enableSpellChecking_warning'] = 'nu funcționează pe toate serverele.';
$txt['enableSpellChecking_error'] = 'nu funcționează pe serverul acesta.';
$txt['enableVideoEmbeding'] = 'Activează încorporarea automată a link-urilor video.';
$txt['enableCodePrettify'] = 'Activează înfrumusețarea tag-urilor BBC';
$txt['max_messageLength'] = 'Dimensiunea maximă permisă a mesajului postat';
$txt['max_messageLength_zero'] = 'zero pentru "nelimitat"';
$txt['convert_to_mediumtext'] = 'Baza ta de date nu este setată să accepte mesaje mai lungi de 65535 caractere. Folosește operațiunile de <a href="%1$s">mentenanță a bazei de date</a> pentru a o converti și revino apoi pentru a mări dimensiunea maximă permisă a mesajului postat.';
$txt['topicSummaryPosts'] = 'Mesaje afişate în sumarul subiectului';
$txt['spamWaitTime'] = 'Timpul necesar între mesajele postate de la acelaşi IP';
$txt['edit_wait_time'] = 'Perioada de curtoazie pentru editarea mesajelor';
$txt['edit_disable_time'] = 'Timpul maxim după postare în care se permite editarea';
$txt['edit_disable_time_zero'] = '0 pentru a dezactiva';
$txt['preview_characters'] = 'Lungimea maximă a previzualizării ultimei/primei postări';
$txt['preview_characters_units'] = 'caractere';
$txt['preview_characters_zero'] = '0 pentru a arăta întreg mesajul';
$txt['message_index_preview'] = 'Arată previzualizări ale mesajelor în index';
$txt['message_index_preview_off'] = 'Nu arăta previzualizările';
$txt['message_index_preview_first'] = 'Arată textul primei postări';
$txt['message_index_preview_last'] = 'Arată textul ultimei postări';

$txt['enableBBC'] = 'Permite utilizarea Bulletin Board Code (BBC)';
$txt['enablePostHTML'] = 'Activează folosirea de HTML <em>de bază</em> în mesajele postate';
$txt['autoLinkUrls'] = 'Afişează în mod automat URL-urile postate ca link-uri';
$txt['disabledBBC'] = 'Taguri BBC permise';
$txt['bbcTagsToUse'] = 'Taguri BBC permise';
$txt['bbcTagsToUse_select'] = 'Selectează tagurile permise pentru utilizare';
$txt['bbcTagsToUse_select_all'] = 'Selectaţi toate tag-urile';

$txt['enableParticipation'] = 'Activează iconiţele de participare';
$txt['enableFollowup'] = 'Permite abonarea la continuare';
$txt['enable_unwatch'] = 'Permite dezabonarea de la subiecte';
$txt['oldTopicDays'] = 'Timpul după care un răspunsurile la un subiect primesc antenţionare de subiect învechit';
$txt['oldTopicDays_zero'] = '0 pentru a dezactiva';
$txt['defaultMaxTopics'] = 'Numărul de subiecte per pagină în indexul mesajelor';
$txt['defaultMaxMessages'] = 'Numărul postărilor per pagina dintr-un subiect';
$txt['disable_print_topic'] = 'Invalidează printarea subiectelor';
$txt['hotTopicPosts'] = 'Numărul postări peste care un subiect devine fierbinte';
$txt['hotTopicVeryPosts'] = 'Numărul postări peste care un subiect devine foarte fierbinte';
$txt['useLikesNotViews'] = 'Utilizează numărul de like-uri în locul numărului de postări pentru a defini \'fierbințeala\' unui subiect.';
$txt['enableAllMessages'] = 'Mărimea maximă a subiectului pentru care încă se afișează &quot;Toate&quot; postările';
$txt['enableAllMessages_zero'] = '0 pentru a nu afişa niciodată &quot;Toate&quot;';
$txt['disableCustomPerPage'] = 'Nu permite utilizatorilor să definească numărul de subiecte/mesaje afişate per pagină';
$txt['enablePreviousNext'] = 'Permite afişarea linkurilor cu topic precedent/urmator';

$txt['not_done_title'] = 'Încă nu e gata';
$txt['not_done_reason'] = 'Pentru a evita supraîncărcarea serverului procesul a fost temporar întrerupt, Va reporni automat în câteva secunde. Dacă asta nu se întâmplă, dă un clic pe \'continuă\', mai jos.';
$txt['not_done_continue'] = 'Continuă';

$txt['general_settings'] = 'General ';
$txt['database_paths_settings'] = 'Baza de date şi Căi';
$txt['cookies_sessions_settings'] = 'Cookies şi Sesiuni';
$txt['caching_settings'] = 'Memorie cache';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Setările locale';
$txt['phpinfo_defaultsettings'] = 'Setările implicite';
$txt['phpinfo_itemsettings'] = 'Setări';

$txt['language_configuration'] = 'Limbi';
$txt['language_description'] = 'Această arie îți permite să editezi fișierele cu traduceri instalate pe forum sau să dscarci altele noi de pe site-ul ElkArte. Tot aici poți edita setările privind limba.';
$txt['language_edit'] = 'Editează limbile';
$txt['language_add'] = 'Adaugă limbă';
$txt['language_settings'] = 'Setări';

$txt['advanced'] = 'Avansat';
$txt['simple'] = 'Simplu';

$txt['admin_news_select_recipients'] = 'Selectează cine ar trebui să primească o copie a buletinului de ştiri';
$txt['admin_news_select_group'] = 'Grupuri de membri';
$txt['admin_news_select_group_desc'] = 'Selectează grupurile care vor primi acest buletin de ştiri.';
$txt['admin_news_select_members'] = 'Membri';
$txt['admin_news_select_members_desc'] = 'Membri adiționali care să primească buletinul de știri.';
$txt['admin_news_select_excluded_members'] = 'Membrii excluşi';
$txt['admin_news_select_excluded_members_desc'] = 'Membrii care nu trbuie să primească buletinul de știri.';
$txt['admin_news_select_excluded_groups'] = 'Grupurile excluse';
$txt['admin_news_select_excluded_groups_desc'] = 'Selectează grupurile care nu trebuie să primească buletinul de ştiri.';
$txt['admin_news_select_email'] = 'Adresele de email';
$txt['admin_news_select_email_desc'] = 'O listă de adrese de email, separate prin punct-și-virgulă, către care acst buletin de știri trebuie trimis (de ex. adresa1; adresa2)';
$txt['admin_news_select_override_notify'] = 'Ignoră setările utilizatorilor privind primirea notificărilor ';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Nu poţi trimite un mesaj personal la o adresă email. Dacă continui, toate adresele de email introduse vor fi ignorate.\\n\\nEşti sigur că vrei să faci asta?';

$txt['mailqueue_browse'] = 'Răsfoiește lista';
$txt['mailqueue_settings'] = 'Setări';

$txt['admin_search'] = 'Căutare Rapidă';
$txt['admin_search_type_internal'] = 'Activitate/Setare';
$txt['admin_search_type_member'] = 'Membru';
$txt['admin_search_type_online'] = 'Manualul online';
$txt['admin_search_go'] = 'Mergi';
$txt['admin_search_results'] = 'Rezultatele căutării';
$txt['admin_search_results_desc'] = 'Rezultatele căutării: &quot;%1$s&quot; ';
$txt['admin_search_results_again'] = 'Caută din nou';
$txt['admin_search_results_none'] = 'Nu s-a găsit nici un rezultat.';

$txt['admin_search_section_sections'] = 'Secţiune';
$txt['admin_search_section_settings'] = 'Setare';

$txt['core_settings_title'] = 'Funcții de bază';
$txt['core_settings_desc'] = 'Pagina aceasta îți permite să activezi sau să dezactivezi unele funcționalități opționale ale forumului.';
$txt['mods_cat_features'] = 'General ';
$txt['mods_cat_security_general'] = 'General ';
$txt['antispam_title'] = 'Anti-spam';
$txt['badbehavior_title'] = 'BadBehavior';
$txt['mods_cat_modifications_misc'] = 'Diverse';
$txt['mods_cat_layout'] = 'Așezarea în pagină';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderare';
$txt['signature_settings_short'] = 'Semnături';
$txt['custom_profile_shorttitle'] = 'Câmpuri de profil';
$txt['pruning_title'] = 'Curățarea jurnalelor';

$txt['core_settings_activation_message'] = 'Funcția {core_feature} a fost activată, fă click pe titlu pentru a o configura';
$txt['core_settings_deactivation_message'] = 'Funcția {core_feature} a fost dezactivată,';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Modifică ariile';
$txt['mboards_new_cat'] = 'Creează o categorie nouă';
$txt['manage_holidays'] = 'Administarea  sărbătorilor';
$txt['calendar_settings'] = 'Setările calendarului';
$txt['search_weights'] = 'Ponderi';
$txt['search_method'] = 'Metoda de căutare';
$txt['search_sphinx'] = 'Configurează Sphinx';

$txt['smiley_sets'] = 'Seturi de emoticoane';
$txt['smileys_add'] = 'Adaugă un emoticon';
$txt['smileys_edit'] = 'Editează emoticoanele';
$txt['smileys_set_order'] = 'Setează ordinea emoticoanelot';
$txt['icons_edit_message_icons'] = 'Editează iconițele pentru mesaje';

$txt['membergroups_new_group'] = 'Adaugă un grup de membri';
$txt['membergroups_edit_groups'] = 'Editează grupurile de membri';
$txt['permissions_groups'] = 'Drepturi pentru grupuri';
$txt['permissions_boards'] = 'Drepturi pentru arii';
$txt['permissions_profiles'] = 'Profiluri de drepturi pentri arii';
$txt['permissions_post_moderation'] = 'Moderarea postărilor';

$txt['browse_packages'] = 'Caută pachete';
$txt['download_packages'] = 'Descarcă pachete';
$txt['upload_packages'] = 'Încarcă pachete';
$txt['installed_packages'] = 'Pachete instalate';
$txt['package_file_perms'] = 'Drepturi pentru fișiere';
$txt['package_settings'] = 'Setări';
$txt['package_servers'] = 'Servere de pachete';
$txt['themeadmin_admin_title'] = 'Administrează şi instalează';
$txt['themeadmin_list_title'] = 'Setările temlor';
$txt['themeadmin_reset_title'] = 'Opţiuni pentru membri';
$txt['themeadmin_edit_title'] = 'Modifică temele';
$txt['admin_browse_register_new'] = 'Înregistrează un membru nou';

$txt['search_engines'] = 'Motoare de căutare';
$txt['spider_logs'] = 'Jurnalul roboţilor (Spiders)';
$txt['spider_stats'] = 'Statistici';

$txt['paid_subscriptions'] = 'Abonamente plătite';
$txt['paid_subs_view'] = 'Vezi Abonamentele';

$txt['maintain_sub_hooks_list'] = 'Interceptări pentru integrare software (Integration Hooks)';
$txt['hooks_field_hook_name'] = 'Numele interceptării';
$txt['hooks_field_function_name'] = 'Numele funcției';
$txt['hooks_field_function'] = 'Funcție';
$txt['hooks_field_included_file'] = 'Fișierul inclus';
$txt['hooks_field_file_name'] = 'Nume Fişier';
$txt['hooks_field_hook_exists'] = 'Statut';
$txt['hooks_active'] = 'Există';
$txt['hooks_disabled'] = 'Dezactivat'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Nu a fost găsit';
$txt['hooks_no_hooks'] = 'Momentan nu sunt integrări în sistem.';
$txt['hooks_disable_legend'] = 'Legenda';
$txt['hooks_disable_legend_exists'] = 'integrarea există și este activă';
$txt['hooks_disable_legend_disabled'] = 'integrarea există dar a fost dezactivată';
$txt['hooks_disable_legend_missing'] = 'integrarea nu a fost găsită';
$txt['hooks_reset_filter'] = 'Resetează filtrul';

$txt['board_perms_allow'] = 'Permite';
$txt['board_perms_ignore'] = 'Ignoraţi';
$txt['board_perms_deny'] = 'Interzice';
$txt['all_boards_in_cat'] = 'Toate ariile din această categorie';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Separatorul pentru cuvinte';

$txt['admin_order_title'] = 'Eroare la ordonare';
$txt['admin_order_error'] = 'A apărut o eroare necunoscută în timpul procesării solicitării tale';

// Known controllers that can work on the front page
$txt['default'] = 'Implicit';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
