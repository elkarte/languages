<?php
// Version: 1.1; Reports

$txt['generate_reports_desc'] = 'În această secţiune poţi genera o gamă de rapoarte care să te ajute în administrarea forumului. Trebuie doar să urmăreşti cu atenţie paşii de mai jos pentru a selecta opţiunile pe care le doreşti';
$txt['generate_reports_continue'] = 'Continuă';
$txt['generate_reports_type'] = 'Selectează tipul de raport';
$txt['gr_type_boards'] = 'Arii';
$txt['gr_type_desc_boards'] = 'Rapoarte despre setările curente şi drepturile de acces pentru fiecare secţiune din forum.';
$txt['gr_type_board_perms'] = 'Drepturi pentru arii';
$txt['gr_type_desc_board_perms'] = 'Generează rapoarte privind drepturile fiecărui grup de utilizatori pentru fiecare secţiune a forumului.';
$txt['gr_type_member_groups'] = 'Grupuri de utilizatori';
$txt['gr_type_desc_member_groups'] = 'Raport cu setările fiecărui grup de utilizatori din forum.';
$txt['gr_type_group_perms'] = 'Drepturile grupului';
$txt['gr_type_desc_group_perms'] = 'Raport cu drepturile pe care fiecare grup de utilizatori le are pe forum.';
$txt['gr_type_staff'] = 'Echipa';
$txt['gr_type_desc_staff'] = 'Acest raport prezintă utilizatorii cu funcţii de administrare sau de moderare de pe forum.';

$txt['full_member'] = 'Membru cu drepturi depline';
$txt['results'] = 'Rezultate';

// Board permissions
$txt['board_perms_permission'] = 'Drept';
$txt['board_perms_allow'] = 'Permite';
$txt['board_perms_deny'] = 'Interzice';
$txt['board_perms_name_announce_topic'] = 'Anunţă subiectul de discuție';
$txt['board_perms_name_approve_posts'] = 'Aprobă mesaje';
$txt['board_perms_name_delete_any'] = 'Şterge orice mesaj';
$txt['board_perms_name_delete_own'] = 'Şterge mesaje proprii';
$txt['board_perms_name_delete_replies'] = 'Şterge răspunsurile la propriile subiecte de discuţie';
$txt['board_perms_name_lock_any'] = 'Închide orice subiect';
$txt['board_perms_name_lock_own'] = 'Închide subiectele proprii';
$txt['board_perms_name_make_sticky'] = 'Fixează subiecte';
$txt['board_perms_name_mark_any_notify'] = 'Cere notificare la orice subiect';
$txt['board_perms_name_mark_notify'] = 'Cere notificare la subiectele proprii';
$txt['board_perms_name_merge_any'] = 'Lipeşte subiectele';
$txt['board_perms_name_moderate_board'] = 'Moderează secţiunea';
$txt['board_perms_name_modify_any'] = 'Modifică orice mesaj';
$txt['board_perms_name_modify_own'] = 'Modifică mesajele proprii';
$txt['board_perms_name_modify_replies'] = 'Modifică răspunsurile la subiectele proprii';
$txt['board_perms_name_move_any'] = 'Mută orice subiect';
$txt['board_perms_name_move_own'] = 'Mută subiectele proprii';
$txt['board_perms_name_poll_add_any'] = 'Adaugă sondaj la orice subiect';
$txt['board_perms_name_poll_add_own'] = 'Adaugă sondaj la subiecte proprii';
$txt['board_perms_name_poll_edit_any'] = 'Editează orice sondaj';
$txt['board_perms_name_poll_edit_own'] = 'Editează sondajele proprii';
$txt['board_perms_name_poll_lock_any'] = 'Închide orice sondaj';
$txt['board_perms_name_poll_lock_own'] = 'Închide sondajele proprii';
$txt['board_perms_name_poll_post'] = 'Publică un sondaj nou';
$txt['board_perms_name_poll_remove_any'] = 'Şterge orice sondaj';
$txt['board_perms_name_poll_remove_own'] = 'Şterge sondajele proprii';
$txt['board_perms_name_poll_view'] = 'Vezi sondajele';
$txt['board_perms_name_poll_vote'] = 'Votează în sondaje';
$txt['board_perms_name_post_attachment'] = 'Adaugă ataşamente';
$txt['board_perms_name_post_new'] = 'Deschide subiecte noi';
$txt['board_perms_name_post_reply_any'] = 'Scrie răspunsuri în orice subiect';
$txt['board_perms_name_post_reply_own'] = 'Scrie răspunsuri în subiectele proprii';
$txt['board_perms_name_post_unapproved_attachments'] = 'Publică ataşamente neaprobate';
$txt['board_perms_name_post_unapproved_topics'] = 'Deschide subiecte neaprobate';
$txt['board_perms_name_post_unapproved_replies_any'] = 'Scrie răspunsuri neaprobate în orice subiect';
$txt['board_perms_name_post_unapproved_replies_own'] = 'Scrie răspunsuri neaprobate în subiectele proprii';
$txt['board_perms_name_remove_any'] = 'Elimină orice subiect';
$txt['board_perms_name_remove_own'] = 'Elimină propriile subiecte';
$txt['board_perms_name_report_any'] = 'Raportează orice mesaj';
$txt['board_perms_name_send_topic'] = 'Trimite subiecte la prieteni';
$txt['board_perms_name_split_any'] = 'Secţionează orice subiect';
$txt['board_perms_name_view_attachments'] = 'Vezi ataşamentele';

$txt['board_perms_group_no_polls'] = 'Această secţiune nu permite adăugarea de sondaje';
$txt['board_perms_group_reply_only'] = 'Această secţiune le permite utilizatorilor doar să răspundă la subiecte';
$txt['board_perms_group_read_only'] = 'Această secţiune nu permite scrierea de mesaje';

// Membergroup info!
$txt['member_group_color'] = 'Culoarea';
$txt['member_group_min_posts'] = 'Numărul minim de measje';
$txt['member_group_max_messages'] = 'Numărul maxim de mesaje personale';
$txt['member_group_icons'] = 'Iconițe';
$txt['member_group_settings'] = 'Setări';
$txt['member_group_access'] = 'Accesul la secţiune';

// Board info.
$txt['none'] = 'Nimic';
$txt['board_category'] = 'Categorie';
$txt['board_parent'] = 'Ariea părinte';
$txt['board_num_topics'] = 'Numărul de subiecte';
$txt['board_num_posts'] = 'Numărul de mesaje';
$txt['board_count_posts'] = 'Numără mesajele';
$txt['board_theme'] = 'Tema grafică a ariei';
$txt['board_override_theme'] = 'Impune tema grafică ';
$txt['board_profile'] = 'Profilul de drepturi';
$txt['board_moderators'] = 'Moderatori';
$txt['board_groups'] = 'Grupuri care au acces';
$txt['board_disallowed_groups'] = 'Grupurile cu Acces interzis';

// Group Permissions.
$txt['group_perms_name_access_mod_center'] = 'Acces la panoul de moderare';
$txt['group_perms_name_admin_forum'] = 'Administrează forum';
$txt['group_perms_name_calendar_edit_any'] = 'Editează orice eveniment';
$txt['group_perms_name_calendar_edit_own'] = 'Editează evenimentele proprii';
$txt['group_perms_name_calendar_post'] = 'Publică evenimente';
$txt['group_perms_name_calendar_view'] = 'Vezi evenimente';
$txt['group_perms_name_edit_news'] = 'Editează ştirile';
$txt['group_perms_name_issue_warning'] = 'Emite avertismente';
$txt['group_perms_name_karma_edit'] = 'Editează karma ';
$txt['group_perms_name_manage_attachments'] = 'Administrează ataşamentele';
$txt['group_perms_name_manage_bans'] = 'Administrează restricționările';
$txt['group_perms_name_manage_boards'] = 'Administrează secţiunile';
$txt['group_perms_name_manage_membergroups'] = 'Administrează grupurile de membri';
$txt['group_perms_name_manage_permissions'] = 'Gestionează drepturi';
$txt['group_perms_name_manage_smileys'] = 'Administrează emoticoanele și iconițele de mesaj';
$txt['group_perms_name_moderate_forum'] = 'Moderează forumul';
$txt['group_perms_name_pm_read'] = 'Citire mesaje personale
';
$txt['group_perms_name_pm_send'] = 'Trimite mesaje personale';
$txt['group_perms_name_profile_extra_any'] = 'Editează orice opţiuni suplimentare';
$txt['group_perms_name_profile_extra_own'] = 'Editează propriile opţiuni suplimentare';
$txt['group_perms_name_profile_identity_any'] = 'Editează orice setări ale contului';
$txt['group_perms_name_profile_identity_own'] = 'Editează setările propriului cont.';
$txt['group_perms_name_profile_set_avatar'] = 'Alege un avatar';
$txt['group_perms_name_profile_remove_any'] = 'Şterge orice cont';
$txt['group_perms_name_profile_remove_own'] = 'Şterge propriul cont';
$txt['group_perms_name_profile_title_any'] = 'Editează orice titlu personalizat';
$txt['group_perms_name_profile_title_own'] = 'Editează titlul personalizat propriu';
$txt['group_perms_name_profile_view_any'] = 'Vezi orice profil';
$txt['group_perms_name_profile_view_own'] = 'Vezi propriul profil';
$txt['group_perms_name_search_posts'] = 'Caută mesaje';
$txt['group_perms_name_send_mail'] = 'Trimite membrilor mailuri din partea forumului';
$txt['group_perms_name_view_mlist'] = 'Vezi lista de membri';
$txt['group_perms_name_view_stats'] = 'Vezi statisticile forumului';
$txt['group_perms_name_who_view'] = 'Vezi cine este online';

$txt['report_error_too_many_staff'] = 'Ai prea mulți membri în echipă. Raportul nu funcționează cu mai mult de 300 de membri administrativi.';
$txt['report_staff_position'] = 'Poziția';
$txt['report_staff_moderates'] = 'Moderează';
$txt['report_staff_posts'] = 'Postări';
$txt['report_staff_last_login'] = 'Ultima autentificare';
$txt['report_staff_all_boards'] = 'Pentru toate ariile';
$txt['report_staff_no_boards'] = 'Nicio arie';