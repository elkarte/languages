<?php
// Version: 1.1; ManageCalendar

$txt['calendar_desc'] = 'Aici poți modifica tot ce ţine de calendar.';

// Calendar Settings
$txt['calendar_settings_desc'] = 'Aici poți activa calendarul şi stabili ce setări să folosească acesta.';
$txt['groups_calendar_view'] = 'Grupurile de utilizatori autorizate să vadă calendarul';
$txt['groups_calendar_post'] = 'Grupurile de utilizatori autorizate să creeze evenimente în calendar';
$txt['groups_calendar_edit_own'] = 'Grupurile de utilizatori autorizate să îşi editeze propriile evenimente';
$txt['groups_calendar_edit_any'] = 'Grupurile de utilizatori autorizate să editeze orice eveniment';
$txt['setting_cal_enabled'] = 'Activează calendarul';
$txt['setting_cal_daysaslink'] = 'Arată zilele ca linkuri către  \'Adaugă eveniment\'';
$txt['setting_cal_days_for_index'] = 'Numărul maxim de zile previzualizate în indexul forumului.';
$txt['setting_cal_showholidays'] = 'Arată sărbătorile';
$txt['setting_cal_showbdays'] = 'Arată zilele de naştere';
$txt['setting_cal_showevents'] = 'Arată evenimentele';
$txt['setting_cal_export'] = 'Permite exportarea evenimentelor în format iCal';
$txt['setting_cal_show_never'] = 'Niciodată';
$txt['setting_cal_show_cal'] = 'Doar în calendar';
$txt['setting_cal_show_index'] = 'Doar în indexul forumului';
$txt['setting_cal_show_all'] = 'În indexul forumului şi în calendar';
$txt['setting_cal_defaultboard'] = 'Secţiunea implicită în care se publică evenimentele';
$txt['setting_cal_allow_unlinked'] = 'Permite evenimente nelegate de un mesaj';
$txt['setting_cal_minyear'] = 'Anul minim';
$txt['setting_cal_maxyear'] = 'Anul maxim';
$txt['setting_cal_allowspan'] = 'Permite evenimentelor să se întindă pe mai multe zile';
$txt['setting_cal_maxspan'] = 'Numărul maxim de zile pe care se poate întinde un eveniment';
$txt['setting_cal_showInTopic'] = 'Arată evenimentele legate în subiect';

// Adding/Editing/Viewing Holidays
$txt['manage_holidays_desc'] = 'Aici puteţi adăuga sau scoate sărbători din calendar.';
$txt['current_holidays'] = 'Sărbători existente';
$txt['holidays_title'] = 'Sărbătoare';
$txt['holidays_title_label'] = 'Titlu';
$txt['holidays_delete_confirm'] = 'Ești sigur că vrei să să ștergi aceste sărbători?';
$txt['holidays_add'] = 'Adaugă o sărbătoare nouă';
$txt['holidays_edit'] = 'Editează o sărbătoare existentă';
$txt['holidays_button_add'] = 'AdaugăAdaugă';
$txt['holidays_button_edit'] = 'Editează';
$txt['holidays_button_remove'] = 'Elimină';
$txt['holidays_no_entries'] = 'În prezent nu sunt configurate sărbători.';
$txt['every_year'] = 'Anual';