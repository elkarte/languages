<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Centrul de moderare';
$txt['mc_main'] = 'General';
$txt['mc_logs'] = 'Jurnale';
$txt['mc_posts'] = 'Postări';
$txt['mc_groups'] = 'Membri și grupuri';

$txt['mc_view_groups'] = 'Vezi grupurile de membri';

$txt['mc_description'] = '<strong>Bun venit, %1$s!</strong><br />Acesta este &quot;Centrul de moderare&quot;. Aici poți desfășura toate activitățile de moderare pentru care Administratorul ți-a alocat drepturi. Această pagină conține un sumar al ultimelor evenimente din forum. Poți <a href="%2$s">personaliza afișarea paginii apăsând aici</a>.';
$txt['mc_group_requests'] = 'Cereri de aderare la grupuri';
$txt['mc_member_requests'] = 'Solicitările membrilor';
$txt['mc_unapproved_posts'] = 'Mesaje neaprobate';
$txt['mc_watched_users'] = 'Membri supravegheați recent';
$txt['mc_watched_topics'] = 'Subiecte urmărite';
$txt['mc_scratch_board'] = 'Zona moderatorilor';
$txt['mc_latest_news'] = 'Ultimele știri';
$txt['mc_recent_reports'] = 'Subiecte raportate recent';
$txt['mc_warnings'] = 'Avertismente';
$txt['mc_notes'] = 'Notele  moderatorilor';
$txt['mc_required'] = 'Aprobări solicitate';
$txt['mc_attachments'] = 'Atașamente care necesită aprobare';
$txt['mc_emailmod'] = 'Postări prin email ce necesită aprobare';
$txt['mc_topics'] = 'Subiecte ce necesită aprobare';
$txt['mc_posts'] = 'Postări';
$txt['mc_groupreq'] = 'Solicitări de aderare la grup ce necesită aprobare';
$txt['mc_memberreq'] = 'Membri ce necesită aprobare';
$txt['mc_reports'] = 'Raportează postările ce necesită aprobare';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'Nu te poți conecta la fișierul cu ultimele știri ElkArte.';

$txt['mc_recent_reports_none'] = 'Nu există rapoarte nerezolvate';
$txt['mc_watched_users_none'] = 'Nu există nici un membru supravegheat.';
$txt['mc_group_requests_none'] = 'Nu există solicitări deschise pentru aderări la grupuri.';

$txt['mc_seen'] = '%1$s văzut ultima dată %2$s';
$txt['mc_seen_never'] = '%1$s nu a fost văzut niciodată';
$txt['mc_groupr_by'] = 'de';

$txt['mc_reported_posts_desc'] = 'Aici vezi toate mesajele raportate de membrii comunităţii.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Rapoarte active';
$txt['mc_reportedp_closed'] = 'Rapoarte vechi';
$txt['mc_reportedp_by'] = 'de';
$txt['mc_reportedp_reported_by'] = 'Raportat de';
$txt['mc_reportedp_last_reported'] = 'Ultima raportare';
$txt['mc_reportedp_none_found'] = 'Nu au fost găsite raportări';

$txt['mc_reportedp_details'] = 'Detalii';
$txt['mc_reportedp_close'] = 'Închide';
$txt['mc_reportedp_open'] = 'Deschide';
$txt['mc_reportedp_ignore'] = 'Înlătură';
$txt['mc_reportedp_unignore'] = 'Redeschide';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Ești sigur că vrei să înlături și să ignori toate raportările referitoare la acest mesaj?

Nici un moderator nu va mai primi notificări!';
$txt['mc_reportedp_close_selected'] = 'Închide cele selectate';

$txt['mc_groupr_group'] = 'Grupuri de utilizatori';
$txt['mc_groupr_member'] = 'Membru';
$txt['mc_groupr_reason'] = 'Motiv';
$txt['mc_groupr_none_found'] = 'Nu există cereri nerezolvate de aderare la un grup de membri.';
$txt['mc_groupr_submit'] = 'Trimite';
$txt['mc_groupr_reason_desc'] = 'Motivarea respingerii cererii lui %1$s de a fi membru al &quot;%2$s&quot; ';
$txt['mc_groups_reason_title'] = 'Motivul respingerii';
$txt['with_selected'] = 'Cu cele selectate';
$txt['mc_groupr_approve'] = 'Aprobă solicitarea';
$txt['mc_groupr_reject'] = 'Respinge solicitarea (fără motivare)';
$txt['mc_groupr_reject_w_reason'] = 'Respinge solicitarea motivat';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Ești sigur că vrei să faci asta?';

$txt['mc_unapproved_attachments_none_found'] = 'Nici un ataşament nu aşteaptă aprobare';
$txt['mc_unapproved_attachments_desc'] = 'Aici poți aproba sau șterge atașamente ce așteaptă moderare.';
$txt['mc_unapproved_replies_none_found'] = 'Nici un mesaj nu aşteaptă aprobare';
$txt['mc_unapproved_topics_none_found'] = 'Nici un subiect nu aşteaptă aprobare';
$txt['mc_unapproved_posts_desc'] = 'Aici poţi aproba sau şterge orice mesaje postate ce așteaptă moderare..';
$txt['mc_unapproved_replies'] = 'Răspunsuri';
$txt['mc_unapproved_topics'] = 'Subiecte';
$txt['mc_unapproved_by'] = 'de';
$txt['mc_unapproved_sure'] = 'Ești sigur că vrei să faci asta?';
$txt['mc_unapproved_attach_name'] = 'Numele atașamentului';
$txt['mc_unapproved_attach_size'] = 'Mărimea fișierului';
$txt['mc_unapproved_attach_poster'] = 'Autor';
$txt['mc_viewmodreport'] = 'Raport de moderare pentru %1$s introdus de %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Membri care au raportat această postare';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Acţiunile celorlalţi moderatori';
$txt['mc_modreport_mod_comments'] = 'Comentariile moderatorilor';
$txt['mc_modreport_no_mod_comment'] = 'În prezent nu sunt comentarii ale moderatorilor.';
$txt['mc_modreport_add_mod_comment'] = 'Adaugă un comentariu';

$txt['show_notice'] = 'Textul anunţului';
$txt['show_notice_subject'] = 'Subiect';
$txt['show_notice_text'] = 'Text';

$txt['mc_watched_users_title'] = 'Membri supravegheaţi';
$txt['mc_watched_users_desc'] = 'Aici puteţi ţine evidenţa tuturor membrilor care au fost &quot;puși sub supraveghere&quot; de către echipa de moderare.';
$txt['mc_watched_users_post'] = 'După mesaje';
$txt['mc_watched_users_warning'] = 'Nivelul avertismentului';
$txt['mc_watched_users_last_login'] = 'Ultima autentificare';
$txt['mc_watched_users_last_post'] = 'Ultimul mesaj postat';
$txt['mc_watched_users_no_posts'] = 'Nu există mesaje postate de membrii supravegheaţi.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Ești sigur că vrei să ştergi acest mesaj?';
$txt['mc_watched_users_delete_posts'] = 'Ești sigur că vrei să ştergi aceste mesaje?';
$txt['mc_watched_users_posted'] = 'Postat';
$txt['mc_watched_users_member'] = 'Membru';

$txt['mc_warnings_description'] = 'Aici poţi vedea ce avertismente au fost emise pentru membrii forumului. De asemenea, poţi adăuga şi modifica şabloanele de notificare folosite atunci când se trimite un avertisment către un utilizator.';
$txt['mc_warning_log'] = 'Jurnal';
$txt['mc_warning_templates'] = 'Şabloane personalizate';
$txt['mc_warning_log_title'] = 'Jurnalul avertismentelor';
$txt['mc_warning_templates_title'] = 'Șabloane de avertisment personalizate';

$txt['mc_warnings_none'] = 'Nu au mai fost emise avertismente.';
$txt['mc_warnings_recipient'] = 'Destinatar';

$txt['mc_warning_templates_none'] = 'Nu a fost creat încă niciun şablon de avertizare';
$txt['mc_warning_templates_time'] = 'Creat la';
$txt['mc_warning_templates_name'] = 'Șablon';
$txt['mc_warning_templates_creator'] = 'Creat de';
$txt['mc_warning_template_add'] = 'Adaugă șablon';
$txt['mc_warning_template_modify'] = 'Editează șablon';
$txt['mc_warning_template_delete'] = 'Şterge șabloanele selectate';
$txt['mc_warning_template_delete_confirm'] = 'Ești sigur că vrei să ştergi şabloanele selectate?';

$txt['mc_warning_template_desc'] = 'Completează detaliile șablonului. Reține că subiectul email-ului nu face parte din șablon. Deasemenea, din moment ce notificarea e trimisă prin MP, poți folosi coduri BBC în textul șablonului. Dacă folosești variabila {MESSAGE} atunci acest șablon nu va fi disponibil pentru emiterea de avertismente generice (care nu sunt legate de un mesaj).';
$txt['mc_warning_template_title'] = 'Titlu șablon ';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

Ai primit un avertisment pentru comportament nepotrivit. Te rugăm să încetezi acest gen de activități și să respecți regulile forumului. În caz contrar, vom fi nevoiți să luăm măsuri suplimentare.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Şablon personal';
$txt['mc_warning_template_personal_desc'] = 'Dacă selectezi această opţiune, numai tu vei putea vedea, edita şi folosi acest şablon. Dacă opţiunea nu este selectată, toţi moderatorii vor putea să utilizeze acest şablon.';
$txt['mc_warning_template_error_no_title'] = 'Titlul notificării nu poate fi gol.';
$txt['mc_warning_template_error_no_body'] = 'Textul notificării nu poate fi gol.';

$txt['mc_settings'] = 'Editează setările';
$txt['mc_prefs_title'] = 'Preferințe';
$txt['mc_prefs_desc'] = 'Aici poți seta unele preferinţe privind activităţile legate de moderare, cum ar fi notificările prin e-mail.';
$txt['mc_prefs_homepage'] = 'Articole afişate pe pagina de moderare';
$txt['mc_prefs_latest_news'] = 'Știrile ElkArte';
$txt['mc_prefs_show_reports'] = 'Arată rapoartele deschise în antetul forumului';
$txt['mc_prefs_notify_report'] = 'Notificări privind subiectele raportate';
$txt['mc_prefs_notify_report_never'] = 'Niciodată';
$txt['mc_prefs_notify_report_moderator'] = 'Pentru secţiuni moderate de mine';
$txt['mc_prefs_notify_report_always'] = 'Întotdeauna';
$txt['mc_prefs_notify_approval'] = 'Notifică-mă privind aprobările în așteptare';
$txt['mc_logoff'] = 'Încheie moderarea';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Adaugă o nouă observaţie';
$txt['mc_add_note'] = 'AdaugăAdaugă';