<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Index Mesaje Personale';
$txt['pm_add'] = 'AdaugăAdaugă';
$txt['make_bcc'] = 'Adăugaţi BCC';
$txt['pm_to'] = 'La';
$txt['pm_bcc'] = 'Bcc';
$txt['inbox'] = 'Primite';
$txt['conversation'] = 'Conversație';
$txt['messages'] = 'Mesaje';
$txt['sent_items'] = 'Trimise';
$txt['new_message'] = 'Mesaj Nou';
$txt['delete_message'] = 'Ştergere Mesaje';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Ştergeţi toate mesajele din PMBOX (căsuţa dumneavoastră de mesaje personale)';
$txt['delete_all_confirm'] = 'Sunteţi sigur(ă) că doriţi să ştergeţi toate mesajele?';

$txt['delete_selected_confirm'] = 'Eşti sigur că vrei să ştergi toate mesajele personale selectate?';

$txt['sent_to'] = 'Trimis la';
$txt['reply_to_all'] = 'Răspundeţi Tuturor';
$txt['delete_conversation'] = 'Ștergere Conversație';

$txt['pm_capacity'] = 'Capacitate';
$txt['pm_currently_using'] = '%1$s mesaje, %2$s%% plin.';
$txt['pm_sent'] = 'Mesajul dumneavoastră a fost trimis cu succes.';

$txt['pm_error_user_not_found'] = 'E imposibil de găsit membrul \'%1$s\'. ';
$txt['pm_error_ignored_by_user'] = 'Utilizatorul \'%1$s\' a blocat mesajul dumneavoastră privat.';
$txt['pm_error_data_limit_reached'] = 'MP nu a putut fi trimis utilizatorului \'%1$s\' pentru că inbox-ul său este plin.';
$txt['pm_error_user_cannot_read'] = 'Utilizatorul \'%1$s\' nu poate primi mesaje private.';
$txt['pm_successfully_sent'] = 'Mesajul Privat a fost trimis cu succes către \'%1$s\'. ';
$txt['pm_send_report'] = 'Trimite raportul';
$txt['pm_undisclosed_recipients'] = 'destinatari secreţi';
$txt['pm_too_many_recipients'] = 'Nu poţi trimite mesaje private la mai mult de %1$d destinatar(i) în acelaşi timp.';

$txt['pm_read'] = 'Citit de ';
$txt['pm_replied'] = 'Răspuns la';
$txt['pm_mark_unread'] = 'Marchează ca necitit';

// Message Pruning.
$txt['pm_prune'] = 'Triază mesajele';
$txt['pm_prune_desc'] = 'Șterge toate mesajele personale mai vechi de %1$s zile.';
$txt['pm_prune_warning'] = 'Sunteţi sigur(ă) că doriţi să reciclaţi mesajele dumneavoastră personale?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Acțiuni ulterioare';
$txt['pm_actions_delete_selected'] = 'Şterge cele selectate';
$txt['pm_actions_filter_by_label'] = 'Filtrează după etichetă';
$txt['pm_actions_go'] = 'Mergi';

// Manage Labels Screen.
$txt['pm_apply'] = 'Aplică';
$txt['pm_manage_labels'] = 'Administrează etichetele';
$txt['pm_labels_delete'] = 'Eşti sigur că vrei să ştergi etichetele selectate?';
$txt['pm_labels_desc'] = 'De aici se pot adăuga, edita şi şterge etichetele utilizate în centrul dumneavoastră  de mesaje personale.';
$txt['pm_label_add_new'] = 'Add new label';
$txt['pm_label_name'] = 'Label name';
$txt['pm_labels_no_exist'] = 'În acest moment nu este setată nicio etichetă!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Etichetă';
$txt['pm_msg_label_title'] = 'Label message';
$txt['pm_msg_label_apply'] = 'Add label';
$txt['pm_msg_label_remove'] = 'Remove label';
$txt['pm_msg_label_inbox'] = 'Primite';
$txt['pm_sel_label_title'] = 'Label selected';

// Sidebar Headings.
$txt['pm_labels'] = 'Etichete';
$txt['pm_messages'] = 'Mesaje';
$txt['pm_actions'] = 'Acțiuni';
$txt['pm_preferences'] = 'Preferinţe';

$txt['pm_is_replied_to'] = 'Aţi transmis mai departe sau aţi răspuns la acest mesaj.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Report to admin';
$txt['pm_report_title'] = 'Report personal message';
$txt['pm_report_desc'] = 'Din această pagină poţi reclama un mesaj personal primit de tine la administratorii forumului. Te rugăm să scrii motivele pentru care reclami acest mesaj, deoarece acestea vor fi ataşate la transcrierea identică a mesajului.';
$txt['pm_report_admins'] = 'Administratorul căruia i se va trimite raportul';
$txt['pm_report_all_admins'] = 'Trimite către toţi administratorii forumului';
$txt['pm_report_reason'] = 'Motivul pentru care raportaţi acest mesaj';
$txt['pm_report_message'] = 'Raportare Mesaj';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[RAPORTARE] ';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} a raportat mesajul personal de mai jos, trimis de {SENDER}, din următoarele motive: ';
$txt['pm_report_pm_other_recipients'] = 'Alţi destinatari ai mesajului includ:';
$txt['pm_report_pm_hidden'] = '%1$d destinatar(i) ascunş(i)';
$txt['pm_report_pm_unedited_below'] = 'În continuare este transcrierea originală a mesajului raportat:';
$txt['pm_report_pm_sent'] = 'Trimis:';

$txt['pm_report_done'] = 'Mulţumim pentru că ai trimis acest raport. Vei avea un răspuns de la echipa de administratori cât mai curând.';
$txt['pm_report_return'] = 'Înapoi la cutia poştală';

$txt['pm_search_title'] = 'Search personal messages';
$txt['pm_search_bar_title'] = 'Search messages';
$txt['pm_search_text'] = 'Caută';
$txt['pm_search_go'] = 'Căutări';
$txt['pm_search_advanced'] = 'Arată opțiunile avansate';
$txt['pm_search_simple'] = 'Ascunde opțiunile avansate';
$txt['pm_search_user'] = 'După utilizator';
$txt['pm_search_match_all'] = 'Potriviţi toate cuvintele';
$txt['pm_search_match_any'] = 'Potriviţi orice cuvinte';
$txt['pm_search_options'] = 'Opţiuni';
$txt['pm_search_post_age'] = 'Vechimea mesajului ';
$txt['pm_search_show_complete'] = 'Afişează mesajul întreg în rezultate.';
$txt['pm_search_subject_only'] = 'Căutare numai după subiect şi autor.';
$txt['pm_search_sent_only'] = 'Search only in sent items.';
$txt['pm_search_between'] = 'între';
$txt['pm_search_between_and'] = 'şi';
$txt['pm_search_between_days'] = 'zile';
$txt['pm_search_order'] = 'Ordinea căutării';
$txt['pm_search_choose_label'] = 'Alegeţi etichetele după care să căutaţi sau căutaţi tot';

$txt['pm_search_results'] = 'Search results';
$txt['pm_search_none_found'] = 'No messages found';

$txt['pm_search_orderby_relevant_first'] = 'Cel mai relevant mai întâi';
$txt['pm_search_orderby_recent_first'] = 'Cel mai recent mai întâi';
$txt['pm_search_orderby_old_first'] = 'Cel mai vechi mai întâi';

$txt['pm_visual_verification_label'] = 'Verificare';
$txt['pm_visual_verification_desc'] = 'Please enter the code in the image above in order to send this PM.';

$txt['pm_settings'] = 'Change settings';
$txt['pm_change_view'] = 'Change view';

$txt['pm_manage_rules'] = 'Manage rules';
$txt['pm_manage_rules_desc'] = 'Aceste reguli şi filtre îţi permit sortarea automată a mesajelor personale în funcţie de criteriile definite de tine. Mai jos sunt filtrele deja create. Pentru a modifica un filtru trebuie doar să dai click pe numele lui.';
$txt['pm_rules_none'] = 'Nu este setat niciun filtru în acest moment.';
$txt['pm_rule_title'] = 'Regulă';
$txt['pm_add_rule'] = 'Add new rule';
$txt['pm_apply_rules'] = 'Apply rules now';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Sunteţi sigur că doriţi să aplicaţi regulile actuale tuturor mesajelor personale ?';
$txt['pm_edit_rule'] = 'Edit rule';
$txt['pm_rule_save'] = 'Save rule';
$txt['pm_delete_selected_rule'] = 'Delete selected rules';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Sunteţi sigur(ă) că doriţi să ştergeţi regulile selectate ?';
$txt['pm_rule_name'] = 'Nume';
$txt['pm_rule_name_desc'] = 'Denumire după care să ne amintim de această regulă';
$txt['pm_rule_name_default'] = '[NAME]';
$txt['pm_rule_description'] = 'Descriere';
$txt['pm_rule_not_defined'] = 'Adaugă unele criterii pentru a începe construirea descrierii aceastei reguli.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>Observaţie:</strong> Figuraţi ca având JavaScript dezactivat.  Vă recomandăm să activaţi JavaScript pentru a utiliza această facilitate.</span>';
$txt['pm_rule_criteria'] = 'Criterii';
$txt['pm_rule_criteria_add'] = 'Add criteria';
$txt['pm_rule_criteria_pick'] = 'Choose criteria';
$txt['pm_rule_mid'] = 'Sender name';
$txt['pm_rule_gid'] = 'Sender\'s group';
$txt['pm_rule_sub'] = 'Message subject contains';
$txt['pm_rule_msg'] = 'Message body contains';
$txt['pm_rule_bud'] = 'Sender is buddy';
$txt['pm_rule_sel_group'] = 'Select group';
$txt['pm_rule_logic'] = 'When checking criteria';
$txt['pm_rule_logic_and'] = 'Toate criteriile trebuie să fie îndeplinite';
$txt['pm_rule_logic_or'] = 'Orice criterii pot fi satisfăcute';
$txt['pm_rule_actions'] = 'Acțiuni';
$txt['pm_rule_sel_action'] = 'Select an action';
$txt['pm_rule_add_action'] = 'Add action';
$txt['pm_rule_label'] = 'Etichetează mesajul cu ';
$txt['pm_rule_sel_label'] = 'Select label';
$txt['pm_rule_delete'] = 'Delete message';
$txt['pm_rule_no_name'] = 'Aţi uitat să introduceţi un nume pentru regulă.';
$txt['pm_rule_no_criteria'] = 'O regulă trebuie să aibă cel puţin un criteriu şi o acţiune.';
$txt['pm_rule_too_complex'] = 'The rule you are creating is too long to save. Try breaking it up into smaller rules.';

$txt['pm_readable_and'] = '<em>şi</em>  ';
$txt['pm_readable_or'] = '<em>sau</em>  ';
$txt['pm_readable_start'] = 'Dacă';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'mesajul este de la &quot;{MEMBER}&quot; ';
$txt['pm_readable_group'] = 'expeditorul este din grupul &quot;{GROUP}&quot;';
$txt['pm_readable_subject'] = 'subiectul mesajului conţine &quot;{SUBJECT}&quot; ';
$txt['pm_readable_body'] = 'corpul mesajului conţine &quot;{BODY}&quot; ';
$txt['pm_readable_buddy'] = 'Expeditorul este un amic';
$txt['pm_readable_label'] = 'Aplicaţi eticheta &quot;{LABEL}&quot; ';
$txt['pm_readable_delete'] = 'şterge mesajul';
$txt['pm_readable_then'] = '<strong>apoi</strong>  ';