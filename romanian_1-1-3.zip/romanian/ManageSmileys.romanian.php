<?php
// Version: 1.1; ManageSmileys

$txt['smiley_sets_save'] = 'Salvează modificările';
$txt['smiley_sets_add'] = 'Set nou de emoticoane';
$txt['smiley_sets_delete'] = 'Şterge cele selectate';
$txt['smiley_sets_confirm'] = 'Eşti sigur că vrei să ştergi setul de emoticoane?\\n\\nReţine: Această acţiune nu va şterge şi imaginea, ci doar posibilitatea de a o selecta.';
$txt['smiley_sets_none'] = 'Momentan nu există seturi de emoticoane.';

$txt['setting_smiley_sets_default'] = 'Setul de emoticoane implicit';
$txt['setting_smiley_sets_enable'] = 'Permite membrilir să selecteze setul de emoticoane';
$txt['setting_smiley_enable'] = 'Activează emoticoanele personalizate';
$txt['setting_smileys_url'] = 'URL-ul de bază a seturilor de emoticoane';
$txt['setting_smileys_dir'] = 'Calea absolută către toate seturile de emoticoane';
$txt['setting_messageIcons_enable'] = 'Activează imaginile personalizate pentru mesaje';
$txt['setting_messageIcons_enable_note'] = '(dacă nu, vor fi utilizate pictogramele implicite.)';
$txt['groups_manage_smileys'] = 'Grupuri de utilizatori care au permisiunea de a administra emoticoanele şi pictogramele';

$txt['smiley_sets_name'] = 'Nume';
$txt['smiley_sets_url'] = 'URL';
$txt['smiley_sets_default'] = 'Implicit';

$txt['smileys_add_method'] = 'Sursa imaginii';
$txt['smileys_add_existing'] = 'Folosește un fișier existent';
$txt['smileys_add_upload'] = 'Încarcă un emoticon nou';
$txt['smileys_add_upload_choose'] = 'Încarcă fișierul';
$txt['smileys_add_upload_choose_desc'] = 'Imaginea utilizată de toate seturile de emoticoane.';
$txt['smileys_add_upload_all'] = 'Aceeaşi imagine pentru toate seturile';
$txt['smileys_add_upload_for1'] = 'Imaginea pentru';
$txt['smileys_add_upload_for2'] = 'set';

$txt['smileys_enable_note'] = '(dacă nu, setul implicit va fi folosit.)';
$txt['smileys_code'] = 'Cod';
$txt['smileys_filename'] = 'Numele fişierului';
$txt['smileys_description'] = 'Indiciu sau descriere';
$txt['smileys_remove'] = 'Elimină';
$txt['smileys_save'] = 'Salvează modificările';
$txt['smileys_delete'] = 'Elimină emoticonul';
// Don't use entities in the below string.
$txt['smileys_delete_confirm'] = 'Eşti sigur că vrei să ştergi acest emoticon ?';
$txt['smileys_with_selected'] = 'Cu cele selectate';
$txt['smileys_make_hidden'] = 'Marchează ascunse';
$txt['smileys_show_on_post'] = 'Afișează în formularul pentru postare';
$txt['smileys_show_on_popup'] = 'Arată într-un popup';

$txt['smiley_settings_explain'] = 'Aici poți să schimbi setul de emoticoane implicit, să permiți utilizatorilor să-şi selecteze propriile emoticoane şi să setezi căile către directoare şi informaţiile de configurare.';
$txt['smiley_editsets_explain'] = 'Seturile de emoticoane sunt grupuri din care utilizatorii pot alege emoticoane. De exemplu poţi avea emoticoane galbene şi roşii.<br />Aici poţi schimba numele şi locaţia pentru fiecare set de emoticoane - nu uita, totuşi, că toate seturile folosesc aceleaşi emoticoane.';
$txt['smiley_editsmileys_explain'] = 'Schimbă emoticoanele dând click pe emoticonul pe care vrei să-l modifici. Reţine că toate aceste emoticoane trebuie să existe în toate seturile altfel unele emoticoane nu vor fi afişate! Nu uita să salvezi după ce termini de modificat!';
$txt['smiley_setorder_explain'] = 'Schimbă ordinea emoticoanelor.';
$txt['smiley_addsmiley_explain'] = 'Aici puteţi adăuga un emoticon nou - fie dintr-un fişier deja existent, fie prin încărcarea unora noi.';

$txt['smiley_set_select_default'] = 'Setul de emoticoane implicit';
$txt['smiley_set_new'] = 'Creează un set de emoticoane nou';
$txt['smiley_set_modify_existing'] = 'Modifică un set de emoticoane existent';
$txt['smiley_set_modify'] = 'Modifică';
$txt['smiley_set_import_directory'] = 'Importă emoticoanele din acest director';
$txt['smiley_set_import_single'] = 'A rămas un emoticon în acest set care nu a fost importat. Fă click';
$txt['smiley_set_import_multiple'] = 'Mai sunt %1$d emoticoane în director care nu au fost importate încă. Fă click';
$txt['smiley_set_to_import_single'] = 'pentru a îl importa acum';
$txt['smiley_set_to_import_multiple'] = 'pentru a le importa acum';

$txt['smileys_location'] = 'Locaţia';
$txt['smileys_location_form'] = 'Formularul de postare a mesajului';
$txt['smileys_location_hidden'] = 'Ascunşi';
$txt['smileys_location_popup'] = 'Popup';
$txt['smileys_modify'] = 'Modifică';
$txt['smileys_not_found_in_set'] = 'emoticoane negăsite în acest(e) set(uri)';
$txt['smileys_default_description'] = '(Inserează o descriere)';
$txt['smiley_new'] = 'Adaugă un emoticon nou';
$txt['smiley_modify_existing'] = 'Modifică emoticonul';
$txt['smiley_preview'] = 'Previzualizare';
$txt['smiley_preview_using'] = 'folosind setul de emoticoane';
$txt['smileys_confirm'] = 'Eşti sigur că vrei să elimini aceste emoticoane?\\n\\nReţine: Acesta nu va şterge fişierele, ci doar opţiunile.';
$txt['smileys_location_form_description'] = 'Aceste emoticoane vor apare deasupra zonei text, atunci când se postează un mesaj nou pe forum sau se trimite un Mesaj Personal.';
$txt['smileys_location_popup_description'] = 'Aceste emoticoane vor fi afişate într-o fereastră popup, care este afişată atunci când un utilizator a dat click pe \'[mai multe]\'';
$txt['smileys_move_select_destination'] = 'Selectează destinaţia emoticoanelor';
$txt['smileys_move_select_smiley'] = 'Selectează emoticunul pe care să-l muți sau trage-l în locația pe care o dorești';
$txt['smileys_move_here'] = 'Mută emoticoanele la această locaţie';
$txt['smileys_no_entries'] = 'În prezent nu sunt emoticoane configurate.';
$txt['smileys_moved_done'] = 'Emoticoanele au fost mutate cu succes';
$txt['smileys_moved_fail'] = 'Nu pot muta emoticonul';

$txt['icons_edit_icons_explain'] = 'Aici poţi modifica pictogramele care sunt disponibile în forum. Poţi adăuga, edita sau şterge pictograme. Poți limita utilizarea lor doar în anumite secţiuni.';
$txt['icons_edit_icons_all_boards'] = 'Disponibile în toate ariile';
$txt['icons_board'] = 'Arie';
$txt['icons_confirm'] = 'Eşti sigur că vrei să ştergi aceste pictograme?\\\\n\\\\nReţine: acest lucru nu îi va îimpiedica pe utilizatorii noi care postează să folosească aceste pictograme - imaginile nu sunt şterse';
$txt['icons_add_new'] = 'Adaugă o pictogramă nouă';

$txt['icons_edit_icon'] = 'Editează pictograma de mesaj';
$txt['icons_new_icon'] = 'Pictogramă de mesaj nouă';
$txt['icons_location_first_icon'] = 'Ca prima pictogramă';
$txt['icons_location_after'] = 'După';
$txt['icons_filename_all_png'] = 'Toate fișierele trebuie să fie &quot;.png&quot;';
$txt['icons_no_entries'] = 'În prezent nu sunt definite pictograme de mesaj.';
$txt['icons_reordered'] = 'Pictogramele de mesaj au fost ordonate cu succes';
$txt['icons_reorder_note'] = 'Poți modifica ordinea pictogramelor de mesaj trăgându-le în locația dorită din listă.';