<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Dată';
$txt['modlog_member'] = 'Membru';
$txt['modlog_position'] = 'Poziția';
$txt['modlog_action'] = 'Acţiune';
$txt['modlog_ip'] = 'IP';
$txt['modlog_search_result'] = 'Rezultatele căutării';
$txt['modlog_total_entries'] = 'Totalul înregistrărilor';
$txt['modlog_ac_approve_topic'] = 'Subiect aprobat &quot;{topic}&quot; de &quot;{member}&quot;';
$txt['modlog_ac_unapprove_topic'] = 'Subiect respins &quot;{topic}&quot; de &quot;{member}&quot;';
$txt['modlog_ac_approve'] = 'Mesaj aprobat &quot;{subject}&quot; în &quot;{topic}&quot; de &quot;{member}&quot;';
$txt['modlog_ac_unapprove'] = 'Mesaj neaprobat &quot;{subject}&quot; în &quot;{topic}&quot; de &quot;{member}&quot;';
$txt['modlog_ac_lock'] = 'Subiect blocat &quot;{topic}&quot;';
$txt['modlog_ac_warning'] = '{member} a fost avertizat pentru &quot;{message}&quot;';
$txt['modlog_ac_unlock'] = 'Subiect deblocat &quot;{topic}&quot;';
$txt['modlog_ac_sticky'] = '&quot;{topic}&quot; fixat';
$txt['modlog_ac_unsticky'] = '&quot;{topic}&quot; eliberat';
$txt['modlog_ac_delete'] = 'Subiect șters &quot;{subject}&quot; de &quot;{member}&quot; din &quot;{topic}&quot;';
$txt['modlog_ac_delete_member'] = 'Membru şters &quot;{name}&quot;';
$txt['modlog_ac_remove'] = 'Subiect şters &quot;{topic}&quot; din &quot;{board}&quot;';
$txt['modlog_ac_modify'] = 'Editat &quot;{message}&quot; de către &quot;{member}&quot;';
$txt['modlog_ac_merge'] = 'Subiecte unite pentru a crea &quot;{topic}&quot;';
$txt['modlog_ac_split'] = 'Subiect divizat &quot;{topic}&quot; pentru a crea &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = 'Subiect mutat &quot;{topic}&quot; din &quot;{board_from}&quot; în &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Profil modificat &quot;{member}&quot;';
$txt['modlog_ac_pruned'] = 'Au fost reciclate unele mesaje mai vechi de {days} zile';
$txt['modlog_ac_news'] = 'Ştiri editate';
$txt['modlog_enter_comment'] = 'Introdu comentariul moderatorului';
$txt['modlog_moderation_log'] = 'Jurnalul de moderare';
$txt['modlog_moderation_log_desc'] = 'Mai jos este afișată o listă a acţiunilor de moderare executate de către moderatorii forumului.<br /><strong>Reţne:</strong> Înregistrările nu pot fi şterse din acest log înainte de a avea minim 24 de ore vechime.';
$txt['modlog_no_entries_found'] = 'In acest moment nu există nici o înregistrare în jurnalul de moderare.';
$txt['modlog_remove'] = 'Şterge șabloanele selectate';
$txt['modlog_removeall'] = 'Golește jurnalul';
$txt['modlog_remove_selected_confirm'] = 'Ești sigur că vrei să ștergi înregistrările selectate din jurnal?';
$txt['modlog_remove_all_confirm'] = 'Ești sigur că vrei să golești complet jurnalul?';
$txt['modlog_go'] = 'Mergi';
$txt['modlog_add'] = 'AdaugăAdaugă';
$txt['modlog_search'] = 'Căutare Rapidă';
$txt['modlog_by'] = 'după';
$txt['modlog_id'] = '<em>Șters - ID:%1$d</em>  ';

$txt['modlog_ac_add_warn_template'] = 'A fost adăugat template-ul de avertizare: &quot;{template}&quot;';
$txt['modlog_ac_modify_warn_template'] = 'A fost editat template-ul de avertizare: &quot;{template}&quot;';
$txt['modlog_ac_delete_warn_template'] = 'A fost șters template-ul de avertizare &quot;{template}&quot;';

$txt['modlog_ac_ban'] = 'Au fost adăugate declanşatoarele de interdicţii:';
$txt['modlog_ac_ban_update'] = 'Au fost editate declanşatoare de interdicţii:';
$txt['modlog_ac_ban_remove'] = 'Au fost eliminate declanşatoare de interdicţii:';
$txt['modlog_ac_ban_trigger_member'] = '<em>Membru:</em> {member}';
$txt['modlog_ac_ban_trigger_email'] = '<em>Email:</em> {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = '<em>IP:</em> {ip_range}';
$txt['modlog_ac_ban_trigger_hostname'] = '<em>Hostname:</em> {hostname}';

$txt['modlog_admin_log'] = 'Jurnal de administrare';
$txt['modlog_admin_log_desc'] = 'Mai jos este afișată lista acţiunilor de administrare care au fost jurnalizate pe forum.<br /><strong>Reţine:</strong> Intrările nu pot fi eliminate din acest log înainte de a avea cel puţin douăzeci şi patru de ore vechime.';
$txt['modlog_admin_log_no_entries_found'] = 'În prezent nu sunt înregistrări în jurnalul de administrare.';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Forumul a fost actualizat la versiunea {version}';
$txt['modlog_ac_install'] = 'A fost instalată versiunea {version}';
$txt['modlog_ac_add_board'] = 'A fost adăugată o nouă secţiune: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Secţiunea &quot;{board}&quot; a fost editată';
$txt['modlog_ac_delete_board'] = 'Secţiunea &quot;{boardname}&quot; a fost ştearsă';
$txt['modlog_ac_add_cat'] = 'A fost adăugată o categorie nouă, &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Categoria &quot;{catname}&quot; a fost editată';
$txt['modlog_ac_delete_cat'] = 'Categoria &quot;{catname}&quot; a fost ştearsă';

$txt['modlog_ac_delete_group'] = 'Grupul &quot;{group}&quot; a fost şters';
$txt['modlog_ac_add_group'] = 'A fost adăugat grupul &quot;{group}&quot;';
$txt['modlog_ac_edited_group'] = 'Grupul &quot;{group}&quot; a fost editat';
$txt['modlog_ac_added_to_group'] = '&quot;{member}&quot; a fost adăugat în grupul &quot;{group}&quot;';
$txt['modlog_ac_removed_from_group'] = '&quot;{member}&quot; a fost şters din grupul &quot;{group}&quot;';
$txt['modlog_ac_removed_all_groups'] = '&quot;{member}&quot; a fost eliminat din toate grupurile';

$txt['modlog_ac_remind_member'] = 'A fost trimis un memento către &quot;{member}&quot; pentru a-şi activa contul';
$txt['modlog_ac_approve_member'] = 'Contul utilizatorului &quot;{member}&quot; a fost aprobat/activat';
$txt['modlog_ac_newsletter'] = 'A fost trimis buletinul de știri';

$txt['modlog_ac_install_package'] = 'Pachet nou instalat: &quot;{package}&quot;, versiunea {version}';
$txt['modlog_ac_upgrade_package'] = 'Pachet actualizat: &quot;{package}&quot; la versiunea {version}';
$txt['modlog_ac_uninstall_package'] = 'Pachet dezinstalat: &quot;{package}&quot;, versiunea {version}';

$txt['modlog_ac_database_backup'] = 'Copie de siguranță a bazei de date, făcută de {member}.';
$txt['modlog_ac_editing_theme'] = '{member} a editat o temă.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Subiect restaurat &quot;{topic}&quot; din &quot;{board}&quot; în &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Mesaje restaurate din &quot;{subject}&quot; în subiectul &quot;{topic}&quot; din secţiunea &quot;{board}&quot;.';

$txt['modlog_parameter_guest'] = '<em>Vizitator</em>';

$txt['modlog_ac_approve_attach'] = 'Atașament &quot;{filename}&quot; aprobat în &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Eliminat atașament neaprobat &quot;{filename}&quot; în &quot;{message}&quot;';