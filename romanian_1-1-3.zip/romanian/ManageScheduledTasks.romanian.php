<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Activităţi planificate';
$txt['scheduled_tasks_header'] = 'Toate activitățileprogramate';
$txt['scheduled_tasks_name'] = 'Numele activității';
$txt['scheduled_tasks_next_time'] = 'Următoarea activare';
$txt['scheduled_tasks_regularity'] = 'Regularitate';
$txt['scheduled_tasks_enabled'] = 'Activat';
$txt['scheduled_tasks_run_now'] = 'Ruleză comanda acum';
$txt['scheduled_tasks_save_changes'] = 'Salvează modificările';
$txt['scheduled_tasks_time_offset'] = '<strong>Reține:</strong>  Toți timpii afișați mai jos arată <em>ora serverului</em> și nu țin cont de decalajele orare definite în panoul de administrare.';
$txt['scheduled_tasks_were_run'] = 'Toate activitățile selectate au fost finalizate';
$txt['scheduled_tasks_were_run_errors'] = 'La rularea activităților programate au apărut următoarele erori:';

$txt['scheduled_tasks_na'] = 'N/A';
$txt['scheduled_task_approval_notification'] = 'Notificări de Aprobări';
$txt['scheduled_task_desc_approval_notification'] = 'Trimite mesaje de e-mail tuturor moderatorilor cu sumarul mesajelor care sunt în aşteptarea aprobării';
$txt['scheduled_task_auto_optimize'] = 'Optimizează baza de date';
$txt['scheduled_task_desc_auto_optimize'] = 'Are loc o optimizare a bazei de date pentru a corecta probleme generate de fragmentare.';
$txt['scheduled_task_daily_maintenance'] = 'Mentenanţă zilnică';
$txt['scheduled_task_desc_daily_maintenance'] = 'Are loc o mentenanţă zilnică importantă a forumului - nu trebuie să fie dezactivată.';
$txt['scheduled_task_daily_digest'] = 'Sumarul notificărilor zilnice';
$txt['scheduled_task_desc_daily_digest'] = 'Trimite un sumar al notificărilor celor care sunt abonaţi.';
$txt['scheduled_task_weekly_digest'] = 'Sumarul notificărilor săptămânale';
$txt['scheduled_task_desc_weekly_digest'] = 'Trimite un sumar săptămânal al notificărilor celor care sunt abonaţi.';
$txt['scheduled_task_birthdayemails'] = 'Trimite emailuri cu ocazia zilelor de naştere';
$txt['scheduled_task_desc_birthdayemails'] = 'Trimite celor care au ziua de naştere urări de la mulţi ani.';
$txt['scheduled_task_weekly_maintenance'] = 'Mentenanţă săptămânală';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Are loc o mentenanţă săptămânală importantă a forumului - nu trebuie să fie dezactivată.';
$txt['scheduled_task_paid_subscriptions'] = 'Verifică abonamentele cu plată';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Se va trimite o atenţionare de plată pentru abonaţii cu plată şi se vor şterge abonamentele expirate ale utilizatorilor.';
$txt['scheduled_task_remove_topic_redirect'] = 'Elimină subiectele de redirectare a subiectelor mutate';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Șterge subiectele de notificare „MUTAT:”create când subiectele au fost mutate.';
$txt['scheduled_task_remove_temp_attachments'] = 'Elimină fișierele temporare ale atașamentelor';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Șterge fișierele temporare create la atașarea unui fișier la o postare și care, din diverse motive, nu au fost șterse sau redenumite.';
$txt['scheduled_task_remove_old_drafts'] = 'Elimină ciornele vechi';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Șterge ciornele mai vechi decât numărul de zile specificat în setările pentru ciorne din panoul de administrare.';
$txt['scheduled_task_remove_old_followups'] = 'Elimină abonările vechi';
$txt['scheduled_task_desc_remove_old_followups'] = 'Șterge înregistrările abonărilor vechi, prezente încă în baza de date dar care indică spre subiecte care nu mai există.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Importă email-uri din IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Importă email-urile pentru lista de email-uri dintr-o căsuță IMAP și le procesează.';
$txt['scheduled_task_user_access_mentions'] = 'Accesul la menționările utilizatorilor';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verifică accesul utilizatorilor la fiecare arie și setează accesul la mențiunile respective  în consecință.';

$txt['scheduled_task_reg_starting'] = 'Începe la %1$s';
$txt['scheduled_task_reg_repeating'] = 'cu repetare la fiecare %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minut(e)';
$txt['scheduled_task_reg_unit_h'] = 'ore';
$txt['scheduled_task_reg_unit_d'] = 'zi(le)';
$txt['scheduled_task_reg_unit_w'] = 'săptămâni';

$txt['scheduled_task_edit'] = 'Editează activitatea programată';
$txt['scheduled_task_edit_repeat'] = 'Repetă activitatea la fiecare';
$txt['scheduled_task_edit_pick_unit'] = 'Alege unitatea de timp';
$txt['scheduled_task_edit_interval'] = 'Interval';
$txt['scheduled_task_edit_start_time'] = 'Începere la';
$txt['scheduled_task_edit_start_time_desc'] = 'Ora la care să pornească prima rulare (ora:minutul)';
$txt['scheduled_task_time_offset'] = 'De reţinut că timpul de început ar trebui să fie compensat faţă de timpul curent al serverului. Timpul curent al serverului este: %1$s';

$txt['scheduled_view_log'] = 'Vezi log';
$txt['scheduled_log_empty'] = 'În prezent nu sunt înregistrări în jurnalul de activități.';
$txt['scheduled_log_time_run'] = 'Ora rulării';
$txt['scheduled_log_time_taken'] = 'Timp rulat';
$txt['scheduled_log_time_taken_seconds'] = '%1$d secunde';
$txt['scheduled_log_completed'] = 'Activitate finalizată';
$txt['scheduled_log_empty_log'] = 'Golește jurnalul';
$txt['scheduled_log_empty_log_confirm'] = 'Ești sigur că vrei să golești complet jurnalul?';