<?php
// Version: 1.1; ManageMembers

$txt['groups'] = 'Grupuri';
$txt['viewing_groups'] = 'Vezi grupurile de membri';

$txt['membergroups_title'] = 'Administrarea grupurilor de membri';
$txt['membergroups_description'] = 'Grupurile de membri sunt grupuri de utilizatori care au setări de aspect şi drepturi de acces similare. Apartenența la unele grupuri este bazată pe numărul de mesaje postate de utilizator. Puteţi aloca un membru la un grup prin selectarea profilului său urmată de schimbarea setărilor relevante.';
$txt['membergroups_modify'] = 'Modifică';
$txt['membergroups_modify_parent'] = 'Modifică grupul părinte';

$txt['membergroups_add_group'] = 'Adaugă grup';
$txt['membergroups_regular'] = 'Grupuri uzuale';
$txt['membergroups_post'] = 'Grupuri bazate pe numărul de mesaje postate';
$txt['membergroups_guests_na'] = 'nu se aplică';

$txt['membergroups_group_name'] = 'Numele grupului de membri';
$txt['membergroups_new_board'] = 'Secţiuni vizibile grupului';
$txt['membergroups_new_board_desc'] = 'Secţiuni pe care grupul de membri le poate vedea';
$txt['membergroups_new_board_post_groups'] = '<em>Notă: În mod normal, grupurile bazate pe numărul de postări nu au nevoie de acces, deoarece grupul din care face parte membrul îi stabilește accesul.</em>';
$txt['membergroups_new_as_inherit'] = 'moşteneşte de la';
$txt['membergroups_new_as_type'] = 'după tip';
$txt['membergroups_new_as_copy'] = 'bazat pe';
$txt['membergroups_new_copy_none'] = '(niciunul)';
$txt['membergroups_can_edit_later'] = 'Le puteţi edita mai târziu.';

$txt['membergroups_edit_group'] = 'Editează grupul de membri';
$txt['membergroups_edit_name'] = 'Numele grupului';
$txt['membergroups_edit_inherit_permissions'] = 'Moştenește permisiunile';
$txt['membergroups_edit_inherit_permissions_desc'] = 'Selectează &quot;Nu&quot; pentru a-i permite grupului sa aibă propriul său set de permisiuni.';
$txt['membergroups_edit_inherit_permissions_no'] = 'Nu - Utilizează permisiuni unice';
$txt['membergroups_edit_inherit_permissions_from'] = 'Moştenește de la';
$txt['membergroups_edit_hidden'] = 'Vizibilitate';
$txt['membergroups_edit_hidden_no'] = 'Vizibil';
$txt['membergroups_edit_hidden_boardindex'] = 'Vizibil - cu excepția câmpului pentru grup';
$txt['membergroups_edit_hidden_all'] = 'Invizibil';
// Do not use numeric entities in the below string.
$txt['membergroups_edit_hidden_warning'] = 'Ești sigur(ă) că nu vrei să permiţi atribuirea acestui grup ca grup primar?\\n\\nAcest lucru va limita atribuirea lui doar ca grup adiţional şi va actualiza toţi membrii &quot;primari&quot; pentru a-l avea doar ca grup adiţional.';
$txt['membergroups_edit_desc'] = 'Descrierea grupului';
$txt['membergroups_edit_group_type'] = 'Tipul grupului';
$txt['membergroups_edit_select_group_type'] = 'Selectează tipul grupului';
$txt['membergroups_group_type_private'] = 'Privat <span class="smalltext">(Calitatea de membru trebuie să fie atribuită)</span>  ';
$txt['membergroups_group_type_protected'] = 'Protejat <span class="smalltext">(Numai administratorii pot gestiona si atribui calitatea de membru)</span>';
$txt['membergroups_group_type_request'] = 'Solicitabil <span class="smalltext">(Utilizatorii pot solicita calitatea de membru)</span>';
$txt['membergroups_group_type_free'] = 'Liber <span class="smalltext">(Utilizatorii pot părăsi şi se pot alătura grupului când doresc)</span>  ';
$txt['membergroups_group_type_post'] = 'Bazat pe numărul de mesaje postate <span class="smalltext"> (Calitatea de membru se bazează pe numărul de mesaje postate)</span>  ';
$txt['membergroups_min_posts'] = 'Număr minim de mesaje';
$txt['membergroups_online_color'] = 'Culoarea în lista online';
$txt['membergroups_icon_count'] = 'Numărul pictogramelor afișate';
$txt['membergroups_icon_image'] = 'Numele de fișier al imaginii pictogramei';
$txt['membergroups_icon_image_note'] = 'Încarcă imaginile pictogramelor în directorul implicit al temelor pentru a apermite selectarea.<br />Selectează pictograma pentru a o schimba.';
$txt['membergroups_max_messages'] = 'Numărul maxim de mesaje personale';
$txt['membergroups_max_messages_note'] = '0 = nelimitat';
$txt['membergroups_max_messages_desc'] = 'Aici poți defini numărul maxim de mesaje personale pe care un utilizator le poate păstra pe server.<br />Pentru a permite păstrarea unui număr nelimitat de mesaje, setează valoarea la zero';
$txt['membergroups_edit_save'] = 'Salvează';
$txt['membergroups_delete'] = 'Şterge';
$txt['membergroups_confirm_delete'] = 'Ești sigur că vrei să ștergi grupul?';

$txt['membergroups_members_title'] = 'Vezi Grupul';
$txt['membergroups_members_group_members'] = 'Membrii grupului';
$txt['membergroups_members_no_members'] = 'Acest grup este momentan gol';
$txt['membergroups_members_add_title'] = 'Adaugă un membru în grup';
$txt['membergroups_members_add_desc'] = 'Lista membrilor de adăugat ';
$txt['membergroups_members_add'] = 'Adaugă membri';
$txt['membergroups_members_remove'] = 'Elimină din grup';
$txt['membergroups_members_last_active'] = 'Ultima dată activ';
$txt['membergroups_members_additional_only'] = 'Adaugă doar ca grup adiţional.';
$txt['membergroups_members_group_moderators'] = 'Grupul moderatorilor';
$txt['membergroups_members_description'] = 'Descriere';
// Use javascript escaping in the below.
$txt['membergroups_members_deadmin_confirm'] = 'Ești sigur că vrei să te elimini din grupul de Administratori ?';

$txt['membergroups_postgroups'] = 'Grupuri bazate pe numărul de postări';
$txt['membergroups_settings'] = 'Setările grupului de membri';
$txt['groups_manage_membergroups'] = 'Grupuri care au permisiunea de a edita grupurile de membri';
$txt['membergroups_select_permission_type'] = 'Selectează profilul de permisiuni';
$txt['membergroups_images_url'] = '{theme URL}/images/group_icons/';
$txt['membergroups_select_visible_boards'] = 'Afişează ariile';
$txt['membergroups_members_top'] = 'Membri';
$txt['membergroups_name'] = 'Nume';
$txt['membergroups_icons'] = 'Iconițe';

$txt['admin_browse_approve'] = 'Membrii ale căror conturi sunt în aşteptarea aprobării ';
$txt['admin_browse_approve_desc'] = 'De aici puteţi gestiona toţi membrii care aşteaptă să le fie aprobate conturile.';
$txt['admin_browse_activate'] = 'Membri ale căror conturi sunt în aşteptarea de activării';
$txt['admin_browse_activate_desc'] = 'Aici sunt afișați toţi membrii care nu şi-au activat conturile încă.';
$txt['admin_browse_awaiting_approval'] = 'Așteaptă aprobare [%1$d]';
$txt['admin_browse_awaiting_activate'] = 'Așteaptă activare [%1$d]';

$txt['admin_browse_username'] = 'Numele de utilizator';
$txt['admin_browse_email'] = 'Adresa de email';
$txt['admin_browse_ip'] = 'Adresă IP';
$txt['admin_browse_registered'] = 'Inregistrat ';
$txt['admin_browse_id'] = 'ID';
$txt['admin_browse_with_selected'] = 'Cu cele selectate';
$txt['admin_browse_no_members_approval'] = 'Nu există în prezent membri în aşteaptarea aprobării.
';
$txt['admin_browse_no_members_activate'] = 'Nu există în prezent membri care nu şi-au activat conturile.';

// Don't use entities in the below strings, except the main ones. (lt, gt, quot.)
$txt['admin_browse_warn'] = 'toţi membrii selectaţi?';
$txt['admin_browse_outstanding_warn'] = 'toţi membrii afectaţi?';
$txt['admin_browse_w_approve'] = 'Aprobaă';
$txt['admin_browse_w_activate'] = 'Activare';
$txt['admin_browse_w_delete'] = 'Şterge';
$txt['admin_browse_w_reject'] = 'Respinge (Șterge)';
$txt['admin_browse_w_remind'] = 'Reamintește';
$txt['admin_browse_w_approve_deletion'] = 'Aprobă (Şterge conturi)';
$txt['admin_browse_w_email'] = 'şi trimiteţi un e-mail';
$txt['admin_browse_w_approve_require_activate'] = 'Aprobă și solicită activare';

$txt['admin_browse_filter_by'] = 'Filtrează după';
$txt['admin_browse_filter_show'] = 'În curs de afişare';
$txt['admin_browse_filter_type_0'] = 'Conturi noi neactivate';
$txt['admin_browse_filter_type_2'] = 'Schimbări de email neactivate';
$txt['admin_browse_filter_type_3'] = 'Conturi noi neaprobate';
$txt['admin_browse_filter_type_4'] = 'Ștergeri neaprobate de conturi';
$txt['admin_browse_filter_type_5'] = 'Conturi "Sub limita de vârstă" neaprobate';

$txt['admin_browse_outstanding'] = 'Membri în suspensie';
$txt['admin_browse_outstanding_days_1'] = 'Pentru toţi membrii care s-au înregistrat cu mai mult de';
$txt['admin_browse_outstanding_days_2'] = 'zile în urmă';
$txt['admin_browse_outstanding_perform'] = 'Aplică următoarea acţiune';
$txt['admin_browse_outstanding_go'] = 'Aplică acţiunea ';

$txt['check_for_duplicate'] = 'Caută duplicate';
$txt['dont_check_for_duplicate'] = 'Nu căuta duplicate';
$txt['duplicates'] = 'Duplicat';

$txt['not_activated'] = 'Neactivat';