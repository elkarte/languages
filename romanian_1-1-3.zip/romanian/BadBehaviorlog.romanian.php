<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Dată';
$txt['badbehaviorlog_protocol'] = 'Protocol';
$txt['badbehaviorlog_method'] = 'Metodă';
$txt['badbehaviorlog_request'] = 'Cerere';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'ID-ul membrului';
$txt['badbehaviorlog_username'] = 'Nume de utilizator';
$txt['badbehaviorlog_headers'] = 'Headere';
$txt['badbehaviorlog_agent'] = 'Browser';
$txt['badbehaviorlog_entity'] = 'Postează';
$txt['badbehaviorlog_key'] = 'Cheie';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Totalul înregistrărilor';
$txt['badbehaviorlog_error_valid_code'] = 'Codul motivului';
$txt['badbehaviorlog_error_valid_response'] = 'Status HTTP';
$txt['badbehaviorlog_error_valid_explaination'] = 'Motiv HTTP';
$txt['badbehaviorlog_error_valid_log'] = 'Detalii';
$txt['badbehaviorlog_log'] = 'Jurnalul BadBehavior';
$txt['badbehaviorlog_desc'] = 'Mai jos este afișată lista tuturor evenimentelor BadBehavior care au fost jurnalizate';
$txt['badbehaviorlog_details'] = 'Detalii suplimentare';
$txt['badbehaviorlog_no_entries_found'] = 'În momentul de față nu există evenimente BadBehavior jurnalizate.';

$txt['badbehaviorlog_remove_selection'] = 'Elimină-le pe cele selectate';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Ești sigur că vrei să ștergi înregistrările selectate din jurnal?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Șterge toate rezultatele filtrate';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Ești sigur că vrei să ștergi înregistrările filtrate?';
$txt['badbehaviorlog_sure_remove'] = 'Ești sigur că vrei să golești complet jurnalul BadBehavior?';

$txt['badbehaviorlog_remove'] = 'Şterge șabloanele selectate';
$txt['badbehaviorlog_removeall'] = 'Golește jurnalul';
$txt['badbehaviorlog_clear_filter'] = 'Resetează filtrul';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Filtrează erorile de tip';
$txt['badbehaviorlog_apply_filter'] = 'Aplică filtrul';
$txt['badbehaviorlog_applying_filter'] = 'Se aplică filtrul';
$txt['badbehaviorlog_filter_only_member'] = 'Arată doar evenimentele BadBehavior jurnalizate pentru acest membru';
$txt['badbehaviorlog_filter_only_ip'] = 'Arată doar evenimentele BadBehavior jurnalizate pentru această adresă IP';
$txt['badbehaviorlog_filter_only_session'] = 'Arată doar evenimentele BadBehavior jurnalizate pentru această sesiune';
$txt['badbehaviorlog_filter_only_headers'] = 'Arată doar evenimentele BadBehavior jurnalizate pentru acest URL';
$txt['badbehaviorlog_filter_only_agent'] = 'Arată doar înregistrările cu același „user agent”';

$txt['badbehaviorlog_session'] = 'Sesiune';
$txt['badbehaviorlog_error_url'] = 'URL-ul paginii care a fost înregistrat în jurnal';

$txt['badbehaviorlog_reverse_direction'] = 'Ordonează lista invers cronologic';
$txt['badbehaviorlog_filter_only_type'] = 'Arată doar intrările din jurnal cu acest cod';