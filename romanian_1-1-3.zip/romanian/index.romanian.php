<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'en_US';
$txt['lang_dictionary'] = 'ro';
$txt['lang_spelling'] = 'american';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'Duminică';
$txt['monday'] = 'Luni';
$txt['tuesday'] = 'Marți';
$txt['wednesday'] = 'Miercuri';
$txt['thursday'] = 'Joi';
$txt['friday'] = 'Vineri';
$txt['saturday'] = 'Sâmbătă';

$txt['sunday_short'] = 'Dum';
$txt['monday_short'] = 'Lun';
$txt['tuesday_short'] = 'Mar';
$txt['wednesday_short'] = 'Mie';
$txt['thursday_short'] = 'Joi';
$txt['friday_short'] = 'Vin';
$txt['saturday_short'] = 'Sâm';

$txt['january'] = 'Ianuarie';
$txt['february'] = 'Februarie';
$txt['march'] = 'Martie';
$txt['april'] = 'Aprilie';
$txt['may'] = 'ai';
$txt['june'] = 'Iunie';
$txt['july'] = 'Iulie';
$txt['august'] = 'August';
$txt['september'] = 'Septembrie';
$txt['october'] = 'Octombrie';
$txt['november'] = 'embrie';
$txt['december'] = 'Decembrie';

$txt['january_titles'] = 'Ianuarie';
$txt['february_titles'] = 'Februarie';
$txt['march_titles'] = 'Martie';
$txt['april_titles'] = 'Aprilie';
$txt['may_titles'] = 'ai';
$txt['june_titles'] = 'Iunie';
$txt['july_titles'] = 'Iulie';
$txt['august_titles'] = 'August';
$txt['september_titles'] = 'Septembrie';
$txt['october_titles'] = 'Octombrie';
$txt['november_titles'] = 'embrie';
$txt['december_titles'] = 'Decembrie';

$txt['january_short'] = 'Ianuarie';
$txt['february_short'] = 'Februarie';
$txt['march_short'] = 'Martie';
$txt['april_short'] = 'Aprilie';
$txt['may_short'] = 'ai';
$txt['june_short'] = 'Iunie';
$txt['july_short'] = 'Iulie';
$txt['august_short'] = 'August';
$txt['september_short'] = 'Septembrie';
$txt['october_short'] = 'Octombrie';
$txt['november_short'] = 'Noiembrie';
$txt['december_short'] = 'Decembrie';

$txt['time_am'] = 'a.m.';
$txt['time_pm'] = 'p.m.';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Acasă';
$txt['community'] = 'Comunitate';
// Sub menu labels
$txt['help'] = 'Ajutor';
$txt['search'] = 'Căutări';
$txt['calendar'] = 'Calendar';
$txt['members'] = 'Membri';
$txt['recent_posts'] = 'Mesaje recente';

$txt['admin'] = 'Administrare';
// Sub menu labels
$txt['errlog'] = 'Jurnalul de erori';
$txt['package'] = 'Managerul de pachete';
$txt['edit_permissions'] = 'Permisiuni';
$txt['modSettings_title'] = 'Funcționalități și Opțiuni';

$txt['moderate'] = 'Moderare';
// Sub menu labels
$txt['modlog_view'] = 'Jurnalul de moderare';
$txt['mc_emailerror'] = 'Emailuri neaprobate';
$txt['mc_reported_posts'] = 'Mesaje raportate';
$txt['mc_reported_pms'] = 'Reported Personal Messages';
$txt['mc_unapproved_attachments'] = 'Ataşamente neaprobate';
$txt['mc_unapproved_poststopics'] = 'Mesaje si subiecte neaprobate';

$txt['pm_short'] = 'Mesajele mele';
// Sub menu labels
$txt['pm_menu_read'] = 'Citește mesajele personale';
$txt['pm_menu_send'] = 'Trimite un mesaj';

$txt['account_short'] = 'Contul meu';
// Sub menu labels
$txt['profile'] = 'Profilul';
$txt['mydrafts'] = 'My Drafts';
$txt['summary'] = 'Sumar';
$txt['theme'] = 'Elemente vizuale';
$txt['account'] = 'Setările contului';
$txt['forumprofile'] = 'Profilul pe forum';

$txt['view_unread_category'] = 'Mesaje noi';
$txt['view_replies_category'] = 'Răspunsuri noi';

$txt['login'] = 'Autentificare';
$txt['register'] = 'Înregistrare';
$txt['logout'] = 'Ieșire';
// End main menu strings.

$txt['save'] = 'Salvează';

$txt['modify'] = 'Modifică';
$txt['forum_index'] = '%1$s - Index';
$txt['board_name'] = 'Numele ariei';
$txt['posts'] = 'Postări';

$txt['member_postcount'] = 'Postări';
$txt['no_subject'] = '(Niciun subiect)';
$txt['view_profile'] = 'Vezi profilul';
$txt['guest_title'] = 'Vizitator';
$txt['author'] = 'Autor';
$txt['on'] = 'din';
$txt['remove'] = 'Elimină';
$txt['start_new_topic'] = 'Creează un subiect nou';

// Use numeric entities in the below string.
$txt['username'] = 'Numele de utilizator';
$txt['password'] = 'Parola';

$txt['username_no_exist'] = 'Acest nume de utilizator nu există.';
$txt['no_user_with_email'] = 'Nu există nume de utilizator asociat cu acest e-mail.';

$txt['board_moderator'] = 'Moderatorul ariei';
$txt['remove_topic'] = 'Elimină';
$txt['topics'] = 'Subiecte';
$txt['modify_msg'] = 'Modifică mesajul';
$txt['name'] = 'Nume';
$txt['email'] = 'Email';
$txt['user_email_address'] = 'Adresa de email';
$txt['subject'] = 'Subiect';
$txt['message'] = 'Mesaj';
$txt['redirects'] = 'Redirecţionări';

$txt['choose_pass'] = 'Alege parola';
$txt['verify_pass'] = 'Verifică parola';
$txt['position'] = 'Poziția';
$txt['notify_announcements'] = 'Sign up to receive important site news by email';

$txt['profile_of'] = 'Vezi profilul lui ';
$txt['total'] = 'Total';
$txt['posts_made'] = 'Postări';
$txt['topics_made'] = 'Subiecte';
$txt['website'] = 'Website';
$txt['contact'] = 'Contactează-ne';
$txt['warning_status'] = 'Nivelul avertizărilor';
$txt['user_warn_watch'] = 'Utilizatorul este pe lista celor supravegheaţi de către moderatori';
$txt['user_warn_moderate'] = 'Mesajele utilizatorului au fost puse  în lista de aşteptare pentru aprobarea moderatorilor';
$txt['user_warn_mute'] = 'Utilizatorul este restricționat și nu poate posta';
$txt['warn_watch'] = 'Supravegheat';
$txt['warn_moderate'] = 'Moderat';
$txt['warn_mute'] = 'Nu poate posta';
$txt['warning_issue'] = 'Avertizează';

$txt['message_index'] = 'Index-ul mesajelor';
$txt['news'] = 'Știri';
$txt['page'] = 'Pagină';
$txt['prev'] = 'anterior';
$txt['next'] = 'următor';

$txt['post'] = 'Postează';
$txt['error_occurred'] = 'A apărut o eroare';
$txt['send_error_occurred'] = 'A apărut o eroare. <a href="{href}">Fă click aici ca să încerci din nou</a>.';
$txt['require_field'] = 'Acest câmp este obligatoriu.';
$txt['started_by'] = 'Început de autor';
$txt['topic_started_by'] = 'Început de %1$s';
$txt['topic_started_by_in'] = 'Început de %1$s în %2$s';
$txt['replies'] = 'Răspunsuri';
$txt['last_post'] = 'Ultimul mesaj';
$txt['first_post'] = 'Primul mesaj';
$txt['last_poster'] = 'Autorul ultimului mesaj';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s </span><span class="board_lastposter"> de %1$s</span><span class="board_lasttime"><strong>Ultimul mesaj: </strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s mesaje in %2$s subiecte de %3$s membri';
$txt['show'] = 'Arată';
$txt['hide'] = 'Ascunde';
$txt['sort_by'] = 'Sortează după';
$txt['sort_asc'] = 'Sortează crescător';
$txt['sort_desc'] = 'Sortează descrescător';

$txt['admin_login'] = 'Autentificarea pentru administrare';
// Use numeric entities in the below string.
$txt['topic'] = 'Subiect';
$txt['help'] = 'Ajutor';
$txt['notify'] = 'Abonează-mă';
$txt['unnotify'] = 'Nu mă notifica';
$txt['notify_request'] = 'Vrei să fii notificat printr-un email dacă apar răspunsuri la acest subiect?';
// Use numeric entities in the below string.
$txt['regards_team'] = "Cele bune,\nEchipa {forum_name_html_unsafe}.";
$txt['notify_replies'] = 'Notificare la răspunsuri';
$txt['move_topic'] = 'Mută';
$txt['move_to'] = 'Mută în';
$txt['pages'] = 'Pagini';
$txt['users_active'] = 'Activi în ultimele %1$d minute';
$txt['personal_messages'] = 'Mesaje personale';
$txt['reply_quote'] = 'Răspunde cu citat';
$txt['reply'] = 'Răspuns';
$txt['reply_number'] = 'Răspunsul nr. #%1$s';
$txt['approve'] = 'Aprobaă';
$txt['unapprove'] = 'Respinge';
$txt['approve_all'] = 'aprobă toate';
$txt['awaiting_approval'] = 'Aşteaptă aprobarea';
$txt['attach_awaiting_approve'] = 'Atașamente care aşteaptă aprobarea';
$txt['post_awaiting_approval'] = 'Notă: acest mesaj aşteaptă aprobarea unui moderator.';
$txt['there_are_unapproved_topics'] = 'În această arie așteaptă aprobarea moderatorilor %1$s subiecte și %2$s mesaje. <a href="%3$s">Fă click aici să le vezi</a>.';
$txt['send_message'] = 'Trimite mesaj';

$txt['msg_alert_no_messages'] = 'nu ai nici un mesaj';
$txt['msg_alert_one_message'] = 'ai <a href="%1$s">1 mesaj</a>';
$txt['msg_alert_many_message'] = 'ai <a href="%1$s">%2$d mesaje</a>';
$txt['msg_alert_one_new'] = 'unul este nou';
$txt['msg_alert_many_new'] = '%1$d sunt noi';
$txt['remove_message'] = 'Elimină acest mesaj';

$txt['topic_alert_none'] = 'Nu sunt mesaje...';
$txt['pm_alert_none'] = 'Nu sunt mesaje...';

$txt['online_users'] = 'Utilizatorii online'; //Deprecated
$txt['online_now'] = 'Online acum';
$txt['personal_message'] = 'Mesaje personale';
$txt['jump_to'] = 'Sari la';
$txt['go'] = 'Mergi';
$txt['are_sure_remove_topic'] = 'Eşti sigur că vrei să elimini acest subiect?';
$txt['yes'] = 'Da';
$txt['no'] = 'Nu';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'din';

$txt['search'] = 'Căutări';
$txt['all'] = 'Toate';
$txt['search_entireforum'] = 'Întregul forum';
$txt['search_thisbrd'] = 'Această arie';
$txt['search_thistopic'] = 'Acest subiect';
$txt['search_members'] = 'Membri';

$txt['back'] = 'Înapoi';
$txt['continue'] = 'Continuă';
$txt['password_reminder'] = 'Reamintire parolă';
$txt['topic_started'] = 'Subiect creat de';
$txt['title'] = 'Titlu';
$txt['post_by'] = 'Scris de';
$txt['welcome_newest_member'] = 'Să-i urăm bun-venit lui %1$s, cel mai nou membru al nostru.';
$txt['admin_center'] = 'Centrul de administrare';
$txt['admin_session_active'] = 'Ești într-o sesiune de administrare. Îți recomandăm să <strong><a class="strong" href="%1$s">închei această sesiune</a></strong> imediat ce termini activitățile administrative.';
$txt['admin_maintenance_active'] = 'Forumul este momentan în modul mentenanță, doar administratorii se pot autentifica. Reține să <strong><a class="strong" href="%1$s">închei sesiunea de mentenanță</a></strong> imediat ce finalizezi operațiile de întreținere.';
$txt['query_command_denied'] = 'Verifică instalarea, apar următoarele erori MySQL:';
$txt['query_command_denied_guests'] = 'Se pare că s-a întâmplat ceva cu baza de date a forumului. Problema ar trebui să fie doar temporară așa că revino mai târziu și încearcă din nou. Dacă acest mesaj continuă să apară, transmite administratorului următorul mesaj:';
$txt['query_command_denied_guests_msg'] = 'comanda %1$s este refuzată de baza de date';
$txt['last_edit_by'] = '<span class="lastedit">Modificat ultima dată la </span>: %1$s , de către %2$s';
$txt['notify_deactivate'] = 'Vrei să dezactivezi notificările primite pe mail privind răspunsurile la acest subiect?';

$txt['date_registered'] = 'Data înregistrării';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'Vezi toate mesajele recente.';
$txt['is_recent_updated'] = '%1$s este subiectul actualizat cel mai recent';

$txt['male'] = 'Bărbat';
$txt['female'] = 'Femeie';

$txt['error_invalid_characters_username'] = 'Caracter invalid în numele de utilizator';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Salut,';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Bun venit,';
$txt['select_destination'] = 'Selectează o destinaţie';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Creat de';

$txt['icon_smiley'] = 'Zâmbește';
$txt['icon_angry'] = 'Furios';
$txt['icon_cheesy'] = 'Obraznic';
$txt['icon_laugh'] = 'Râzi';
$txt['icon_sad'] = 'Trist';
$txt['icon_wink'] = 'Fă cu ochiul';
$txt['icon_grin'] = 'Rânjește';
$txt['icon_shocked'] = 'Şocat';
$txt['icon_cool'] = 'Grozav';
$txt['icon_huh'] = 'Ce?';
$txt['icon_rolleyes'] = 'Dă-ți ochii peste cap';
$txt['icon_tongue'] = 'Scoate limba';
$txt['icon_embarrassed'] = 'Ruşinat';
$txt['icon_lips'] = 'Buze lipite';
$txt['icon_undecided'] = 'Nehotărât';
$txt['icon_kiss'] = 'Sărută';
$txt['icon_cry'] = 'Plângi';
$txt['icon_angel'] = 'Nevinovat';

$txt['moderator'] = 'Moderator';
$txt['moderators'] = 'Moderatori';

$txt['views'] = 'Vizualizări';
$txt['new'] = 'Nou';
$txt['no_redir'] = 'Redirectat de la %1$s';

$txt['view_all_members'] = 'Afișează toți membrii';
$txt['view'] = 'Vezi';

$txt['viewing_members'] = 'Vezi membrii de la %1$s la %2$s';
$txt['of_total_members'] = 'din %1$s';

$txt['forgot_your_password'] = 'Ai uitat parola ?';

$txt['date'] = 'Dată';
// Use numeric entities in the below string.
$txt['from'] = 'De la';
$txt['to'] = 'La';

$txt['board_topics'] = 'Subiecte';
$txt['members_title'] = 'Membri';
$txt['members_list'] = 'Lista de membri';
$txt['new_posts'] = 'Mesaje noi';
$txt['old_posts'] = 'Nu sunt mesaje noi';
$txt['redirect_board'] = 'Arie de redirectare';
$txt['redirect_board_to'] = 'Ești redirectat către %1$s';

$txt['sendtopic_send'] = 'Trimite';
$txt['report_sent'] = 'Raportul tău a fost trimis cu succes.';
$txt['topic_sent'] = 'Emailul tău a fost trimis cu succes.';

$txt['time_offset'] = 'Diferența de fus orar';
$txt['or'] = 'sau';

$txt['mention'] = 'Notificări';
$txt['notifications'] = 'Notificări';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = 'Ne pare rău %1$s, ți s-a interzis să folosești acest forum!';
$txt['your_ban_expires'] = 'Această interdicție este setată să expire %1$s.';
$txt['your_ban_expires_never'] = 'Această interdicţie nu este setată să expire.';
$txt['ban_continue_browse'] = 'Poţi continua să navighezi pe forum ca vizitator.';

$txt['mark_as_read'] = 'Marchează TOATE mesajele ca fiind citite';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'Marchează ACESTE mesaje ca citite';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'Subiect închis';
$txt['normal_topic'] = 'Subiect normal';
$txt['participation_caption'] = 'Subiect în care ai scris';

$txt['print'] = 'Tipărește';
$txt['topic_summary'] = 'Rezumatul subiectului';
$txt['not_applicable'] = 'N/A';
$txt['name_in_use'] = 'Numele %1$s este folosit deja de un alt membru.';

$txt['total_members'] = 'Numărul total de membri';
$txt['total_posts'] = 'Total mesaje postate';
$txt['total_topics'] = 'Numărul total de subiecte';

$txt['mins_logged_in'] = 'Câte minute să rămâi autentificat?';

$txt['preview'] = 'Previzualizare';
$txt['always_logged_in'] = 'Rămâi autentificat permanent';

$txt['logged'] = 'Jurnalizat';
// Use numeric entities in the below string.
$txt['ip'] = 'IP';

$txt['www'] = 'WWW';
$txt['link'] = 'Link';

$txt['by'] = 'de'; //Deprecated

$txt['hours'] = 'ore';
$txt['minutes'] = 'minute';
$txt['seconds'] = 'secunde';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'Ora';
$txt['days_word'] = 'zile';

$txt['newest_member'] = ', cel mai nou membru.'; //Deprecated

$txt['search_for'] = 'Caută';
$txt['search_match'] = 'Compară';

$txt['maintain_mode_on'] = 'Nu uita, forumul este în modul \'Mentenanță\'.';

$txt['read'] = 'Citit de '; //Deprecated
$txt['times'] = 'ori'; //Deprecated
$txt['read_one_time'] = 'Citit 1 dată';
$txt['read_many_times'] = 'Citit de %1$d ori';

$txt['forum_stats'] = 'Statisticile forumului';
$txt['latest_member'] = 'Ultimul membru';
$txt['total_cats'] = 'Numărul total de categorii';
$txt['latest_post'] = 'Ultimul mesaj postat';

$txt['here'] = 'aici';
$txt['you_have_no_msg'] = 'Nu ai nici un mesaj...';
$txt['you_have_one_msg'] = 'Ai 1 mesaj... <a href="%1$s">Fă click aici ca să-l citești</a>';
$txt['you_have_many_msgs'] = 'Ai %2$d mesaje... <a href="%1$s">Fă click aici ca să le citești</a>';

$txt['total_boards'] = 'Numărul total de arii';

$txt['print_page'] = 'Tipăreşte pagina';
$txt['print_page_text'] = 'Doar text';
$txt['print_page_images'] = 'Text cu imagini';

$txt['valid_email'] = 'Trebuie să fie o adresă de e-mail validă.';

$txt['info_center_title'] = '%1$s - Centrul de informare';

$txt['send_topic'] = 'Distribuie';
$txt['unwatch'] = 'Nu mai urmări';
$txt['watch'] = 'Urmărește';

$txt['sendtopic_title'] = 'Trimite subiectul &quot;%1$s&quot; unui prieten.';
$txt['sendtopic_sender_name'] = 'Numele tău';
$txt['sendtopic_sender_email'] = 'Adresa ta de e-mail';
$txt['sendtopic_receiver_name'] = 'Numele destinatarului';
$txt['sendtopic_receiver_email'] = 'Adresa de e-mail a destinatarului';
$txt['sendtopic_comment'] = 'Adaugă un comentariu';

$txt['allow_user_email'] = 'Permite utilizatorilor să îmi trimită e-mail';

$txt['check_all'] = 'Selectează toată pagina';

// Use numeric entities in the below string.
$txt['database_error'] = 'Eroare bază de date';
$txt['try_again'] = 'Încearcă din nou. Dacă această eroare reapare, raportează problema unui administrator.';
$txt['file'] = 'Fişier';
$txt['line'] = 'Linie';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'ElkArte a detectat și a încercat să repare automat o eroare în baza de date. Dacă problemele continuă să apară sau dacă primești în continuare aceste email-uri, contactează host-ul.';
$txt['database_error_versions'] = '<strong>Notă:</strong> Versiunea bazei tale de date este %1$s.';
$txt['template_parse_error'] = 'Eroare de analiză a template-ului!';
$txt['template_parse_error_message'] = 'Se pare ca există o problema la sistemul de template-uri a forumului. Această problemă ar trebui să fie temporara, deci te rugăm să revii mai târziu și să încerci din nou. Dacă în continuare vei vedea acest mesaj, te rugăm să iei legătura cu administratorul forumului.<br /><br />Poți încerca să <a href="javascript:location.reload();">reîncarci pagina</a>.';
$txt['template_parse_error_details'] = 'A apărut o problemă la încărcarea template-ului sau a fișierului de limbă <span class="tt"><strong>%1$s</strong></span>. Verifcă sintaxa și încearcă din nou - reține că ghilimelele simple (<span class="tt">\'</span>) trebuiesc de multe ori marcate cu un backslash (<span class="tt">\\</span>). Dacă vrei să vezi detaliile erorii date de PHP, încearcă să <a href="%2$s%1$s">accesezi fișierul direct</a>.<br /><br />Ai putea să <a href="javascript:location.reload();">reîmprospătezi pagina</a> sau să <a href="%3$s">folosești tema implicită</a>.';
$txt['template_parse_undefined'] = 'A apărut o eroare necunoscută la analiza acestui template';

$txt['today'] = 'Astăzi la %1$s';
$txt['yesterday'] = 'Ieri la %1$s';

// Relative times
$txt['rt_now'] = 'de curând';
$txt['rt_minute'] = 'Acum un minut';
$txt['rt_minutes'] = 'Acum %s minute';
$txt['rt_hour'] = 'Acum o oră';
$txt['rt_hours'] = 'Acum %s ore';
$txt['rt_day'] = 'Acum o zi';
$txt['rt_days'] = 'Acum %s zile';
$txt['rt_week'] = 'Acum o săptămână';
$txt['rt_weeks'] = 'Acum %s săptămâni';
$txt['rt_month'] = 'Acum o lună';
$txt['rt_months'] = 'Acum %s luni';
$txt['rt_year'] = 'Acum un an';
$txt['rt_years'] = 'Acum %s ani';

$txt['new_poll'] = 'Sondaj nou';
$txt['poll_question'] = 'Întrebare';
$txt['poll_question_options'] = 'Întrebarea și opțiunile';
$txt['poll_vote'] = 'Trimite votul';
$txt['poll_total_voters'] = 'Numărul total de membri care au votat';
$txt['draft_saved_on'] = 'Ciorna a fost salvată';
$txt['poll_results'] = 'Vezi rezultatele';
$txt['poll_lock'] = 'Închide votarea';
$txt['poll_unlock'] = 'Deschide votarea';
$txt['poll_edit'] = 'Editează sondajul';
$txt['poll'] = 'Sondaj';
$txt['one_day'] = '1 Zi';
$txt['one_week'] = '1 Săptămână';
$txt['two_weeks'] = '2 Săptămâni';
$txt['one_month'] = '1 Lună';
$txt['two_months'] = '2 Luni';
$txt['forever'] = 'Permanent';
$txt['quick_login_dec'] = 'Autentifică-te cu numele de utilizator, parola și durata sesiunii';
$txt['one_hour'] = '1 Oră';
$txt['moved'] = 'MUTAT';
$txt['moved_why'] = 'Introdu o scurtă descriere a motivului <br />mutării acestui subiect.';
$txt['board'] = 'Arie';
$txt['in'] = 'în';
$txt['sticky_topic'] = 'Subiect fixat';
$txt['split'] = 'DESPĂRȚIT';

$txt['delete'] = 'Şterge';

$txt['byte'] = 'B';
$txt['kilobyte'] = 'KB';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[Mai multe statistici]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Cod';
$txt['code_select'] = '[Selectează]';
$txt['quote_from'] = 'Citat din';
$txt['quote'] = 'Citat';
$txt['quote_new'] = 'Subiect nou';
$txt['follow_ups'] = 'Abonări';
$txt['topic_derived_from'] = 'Subiect derivat din %1$s';
$txt['edit'] = 'Editează';
$txt['quick_edit'] = 'Editare rapidă';
$txt['post_options'] = 'Mai multe...';

$txt['set_sticky'] = 'Fixează';
$txt['set_nonsticky'] = 'Eliberează';
$txt['set_lock'] = 'Închide';
$txt['set_unlock'] = 'Deschide';

$txt['search_advanced'] = 'Arată opțiunile avansate';
$txt['search_simple'] = 'Ascunde opțiunile avansate';

$txt['security_risk'] = 'RISC MAJOR DE SECURITATE:';
$txt['not_removed'] = 'Nu ai eliminat %1$s';
$txt['not_removed_extra'] = '%1$s e o copie de siguranță a %2$s care nu a fost generată de ElkArte. Poate fi accesată direct și folosită pentru a obține acces neautorizat la forumul dumneavoastră. Ar trebui să o ștergi imediat.';
$txt['generic_warning'] = 'Atenție!';
$txt['agreement_missing'] = 'Le soliciți noilor utilizatori să accepte un acord de înregistrare însă fișierul respectiv (agreement.txt) nu există.';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'Tocmai ai actualizat!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Fă click aici ca să afli ce a apărut nou în această versiune de ElkArte!</a>!';

$txt['cache_writable'] = 'În directorul de cache nu se poate scrie - acest lucru ar afecta negativ performanța forumului.';

$txt['page_created_full'] = 'Pagina a fost creată în %1$.3f secunde cu %2$d interogări.';

$txt['report_to_mod_func'] = 'Utilizează această funcție pentru a informa moderatorii și administratorii cu privire la un mesaj abuziv sau postat greșit.<br /><em>Reține că adresa ta de email va fi vizibilă moderatorilor.</em>';

$txt['online'] = 'Online';
$txt['member_is_online'] = '%1$s este online';
$txt['offline'] = 'Offline';
$txt['member_is_offline'] = '%1$s este offline';
$txt['pm_online'] = 'Mesaj personal (Online)';
$txt['pm_offline'] = 'Mesaj personal (Offline)';
$txt['status'] = 'Statut';

$txt['skip_nav'] = 'Sari la conținutul principal';
$txt['go_up'] = 'Mergi sus';
$txt['go_down'] = 'Mergi jos';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Zile de naştere:';
$txt['events'] = 'Evenimente:';
$txt['birthdays_upcoming'] = 'Următoarele zile de naștere:';
$txt['events_upcoming'] = 'Următoarele evenimente:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Sărbători:';
$txt['calendar_month'] = 'Luna:';
$txt['calendar_year'] = 'Anul:';
$txt['calendar_day'] = 'Ziua:';
$txt['calendar_event_title'] = 'Titlul evenimentului';
$txt['calendar_event_options'] = 'Opțiunile evenimentului';
$txt['calendar_post_in'] = 'Publică în:';
$txt['calendar_edit'] = 'Editează evenimentul';
$txt['event_delete_confirm'] = 'Ştergi acest eveniment?';
$txt['event_delete'] = 'Şterge evenimentul';
$txt['calendar_post_event'] = 'Postează evenimentul';
$txt['calendar'] = 'Calendar';
$txt['calendar_link'] = 'Legătura cu calendarul';
$txt['calendar_upcoming'] = 'Calendarul viitor';
$txt['calendar_today'] = 'Calendarul de azi';
$txt['calendar_week'] = 'Săptămâna';
$txt['calendar_week_title'] = 'Săptămâna %1$d din %2$d';
$txt['calendar_numb_days'] = 'Numărul de zile:';
$txt['calendar_how_edit'] = 'cum editezi aceste evenimente?';
$txt['calendar_link_event'] = 'Leagă evenimentul de mesajul:';
$txt['calendar_confirm_delete'] = 'Ești sigur că vrei să ştergi acest eveniment?';
$txt['calendar_linked_events'] = 'Evenimente legate';
$txt['calendar_click_all'] = 'apasă pentru a vedea toate %1$s';

$txt['moveTopic1'] = 'Postează un subiect de redirecționare';
$txt['moveTopic2'] = 'Schimbă titlul subiectului';
$txt['moveTopic3'] = 'Subiect nou';
$txt['moveTopic4'] = 'Schimba titlul tuturor mesajelor din acest subiect';
$txt['move_topic_unapproved_js'] = 'Atentie! Acest subiect nu a fost încă aprobat.\\n\\n În cazul în care nu aprobați mesajul imediat dupa mutare, nu este recomandat să creați un subiect de redirectare.';
$txt['movetopic_auto_board'] = '[BOARD]';
$txt['movetopic_auto_topic'] = '[TOPIC LINK]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Redirectează la subiectul mutat';
$txt['movetopic_expires'] = 'Elimină automat subietul de redirectare';

$txt['merge_to_topic_id'] = 'ID-ul subiectului țintă';
$txt['split_topic'] = 'Desparte';
$txt['merge'] = 'Unește';
$txt['subject_new_topic'] = 'Tematica noului subiect';
$txt['split_this_post'] = 'Desparte doar acest mesaj.';
$txt['split_after_and_this_post'] = 'Desparte subiectul de aici în jos, incluzând acest mesaj.';
$txt['select_split_posts'] = 'Alege mesajele pentru despărțire.';

$txt['splittopic_notification'] = 'Postează un mesaj când subiectul este despărțit.';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Mută noul subiect în altă arie';

$txt['new_topic'] = 'Subiect nou';
$txt['split_successful'] = 'Subiectul a fost despărțit cu succes în doua subiecte diferite.';
$txt['origin_topic'] = 'Subiectul de origine';
$txt['please_select_split'] = 'Alege care mesaje vrei să fie despărțite.';
$txt['merge_successful'] = 'Subiectele au fost unite cu succes.';
$txt['new_merged_topic'] = 'Subiectul obținut după unire';
$txt['topic_to_merge'] = 'Subiectul ce urmează a fi unit';
$txt['target_board'] = 'Aria ţintă';
$txt['target_topic'] = 'Subiectul ţintă';
$txt['merge_confirm'] = 'Sunteţi sigur că doriţi să uniți';
$txt['with'] = 'cu';
$txt['merge_desc'] = 'Această funcție va uni mesajele din două subiecte într-un singur subiect. Mesajele vor fi sortate în funcție de data de publicare. Astfel, cel mai vechi mesaj va fi primul mesaj al subiectului nou creat prin comasarea celor doua subiecte vechi.';

$txt['theme_template_error'] = 'Nu poate fi încarcat șablonul \'%1$s\'.';
$txt['theme_language_error'] = 'Nu poate fi încarcat fișierul de limbă \'%1$s\'.';

$txt['parent_boards'] = 'Sub-arii';

$txt['smtp_no_connect'] = 'Nu a fost posibilă conectarea la host-ul SMTP';
$txt['smtp_port_ssl'] = 'Setarea pentru portul SMTP e incorectă; ar trebui să fie 465 pentru serverele SSL.';
$txt['smtp_bad_response'] = 'Nu a fost posibilă preluarea codurilor de răspuns de la serverul de mail';
$txt['smtp_error'] = 'Am întâlnit probleme în trimiterea Mailului. Eroarea:';
$txt['mail_send_unable'] = 'Nu s-a putut trimite emailul către adresa: \'%1$s\'';

$txt['mlist_search'] = 'Caută membri';
$txt['mlist_search_again'] = 'Caută din nou'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Caută după adresa de mail';
$txt['mlist_search_group'] = 'Caută după poziţie';
$txt['mlist_search_name'] = 'Caută după nume';
$txt['mlist_search_website'] = 'Caută după website';
$txt['mlist_search_results'] = 'Rezultatele căutării pentru';
$txt['mlist_search_by'] = 'Caută după %1$s';

$txt['attach_downloaded'] = 'descărcat de %1$d ori';
$txt['attach_viewed'] = 'văzut de %1$d ori';

$txt['settings'] = 'Setări';
$txt['never'] = 'Niciodată';
$txt['more'] = 'mai mult';

$txt['hostname'] = 'Hostname';
$txt['you_are_post_banned'] = 'Ne pare rău %1$s, ți s-a interzis postarea si trimiterea de mesaje personale pe acest forum.';
$txt['ban_reason'] = 'Motiv';

$txt['add_poll'] = 'Adaugă un sondaj';
$txt['poll_options6'] = 'Poți selecta până la %1$s opțiuni.';
$txt['poll_remove'] = 'Elimină sondajul';
$txt['poll_remove_warn'] = 'Ești sigur că vrei să ştergi acest sondaj din subiect?';
$txt['poll_results_expire'] = 'Rezultatele vor fi afișate când votarea va fi închisă';
$txt['poll_expires_on'] = 'Votarea se închide';
$txt['poll_expired_on'] = 'Votare închisă';
$txt['poll_change_vote'] = 'Elimină votul';
$txt['poll_return_vote'] = 'Opţiuni de vot';
$txt['poll_cannot_see'] = 'Nu poţi vedea rezultatele acestui sondaj în acest moment.';

$txt['quick_mod_approve'] = 'Aprobă cele selectate';
$txt['quick_mod_remove'] = 'Elimină-le pe cele selectate';
$txt['quick_mod_lock'] = 'Închide/Deschide cele selectate';
$txt['quick_mod_sticky'] = 'Fixează/Eliberează cele selectate';
$txt['quick_mod_move'] = 'Mută cele selectate în';
$txt['quick_mod_merge'] = 'Unește cele selectate';
$txt['quick_mod_markread'] = 'Marcheaza cele selectate ca citite';
$txt['quick_mod_go'] = 'Mergi';
$txt['quickmod_confirm'] = 'Ești sigur că vrei să faci asta?';

$txt['spell_check'] = 'Verifică ortografia';

$txt['quick_reply'] = 'Răspuns rapid';
$txt['quick_reply_warning'] = 'Atenție! Acest subiect este închis, doar moderatorii și administratorii pot posta mesaje.';
$txt['quick_reply_verification'] = 'După ce trimiți mesajul vei fi direcționat către pagina normală de postare pentru a verifica mesajul %1$s.';
$txt['quick_reply_verification_guests'] = '(obligatoriu pentru toţi vizitatorii)';
$txt['quick_reply_verification_posts'] = '(obligatoriu pentru toţi userii cu mai puţin de %1$d postări)';
$txt['wait_for_approval'] = 'Notă: acest mesaj postat nu va fi afişat până când nu va fi aprobat de un moderator.';

$txt['notification_enable_board'] = 'Ești sigur că vrei să activezi notificarea pentru subiecte noi în această arie?';
$txt['notification_disable_board'] = 'Ești sigur că vrei să dezactivezi notificarea pentru subiecte noi în această arie?';
$txt['notification_enable_topic'] = 'Ești sigur că vrei să activezi notificarea pentru răspunsuri noi la acest subiect? ';
$txt['notification_disable_topic'] = 'Ești sigur că vrei să dezactivezi notificarea pentru răspunsuri noi la acest subiect? ';

$txt['report_to_mod'] = 'Raportează mesajul';
$txt['issue_warning_post'] = 'Emite un avertisment din cauza acestui mesaj';

$txt['like_post'] = 'Îmi place';
$txt['unlike_post'] = 'Nu-mi mai place';
$txt['likes'] = '"Likes"';
$txt['liked_by'] = 'Apreciat de:';
$txt['liked_you'] = 'Tine';
$txt['liked_more'] = 'mai mult';
$txt['likemsg_are_you_sure'] = 'Îți plăcuse acest mesaj! Ești sigur că vrei să-ți schimbi părerea?';

$txt['unread_topics_visit'] = 'Subiecte necitite recente ';
$txt['unread_topics_visit_none'] = 'Nu au fost găsite subiecte necitite de la ultima ta vizită.  <a href="{unread_all_url}" class="linkbutton">Apasă aici ca să vezi toate subiectele necitite</a>';
$txt['unread_topics_all'] = 'Toate subiectele necitite';
$txt['unread_replies'] = 'Subiectele actualizate';

$txt['who_title'] = 'Cine este online';
$txt['who_and'] = ' şi ';
$txt['who_viewing_topic'] = ' citesc acest subiect.';
$txt['who_viewing_board'] = ' citesc această arie.';
$txt['who_member'] = 'Membru';

// Current footer strings
$txt['valid_html'] = 'HTML5 valid';
$txt['rss'] = 'RSS ';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'Vizitator';
$txt['guests'] = 'Vizitatori';
$txt['user'] = 'Utilizator';
$txt['users'] = 'Utilizatori';
$txt['hidden'] = 'Ascunşi';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'Ascunşi';
$txt['buddy'] = 'Amic';
$txt['buddies'] = 'Amici';
$txt['most_online_ever'] = 'Cei mai mulţi utilizatori online vreodată';
$txt['most_online_today'] = 'Cei mai mulţi utilizatori online astăzi';

$txt['merge_select_target_board'] = 'Alegeți aria țintă pentru subiectul rezultat din unire';
$txt['merge_select_poll'] = 'Alege sondajul care va fi afișat în subiectul rezultat din unire';
$txt['merge_topic_list'] = 'Alege subiectele ce urmează a fi unite';
$txt['merge_select_subject'] = 'Alege titlul subiectului rezultat din unire';
$txt['merge_custom_subject'] = 'Titlu personalizat';
$txt['merge_enforce_subject'] = 'Schimbă titlul tuturor mesajelor';
$txt['merge_include_notifications'] = 'Includ notificările?';
$txt['merge_check'] = 'Unesc?';
$txt['merge_no_poll'] = 'Niciun sondaj';

$txt['response_prefix'] = 'Re: ';
$txt['current_icon'] = 'Iconița curentă';
$txt['message_icon'] = 'Pictograma mesajului';

$txt['smileys_current'] = 'Setul actual de emoticoane';
$txt['smileys_none'] = 'Fără emoticoane';
$txt['smileys_forum_board_default'] = 'Opțiuni implicite pentru Forum/Arii';

$txt['search_results'] = 'Rezultatele căutării';
$txt['search_no_results'] = 'Ne pare rău, nu au fost găsite rezultate compatibile';

$txt['totalTimeLogged2'] = ' zile,';
$txt['totalTimeLogged3'] = ' ore şi ';
$txt['totalTimeLogged4'] = ' minute.';
$txt['totalTimeLogged5'] = ' d ';
$txt['totalTimeLogged6'] = ' h';
$txt['totalTimeLogged7'] = ' m';

$txt['approve_thereis'] = 'Este'; //Deprecated
$txt['approve_thereare'] = 'Sunt'; //Deprecated
$txt['approve_member'] = 'un membru'; //Deprecated
$txt['approve_members'] = 'membri'; //Deprecated
$txt['approve_members_waiting'] = ' în aşteptarea aprobării.'; //Deprecated
$txt['approve_one_member_waiting'] = '<a href="%1$s">Un membru</a> așteaptă aprobarea.';
$txt['approve_many_members_waiting'] = '<a href="%1$s">%2$d membri</a> așteaptă aprobarea.';

$txt['notifyboard_turnon'] = 'Vrei să primiești un email de notificare când cineva deschide un subiect nou în această arie?';
$txt['notifyboard_turnoff'] = 'Ești sigur că nu vrei să primiești un email de notificare când cineva deschide un subiect nou în această arie?';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Caută membri';
$txt['find_username'] = 'Numele, numele de utilizator sau adresa de e-mail';
$txt['find_buddies'] = 'Să afișez doar prietenii?';
$txt['find_wildcards'] = 'Permite metacaractere: *, ?';
$txt['find_no_results'] = 'Nu s-a găsit niciun rezultat';
$txt['find_results'] = 'Rezultate';
$txt['find_close'] = 'Închide';

$txt['quickmod_delete_selected'] = 'Elimină-le pe cele selectate';
$txt['quickmod_split_selected'] = 'Desparte cele selectate';

$txt['show_personal_messages_heading'] = 'Mesaje noi';
$txt['show_personal_messages'] = 'Ai <strong>%1$s</strong> mesaje personale necitite în inbox.<br /><br /><a href="%2$s">Mergi la inbox</a>';

$txt['help_popup'] = 'Ai nelămuriri? Să-ți explic:';

$txt['previous_next_back'] = 'subiectul precedent';
$txt['previous_next_forward'] = 'subiectul următor';

$txt['upshrink_description'] = 'Restrânge sau extinde antetul.';

$txt['mark_unread'] = 'Marchează ca necitit';

$txt['ssi_not_direct'] = 'Nu accesa SSI.php direct prin URL; poți să folosești calea (%1$s) sau să adaugi ?ssi_function=ce_vrei_tu.';
$txt['ssi_session_broken'] = 'SSI.php nu a putut încărca o sesiune! Acest lucru poate cauza probleme cu de-logarea și alte funcții - asigură-te că SSI.php este inclus înainte de ORICE altceva în toate scripturile tale!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Previzualizează mesajul';
$txt['preview_fetch'] = 'Se încarcă previzualizarea...';
$txt['pm_error_while_submitting'] = 'Următoarele erori au apărut la trimiterea acestui mesaj personal:';
$txt['warning_while_submitting'] = 'S-a întâmplat ceva, vezi aici:';
$txt['error_while_submitting'] = 'Mesajul conține următoarele erori care trebuies corectate pentru a putea continua:';
$txt['error_old_topic'] = 'ATENȚIE: în acest subiect nu s-a mai postat de cel puțin %1$d zile.<br />Dacă nu ești sigur că e bine să răspunzi aici, ia în calcul deschiderea unui subiect nou.';

$txt['split_selected_posts'] = 'Mesajele selectate';
$txt['split_selected_posts_desc'] = 'Mesajele de mai jos vor forma un nou subiect după despărțire.';
$txt['split_reset_selection'] = 'resetează selecţia';

$txt['modify_cancel'] = 'Anulează';
$txt['mark_read_short'] = 'Marchează ca citit(e)';

$txt['hello_member_ndt'] = 'Salut';

$txt['unapproved_posts'] = 'Postări neaprobate (Subiecte: %1$d, Mesaje: %2$d)';

$txt['ajax_in_progress'] = 'Se încarcă...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = 'În prezent sunt deschise %1$d rapoarte de moderare.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'Apasă ca să vezi postările noi din %1$s';
$txt['verification'] = 'Verificare';
$txt['visual_verification_hidden'] = 'Lasă această casetă necompletată';
$txt['visual_verification_description'] = 'Tastează literele arătate în imagine';
$txt['visual_verification_sound'] = 'Ascultă literele';
$txt['visual_verification_request_new'] = 'Solicită altă imagine';

// @todo Send email strings - should move?
$txt['send_email'] = 'Trimite email';
$txt['send_email_disclosed'] = 'Reține că va putea fi văzut de destinatar.';
$txt['send_email_subject'] = 'Subiectul email-ului';

$txt['ignoring_user'] = 'În prezent ignori acest utilizator.';
$txt['show_ignore_user_post'] = '<em>[Arată-mi postarea.]</em>';

$txt['spider'] = 'Motor de căutare';
$txt['spiders'] = 'Roboţi';
$txt['openid'] = 'OpenID';

$txt['downloads'] = 'Descărcări';
$txt['filesize'] = 'Mărimea fișierului';
$txt['subscribe_webslice'] = 'Abonează-te la Webslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Restaurează subiectul';
$txt['restore_message'] = 'Restaurează';
$txt['quick_mod_restore'] = 'Restaurează cele selectate';

// Editor prompt.
$txt['prompt_text_email'] = 'Introdu adresa de email';
$txt['prompt_text_ftp'] = 'Introdu adresa FTP';
$txt['prompt_text_url'] = 'Introdu URL-ul către care vrei să creezi legătura.';
$txt['prompt_text_img'] = 'Introdu locaţia imaginii';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Şterge articolul';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> a blocat  %1$s încercări de acces în ultimele 7 zile.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Template-uri:';
$txt['debug_subtemplates'] = 'Sub-șabloane:'; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Sub-șabloane:';
$txt['debug_language_files'] = 'Fișiere de limbă:';
$txt['debug_sheets'] = 'Foi de stil (style sheets):';
$txt['debug_javascript'] = 'Scripturi:';
$txt['debug_files_included'] = 'Fișiere incluse:';
$txt['debug_kb'] = 'KB.';
$txt['debug_show'] = 'arată';
$txt['debug_cache_hits'] = 'Accesări din cache:';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s octeți';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss pentru %2$s octeți';
$txt['debug_queries_used'] = 'Interogări folosite: %1$d.';
$txt['debug_queries_used_and_warnings'] = 'Interogări folosite: %1$d, %2$d atenționări.';
$txt['debug_query_in_line'] = 'în <em>%1$s</em> linia <em>%2$s</em>,';
$txt['debug_query_which_took'] = 'în %1$s secunde.';
$txt['debug_query_which_took_at'] = 'în %1$s secunde la %2$s în cerere.';
$txt['debug_show_queries'] = '[Arată Interogările]';
$txt['debug_hide_queries'] = '[Ascunde Interogările]';
$txt['debug_tokens'] = 'Tokenuri:';
$txt['debug_browser'] = 'ID-ul browserului';
$txt['debug_hooks'] = 'Interceptări apelate:';
$txt['debug_system_type'] = 'Sistem:';
$txt['debug_server_load'] = 'Încărcarea serverului:';
$txt['debug_script_mem_load'] = 'Utilizarea memoriei de scripturi:';
$txt['debug_script_cpu_load'] = 'Timpul CPU pentru scripturi (utilizator/sistem):';

// Video embedding
$txt['preview_image'] = 'Imaginea de preview pentru video';
$txt['ctp_video'] = 'Click pentru playback, dublu-click pentru încărcare';
$txt['hide_video'] = 'Arată/Ascunde video';
$txt['youtube'] = 'Video YouTube:';
$txt['vimeo'] = 'Video Vimeo:';
$txt['dailymotion'] = 'Video Dailymotion:';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (apasă ca să vezi/ascunzi)';

$txt['ok_uppercase'] = 'OK';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Atenție!';

$txt['via'] = 'via';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
