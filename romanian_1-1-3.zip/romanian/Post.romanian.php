<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Răspuns';
$txt['post_in_board'] = 'Publică în arie';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Inserează un citat';
$txt['disable_smileys'] = 'Dezactvează emoticoanele';
$txt['dont_use_smileys'] = 'Nu utiliza emoticoanele.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Postat în';
$txt['standard'] = 'Standard';
$txt['thumbs_up'] = 'Degetul mare în sus';
$txt['thumbs_down'] = 'Degetul mare în jos';
$txt['exclamation_point'] = 'Semn de exclamare';
$txt['question_mark'] = 'Semn de întrebare';
$txt['icon_poll'] = 'Sondaj';
$txt['lamp'] = 'Lampă';
$txt['add_smileys'] = 'Adaugă emoticoane';
$txt['topic_notify_no'] = 'Nu sunt subiecte cu notificări.';

$txt['rich_edit_wont_work'] = 'Browser-ul dumneavoastră nu suportă editarea în format Rich Text.';
$txt['rich_edit_function_disabled'] = 'Browserul tău nu acceptă această funcţie.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Dezabonaţi-vă de la acest subiect făcând clic aici';

$txt['lock_after_post'] = 'Blochează după postare';
$txt['notify_replies'] = 'Anunţă-mă când apar răspunsuri.';
$txt['lock_topic'] = 'Blocaţi acest subiect de discuţie.';
$txt['shortcuts'] = 'Comenzi rapide: Shift+Alt+s introdu/postează sau Shift+Alt+p previzualizează';
$txt['shortcuts_drafts'] = 'Comenzi rapide: Shift+Alt+s introdu/postează, Shift+Alt+p previzualizează sau Shift+Alt+d salvează ca ciornă';
$txt['option'] = 'Opţiune';
$txt['reset_votes'] = 'Resetează contorul voturilor';
$txt['reset_votes_check'] = 'Verificaţi acest lucru, dacă doriţi să resetaţi numărătoarea tuturor voturilor la 0.';
$txt['votes'] = 'voturi';
$txt['attach'] = 'Ataşează';
$txt['clean_attach'] = 'Elimină atașamentul';
$txt['attached'] = 'Ataşat'; // @deprecated since 1.1
$txt['allowed_types'] = 'Tipuri de fişiere permise';
$txt['cant_upload_type'] = 'Nu poți încărca fișiere de acest tip. Singurele extensii permise sunt %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Debifaţi ataşamentele pe care nu le mai doriţi ataşate'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Acesta este un nume de fişier restricţionat. Vă rugăm să încercaţi un alt nume de fişier';
$txt['topic_locked_no_reply'] = 'Atenție! Acest subiect este / va fi închis.<br />Doar administratorii și moderatorii pot posta.';
$txt['attachment_requires_approval'] = 'Reţineţi că orice fişier ataşat nu va fi afişat până nu va fi aprobat de un moderator.';
$txt['error_temp_attachments'] = 'Au fost găsite atașamente care au fost atașate dar nu au fost publicate. Aceste atașamente sunt atașate acum acestui mesaj. Dacă nu vrei să le incluzi acum, <a href="#postAttachment">le poți elimina aici</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Atenţie: Acest post nu va apărea fără a fi aprobat de un moderator.';

$txt['enter_comment'] = 'Introduceţi un comentariu';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Post raportat';
$txt['reported_to_mod_by'] = 'de';
$txt['rtm10'] = 'Trimite';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Urm&#259;torul mesaj postat, "%1$s" de c&#259;tre';
$txt['reported_by'] = 'a fost raportat de către';
$txt['board_moderate'] = 'într-o secţiune pe care o moderaţi';
$txt['report_comment'] = 'Cel ce a raportat a făcut următorul comentariu';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximum total size %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximum individual size %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d per mesaj postat ';
$txt['attach_restrictions'] = 'Restricţii:';

$txt['post_additionalopt_attach'] = 'Ataşamente şi alte opţiuni';
$txt['post_additionalopt'] = 'Other options';
$txt['sticky_after'] = 'Pin this topic.';
$txt['move_after2'] = 'Mută acest subiect.';
$txt['back_to_topic'] = 'Revenire la acest subiect.';
$txt['approve_this_post'] = 'Approve this post';

$txt['retrieving_quote'] = 'Retrieving quote...';

$txt['post_visual_verification_label'] = 'Verificare';
$txt['post_visual_verification_desc'] = 'Vă rugăm să introduceţi codul din imaginea de mai sus pentru a posta acest mesaj.';

$txt['poll_options'] = 'Opţiuni Sondaj';
$txt['poll_run'] = 'Rulează sondajul pentru ';
$txt['poll_run_limit'] = '(Lăsaţi necompletat pentru nicio limită.)';
$txt['poll_results_visibility'] = 'Vizibilitate rezultat';
$txt['poll_results_anyone'] = 'Arată oricui rezultatele sondajului.';
$txt['poll_results_voted'] = 'Afişează rezultatele numai după ce cineva a votat';
$txt['poll_results_after'] = 'Arată rezultatele numai după expirarea sondajului.';
$txt['poll_max_votes'] = 'Numărul maxim de voturi per utilizator';
$txt['poll_do_change_vote'] = 'Permiteți utilizatorilor să își schimbe votul';
$txt['poll_too_many_votes'] = 'Aţi selectat prea multe opţiuni. Pentru acest sondaj, puteţi selecta numai %1$s opţiuni.';
$txt['poll_add_option'] = 'Adaugă Opţiunea';
$txt['poll_guest_vote'] = 'Permiteți vizitatorilor să voteze';

$txt['spellcheck_done'] = 'Verificarea ortografiei e terminată.';
$txt['spellcheck_change_to'] = 'Înlocuiţi Cu :';
$txt['spellcheck_suggest'] = 'Sugestii';
$txt['spellcheck_change'] = 'Modifică';
$txt['spellcheck_change_all'] = 'Schimbaţi Tot';
$txt['spellcheck_ignore'] = 'Ignoraţi';
$txt['spellcheck_ignore_all'] = 'Ignoraţi Tot';

$txt['more_attachments'] = 'mai multe ataşamente';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Ne pare rău, nu aveţi permisiunea de a mai posta alte ataşmente.';

$txt['more_smileys'] = 'mai mult';
$txt['more_smileys_title'] = 'Emoticoane suplimentare';
$txt['more_smileys_pick'] = 'Alege un emoticon';
$txt['more_smileys_close_window'] = 'Închideţi Fereastra';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = 'Trimite un anunţ despre acest subiect către membrii :';
$txt['announce_title'] = 'Trimite un anunţ';
$txt['announce_desc'] = 'Acest formular vă permite să trimiteţi un anunţ despre acest subiect grupurilor de membri selectate.';
$txt['announce_sending'] = 'Trimitere anunţ subiect';
$txt['announce_done'] = 'terminat';
$txt['announce_continue'] = 'Continuă';
$txt['announce_topic'] = 'Anunţare subiect.';
$txt['announce_regular_members'] = 'Membri obişnuiţi';

$txt['digest_subject_daily'] = 'Rezumat Zilnic';
$txt['digest_subject_weekly'] = 'Rezumat Săptămânal ';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'The following topics were started';
$txt['digest_new_topics_line'] = '"%1$s" in the %2$s board';
$txt['digest_new_replies'] = 'S-a răspuns în următoarele subiecte de discuţie';
$txt['digest_new_replies_one'] = '1 răspuns în "%1$s" ';
$txt['digest_new_replies_many'] = '%1$d răspunsuri în "%2$s" ';
$txt['digest_mod_actions'] = 'Au avut loc următoarele acţiuni de moderare ';
$txt['digest_mod_act_sticky'] = '"%1$s" was pinned';
$txt['digest_mod_act_lock'] = '"%1$s" a fost blocat';
$txt['digest_mod_act_unlock'] = '"%1$s" a fost deblocat';
$txt['digest_mod_act_remove'] = '"%1$s"a fost eliminat';
$txt['digest_mod_act_move'] = '"%1$s" a fost mutat';
$txt['digest_mod_act_merge'] = '"%1$s" a fuzionat';
$txt['digest_mod_act_split'] = '"%1$s" a fost împărţit';

$txt['attach_error_title'] = 'Error uploading attachments.';
$txt['attach_warning'] = 'There was a problem during the uploading of <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Sorry, you are out of attachment space. The total attachment size allowed per post is %1$s KB. Space remaining is %2$s KB.';
$txt['attach_folder_warning'] = 'The attachments directory can not be located. Please notify an administrator of this problem.';
$txt['attach_folder_admin_warning'] = 'The path to the attachments directory (%1$s) is incorrect. Please correct it in the attachment settings area of your admin panel.';
$txt['attach_limit_nag'] = 'You have reached the maximum number of attachments allowed per post.';
$txt['attach_no_upload'] = 'There was a problem and your attachments could not be uploaded';
$txt['attach_remaining'] = '%1$d remaining';
$txt['attach_available'] = '%1$s KB available';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'The file appears to be empty. Please contact your forum administrator if this continues to be a problem';
$txt['attached_files_in_session'] = '<em>The above underlined file(s) have been uploaded but will not be attached to this post until it is submitted.</em>';

$txt['attach_php_error'] = 'Due to an error, your attachment could not be uploaded. Please contact the forum administrator if this problem continues.';
$txt['php_upload_error_1'] = 'The uploaded file exceeds the upload_max_filesize directive in php.ini. Please contact your host if you are unable to correct this issue.';
$txt['php_upload_error_3'] = 'The uploaded file was only partially uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_4'] = 'No file was uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_6'] = 'Unable to save. Missing a temporary directory. Please contact your host if you are unable to correct this problem.';
$txt['php_upload_error_7'] = 'Failed to write file to disk. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_8'] = 'A PHP extension stopped the file upload. This is a PHP related error. Please contact your host if this problem continues.';
$txt['error_temp_attachments_new'] = 'There are attachments which you had previously attached but not posted. These attachments are still attached to this post. This post does need to be submitted before these attachments are either saved or removed. You <a href="#postAttachment">can do that here</a>';
$txt['error_temp_attachments_found'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not post until these are either removed or that post has been submitted.<br />Click <a href="%1$s">here to remove </a>those attachments. Or <a href="%2$s">here to return to that post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not upload any more attachments until these are removed or that post has been submitted.<br />Click <a href="%1$s">here to remove these attachments</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Those attachments have now been removed and you have been returned to the page you were previously on';
$txt['error_temp_attachments_flushed'] = 'Please note that any files which had been previously attached, but not posted, have now been removed.';
$txt['error_topic_already_announced'] = 'Please note that this topic has already been announced.';

$txt['cant_access_upload_path'] = 'Imposibil de accesat calea de încărcare a ataşamentului!';
$txt['file_too_big'] = 'Your file is too large. The maximum attachment size allowed is %1$s KB.';
$txt['attach_timeout'] = 'Ataşamentul nu a putut fi salvat. Aceasta se poate întâmpla când încărcarea durează foarte mult sau fişierul este mai mare decât dimensiunea maximă admisă.<br /><br />Consultaţi administratorul serverului pentru mai multe informaţii.';
$txt['bad_attachment'] = 'Ataşamentul dumneavoastră a picat controalele de securitate şi nu poate fi încărcat. Vă rugăm să vă consultaţi cu administratorul forumului.
';
$txt['ran_out_of_space'] = 'The upload directory is full. Please contact an administrator about this problem.';
$txt['attachments_no_write'] = 'Directorul pentru încărcarea ataşamentelor este plin sau nu aveţi drepturi de scriere.  Ataşamentul sau avatarul nu poate fi salvat.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory.  Your attachment or avatar cannot be saved.';
$txt['attachments_limit_per_post'] = 'Nu puteţi încărca mai mult de %1$d ataşamente per mesaj postat';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Inserează';
$txt['ila_opt_size'] = 'Mărime';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Nimic';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Centrează';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/