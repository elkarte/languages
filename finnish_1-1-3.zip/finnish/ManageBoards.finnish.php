<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Hallinnoi alueita ja kategorioita';
$txt['order'] = 'Tilaa';
$txt['full_name'] = 'Koko nimi';
$txt['name_on_display'] = 'Tämä on nimi joka näytetään.';
$txt['boards_and_cats_desc'] = 'Edit your categories and boards here. List multiple moderators as <em>&quot;username&quot;, &quot;username&quot;</em>. (these must be usernames and *not* display names)<br />To create a new board, click the Add Board button.<br />To move a board you can drag and drop it to its new location in the list (across cataegories and Child of locations)<br />To create a new board as a child of a current board, select "Child of..." from the Order drop down menu when creating the board.';
$txt['parent_members_only'] = 'Tavalliset jäsenet';
$txt['parent_guests_only'] = 'Vieraat';
$txt['catConfirm'] = 'Haluatko varmasti poistaa tämän alueen?';
$txt['boardConfirm'] = 'Haluatko varmasti poistaa tämän kategorian?';

$txt['catEdit'] = 'Muokkaa aluetta';
$txt['collapse_enable'] = 'Supistettavissa';
$txt['collapse_desc'] = 'Anna käyttäjien supistaa tämä alue';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'perään ';
$txt['mboards_order_first'] = 'Ensimmäiseksi';
$txt['mboards_board_error'] = 'Failed to resolve move location.';

$txt['mboards_new_board'] = 'Lisää kategoria';
$txt['mboards_new_cat_name'] = 'Uusi alue';
$txt['mboards_add_cat_button'] = 'Lisää alue';
$txt['mboards_new_board_name'] = 'Uusi kategoria';

$txt['mboards_modify'] = 'muokkaa';
$txt['mboards_permissions'] = 'oikeudet';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Haluatko varmasti käyttää tällä alueella paikallisia oikeuksia?';

$txt['mboards_delete_cat'] = 'Poista alue';
$txt['mboards_delete_board'] = 'Poista kategoria';

$txt['mboards_delete_cat_contains'] = 'Jos poistat tämä alueen, se poistaa myös seuraavat kategoriat viesteineen';
$txt['mboards_delete_option1'] = 'Poista alue kategorioineen.';
$txt['mboards_delete_option2'] = 'Poista alue ja siirrä kategoriat alueelle';
$txt['mboards_delete_board_contains'] = 'Deleting this board will also move the sub-boards below, including all topics, posts and attachments within each board';
$txt['mboards_delete_board_option1'] = 'Delete board and move sub-boards contained within to category level.';
$txt['mboards_delete_board_option2'] = 'Delete board and move all sub-boards contained within to';
$txt['mboards_delete_what_do'] = 'Ole hyvä ja valitse mitä haluat tehdä näille alueille';
$txt['mboards_delete_confirm'] = 'Vahvista';
$txt['mboards_delete_cancel'] = 'Peruuta';

$txt['mboards_category'] = 'Alue';
$txt['mboards_description'] = 'Kuvaus';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Sallitut jäsenryhmät';
$txt['mboards_groups_desc'] = 'Jäsenryhmät jotka pääsevät tälle alueelle.';
$txt['mboards_groups_regular_members'] = 'Tähän ryhmään kuuluu kaikki käyttäjät, joille ei ole asetettu ensisijaista käyttäjäryhmää.';
$txt['mboards_groups_post_group'] = 'Tämä ryhmä on viestimääriin perustuva ryhmä.';
$txt['mboards_moderators'] = 'Valvojat';
$txt['mboards_moderators_desc'] = 'Jäsenet joilla on erityisoikeuksia alueella. Ylläpitäjiä ei tarvitse listata tähän';
$txt['mboards_count_posts'] = 'Laskee viestit';
$txt['mboards_count_posts_desc'] = 'Kasvattaa jäsenten viestien yhteismäärää viestittäessä tälle alueelle.';
$txt['mboards_unchanged'] = 'Muuttumaton';
$txt['mboards_theme'] = 'Alueen teema';
$txt['mboards_theme_desc'] = 'Täältä voit muuttaa alueen ulkoasua keskustelualueesi sisällä.';
$txt['mboards_theme_default'] = '(Käytä keskustelualueen oletusta.)';
$txt['mboards_override_theme'] = 'Teema ohittaa käyttäjän valinnan.';
$txt['mboards_override_theme_desc'] = 'Ohittaako alueen teema käyttäjän valinnan? Toimii vain jos alueella on oma teema valittuna.';

$txt['mboards_redirect'] = 'Ohjaa verkko-osoitteeseen';
$txt['mboards_redirect_desc'] = 'Ottamalla tämän käyttöön kaikki jotka menevät tälle alueelle ohjataan verkko-osoitteeseen.';
$txt['mboards_redirect_url'] = 'Osoite johon ohjataan';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Nollaa ohjaukset';
$txt['mboards_redirect_reset_desc'] = 'Valitsemalla tämän ohjausten määrä nollataan.';
$txt['mboards_current_redirects'] = 'Tällä hetkellä: %1$s';
$txt['mboards_redirect_disabled'] = 'Huomaa: Alueen tulee olla tyhjä että voit ottaa tämän käyttöön';
$txt['mboards_redirect_disabled_recycle'] = 'Huomaa: Et voi asetttaa roskakori aluetta uudelleenohjaus alueeksi';

$txt['mboards_order_before'] = 'Ennen';
$txt['mboards_order_child_of'] = 'Alakategoriaksi';
$txt['mboards_order_in_category'] = 'Alueella';
$txt['mboards_current_position'] = 'Nykyinen sijainti';
$txt['no_valid_parent'] = 'Alueella %1$s ei ole asianmukaista yläkategoriaa. Käytä \'Etsi ja korjaa virheet\' toimintoa korjataksesi tämän.';

$txt['mboards_recycle_disabled_delete'] = 'You must select an alternative recycle bin board or disable recycling before you can delete this board.';

$txt['mboards_settings_desc'] = 'Muokkaa alueiden ja kategorioiden asetuksia.';
$txt['groups_manage_boards'] = 'Jäsenryhmät jotka voivat muokata alueita ja kategorioita';
$txt['recycle_enable'] = 'Kierrätä poistetut viestit';
$txt['recycle_board'] = 'Alue johon poistetut viestit siirretään';
$txt['recycle_board_unselected_notice'] = 'Sinulla on käytössä roskakori ilman että olet valinnut roskakorialuetta, tätä ominaisuutta ei käytetä ennen kuin olet valinnut sen.';
$txt['countChildPosts'] = 'Laske alakategorian viestimäärät mukaan yläkategorian viestimääriä näytettäessä.';
$txt['allow_ignore_boards'] = 'Salli alueiden huomiotta jättäminen';
$txt['deny_boards_access'] = 'Enable the option to deny board access based on membergroup';
$txt['boardsaccess_option_desc'] = 'For each permission you can choose \'Allow\' (A), \'Ignore\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />If you deny access, any member - (including moderators) - in that group will be denied access.<br />For this reason, you should set deny carefully, only when <strong>necessary</strong>. Ignore, on the other hand, denies unless otherwise granted.';

$txt['mboards_select_destination'] = 'Valitse kohde alueelle \'<strong>%1$s</strong>\' ';
$txt['mboards_cancel_moving'] = 'Peruuta siirto';
$txt['mboards_move'] = 'siirrä';

$txt['mboards_no_cats'] = 'Yhtään aluetta tai kategoriaa ei ole luotu.';
