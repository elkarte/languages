<?php
// Version: 1.1; ManagePaid

// Symbols.
$txt['usd_symbol'] = '$%1.2f';
$txt['eur_symbol'] = '%1.2f &euro;';
$txt['gbp_symbol'] = '&pound;%1.2f';

$txt['usd'] = 'USD ($)';
$txt['eur'] = 'EURO (&euro;)';
$txt['gbp'] = 'GBP (&pound;)';
$txt['other'] = 'Muu';

$txt['paid_username'] = 'Käyttäjänimi';

$txt['paid_subscriptions_desc'] = 'Täältä voit lisätä, poistaa ja muokata maksullisia jäsenyyksiä.';
$txt['paid_subs_settings'] = 'Asetukset';
$txt['paid_subs_settings_desc'] = 'Täällä voit muokata saatavilla olevia maksutapoja.';
$txt['paid_subs_view'] = 'Katso jäsenyyksiä';
$txt['paid_subs_view_desc'] = 'Täältä näet jäsenyydet joita tarjoat tällä hetkellä.';

// Setting type strings.
$txt['paid_enabled'] = 'Maksulliset jäsenyydet käytössä';
$txt['paid_enabled_desc'] = 'This must be checked for the paid subscriptions to be used on the forum.';
$txt['paid_email'] = 'Lähetä muistutukset';
$txt['paid_email_desc'] = 'Lähetä muistutukset tapahtumista ylläpitäjille.';
$txt['paid_email_to'] = 'Vastaanottajat';
$txt['paid_email_to_desc'] = 'Pilkulla eroteltu lista kelle muille kuin ylläpitäjille muistutukset lähetetään.';
$txt['paidsubs_test'] = 'Ota testitila käyttöön';
$txt['paidsubs_test_desc'] = 'Tämä asettaa maksullisetjäsenyydet &quot;testi&quot; -tilaan jossa, mikäli mahdollista, käytetään  &quot;hiekkalaatikko&quot; maksutiloja. Älä käytä jos et tiedä mitä olet tekemässä!';
$txt['paidsubs_test_confirm'] = 'Oletko varma että tahdot aktivoida testi-moodin?';
$txt['paid_email_no'] = 'Älä lähetä muistutuksia';
$txt['paid_email_error'] = 'Muistuta jos tilaus epäonnistuu';
$txt['paid_email_all'] = 'Muistuta kaikissa muutoksissa';
$txt['paid_currency'] = 'Valitse rahayksikkö';
$txt['paid_currency_code'] = 'Rahayksikön koodi';
$txt['paid_currency_code_desc'] = 'Maksunvälittäjien käyttämä koodi';
$txt['paid_currency_symbol'] = 'Rahayksikön symboli';
$txt['paid_currency_symbol_desc'] = 'Käytä \'%1.2f\' merkkaaksesi numeron paikkaa. Esimerkiksi $%1.2f tai %1.2fDM jne.';

$txt['paypal_email'] = 'Paypalin sähköpostiosoite';
$txt['paypal_email_desc'] = 'Jätä tyhjäksi mikäli et käytää PayPalia';

$txt['authorize_id'] = 'Authorize.net asennustunniste';
$txt['authorize_id_desc'] = 'Authorize.netin antama asennustunniste (Install ID). Jätä tyhjäksi mikäli et käytä Authorize.nettiä';
$txt['authorize_transid'] = 'Authorize.Net Transaction ID';

$txt['2co_id'] = '2checkout.com Install ID';
$txt['2co_id_desc'] = '2co.comin antama asennustunniste (Install ID). Jätä tyhjäksi mikäli et käytä 2co.comia';
$txt['2co_password'] = '2checkout.com Secret Word';
$txt['2co_password_desc'] = 'Sinun 2checkout secret word.';
$txt['2co_password_wrong'] = 'Your 2checkout secret word was not accepted.';

$txt['paid_settings_save'] = 'Tallenna';

$txt['paid_note'] = '<strong class="alert">Note:</strong><br />For subscriptions to be automatically updated for your users, you
	will need to setup a return URL for each of your payment methods. For all payment types, this return URL should be set as:<br /><br />
	&nbsp;&nbsp;&bull;&nbsp;&nbsp;<strong>{board_url}/subscriptions.php</strong><br /><br />
	You can edit the link for PayPal directly <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ipn-notify" target="_blank">by clicking here</a>.<br />
	For the other gateways (if installed) you can normally find it in your customer panels, usually under the term &quot;Return URL&quot; or &quot;Callback URL&quot;.';

// View subscription strings.
$txt['paid_name'] = 'Nimi';
$txt['paid_status'] = 'Tila';
$txt['paid_cost'] = 'Hinta';
$txt['paid_duration'] = 'Kesto';
$txt['paid_active'] = 'Aktiivinen';
$txt['paid_pending'] = 'Odottaa maksua';
$txt['paid_finished'] = 'Päättynyt';
$txt['paid_total'] = 'Yhteensä';
$txt['paid_is_active'] = 'Aktivoitu';
$txt['paid_none_yet'] = 'Et ole vielä luonut yhtäkään jäsenyyttä.';
$txt['paid_none_ordered'] = 'You don\'t any subscriptions.';
$txt['paid_payments_pending'] = 'Maksuja odottamassa';
$txt['paid_order'] = 'Tilaa';

$txt['yes'] = 'Kyllä';
$txt['no'] = 'Ei';

// Add/Edit/Delete subscription.
$txt['paid_add_subscription'] = 'Luo jäsenyys';
$txt['paid_edit_subscription'] = 'Muokkaa jäsenyyttä';
$txt['paid_delete_subscription'] = 'Poista jäsenyys';

$txt['paid_mod_name'] = 'Jäsenyyden nimi';
$txt['paid_mod_desc'] = 'Kuvaus';
$txt['paid_mod_reminder'] = 'Lähetä muistutus';
$txt['paid_mod_reminder_desc'] = 'Päivää ennen tilauksen päättymistä. (0 poistaa käytöstä)';
$txt['paid_mod_email'] = 'Sähköposti joka lähetetään tilauksen jälkeen';
$txt['paid_mod_email_desc'] = 'Jossa {NAME} on jäsenen nimi; {FORUM} on keskustelualueen nimi. Aihe tulee ensimmäiselle riville. Jätä tyhjäksi niin muistutusta ei lähetetä.';
$txt['paid_mod_cost_usd'] = 'Hinta (USD)';
$txt['paid_mod_cost_eur'] = 'Hinta (EUR)';
$txt['paid_mod_cost_gbp'] = 'Hinta (GBP)';
$txt['paid_mod_cost_blank'] = 'Jätä tyhjäksi jolloin kyseisellä valuutalla ei voi maksaa tätä jäsenyyttä.';
$txt['paid_mod_span'] = 'Jäsenyyden kesto';
$txt['paid_mod_span_days'] = 'Päivää';
$txt['paid_mod_span_weeks'] = 'Viikkoa';
$txt['paid_mod_span_months'] = 'Kuukautta';
$txt['paid_mod_span_years'] = 'Vuotta';
$txt['paid_mod_active'] = 'Aktiivinen';
$txt['paid_mod_active_desc'] = 'Jäsenyyden pitää olla käytöstä, jotta sen voi tilata.';
$txt['paid_mod_prim_group'] = 'Ensisijainen jäsenryhmä';
$txt['paid_mod_prim_group_desc'] = 'Ensisijainen jäsenryhmä johon käyttäjä siirretään jäsenyyden ajaksi.';
$txt['paid_mod_add_groups'] = 'Muut jäsenryhmät';
$txt['paid_mod_add_groups_desc'] = 'Muut ryhmät jotka lisätään käyttäjälle jäsenyyden ajaksi.';
$txt['paid_mod_no_group'] = 'Ei muutosta';
$txt['paid_mod_edit_note'] = 'Huomaa: Koska tällä ryhmällä on tilaajia niin ryhmä asetuksia ei voida muuttaa!';
$txt['paid_mod_delete_warning'] = '<strong>Varoitus</strong><br /><br />Jos poistat jäsenyyden käyttäjät menettävät kaikki oikeudet joita jäsnyys antaa. Ellet halua sitä on suositeltavaa vain poistaa käytöstä poistamisen sijaan.<br />';
$txt['paid_mod_repeatable'] = 'Salli automaattinen uusiminen';
$txt['paid_mod_allow_partial'] = 'Salli osoittainen tilaus';
$txt['paid_mod_allow_partial_desc'] = 'Jos tämä on käytössä niin tapauksissa joissa käyttäjä maksaa vain osan niin tilaus on voimassa maksua vastaavan ajan.';
$txt['paid_mod_fixed_price'] = 'Kiinteä hinta ja -pituus';
$txt['paid_mod_flexible_price'] = 'Hinta riippuu tilauksen pituudesta';
$txt['paid_mod_price_breakdown'] = 'Vahtelevn keston hinnasto';
$txt['paid_mod_price_breakdown_desc'] = 'Määrittele tässä paljonko maksaa mikäkin aika yksikkö. Esimerkiksi kuukausi voi maksaa 12 euroa, mutta vuosi vain 100 euroa. Jos et halua käyttää jotankin jaksoa niin jätä se tyhjäksi.';
$txt['flexible'] = 'Vaihteleva kesto';

$txt['paid_per_day'] = 'Päivän hinta';
$txt['paid_per_week'] = 'Viikon hinta';
$txt['paid_per_month'] = 'Kuukauden hinta';
$txt['paid_per_year'] = 'Vuoden hinta';
$txt['day'] = 'Päivä';
$txt['week'] = 'Viikko';
$txt['month'] = 'Kuukausi';
$txt['year'] = 'Vuosi';

// View subscribed users.
$txt['viewing_users_subscribed'] = 'Katsotaan käyttäjiä';
$txt['view_users_subscribed'] = 'Katsotaan käyttäjiä jäsenyydelle &quot;%1$s&quot;';
$txt['no_subscribers'] = 'There are currently no subscribers to this subscription.';
$txt['add_subscriber'] = 'Lisää tilaaja';
$txt['edit_subscriber'] = 'Muokkaa tilaajaa';
$txt['delete_selected'] = 'Poista valitut';
$txt['complete_selected'] = 'Suorita valitut loppuun';

// @todo These strings are used in conjunction with JavaScript.  Use numeric entities.
$txt['delete_are_sure'] = 'Are you sure you want to delete all record of the selected subscriptions?';
$txt['complete_are_sure'] = 'Oletko varma että tahdot varmistaa valitut tilaukset?';

$txt['start_date'] = 'Alkamispäivä';
$txt['end_date'] = 'Loppumispäivä';
$txt['start_date_and_time'] = 'Alkumispäivä ja -aika';
$txt['end_date_and_time'] = 'Loppumispäivä ja -aika';
$txt['one_username'] = 'Anna vain yksi käyttäjänimi.';
$txt['minute'] = 'Minuutti';
$txt['error_member_not_found'] = 'Käyttäjää ei löytynyt';
$txt['member_already_subscribed'] = 'Tämä jäsen on jo tilannut tämän jäsenyyden. Muokkaa hänen olemassaolevaa tilaustaan.';
$txt['search_sub'] = 'Etsi käyttäjä';

// Make payment.
$txt['paid_confirm_payment'] = 'Vahvista maksu';
$txt['paid_confirm_desc'] = 'Jatkaaksesi, tarkista tiedot ja paina &quot;Tilaa&quot;-nappia';
$txt['paypal'] = 'PayPal';
$txt['paid_confirm_paypal'] = 'Maksaaksesi <a href="http://www.paypal.com">PayPal</a>in kautta, paina nappia alapuolelta ja sinut ohjataan PayPalin sivuille maksun suorittamiseksi.';
$txt['paid_paypal_order'] = 'Tilaa PayPalin kautta';
$txt['authorize'] = 'Authorize.Net';
$txt['paid_confirm_authorize'] = 'Maksaaksesi <a href="http://www.authorize.net">Authorize.Net</a> kautta, paina nappia alapuolelta ja sinut ohjataan Authorize.Netin sivuille maksun suorittamiseksi.';
$txt['paid_authorize_order'] = 'Tilaus Authorize.Net kautta';
$txt['2co'] = '2checkout';
$txt['paid_confirm_2co'] = 'Maksaaksesi <a href="http://www.2com.com">2co.com</a> kautta, paina nappia alapuolelta ja sinut ohjataan 2co.comin sivuille maksun suorittamiseksi.';
$txt['paid_2co_order'] = 'Tilaus 2co.com kautta';
$txt['paid_done'] = 'Maksu suoritettu';
$txt['paid_done_desc'] = 'Kiitos tilauksestasi. Jäsenyys lisätään maksunvälittäjän vahvistettua maksun.';
$txt['paid_sub_return'] = 'Palaa jäsenyyksiin';
$txt['paid_current_desc'] = 'Alla on luettelo kaikista nykyisistä ja edeltävistä tilauksista. Jatkaaksesi olemassaolevaa tilausta, yksinkertaisesti valitse se yllä olevasta luettelosta.';
$txt['paid_admin_add'] = 'Lisää tämä jäsenyys';

$txt['paid_not_set_currency'] = 'You have not setup your currency yet. Please do so from the <a href-"%1$s">Settings</a> section before continuing.';
$txt['paid_no_cost_value'] = 'Sinun on annettava hinta ja tilauksen pituus.';
$txt['paid_all_freq_blank'] = 'Sinun täytyy asettaa hinta ainakin yhdelle neljästä kestovaihtoehdosta.';

// Some error strings.
$txt['paid_no_data'] = 'Tämä skripti ei saanut kelpoa dataa.';

$txt['paypal_could_not_connect'] = 'Ei saatu yhtettä PayPalin palvelimeen';
$txt['paypal_currency_unkown'] = 'The currency code from PayPal (%1$s) does not match the code in your settings (%2$s)';
$txt['paid_sub_not_active'] = 'That subscription is not taking any new users.';
$txt['paid_disabled'] = 'Paid subscriptions are currently disabled.';
$txt['paid_unknown_transaction_type'] = 'Tuntematon maksullisen jäsenyyden tapahtumatyyppi.';
$txt['paid_empty_member'] = 'Maksullisten jäsenyyksien hallinta ei löytänyt jäsenen ID:tä';
$txt['paid_could_not_find_member'] = 'Maksullisten jäsenyyksien hallinta ei löytänyt jäsentä ID:llä %1$d ';
$txt['paid_count_not_find_subscription'] = 'Maksullisten jäsenyyksien hallinta ei löytänyt tilausta jäsenelle ID:llä %1$s, tilaus-ID: %2$s';
$txt['paid_count_not_find_subscription_log'] = 'Maksullisten jäsenyyksien hallinta ei löytänyt tilauslogimerkintää jäsenelle ID:llä %1$s, tilaus-ID: %2$s ';
$txt['paid_count_not_find_outstanding_payment'] = 'Coud not find outstanding payment entry for member ID: %1$s, subscription ID: %2$s so ignoring';
$txt['paid_admin_not_setup_gateway'] = 'Ylläpitäjä ei ole vielä käsitellyt tilauksia. Yritä myöhemmin uudelleen.';
$txt['paid_make_recurring'] = 'Tee tästä maksusta toistuva';

$txt['subscriptions'] = 'Jäsenyydet';
$txt['subscription'] = 'Jäsenyys';
$txt['subscribers'] = 'Subscribers';
$txt['paid_subs_desc'] = 'Below is a list of all the subscriptions which are available on this site.';
$txt['paid_subs_none'] = 'There are currently no paid subscriptions available.';

$txt['paid_current'] = 'Nykyiset tilaukset';
$txt['pending_payments'] = 'Odottavat maksut';
$txt['pending_payments_desc'] = 'Tämä jäsen on yrittänyt suoritaaa seuraavat maksut, mutta niihin ei olla saatu varmistusta. Jos olet varma että maksu on maksettu paina &quot;hyväksy&quot; ottaaksesi käyttöön. Voit myös poistaa kaikki viittaukset maksuun painamalla &quot;Poista&quot;.';
$txt['pending_payments_value'] = 'Arvo';
$txt['pending_payments_accept'] = 'Hyväksy';
$txt['pending_payments_remove'] = 'Poista';