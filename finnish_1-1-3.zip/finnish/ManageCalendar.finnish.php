<?php
// Version: 1.1; ManageCalendar

$txt['calendar_desc'] = 'Täällä voit muokata kalenterin ominaisuuksia.';

// Calendar Settings
$txt['calendar_settings_desc'] = 'Täällä voit ottaa kalenterin käyttöön sekä muokata sen asetuksia.';
$txt['groups_calendar_view'] = 'Jäsenryhmät jotka saavat katsella kalenteria';
$txt['groups_calendar_post'] = 'Jäsenryhmät jotka saavat lisätä tapahtumia';
$txt['groups_calendar_edit_own'] = 'Jäsenryhmät jotka saavat muokata omia tapahtumiaan';
$txt['groups_calendar_edit_any'] = 'Jäsenryhmät jotka saavat muokata kaikkia tapahtumia';
$txt['setting_cal_enabled'] = 'Kalenteri päällä';
$txt['setting_cal_daysaslink'] = 'Linkitä päivät \'Lähetä tapahtuma\' toimintoon';
$txt['setting_cal_days_for_index'] = 'Enimmämäärä päiviä jolloin tapahtuma näkyy etusivulla';
$txt['setting_cal_showholidays'] = 'Näytä lomat';
$txt['setting_cal_showbdays'] = 'Näytä syntymäpäivät';
$txt['setting_cal_showevents'] = 'Näytä tapahtumat';
$txt['setting_cal_export'] = 'Allow events to be exported in iCal format';
$txt['setting_cal_show_never'] = 'Ei koskaan';
$txt['setting_cal_show_cal'] = 'Vain kalenterissa';
$txt['setting_cal_show_index'] = 'Vain keskustelualueen etusivulla';
$txt['setting_cal_show_all'] = 'Näytä sekä kalenterissa että keskustelualueen etusivulla';
$txt['setting_cal_defaultboard'] = 'Oletusalue johon tapahtumia lähetetään';
$txt['setting_cal_allow_unlinked'] = 'Salli ettei tapahtumia tarvitse linkittää viesteihin';
$txt['setting_cal_minyear'] = 'Ensimmäinen vuosi kalenterissa';
$txt['setting_cal_maxyear'] = 'Viimeinen vuosi kalenterissa';
$txt['setting_cal_allowspan'] = 'Salli tapahtumien kestää useampia päiviä';
$txt['setting_cal_maxspan'] = 'Tapahtuman maksimipituus päivissä';
$txt['setting_cal_showInTopic'] = 'Näytä linkitetyt tapahtumat viestinäkymässä';

// Adding/Editing/Viewing Holidays
$txt['manage_holidays_desc'] = 'Täällä voit lisätä ja poistaa pyhäpäiviä ja lomia keskustelualueesi kalenteriin.';
$txt['current_holidays'] = 'Nykyiset loma-ajat ja pyhäpäivät';
$txt['holidays_title'] = 'Loma-aika - pyhäpäivä';
$txt['holidays_title_label'] = 'Otsikko';
$txt['holidays_delete_confirm'] = 'Oletko varma että haluat poistaa nämä pyhät ja loma-ajat?';
$txt['holidays_add'] = 'Add new holiday';
$txt['holidays_edit'] = 'Edit existing holiday';
$txt['holidays_button_add'] = 'Lisää';
$txt['holidays_button_edit'] = 'Muokkaa';
$txt['holidays_button_remove'] = 'Poista';
$txt['holidays_no_entries'] = 'Yhtään juhlapyhää ei ole lisätty';
$txt['every_year'] = 'Joka vuosi';