<?php
// Version: 1.1; Reports

$txt['generate_reports_desc'] = 'Tällä alueella voit luoda yhteenvetoja eri asioista helpottaaksesi foorumin ylläpitoa. Valitse alta vaihtoehto ja jatka eteenpäin.';
$txt['generate_reports_continue'] = 'Eteenpäin';
$txt['generate_reports_type'] = 'Valitse yhteenvedon tyyppi';
$txt['gr_type_boards'] = 'Alueet';
$txt['gr_type_desc_boards'] = 'Näyttää yhteenvetoa alueistasi sekä kenellä on pääsy niihin.';
$txt['gr_type_board_perms'] = 'Alueiden oikeudet';
$txt['gr_type_desc_board_perms'] = 'Luo yhteenvedon jokaisen ryhmän oikeuksista eri alueilla.';
$txt['gr_type_member_groups'] = 'Jäsenryhmät';
$txt['gr_type_desc_member_groups'] = 'Yhteenveto jokaisen ryhmän asetuksista keskustelualueella.';
$txt['gr_type_group_perms'] = 'Ryhmien oikeudet';
$txt['gr_type_desc_group_perms'] = 'Yhteenveto jokaisen jäsenryhmän oikeuksista keskustelualueella.';
$txt['gr_type_staff'] = 'Ylläpitäjät';
$txt['gr_type_desc_staff'] = 'Yhteenveto kaikista jäsenistä, joilla on erityisoikeuksia keskustelualueella.';

$txt['full_member'] = 'Tavallinen jäsen';
$txt['results'] = 'Tulokset';

// Board permissions
$txt['board_perms_permission'] = 'Oikeudet';
$txt['board_perms_allow'] = 'Sallittu';
$txt['board_perms_deny'] = 'Kielletty';
$txt['board_perms_name_announce_topic'] = 'Tiedottaa aiheesta';
$txt['board_perms_name_approve_posts'] = 'Hyväksyä viestejä';
$txt['board_perms_name_delete_any'] = 'Poistaa kenen tahansa viestejä';
$txt['board_perms_name_delete_own'] = 'Poistaa omia viestejä';
$txt['board_perms_name_delete_replies'] = 'Poistaa vastauksia omista aiheista';
$txt['board_perms_name_lock_any'] = 'Lukita mikä tahansa aihe';
$txt['board_perms_name_lock_own'] = 'Lukita oma aihe';
$txt['board_perms_name_make_sticky'] = 'Pin topics';
$txt['board_perms_name_mark_any_notify'] = 'Pyytää muistutuksia kaikista aiheista';
$txt['board_perms_name_mark_notify'] = 'Pyytää muistutuksia omista aiheista';
$txt['board_perms_name_merge_any'] = 'Yhdistää aiheita';
$txt['board_perms_name_moderate_board'] = 'Valvoa aluetta';
$txt['board_perms_name_modify_any'] = 'Muokata kaikkia viestejä';
$txt['board_perms_name_modify_own'] = 'Muokata omia viestejä';
$txt['board_perms_name_modify_replies'] = 'Muokata vastauksia omissa aiheissa';
$txt['board_perms_name_move_any'] = 'Siirtää kaikkia aiheita';
$txt['board_perms_name_move_own'] = 'Siirtää omia aiheita';
$txt['board_perms_name_poll_add_any'] = 'Lisätä äänestys mihin tahansa aiheeseen';
$txt['board_perms_name_poll_add_own'] = 'Lisätä äänestys omaan aiheeseen';
$txt['board_perms_name_poll_edit_any'] = 'Muokata kaikkia äänestyksiä';
$txt['board_perms_name_poll_edit_own'] = 'Muokata omia äänestyksiä';
$txt['board_perms_name_poll_lock_any'] = 'Lukita mikä tahansa äänestys';
$txt['board_perms_name_poll_lock_own'] = 'Lukita omat äänestykset';
$txt['board_perms_name_poll_post'] = 'Aloittaa uusi äänestys';
$txt['board_perms_name_poll_remove_any'] = 'Poistaa mikä tahansa äänestys';
$txt['board_perms_name_poll_remove_own'] = 'Poistaa omia äänestyksiä';
$txt['board_perms_name_poll_view'] = 'Katsella äänestyksiä';
$txt['board_perms_name_poll_vote'] = 'Äänestäminen';
$txt['board_perms_name_post_attachment'] = 'Liitteiden lisääminen viesteihin';
$txt['board_perms_name_post_new'] = 'Uusien aiheiden aloittaminen';
$txt['board_perms_name_post_reply_any'] = 'Kaikkiin aiheisiin vastaaminen';
$txt['board_perms_name_post_reply_own'] = 'Omiin aiheisiin vastaaminen';
$txt['board_perms_name_post_unapproved_attachments'] = 'Lähettää hyväksymättömiä liitetiedostoja';
$txt['board_perms_name_post_unapproved_topics'] = 'Lähettää hyväksymättömiä aiheita';
$txt['board_perms_name_post_unapproved_replies_any'] = 'Lähettää hyväksymättömiä vastauksia mihän tahansa aiheeseen';
$txt['board_perms_name_post_unapproved_replies_own'] = 'Lähettää hyväksymättömiä vastauksia omiin aiheisiin';
$txt['board_perms_name_remove_any'] = 'Poistaa mikä tahansa aihe';
$txt['board_perms_name_remove_own'] = 'Poistaa oma aihe';
$txt['board_perms_name_report_any'] = 'Raportoida mistä tahansa viesteistä';
$txt['board_perms_name_send_topic'] = 'Aiheiden lähettäminen ystäville';
$txt['board_perms_name_split_any'] = 'Jakaa mikä tahansa aihe';
$txt['board_perms_name_view_attachments'] = 'Katsella liitetiedostoja';

$txt['board_perms_group_no_polls'] = 'Tälle alueelle ei voi lisätä äänestyksiä';
$txt['board_perms_group_reply_only'] = 'Tällä alueella voi vain vastata aiheisiin';
$txt['board_perms_group_read_only'] = 'Tällä alueella ei voi kirjoittaa viestejä';

// Membergroup info!
$txt['member_group_color'] = 'Jäsenryhmän väri';
$txt['member_group_min_posts'] = 'Vaadittu viestimäärä';
$txt['member_group_max_messages'] = 'Yksityisviestien enimmäismäärä postilaatikossa';
$txt['member_group_icons'] = 'Icons';
$txt['member_group_settings'] = 'Asetukset';
$txt['member_group_access'] = 'Pääsy alueille';

// Board info.
$txt['none'] = 'Ei ole';
$txt['board_category'] = 'Alue';
$txt['board_parent'] = 'Yläkategoria';
$txt['board_num_topics'] = 'Aiheiden määrä';
$txt['board_num_posts'] = 'Viestien määrä';
$txt['board_count_posts'] = 'Laskee viestit';
$txt['board_theme'] = 'Alueen teema';
$txt['board_override_theme'] = 'Pakotettu alueen teema';
$txt['board_profile'] = 'Oikeusprofiili';
$txt['board_moderators'] = 'Valvojat';
$txt['board_groups'] = 'Ryhmät joilla pääsy alueelle';
$txt['board_disallowed_groups'] = 'Groups with Access Denied';

// Group Permissions.
$txt['group_perms_name_access_mod_center'] = 'Pääsy valvontakeskukseen';
$txt['group_perms_name_admin_forum'] = 'Hallinnoida keskustelualuetta';
$txt['group_perms_name_calendar_edit_any'] = 'Muokata kaikkia tapahtumia';
$txt['group_perms_name_calendar_edit_own'] = 'Muokata omia tapahtumia';
$txt['group_perms_name_calendar_post'] = 'Lisätä tapahtumia';
$txt['group_perms_name_calendar_view'] = 'Katsella tapahtumia';
$txt['group_perms_name_edit_news'] = 'Muokata uutisia';
$txt['group_perms_name_issue_warning'] = 'Antaa varoituksia';
$txt['group_perms_name_karma_edit'] = 'Muokata karmaa';
$txt['group_perms_name_manage_attachments'] = 'Hallinnoida liitetiedostoja';
$txt['group_perms_name_manage_bans'] = 'Hallinnoida porttikieltoja';
$txt['group_perms_name_manage_boards'] = 'Hallinnoida alueita';
$txt['group_perms_name_manage_membergroups'] = 'Manage member groups';
$txt['group_perms_name_manage_permissions'] = 'Hallinnoida oikeuksia';
$txt['group_perms_name_manage_smileys'] = 'Hallinnoida hymiöitä ja viesti-ikoneja';
$txt['group_perms_name_moderate_forum'] = 'Valvoa keskustelualuetta';
$txt['group_perms_name_pm_read'] = 'Lukea yksityisviestejä';
$txt['group_perms_name_pm_send'] = 'Lähettää yksityisviestejä';
$txt['group_perms_name_profile_extra_any'] = 'Muokata kaikkia lisäasetuksia';
$txt['group_perms_name_profile_extra_own'] = 'Muokata omia lisäasetuksia';
$txt['group_perms_name_profile_identity_any'] = 'Muokata kaikkien jäsenasetuksia';
$txt['group_perms_name_profile_identity_own'] = 'Muokata omia jäsenasetuksia';
$txt['group_perms_name_profile_set_avatar'] = 'Select an avatar';
$txt['group_perms_name_profile_remove_any'] = 'Poistaa kenen tahansa jäsenyys';
$txt['group_perms_name_profile_remove_own'] = 'Poistaa oma jäsenyys';
$txt['group_perms_name_profile_title_any'] = 'Muokata kenen tahansa titteliä';
$txt['group_perms_name_profile_title_own'] = 'Muokata omaa titteliä';
$txt['group_perms_name_profile_view_any'] = 'Katsella kaikkien profiileja';
$txt['group_perms_name_profile_view_own'] = 'View own profile';
$txt['group_perms_name_search_posts'] = 'Hakea viestejä';
$txt['group_perms_name_send_mail'] = 'Lähettää sähköpostia jäsenille keskustelualueen kautta';
$txt['group_perms_name_view_mlist'] = 'View the member list';
$txt['group_perms_name_view_stats'] = 'Katsella tilastoja';
$txt['group_perms_name_who_view'] = 'Katsella mitä keskustelualueella tapahtuu';

$txt['report_error_too_many_staff'] = 'You have too many staff members. The report will not work with more than 300 staff members.';
$txt['report_staff_position'] = 'Asema';
$txt['report_staff_moderates'] = 'Valvoo';
$txt['report_staff_posts'] = 'Viestit';
$txt['report_staff_last_login'] = 'Viimeksi paikalla';
$txt['report_staff_all_boards'] = 'Kaikki alueet';
$txt['report_staff_no_boards'] = 'Ei alueita';