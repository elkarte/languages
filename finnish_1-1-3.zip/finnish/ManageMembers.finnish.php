<?php
// Version: 1.1; ManageMembers

$txt['groups'] = 'Ryhmät';
$txt['viewing_groups'] = 'Tarkastellaan jäsenryhmiä';

$txt['membergroups_title'] = 'Muokkaa jäsenryhmiä';
$txt['membergroups_description'] = 'Jäsenryhmät ovat ryhmiä joilla on tietyt oikeudet, ulkoasu jne. Eräät ryhmät ovat riippuvaisia viestimääristä. Voit liittää jäseniä eri ryhmiin heidän profiilistaan.';
$txt['membergroups_modify'] = 'muokkaa';
$txt['membergroups_modify_parent'] = 'Modify parent group';

$txt['membergroups_add_group'] = 'Lisää ryhmä';
$txt['membergroups_regular'] = 'Tavalliset ryhmät';
$txt['membergroups_post'] = 'Viestimääriin perustuvat ryhmät';
$txt['membergroups_guests_na'] = '-';

$txt['membergroups_group_name'] = 'Jäsenryhmän nimi';
$txt['membergroups_new_board'] = 'Näkyvät alueet';
$txt['membergroups_new_board_desc'] = 'Alueet jotka jäsenryhmä saa näähdä.';
$txt['membergroups_new_board_post_groups'] = '<em>Huomioi: normaalisti viesteihin perustuvat ryhmät eivät tarvitse pääsyä, koska ryhmä johon jäsen kuuluu mahdollistaa sen.</em>';
$txt['membergroups_new_as_inherit'] = 'peritty';
$txt['membergroups_new_as_type'] = 'tyypin mukaan';
$txt['membergroups_new_as_copy'] = 'tai perustuen';
$txt['membergroups_new_copy_none'] = '(ei mitään)';
$txt['membergroups_can_edit_later'] = 'Voit muokata niitä myöhemmin.';

$txt['membergroups_edit_group'] = 'Muokkaa ryhmää';
$txt['membergroups_edit_name'] = 'Ryhmän nimi';
$txt['membergroups_edit_inherit_permissions'] = 'Peri oikeudet';
$txt['membergroups_edit_inherit_permissions_desc'] = 'Valitse "Ei" niin käytetään omia oikeuksia.';
$txt['membergroups_edit_inherit_permissions_no'] = 'Ei - käytä omia oikeuksia';
$txt['membergroups_edit_inherit_permissions_from'] = 'Peri';
$txt['membergroups_edit_hidden'] = 'Voi olla ensijainen jäsenryhmä';
$txt['membergroups_edit_hidden_no'] = 'Näkyvä';
$txt['membergroups_edit_hidden_boardindex'] = 'Visible - Apart from in group key';
$txt['membergroups_edit_hidden_all'] = 'Näkymätön';
// Do not use numeric entities in the below string.
$txt['membergroups_edit_hidden_warning'] = 'Oletko varma että haluat estää tämän asettamisen ensisijaiseksi ryhmäksi?\\n\\nJos teet niin, käyttäjät joilla on tämä ryhmä ensisijaisena muutetaan se lisärymäksi.';
$txt['membergroups_edit_desc'] = 'Ryhmän esittely';
$txt['membergroups_edit_group_type'] = 'Group type';
$txt['membergroups_edit_select_group_type'] = 'Select Group type';
$txt['membergroups_group_type_private'] = 'Yksityinen <span class="smalltext">(Jäsenyys tulee asettaa)</span>';
$txt['membergroups_group_type_protected'] = 'Suojattu <span class="smalltext">(Vain ylläpitäjät voivat hallita ja asettaa ryhmälle jäseniä)</span> ';
$txt['membergroups_group_type_request'] = 'Haettava <span class="smalltext">(Käyttäjät voi hakea jäsenyyttä)</span>';
$txt['membergroups_group_type_free'] = 'Vapaa <span class="smalltext">(Käytäjät voi lisätä ja poistaa ryhmän vapaasti)</span>';
$txt['membergroups_group_type_post'] = 'Viestimäärään perustuva <span class="smalltext">(Jäsenyys riippuu viestimäärästä)</span>';
$txt['membergroups_min_posts'] = 'Tarv. viestit';
$txt['membergroups_online_color'] = 'Väri jäsenluettelossa';
$txt['membergroups_icon_count'] = 'Number of icon images';
$txt['membergroups_icon_image'] = 'Icon image filename';
$txt['membergroups_icon_image_note'] = 'Upload icon images in to the default theme directory to enable selection.<br />Select the icon to change it.';
$txt['membergroups_max_messages'] = 'Maksimissaan yksityisviestejä postilaatikossa';
$txt['membergroups_max_messages_note'] = '0 = ei rajoitusta';
$txt['membergroups_max_messages_desc'] = 'Here you can set the limit of personal messages a user can keep on the server.<br />
To allow store an unlimited number of personal messages, you can set the value to 0';
$txt['membergroups_edit_save'] = 'Tallenna';
$txt['membergroups_delete'] = 'Poista';
$txt['membergroups_confirm_delete'] = 'Are you sure you want to delete this group?';

$txt['membergroups_members_title'] = 'Ryhmän kaikki jäsenet';
$txt['membergroups_members_group_members'] = 'Ryhmän jäsenet';
$txt['membergroups_members_no_members'] = 'Tämä ryhmä on tyhjä';
$txt['membergroups_members_add_title'] = 'Lisää jäsen tähän ryhmään';
$txt['membergroups_members_add_desc'] = 'Lista lisättävistä jäsenistä';
$txt['membergroups_members_add'] = 'Lisää jäseniä';
$txt['membergroups_members_remove'] = 'Poista ryhmästä';
$txt['membergroups_members_last_active'] = 'Viimeksi paikalla';
$txt['membergroups_members_additional_only'] = 'Aseta vain lisäryhmäksi';
$txt['membergroups_members_group_moderators'] = 'Ryhmän valvojat';
$txt['membergroups_members_description'] = 'Kuvaus';
// Use javascript escaping in the below.
$txt['membergroups_members_deadmin_confirm'] = 'Oletko varma että haluat poistaa itsesi ylläpitäjä ryhmästä?';

$txt['membergroups_postgroups'] = 'Viestimääriin perustuvat ryhmät';
$txt['membergroups_settings'] = 'Jäsenryhmäasetukset';
$txt['groups_manage_membergroups'] = 'Jäsenet jotka saavat muokata jäsenryhmiä';
$txt['membergroups_select_permission_type'] = 'Valitse lupaprofiili';
$txt['membergroups_images_url'] = '{theme URL}/images/group_icons/';
$txt['membergroups_select_visible_boards'] = 'Näytä alueet';
$txt['membergroups_members_top'] = 'Jäsenet';
$txt['membergroups_name'] = 'Nimi';
$txt['membergroups_icons'] = 'Icons';

$txt['admin_browse_approve'] = 'Jäsenet joiden hakemus odottaa hyväksyntää';
$txt['admin_browse_approve_desc'] = 'Täällä voit hallinnoida jäsenhakemuksia.';
$txt['admin_browse_activate'] = 'Jäsenet joiden tunnukset odottavat aktivointia';
$txt['admin_browse_activate_desc'] = 'Tämä ikkuna listaa jäsenet jotka eivät vielä ole aktivoineet tunnuksiaan.';
$txt['admin_browse_awaiting_approval'] = 'Awaiting Approval [%1$d]';
$txt['admin_browse_awaiting_activate'] = 'Awaiting Activation [%1$d]';

$txt['admin_browse_username'] = 'Käyttäjänimi';
$txt['admin_browse_email'] = 'Sähköpostiosoite';
$txt['admin_browse_ip'] = 'IP osoite';
$txt['admin_browse_registered'] = 'Rekisteröitynyt';
$txt['admin_browse_id'] = 'ID';
$txt['admin_browse_with_selected'] = 'Valitut';
$txt['admin_browse_no_members_approval'] = 'Tällä hetkellä ei ole jäseniä odottamassa hyväksyntää.';
$txt['admin_browse_no_members_activate'] = 'Yhtään jäsentä ei ole jättänyt aktivoimatta jäsenyyttään.';

// Don't use entities in the below strings, except the main ones. (lt, gt, quot.)
$txt['admin_browse_warn'] = 'kaikki valitut jäsenet?';
$txt['admin_browse_outstanding_warn'] = 'kaikki k.o jäsenet?';
$txt['admin_browse_w_approve'] = 'Hyväksy';
$txt['admin_browse_w_activate'] = 'Aktivoi';
$txt['admin_browse_w_delete'] = 'Poista';
$txt['admin_browse_w_reject'] = 'Reject (Delete)';
$txt['admin_browse_w_remind'] = 'Muistuta';
$txt['admin_browse_w_approve_deletion'] = 'Hyväksy (jäsenyyden poisto)';
$txt['admin_browse_w_email'] = 'ja lähetä sähköposti';
$txt['admin_browse_w_approve_require_activate'] = 'Approve and require activation';

$txt['admin_browse_filter_by'] = 'Näytä vain';
$txt['admin_browse_filter_show'] = 'Näytetään';
$txt['admin_browse_filter_type_0'] = 'Unactivated new accounts';
$txt['admin_browse_filter_type_2'] = 'Unactivated email changes';
$txt['admin_browse_filter_type_3'] = 'Unapproved new accounts';
$txt['admin_browse_filter_type_4'] = 'Unapproved account deletions';
$txt['admin_browse_filter_type_5'] = 'Hyväksymättömät "alaikäisten" jäsenyydet';

$txt['admin_browse_outstanding'] = 'Aktivoimattomat jäsenet';
$txt['admin_browse_outstanding_days_1'] = 'Jäsenet jotka ovat rekisteröityneet';
$txt['admin_browse_outstanding_days_2'] = 'päivää sitten';
$txt['admin_browse_outstanding_perform'] = 'Suorita seuraavat toimenpiteet';
$txt['admin_browse_outstanding_go'] = 'Suorita toimepide';

$txt['check_for_duplicate'] = 'Check for duplicates';
$txt['dont_check_for_duplicate'] = 'Don\'t check for duplicates';
$txt['duplicates'] = 'Kaksointunnukset';

$txt['not_activated'] = 'Aktivoimaton';