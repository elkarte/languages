<?php
// Version: 1.1; ManageSmileys

$txt['smiley_sets_save'] = 'Tallenna muutokset';
$txt['smiley_sets_add'] = 'New Smiley Set';
$txt['smiley_sets_delete'] = 'Poista valitut';
$txt['smiley_sets_confirm'] = 'Haluatko varmasti poistaa tämän paketin?\\n\\nHuom! Tämä ei poista tiedostoja, vain valinnan.';
$txt['smiley_sets_none'] = 'There are currently no smiley sets.';

$txt['setting_smiley_sets_default'] = 'Oletushymiöpaketti';
$txt['setting_smiley_sets_enable'] = 'Anna jäsenten valita hymiönsä';
$txt['setting_smiley_enable'] = 'Käytä muokattuja hymiöitä';
$txt['setting_smileys_url'] = 'URL kansioon, jossa hymiöt sijaitsevat';
$txt['setting_smileys_dir'] = 'Absoluuttinen polku hymiöihin';
$txt['setting_messageIcons_enable'] = 'Käytä muokattuja viesti-ikoneita';
$txt['setting_messageIcons_enable_note'] = '(muuten käytetään oletusikoneja.)';
$txt['groups_manage_smileys'] = 'Ryhmät jotka saavat hallita hymiöitä ja viesti-ikoneja';

$txt['smiley_sets_name'] = 'Nimi';
$txt['smiley_sets_url'] = 'Osoite';
$txt['smiley_sets_default'] = 'Vakio';

$txt['smileys_add_method'] = 'Kuva';
$txt['smileys_add_existing'] = 'Use existing file';
$txt['smileys_add_upload'] = 'Upload new smiley';
$txt['smileys_add_upload_choose'] = 'Ladattava tiedosto';
$txt['smileys_add_upload_choose_desc'] = 'Kuva jota käytetään kaikissa hymiöspaketeissa.';
$txt['smileys_add_upload_all'] = 'Sama kuva kaikkiin paketteihin';
$txt['smileys_add_upload_for1'] = 'Kuva';
$txt['smileys_add_upload_for2'] = 'pakettiin';

$txt['smileys_enable_note'] = '(muuten käytetään oletushymiötä.)';
$txt['smileys_code'] = 'Koodi';
$txt['smileys_filename'] = 'Tiedoston nimi';
$txt['smileys_description'] = 'Vihje tai kuvaus';
$txt['smileys_remove'] = 'Poista';
$txt['smileys_save'] = 'Tallenna muutokset';
$txt['smileys_delete'] = 'Poista hymiö';
// Don't use entities in the below string.
$txt['smileys_delete_confirm'] = 'Haluatko varmasti poistaa tämän hymiön?';
$txt['smileys_with_selected'] = 'Valitut';
$txt['smileys_make_hidden'] = 'Piilota';
$txt['smileys_show_on_post'] = 'Show on post form';
$txt['smileys_show_on_popup'] = 'Show on popup';

$txt['smiley_settings_explain'] = 'Näillä asetuksilla voit muuttaa oletushymiöpakettia, sallia käyttäjien valita omat hymiönsä sekä asettaa polut ja muut hymiöasetukset.';
$txt['smiley_editsets_explain'] = 'Hymiöpaketit on ryhmiä joista käyttäjät voivat valita mieluisensa. Käytössä voi olla esimerkiksi keltaisia ja punaisia hymiöitä. Täällä voit muuttaa jokaisen paketin nimeä ja sijaintia.';
$txt['smiley_editsmileys_explain'] = 'Change your smileys here by clicking on the smiley you want to modify. Remember that these smileys all have to exist in all the sets or some smileys won\'t show up.  Don\'t forget to save after you are done editing.';
$txt['smiley_setorder_explain'] = 'Hymiöiden järjestystä voi muttaa täältä.';
$txt['smiley_addsmiley_explain'] = 'Täällä voidaan lisätä uusia hymiöitä joko olemassa olevasta tiedostosta tai lataamalla kokonaan uusia.';

$txt['smiley_set_select_default'] = 'Oletushymiöpaketti';
$txt['smiley_set_new'] = 'Create new Smiley Set';
$txt['smiley_set_modify_existing'] = 'Modify existing Smiley Set';
$txt['smiley_set_modify'] = 'muokkaa';
$txt['smiley_set_import_directory'] = 'Tuo hymiöitä hakemistosta';
$txt['smiley_set_import_single'] = 'Tähän pakettiin on vielä tuomatta hymiö. Klikkaa';
$txt['smiley_set_import_multiple'] = '%1$d hymiötä hakemistossa ei ole vielä tuotu. Klikkaa';
$txt['smiley_set_to_import_single'] = 'tuodaksesi sen nyt.';
$txt['smiley_set_to_import_multiple'] = 'tuodaksesi ne nyt.';

$txt['smileys_location'] = 'Sijainti';
$txt['smileys_location_form'] = 'Viestien lähetyslomake';
$txt['smileys_location_hidden'] = 'Piilotettu';
$txt['smileys_location_popup'] = 'Popup-ikkuna';
$txt['smileys_modify'] = 'muokkaa';
$txt['smileys_not_found_in_set'] = 'Hymiötä ei löydy seuraavasta paketista';
$txt['smileys_default_description'] = '(Lisää kuvaus)';
$txt['smiley_new'] = 'Lisää uusi hymiö';
$txt['smiley_modify_existing'] = 'Muokkaa hymiötä';
$txt['smiley_preview'] = 'Esikatsele';
$txt['smiley_preview_using'] = 'Hymiösetti';
$txt['smileys_confirm'] = 'Haluatko varmasti poistaa hymiöt?\\n\\nHuom! Tämä ei poista kuvatiedostoja, vain valinnan.';
$txt['smileys_location_form_description'] = 'Nämä hymiöt näkyvät viestien lähetyslomakkeessa tekstikentän yllä.';
$txt['smileys_location_popup_description'] = 'Nämä hymiöt näkyvät ponnahdusikkunassa kun käyttäjä klikkaa \'Lisää hymiöitä\' -linkkiä';
$txt['smileys_move_select_destination'] = 'Valitse hymiön paikka';
$txt['smileys_move_select_smiley'] = 'Select smiley to move or drag it to the location you want';
$txt['smileys_move_here'] = 'Siirrä hymiö tänne';
$txt['smileys_no_entries'] = 'Yhtään hymiötä ei ole muokattu';
$txt['smileys_moved_done'] = 'Smiley successfully moved';
$txt['smileys_moved_fail'] = 'Unable to move smiley';

$txt['icons_edit_icons_explain'] = 'Täällä voit muuttaa viesti-ikonien valikoimaa. Voit lisätä, poistaa ja muokata niitä sekä rajoittaa niiden käytön tietyille alueille.';
$txt['icons_edit_icons_all_boards'] = 'Available in all boards';
$txt['icons_board'] = 'Alue';
$txt['icons_confirm'] = 'Haluatko varmasti poistaa nämä ikonit?\\n\\nTämä poistaa vain valinnan, vanhoissa viesteissä kuvat säilyvät.';
$txt['icons_add_new'] = 'Add new icon';

$txt['icons_edit_icon'] = 'Edit message icon';
$txt['icons_new_icon'] = 'New message icon';
$txt['icons_location_first_icon'] = 'As first icon';
$txt['icons_location_after'] = 'Jälkeen';
$txt['icons_filename_all_png'] = 'All files must be &quot;png&quot; files';
$txt['icons_no_entries'] = 'Yhtään ikonia ei ole vielä muokattu.';
$txt['icons_reordered'] = 'Message Icons successfully reordered';
$txt['icons_reorder_note'] = 'You can change the message icon order by dragging and dropping an item to a new location in the list.';