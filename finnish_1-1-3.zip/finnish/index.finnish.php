<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'fi_FI.utf8';
$txt['lang_dictionary'] = 'fi';
$txt['lang_spelling'] = 'american';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'Sunday';
$txt['monday'] = 'Monday';
$txt['tuesday'] = 'Tuesday';
$txt['wednesday'] = 'Wednesday';
$txt['thursday'] = 'Thursday';
$txt['friday'] = 'Friday';
$txt['saturday'] = 'Saturday';

$txt['sunday_short'] = 'Sun';
$txt['monday_short'] = 'Mon';
$txt['tuesday_short'] = 'Tue';
$txt['wednesday_short'] = 'Wed';
$txt['thursday_short'] = 'Thu';
$txt['friday_short'] = 'Fri';
$txt['saturday_short'] = 'Sat';

$txt['january'] = 'January';
$txt['february'] = 'February';
$txt['march'] = 'March';
$txt['april'] = 'April';
$txt['may'] = 'May';
$txt['june'] = 'June';
$txt['july'] = 'July';
$txt['august'] = 'August';
$txt['september'] = 'September';
$txt['october'] = 'October';
$txt['november'] = 'November';
$txt['december'] = 'December';

$txt['january_titles'] = 'January';
$txt['february_titles'] = 'February';
$txt['march_titles'] = 'March';
$txt['april_titles'] = 'April';
$txt['may_titles'] = 'May';
$txt['june_titles'] = 'June';
$txt['july_titles'] = 'July';
$txt['august_titles'] = 'August';
$txt['september_titles'] = 'September';
$txt['october_titles'] = 'October';
$txt['november_titles'] = 'November';
$txt['december_titles'] = 'December';

$txt['january_short'] = 'Jan';
$txt['february_short'] = 'Feb';
$txt['march_short'] = 'Mar';
$txt['april_short'] = 'Apr';
$txt['may_short'] = 'May';
$txt['june_short'] = 'Jun';
$txt['july_short'] = 'Jul';
$txt['august_short'] = 'Aug';
$txt['september_short'] = 'Sep';
$txt['october_short'] = 'Oct';
$txt['november_short'] = 'Nov';
$txt['december_short'] = 'Dec';

$txt['time_am'] = 'ap';
$txt['time_pm'] = 'ip';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Etusivu';
$txt['community'] = 'Community';
// Sub menu labels
$txt['help'] = 'Ohjeet';
$txt['search'] = 'Haku';
$txt['calendar'] = 'Kalenteri';
$txt['members'] = 'Jäsenet';
$txt['recent_posts'] = 'Tuoreimmat viestit';

$txt['admin'] = 'Ylläpito';
// Sub menu labels
$txt['errlog'] = 'Virhelogi';
$txt['package'] = 'Pakettienhallinta';
$txt['edit_permissions'] = 'Oikeudet';
$txt['modSettings_title'] = 'Toiminnot ja asetukset';

$txt['moderate'] = 'Moderoi';
// Sub menu labels
$txt['modlog_view'] = 'Valvontalogi';
$txt['mc_emailerror'] = 'Unapproved Emails';
$txt['mc_reported_posts'] = 'Raportoidut viestit';
$txt['mc_reported_pms'] = 'Reported Personal Messages';
$txt['mc_unapproved_attachments'] = 'Hyväksymättömät liitetiedostot';
$txt['mc_unapproved_poststopics'] = 'Hyväksymättömät viestit ja aiheet';

$txt['pm_short'] = 'Yksityisviestit';
// Sub menu labels
$txt['pm_menu_read'] = 'Lue viestisi';
$txt['pm_menu_send'] = 'Lähetä viesti';

$txt['account_short'] = 'My Account';
// Sub menu labels
$txt['profile'] = 'Profiilit';
$txt['mydrafts'] = 'My Drafts';
$txt['summary'] = 'Yhteenveto';
$txt['theme'] = 'Keskustelualueen asetukset';
$txt['account'] = 'Tunnuksen asetukset';
$txt['forumprofile'] = 'Profiili';

$txt['view_unread_category'] = 'Uusia viestejä';
$txt['view_replies_category'] = 'New Replies';

$txt['login'] = 'Log in';
$txt['register'] = 'Rekisteröidy';
$txt['logout'] = 'Log out';
// End main menu strings.

$txt['save'] = 'Tallenna';

$txt['modify'] = 'muokkaa';
$txt['forum_index'] = '%1$s - Etusivu';
$txt['board_name'] = 'Keskustelualueen nimi';
$txt['posts'] = 'Viestit';

$txt['member_postcount'] = 'Viestit';
$txt['no_subject'] = '(Ei otsikkoa)';
$txt['view_profile'] = 'Profiili';
$txt['guest_title'] = 'Vieras';
$txt['author'] = 'Muokkauksen tekijä';
$txt['on'] = 'ap';
$txt['remove'] = 'Poista';
$txt['start_new_topic'] = 'Aloita uusi aihe';

// Use numeric entities in the below string.
$txt['username'] = 'Käyttäjänimi';
$txt['password'] = 'Salasana';

$txt['username_no_exist'] = 'Tunnusta ei ole olemassa';
$txt['no_user_with_email'] = 'Tätä sähköpostiosoitetta ei ole yhdelläkään käyttäjällä.';

$txt['board_moderator'] = 'Aluevalvoja';
$txt['remove_topic'] = 'Poista';
$txt['topics'] = 'Aiheet';
$txt['modify_msg'] = 'Muokkaa viestiä';
$txt['name'] = 'Nimi';
$txt['email'] = 'Sähköposti';
$txt['user_email_address'] = 'Sähköpostiosoite';
$txt['subject'] = 'Aihe';
$txt['message'] = 'Viesti';
$txt['redirects'] = 'Ohjauksia';

$txt['choose_pass'] = 'Valitse salasana';
$txt['verify_pass'] = 'Vahvista salasana';
$txt['position'] = 'Asema';
$txt['notify_announcements'] = 'Sign up to receive important site news by email';

$txt['profile_of'] = 'Tarkastele profiilia käyttäjältä';
$txt['total'] = 'Yhteensä';
$txt['posts_made'] = 'Viestit';
$txt['topics_made'] = 'Aiheet';
$txt['website'] = 'Kotisivu';
$txt['contact'] = 'Contact Us';
$txt['warning_status'] = 'Varoitus';
$txt['user_warn_watch'] = 'Käyttäjä on tarkkailulistalla';
$txt['user_warn_moderate'] = 'Käyttäjän viestit lisätään hyväksymis jonoon';
$txt['user_warn_mute'] = 'Käyttäjältä on estetty viestien kirjoitus';
$txt['warn_watch'] = 'Tarkkailussa';
$txt['warn_moderate'] = 'Moderoitu';
$txt['warn_mute'] = 'Hiljennetty';
$txt['warning_issue'] = 'Warn';

$txt['message_index'] = 'Viestien etusivu';
$txt['news'] = 'Uutiset';
$txt['page'] = 'Page';
$txt['prev'] = 'previous';
$txt['next'] = 'next';

$txt['post'] = 'Lähetä';
$txt['error_occurred'] = 'An Error Has Occurred';
$txt['send_error_occurred'] = 'An error has occurred, <a href="{href}">please click here to try again</a>.';
$txt['require_field'] = 'This is a required field.';
$txt['started_by'] = 'Started by author';
$txt['topic_started_by'] = 'Started by %1$s';
$txt['topic_started_by_in'] = 'Started by %1$s in %2$s';
$txt['replies'] = 'Vastaukset';
$txt['last_post'] = 'Uusin viesti';
$txt['first_post'] = 'First post';
$txt['last_poster'] = 'Last post author';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s </span><span class="board_lastposter">by %1$s</span><span class="board_lasttime"><strong>Last post: </strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s Posts in %2$s Topics by %3$s Members';
$txt['show'] = 'Show';
$txt['hide'] = 'Hide';
$txt['sort_by'] = 'Sort By';
$txt['sort_asc'] = 'Sort ascending';
$txt['sort_desc'] = 'Sort descending';

$txt['admin_login'] = 'Administration Log in';
// Use numeric entities in the below string.
$txt['topic'] = 'Aihe';
$txt['help'] = 'Ohjeet';
$txt['notify'] = 'Muistutus';
$txt['unnotify'] = 'Peruuta muistutus ';
$txt['notify_request'] = 'Haluatko ilmoitukseen sähköpostiin jos joku vastaa tähän aiheeseen?';
// Use numeric entities in the below string.
$txt['regards_team'] = "Regards,\nThe {forum_name_html_unsafe} Team.";
$txt['notify_replies'] = 'Ilmoita vastauksista';
$txt['move_topic'] = 'Siirrä';
$txt['move_to'] = 'Siirrä';
$txt['pages'] = 'Sivuja';
$txt['users_active'] = 'Active in past %1$d minutes';
$txt['personal_messages'] = 'Yksityisviestit';
$txt['reply_quote'] = 'Vastaa lainaten';
$txt['reply'] = 'Vastaa';
$txt['reply_number'] = 'Reply #%1$s';
$txt['approve'] = 'Hyväksy';
$txt['unapprove'] = 'Unapprove';
$txt['approve_all'] = 'hyväksy kaikki';
$txt['awaiting_approval'] = 'Odottaa hyväksyntää';
$txt['attach_awaiting_approve'] = 'Liitetiedostot hyväksyntää odottamassa';
$txt['post_awaiting_approval'] = 'Huomaa: Tämä viesti odottaa valvojan hyväksyntää';
$txt['there_are_unapproved_topics'] = 'There are %1$s topics and %2$s posts awaiting approval in this board. <a href="%3$s">Click here to view them</a>.';
$txt['send_message'] = 'Lähetä viesti';

$txt['msg_alert_no_messages'] = 'you don\'t have any message';
$txt['msg_alert_one_message'] = 'you have <a href="%1$s">1 message</a>';
$txt['msg_alert_many_message'] = 'you have <a href="%1$s">%2$d messages</a>';
$txt['msg_alert_one_new'] = '1 is new';
$txt['msg_alert_many_new'] = '%1$d are new';
$txt['remove_message'] = 'Poista viesti';

$txt['topic_alert_none'] = 'Ei viestejä...';
$txt['pm_alert_none'] = 'Ei viestejä...';

$txt['online_users'] = 'Tällä hetkellä käyttäjiä paikalla'; //Deprecated
$txt['online_now'] = 'Online Now';
$txt['personal_message'] = 'Yksityisviestit';
$txt['jump_to'] = 'Siirry';
$txt['go'] = 'Mene';
$txt['are_sure_remove_topic'] = 'Oletko varma että haluat poistaa tämän aiheen?';
$txt['yes'] = 'Kyllä';
$txt['no'] = 'Ei';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'ap';

$txt['search'] = 'Haku';
$txt['all'] = 'Kaikki';
$txt['search_entireforum'] = 'Entire Forum';
$txt['search_thisbrd'] = 'This board';
$txt['search_thistopic'] = 'This topic';
$txt['search_members'] = 'Jäsenet';

$txt['back'] = 'Takaisin';
$txt['continue'] = 'Eteenpäin';
$txt['password_reminder'] = 'Salasanan palautus';
$txt['topic_started'] = 'Aiheen aloitti';
$txt['title'] = 'Otsikko';
$txt['post_by'] = 'Kirjoitti';
$txt['welcome_newest_member'] = 'Please welcome %1$s, our newest member.';
$txt['admin_center'] = 'Ylläpitokeskus';
$txt['admin_session_active'] = 'You have an active admin session in place. We recommend to <strong><a class="strong" href="%1$s">end this session</a></strong> once you have finished your administrative tasks.';
$txt['admin_maintenance_active'] = 'Your forum is currently in maintenance mode, only admins can log in.  Remember to <strong><a class="strong" href="%1$s">exit maintenance</a></strong> once you have finished your administrative tasks.';
$txt['query_command_denied'] = 'The following MySQL errors are occurring, please verify your setup:';
$txt['query_command_denied_guests'] = 'It seems something has gone sour on the forum with the database. This problem should only be temporary, so please come back later and try again.  If you continue to see this message, please report the following message to the administrator:';
$txt['query_command_denied_guests_msg'] = 'the command %1$s is denied on the database';
$txt['last_edit_by'] = '<span class="lastedit">Last Edit</span>: %1$s by %2$s';
$txt['notify_deactivate'] = 'Haluatko perua muistutukset tästä aiheesta?';

$txt['date_registered'] = 'Rekisteröitynyt';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'View all recent posts.';
$txt['is_recent_updated'] = '%1$s is the most recently updated topic';

$txt['male'] = 'Mies';
$txt['female'] = 'Nainen';

$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Hei,';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Tervetuloa,';
$txt['select_destination'] = 'Ole hyvä ja valitse kohde';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Kirjoittanut';

$txt['icon_smiley'] = 'Hymyilee';
$txt['icon_angry'] = 'Vihainen';
$txt['icon_cheesy'] = 'Leveä hymy';
$txt['icon_laugh'] = 'Nauru';
$txt['icon_sad'] = 'Surullinen';
$txt['icon_wink'] = 'Iskee silmä';
$txt['icon_grin'] = 'Virnistää';
$txt['icon_shocked'] = 'Järkyttynyt';
$txt['icon_cool'] = 'Cool';
$txt['icon_huh'] = 'Huh';
$txt['icon_rolleyes'] = 'Pyörittää silmiään';
$txt['icon_tongue'] = 'Näyttää kieltä';
$txt['icon_embarrassed'] = 'Nolostunut';
$txt['icon_lips'] = 'Vaikenee';
$txt['icon_undecided'] = 'Miettii';
$txt['icon_kiss'] = 'Pusu';
$txt['icon_cry'] = 'Itkee';
$txt['icon_angel'] = 'Innocent';

$txt['moderator'] = 'Aluevalvoja';
$txt['moderators'] = 'Valvojat';

$txt['views'] = 'Lukukerrat';
$txt['new'] = 'Uusi';
$txt['no_redir'] = 'Redirected from %1$s';

$txt['view_all_members'] = 'Tarkastele kaikkia käyttäjiä';
$txt['view'] = 'Katso tarkemmin';

$txt['viewing_members'] = 'Tarkastellaan jäseniä %1$s - %2$s';
$txt['of_total_members'] = 'jäseniä yhteensä %1$s';

$txt['forgot_your_password'] = 'Unohtuiko salasana?';

$txt['date'] = 'Päivä';
// Use numeric entities in the below string.
$txt['from'] = 'L&#228;hett&#228;j&#228;';
$txt['to'] = 'Käyttäjälle';

$txt['board_topics'] = 'Aiheet';
$txt['members_title'] = 'Jäsenet';
$txt['members_list'] = 'Jäsenlista';
$txt['new_posts'] = 'Uusia viestejä';
$txt['old_posts'] = 'Ei uusia viestejä';
$txt['redirect_board'] = 'Uudelleenohjaava alue';
$txt['redirect_board_to'] = 'Redirecting to %1$s';

$txt['sendtopic_send'] = 'Lähetä';
$txt['report_sent'] = 'Ilmoituksesi on tallennettu.';
$txt['topic_sent'] = 'Your email has been sent successfully.';

$txt['time_offset'] = 'Aikaeron asetus';
$txt['or'] = 'tai';

$txt['mention'] = 'Muistutukset ja sähköposti';
$txt['notifications'] = 'Muistutukset ja sähköposti';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = '%1$s, sinulla on porttikielto tälle keskustelualueelle!';
$txt['your_ban_expires'] = 'Porttikieltosi on asettettu päättymään %1$s.';
$txt['your_ban_expires_never'] = 'Porttikiellollesi ei ole määritetty päättymishetkeä.';
$txt['ban_continue_browse'] = 'Voit silti lukea keskustelualuetta vieraana.';

$txt['mark_as_read'] = 'Merkitse KAIKKI viestit luetuiksi';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'Mark THESE messages as read';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'Lukittu aihe';
$txt['normal_topic'] = 'Tavallinen aihe';
$txt['participation_caption'] = 'Aihe, johon olet osallistunut';

$txt['print'] = 'Tulostusversio';
$txt['topic_summary'] = 'Yhteenveto';
$txt['not_applicable'] = 'ei asetettu';
$txt['name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['total_members'] = 'Jäseniä yhteensä';
$txt['total_posts'] = 'Viestejä yhteensä';
$txt['total_topics'] = 'Aiheita yhteensä';

$txt['mins_logged_in'] = 'Istunnon pituus minuutteina';

$txt['preview'] = 'Esikatsele';
$txt['always_logged_in'] = 'Pysy aina kirjautuneena sisälle';

$txt['logged'] = 'Kirjattu';
// Use numeric entities in the below string.
$txt['ip'] = 'IP';

$txt['www'] = 'WWW';
$txt['link'] = 'Link';

$txt['by'] = 'kirjoittanut'; //Deprecated

$txt['hours'] = 'tuntia';
$txt['minutes'] = 'minuuttia';
$txt['seconds'] = 'sek';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'Tunti';
$txt['days_word'] = 'päiviä';

$txt['newest_member'] = ', uusin jäsenemme.'; //Deprecated

$txt['search_for'] = 'Etsi seuraavaa';
$txt['search_match'] = 'Match';

$txt['maintain_mode_on'] = 'Muista, keskustelualue on \'Huoltotilassa\'.';

$txt['read'] = 'Luettu'; //Deprecated
$txt['times'] = 'kertaa'; //Deprecated
$txt['read_one_time'] = 'Read 1 time';
$txt['read_many_times'] = 'Read %1$d times';

$txt['forum_stats'] = 'Keskustelualueen tilastoja';
$txt['latest_member'] = 'Uusin jäsen';
$txt['total_cats'] = 'Kategorioita yhteensä';
$txt['latest_post'] = 'Uusin viesti';

$txt['here'] = 'tästä';
$txt['you_have_no_msg'] = 'You don\'t have any message...';
$txt['you_have_one_msg'] = 'You\'ve 1 message...<a href="%1$s">Click here to view it</a>';
$txt['you_have_many_msgs'] = 'You\'ve %2$d messages...<a href="%1$s">Click here to view them</a>';

$txt['total_boards'] = 'Alueita yhteensä';

$txt['print_page'] = 'Tulosta sivu';
$txt['print_page_text'] = 'Text only';
$txt['print_page_images'] = 'Text with Images';

$txt['valid_email'] = 'Tämän on oltava toimiva osoite.';

$txt['info_center_title'] = '%1$s - Informaatiokeskus';

$txt['send_topic'] = 'Share';
$txt['unwatch'] = 'Unwatch';
$txt['watch'] = 'Watch';

$txt['sendtopic_title'] = 'Lähetä aihe &quot;%1$s&quot; ystävälle.';
$txt['sendtopic_sender_name'] = 'Sinun nimesi';
$txt['sendtopic_sender_email'] = 'Sähköpostiosoitteesi';
$txt['sendtopic_receiver_name'] = 'Vastaanottajan nimi';
$txt['sendtopic_receiver_email'] = 'Vastaanottajan sähköpostiosoite';
$txt['sendtopic_comment'] = 'Lisää kommentti';

$txt['allow_user_email'] = 'Salli muiden käyttäjien lähettää sinulle sähköpostia';

$txt['check_all'] = 'Valitse kaikki';

// Use numeric entities in the below string.
$txt['database_error'] = 'Tietokantavirhe';
$txt['try_again'] = 'Ole hyvä ja yritä uudelleen. Jos tämä virheilmoitus näkyy vielä uudestaan, ilmoita siitä ylläpidolle.';
$txt['file'] = 'tiedosto';
$txt['line'] = 'Rivi';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'ElkArte has detected and automatically tried to repair an error in your database.  If you continue to have problems, or continue to receive these emails, please contact your host.';
$txt['database_error_versions'] = '<strong>Note:</strong> Your database version is %1$s.';
$txt['template_parse_error'] = 'Teeman jäsennysvirhe!';
$txt['template_parse_error_message'] = 'Näyttää että jokin on pielessä keskustelualueen teematiedostoissa. Tämän pitäisi olla väliaikaista, yritä hetken kuluttua uudelleen. Jos ongelma jatkuu, ota yhteyttä keskustelualueen ylläpitoon.<br /><br />Voit myös yrttää <a href="javascript:location.reload();">päivittää tämän sivun</a>.';
$txt['template_parse_error_details'] = 'There was a problem loading the <span class="tt"><strong>%1$s</strong></span> template or language file.  Please check the syntax and try again - remember, single quotes (<span class="tt">\'</span>) often have to be escaped with a backslash (<span class="tt">\\</span>).  To see more specific error information from PHP, try <a href="%2$s%1$s">accessing the file directly</a>.<br /><br />You may want to try to <a href="javascript:location.reload();">refresh this page</a> or <a href="%3$s">use the default theme</a>.';
$txt['template_parse_undefined'] = 'An undefined error occurred during the parsing of this template';

$txt['today'] = 'Today at %1$s';
$txt['yesterday'] = 'Yesterday at %1$s';

// Relative times
$txt['rt_now'] = 'just now';
$txt['rt_minute'] = 'A minute ago';
$txt['rt_minutes'] = '%s minutes ago';
$txt['rt_hour'] = 'An hour ago';
$txt['rt_hours'] = '%s hours ago';
$txt['rt_day'] = 'A day ago';
$txt['rt_days'] = '%s days ago';
$txt['rt_week'] = 'A week ago';
$txt['rt_weeks'] = '%s weeks ago';
$txt['rt_month'] = 'A month ago';
$txt['rt_months'] = '%s months ago';
$txt['rt_year'] = 'A year ago';
$txt['rt_years'] = '%s years ago';

$txt['new_poll'] = 'Uusi äänestys';
$txt['poll_question'] = 'Kysymys';
$txt['poll_question_options'] = 'Question and Options';
$txt['poll_vote'] = 'Äänestä';
$txt['poll_total_voters'] = 'Äänestäjiä yhteensä';
$txt['draft_saved_on'] = 'Draft last saved';
$txt['poll_results'] = 'Katsele tuloksia.';
$txt['poll_lock'] = 'Lukitse äänestys';
$txt['poll_unlock'] = 'Avaa äänestys';
$txt['poll_edit'] = 'Muokkaa äänestystä';
$txt['poll'] = 'Äänestys';
$txt['one_day'] = '1 päivä';
$txt['one_week'] = '1 viikko';
$txt['two_weeks'] = '2 Weeks';
$txt['one_month'] = '1 kuukausi';
$txt['two_months'] = '2 Months';
$txt['forever'] = 'Ikuisesti';
$txt['quick_login_dec'] = 'Kirjautuaksesi anna tunnus, salasana ja istuntosi pituus';
$txt['one_hour'] = '1 tunti';
$txt['moved'] = 'SIIRRETTY';
$txt['moved_why'] = 'Anna lyhyt selitys siitä,<br />miksi tämä aihe on siirretty.';
$txt['board'] = 'Alue';
$txt['in'] = 'fi';
$txt['sticky_topic'] = 'Pinned Topic';
$txt['split'] = 'SPLIT';

$txt['delete'] = 'Poista';

$txt['byte'] = 't';
$txt['kilobyte'] = 'kt';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[Lisää tilastoja]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Koodi';
$txt['code_select'] = '[Valitse]';
$txt['quote_from'] = 'Lainaus k&#228;ytt&#228;j&#228;lt&#228;';
$txt['quote'] = 'Lainaus';
$txt['quote_new'] = 'New topic';
$txt['follow_ups'] = 'Follow-ups';
$txt['topic_derived_from'] = 'Topic derived from %1$s';
$txt['edit'] = 'Muokkaa';
$txt['quick_edit'] = 'Quick Edit';
$txt['post_options'] = 'More...';

$txt['set_sticky'] = 'Pin';
$txt['set_nonsticky'] = 'Unpin';
$txt['set_lock'] = 'Lukitse';
$txt['set_unlock'] = 'Avaa';

$txt['search_advanced'] = 'Show advanced options';
$txt['search_simple'] = 'Hide advanced options';

$txt['security_risk'] = 'HUOMATTAVA TIETOTURVARISKI!:';
$txt['not_removed'] = 'You have not removed %1$s';
$txt['not_removed_extra'] = '%1$s is a backup of %2$s that was not generated by ElkArte. It can be accessed directly and used to gain unauthorised access to your forum. You should delete it immediately.';
$txt['generic_warning'] = 'Warning';
$txt['agreement_missing'] = 'You are requiring new users to accept a registration agreement, however the file (agreement.txt) doesn\'t exist.';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'You have just updated!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Click here to see what\'s new in this version of ElkArte!</a>!';

$txt['cache_writable'] = 'Tiedostovälimuistin käyttämä hakemisto ei ole kirjoitettavissa - tämä vaikuttanee haitallisesti keskustelualueesi suorityskykyyn.';

$txt['page_created_full'] = 'Page created in %1$.3f seconds with %2$d queries.';

$txt['report_to_mod_func'] = 'Käytä tätä toimintoa raportoidaksesi valvojille ja ylläpitäjille herjaavista, sääntöjen vastaisista tai muuten väärille raiteille joutuneista viesteistä.<br /><em>Huomioi myös että valvojat näkevät sähköpostiosoitteesi jos käytät tätä toimintoa.</em>';

$txt['online'] = 'Paikalla';
$txt['member_is_online'] = '%1$s is online';
$txt['offline'] = 'Poissa';
$txt['member_is_offline'] = '%1$s is offline';
$txt['pm_online'] = 'Yksityisviesti (paikalla)';
$txt['pm_offline'] = 'Yksityisviesti (poissa)';
$txt['status'] = 'Tila';

$txt['skip_nav'] = 'Skip to main content';
$txt['go_up'] = 'Siirry ylös';
$txt['go_down'] = 'Siirry alas';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Syntymäpäivät:';
$txt['events'] = 'Tapahtumat:';
$txt['birthdays_upcoming'] = 'Tulevia syntymäpäiviä:';
$txt['events_upcoming'] = 'Tulevia tapahtumia:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Holidays:';
$txt['calendar_month'] = 'Kuukausi:';
$txt['calendar_year'] = 'Vuosi:';
$txt['calendar_day'] = 'Päivä:';
$txt['calendar_event_title'] = 'Tapahtuman Otsikko';
$txt['calendar_event_options'] = 'Tapahtuma-asetukset';
$txt['calendar_post_in'] = 'Lähetä alueelle:';
$txt['calendar_edit'] = 'Muokkaa tapahtumaa';
$txt['event_delete_confirm'] = 'Poista tämä tapahtuma?';
$txt['event_delete'] = 'Poista tapahtuma';
$txt['calendar_post_event'] = 'Lähetä tapahtuma';
$txt['calendar'] = 'Kalenteri';
$txt['calendar_link'] = 'Linkitä kalenteriin';
$txt['calendar_upcoming'] = 'Kalenterissa tulossa';
$txt['calendar_today'] = 'Kalenterissa tänään';
$txt['calendar_week'] = 'Viikko';
$txt['calendar_week_title'] = 'Viikko %1$d / %2$d';
$txt['calendar_numb_days'] = 'Päivien lukumäärä:';
$txt['calendar_how_edit'] = 'Kuinka muokkaat näitä tapahtumia?';
$txt['calendar_link_event'] = 'Linkitä tapahtumaan';
$txt['calendar_confirm_delete'] = 'Oletko varma että haluat poistaa tapahtuman?';
$txt['calendar_linked_events'] = 'Kalenteriin linkitetyt tapahtumat';
$txt['calendar_click_all'] = 'näytä kaikki %1$s';

$txt['moveTopic1'] = 'Jätä kommentti siirrosta alkuperäiselle alueelle';
$txt['moveTopic2'] = 'Muuta aiheen otsikkoa';
$txt['moveTopic3'] = 'Uusi otsikko';
$txt['moveTopic4'] = 'Muuta kaikkien viestien otsikoita';
$txt['move_topic_unapproved_js'] = 'Varoitus! Tätä aihetta ei ole hyväksytty.\\n\\nEi ole suositeltavaa luoda siirretty-aihetta ellet suunnittele hyväksyväsi aihetta itse välittömästi siirron jälkeen.';
$txt['movetopic_auto_board'] = '[ALUE]';
$txt['movetopic_auto_topic'] = '[LINKKI AIHEESEEN]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Redirect to the moved topic';
$txt['movetopic_expires'] = 'Automatically remove the redirection topic';

$txt['merge_to_topic_id'] = 'Kohdeaiheen ID';
$txt['split_topic'] = 'Split';
$txt['merge'] = 'Merge';
$txt['subject_new_topic'] = 'Otsikko uudelle aiheelle';
$txt['split_this_post'] = 'Siirrä vain tämä viesti.';
$txt['split_after_and_this_post'] = 'Siirrä tämä viesti, ja kaikki tämän jälkeiset viestit.';
$txt['select_split_posts'] = 'Valitse siirrettävät viestit.';

$txt['splittopic_notification'] = 'Post a message when the topic is split';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Move the new topic to another board';

$txt['new_topic'] = 'Uusi aihe';
$txt['split_successful'] = 'Aiheen jakaminen kahdeksi onnistui.';
$txt['origin_topic'] = 'Alkuperäinen aihe';
$txt['please_select_split'] = 'Valitse mitkä viestit haluat jakaa.';
$txt['merge_successful'] = 'Aiheiden yhdistäminen onnistui.';
$txt['new_merged_topic'] = 'Vasta yhdistetty aihe';
$txt['topic_to_merge'] = 'Yhdistettävä aihe';
$txt['target_board'] = 'Kohdealue';
$txt['target_topic'] = 'Kohdeaihe';
$txt['merge_confirm'] = 'Oletko varma että haluat yhdistää';
$txt['with'] = 'kanssa';
$txt['merge_desc'] = 'Tämä toiminto yhdistää kahden aiheen viestit yhdeksi aiheeksi. Viestit järjestetään niiden lähetysaikojen mukaan. Täten ensimmäisenä lähetetty viesti tulee olemaan aiheen ensimmäinen viesti.';

$txt['theme_template_error'] = 'Teeman \'%1$s\' lataus ei onnistunut.';
$txt['theme_language_error'] = 'Kielitiedoston \'%1$s\' lataus ei onnistunut.';

$txt['parent_boards'] = 'Sub-boards';

$txt['smtp_no_connect'] = 'Ei saatu yhteyttä SMTP-palvelimeen';
$txt['smtp_port_ssl'] = 'SMTP portti on asetettu väärin; SSL palvelimille portin tulisi olla 465 ';
$txt['smtp_bad_response'] = 'Yhdistäminen sähköpostipalvelimeen epäonnistui.';
$txt['smtp_error'] = 'Ongelmia lähetettäessä postia. Virhe: ';
$txt['mail_send_unable'] = 'Viestiä ei voitu lähettää osoitteeseen \'%1$s\'';

$txt['mlist_search'] = 'Etsi käyttäjistä';
$txt['mlist_search_again'] = 'Etsi uudestaan'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Etsi sähköpostiosoitteista';
$txt['mlist_search_group'] = 'Etsi ryhmän perusteella';
$txt['mlist_search_name'] = 'Etsi nimen perusteella';
$txt['mlist_search_website'] = 'Etsi kotisivun perusteella';
$txt['mlist_search_results'] = 'Haun tulos hakusanalle';
$txt['mlist_search_by'] = 'Etsitään %1$s mukaan';

$txt['attach_downloaded'] = 'downloaded %1$d times';
$txt['attach_viewed'] = 'viewed %1$d times';

$txt['settings'] = 'Asetukset';
$txt['never'] = 'Ei koskaan';
$txt['more'] = 'lisää';

$txt['hostname'] = 'Host';
$txt['you_are_post_banned'] = '%1$s, olet kirjoituskiellossa tällä keskustelualueella, joten et voi lähettää viestejä.';
$txt['ban_reason'] = 'Syy';

$txt['add_poll'] = 'Lisää äänestys';
$txt['poll_options6'] = 'Voit valita %1$s vaihtoehtoa.';
$txt['poll_remove'] = 'Poista äänestys';
$txt['poll_remove_warn'] = 'Oletko varma että haluat poistaa äänestyksen aiheesta?';
$txt['poll_results_expire'] = 'Tulokset näkyvät kun äänestys on päättynyt';
$txt['poll_expires_on'] = 'Äänestys päättyy';
$txt['poll_expired_on'] = 'Äänestys päättynyt';
$txt['poll_change_vote'] = 'Poista oma ääni';
$txt['poll_return_vote'] = 'Äänestysvaihtoehdot';
$txt['poll_cannot_see'] = 'Et voit katsella tuloksia tällä hetkellä.';

$txt['quick_mod_approve'] = 'Hyväksy valitut';
$txt['quick_mod_remove'] = 'Poista valitut';
$txt['quick_mod_lock'] = 'Lukitse/avaa valitut';
$txt['quick_mod_sticky'] = 'Pin/Unpin selected';
$txt['quick_mod_move'] = 'Siirrä valitut';
$txt['quick_mod_merge'] = 'Yhdistä valitut';
$txt['quick_mod_markread'] = 'Merkitse valitut luetuiksi';
$txt['quick_mod_go'] = 'Mene';
$txt['quickmod_confirm'] = 'Haluatko varmasti tehdä tämän?';

$txt['spell_check'] = 'Oikoluku';

$txt['quick_reply'] = 'Pikavastaus';
$txt['quick_reply_warning'] = 'Warning! This topic is currently locked, only admins and moderators can reply.';
$txt['quick_reply_verification'] = 'Viestin lähetyksen jälkeen, sinut ohjataan tavalliselle sivulle varmistaaksesi viestin %1$s.';
$txt['quick_reply_verification_guests'] = '(vaaditaan vieralijoilta)';
$txt['quick_reply_verification_posts'] = '(vaaditaan kättäjiltä jolla alle %1$d viestiä) ';
$txt['wait_for_approval'] = 'Huomioi: tämä viesti näytetään vasta kun valvoja on sen hyväksynyt.';

$txt['notification_enable_board'] = 'Oletko varma että haluat muistutuksen uusista aiheista tällä keskustelualueella?';
$txt['notification_disable_board'] = 'Oletko varma että haluat perua muistutuksen uusista aiheista tällä keskustelualueella?';
$txt['notification_enable_topic'] = 'Oletko varma että haluat muistutuksen uusista vastauksista tähän aiheeseen?';
$txt['notification_disable_topic'] = 'Oletko varma että haluat perua muistutuksen uusista vastauksista tähän aiheeseen?';

$txt['report_to_mod'] = 'Report Post';
$txt['issue_warning_post'] = 'Anna varoitus tästä viestistä';

$txt['like_post'] = 'Like';
$txt['unlike_post'] = 'Unlike';
$txt['likes'] = 'Likes';
$txt['liked_by'] = 'Liked by:';
$txt['liked_you'] = 'You';
$txt['liked_more'] = 'lisää';
$txt['likemsg_are_you_sure'] = 'You already liked this message, are you sure you want to remove your like?';

$txt['unread_topics_visit'] = 'Viimeisimmät lukemattomat aiheet';
$txt['unread_topics_visit_none'] = 'No unread topics found since your last visit. <a href="{unread_all_url}" class="linkbutton">Click here to try all unread topics</a>';
$txt['unread_topics_all'] = 'Kaikki lukemattomat aiheet';
$txt['unread_replies'] = 'Päivittyneet aiheet';

$txt['who_title'] = 'Mitä keskustelualueella tapahtuu?';
$txt['who_and'] = ' ja ';
$txt['who_viewing_topic'] = ' katselee tätä aihetta.';
$txt['who_viewing_board'] = ' katselee tätä aluetta.';
$txt['who_member'] = 'Jäsen';

// Current footer strings
$txt['valid_html'] = 'Valid HTML 5';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'Vieras';
$txt['guests'] = 'Vieraat';
$txt['user'] = 'Käyttäjä';
$txt['users'] = 'Käyttäjiä';
$txt['hidden'] = 'Piilotettu';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'Piilotettu';
$txt['buddy'] = 'Kaveri';
$txt['buddies'] = 'Kaveria';
$txt['most_online_ever'] = 'Käyttäjiä enimmillään koskaan';
$txt['most_online_today'] = 'Käyttäjiä enimmillään tänään';

$txt['merge_select_target_board'] = 'Valitse kohdealue yhdistetylle aiheelle';
$txt['merge_select_poll'] = 'Valitse kumpi äänestys yhdistetyssä aiheessa on';
$txt['merge_topic_list'] = 'Valitse yhdistettävät aiheet';
$txt['merge_select_subject'] = 'Valitse otsikko yhdistetylle aiheelle';
$txt['merge_custom_subject'] = 'Muokattu otsikko';
$txt['merge_enforce_subject'] = 'Muuta kaikkien viestien otsikoita';
$txt['merge_include_notifications'] = 'Sisällytä muistutukset?';
$txt['merge_check'] = 'Yhdistä?';
$txt['merge_no_poll'] = 'Ei äänestystä';

$txt['response_prefix'] = 'Vs: ';
$txt['current_icon'] = 'Current icon';
$txt['message_icon'] = 'Otsikon ikoni';

$txt['smileys_current'] = 'Käytettävät hymiöt';
$txt['smileys_none'] = 'Ei hymiöitä';
$txt['smileys_forum_board_default'] = 'keskustelualueen/alueen oletus';

$txt['search_results'] = 'Haun tulokset';
$txt['search_no_results'] = 'Hakuehtoja vastaavia tuloksia ei löytynyt';

$txt['totalTimeLogged2'] = ' päivää, ';
$txt['totalTimeLogged3'] = ' tuntia ja ';
$txt['totalTimeLogged4'] = ' minuuttia.';
$txt['totalTimeLogged5'] = 'p ';
$txt['totalTimeLogged6'] = 't ';
$txt['totalTimeLogged7'] = 'm';

$txt['approve_thereis'] = 'Ylläpitoalueella on'; //Deprecated
$txt['approve_thereare'] = 'Ylläpitoalueella on'; //Deprecated
$txt['approve_member'] = 'yksi käyttäjä'; //Deprecated
$txt['approve_members'] = 'käyttäjää'; //Deprecated
$txt['approve_members_waiting'] = 'odottamassa hyväksyntää.'; //Deprecated
$txt['approve_one_member_waiting'] = 'There is <a href="%1$s">one member</a> awaiting approval.';
$txt['approve_many_members_waiting'] = 'There are <a href="%1$s">%2$d members</a> awaiting approval.';

$txt['notifyboard_turnon'] = 'Haluatko ilmoituksen sähköpostiisi kun joku aloittaa uuden aiheen tällä alueella?';
$txt['notifyboard_turnoff'] = 'Oletko varma ettet halua saada tiedotetta uusista aiheista tällä alueella?';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Etsi jäseniä';
$txt['find_username'] = 'Nimi, tunnus tai sähköpostiosoite';
$txt['find_buddies'] = 'Näytä vain kaverit?';
$txt['find_wildcards'] = 'Sallitut jokerimerkit: *, ?';
$txt['find_no_results'] = 'Hakuehtoja vastaavia tuloksia ei löytynyt';
$txt['find_results'] = 'Tulokset';
$txt['find_close'] = 'Sulje';

$txt['quickmod_delete_selected'] = 'Poista valitut';
$txt['quickmod_split_selected'] = 'Split Selected';

$txt['show_personal_messages_heading'] = 'New messages';
$txt['show_personal_messages'] = 'You have <strong>%1$s</strong> unread personal messages in your inbox.<br /><br /><a href="%2$s">Go to your inbox</a>';

$txt['help_popup'] = 'A little lost? Let me explain:';

$txt['previous_next_back'] = 'previous topic';
$txt['previous_next_forward'] = 'next topic';

$txt['upshrink_description'] = 'Kutista tai laajenna yläosa.';

$txt['mark_unread'] = 'Muuta lukemattomaksi';

$txt['ssi_not_direct'] = 'Älä kutsu SSI.php:tä suoraan; tahdot kenties käyttää (%1$s polkua tai lisätä ?ssi_function=jotain.';
$txt['ssi_session_broken'] = 'SSI.php ei saanut ladattua sessiota! Tämä voi aiheuttaa ongelmia uloskirjautumisessa ja muissa toiminnoissa - varmista että SSI.php on sisällytetty/linkitetty tiedostosi *ensimmäisellä* rivillä!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Esikatsele viesti';
$txt['preview_fetch'] = 'Ladataan esikatselua...';
$txt['pm_error_while_submitting'] = 'The following error or errors occurred while sending this personal message:';
$txt['warning_while_submitting'] = 'Something happened, review it here:';
$txt['error_while_submitting'] = 'The message has the following error or errors that must be corrected before continuing:';
$txt['error_old_topic'] = 'Varoitus: tähän aiheeseen ei ole vastattu yli %1$d päivään.<br />Jollet ole varma että haluat vastata juuri tähän, harkitse uuden aiheen aloittamista.';

$txt['split_selected_posts'] = 'Valitut viestit';
$txt['split_selected_posts_desc'] = 'Alla olevat viestit muodostavat uuden aiheen jakamisen lopuksi.';
$txt['split_reset_selection'] = 'tyhjennä valinnat';

$txt['modify_cancel'] = 'Peruuta';
$txt['mark_read_short'] = 'Merkitse luetuksi';

$txt['hello_member_ndt'] = 'Hei';

$txt['unapproved_posts'] = 'Hyväksymättömät viestit (aiheet: %1$d, viestit: %2$d)';

$txt['ajax_in_progress'] = 'Ladataan...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = '%1$d valvontaraporttia on avoinna.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'Click to see the new posts in %1$s';
$txt['verification'] = 'Varmistus';
$txt['visual_verification_hidden'] = 'Please leave this box empty';
$txt['visual_verification_description'] = 'Kirjoita kuvassa näkyvät kirjaimet';
$txt['visual_verification_sound'] = 'Kuuntele kirjaimet';
$txt['visual_verification_request_new'] = 'Pyydä uusi kuva';

// @todo Send email strings - should move?
$txt['send_email'] = 'Send email';
$txt['send_email_disclosed'] = 'Huomaa että tämä näkyy vastaanottajalle.';
$txt['send_email_subject'] = 'Aihe';

$txt['ignoring_user'] = 'Tämä käyttäjä on hylkäyslistallasi.';
$txt['show_ignore_user_post'] = '<em>[Show me the post.]</em>';

$txt['spider'] = 'Hakurobotti';
$txt['spiders'] = 'Hakurobottia';
$txt['openid'] = 'OpenID';

$txt['downloads'] = 'latausta';
$txt['filesize'] = 'File size';
$txt['subscribe_webslice'] = 'Tilaa Webslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Palauta aihe';
$txt['restore_message'] = 'Palauta';
$txt['quick_mod_restore'] = 'Palauta valitut';

// Editor prompt.
$txt['prompt_text_email'] = 'Anna sähköpostiosoite.';
$txt['prompt_text_ftp'] = 'Please enter the FTP address.';
$txt['prompt_text_url'] = 'Anna sen sivun URL johon haluat linkittää';
$txt['prompt_text_img'] = 'Anna kuvan sijainti';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Poista';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> has blocked %1$s access attempts in the last 7 days.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Teematiedostot';
$txt['debug_subtemplates'] = 'Sub templates: '; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Sub templates: ';
$txt['debug_language_files'] = 'Kielitiedostot';
$txt['debug_sheets'] = 'Tyylitiedostot';
$txt['debug_javascript'] = 'Scripts: ';
$txt['debug_files_included'] = 'Sisällytetyt tiedostot:';
$txt['debug_kb'] = 'KB. ';
$txt['debug_show'] = 'näytä';
$txt['debug_cache_hits'] = 'Osumat välimuistiin:';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s bytes';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss for %2$s bytes';
$txt['debug_queries_used'] = 'Kyselyjä: %1$d. ';
$txt['debug_queries_used_and_warnings'] = 'Kyselyjä: %1$d, %2$d varoitusta. ';
$txt['debug_query_in_line'] = 'in <em>%1$s</em> line <em>%2$s</em>, ';
$txt['debug_query_which_took'] = 'vei aikaa %1$s sekuntia';
$txt['debug_query_which_took_at'] = 'which took %1$s seconds at %2$s into request. ';
$txt['debug_show_queries'] = '[Näytä kyselyt]';
$txt['debug_hide_queries'] = '[Piilota kyselyt] ';
$txt['debug_tokens'] = 'Tokens: ';
$txt['debug_browser'] = 'Browser ID: ';
$txt['debug_hooks'] = 'Hooks called: ';
$txt['debug_system_type'] = 'System: ';
$txt['debug_server_load'] = 'Server Load: ';
$txt['debug_script_mem_load'] = 'Script Memory Usage: ';
$txt['debug_script_cpu_load'] = 'Script CPU Time (user/system): ';

// Video embedding
$txt['preview_image'] = 'Video Preview Image';
$txt['ctp_video'] = 'Click to play video, double click to load video';
$txt['hide_video'] = 'Show/Hide video';
$txt['youtube'] = 'YouTube video:';
$txt['vimeo'] = 'Vimeo video:';
$txt['dailymotion'] = 'Dailymotion video:';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (click to show/hide)';

$txt['ok_uppercase'] = 'OK';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Warning';

$txt['via'] = 'via';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
