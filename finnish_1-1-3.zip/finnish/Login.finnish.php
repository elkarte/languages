<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Rekisteröintisopimus';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'Hyväksyn rekisteröintisopimuksen ehdot.';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Hyväksyn rekisteröintisopimuksen ehdot. Olen vähintään %1$d vuotias.';
$txt['agreement_agree_coppa_below'] = 'Hyväksyn rekisteröintisopimuksen ehdot. Olen nuorempi kuin %1$d vuotta.';
$txt['agree_coppa_above'] = 'I am at least %1$d years old.';
$txt['agree_coppa_below'] = 'I am younger than %1$d years old.';

// Registration form.
$txt['registration_form'] = 'Rekisteröitymislomake';
$txt['error_too_quickly'] = 'You went through the registration process too quickly, faster than should normally be possible. Please wait a moment and try again.';
$txt['error_token_verification'] = 'Token verification failed. Please try again.';
$txt['need_username'] = 'Sinun täytyy antaa käyttäjätunnus.';
$txt['no_password'] = 'Salasana puuttuu';
$txt['improper_password'] = 'The supplied password is too long.';
$txt['incorrect_password'] = 'Salasana on väärä';
$txt['openid_not_found'] = 'Supplied OpenID identifier not found.';
$txt['maintain_mode'] = 'Huoltotila';
$txt['registration_successful'] = 'Rekisteröinti onnistui';
$txt['valid_email_needed'] = 'Ole hyvä ja valitse asianmukainen sähköpostiosoite, %1$s.';
$txt['required_info'] = 'Perustiedot';
$txt['additional_information'] = 'Lisätiedot';
$txt['warning'] = 'Huom!';
$txt['only_members_can_access'] = 'Vain rekisteröityneet jäsenet pääsevät tälle alueelle.';
$txt['login_below'] = 'Please login below.';
$txt['login_below_or_register'] = 'Please login below or <a href="%1$s">register an account</a> with %2$s';
$txt['checkbox_agreement'] = 'I accept the registration agreement';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Password security has recently been upgraded.<br />Please enter your password again.';

$txt['ban_register_prohibited'] = 'Pahoittelut, oikeutesi eivät riitä rekisteröitymiseen tälle keskustelualueelle.';
$txt['under_age_registration_prohibited'] = 'Olemme pahoillamme, mutta käyttäjät jotka ovat alle %1$d vuotiaita, eivät saa rekisteröityä tälle keskustelualueelle.';

$txt['activate_account'] = 'Jäsenyyden aktivointi';
$txt['activate_success'] = 'Jäsenyytesi on vahvistettu. Voit nyt kirjautua sisään.';
$txt['activate_not_completed1'] = 'Sinun on vahvistettava sähköpostiosoitteesi ennen kirjautumista.';
$txt['activate_not_completed2'] = 'Tarvitsetko toisen aktivointiviestin?';
$txt['activate_after_registration'] = 'Kiitos rekisteröitymisestäsi. Saat pian sähköpostia, jolla voit aktivoida jäsenyytesi. Jos viestiä ei ala kuulua, tarkista roskapostikansiosi.';
$txt['invalid_userid'] = 'Käyttäjää ei ole olemassa';
$txt['invalid_activation_code'] = 'Virheellinen aktivointikoodi';
$txt['invalid_activation_username'] = 'Käyttäjätunnus tai sähköposti';
$txt['invalid_activation_new'] = 'Jos olet rekisteröitynyt väärällä sähköpostiosoitteella, kirjoita uusi osoite ja salasanasi tähän.';
$txt['invalid_activation_new_email'] = 'Uusi sähköpostiosoite';
$txt['invalid_activation_password'] = 'Vanha salasana';
$txt['invalid_activation_resend'] = 'Lähetä aktivointikoodi uudestaan';
$txt['invalid_activation_known'] = 'Jos tiedät aktivointikoodisi, kirjoita se tähän.';
$txt['invalid_activation_retry'] = 'Aktivointikoodi';
$txt['invalid_activation_submit'] = 'Aktivoi';

$txt['coppa_no_concent'] = 'Ylläpito ei ole edelleenkään saanut huoltajasi suostumusta jäsenyyteesi.';
$txt['coppa_need_more_details'] = 'Tarvitsetko lisätietoja?';

$txt['awaiting_delete_account'] = 'Jäsenyytesi on merkitty poistettavaksi!<br />Jos haluat palauttaa jäsenyytesi, valitse &quot;Aktivoi jäsenyyteni uudelleen&quot; laatikko, ja kirjaudu uudelleen.';
$txt['undelete_account'] = 'Aktivoi jäsenyyteni uudelleen';

$txt['in_maintain_mode'] = 'Tämä keskustelualue on huoltotilassa.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Ole hyvä ja lue ja hyväksy sitoumus ennen rekisteröintiä';
$txt['register_passwords_differ_js'] = 'Syöttämäsi kaksi salasanaa eivät ole samoja!';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Kiitoksia rekisteröitymisestäsi. Ylläpidon pitää vielä hyväksyä hakemuksesi, saat siitä tiedotteen sähköpostiisi.';

$txt['admin_settings_desc'] = 'Täällä voit muokata uusien rekisteröintien asetuksia.';

$txt['setting_enableOpenID'] = 'Salli käyttäjien rekisteröityä OpenIDn avulla';

$txt['setting_registration_method'] = 'Uusien jäsenien rekisteröitymismetodi';
$txt['setting_registration_disabled'] = 'Rekisteröityminen estetty';
$txt['setting_registration_standard'] = 'Välitön rekisteröinti';
$txt['setting_registration_activate'] = 'Edellytä aktivointia';
$txt['setting_registration_approval'] = 'Edellytä ylläpidon hyväksyntää';
$txt['setting_notify_new_registration'] = 'Ilmoita ylläpitäjille kun uusi jäsen on rekisteröitynyt';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Lähetä tervetuliaisviesti uusille jäsenille';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Ikäräja uusille jäsenille';
$txt['setting_coppaAge_desc'] = '(0 poistaa käytöstä)';
$txt['setting_coppaType'] = 'Mitä tehdään jos ikäraja ei täyty';
$txt['setting_coppaType_reject'] = 'Hylkää rekisteröityminen';
$txt['setting_coppaType_approval'] = 'Edellytä kirjallista lupaa huoltajalta/vanhemmilta';
$txt['setting_coppaPost'] = 'Postiosoite johon vanhempien lupalappu lähetetään';
$txt['setting_coppaPost_desc'] = 'Käytössä vain jos lupaa edellytetään';
$txt['setting_coppaFax'] = 'Faxin numero johon huoltajan lupalappu voidaan lähettää';
$txt['setting_coppaPhone'] = 'Puhelinnumero josta huoltaja voi kysellä lisätietoja asiasta';

$txt['admin_register'] = 'Uuden jäsenen rekisteröinti';
$txt['admin_register_desc'] = 'Täällä voit rekisteröidä uusia jäseniä keskustelualueellesi, ja jos haluat, lähettää samalla tiedot heille itselleen sähköpostitse.';
$txt['admin_register_username'] = 'Uusi tunnus';
$txt['admin_register_email'] = 'Sähköpostiosoite';
$txt['admin_register_password'] = 'Salasana';
$txt['admin_register_username_desc'] = 'Käyttäjänimi uudelle jäsenelle';
$txt['admin_register_email_desc'] = 'Uuden jäsenen sähköpostiosoite<br />(tarvitaan jos lähetetät sähköpostia tunnuksesta)';
$txt['admin_register_password_desc'] = 'Salasana uudelle jäsenelle';
$txt['admin_register_email_detail'] = 'Lähetä salasana käyttäjän sähköpostiin';
$txt['admin_register_email_detail_desc'] = 'Sähköpostiosoite vaaditaan vaikka tätä ei valittaisi';
$txt['admin_register_email_activate'] = 'Edellytä aktivointia';
$txt['admin_register_group'] = 'Ensisijainen jäsenryhmä';
$txt['admin_register_group_desc'] = 'Ensisijainen jäsenryhmä mihin uusi jäsen kuuluu';
$txt['admin_register_group_none'] = '(ei ensisijaista jäsenryhmää)';
$txt['admin_register_done'] = 'Jäsen %1$s on rekisteröity onnistuneesti!';

$txt['coppa_title'] = 'Ikärajallinen keskustelualue';
$txt['coppa_after_registration'] = 'Thank you for registering with {forum_name_html_safe}.<br /><br />Because you fall under the age of {MINIMUM_AGE}, it is a legal requirement to obtain your parent or guardian\'s permission before you may begin to use your account.  To arrange for account activation please print off the form below:';
$txt['coppa_form_link_popup'] = 'Lataa lomake uuteen ikkunaan';
$txt['coppa_form_link_download'] = 'Tallenna tekstitiedostona';
$txt['coppa_send_to_one_option'] = 'Tämän jälkeen pyydä vanhempiasi lähettämään täytetty lomake:';
$txt['coppa_send_to_two_options'] = 'Tämän jälkeen pyydä vanhempiasi lähettämään täytetty lomake joko:';
$txt['coppa_send_by_post'] = 'Postitse, seuraavaan osoitteeseen:';
$txt['coppa_send_by_fax'] = 'Faxilla, seuraavaan numeroon:';
$txt['coppa_send_by_phone'] = 'Voit myös pyytää heitä soittamaan ylläpidolle numeroon {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Permission form for registration at {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Osoite';
$txt['coppa_form_date'] = 'Päivä';
$txt['coppa_form_body'] = 'I {PARENT_NAME},<br /><br />give permission for {CHILD_NAME} (child name) to become a fully registered member of the forum: {forum_name_html_safe}, with the username: {USER_NAME}.<br /><br />I understand that certain personal information entered by {USER_NAME} may be shown to other users of the forum.<br /><br />Signed:<br />{PARENT_NAME} (Parent/Guardian).';

$txt['visual_verification_sound_again'] = 'Soita uudelleen';
$txt['visual_verification_sound_close'] = 'Sulje ikkuna';
$txt['visual_verification_sound_direct'] = 'Onko ongelmia kuulla tämä? Kokeile suoraa linkkiä siihen.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Tunnus on vapaa';
$txt['registration_username_unavailable'] = 'Tunnun on varattu';
$txt['registration_username_check'] = 'Tarkista onko tunnus vapaana';
$txt['registration_password_short'] = 'Salasana on liian lyhyt';
$txt['registration_password_reserved'] = 'Salasana sisältää käyttäjätunnuksen tai sähköpostiosoitteen';
$txt['registration_password_numbercase'] = 'Salasanassa pitää olla sekä isojakirjaimia että numeroita';
$txt['registration_password_no_match'] = 'Salasanat ei täsmää';
$txt['registration_password_valid'] = 'Salasana on kelvollinen';

$txt['registration_errors_occurred'] = 'Seuraavat virheet huomattiin rekisteröinnissä. Ole hyvä ja korjaa ne jatkaaksesi:';

$txt['authenticate_label'] = 'Kirjautumistapa';
$txt['authenticate_password'] = 'Salasana';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'OpenID Kirjautumisosoite';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'Contact the admins';
$txt['contact_your_message'] = 'Your message';
$txt['errors_contact_form'] = 'The following errors occurred while processing your contact request';
$txt['contact_subject'] = 'A guest has sent you a message';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
