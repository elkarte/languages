<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Valvontakeskus';
$txt['mc_main'] = 'Aloitus';
$txt['mc_logs'] = 'Logit';
$txt['mc_posts'] = 'Viestit';
$txt['mc_groups'] = 'Members and groups';

$txt['mc_view_groups'] = 'Tarkastele ryhmiä';

$txt['mc_description'] = '<strong>Welcome, %1$s!</strong><br />This is your &quot;Moderation Center&quot;. From here you can perform all the moderation actions assigned to yourself by the Administrator. This home page contains a summary of all the latest happenings in your community. You can <a href="%2$s">personalize the layout by clicking here</a>.';
$txt['mc_group_requests'] = 'Jäsenryhmähakemukset';
$txt['mc_member_requests'] = 'Member Requests';
$txt['mc_unapproved_posts'] = 'Hyväksymättömät viestit';
$txt['mc_watched_users'] = 'Recently Watched Members';
$txt['mc_watched_topics'] = 'Tarkkaillut aiheet';
$txt['mc_scratch_board'] = 'Modemuistio';
$txt['mc_latest_news'] = 'Latest News';
$txt['mc_recent_reports'] = 'Viimeisimmät raportoidut aiheet';
$txt['mc_warnings'] = 'Varoitukset';
$txt['mc_notes'] = 'Valvojien muistiinpanot';
$txt['mc_required'] = 'Items Requiring Approval';
$txt['mc_attachments'] = 'Attachments needing approval';
$txt['mc_emailmod'] = 'Email Postings needing approval';
$txt['mc_topics'] = 'Topics needing approval';
$txt['mc_posts'] = 'Viestit';
$txt['mc_groupreq'] = 'Group requests needing approval';
$txt['mc_memberreq'] = 'Members needing approval';
$txt['mc_reports'] = 'Report posts needing approval';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['mc_recent_reports_none'] = 'Ei yhtään odottavaa raporttia';
$txt['mc_watched_users_none'] = 'Yhtään käyttäjää ei ole tarkkailussa.';
$txt['mc_group_requests_none'] = 'Ei yhtään avointa jäsenryhmähakemusta.';

$txt['mc_seen'] = '%1$s on viimeksi nähty %2$s';
$txt['mc_seen_never'] = '%1$s ei ole nähty koskaan.';
$txt['mc_groupr_by'] = 'kirjoittanut';

$txt['mc_reported_posts_desc'] = 'Täällä voit tarkastella kaikkia raportoituja viestejä.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Aktiiviset raportit';
$txt['mc_reportedp_closed'] = 'Vanhat raportit';
$txt['mc_reportedp_by'] = 'kirjoittanut';
$txt['mc_reportedp_reported_by'] = 'Raportoinut';
$txt['mc_reportedp_last_reported'] = 'Viimesin raportointi';
$txt['mc_reportedp_none_found'] = 'Ei raportteja';

$txt['mc_reportedp_details'] = 'Lisätiedot';
$txt['mc_reportedp_close'] = 'Sulje';
$txt['mc_reportedp_open'] = 'Aktiiviset raportit';
$txt['mc_reportedp_ignore'] = 'Dismiss';
$txt['mc_reportedp_unignore'] = 'Reopen';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Are you sure you wish to dismiss and ignore further reports about this message?

This will turn off further reports for all moderators of the forum.';
$txt['mc_reportedp_close_selected'] = 'Sulje valitut';

$txt['mc_groupr_group'] = 'Jäsenryhmät';
$txt['mc_groupr_member'] = 'Jäsen';
$txt['mc_groupr_reason'] = 'Syy';
$txt['mc_groupr_none_found'] = 'Ei avoimia jäsenryhmähakemuksia tällä hetkellä.';
$txt['mc_groupr_submit'] = 'Lähetä';
$txt['mc_groupr_reason_desc'] = 'Syy hylätä %1$s\'s:n pyyntö liittyä ryhmään &quot;%s&quot;';
$txt['mc_groups_reason_title'] = 'Reasons for rejection';
$txt['with_selected'] = 'With selected';
$txt['mc_groupr_approve'] = 'Approve request';
$txt['mc_groupr_reject'] = 'Reject request (No Reason)';
$txt['mc_groupr_reject_w_reason'] = 'Reject request with reason';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Haluatko varmasti tehdä tämän?';

$txt['mc_unapproved_attachments_none_found'] = 'Ei hyväksymättömiä liitteitä!';
$txt['mc_unapproved_attachments_desc'] = 'From here you can approve or delete any attachments awaiting moderation.';
$txt['mc_unapproved_replies_none_found'] = 'Ei hyväksymättömiä vastauksia!';
$txt['mc_unapproved_topics_none_found'] = 'Ei hyväksymättömiä aiheita!';
$txt['mc_unapproved_posts_desc'] = 'Täältä voit hyväksyä tai hylätä viestejä jotka ovat valvottuja';
$txt['mc_unapproved_replies'] = 'Vastaukset';
$txt['mc_unapproved_topics'] = 'Aiheet';
$txt['mc_unapproved_by'] = 'kirjoittanut';
$txt['mc_unapproved_sure'] = 'Haluatko varmasti tehdä tämän?';
$txt['mc_unapproved_attach_name'] = 'Attachment name';
$txt['mc_unapproved_attach_size'] = 'File size';
$txt['mc_unapproved_attach_poster'] = 'Kirjoittaja';
$txt['mc_viewmodreport'] = 'Moderation report for %1$s by %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Seuraavat jäsenet ovat raportoineet tästän viestistä';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Muiden valvojien toimenpiteet';
$txt['mc_modreport_mod_comments'] = 'Valvojien kommentit';
$txt['mc_modreport_no_mod_comment'] = 'Tällä hetkellä ei ole valvojien kommentteja';
$txt['mc_modreport_add_mod_comment'] = 'Lisää kommentti';

$txt['show_notice'] = 'Huomatusteksti';
$txt['show_notice_subject'] = 'Aihe';
$txt['show_notice_text'] = 'Teksti';

$txt['mc_watched_users_title'] = 'Tarkkailussa olevat käyttäjät';
$txt['mc_watched_users_desc'] = 'Täältä voit seurata valvojien tarkkailuun asettamia käyttäji&auml.';
$txt['mc_watched_users_post'] = 'Viestin mukaan';
$txt['mc_watched_users_warning'] = 'Varoitustaso';
$txt['mc_watched_users_last_login'] = 'Viimeksi paikalla';
$txt['mc_watched_users_last_post'] = 'Viimeisin viesti';
$txt['mc_watched_users_no_posts'] = 'Tarkkailluilta käyttäjiltä ei ole viestejä.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Haluatko varmasti poistaa tämän viestin?';
$txt['mc_watched_users_delete_posts'] = 'Haluatko varmasti poistaa nämä viestit?';
$txt['mc_watched_users_posted'] = 'Lisätty';
$txt['mc_watched_users_member'] = 'Jäsen';

$txt['mc_warnings_description'] = 'Täältä näet käyttäjille jaetut varoitukset. Voit myös lisätä ja muokata käyttäjille lähetettäviä varoituspohjia.';
$txt['mc_warning_log'] = 'Varoituslogi';
$txt['mc_warning_templates'] = 'Varoituspohjat';
$txt['mc_warning_log_title'] = 'Viewing warning log';
$txt['mc_warning_templates_title'] = 'Custom warning templates';

$txt['mc_warnings_none'] = 'No warnings have been issued.';
$txt['mc_warnings_recipient'] = 'Vastaanottaja';

$txt['mc_warning_templates_none'] = 'Varoituspohjia ei ole vielä luotu';
$txt['mc_warning_templates_time'] = 'Luotu';
$txt['mc_warning_templates_name'] = 'Pohja';
$txt['mc_warning_templates_creator'] = 'Tekijä';
$txt['mc_warning_template_add'] = 'Uusi pohja';
$txt['mc_warning_template_modify'] = 'Muokkaa pohjaa';
$txt['mc_warning_template_delete'] = 'Poista valitut';
$txt['mc_warning_template_delete_confirm'] = 'Haluatko varmasti poistaa valitut pohjat?';

$txt['mc_warning_template_desc'] = 'Use this page to fill in the details of the template. Note that the subject for the email is not part of the template. Note that as the notification is sent by PM you can use BBC within the template. If you use the {MESSAGE} variable then this template will not be available when issuing a generic warning (i.e. A warning not linked to a post).';
$txt['mc_warning_template_title'] = 'Pohjan nimi';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Henkilökohtainen pohja';
$txt['mc_warning_template_personal_desc'] = 'Jos valitset tämän, vain sinä voit nähdä, muokata ja käyttää tätä pohjaa. Muuten pohja on kaikkien valvojien käytössä.';
$txt['mc_warning_template_error_no_title'] = 'You must set the title.';
$txt['mc_warning_template_error_no_body'] = 'You must set the notification body.';

$txt['mc_settings'] = 'Muuta asetuksia';
$txt['mc_prefs_title'] = 'Valvonnan asetukset';
$txt['mc_prefs_desc'] = 'Tämä osio antaa sinulle mahdollisuuden muokata joitakin henkilökohtaisia asetuksia kuten muistutuksien lähetystä.';
$txt['mc_prefs_homepage'] = 'Etusivulla näytettävät kohdat';
$txt['mc_prefs_latest_news'] = 'ElkArte News';
$txt['mc_prefs_show_reports'] = 'Näytä avointen raporttien määrä yläpalkissa';
$txt['mc_prefs_notify_report'] = 'Lähetä muistutus raportoiduista aiheista';
$txt['mc_prefs_notify_report_never'] = 'Ei koskaan';
$txt['mc_prefs_notify_report_moderator'] = 'Vain jos se on valvomallani alueella';
$txt['mc_prefs_notify_report_always'] = 'Aina';
$txt['mc_prefs_notify_approval'] = 'Lähetä muistutus hyväksymistä odottavista';
$txt['mc_logoff'] = 'End Moderator Session';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Lisää uusi muistiinpano';
$txt['mc_add_note'] = 'Lisää';