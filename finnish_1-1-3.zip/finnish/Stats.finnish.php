<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Eniten paikalla';

$txt['stats_center'] = 'Tilastot';
$txt['general_stats'] = 'Yleiset tilastot';
$txt['top_posters'] = 'Kirjoittajien Top 10';
$txt['top_boards'] = 'Alueiden Top 10';
$txt['forum_history'] = 'Keskustelualueen historia';
$txt['stats_new_topics'] = 'Uusia aiheita';
$txt['stats_new_posts'] = 'Uusia viestejä';
$txt['stats_new_members'] = 'Uusia jäseniä';
$txt['page_views'] = 'Osumat';
$txt['top_topics_replies'] = 'Top 10 -aiheet (vastausten perusteella)';
$txt['top_topics_views'] = 'Top 10 -aiheet (katselujen perusteella)';
$txt['yearly_summary'] = 'Vuosittainen yhteenveto';
$txt['top_starters'] = 'Eniten uusien aiheiden aloituksia';
$txt['most_time_online'] = 'Pisimpään keskustelualueella sisällä ';

$txt['average_members'] = 'Keskimäärin uusia jäseniä päivässä';
$txt['average_posts'] = 'Keskimäärin uusia viestejä päivässä';
$txt['average_topics'] = 'Keskimäärin uusia aiheita päivässä';
$txt['average_online'] = 'Keskimäärin käyttäjiä paikalla';
$txt['users_online'] = 'Tällä hetkellä käyttäjiä paikalla';
$txt['emails_sent'] = 'Average Emails per day';
$txt['users_online_today'] = 'Tämän päivän kävijäennätys';
$txt['num_hits'] = 'Katseltuja sivuja yhteensä';
$txt['average_hits'] = 'Katseltuja sivuja keskimäärin päivässä';

$txt['ssi_comment'] = 'kommentti';
$txt['ssi_comments'] = 'kommenttia';
$txt['ssi_write_comment'] = 'Kirjoita kommentti';
$txt['ssi_no_guests'] = 'Et voi valita aluetta jolle vieraat ei pääse. Ole hyvä ja tarkasta alue ennenkuin yrität uudelleen.';
$txt['xml_rss_desc'] = 'Live information from {forum_name}';