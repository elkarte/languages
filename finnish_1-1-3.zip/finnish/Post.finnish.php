<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Vastaa';
$txt['post_in_board'] = 'Post in the board';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Lisää lainaus';
$txt['disable_smileys'] = 'Disable smileys';
$txt['dont_use_smileys'] = 'Älä käytä kuvallisia hymiöitä';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Lähetetty';
$txt['standard'] = 'Vakio';
$txt['thumbs_up'] = 'Peukku ylös';
$txt['thumbs_down'] = 'Peukku alas';
$txt['exclamation_point'] = 'Huutomerkki';
$txt['question_mark'] = 'Kysymysmerkki';
$txt['icon_poll'] = 'Äänestys';
$txt['lamp'] = 'Lamppu';
$txt['add_smileys'] = 'Add smileys';
$txt['topic_notify_no'] = 'There are no topics with notification.';

$txt['rich_edit_wont_work'] = 'Selaimesi ei tue rikasta tekstinmuokkausta';
$txt['rich_edit_function_disabled'] = 'Selaimesi ei tue tätä toimintoa.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Peruuta t&#228;m&#228;n aiheen muistutukset t&#228;st&#228;.';

$txt['lock_after_post'] = 'Lukitse l&#228;hett&#228;misen j&#228;lkeen';
$txt['notify_replies'] = 'Ilmoita vastauksista';
$txt['lock_topic'] = 'Lukitse t&#228;m&#228; aihe';
$txt['shortcuts'] = 'shortcuts: shift+alt+s submit/post or shift+alt+p preview';
$txt['shortcuts_drafts'] = 'shortcuts: shift+alt+s submit/post, shift+alt+p preview or shift+alt+d save draft';
$txt['option'] = 'Vaihtoehto';
$txt['reset_votes'] = 'Reset vote count';
$txt['reset_votes_check'] = 'Valitse tämä jos haluat nollata kaikki äänimäärät.';
$txt['votes'] = 'ääntä';
$txt['attach'] = 'Liite';
$txt['clean_attach'] = 'Clear attachment';
$txt['attached'] = 'Liitetty'; // @deprecated since 1.1
$txt['allowed_types'] = 'Sallitut tiedostomuodot';
$txt['cant_upload_type'] = 'You cannot upload that type of file. The only allowed extensions are %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Poista valinta liitteistä jotka haluat poistaa'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Kielletty tiedostonimi, kokeile jotain muuta nimeä.';
$txt['topic_locked_no_reply'] = 'Warning! This topic is currently/will be locked<br />Only admins and moderators can reply.';
$txt['attachment_requires_approval'] = 'Huomaa, että liitetiedostot vaativat valvojan hyväksynnän.';
$txt['error_temp_attachments'] = 'There are attachments found, which you have attached before but not posted. These attachments are now attached to this post. If you do not want to include them in this post, <a href="#postAttachment">you can remove them here</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Huom! T&#228;t&#228; viesti&#228; ei n&#228;ytet&#228; ennen kuin se on hyv&#228;ksytty.';

$txt['enter_comment'] = 'Ilmoituksen syy';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Ilmoitettu viesti';
$txt['reported_to_mod_by'] = 'kirjoittanut';
$txt['rtm10'] = 'Lähetä';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Viestist&#228; "%1$s, jonka on kirjoittanut';
$txt['reported_by'] = ', raportoi';
$txt['board_moderate'] = 'alueelta jota valvot';
$txt['report_comment'] = 'Ilmoituksen tekijä kommentoi seuraavasti';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximum total size %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximum individual size %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = 'korkeintaan %1$d liitettä';
$txt['attach_restrictions'] = 'Rajoitukset:';

$txt['post_additionalopt_attach'] = 'Liitteet ja muut asetukset';
$txt['post_additionalopt'] = 'Other options';
$txt['sticky_after'] = 'Pin this topic.';
$txt['move_after2'] = 'Siirrä tämä aihe';
$txt['back_to_topic'] = 'Palaa viestiketjuun';
$txt['approve_this_post'] = 'Approve this post';

$txt['retrieving_quote'] = 'Retrieving quote...';

$txt['post_visual_verification_label'] = 'Varmistus';
$txt['post_visual_verification_desc'] = 'Anna kuvassa oleva koodi jättääksesi viestin.';

$txt['poll_options'] = 'Äänestyksen asetukset';
$txt['poll_run'] = 'Äänestys käynnissä ';
$txt['poll_run_limit'] = '(Jätä tyhjäksi niin ei suljeta automaattisesti)';
$txt['poll_results_visibility'] = 'Tulosten näkyvyys';
$txt['poll_results_anyone'] = 'Näytä tulokset kaikille';
$txt['poll_results_voted'] = 'Näytä tulokset vain äänestämisen jälkeen';
$txt['poll_results_after'] = 'Näytä tulokset vasta äänestyksen päätyttyä.';
$txt['poll_max_votes'] = 'Enin äänimäärä käyttäjää kohden';
$txt['poll_do_change_vote'] = 'Salli käyttäjien vaihtaa ääntään.';
$txt['poll_too_many_votes'] = 'Valitsit liikaa vaihtoehtoja - valitse enintään "%1$s';
$txt['poll_add_option'] = 'Lisää vaihtoehto';
$txt['poll_guest_vote'] = 'Salli vieraiden äänestää';

$txt['spellcheck_done'] = 'Oikoluku suoritettu.';
$txt['spellcheck_change_to'] = 'Muuta:';
$txt['spellcheck_suggest'] = 'Ehdotukset:';
$txt['spellcheck_change'] = 'Muuta';
$txt['spellcheck_change_all'] = 'Muuta kaikki';
$txt['spellcheck_ignore'] = 'Ohita';
$txt['spellcheck_ignore_all'] = 'Ohita kaikki';

$txt['more_attachments'] = 'lisää liitteitä';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Et voi lähettää enempää liitteitä.';

$txt['more_smileys'] = 'lisää';
$txt['more_smileys_title'] = 'Lisää hymi&ouml;itä';
$txt['more_smileys_pick'] = 'Valitse hymi&ouml;';
$txt['more_smileys_close_window'] = 'Sulje ikkuna';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = 'Lähetä tiedote tästä aiheesta jäsenille.';
$txt['announce_title'] = 'Lähetä tiedote';
$txt['announce_desc'] = 'Tämän lomakkeen avulla voit lähettää tiedotteen tästä aiheesta tietyille jäsenryhmille.';
$txt['announce_sending'] = 'Lähettää tiedotetta aiheesta';
$txt['announce_done'] = 'valmis';
$txt['announce_continue'] = 'Eteenpäin';
$txt['announce_topic'] = 'Tiedota aiheesta';
$txt['announce_regular_members'] = 'Tavalliset jäsenet';

$txt['digest_subject_daily'] = 'Päivittäinen yhteenveto';
$txt['digest_subject_weekly'] = 'Viikottainen yhteenveto';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'The following topics were started';
$txt['digest_new_topics_line'] = '"%1$s" in the %2$s board';
$txt['digest_new_replies'] = 'Seuraaviin aiheisiin on tullut vastauksia';
$txt['digest_new_replies_one'] = 'Yksi vastaus aiheessa "%1$s" ';
$txt['digest_new_replies_many'] = '%1$d vastausta aiheessa "%2$s" ';
$txt['digest_mod_actions'] = 'Seuraavat valvontatoimenpiteet suoritettiin';
$txt['digest_mod_act_sticky'] = '"%1$s" was pinned';
$txt['digest_mod_act_lock'] = '"%1$s lukittiin';
$txt['digest_mod_act_unlock'] = '"%1$s avattiin';
$txt['digest_mod_act_remove'] = '"%1$s poistettiin';
$txt['digest_mod_act_move'] = '"%1$s siirrettiin';
$txt['digest_mod_act_merge'] = '"%1$s yhdistettiin';
$txt['digest_mod_act_split'] = '"%1$s jaettiin';

$txt['attach_error_title'] = 'Error uploading attachments.';
$txt['attach_warning'] = 'There was a problem during the uploading of <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Sorry, you are out of attachment space. The total attachment size allowed per post is %1$s KB. Space remaining is %2$s KB.';
$txt['attach_folder_warning'] = 'The attachments directory can not be located. Please notify an administrator of this problem.';
$txt['attach_folder_admin_warning'] = 'The path to the attachments directory (%1$s) is incorrect. Please correct it in the attachment settings area of your admin panel.';
$txt['attach_limit_nag'] = 'You have reached the maximum number of attachments allowed per post.';
$txt['attach_no_upload'] = 'There was a problem and your attachments could not be uploaded';
$txt['attach_remaining'] = '%1$d remaining';
$txt['attach_available'] = '%1$s KB available';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'The file appears to be empty. Please contact your forum administrator if this continues to be a problem';
$txt['attached_files_in_session'] = '<em>The above underlined file(s) have been uploaded but will not be attached to this post until it is submitted.</em>';

$txt['attach_php_error'] = 'Due to an error, your attachment could not be uploaded. Please contact the forum administrator if this problem continues.';
$txt['php_upload_error_1'] = 'The uploaded file exceeds the upload_max_filesize directive in php.ini. Please contact your host if you are unable to correct this issue.';
$txt['php_upload_error_3'] = 'The uploaded file was only partially uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_4'] = 'No file was uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_6'] = 'Unable to save. Missing a temporary directory. Please contact your host if you are unable to correct this problem.';
$txt['php_upload_error_7'] = 'Failed to write file to disk. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_8'] = 'A PHP extension stopped the file upload. This is a PHP related error. Please contact your host if this problem continues.';
$txt['error_temp_attachments_new'] = 'There are attachments which you had previously attached but not posted. These attachments are still attached to this post. This post does need to be submitted before these attachments are either saved or removed. You <a href="#postAttachment">can do that here</a>';
$txt['error_temp_attachments_found'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not post until these are either removed or that post has been submitted.<br />Click <a href="%1$s">here to remove </a>those attachments. Or <a href="%2$s">here to return to that post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not upload any more attachments until these are removed or that post has been submitted.<br />Click <a href="%1$s">here to remove these attachments</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Those attachments have now been removed and you have been returned to the page you were previously on';
$txt['error_temp_attachments_flushed'] = 'Please note that any files which had been previously attached, but not posted, have now been removed.';
$txt['error_topic_already_announced'] = 'Please note that this topic has already been announced.';

$txt['cant_access_upload_path'] = 'Liitetiedostojen latauskansiota ei pysty käyttämään!';
$txt['file_too_big'] = 'Your file is too large. The maximum attachment size allowed is %1$s KB.';
$txt['attach_timeout'] = 'Virhe tallennettaessa liitettä. Tämä voi johtua liian isosta tiedostosta, tai liian hitaasta latauksesta riippuen palvelimen asetuksista. Ole hyvä ja yritä uudestaan, ja mikäli virhe toistuu, ole yhteydessä palvelimen ylläpitäjään saadaksesi lisätietoja.';
$txt['bad_attachment'] = 'Tiedostosi ei läpäissyt turvatarkistuksia. Ota yhteyttä ylläpitäjään.';
$txt['ran_out_of_space'] = 'The upload directory is full. Please contact an administrator about this problem.';
$txt['attachments_no_write'] = 'Liitetiedostojen hakemisto ei ole kirjoitettava (chmod). Liitettäsi tai kuvaasi ei voida tallentaa.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory.  Your attachment or avatar cannot be saved.';
$txt['attachments_limit_per_post'] = 'Voit ladata vain %1$d liitettä viestiä kohden';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Insert';
$txt['ila_opt_size'] = 'Koko';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Ei ole';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Center';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/