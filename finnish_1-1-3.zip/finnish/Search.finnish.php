<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Aseta hakuparametrit';
$txt['choose_board'] = 'Valitse keskustelualue josta etsiä, tai etsi kaikkialta';
$txt['all_words'] = 'Kaikilla sanoilla';
$txt['any_words'] = 'Millä tahansa sanoista';
$txt['by_user'] = 'käyttäjältä';

$txt['search_post_age'] = 'Viestin ikä';
$txt['search_between'] = 'Aikajaksolla';
$txt['search_and'] = 'ja';
$txt['search_options'] = 'Lisävalinnat';
$txt['search_show_complete_messages'] = 'Näytä tulokset viesteinä';
$txt['search_subject_only'] = 'Hae vain otsikoista';
$txt['search_relevance'] = 'Vastaavuus';
$txt['search_date_posted'] = 'Viesti kirjoitettu';
$txt['search_order'] = 'Tuloksien järjestys';
$txt['search_orderby_relevant_first'] = 'Vastaavimmat tulokset ensin';
$txt['search_orderby_large_first'] = 'Isoimmat aiheet ensin';
$txt['search_orderby_small_first'] = 'Pienimmät aiheet ensin';
$txt['search_orderby_recent_first'] = 'Uusimmat aiheet ensin';
$txt['search_orderby_old_first'] = 'Vanhimmat aiheet ensin';
$txt['search_visual_verification_label'] = 'Varmistus';
$txt['search_visual_verification_desc'] = 'Anna kuvassa oleva koodi käyttääksesi hakua';

$txt['search_specific_topic'] = 'Haetaan tuloksia vain aiheen sisältä';

$txt['groups_search_posts'] = 'Jäsenryhmät joilla on pääsy hakutoimintoon';
$txt['search_dropdown'] = 'Enable the Quick Search dropdown';
$txt['search_results_per_page'] = 'Haun tuloksien lukumäärä sivua kohden';
$txt['search_weight_frequency'] = 'Aiheessa olevien hakutuloksiin sopivien viestien määrän suhteellinen painoarvo haussa';
$txt['search_weight_age'] = 'Aiheessa olevan viimeisen hakutuloksiin sopivan viestin iän suhteellinen painoarvo haussa';
$txt['search_weight_length'] = 'Aiheen pituuden suhteellinen painoarvo haussa';
$txt['search_weight_subject'] = 'Aiheen otsikon suhteellinen painoarvo haussa';
$txt['search_weight_first_message'] = 'Aiheen ensimmäisen viestin suhteellinen painoarvo haussa';
$txt['search_weight_sticky'] = 'Relative search weight for a pinned topic';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Here you can change the basic settings of the search function.';
$txt['search_settings_title'] = 'Search Settings';

$txt['search_weights_desc'] = 'Here you can change the individual components of the relevance rating.';
$txt['search_weights_sphinx'] = 'To update weight factors with Sphinx, you must generate and install a new sphinx.conf file.';
$txt['search_weights_title'] = 'Haku - painoarvot';
$txt['search_weights_total'] = 'Yhteensä';
$txt['search_weights_save'] = 'Tallenna';

$txt['search_method_desc'] = 'Täällä voit päättää miten hakukone toimii.';
$txt['search_method_title'] = 'Hakutapa';
$txt['search_method_save'] = 'Tallenna';
$txt['search_method_messages_table_space'] = 'Tilaa käytettynä viesteihin tietokannassa';
$txt['search_method_messages_index_space'] = 'Tilaa käytettynä viestien indeksoimiseen tietokannassa';
$txt['search_method_kilobytes'] = 'kt';
$txt['search_method_fulltext_index'] = 'Fulltext indeksi';
$txt['search_method_no_index_exists'] = 'ei olemassa tällä hetkellä';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'ei voida luoda koska viestin enimmäispituus on yli 65,535';
$txt['search_method_index_already_exists'] = 'on olemassa';
$txt['search_method_fulltext_remove'] = 'poista fulltext indeksi';
$txt['search_method_index_partial'] = 'osittain luotu';
$txt['search_index_custom_resume'] = 'jatka';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'In order to be able to use fulltext search, you\\\'ll have to create a fulltext index first.';
$txt['search_index_custom_warning'] = 'Muokattu indeksi täytyy ensin luoda, jotta sitä voi käyttää haussa!';

$txt['search_index'] = 'Hakuindeksi';
$txt['search_index_none'] = 'Ei indeksiä';
$txt['search_index_custom'] = 'Muokattu indeksi';
$txt['search_index_label'] = 'Indeksi';
$txt['search_index_size'] = 'Koko';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Pakota hakuindeksin käyttöön';
$txt['search_match_words'] = 'Osumat vain kokonaisiin sanoihin';
$txt['search_max_results'] = 'Tulosten enimmäismäärä';
$txt['search_max_results_disable'] = '(0: ei rajoitusta)';
$txt['search_floodcontrol_time'] = 'Hakujen välillä odotettava aika';
$txt['search_floodcontrol_time_desc'] = '(0: ei rajoitusta, sekunneissa)';

$txt['additional_search_engines'] = 'Additional search engines';
$txt['setup_search_engine_add_more'] = 'Add another search engine';

$txt['search_create_index'] = 'Luo indeksi';
$txt['search_create_index_why'] = 'Miksi luoda hakuindeksi?';
$txt['search_create_index_start'] = 'Luo';
$txt['search_predefined'] = 'Ennalta määritetty profiili';
$txt['search_predefined_small'] = 'Pienikokoinen indeksi';
$txt['search_predefined_moderate'] = 'Keskikokoinen indeksi';
$txt['search_predefined_large'] = 'Isokokoinen indeksi';
$txt['search_create_index_continue'] = 'Eteenpäin';
$txt['search_create_index_not_ready'] = 'ElkArte is currently creating a search index of your messages. To avoid overloading your server, the process has been temporarily paused. It should automatically continue in a few seconds. If it doesn\'t, please click continue below.';
$txt['search_create_index_progress'] = 'Käynnissä';
$txt['search_create_index_done'] = 'Custom search index successfully created.';
$txt['search_create_index_done_link'] = 'Eteenpäin';
$txt['search_double_index'] = 'Viestitaulusta on luotu kaksi indeksiä. Parhaan suorityskyvyn saavuttamiseksi on suositeltavaa poistaa niistä toinen.';

$txt['search_error_indexed_chars'] = 'Virheellinen lukumäärä indeksoitavia merkkejä. Käyttökelpoiseen indeksiin tarvitaan ainakin 3 merkkiä.';
$txt['search_error_max_percentage'] = 'Virheellinen prosenttimäärä. Aseta arvoksi vähintään 5%.';
$txt['error_string_too_long'] = 'Hakusanat voi olla maksimissaan %1$d merkkiä pitkä.';

$txt['search_warning_ignored_word'] = 'The following term has been ignored in your search';
$txt['search_warning_ignored_words'] = 'The following terms have been ignored in your search';

$txt['search_adjust_query'] = 'Tarkenna hakuehtoja';
$txt['search_adjust_submit'] = 'Hae uudelleen';
$txt['search_did_you_mean'] = 'Tarkoititko';

$txt['search_example'] = '<em>esim.</em> Orwellin "Eläinten vallankumous" -elokuva';

$txt['search_engines_description'] = 'Täältä voit muokata miten tarkkaan hakurobotteja seurataan kun ne indeksoivat keskustelualuettasi ja katsoa hakurobottien logia.';
$txt['spider_mode'] = 'Search Engine Tracking Level';
$txt['spider_mode_note'] = 'Note higher level tracking increases server resource requirement.';
$txt['spider_mode_off'] = 'Ei käytössä';
$txt['spider_mode_standard'] = 'Vakio';
$txt['spider_mode_high'] = 'Moderoi';
$txt['spider_mode_vhigh'] = 'Aggressive';
$txt['spider_settings_desc'] = 'You can change settings for spider tracking from this page. Note, if you wish to <a href="%1$s">enable automatic pruning of the hit logs you can set this up here</a>';

$txt['spider_group'] = 'Apply restrictive permissions from group';
$txt['spider_group_note'] = 'To enable you to stop spiders indexing some pages.';
$txt['spider_group_none'] = 'Ei käytössä';

$txt['show_spider_online'] = 'Näytä hakurobotit paikalla olevien käyttäjien listassa.';
$txt['show_spider_online_no'] = 'Ei ollenkaan';
$txt['show_spider_online_summary'] = 'Näytä hakurobottien määrä';
$txt['show_spider_online_detail'] = 'Näytä hakurobottien tiedot';
$txt['show_spider_online_detail_admin'] = 'Näytä hakurobottien tiedot ylläpidolle';

$txt['spider_name'] = 'Hakurobotin nimi';
$txt['spider_last_seen'] = 'Viimeksi käynyt';
$txt['spider_last_never'] = 'Ei koskaan';
$txt['spider_agent'] = 'Asiakasohjelma';
$txt['spider_ip_info'] = 'IP-Osoite';
$txt['spiders_add'] = 'Lisää hakurobotti';
$txt['spiders_edit'] = 'Muokkaa hakurobottia';
$txt['spiders_remove_selected'] = 'Poista valitut';
$txt['spider_remove_selected_confirm'] = 'Are you sure you want to remove these spiders?\\n\\nAll associated statistics will also be deleted!';
$txt['spiders_no_entries'] = 'Yhtään hakurobottia ei vielä ole konfiguroitu';

$txt['add_spider_desc'] = 'Tältä sivulta voit muokata harubotti luokittelun parametrejä. Jos vieraan asiakasohjelma tai IP-osoite täsmää tällä sivulla oleviin, luokitellaan vieras hakurobotiksi ja sitä seurataan keskustelualueen asetuksien mukaan.';
$txt['spider_name_desc'] = 'Nimi jolla hakurobittia kutsutaan.';
$txt['spider_agent_desc'] = 'Hakurobotin ilmoittama asiakasohjelma.';
$txt['spider_ip_info_desc'] = 'Pilkulla erotettu lista hakurobitin käyttämistä IP-osoitteista.';

$txt['spider_time'] = 'Aika';
$txt['spider_viewing'] = 'Katselee';
$txt['spider_logs_empty'] = 'Ei kirjattuja tapahtumia hakuroboille.';
$txt['spider_logs_info'] = 'Huom! Kaikki toiminnot kirjataan vain tasolla &quot;korkea&quot; tai &quot;erittäin korkea&quot;. Yksityiskohdat kirjataan vain tasolla erittäin &quot;korkea&quot;.';
$txt['spider_disabled'] = 'Ei käytössä';
$txt['spider_log_empty_log'] = 'Clear Log';
$txt['spider_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log';

$txt['spider_logs_delete'] = 'Poista tapahtumia';
$txt['spider_logs_delete_older'] = 'Delete all entries older than %1$s days.';
$txt['spider_logs_delete_submit'] = 'Poista';

$txt['spider_stats_delete_older'] = 'Delete all spider statistics from spiders not seen in %1$s days.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Oletko varma että haluat tyhjentää login?';

$txt['spider_stats_select_month'] = 'Näytä kuukausi';
$txt['spider_stats_page_hits'] = 'Sivulatauksia';
$txt['spider_stats_no_entries'] = 'Hakuroboteista ei ole vielä tallennettu statistiikkaa.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'You have not yet selected to use Sphinx or SphinxQL as your Search Method';
$txt['sphinx_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using the Sphinx API.';
$txt['sphinxql_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using SphinxQL commands.';
$txt['sphinx_test_connect_failed'] = 'Unable to connect to the Sphinx daemon. Make sure it is running and configured properly. Sphinx search will not work until you fix the problem.';
$txt['sphinxql_test_connect_failed'] = 'Unable to access SphinxQL. Make sure your sphinx.conf has a separate listen directive for the SphinxQL port. SphinxQL search will not work until you fix the problem';
$txt['sphinx_test_api_missing'] = 'The sphinxapi.php file is missing in your &quot;sources&quot; directory. You need to copy this file from the Sphinx distribution. Sphinx search will not work until you fix the problem.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Index data path:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Log file path:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';