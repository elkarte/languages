<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Yksityisviestit';
$txt['pm_add'] = 'Lisää';
$txt['make_bcc'] = 'Lisää piilokopio';
$txt['pm_to'] = 'Käyttäjälle';
$txt['pm_bcc'] = 'Kopio';
$txt['inbox'] = 'Saapuneet';
$txt['conversation'] = 'Keskustelu';
$txt['messages'] = 'Viestit';
$txt['sent_items'] = 'Lähetetyt';
$txt['new_message'] = 'Uusi viesti';
$txt['delete_message'] = 'Poista viestit';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Poista kaikki viestit laatikosta PMBOX';
$txt['delete_all_confirm'] = 'Haluatko varmasti poistaa kaikki viestit?';

$txt['delete_selected_confirm'] = 'Oletko varma että haluat poistaa valitut viestit?';

$txt['sent_to'] = 'Lähetetty käyttäjälle';
$txt['reply_to_all'] = 'Vastaa kaikille';
$txt['delete_conversation'] = 'Poista keskustelu';

$txt['pm_capacity'] = 'Tilan käyttö';
$txt['pm_currently_using'] = 'Viestejä %1$s, %2$s%% tilasta käytössä.';
$txt['pm_sent'] = 'Viestisi on lähetetty onnistuneesti.';

$txt['pm_error_user_not_found'] = 'Jäsentä \'%1$s\' ei löydy.';
$txt['pm_error_ignored_by_user'] = 'Käyttäjä \'%1$s\' on estänyt yksityisviestit sinulta.';
$txt['pm_error_data_limit_reached'] = 'PM could not be sent to \'%1$s\' as their inbox is full.';
$txt['pm_error_user_cannot_read'] = 'Käyttäjä \'%1$s\'  ei voi vastaanottaa yksityisviestejä.';
$txt['pm_successfully_sent'] = 'Viestin lähetys jäsenelle \'%1$s\'  onnistui.';
$txt['pm_send_report'] = 'Lähetysraportti';
$txt['pm_undisclosed_recipients'] = 'Piilokopion saaneet vastaanottajat';
$txt['pm_too_many_recipients'] = 'Voit lähettää yksityisviestin korkeintaan %1$d vastaanottajalle kerrallaan.';

$txt['pm_read'] = 'Luettu';
$txt['pm_replied'] = 'Vastattu';
$txt['pm_mark_unread'] = 'Mark as Unread';

// Message Pruning.
$txt['pm_prune'] = 'Prune messages';
$txt['pm_prune_desc'] = 'Delete all personal messages older than %1$s days.';
$txt['pm_prune_warning'] = 'Oletko varma että haluat karsia yksityisviestejäsi?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Further actions';
$txt['pm_actions_delete_selected'] = 'Poista valitut';
$txt['pm_actions_filter_by_label'] = 'Filter by label';
$txt['pm_actions_go'] = 'Mene';

// Manage Labels Screen.
$txt['pm_apply'] = 'Käytä';
$txt['pm_manage_labels'] = 'Manage labels';
$txt['pm_labels_delete'] = 'Haluatko varmasti poistaa valitut leimat? Samalla poistuvat kaikki säännöt, jotka niihin on kytketty.';
$txt['pm_labels_desc'] = 'Täällä voit lisätä, muokata sekä poistaa leimoja yksityisviestialueeltasi.';
$txt['pm_label_add_new'] = 'Add new label';
$txt['pm_label_name'] = 'Label name';
$txt['pm_labels_no_exist'] = 'Et ole asettanut ainuttakaan leimaa!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Leima';
$txt['pm_msg_label_title'] = 'Label message';
$txt['pm_msg_label_apply'] = 'Add label';
$txt['pm_msg_label_remove'] = 'Remove label';
$txt['pm_msg_label_inbox'] = 'Saapuneet';
$txt['pm_sel_label_title'] = 'Label selected';

// Sidebar Headings.
$txt['pm_labels'] = 'Leima';
$txt['pm_messages'] = 'Viestit';
$txt['pm_actions'] = 'Toiminnot';
$txt['pm_preferences'] = 'Lisävalinnat';

$txt['pm_is_replied_to'] = 'Olet vastannut tähän viestiin tai lähettänyt sen edelleen.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Report to admin';
$txt['pm_report_title'] = 'Report personal message';
$txt['pm_report_desc'] = 'Täällä voit raportoida ylläpidolle saamastasi yksityisviestistä. Ole hyvä ja liitä mukaan selvitys miksi viestistä raportoit, se lähetetään alkuperäisen viestin mukana ylläpidolle..';
$txt['pm_report_admins'] = 'Ylläpitäjä jolle lähetetään raportti';
$txt['pm_report_all_admins'] = 'Lähetä kaikille ylläpitäjille';
$txt['pm_report_reason'] = 'Syy miksi raportoit viestistä';
$txt['pm_report_message'] = 'Raportoi viesti';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[RAPORTOITU VIESTI]';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} raportoi seuraavasta yksityisviestistä jonka {SENDER} on lähettänyt hänelle. Syy:';
$txt['pm_report_pm_other_recipients'] = 'Muut viestin saajat:';
$txt['pm_report_pm_hidden'] = '%1$d piilotettu(a) vastaanottaja(a)';
$txt['pm_report_pm_unedited_below'] = 'Alla on alkuperäinen versio raportoidusta viestistä:';
$txt['pm_report_pm_sent'] = 'Lähetti:';

$txt['pm_report_done'] = 'Kiitos raportistasi. Ylläpitoryhmä ottaa sinuun yhteyttä tarvittaessa pikapuoliin.';
$txt['pm_report_return'] = 'Palaa saapuneisiin';

$txt['pm_search_title'] = 'Search personal messages';
$txt['pm_search_bar_title'] = 'Search messages';
$txt['pm_search_text'] = 'Etsi seuraavaa';
$txt['pm_search_go'] = 'Haku';
$txt['pm_search_advanced'] = 'Show advanced options';
$txt['pm_search_simple'] = 'Hide advanced options';
$txt['pm_search_user'] = 'käyttäjältä';
$txt['pm_search_match_all'] = 'Kaikilla sanoilla';
$txt['pm_search_match_any'] = 'Millä tahansa sanoista';
$txt['pm_search_options'] = 'Lisävalinnat';
$txt['pm_search_post_age'] = 'Viestin ikä';
$txt['pm_search_show_complete'] = 'Näytä koko viesti hakutuloksissa.';
$txt['pm_search_subject_only'] = 'Hae vain otsikon ja kirjoittajan mukaan.';
$txt['pm_search_sent_only'] = 'Search only in sent items.';
$txt['pm_search_between'] = 'Aikajaksolla';
$txt['pm_search_between_and'] = 'ja';
$txt['pm_search_between_days'] = 'päiviä';
$txt['pm_search_order'] = 'Tuloksien järjestys';
$txt['pm_search_choose_label'] = 'Valitse leimat joista etsitään tai valitse kaikki';

$txt['pm_search_results'] = 'Search results';
$txt['pm_search_none_found'] = 'No messages found';

$txt['pm_search_orderby_relevant_first'] = 'Osuvin ensimmäiseksi';
$txt['pm_search_orderby_recent_first'] = 'Uusin ensimmäiseksi';
$txt['pm_search_orderby_old_first'] = 'Vanhin ensimmäiseksi';

$txt['pm_visual_verification_label'] = 'Varmistus';
$txt['pm_visual_verification_desc'] = 'Please enter the code in the image above in order to send this PM.';

$txt['pm_settings'] = 'Change settings';
$txt['pm_change_view'] = 'Change view';

$txt['pm_manage_rules'] = 'Manage rules';
$txt['pm_manage_rules_desc'] = 'Viestisäännöillä voit lajitella viestejä kriteereiden mukaan. Alla näet kaikki olemassa olevat säännöt. Voit muokata sääntöä napsauttamalla sen nimeä.';
$txt['pm_rules_none'] = 'Et ole asettanut sääntöjä.';
$txt['pm_rule_title'] = 'Sääntö';
$txt['pm_add_rule'] = 'Add new rule';
$txt['pm_apply_rules'] = 'Apply rules now';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Oletko varma ett&auml; haluat ottaa s&auml;&auml;nn&ouml;t k&auml;ytt&ouml;&ouml;n kaikkiin viestehin?';
$txt['pm_edit_rule'] = 'Edit rule';
$txt['pm_rule_save'] = 'Save rule';
$txt['pm_delete_selected_rule'] = 'Delete selected rules';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Haluatko varmasti poistaa valitut s&auml;&auml;nn&ouml;t?';
$txt['pm_rule_name'] = 'Nimi';
$txt['pm_rule_name_desc'] = 'Nimi säännölle';
$txt['pm_rule_name_default'] = '[NIMI]';
$txt['pm_rule_description'] = 'Kuvaus';
$txt['pm_rule_not_defined'] = 'Lisää muutama kriteeri aloittaaksesi säännön rakentamisen.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><b>Huomaa:</b> Javascript-tuki on pois käytöstä. On suositeltavaa ottaa Javascriptin käyttöön käyttääksesi tätä toimintoa.</span>';
$txt['pm_rule_criteria'] = 'Kriteeri';
$txt['pm_rule_criteria_add'] = 'Add criteria';
$txt['pm_rule_criteria_pick'] = 'Choose criteria';
$txt['pm_rule_mid'] = 'Sender name';
$txt['pm_rule_gid'] = 'Sender\'s group';
$txt['pm_rule_sub'] = 'Message subject contains';
$txt['pm_rule_msg'] = 'Message body contains';
$txt['pm_rule_bud'] = 'Sender is buddy';
$txt['pm_rule_sel_group'] = 'Select group';
$txt['pm_rule_logic'] = 'When checking criteria';
$txt['pm_rule_logic_and'] = 'Kaikki kriteerit täyttyy';
$txt['pm_rule_logic_or'] = 'Osa kriteereistä täyttyy';
$txt['pm_rule_actions'] = 'Toiminnot';
$txt['pm_rule_sel_action'] = 'Select an action';
$txt['pm_rule_add_action'] = 'Add action';
$txt['pm_rule_label'] = 'Aseta leima';
$txt['pm_rule_sel_label'] = 'Select label';
$txt['pm_rule_delete'] = 'Delete message';
$txt['pm_rule_no_name'] = 'Unohdit antaa säännölle nimen.';
$txt['pm_rule_no_criteria'] = 'Säännössä tulee olla vähintään yksi kriteeri ja yksi tapahtuma';
$txt['pm_rule_too_complex'] = 'The rule you are creating is too long to save. Try breaking it up into smaller rules.';

$txt['pm_readable_and'] = '<em>ja</em>';
$txt['pm_readable_or'] = '<em>tai</em>';
$txt['pm_readable_start'] = 'Jos ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'viesti on jäseneltä &quot;{MEMBER}&quot;';
$txt['pm_readable_group'] = 'lähettäjän ryhmä on &quot;{GROUP}&quot;';
$txt['pm_readable_subject'] = 'otsikko sisältää &quot;{SUBJECT}&quot;';
$txt['pm_readable_body'] = 'viesti sisältää &quot;{BODY}&quot;';
$txt['pm_readable_buddy'] = 'lähettäjä on kaveri';
$txt['pm_readable_label'] = 'aseta leimaksi &quot;{LABEL}&quot;';
$txt['pm_readable_delete'] = 'poista viesti';
$txt['pm_readable_then'] = '<strong>sitten</strong>';