<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'ElkArte User Help';

$txt['manual_welcome'] = 'Welcome to %s, powered by ElkArte Forum software!';
$txt['manual_introduction'] = 'ElkArte is the elegant, effective, powerful and free forum software solution that this site is running. It allows users to communicate in discussion topics on a given subject in a clever and organized manner. Furthermore, it has a number of powerful features which end users can take advantage of. Help for many of ElkArte\'s features can be found by either clicking the question mark icon next to the relevant section or by selecting one of the links on this page. These links will take you to ElkArte\'s centrally-located documentation on the ElkArte official site.';
$txt['manual_docs_and_credits'] = 'For more information about how to use ElkArte, please see the <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> and check out the <a href="%2$s">credits</a> to find out who has made ElkArte what it is today.';

$txt['manual_section_registering_title'] = 'Rekisteröityminen';
$txt['manual_section_logging_in_title'] = 'Sisäänkirjautuminen';
$txt['manual_section_profile_title'] = 'Profiilit';
$txt['manual_section_search_title'] = 'Haku';
$txt['manual_section_posting_title'] = 'Viestin lähettäminen';
$txt['manual_section_bbc_title'] = 'Bulletin Board Code (BBC) ';
$txt['manual_section_personal_messages_title'] = 'Yksityisviestit';
$txt['manual_section_memberlist_title'] = 'Jäsenluettelo';
$txt['manual_section_calendar_title'] = 'Kalenteri';
$txt['manual_section_features_title'] = 'Toiminnot';

$txt['manual_section_registering_desc'] = 'Useimmat foorumit vaativat käyttäjältä rekisteröitymistä käyttääkseen kaikkia foorumin toimintoja.';
$txt['manual_section_logging_in_desc'] = 'Rekisteröidyttyään, käyttäjien tulee kirjautua sisään käyttääkseen uutta käyttäjätunnustaan.';
$txt['manual_section_profile_desc'] = 'Jokaisella käyttäjällä on oma, henkilökohtainen profiilinsa.';
$txt['manual_section_search_desc'] = 'Haku on erittäin suuri apu tiedonhakuun, ja helpottaa tiettyjen viestien ja viestiketjujen löytämistä.';
$txt['manual_section_posting_desc'] = 'Foorumien keskeisin tarkoitus, viestien jakamisen mahdollistaminen käyttäjien kesken.';
$txt['manual_section_bbc_desc'] = 'Viestejä voi muotoilla ja maustaa BBC koodein.';
$txt['manual_section_personal_messages_desc'] = 'Käyttäjät voivat lähettää yksityisviestejä suoraan toisilleen.';
$txt['manual_section_memberlist_desc'] = 'Jäsenluettelo näyttää kaikki keskustelualueelle rekisteröityneet käyttäjät.';
$txt['manual_section_calendar_desc'] = 'Käyttäjät voivat käyttää kalenteria tapahtumien, pyhäpäivien, syntymäpäivien ja vastaavien seurantaan.';
$txt['manual_section_features_desc'] = 'Here is a list of the most popular features in ElkArte.';