<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Hallinnoi oikeuksia';
$txt['permissions_modify'] = 'muokkaa';
$txt['permissions_view'] = 'Katso tarkemmin';
$txt['permissions_allowed'] = 'Sallittu';
$txt['permissions_denied'] = 'Kielletty';
$txt['permission_cannot_edit'] = '<strong>Note:</strong> You cannot edit this permission profile as it is a predefined profile included within the forum software by default. If you wish to change the permissions of this profile you must first create a duplicate profile. You can <a href="%1$s">carry out this task by clicking here</a>.';

$txt['permissions_for_profile'] = 'Oikeudet profiilille';
$txt['permissions_boards_desc'] = 'Lista alapuolella näyttää mitä oikeuksia mikin alue käyttää. Voit mukata oikeusprofiilia painamlla sen nimestä tai valitsemalla &quot;muokkaa kaikkia&quot; sivun alaosasta. Profiilin itsensä muokkaamiseksi paina sen nimeä.';
$txt['permissions_board_all'] = 'Muokkaa kaikkia';
$txt['permission_profile'] = 'Oikeusprofiili';
$txt['permission_profile_desc'] = 'Which <a target="_blank" href="%1$s">permission set</a> the board should use.';
$txt['permission_profile_inherit'] = 'Peri ylemmältä alueelta';

$txt['permissions_profile'] = 'Profiilit';
$txt['permissions_profiles_desc'] = 'Oikeusprofiilit annetaa yksittäisille alueille, jotta voisit helposti muokata turvallisuusasetuksia. Täältä voit luoda, muokata ja poistaa oikeusprofiilieja.';
$txt['permissions_profiles_change_for_board'] = 'Muokataan oikeusprofiilia &quot;%1$s&quot; ';
$txt['permissions_profile_default'] = 'Vakio';
$txt['permissions_profile_no_polls'] = 'Ei äänestyksiä';
$txt['permissions_profile_reply_only'] = 'Vain vastauksia';
$txt['permissions_profile_read_only'] = 'Vain luku';

$txt['permissions_profile_rename'] = 'Rename all';
$txt['permissions_profile_edit'] = 'Muokkaa profiileja';
$txt['permissions_profile_new'] = 'Uusi profiili';
$txt['permissions_profile_new_create'] = 'Luo';
$txt['permissions_profile_name'] = 'Profiilin nimi';
$txt['permissions_profile_used_by'] = 'Käytössä';
$txt['permissions_profile_used_by_one'] = 'Yhdellä alueella';
$txt['permissions_profile_used_by_many'] = '%1$d alueella';
$txt['permissions_profile_used_by_none'] = 'Ei missään';
$txt['permissions_profile_do_edit'] = 'Muokkaa';
$txt['permissions_profile_do_delete'] = 'Poista';
$txt['permissions_profile_copy_from'] = 'Kopioi oikeudet ryhmästä';

$txt['permissions_includes_inherited'] = 'Perityt ryhmät';
$txt['permissions_includes_inherited_from'] = 'Inherited from: ';

$txt['permissions_all'] = 'kaikki';
$txt['permissions_none'] = '-';
$txt['permissions_set_permissions'] = 'Aseta oikeudet';

$txt['permissions_advanced_options'] = 'Lisäasetukset';
$txt['permissions_with_selection'] = 'Valinnan mukaan';
$txt['permissions_apply_pre_defined'] = 'Aseta ennalta määritelty profiili';
$txt['permissions_select_pre_defined'] = 'Valitse profiili';
$txt['permissions_copy_from_board'] = 'Kopioi oikeudet tältä alueelta';
$txt['permissions_select_board'] = 'Valitse alue';
$txt['permissions_like_group'] = 'Aseta oikeudet kuten tällä ryhmällä';
$txt['permissions_select_membergroup'] = 'Select a member group';
$txt['permissions_add'] = 'Lisää oikeus';
$txt['permissions_remove'] = 'Poista oikeus';
$txt['permissions_deny'] = 'Kiellä oikeus';
$txt['permissions_select_permission'] = 'Valitse oikeus';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Voit valita vain yhden toiminnon oikeuksien muokkaukseen';
$txt['permissions_no_action'] = 'Toimintoa ei valittu';
$txt['permissions_deny_dangerous'] = 'Olet kieltämässä; yhtä tai useampaa oikeutta.\\nTämä voi olla vaarallista ja luoda odottamattomia tuloksia jos et ole aivan varma kuka k.o ryhmään kuuluu jolta olet oikeuksia kieltämässä.\\n\\Haluatko jatkaa eteenpäin?';

$txt['permissions_modify_group'] = 'Muokkaa ryhmää';
$txt['permissions_general'] = 'Keskeisimmät oikeudet';
$txt['permissions_board'] = 'Koko keskustelualueen oikeudet';
$txt['permissions_board_desc'] = '<strong>Huomaa</strong>: näiden oikeuksien muuttaminen muuttaa kaikkien alueiden oikeuksia joilla on käytössä &quot;Oletus&quot; -oikeusprofiili. Tällä ei ole vaihutusta niihin alueisiin, jotka eivät käytä &quot;Oletus&quot; -oikeusprofiilia.';
$txt['permissions_commit'] = 'Tallenna muutokset';
$txt['permissions_on'] = 'alueella';
$txt['permissions_local_for'] = 'Paikalliset luvat ryhmälle';
$txt['permissions_option_on'] = 'K';
$txt['permissions_option_off'] = 'ä';
$txt['permissions_option_deny'] = 'K';
$txt['permissions_option_desc'] = 'For each permission you can pick either \'Allow\' (A), \'Disallow\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />Remember that if you deny a permission, any member - whether moderator or otherwise - that is in that group will be denied that as well.<br />For this reason, you should use deny carefully, only when <strong>necessary</strong>. Disallow, on the other hand, denies unless otherwise granted.';

$txt['permissiongroup_general'] = 'Yleiset';
$txt['permissionname_view_stats'] = 'Statistiikan katselu';
$txt['permissionhelp_view_stats'] = 'Keskustelualueen tilastot on ikkuna mihin on kerätty keskeisimmät keskustelualueesi tilastot. Sallimalla tämän luvan, etusivulle ilmestyy linkki (\'[Lisää tilastoja]\').';
$txt['permissionname_view_mlist'] = 'View the member list and groups';
$txt['permissionhelp_view_mlist'] = 'The member list shows all members that have registered on your forum. The list can be sorted and searched. The member list is linked from both the board index and the stats page, by clicking on the number of members. It also applies to the groups page which is a mini memberlist of people in that group.';
$txt['permissionname_who_view'] = 'keskustelualueen tapahtumien katselu';
$txt['permissionhelp_who_view'] = 'keskustelualueen tapahtumien katselussa voit katsella mitä keskustelualueella tapahtuu, mitä kukin jäsenistä on tekemässä jne.Tämä oikeus toimii vain jos olet sallinut sen admin asetuksista.Pääset \'Mitä keskustelualueella tapahtuu\' ikkunaan klikkaamalla jäsenlistaa keskustelualueesi etusivulla.';
$txt['permissionname_search_posts'] = 'Hakutoiminnon käyttö';
$txt['permissionhelp_search_posts'] = 'Hakutoiminnon avulla käyttäjä pääsee käyttämään keskustelualueen omaa hakukonetta ja \'Haku\' painike ilmestyy painikerivistöön.';
$txt['permissionname_karma_edit'] = 'Karman äänestäminen';
$txt['permissionhelp_karma_edit'] = 'Karma is a feature that shows the popularity of a member. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to cast a vote. This permission has no effect on guests.';
$txt['permissionname_like_posts'] = 'Like other users\' posts';
$txt['permissionhelp_like_posts'] = 'Likes is a feature that shows the popularity of a post. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to like a post or unlike one they previously liked.  This permission has no effect on guests.';
$txt['permissionname_like_posts_stats'] = 'See like posts stats';
$txt['permissionhelp_like_posts_stats'] = 'This will allow users to see stats of posts liking';
$txt['permissionname_disable_censor'] = 'Disable word censor';
$txt['permissionhelp_disable_censor'] = 'Allows members the option to disable the word censor.';

$txt['permissiongroup_pm'] = 'Yksityisviestintä';
$txt['permissionname_pm_read'] = 'Lukea yksityisviestejä';
$txt['permissionhelp_pm_read'] = 'Tämä toiminto sallii yksityisviestien lukemisen.';
$txt['permissionname_pm_send'] = 'Lähettää yksityisviestejä';
$txt['permissionhelp_pm_send'] = 'Tämä toiminto sallii yksityisviestien lähettämisen.';
$txt['permissionname_send_email_to_members'] = 'Send emails';
$txt['permissionhelp_send_email_to_members'] = 'Send emails to other registered members.';

$txt['permissiongroup_calendar'] = 'Kalenteri';
$txt['permissionname_calendar_view'] = 'Kalenterin katselu';
$txt['permissionhelp_calendar_view'] = 'Kalenterissa näkyy syntymäpäivät, tapahtumat jne. Aktivoimalla tämän oikeuden, panikeriville ilmestyy kalenteri painike ja etusivun alalaitaan luettelo tämänhetkisistä ja tulevista tapahtumista. Tätä varten Kalenteri täytyy aktivoida erikseen foorumin Perusominaisuuksista.';
$txt['permissionname_calendar_post'] = 'Kalenterin tapahtumien lisääminen.';
$txt['permissionhelp_calendar_post'] = 'Tapahtumia pääsee luomaan/lisäämään kalenterissa.';
$txt['permissionname_calendar_edit'] = 'Tapahtumien muokkaus kalenterissa.';
$txt['permissionhelp_calendar_edit'] = 'Tapahtuma on aihe joka on linkitetty tiettyyn päivämäärään, tai aikaväliin. Tapahtumaa voi muokata klikkaamalla punaista asteriskia (*) tapahtuman kohdalla kalenterissa. Voidakseen muokata tahtumaa, k.o henkilöllä täytyy olla myös oikeus muokata ensimmäistä viestiä k.o viestiketjussa.';
$txt['permissionname_calendar_edit_own'] = 'Omia tapahtumia';
$txt['permissionname_calendar_edit_any'] = 'Kaikkia tapahtumia';

$txt['permissiongroup_maintenance'] = 'Keskustelualueen hallinta';
$txt['permissionname_admin_forum'] = 'keskustelualueen ja tietokannan hallinnointi';
$txt['permissionhelp_admin_forum'] = 'Tämä toimnto sallii käyttäjän muuttaa keskustelualueen teeman asetuksia, lisätä poistaa muokkauksia, käyttää tietokannan huoltoa jne.Käytä tätä oikeutta harkiten, se antaa todella isoja oikeuksia!';
$txt['permissionname_manage_boards'] = 'Alueiden ja kategorioiden hallinta';
$txt['permissionhelp_manage_boards'] = 'Tämä oikeus sallii luoda, muokata sekä poistaa alueita ja kategoroita.';
$txt['permissionname_manage_attachments'] = 'Liitetiedostojen ja avatar-kuvien hallinta';
$txt['permissionhelp_manage_attachments'] = 'Tämä oikeus sallii pääsyn liitetiedostojen hallintaan, jossa kaikki keskustelualueen liitetiedostot ja avatar-kuvat ovat listattuna ja poistettavissa.';
$txt['permissionname_manage_smileys'] = 'Hallinnoida hymiöitä ja viesti-ikoneja';
$txt['permissionhelp_manage_smileys'] = 'Tämä antaa pääsyn hymiöiden hallintaan. Siellä voit lisätä, muokata ja poistaa hymiöitä ja hymiöpaketteja. Jos muokautetut viesti-ikonit on käytössä voit myös listä ja poistaa niitä tämän oikeuden avulla.';
$txt['permissionname_edit_news'] = 'Uutisten muokkaus';
$txt['permissionhelp_edit_news'] = 'The news function allows a random news line to appear on each screen. In order to use the news function, enable it in the forum settings.';
$txt['permissionname_access_mod_center'] = 'Pääsy valvontakeskukseen';
$txt['permissionhelp_access_mod_center'] = 'Tämän oikeuden omaavat pääsevät valvontakeskukseen, jossa heillä on yksinkertainen pääsy vavlonta tehtäviin. Huomaa että tämä oikeus ei anna yhtäkään valvonta oikeutta.';

$txt['permissiongroup_member_admin'] = 'Jäsenien hallinta';
$txt['permissionname_moderate_forum'] = 'keskustelualueen jäsenien hallinta';
$txt['permissionhelp_moderate_forum'] = 'Tämä oikeus sisältää kaikki oleelliset jäsenien hallintaan liittyvät toiminnot:<ul class="normallist"><li>pääsyn rekisteröintien hallintaan</li><li>pääsyn poistamaan jäseniä</li><li>laajempi profiilin tarkastelu, sisältäen IP-osoitteen jäljittämisen ja piilotetun online statuksen näkemisen</li><li>rekisteröintien aktivoimisen</li><li>tiedotteiden saamisen jäsenyyksien hyväksynnästä ja niiden hallinnoinnin</li><li>yksityisviestien estojen ohituksen</li><li>useita pienempiä asioita</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Jäsenryhmien hallinta';
$txt['permissionhelp_manage_membergroups'] = 'Tämä oikeus sallii muokata jäsenryhmiä ja liittää jäseniä niihin.';
$txt['permissionname_manage_permissions'] = 'Hallinnoida oikeuksia';
$txt['permissionhelp_manage_permissions'] = 'Tämä oikeus antaa luvan hallinnoida kaikkia oikeuksia koko keskustelualueella tai paikallisesti tietyllä alueella.';
$txt['permissionname_manage_bans'] = 'Hallinnoida estoja/banni-listaa';
$txt['permissionhelp_manage_bans'] = 'This permission allows a user to add or remove user names, IP addresses, hostnames and email addresses to or from a list of banned users. It also allows a user to view and remove log entries of banned users that attempted to login.';
$txt['permissionname_send_mail'] = 'Broadcast to multiple members';
$txt['permissionhelp_send_mail'] = 'Mass mail all forum members or just a few member groups by email or personal message (the latter requires the \'Send Personal Message\' permission).';
$txt['permissionname_issue_warning'] = 'Antaa varoituksia jäsenille';
$txt['permissionhelp_issue_warning'] = 'Mahdollisuus antaa varoituksia jäsennille. Varoitusjärjestelmä pitää olla käytössä.';

$txt['permissiongroup_profile'] = 'Jäsenten profiilit';
$txt['permissionname_profile_view'] = 'Profiilien katselu';
$txt['permissionhelp_profile_view'] = 'This permission allows users clicking on a user name to see a summary of profile settings, some statistics and all posts of the user.';
$txt['permissionname_profile_view_own'] = 'Oma profiili';
$txt['permissionname_profile_view_any'] = 'Kenen tahansa';
$txt['permissionname_profile_identity'] = 'Tilin asetusten muokkaus';
$txt['permissionhelp_profile_identity'] = 'Account settings are the basic settings of a profile, like password, email address, member group and preferred language.';
$txt['permissionname_profile_identity_own'] = 'Oma profiili';
$txt['permissionname_profile_identity_any'] = 'Kenen tahansa';
$txt['permissionname_profile_extra'] = 'Profiilin asetusten muokkaus';
$txt['permissionhelp_profile_extra'] = 'Profiilin asetukset ovat avatar, teeman asetukset, muistutukset ja yksityisviestit.';
$txt['permissionname_profile_extra_own'] = 'Oma profiili';
$txt['permissionname_profile_extra_any'] = 'Kenen tahansa';
$txt['permissionname_profile_title'] = 'Kustomoidun tittelin muokkaus';
$txt['permissionhelp_profile_title'] = 'Kustomoidut tittelit näkyvät viesteissä ja profiilissa.';
$txt['permissionname_profile_title_own'] = 'Oma profiili';
$txt['permissionname_profile_title_any'] = 'Kenen tahansa';
$txt['permissionname_profile_remove'] = 'Jäsenyyden poistaminen';
$txt['permissionhelp_profile_remove'] = 'Tämä toiminto sallii jäsenen poistaa oman tilinsa jos on valittuna \'Oma jäsenyys\'.';
$txt['permissionname_profile_remove_own'] = 'Oma jäsenyys';
$txt['permissionname_profile_remove_any'] = 'Kenen tahansa';
$txt['permissionname_profile_set_avatar'] = 'Select an avatar';
$txt['permissionhelp_profile_set_avatar'] = 'If enabled this will allow a user to select an avatar.';

$txt['permissiongroup_general_board'] = 'Yleiset';
$txt['permissionname_moderate_board'] = 'Alueen valvonta';
$txt['permissionhelp_moderate_board'] = 'Alueen valvonta lupa antaa pari pientä erikoisoikeutta. Oikeuksiin kuuluu lukittuihin aiheisiin vastaaminen, lukittujen äänestysten muokkaaminen ja katseleminen';

$txt['permissiongroup_topic'] = 'Aiheet';
$txt['permissionname_post_new'] = 'Uusien aiheiden aloittaminen';
$txt['permissionhelp_post_new'] = 'Tämä oikeuttaa uusien aiheiden lähettämiseen. Se ei oikeuta vastaamaan aiheisiin.';
$txt['permissionname_merge_any'] = 'Aiheiden yhdistäminen';
$txt['permissionhelp_merge_any'] = 'Merge two or more topics into one. The order of messages within the merged topic will be based on the time the messages were created. A user can only merge topics on those boards a user is allowed to merge. In order to merge multiple topics at once, a user has to enable quick moderation in their profile settings.';
$txt['permissionname_split_any'] = 'Aiheiden jakaminen';
$txt['permissionhelp_split_any'] = 'Aiheiden jakaminen kahdeksi erilliseksi aiheeksi.';
$txt['permissionname_send_topic'] = 'Aiheiden lähettäminen ystäville';
$txt['permissionhelp_send_topic'] = 'Tämä sallii aiheiden lähettämisen haluttuun sähköpostiosoitteeseen.';
$txt['permissionname_make_sticky'] = 'Pin topics';
$txt['permissionhelp_make_sticky'] = 'Pinned topics are topics that always remain on top of a board. They can be useful for announcements or other important messages.';
$txt['permissionname_move'] = 'Move topics';
$txt['permissionhelp_move'] = 'Aiheiden siirtämistä alueelta toiselle.';
$txt['permissionname_move_own'] = 'Oma aihe';
$txt['permissionname_move_any'] = 'Muut aiheet';
$txt['permissionname_lock'] = 'Aiheiden lukitseminen';
$txt['permissionhelp_lock'] = 'This permission allows a user to lock a topic. This can be done in order to make sure no one can reply to a topic. Only users with a \'Moderate board\' permission can still post in locked topics.';
$txt['permissionname_lock_own'] = 'Oma aihe';
$txt['permissionname_lock_any'] = 'Muut aiheet';
$txt['permissionname_remove'] = 'Aiheiden poistaminen';
$txt['permissionhelp_remove'] = 'Aiheiden poistamista kokonaisuudessaan. Huomio että tämä ei anna oikeutta valita vain tiettyjä viestejä deletoitavaksi.!';
$txt['permissionname_remove_own'] = 'Oma aihe';
$txt['permissionname_remove_any'] = 'Kaikkiin aiheisiin';
$txt['permissionname_post_reply'] = 'Lähettää vastauksia aiheisiin';
$txt['permissionhelp_post_reply'] = 'Sallii vastaamisen aiheisiin.';
$txt['permissionname_post_reply_own'] = 'Oma aihe';
$txt['permissionname_post_reply_any'] = 'Muut aiheet';
$txt['permissionname_modify_replies'] = 'Muokata vastauksia omissa aiheissa';
$txt['permissionhelp_modify_replies'] = 'Sallii itse aloittamansa aiheen vastauksen muokkaamisen.';
$txt['permissionname_delete_replies'] = 'Poistaa vastauksia omista aiheista';
$txt['permissionhelp_delete_replies'] = 'Antaa luvan poistaa kirjoituksia omista aiheista.';
$txt['permissionname_announce_topic'] = 'Tiedottaa aiheesta';
$txt['permissionhelp_announce_topic'] = 'This allows a user to send an announcement email about a topic to all members or to a few member groups.';

$txt['permissionname_approve_emails'] = 'Moderate Post by Email Failures';
$txt['permissionhelp_approve_emails'] = 'Allow moderators to access the Post by Email failure log to perform actions including approve, delete, view and bounce.  Note, since the system may not always know what board a post goes to, this permission should be only be given to members with full board access';
$txt['permissionname_postby_email'] = 'Post by Email';
$txt['permissionhelp_postby_email'] = 'This permission allows users to start new topics as well as reply to topic and PM notifications by email.';

$txt['permissiongroup_post'] = 'Viestit';
$txt['permissionname_delete'] = 'Viestien poistaminen';
$txt['permissionhelp_delete'] = 'Tämä sallii viestien poistamisen, mutta ei ensimmäistä viestiä aiheessa.';
$txt['permissionname_delete_own'] = 'Omat viestit';
$txt['permissionname_delete_any'] = 'Kenen tahansa viestit';
$txt['permissionname_modify'] = 'Viestien muokkaus';
$txt['permissionhelp_modify'] = 'Sallii viestien muokkaamisen';
$txt['permissionname_modify_own'] = 'Omat viestit';
$txt['permissionname_modify_any'] = 'Kenen tahansa viestit';
$txt['permissionname_report_any'] = 'Viesteistä raportointi valvojille';
$txt['permissionhelp_report_any'] = 'Tämä lisää linkin jokaiseen viestiin, mitä kautta voi raportoida viesteistä valvojille.';

$txt['permissiongroup_poll'] = 'Äänestykset';
$txt['permissionname_poll_view'] = 'Katsella äänestyksiä';
$txt['permissionhelp_poll_view'] = 'Tämä sallii äänestysten katselun. Ilman tätä oikeutta käyttäjä näkee vain aiheen ilman äänestystä.';
$txt['permissionname_poll_vote'] = 'Äänestäminen';
$txt['permissionhelp_poll_vote'] = 'Tämä sallii jäsenten äänestää.';
$txt['permissionname_poll_post'] = 'Äänestysten luominen';
$txt['permissionhelp_poll_post'] = 'Tämä oikeus sallii käyttäjän luoda uusia äänestyksiaä.';
$txt['permissionname_poll_add'] = 'Äänestysten lisääminen aiheisiin';
$txt['permissionhelp_poll_add'] = 'Tämä sallii äänestyksein lisäämisen aiheisiin jälkikäteen. Myös ensimmäisen viestin muokkaus pitää olla sallittuna.';
$txt['permissionname_poll_add_own'] = 'Omiin aiheisiin';
$txt['permissionname_poll_add_any'] = 'Kaikkiin aiheisiin';
$txt['permissionname_poll_edit'] = 'Äänestyksien muokkaus';
$txt['permissionhelp_poll_edit'] = 'Sallii muokata äänestyksiä.';
$txt['permissionname_poll_edit_own'] = 'Oma äänestys';
$txt['permissionname_poll_edit_any'] = 'Kaikkien';
$txt['permissionname_poll_lock'] = 'Äänestyksen lukitseminen';
$txt['permissionhelp_poll_lock'] = 'Pysäyttää äänestämisen.';
$txt['permissionname_poll_lock_own'] = 'Oma äänestys';
$txt['permissionname_poll_lock_any'] = 'Kaikkien';
$txt['permissionname_poll_remove'] = 'Äänestyksen poistaminen';
$txt['permissionhelp_poll_remove'] = 'Sallii äänestyksien poistamisen.';
$txt['permissionname_poll_remove_own'] = 'Oma äänestys';
$txt['permissionname_poll_remove_any'] = 'Kaikkien';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Save drafts of new posts';
$txt['permissionname_simple_post_draft'] = 'Save drafts of new posts';
$txt['permissionhelp_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionhelp_simple_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionname_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionname_simple_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionhelp_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionname_simple_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionhelp_pm_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid losing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionname_simple_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionhelp_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';
$txt['permissionhelp_simple_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';

$txt['permissiongroup_approval'] = 'Viestienvalvonta';
$txt['permissionname_approve_posts'] = 'Hyväksyä viestejä';
$txt['permissionhelp_approve_posts'] = 'Tämä oikeus mahdollistaa kaikkien hyväksyntää odottavien viesten hyväksymisen.';
$txt['permissionname_post_unapproved_replies'] = 'Lähettää vastauksia hyväksyttäväksi';
$txt['permissionhelp_post_unapproved_replies'] = 'Tämä oikeus antaa mahdollisuuden lähettää vastauksia moderaattorin hyväksyttäväksi. Viestejä ei näytetä ennen hyväksyntää.';
$txt['permissionname_post_unapproved_replies_own'] = 'Oma aihe';
$txt['permissionname_post_unapproved_replies_any'] = 'Muut aiheet';
$txt['permissionname_post_unapproved_topics'] = 'Lähettää aiheita hyväksyttäväksi';
$txt['permissionhelp_post_unapproved_topics'] = 'Tämä oikeus antaa mahdollisuuden lähettää aiheita, jotka täytyy hyväksyä';
$txt['permissionname_post_unapproved_attachments'] = 'Lähettää liitetiedostoja hyväksyttäväksi';
$txt['permissionhelp_post_unapproved_attachments'] = 'Tämä oikeus antaa mahdollisuuden liittää liitetiedostoja moderaattorin hyväksyttäväksi. Tiedostoja ei näytetä ennen hyväksyntää.';

$txt['permissiongroup_notification'] = 'Muistutukset ja sähköposti';
$txt['permissionname_mark_any_notify'] = 'Muistutukset uusista vastauksista';
$txt['permissionhelp_mark_any_notify'] = 'Sallii vastaanottaa tiedotteita sähköpostiin uusista vastauksista pyydettyihin aiheisiin.';
$txt['permissionname_mark_notify'] = 'Muistutukset uusista aiheista';
$txt['permissionhelp_mark_notify'] = 'Sallii vastaanottaa tiedotteita sähköpostiin uusista aiheista pyydetyiltä alueilta.';

$txt['permissiongroup_attachment'] = 'Liitteet';
$txt['permissionname_view_attachments'] = 'Katsella liitetiedostoja';
$txt['permissionhelp_view_attachments'] = 'Liitteet ovat tiedostoja joita voit liittää viesteihin. Tämän toiminnon voi ottaa käyttöön ja konfiguroida \'Liitetiedostot ja avatarkuvat\' osiossa. Koska liitetiedostoja ei ladata suoraan, voit estää tiedostojen lataamisen niiltä henkilöiltä joilla ei ole tätä oikeutta.';
$txt['permissionname_post_attachment'] = 'Liitteiden lisääminen viesteihin';
$txt['permissionhelp_post_attachment'] = 'Sallii liitteiden lisäämisen viesteihin.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Oikeuksien asetukset';
$txt['groups_manage_permissions'] = 'Member groups allowed to manage permissions';
$txt['permission_enable_deny'] = 'Salli asetus kieltää oikeuksia';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Sammuttamalla tämän ominaisuuden, \\\'Kiellä\\\'-oikeudet muuttuvat \\\'älä salli\\\' vaihtoehdoksi.';
$txt['permission_by_board_desc'] = 'Here you can set which permission profile a board uses. You can create new permission profiles from the &quot;Edit Profiles&quot; menu.';
$txt['permission_settings_desc'] = 'Täällä voit määrittää kuka saa muuttaa oikeuksia, sekä kuinka edistyneen oikeusjärjestelmän haluat.';
$txt['permission_enable_postgroups'] = 'Salli asettaa oikeuksia myös viestimääriin perustuville ryhmille';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Sulkemalla tämän ominaisuuden, poistat kaikki oikeudet viestimääriin perustuvilta ryhmiltä.';

$txt['permissions_post_moderation_desc'] = 'From this page you can easily change which groups have their posts moderated for a particular permission profile.';
$txt['permissions_post_moderation_deny_note'] = 'Huomaa että vaikka sinulla on käytössä yksityiskohtaiset oikeudet et voi asettaa estoja tältä sivulta. Muokkaa oikeuksia suoraan jos haluat asetaa estoja.';
$txt['permissions_post_moderation_select'] = 'Valitse profiili';
$txt['permissions_post_moderation_new_topics'] = 'Uusia aiheita';
$txt['permissions_post_moderation_replies_own'] = 'Vastaukset omiin';
$txt['permissions_post_moderation_replies_any'] = 'Vastaukset kaikkiin';
$txt['permissions_post_moderation_attachments'] = 'Liitteet';
$txt['permissions_post_moderation_legend'] = 'Selitys';
$txt['permissions_post_moderation_allow'] = 'Voi tehdä';
$txt['permissions_post_moderation_moderate'] = 'Voi tehdä, mutta vaatii hyväksynnän';
$txt['permissions_post_moderation_disallow'] = 'Ei voi tehdä';
$txt['permissions_post_moderation_group'] = 'Ryhmä';

$txt['auto_approve_topics'] = 'Post new topics without requiring approval';
$txt['auto_approve_replies'] = 'Post replies to topics without requiring approval';
$txt['auto_approve_attachments'] = 'Post attachments without requiring approval';
