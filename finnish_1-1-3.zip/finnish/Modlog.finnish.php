<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Päivä';
$txt['modlog_member'] = 'Jäsen';
$txt['modlog_position'] = 'Asema';
$txt['modlog_action'] = 'Tapahtuma';
$txt['modlog_ip'] = 'IP';
$txt['modlog_search_result'] = 'Haun tulokset';
$txt['modlog_total_entries'] = 'Kokonaismerkinnät';
$txt['modlog_ac_approve_topic'] = 'Hyväksyi käyttäjän &quot;{member}&quot; aiheen &quot;{topic}&quot;';
$txt['modlog_ac_unapprove_topic'] = 'Unapproved topic &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_approve'] = 'Hyväksyi käyttäjän &quot;{member}&quot; viestin &quot;{subject}&quot; aiheessa &quot;{topic}&quot;';
$txt['modlog_ac_unapprove'] = 'Unapproved message &quot;{subject}&quot; in &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_lock'] = 'Lukitsi aiheen &quot;{topic}&quot;';
$txt['modlog_ac_warning'] = 'Varoitus jäsenelle {member} viestistä &quot;{message}&quot; ';
$txt['modlog_ac_unlock'] = 'Avasi aiheen &quot;{topic}&quot;';
$txt['modlog_ac_sticky'] = 'Pinned &quot;{topic}&quot;';
$txt['modlog_ac_unsticky'] = 'Unpinned &quot;{topic}&quot;';
$txt['modlog_ac_delete'] = 'Poisti käyttäjän &quot;{member}&quot; kirjoittaman viestin &quot;{subject}&quot; aiheesta &quot;{topic}&quot;';
$txt['modlog_ac_delete_member'] = 'Poisti käyttäjän &quot;{name}&quot;';
$txt['modlog_ac_remove'] = 'Poisti aiheen &quot;{topic}&quot; alueelta &quot;{board}&quot;';
$txt['modlog_ac_modify'] = 'Muokkasi käyttäjän &quot;{member}&quot; viestiä &quot;{message}&quot;';
$txt['modlog_ac_merge'] = 'Loi aiheen &quot;{topic}&quot; yhdistämällä aiheita';
$txt['modlog_ac_split'] = 'Jakoi viestejä aiheesta &quot;{topic}&quot; uudeksi aiheeksi &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = 'Siirsi aiheen &quot;{topic}&quot; alueelta &quot;{board_from}&quot; alueelle &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Muokkasi käyttäjän &quot;{member}&quot; profiilia';
$txt['modlog_ac_pruned'] = 'Poisti viestejä jotka olivat vanhempia kuin {days} päivää';
$txt['modlog_ac_news'] = 'Muokkasi uutisia';
$txt['modlog_enter_comment'] = 'Lisäsi valvojien kommentin';
$txt['modlog_moderation_log'] = 'Valvontalogi';
$txt['modlog_moderation_log_desc'] = 'Alla on lista kaikista valvojien tekemistä toimenpiteistä.<br /><strong>>Huomaa:</strong>> Merkintöjä ei voi poistaa ennen kuin ne ovat vuorokauden vanhoja.';
$txt['modlog_no_entries_found'] = 'Ei merkintöjä valvontalogissa';
$txt['modlog_remove'] = 'Poista valitut';
$txt['modlog_removeall'] = 'Clear Log';
$txt['modlog_remove_selected_confirm'] = 'Are you sure you want to delete the selected log entries?';
$txt['modlog_remove_all_confirm'] = 'Are you sure you want to completely clear the log?';
$txt['modlog_go'] = 'Mene';
$txt['modlog_add'] = 'Lisää';
$txt['modlog_search'] = 'Pikahaku';
$txt['modlog_by'] = 'Hakukriteeri';
$txt['modlog_id'] = '<em>Poistettu - ID:%1$d</em>';

$txt['modlog_ac_add_warn_template'] = 'Lisäsi varoituspohjan: &quot;{template}&quot; ';
$txt['modlog_ac_modify_warn_template'] = 'Muokkasi varoituspohjaa: &quot;{template}&quot; ';
$txt['modlog_ac_delete_warn_template'] = 'Poisti varoituspohjan: &quot;{template}&quot; ';

$txt['modlog_ac_ban'] = 'Lisäsi estoja:';
$txt['modlog_ac_ban_update'] = 'Edited ban triggers:';
$txt['modlog_ac_ban_remove'] = 'Removed ban triggers:';
$txt['modlog_ac_ban_trigger_member'] = ' <em>Jäsen:</em> {member}';
$txt['modlog_ac_ban_trigger_email'] = ' <em>Sähköposti:</em> {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = '<em>IP:</em> {ip_range} ';
$txt['modlog_ac_ban_trigger_hostname'] = ' <em>Isäntänimi:</em> {hostname}';

$txt['modlog_admin_log'] = 'Ylläpitologi';
$txt['modlog_admin_log_desc'] = 'Alla on lista kaikista ylläpitäjien suorittamista toimenpiteist&auml.<br /><strong>>Huomaa:</strong>> Merkintöjä ei voi poistaa ennen kuin ne ovat vuorokauden vanhoja.';
$txt['modlog_admin_log_no_entries_found'] = 'Ylläpitologi on tyhjä';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Päivitti keskustelualueen versioon {version}';
$txt['modlog_ac_install'] = 'Asensi version {version}';
$txt['modlog_ac_add_board'] = 'Loi uuden alueen: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Muokkasi aluetta &quot;{board}&quot;';
$txt['modlog_ac_delete_board'] = 'Poisti alueen &quot;{boardname}&quot;';
$txt['modlog_ac_add_cat'] = 'Loi uuden kategorian &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Muokkasi kategoriaa &quot;{catname}&quot;';
$txt['modlog_ac_delete_cat'] = 'Poisti kategorian &quot;{catname}&quot;';

$txt['modlog_ac_delete_group'] = 'Poisti ryhmän &quot;{group}&quot;';
$txt['modlog_ac_add_group'] = 'Loi ryhmän &quot;{group}&quot;';
$txt['modlog_ac_edited_group'] = 'Muokkasi ryhmää &quot;{group}&quot;';
$txt['modlog_ac_added_to_group'] = 'Lisäsi käyttäjän &quot;{member}&quot; ryhmään &quot;{group}&quot;';
$txt['modlog_ac_removed_from_group'] = 'Poisti käyttäjän &quot;{member}&quot; ryhmästä &quot;{group}&quot;';
$txt['modlog_ac_removed_all_groups'] = 'Poisti käyttäjän &quot;{member}&quot; kaikista ryhmistä';

$txt['modlog_ac_remind_member'] = 'Lähetti aktivointimuistutuksen käyttjälle &quot;{member}&quot;';
$txt['modlog_ac_approve_member'] = 'Hyväksyi tai aktivoi käyttäjän &quot;{member}&quot;';
$txt['modlog_ac_newsletter'] = 'Lähetä uutiskirje';

$txt['modlog_ac_install_package'] = 'Asensi uuden paketin: &quot;{package}&quot;, versio {version} ';
$txt['modlog_ac_upgrade_package'] = 'Päivitti paketin: &quot;{package}&quot; versioon {version} ';
$txt['modlog_ac_uninstall_package'] = 'Poisti paketin asennuksen: &quot;{package}&quot;, versio {version} ';

$txt['modlog_ac_database_backup'] = 'Database backup taken by {member}.';
$txt['modlog_ac_editing_theme'] = '{member} edited a theme.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Palautti aiheen &quot;{topic}&quot; alueelta &quot;{board}&quot; alueelle &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Palautti viestejä aiheen &quot;{subject}&quot; aiheeseen &quot;{topic}&quot; alueella &quot;{board}&quot;.';

$txt['modlog_parameter_guest'] = '<em>Vieras</em>';

$txt['modlog_ac_approve_attach'] = 'Approved &quot;{filename}&quot; in &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Removed unapproved &quot;{filename}&quot; in &quot;{message}&quot;';