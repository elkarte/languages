<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Sorry, we can\'t let you access this section. We can\'t even tell you if it exists. You\'re welcome to visit the main page and choose your way from there.';
$txt['not_guests'] = 'Sorry, this action is not available to guests.';

$txt['mods_only'] = 'Only moderators can use the direct remove function, please remove this message through the modify feature.';
$txt['no_name'] = 'You didn\'t fill the name field out. We can\'t let you continue without a name, sorry.';
$txt['no_email'] = 'You didn\'t fill the email field out. We can\'t let you continue without an email, sorry.';
$txt['topic_locked'] = 'Tämä aihe on lukittu, joten et voi muokata etkä jatkaa sitä.';
$txt['no_password'] = 'Salasana puuttuu';
$txt['passwords_dont_match'] = 'Salasanat eivät vastanneet toisiaan.';
$txt['register_to_use'] = 'Pahoittelemme, sinun täytyy rekisteröityä ennen kuin voit käyttää tätä toimintoa.';
$txt['username_reserved'] = 'The user name you tried to use contains the reserved name \'%1$s\'. Please try another user name.';
$txt['numbers_one_to_nine'] = 'Tämä kenttä hyväksyy ainoastaan numerot väliltä 0-9';
$txt['not_a_user'] = 'Käyttäjää jonka profiilia yrität katsella, ei ole olemassa. ';
$txt['not_a_topic'] = 'Tätä aihetta ei ole olemassa tällä keskustelualueella.';
$txt['not_approved_topic'] = 'Tätä aihetta ei ole vielä hyväksytty.';
$txt['email_in_use'] = 'Tämä sähköpostiosoite (%1$s) on käytössä jollain jäsenellämme. Jos tämä ei mielestäsi voi pitää paikkansa, mene kirjautumissivulle ja käytä salasanan palauttajaa sillä osoitteella.';

$txt['didnt_select_vote'] = 'Et valinnut äänestysvaihtoehtoa';
$txt['poll_error'] = 'Something isn\'t working, sorry: either that poll doesn\'t exist, the poll has been locked, or you tried to vote twice.';
$txt['locked_by_admin'] = 'Ylläpito on lukinnut aiheen. Et voi avata sitä';
$txt['not_enough_posts_karma'] = 'Viestimääräsi ei riitä karman muokkaamiseen - tarvitset vänhintään %1$d.';
$txt['cant_change_own_karma'] = 'Valitettavasti oman karman muokkaaminen ei ole sallittua.';
$txt['karma_wait_time'] = 'Et voi toistaa toimintoa ennekuin olet odottanut %1$s %2$s.';
$txt['feature_disabled'] = 'Pahoittelut, tämä toiminto on estetty.';
$txt['feature_no_exists'] = 'Sorry, this feature doesn\'t exist.';
$txt['couldnt_connect'] = 'Palvelimeen ei saatu yhteyttä, tai tiedostoa ei löydetty';
$txt['no_board'] = 'Määrittelemääsi aluetta ei ole olemassa';
$txt['no_message'] = 'The message is no longer available';
$txt['no_topic_id'] = 'Valitsit virheellisen aihe ID:n.';
$txt['split_first_post'] = 'Aihetta ei voi jakaa ensimmäisestä viestistä.';
$txt['topic_one_post'] = 'Tässä aiheessa on vain yksi viesti, joten jakaminen on mahdotonta';
$txt['no_posts_selected'] = 'Viestejä ei ole valittuna';
$txt['selected_all_posts'] = 'Aihetta ei voida jakaa. Valitsit kaikki viestit jaettavaksi.';
$txt['cant_find_messages'] = 'Viestejä ei löydy';
$txt['cant_find_user_email'] = 'Käyttäjän sähköpostiosoitetta ei löytynyt.';
$txt['cant_insert_topic'] = 'Ei pysty liittämään aiheeseen';
$txt['session_timeout'] = 'Your session timed out while posting. Please go back and try again.';
$txt['session_timeout_file_upload'] = 'Your session timed out while uploading the file. Please try again.';
$txt['no_files_uploaded'] = 'There are no files to upload.';
$txt['session_verify_fail'] = 'Session verification failed. Please try logging out and back in again, and then try again.';
$txt['verify_url_fail'] = 'Unable to verify referring URL: %1$s. Please go back and try again.';
$txt['token_verify_fail'] = 'Token verification failed. Please go back and try again.';
$txt['guest_vote_disabled'] = 'Vieraat eivät voi äänestää tässä äänestyksessä.';

$txt['cannot_access_mod_center'] = 'Valitettavasti oikeutesi eivät riitä valvonta-alueelle pääsyyn.';
$txt['cannot_admin_forum'] = 'Valitettavasti oikeutesi eivät riitä ylläpitoalueelle pääsyyn. ';
$txt['cannot_announce_topic'] = 'Sinulla ei ole oikeutta tiedottaa aiheista tällä alueella.';
$txt['cannot_approve_posts'] = 'Sinulla ei ole oikeutta hyväksyä tiedostoja.';
$txt['cannot_post_unapproved_attachments'] = 'Sinulla ei ole oikeutta lisätä tarkastamattomia liitteitä.';
$txt['cannot_post_unapproved_topics'] = 'Sinulla ei ole oikeutta aloittaa tarkastamattomia aiheita.';
$txt['cannot_post_unapproved_replies_own'] = 'Sinulla ei ole oikeutta lähettää tarkastamattomia vastauksia aiheisiisi.';
$txt['cannot_post_unapproved_replies_any'] = 'Sinulla ei ole oikeutta lähettää tarkastamattomia vastauksia muiden aiheisiin.';
$txt['cannot_calendar_edit_any'] = 'Sinulla ei ole oikeutta muokata kalenterin tapahtumia';
$txt['cannot_calendar_edit_own'] = 'Valitettavasti oikeutesi eivät riitä omien tapahtumiesi muokkaamiseen. ';
$txt['cannot_calendar_post'] = 'Valitettavasti tapahtumien lisääminen ei tällä hetkellä ole sallittua.';
$txt['cannot_calendar_view'] = 'Valitettavasti oikeutesi eivät riitä kalenterin katseluun.';
$txt['cannot_remove_any'] = 'Valitettavasti sinulla ei ole oikeuksia poistaa mitä tahansa aiheita. Varmista ettei aihetta ole juuri siirretty alueelta toiselle. ';
$txt['cannot_remove_own'] = 'Et voi poistaa omia aiheitasi tällä alueella. Varmista ettei aihetta ole juuri siirretty toiselle alueelle. ';
$txt['cannot_edit_news'] = 'Sinulla ei ole oikeutta muokata tämän foorumin uutisia.';
$txt['cannot_pm_read'] = 'Valitettavasti et voi lukea yksityisviestejäsi.';
$txt['cannot_pm_send'] = 'Sinulla ei ole oikeutta lähettää yksityisviestejä.';
$txt['cannot_karma_edit'] = 'Sinulla ei ole oikeuksia muokata muiden karmaa.';
$txt['cannot_like_posts'] = 'You are not allowed to like messages in this board.';
$txt['cannot_lock_any'] = 'Et valitettavasti voi lukita mitä tahansa aihetta täällä. ';
$txt['cannot_lock_own'] = 'Valitettavasti et voi lukita omia aiheitasi täällä.';
$txt['cannot_make_sticky'] = 'You don\'t have permission to pin this topic.';
$txt['cannot_manage_attachments'] = 'Sinulla ei ole oikeuksia hallinnoida liitetiedostoja tai avatar-kuvia.';
$txt['cannot_manage_bans'] = 'Sinulla ei ole oikeuksia muokata porttikieltoja.';
$txt['cannot_manage_boards'] = 'Sinulla ei ole oikeuksia hallinnoida alueita ja kategorioita.';
$txt['cannot_manage_membergroups'] = 'You don\'t have permission to modify or assign member groups.';
$txt['cannot_manage_permissions'] = 'Sinulla ei ole oikeutta hallinoida oikeuksia.';
$txt['cannot_manage_smileys'] = 'Sinulla ei ole oikeuksia hallinnoida hymiöitä ja viestikuvakkeita.';
$txt['cannot_mark_any_notify'] = 'Oikeutesi eivät riitä tämän aiheen muistutusten tilaamiseen. ';
$txt['cannot_mark_notify'] = 'Valitettavasti oikeutesi eivät riitä tämän alueen muistutusten tilaamiseen. ';
$txt['cannot_merge_any'] = 'Oikeutesi eivät riitä aiheiden yhdistämiseen yhdella tai useammalla valituista alueista.';
$txt['cannot_moderate_forum'] = 'Oikeutesi eivät riitä tämän alueen valvontatoimintoihin.';
$txt['cannot_moderate_board'] = 'Sinulla ei ole oikeuksia moderoida tätä aluetta.';
$txt['cannot_modify_any'] = 'Sinulla ei ole oikeutta muokata aivan kaikkia viestejä.';
$txt['cannot_modify_own'] = 'Valitettavasti sinulla ei ole oikeutta muokata omia viestejäsi.';
$txt['cannot_modify_replies'] = 'Vaikka tämä on vastaus omaan aiheeseesi, sinulla ei ole oikeutta muokata sitä.';
$txt['cannot_move_own'] = 'Sinulla ei ole oikeutta siirtää omia aiheitasi tällä alueella.';
$txt['cannot_move_any'] = 'Sinulla ei ole oikeutta siirtää aiheita tällä alueella.';
$txt['cannot_poll_add_own'] = 'Sinulla ei ole oikeutta lisätä äänestyksiä omiin aiheisiisi tällä alueella.';
$txt['cannot_poll_add_any'] = 'Sinulla ei ole oikeutta lisätä äänestystä tähän aiheeseen.';
$txt['cannot_poll_edit_own'] = 'Oikeutesi eivät riitä tämän äänestyksen muokkaamiseen, vaikka se onkin omasi.';
$txt['cannot_poll_edit_any'] = 'Sinulta on evätty oikeus muokata äänestyksiä tällä alueella.';
$txt['cannot_poll_lock_own'] = 'Sinulla ei ole oikeutta lukita omia äänestyksiäsi tällä alueella.';
$txt['cannot_poll_lock_any'] = 'Valitettavasti et voi lukita aivan mitä tahansa äänestystä.';
$txt['cannot_poll_post'] = 'Sinulla ei ole oikeutta aloittaa äänestyksiä tällä alueella.';
$txt['cannot_poll_remove_own'] = 'Sinulla ei ole oikeutta poistaa tätä äänestystä aiheestasi.';
$txt['cannot_poll_remove_any'] = 'Valitettavasti et voi poistaa mitä tahansa äänestystä tällä alueella.';
$txt['cannot_poll_view'] = 'Sinulla ei ole oikeutta tarkastella äänestyksiä tällä alueella.';
$txt['cannot_poll_vote'] = 'Valitettavasti sinulla ei ole oikeutta äänestää tällä alueella.';
$txt['cannot_post_attachment'] = 'Valitettavasti sinulla ei ole oikeutta lisätä liitetiedostoja täällä.';
$txt['cannot_post_new'] = 'Valitettavasti sinulla ei ole oikeutta aloittaa uusia aiheita tällä alueella.';
$txt['cannot_post_new_board'] = 'Sorry, you cannot post new topics in the board %1$s.';
$txt['cannot_post_reply_any'] = 'Sinulla ei ole oikeutta lähettää vastauksia tälle alueelle.';
$txt['cannot_post_reply_own'] = 'Sinulla ei ole oikeutta lähettää vastauksia edes omiin aiheisiisi tällä alueella.';
$txt['cannot_profile_remove_own'] = 'Valitettavasti oikeutesi eivät riitä oman profiilisi poistamiseen. ';
$txt['cannot_profile_remove_any'] = 'You don\'t have the appropriate permissions to remove accounts.';
$txt['cannot_profile_extra_any'] = 'Sinulla ei ole tarvittavia oikeuksia muokata profiilin asetuksia.';
$txt['cannot_profile_identity_any'] = 'Sinulla ei ole oikeuksia muokata jäsenyyden asetuksia.';
$txt['cannot_profile_title_any'] = 'Sinulla ei ole oikeutta muokata muiden titteleitä.';
$txt['cannot_profile_extra_own'] = 'Valitettavasti sinulla ei ole tarvittavia oikeuksia muokata profiilisi asetuksia.';
$txt['cannot_profile_identity_own'] = 'Et voi muuttaa nimeäsi juuri nyt.';
$txt['cannot_profile_title_own'] = 'Sinulla ei ole vaadittavia oikeuksia muokata omaa titteliäsi.';
$txt['cannot_profile_set_avatar'] = 'You are not permitted to change your avatar.';
$txt['cannot_profile_view_own'] = 'Valitettavasti et voi tarkastella omaa profiliasi.';
$txt['cannot_profile_view_any'] = 'Valitettavasti et voi tarkastella kenen tahansa profiilia.';
$txt['cannot_delete_own'] = 'Ouch, sorry, you cannot delete your posts on this board.';
$txt['cannot_delete_replies'] = 'Sinulla ei ole oikeutta poistaa näitä viestejä, vaikka ne ovatkin vastauksia aiheeseesi.';
$txt['cannot_delete_any'] = 'Ouch, sorry, you cannot delete posts in this board.';
$txt['cannot_report_any'] = 'Sinulla ei ole oikeutta raportoida viesteistä tällä alueella.';
$txt['cannot_search_posts'] = 'Sinulla ei ole oikeutta haun käyttöön tällä alueella.';
$txt['cannot_send_mail'] = 'Sinulla ei ole vaadittavia oikeuksia sähköpostin lähettämiseen kaikille.';
$txt['cannot_issue_warning'] = 'Valitettavasti sinulla ei ole oikeutta jakaa varoituksia.';
$txt['cannot_send_topic'] = 'Pahoittelut, mutta ylläpito on estänyt viestien lähettämisen tällä alueella.';
$txt['cannot_send_email_to_members'] = 'Sorry, but the administrator has disallowed sending emails on this board.';
$txt['cannot_split_any'] = 'Aivan minkä tahansa aiheen jakaminen ei ole sallittua tällä alueella.';
$txt['cannot_view_attachments'] = 'Näyttää siltä, että sinulla ei ole oikeutta tarkastella liitetiedostoja tällä alueella.';
$txt['cannot_view_mlist'] = 'You can\'t view the member list because you don\'t have permission to.';
$txt['cannot_view_stats'] = 'Sinulla ei ole oikeutta tarkastella foorumin tilastoja.';
$txt['cannot_who_view'] = 'Valitettavasti sinulla ei ole vaadittavia oikeuksia tämän toiminnon käyttämiseen.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = ' We can\'t find that theme.';
$txt['theme_dir_wrong'] = 'Oletusteeman hakemisto on väärä. Ole hyvä ja korjaa se klikkaamalla tätä tekstiä.';
$txt['registration_disabled'] = 'Valitettavasti tämä foorumi ei hyväksy uusia käyttäjiä tällä hetkellä.';
$txt['registration_agreement_missing'] = 'The registration agreement file, agreement.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Valitettavasti tälle jäsenelle ei ole asetettu salaista kysymystä.';
$txt['poll_range_error'] = 'Valitettavasti äänestyksen pituuden on ylitettävä 0 päivää.';
$txt['delFirstPost'] = 'You are not allowed to delete the first post in a topic.<p>If you want to delete this topic, click on the Remove link, or ask a moderator/administrator to do it for you.</p>';
$txt['login_cookie_error'] = 'Et onnistunut kirjautumaan sisälle. Tarkista keksi/cookie asetuksesi.';
$txt['incorrect_answer'] = 'Et vastannut kysymykseesi oikein. Siirry takaisin ja yritä uudestaan, tai klikkaa takaisin kahdesti ja yritä oletusvaihtoehtoa palauttaaksesi salasanasi.';
$txt['no_mods'] = 'Valvojia ei löytynyt!';
$txt['parent_not_found'] = 'Alueen rakenne on väärä: yläkategoriaa ei löytynyt';
$txt['modify_post_time_passed'] = 'Et voi muokata tätä viestiä koska aikaraja on kulunut umpeen.';

$txt['calendar_off'] = 'Kalenteriin ei pääse tällä hetkellä, sillä sen käyttö on estetty.';
$txt['calendar_export_off'] = 'You cannot export calendar events because that feature is currently disabled.';
$txt['invalid_month'] = 'Virheellinen kuukausi.';
$txt['invalid_year'] = 'Virheellinen vuosi';
$txt['invalid_day'] = 'Virheellinen päivä.';
$txt['event_month_missing'] = 'Tapahtuman kuukausi puuttuu';
$txt['event_year_missing'] = 'Tapahtuman vuosi puuttuu.';
$txt['event_day_missing'] = 'Tapahtuman päivä puuttuu.';
$txt['event_title_missing'] = 'Tapahtuman otsikko puuttuu.';
$txt['invalid_date'] = 'Virheellinen päivämäärä.';
$txt['no_event_title'] = 'Tapahtuman otsikkoa ei ole syötetty.';
$txt['missing_board_id'] = 'Alueen ID puuttuu.';
$txt['missing_topic_id'] = 'Aiheen ID puuttuu.';
$txt['topic_doesnt_exist'] = 'Aihetta ei ole olemassa.';
$txt['not_your_topic'] = 'Tämä ei ole sinun aloittama aihe.';
$txt['board_doesnt_exist'] = 'Aluetta ei ole olemassa.';
$txt['no_span'] = 'Aikajakso toiminto on pois päältä.';
$txt['invalid_days_numb'] = 'Virheellinen määrä päiviä aikajaksolle.';

$txt['moveto_noboards'] = 'Ei ole aluetta jonne siirtää tätä aihetta!';
$txt['topic_already_moved'] = 'This topic %1$s has been moved to the board %2$s, please check its new location before moving it again.';

$txt['already_activated'] = 'We\'d love to process your request, but your account has already been activated.';
$txt['still_awaiting_approval'] = 'Jäsenyytesi odottaa edelleen ylläpidon hyväksyntää.';

$txt['invalid_email'] = 'Virheellinen sähköpostiosoite / osoitealue.<br />Esimerkki asianmukaisesta osoitteesta: bill.gates@microsoft.com.<br />Esimerkki asianmukaisesta osoitealueesta: *@*.microsoft.com';
$txt['invalid_expiration_date'] = 'Päättymispäivä on virheellinen';
$txt['invalid_hostname'] = 'Virheellinen isäntäkoneen nimi / alue.<br />Esimerkki asianmukaisesta isäntäkoneen nimestä: proxy4.microsoft.com<br />Esimerkki asianmukaisesta isäntäkoneen nimialueesta: *.microsoft.com';
$txt['invalid_ip'] = 'Virheellinen IP / IP alue.<br />Esimerkki asianmukaisesta IP-osoitteesta: 127.0.0.1<br />Esimerkki asianmukaisesta IP alueesta: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Virheellinen IP / IP-alue.<br />Esimerkki IP-osoitteesta: 127.0.0.1<br />Esimerkki IP-alueesta: 127.0.0.* ';
$txt['invalid_username'] = 'Jäsenen nimeä ei löytynyt';
$txt['no_user_selected'] = 'Member not found';
$txt['no_ban_admin'] = 'Hey! We can\'t let you ban an admin. If you are certain about this, demote them first!';
$txt['no_bantype_selected'] = 'Porttikiellon tyyppiä ei valittu';
$txt['ban_not_found'] = 'Porttikieltoa ei löydetty';
$txt['ban_unknown_restriction_type'] = 'Rajoituksen tyyppi tuntematon';
$txt['ban_name_empty'] = 'Porttikiellon nimi puuttu';
$txt['ban_id_empty'] = 'Dang, sorry. We tried to find this ban ID, but it can\'t be found.';
$txt['ban_group_id_empty'] = 'A ban group needs a group ID, and this group didn\'t have any.';
$txt['ban_no_triggers'] = 'Did you forget to select ban triggers? We need at least one, and we haven\'t got any.';
$txt['ban_ban_item_empty'] = 'Ban trigger not found';
$txt['impossible_insert_new_bangroup'] = 'An error occurred while inserting the new ban';

$txt['like_heading_error'] = 'Error in Likes';
$txt['like_wait_time'] = 'Sorry, you can\'t repeat a like action without waiting %1$s %2$s.';
$txt['like_unlike_error'] = 'Oops, there was an error while liking/unliking the post';
$txt['cant_like_yourself'] = 'Liking your own posts ... it\'s like laughing at your own jokes when there is no one else around  ... lol ... Wait did I just lol myself?';

$txt['ban_name_exists'] = 'Samanniminen porttikielto (%1$s) on jo olemassa. Vaihda nimi toiseen.';
$txt['ban_trigger_already_exists'] = 'Tämä esto (%1$s) on jo olemassa %2$s';
$txt['attach_check_nag'] = 'Unable to continue due to incomplete data (%1$s).';

$txt['recycle_no_valid_board'] = 'Sopivaa aluetta poistettujen viestien säilyttämiseen ei valittu.';
$txt['post_already_deleted'] = 'The topic or message has already been moved to the recycle board. Are you sure you want to delete it completely?<br />If so follow <a href="%1$s">this link</a>';

$txt['login_threshold_fail'] = 'Pahoittelumme, mutta olet ylittänyt sallitun kirjautumisyritysten määrän. Yritä uudelleen myöhemmin.';
$txt['login_threshold_brute_fail'] = 'Sorry, but you\'ve reached your login attempts threshold.  Please wait 30 seconds and try again.';

$txt['who_off'] = 'We would love to let you peek at Who\'s Online, but unfortunately right now it\'s disabled.';

$txt['merge_create_topic_failed'] = 'Dang, sorry. We tried, we really did, but creating a new topic failed.';
$txt['merge_need_more_topics'] = 'Merge topics requires at least two topics to merge, but we didn\'t get two. Please try again.';

$txt['post_WaitTime_broken'] = 'Tästä IP osoiteesta lähetettiin viesti alle %1$d sekuntia sitten. Yritä myöhemmin uudelleen.';
$txt['register_WaitTime_broken'] = 'Sinä rekisteröidyit juuri %1$d sekuntia sitten!';
$txt['login_WaitTime_broken'] = 'Sinun on odotettava noin %1$d sekuntia ennen uudelleenkirjautumista.';
$txt['pm_WaitTime_broken'] = 'Viimeisin yksityisviesti IPstäsi lähettettiin alle %1$d sekuntia sitten. Yritä myöhemmin uudelleen.';
$txt['reporttm_WaitTime_broken'] = 'Viimeisin viestin raportointi IPstäsi tehtiin alle %1$d sekuntia sitten. Yritä myöhemmin uudelleen.';
$txt['sendtopic_WaitTime_broken'] = 'Viimeisin aihe IPstäsi lähettettiin alle %1$d sekuntia sitten. Yritä myöhemmin uudelleen.';
$txt['sendmail_WaitTime_broken'] = 'Viimeisin sähköposti IPstäsi lähettettiin alle %1$d sekuntia sitten. Yritä myöhemmin uudelleen.';
$txt['search_WaitTime_broken'] = 'Edellinen hakusi tapahtui %1$d sekunttia sitten. Yritä myöhemmin uudelleen.';
$txt['remind_WaitTime_broken'] = 'Your last reminder was less than %1$d seconds ago. Please try again later.';
$txt['contact_WaitTime_broken'] = 'The last time you tried to use the contact form was less than %1$d seconds ago. Please try again later.';

$txt['topic_gone'] = 'We tried very hard to find the topic or board you are looking for, but it\'s nowhere to be found. It appears to be either missing or off limits to you.';
$txt['theme_edit_missing'] = 'We tried very hard to find the file you are trying to edit, but it can\'t be found.';

$txt['no_dump_database'] = 'Sorry, we can\'t let you make database backups. Only administrators can.';
$txt['pm_not_yours'] = 'Yksityisviesti jota yrität lainata ei ole sinun tai sitä ei ole olemassa. Ole hyvä ja palaa takaisin ja yritä uudestaan.';
$txt['mangled_post'] = 'Virheellinen lomakkeen data - Ole hyvä ja palaa takaisin ja yritä uudestaan.';
$txt['too_many_groups'] = 'Sorry, you selected too many groups, please remove some.';
$txt['post_upload_error'] = 'The post data is missing. This error could be caused by trying to submit a file larger than allowed by the server.  Please contact your administrator if this problem continues.';
$txt['quoted_post_deleted'] = 'Viestiä jota yrität lainata ei ole olemassa, on poistettu, tai ei ole enää sinun luettavissasi.';
$txt['pm_too_many_per_hour'] = 'Olet lähettänyt enimmäismäärän %1$d yksityisviestejä tuntia kohden.';
$txt['labels_too_many'] = '%1$s viestiä sisältää jo enimmäismäärän leimoja!';

$txt['register_only_once'] = 'Pahoittelumme, et voi rekisteröidä useampia tunnuksia samaan aikaan, samalta koneelta.';
$txt['admin_setting_coppa_require_contact'] = 'Sinun on annettava yhteystiedoksi joko postiosoite tai faksinumero, mikäli edellytät vanhempien hyväksyntää.';

$txt['error_long_name'] = 'Käyttämäsi nimi oli liian pitkä.';
$txt['error_no_name'] = 'Nimeä ei annettu lainkaan.';
$txt['error_bad_name'] = 'Valitsemaasi nimeä ei voi käyttää, sillä se on, tai se sisältää ylläpidon varaaman nimen.';
$txt['error_no_email'] = 'Sähköpostiosoite puuttuu.';
$txt['error_bad_email'] = 'Sähköpostiosoite on virheellinen.';
$txt['error_email'] = 'email address';
$txt['error_message'] = 'viesti';
$txt['error_no_event'] = 'Tapahtuman nimi puuttuu.';
$txt['error_no_subject'] = 'Aihe puuttuu.';
$txt['error_no_question'] = 'Äänestyksestä puuttuvat kysymykset.';
$txt['error_no_message'] = 'Viestikenttä jätettiin tyhjäksi.';
$txt['error_long_message'] = 'Viestissä on liikaa merkkejä. Suurin sallittu määrä on (%1$s).';
$txt['error_no_comment'] = 'Et antanut kommenttia.';
$txt['error_post_too_long'] = 'Your message is too long. Please enter a maximum of 255 characters.';
$txt['error_session_timeout'] = 'Istuntosi vanheni sillä aikaa kun kirjoitit. Ole hyvä ja yritä lähettää viesti uudelleen.';
$txt['error_no_to'] = 'Vastaanottaja puuttuu.';
$txt['error_bad_to'] = 'Yhtä tai useampaa vastaanottajista ei löydy.';
$txt['error_bad_bcc'] = 'Yhtä tai useampaa kopion vastaanottajista ei löydy.';
$txt['error_form_already_submitted'] = 'You already submitted this post!  You might have accidentally double clicked or refreshed the page.';
$txt['error_poll_few'] = 'Äänestyksessä täytyy olla vähintään kaksi vaihtoehtoa!';
$txt['error_poll_many'] = 'You must have no more than 256 choices.';
$txt['error_need_qr_verification'] = 'Täytä varmistustehtävä alapuolelta lähettääksesi viestin.';
$txt['error_wrong_verification_code'] = 'Antamasi kirjaimet eivät vastaa kuvassa olevia.';
$txt['error_wrong_verification_answer'] = 'Et vastannut varmistuskysymyksiin oikein.';
$txt['error_need_verification_code'] = 'Anna varmistus koodi jatkaaksesi tuloksiin';
$txt['error_bad_file'] = 'Sorry, but the file specified could not be opened: %1$s';
$txt['error_bad_line'] = 'Antamasi rivi on virheellinen.';
$txt['error_draft_not_saved'] = 'There was an error saving the draft';
$txt['error_name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['smiley_not_found'] = 'Hymiötä ei löydy.';
$txt['smiley_has_no_code'] = 'Tälle hymiölle ei annettu koodia.';
$txt['smiley_has_no_filename'] = 'No file name for this smiley was given.';
$txt['smiley_not_unique'] = 'Hymiö tällä koodilla on jo olemassa.';
$txt['smiley_set_already_exists'] = 'Hymiöpaketti samalla URL-osoitteella on jo olemassa';
$txt['smiley_set_not_found'] = 'Hymiöpakettia ei löydetty';
$txt['smiley_set_dir_not_found'] = 'The directory of the smiley set %1$s is either invalid or cannot be accessed';
$txt['smiley_set_path_already_used'] = 'Tätä URL-osoitetta käyttää jo toinen hymiöpaketti.';
$txt['smiley_set_unable_to_import'] = 'Hymiöpakettia ei voitu tuoda. Joko kansio on väärä tai sinne ei pääse.';

$txt['smileys_upload_error'] = 'Tiedoston lataaminen epäonnistui.';
$txt['smileys_upload_error_blank'] = 'All smiley sets must have an image.';
$txt['smileys_upload_error_name'] = 'All smileys must have the same file name.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Virheellinen tyyppi.';

$txt['search_invalid_weights'] = 'Search weights are not configured properly. At least one weight should be configured to be non-zero. Please report this error to an administrator.';

$txt['package_no_file'] = 'Tiedostoa ei löytynyt!';
$txt['packageget_unable'] = 'Palvelimeen ei saatu yhteyttä. Yritä <a href="%1$s" target="_blank" class="new_win">tätä kautta</a>.';
$txt['not_valid_server'] = 'Sorry, packages can only be downloaded like this from servers you have first authorized.';
$txt['package_cant_uninstall'] = 'Tämä paketti on joko kokonaan asentamatta tai sitten se on jo poistettu - et voi poistaa sitä nyt.';
$txt['package_cant_download'] = 'You cannot download or install new packages because the &quot;packages&quot; directory or one of the files in it are not writable!';
$txt['package_upload_error_nofile'] = 'Et valinnut pakettia ladattavaksi.';
$txt['package_upload_error_failed'] = 'Pakettia ei saatu ladattua, tarkista hakemiston oikeudet!';
$txt['package_upload_error_exists'] = 'The file you are uploading already exists on the server. Please delete it first, then try again.';
$txt['package_upload_already_exists'] = 'The package you are trying to upload already exists on the server under file name: %1$s';
$txt['package_upload_error_supports'] = 'Pakettienhallinta hyväksyy vain nämä tiedostotyypit: %1$s.';
$txt['package_upload_error_broken'] = 'Paketin tallennus epäonnistui:<br />&quot;%1$s&quot; ';

$txt['package_get_error_not_found'] = 'The package you are trying to install cannot be located. You may want to manually upload the package to your &quot;packages&quot; directory.';
$txt['package_get_error_missing_xml'] = 'Paketista jota yrität asentaa puuttuu package-info.xml-tiedosto sen tulee olla paketin juurikansiossa.';
$txt['package_get_error_is_zero'] = 'Although the package was downloaded to the server it appears to be empty. Please check the &quot;packages&quot; directory, and the &quot;temp&quot; sub-directory are both writable. If you continue to experience this problem you should try extracting the package on your PC and uploading the extracted files into a subdirectory in your &quot;packages&quot; directory and try again. For example, if the package was called shout.tar.gz you should:<br />1) Download the package to your local PC and extract its files.<br />2) Create a new directory in your &quot;packages&quot; folder using an FTP client, in this example you may call it "shout".<br />3) Upload all the files from the extracted package to this directory.<br />4) Go back to the package manager browse page. The package will be automatically found.';
$txt['package_get_error_packageinfo_corrupt'] = 'Unable to find any valid information within the package-info.xml file included within the package. There may be an error in the add-on, or the package may be corrupt.';
$txt['package_get_error_is_theme'] = 'You can\'t install a theme from this section, please use the <a href="{MANAGETHEMEURL}">Theme Management</a> page to upload it';

$txt['no_membergroup_selected'] = 'No member group selected';
$txt['membergroup_does_not_exist'] = 'The member group doesn\'t exist or is invalid.';

$txt['at_least_one_admin'] = 'Foorumilla on pakko olla edes yksi ylläpitäjä!';

$txt['error_functionality_not_windows'] = 'Tämä toiminnallisuus ei ole käytettävissa Windows-palvelimilla.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Liitetiedostoa ei löytynyt';

$txt['error_no_boards_selected'] = 'No valid boards were selected.';
$txt['error_invalid_search_string'] = 'Did you forget to enter something to search for?';
$txt['error_invalid_search_string_blacklist'] = 'Your search query contained trivial words. Please try again with a different query.';
$txt['error_search_string_small_words'] = 'Kaikkien sanojen tulee olla pitempiä kuin 2 merkkiä.';
$txt['error_query_not_specific_enough'] = 'Hakusi ei tuottanut tuloksia.';
$txt['error_no_messages_in_time_frame'] = 'Valitulta aikajaksolta ei löytynyt viestejä.';
$txt['error_no_labels_selected'] = 'No labels were selected.';
$txt['error_no_search_daemon'] = 'Haku palveluun ei saatu yhteyttä';

$txt['profile_errors_occurred'] = 'The following errors occurred when trying to update your profile';
$txt['profile_error_bad_offset'] = 'Aikaeron asetus on yli rajojen';
$txt['profile_error_no_name'] = 'Nimi kenttä jäi tyhjäksi';
$txt['profile_error_digits_only'] = 'Voit laittaa vain numeroita';
$txt['profile_error_name_taken'] = 'The selected user name/display name has already been taken';
$txt['profile_error_name_too_long'] = 'Valittu nimi on liian pitkä. Sen tulee olla alle 60 merkkiä pitkä';
$txt['profile_error_no_email'] = 'Sähköposti kenttä jäi tyhjäksi';
$txt['profile_error_bad_email'] = 'Et ilmoittanut sähköpostiosoitettasi';
$txt['profile_error_email_taken'] = 'Toinen käyttäjä on jo rekisteröitynyt samalla sähköpostiosoitteella';
$txt['profile_error_no_password'] = 'Et antanut salasanaasi';
$txt['profile_error_bad_new_password'] = 'Syöttämäsi uudet salasanat eivät vastaa toisiaan';
$txt['profile_error_bad_password'] = 'Antamasi salasana on väärä.';
$txt['profile_error_bad_avatar'] = 'Valitsemasi avatar-kuva on joko liian iso, tai ei lainkaan avatar.';
$txt['profile_error_password_short'] = 'Your password must be at least %1$s characters long.';
$txt['profile_error_password_restricted_words'] = 'Your password must not contain your user name, email address or other commonly used words.';
$txt['profile_error_password_chars'] = 'Salasanan pitää sisältää isoja ja pieniä kirjaimia, sekä numeroita.';
$txt['profile_error_already_requested_group'] = 'Edellinen hakemuksesi tähän ryhmään on yhä avoin!';
$txt['profile_error_openid_in_use'] = 'Toinen käyttäjä käyttää samaa OpenID authentication osoitetta';
$txt['profile_error_signature_not_yet_saved'] = 'The signature has not been saved.';
$txt['profile_error_personal_text_too_long'] = 'The personal text is too long.';
$txt['profile_error_user_title_too_long'] = 'The custom title is too long.';

$txt['mysql_error_space'] = ' - tarkista tietokannan käytettävissä oleva tallennustila, tai ota yhteyttä palvelimen ylläpitäjään.';

$txt['icon_not_found'] = 'Ikoni kuvaa ei löytynyt default teemasta - tarkista että kuva on ladattu palvelimelle ja yritä uudelleen';
$txt['icon_after_itself'] = 'The icon cannot be positioned after itself.';
$txt['icon_name_too_long'] = 'Icon file names cannot be more than 16 characters long';

$txt['name_censored'] = 'Nimi %1$s, jota yrität käyttää, sisältää sanoja jotka on sensuroitu. Ole hyvä ja kokeile toisella nimellä.';

$txt['poll_already_exists'] = 'A topic can only have one poll associated with it.';
$txt['poll_not_found'] = 'Tähän aiheeseen ei ole liitetty äänestystä!';

$txt['error_while_adding_poll'] = 'Lisättäessä äänestystä, tapahtui seuraava virhe tai virheet';
$txt['error_while_editing_poll'] = 'Muokattaessa äänestystä, tapahtui seuraava virhe tai virheet';

$txt['loadavg_search_disabled'] = 'Palvelimen korkean kuormituksen vuoksi, hakutoiminto on väliaikaisesti poistettu käytöstä. Yritä uudelleen pienen ajan kuluttua.';
$txt['loadavg_generic_disabled'] = 'Palvelimen korkean kuormituksen vuoksi, tämä toiminto on väliaikaisesti poistettu käytöstä. ';
$txt['loadavg_allunread_disabled'] = 'The server\'s resources are temporarily under a too high demand to find all the topics you have not read.';
$txt['loadavg_unreadreplies_disabled'] = 'Palvelimen korkean kuormituksen vuoksi, tämä toiminto on väliaikaisesti poistettu käytöstä. Yritä uudelleen pienen ajan kuluttua.';
$txt['loadavg_show_posts_disabled'] = 'Palvelimen korkean kuormituksen vuoksi, tämä toiminto on väliaikaisesti poistettu käytöstä. Yritä uudelleen pienen ajan kuluttua.';
$txt['loadavg_unread_disabled'] = 'The server\'s resources are temporarily under a too high demand to list out the topics you have not read.';
$txt['loadavg_userstats_disabled'] = 'Please try again later.  This member\'s statistics are not currently available due to high load on the server.';

$txt['cannot_edit_permissions_inherited'] = 'You cannot edit inherited permissions directly, you must either edit the parent group or edit the member group inheritance.';

$txt['mc_no_modreport_specified'] = 'Sinun täytyy valita mitä raporttia haluat tarkastella.';
$txt['mc_no_modreport_found'] = 'Antaamasi raporttia ei ole olemassa tai sinulla ei ole oikeuksia siihen';

$txt['st_cannot_retrieve_file'] = 'Tiedostoa ei voitu jäljittää %1$s.';
$txt['admin_file_not_found'] = 'Tiedostoa ei voitu ladata: %1$s.';

$txt['themes_none_selectable'] = 'Ainakin yhden teeman pitää olla valittavissa.';
$txt['themes_default_selectable'] = 'Foorumin oletus pitää olla valittavissa oleva teema.';
$txt['ignoreboards_disallowed'] = 'Toimintoa alueiden huomioimatta jättämisestä ei ole laitettu päälle.';

$txt['mboards_delete_error'] = 'No category selected.';
$txt['mboards_delete_board_error'] = 'No board selected.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'You can not make a parent its own child.';
$txt['mboards_board_own_child_error'] = 'You can not make a board its own child.';

$txt['smileys_upload_error_notwritable'] = 'Seuraavat hymiöhakemistot eivät ole kirjoitettavissa: %1$s';
$txt['smileys_upload_error_types'] = 'Kuva voi olla vain seuraavissa muodoissa: %1$s.';

$txt['change_email_success'] = 'Sähköpostiosoitteesi on muutettu. Uusi aktivointiviesti on lähetetty siihen osoitteeseen.';
$txt['resend_email_success'] = 'Aktivointiviestin lähetys onnistui.';

$txt['custom_option_need_name'] = 'The profile option must have a name.';
$txt['custom_option_not_unique'] = 'Field name is not unique.';
$txt['custom_option_regex_error'] = 'The regex you entered is not valid';

$txt['warning_no_reason'] = 'Sinun tulee antaa syy jäsenen varoitustason muutokselle.';
$txt['warning_notify_blank'] = 'Valitsit, että käyttäjälle lähetetään huomautus, mutta jätit tyhjäksi otsikon ja/tai viestin.';

$txt['cannot_connect_doc_site'] = 'Could not connect to the documentation site. Please check that your server configuration allows external internet connections and try again later.';

$txt['movetopic_no_reason'] = 'Sinun on annettava syy siirrolle, tai poista valinta kohdasta \'Jätä kommentti siirrosta alkuperäiselle alueelle\'.';
$txt['movetopic_no_board'] = 'You must choose a board to move the topic to.';

$txt['splittopic_no_reason'] = 'You must enter a reason for splitting the topic, or uncheck the option to \'post a redirection message\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Tunnisteen tarjoaja ei vastannut oikein.';
$txt['openid_return_no_mode'] = 'Tunnisteen tarjoaja ei vastannut Open ID -tilassa.';
$txt['openid_not_resolved'] = 'Tunnisteen tarjoaja ei hyväksynyt pyyntöäsi.';
$txt['openid_no_assoc'] = 'Pyydettyä assosiaatiota ei saatu tunnisteen tarjoajalta.';
$txt['openid_sig_invalid'] = 'Tunnisteen tarjoajan allekirjoitus on virheellinen.';
$txt['openid_load_data'] = 'Ei voitu ladata tietoja tunnisteen tarjoajalta. Yritä uudelleen.';
$txt['openid_not_verified'] = 'The supplied OpenID has not been verified yet.  Please log in to verify.';

$txt['error_custom_field_too_long'] = 'Kentän &quot;%1$s&quot; maksimi pituus on %2$d merkkiä.';
$txt['error_custom_field_invalid_email'] = 'Kentässä &quot;%1$s&quot; tulee olla kelpo sähköpostiosoite.';
$txt['error_custom_field_not_number'] = 'Kentässä &quot;%1$s&quot; tulee olla numeerinen arvo.';
$txt['error_custom_field_inproper_format'] = 'Kenttä &quot;%1$s&quot; on väärässä muodossa.';
$txt['error_custom_field_empty'] = 'Kenttä &quot;%1$s&quot; ei voi olla tyhjä.';

$txt['email_no_template'] = 'Sähköpostipohjaa &quot;%1$s&quot; ei löytynyt.';

$txt['search_api_missing'] = 'The search API could not be found. Please contact the admin to check they have uploaded the correct files.';
$txt['search_api_not_compatible'] = 'The selected search API the forum is using is out of date - falling back to standard search. Please check the file %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Et voi palauttaa aiheen ensimmäistä viestiä.';
$txt['restored_disabled'] = 'Aiheiden palautus ei ole käytössä.';
$txt['restore_not_found'] = 'The following messages could not be restored; the original topic may have been removed: %1$s You will need to move these manually.';

$txt['error_invalid_dir'] = 'Antamasi kansio on virheellinen.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'The Sub-action you requested is not defined';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'No sortable items were found';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
