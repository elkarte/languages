<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Jatka';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Lista paketin tiedostoista';
$txt['files_archive'] = 'Tiedostot kansiossa';
$txt['package_browse'] = 'Selaa';
$txt['add_server'] = 'Lisää palvelin';
$txt['server_name'] = 'Palvelimen nimi';
$txt['serverurl'] = 'Osoite';
$txt['no_packages'] = 'Ei paketteja.';
$txt['download'] = 'Lataa';
$txt['download_success'] = 'Paketti ladattu onnistuneesti';
$txt['package_downloaded_successfully'] = 'Paketti ladattu onnistuneesti';
$txt['package_manager'] = 'Pakettienhallinta';
$txt['install_mod'] = 'Install Add-on';
$txt['uninstall_mod'] = 'Uninstall Add-on';
$txt['no_adds_installed'] = 'No addons currently installed';
$txt['uninstall'] = 'Poista asennus';
$txt['delete_list'] = 'Delete Add-on List';
$txt['package_delete_list_warning'] = 'Are you sure you wish to clear the installed addons list?';

$txt['package_manager_desc'] = 'From this easy to use interface, you can download and install addons for use on your forum.';
$txt['installed_packages_desc'] = 'Alla voit tarkastella asennettuja muokkauksia, sekä poistaa ne joita et enää tarvitse.';
$txt['download_packages_desc'] = 'From this section you can add or remove package servers, browse for packages, or download new packages from servers.';
$txt['package_servers_desc'] = 'From this easy to use interface, you can manage your package servers and download addon archives on your forum.';
$txt['upload_packages_desc'] = 'From this section you can upload a package file from your local computer directly to the forum.';

$txt['upload_new_package'] = 'Upload new package';
$txt['view_and_remove'] = 'View and remove installed packages';
$txt['modification_package'] = 'Add-on packages';
$txt['avatar_package'] = 'Avatar packages';
$txt['language_package'] = 'Language packages';
$txt['unknown_package'] = 'Other packages';
$txt['smiley_package'] = 'Smiley packages';
$txt['use_avatars'] = 'Käytä avatareja/kuvia';
$txt['add_languages'] = 'Lisää kieli';
$txt['list_files'] = 'Listaa tiedostot';
$txt['package_type'] = 'Paketin tyyppi';
$txt['extracting'] = 'Puretaan';
$txt['avatars_extracted'] = 'The avatars have been installed, you should now be able to use them.';
$txt['language_extracted'] = 'The language pack has been installed, you can now enable its use in the language settings area of your admin control panel.';

$txt['mod_name'] = 'Add-on Name';
$txt['mod_version'] = 'Versio';
$txt['mod_author'] = 'Muokkauksen tekijä';
$txt['author_website'] = 'Tekijän kotisivu';
$txt['package_no_description'] = 'No description given';
$txt['package_description'] = 'Kuvaus';
$txt['file_location'] = 'Lataa';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'No source edits';
$txt['mod_date'] = 'Last updated';
$txt['mod_section_count'] = 'Browse the (%1d) addons in this section';

// Package Server strings
$txt['package_current'] = '(%s <em>You have the Current version %s</em>)';
$txt['package_update'] = '(%s <em>An update for your %s version is available</em>)';
$txt['package_installed'] = 'installed';
$txt['package_downloaded'] = 'ladattu';

$txt['package_installed_key'] = 'Installed addons:';
$txt['package_installed_current'] = 'nykyinen versio';
$txt['package_installed_old'] = 'vanhempi versio';
$txt['package_installed_warning1'] = 'This package is already installed, and no upgrade was found.';
$txt['package_installed_warning2'] = 'Vältty;äksesi ongelmilta vanha versio kannattaa poistaa ensin tai pyytää tekijää luomaan päivitys vanhaan versioosi.';
$txt['package_installed_warning3'] = 'Muista aina varmuuskopoioida tiedostosi ja tietokantasi ennen muokkauksien asennusta.';
$txt['package_installed_extract'] = 'Puretaan pakettia';
$txt['package_installed_done'] = 'Muokkaus tehty onnistuneesti. Muokkauksen pitäisi toimia kuten se on tarkoitettu.';
$txt['package_installed_redirecting'] = 'Uudelleenohjataan...';
$txt['package_installed_redirect_go_now'] = 'Uudelleenohjaa';
$txt['package_installed_redirect_cancel'] = 'Paluu pakettien hallintaan';

$txt['package_upgrade'] = 'Päivitys';
$txt['package_uninstall_readme'] = 'Asennuksen poiston Lueminut';
$txt['package_install_readme'] = 'Asennuksen LueMinut';
$txt['package_install_license'] = 'License';
$txt['package_install_type'] = 'Tyyppi';
$txt['package_install_action'] = 'Tapahtuma';
$txt['package_install_desc'] = 'Kuvaus';
$txt['install_actions'] = 'Asenna muokkaus';
$txt['perform_actions'] = 'This will perform the following actions:';
$txt['corrupt_compatible'] = 'The package you are trying to download or install is either corrupt or not compatible with this version of the software.';
$txt['package_create'] = 'Luo';
$txt['package_move'] = 'Siirrä';
$txt['package_delete'] = 'Poista';
$txt['package_extract'] = 'Pura';
$txt['package_file'] = 'tiedosto';
$txt['package_tree'] = 'polku';
$txt['execute_modification'] = 'Suorita muokkaus';
$txt['execute_code'] = 'Suorita koodi';
$txt['execute_database_changes'] = 'Execute file';
$txt['execute_hook_add'] = 'Add Hook';
$txt['execute_hook_remove'] = 'Remove Hook';
$txt['execute_hook_action'] = 'Adapting hook %1$s';
$txt['package_requires'] = 'Requires Modification';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Add Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'Asennustoiminnot paketille';
$txt['package_will_fail_title'] = 'Error in package %1$s';
$txt['package_will_fail_warning'] = 'At least one error was encountered during a test %1$s of this package.<br />It is <strong>strongly</strong> recommended that you do not continue with %1$s unless you know what you are doing, and have made a backup very recently.<br /><br />This error may be caused by a conflict between the package you\'re trying to install and another package you have already installed, an error in the package, a package which requires another package that you have not installed yet, or a package designed for another version of the software.';
$txt['package_will_fail_unknown_action'] = 'The package is trying to perform an unknown action: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Are you sure you wish to continue installing this addon, even though it will not install successfully?';
$txt['package_will_fail_popup_uninstall'] = 'Are you sure you wish to continue uninstalling this addon, even though it will not uninstall successfully?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'removal';
$txt['package_install_now'] = 'Install now';
$txt['package_uninstall_now'] = 'Uninstall now';
$txt['package_other_themes'] = 'Install in other themes';
$txt['package_other_themes_uninstall'] = 'UnInstall in other themes';
$txt['package_other_themes_desc'] = 'To use this addon in themes other than the default, the package manager needs to make additional changes to the other themes. If you\'d like to install this addon in the other themes, please select these themes below.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Ainakin yksi virhe ilmeni asennuksen testauksen aikana teemaan. Haluatko varmasti yrittää asennusta?';

$txt['package_bytes'] = 'tavua';

$txt['package_action_missing'] = '<strong class="error">Tiedostoa ei löydy</strong>';
$txt['package_action_error'] = '<strong class="error">Muokkauksen jäsennysvirhe</strong>';
$txt['package_action_failure'] = '<strong class="error">Testi epäonnistui</strong>';
$txt['package_action_success'] = '<strong>Testi onnistui</strong>';
$txt['package_action_skipping'] = '<strong>Ohitetaan tiedosto</strong>';

$txt['package_uninstall_actions'] = 'Asennuksen poistotoiminnot';
$txt['package_uninstall_done'] = 'The package has been successfully uninstalled.';
$txt['package_uninstall_cannot'] = 'This package cannot be uninstalled, because there is no uninstaller.<br /><br />Please contact the addon author for more information.';

$txt['package_install_options'] = 'Asennuksen asetukset';
$txt['package_install_options_desc'] = 'Set various options for how the package manager installs addons, including backups and ftp access';
$txt['package_install_options_ftp_why'] = 'Pakettienhallinnan FTP-toimintoja käyttämällä on helppo asettaa oikeudet ilman että joudut käyttää FTP-asiakasohjelmaa muokataksesi oikeuksia manuaalisesti.<br />Täältä voit muokata oletuksia joillekkin kentille.';
$txt['package_install_options_ftp_server'] = 'FTP Serveri';
$txt['package_install_options_ftp_port'] = 'Portti';
$txt['package_install_options_ftp_user'] = 'Käyttäjänimi';
$txt['package_install_options_make_backups'] = 'Luo varmuuskopio ylikirjoitetuista tiedostoista ja lisää (~) merkki tiedoston nimen loppuun.';
$txt['package_install_options_make_full_backups'] = 'Create an entire backup (excluding smileys, avatars and attachments) of the ElkArte install.';

$txt['package_ftp_necessary'] = 'Tarvitaan FTP-tunnukset';
$txt['package_ftp_why'] = 'Some of the files the package manager needs to modify are not writable.  This needs to be changed by logging into FTP and using it to chmod or create the files and directories.  Your FTP information may be temporarily cached for proper operation of the package manager. Note you can also do this manually using an FTP client - <a href="#" onclick="%1$s">to view a list of the affected files please click here</a>.';
$txt['package_ftp_why_file_list'] = 'Seuraaville tiedostoille täytyy antaa kirjoitusoikeudet, jotta asennus voi jatkua:';
$txt['package_ftp_why_download'] = 'In order to download packages, the packages directory, and any files in it, must be writable.  Currently the system does not have the needed permissions to write to this directory.  The package manager can use your FTP information to attempt to fix this problem.';
$txt['package_ftp_server'] = 'FTP Serveri';
$txt['package_ftp_port'] = 'Portti';
$txt['package_ftp_username'] = 'Käyttäjänimi';
$txt['package_ftp_password'] = 'Salasana';
$txt['package_ftp_path'] = 'Local path to ElkArte';
$txt['package_ftp_test'] = 'Testaus';
$txt['package_ftp_test_connection'] = 'Testaa yhteys';
$txt['package_ftp_test_success'] = 'FTP-yhteys luotu onnistuneesti.';
$txt['package_ftp_test_failed'] = 'FTP-palvelimeen yhdistäminen epäonnistui.';
$txt['package_ftp_bad_server'] = 'FTP-palvelimeen yhdistäminen epäonnistui.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Paketti jota olet poistamassa on asennettuna! Jos poistat sen, et voi enää poistaa asennusta.\\n\\nOletko varma?';

$txt['package_examine_file'] = 'Tarkastele tiedostoa paketissa';
$txt['package_file_contents'] = 'Tiedoston sisältö';

$txt['package_upload_title'] = 'Lataa paketti';
$txt['package_upload_select'] = 'Ladattava paketti';
$txt['package_upload'] = 'Lataa';
$txt['package_uploaded_success'] = 'Paketin lataaminen onnistui';
$txt['package_uploaded_successfully'] = 'Paketti ladattu onnistuneesti';

$txt['package_modification_malformed'] = 'Malformed or invalid addon file.';
$txt['package_modification_missing'] = 'Tiedostoa ei löydy.';
$txt['package_no_zlib'] = 'Valitettavasti PHP-asetuksesi eivät sisällä <strong>zlib</strong>-tukea. Ilman sitä pakettienhallinta ei toimi. Ota yhteyttä palveluntarjoajaasi saadaksesi lisätietoja.';

$txt['package_cleanperms_title'] = 'Järjestele oikeudet';
$txt['package_cleanperms_desc'] = 'Täällä voit resetoida asennuksen tiedostojen oikeudet parantaaksesi tietoturvaa tai ratkaistaksesi ongelmat joihin törmäsit pakettien asennuksessa.';
$txt['package_cleanperms_type'] = 'Aseta kaikki oikeudet läpi keskustelualueen seuraavasti';
$txt['package_cleanperms_standard'] = 'Vain keskeisimmät tiedostot ovat kirjoitettavissa.';
$txt['package_cleanperms_free'] = 'Kaikki tiedostot ovat kirjoitettavia.';
$txt['package_cleanperms_restrictive'] = 'Vain välttämättömät tiedostot ovat kirjoitettavissa.';
$txt['package_cleanperms_go'] = 'Muuta tiedostojen oikeudet';

$txt['package_download_by_url'] = 'Lataa paketti osoitteesta';
$txt['package_download_filename'] = 'Tiedoston nimi';
$txt['package_download_filename_info'] = 'Valinnainen. Tulee käyttää kun osoite ei pääty tiedoston nimeen. Esim. index.php?mod=5';

$txt['package_db_uninstall'] = 'Remove all data associated with this addon.';
$txt['package_db_uninstall_details'] = 'Lisätiedot';
$txt['package_db_uninstall_actions'] = 'Checking this option will result in the following actions';
$txt['package_db_remove_table'] = 'Tiputa taulu &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Poista sarake &quot;%2$s&quot; taulusta &quot;%1$s&quot;';
$txt['package_db_remove_index'] = 'Poista indeksi &quot;%1$s&quot; taulusta &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Install Emulating:';
$txt['package_emulate_uninstall'] = 'Uninstall Emulating:';

// Operations.
$txt['operation_find'] = 'Etsi';
$txt['operation_replace'] = 'Korvaa';
$txt['operation_after'] = 'Lisää perään';
$txt['operation_before'] = 'Lisää ennen';
$txt['operation_title'] = 'Toiminnot';
$txt['operation_ignore'] = 'Ei ota virheitä huomioon';
$txt['operation_invalid'] = 'Valitsemase toiminto on virheellinen.';

$txt['package_file_perms_desc'] = 'Tältä alueelta voit tarkistaa tärkeiden tiedostojen ja kansioiden oikeudet. Huomaa, tämä sisältää vain tärkeimmät kansiot ja tiedostot - käytä FTP-asiakasohjelmaa muihin.';
$txt['package_file_perms_name'] = 'File/Directory Name';
$txt['package_file_perms_status'] = 'Nykyinen tila';
$txt['package_file_perms_new_status'] = 'Uusi tila';
$txt['package_file_perms_status_read'] = 'Luettu';
$txt['package_file_perms_status_write'] = 'Kirjoitus';
$txt['package_file_perms_status_execute'] = 'Suoritus';
$txt['package_file_perms_status_custom'] = 'Mukautettu';
$txt['package_file_perms_status_no_change'] = 'Ei muutosta';
$txt['package_file_perms_writable'] = 'Kirjoitettava';
$txt['package_file_perms_not_writable'] = 'Ei kirjoitettava';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Enemmän tiedostoja';

$txt['package_file_perms_change'] = 'Muuta tiedostojen oikeuksia';
$txt['package_file_perms_predefined'] = 'Käytä ennalta määritettyä profiilia';
$txt['package_file_perms_predefined_note'] = 'Note that this only applies the predefined profile to key directories and files.';
$txt['package_file_perms_apply'] = 'Aseta ylempänä valitut oikeudet tiedostoille.';
$txt['package_file_perms_custom'] = 'Jos &quot;Mukautettuquot; valittiin niin käytä chmod-arvoa';
$txt['package_file_perms_pre_restricted'] = 'Rajoitettu - vähiten kirjoitettavia';
$txt['package_file_perms_pre_standard'] = 'Vakio - tärkeimmät tiedostot kirjoitettavia';
$txt['package_file_perms_pre_free'] = 'Vapaa - kaikkie tiedostot kirjoitettavia';
$txt['package_file_perms_ftp_details'] = 'Suurimalla osalla palvelimista muutos onnistuu vain käyttäen FTP-tunnusta. Anna FTP:n tiedot';
$txt['package_file_perms_ftp_retain'] = 'Note, the system will only retain the password information temporarily to aid operation of the package manager.';
$txt['package_file_perms_go'] = 'Tee muutokset';

$txt['package_file_perms_applying'] = 'Otetaan käyttöön';
$txt['package_file_perms_items_done'] = '%1$d / %2$d valmiina';
$txt['package_file_perms_skipping_ftp'] = '<strong>Varoitus:</strong> FTP-palvelimeen ei saatu yhteyttä yritetään vaihtaa oikeuksia ilman. Tämä <em>todennäköisesti</em> ei onnistu - tarkista tulokset ja yritä tarvittaessa uudellen oikeilla FTP:n tiedoilla.';

$txt['package_file_perms_dirs_done'] = '%1$d / %2$d kansiota valmiina';
$txt['package_file_perms_files_done'] = '%1$d / %2$d tiedostoa valmiina tässä kansiossa';

$txt['chmod_value_invalid'] = 'Annoit epäkelvon chmod -arvon. Arvo tulee olla välillä 0444 ja 0777';

$txt['package_restore_permissions'] = 'Restore file permissions';
$txt['package_restore_permissions_desc'] = 'The following file permissions were changed in order to install the selected package(s). You can return these files back to their original status by clicking &quot;Restore&quot; below.';
$txt['package_restore_permissions_restore'] = 'Palauta';
$txt['package_restore_permissions_filename'] = 'Tiedoston nimi';
$txt['package_restore_permissions_orig_status'] = 'Alkuperäinen tila';
$txt['package_restore_permissions_cur_status'] = 'Nykyinen tila';
$txt['package_restore_permissions_result'] = 'Tulos';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - oli %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Ohitettu</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Success</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Epäonnistui</span>';
$txt['package_restore_permissions_action_done'] = 'An attempt to restore the selected files back to their original permissions has been completed, the results can be seen below. If a change failed, or for a more detailed view of file permissions, please see the <a href="%1$s">File Permissions</a> section.';

$txt['package_file_perms_warning'] = 'Huomio!';
$txt['package_file_perms_warning_desc'] = '
	Be careful when changing file permissions from this section - incorrect permissions can adversely affect the operation of your forum!<br />
	On some server configurations selecting the wrong permissions may stop the forum from operating.<br />
	Certain directories such as <em>attachments</em> need to be writable to use that functionality.<br />
	This functionality is mainly applicable on non-Windows based servers - it will not work as expected on Windows in regards to permission flags.<br />
	Before proceeding make sure you have an FTP client installed in case you do make an error and need to FTP into the server to remedy it.';

$txt['package_confirm_view_package_content'] = 'Haluatko varmasti näyttää paketit kohteesta:<br /><br />%1$s ';
$txt['package_confirm_proceed'] = 'Jatka';
$txt['package_confirm_go_back'] = 'Takaisin';

$txt['package_readme_default'] = 'Vakio';
$txt['package_available_readme_language'] = 'Saatavilla olevat Lueminut kielet';
$txt['package_license_default'] = 'Vakio';
$txt['package_available_license_language'] = 'Available License Languages:';