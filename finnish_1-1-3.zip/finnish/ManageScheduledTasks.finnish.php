<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Ajoitetut tehtävät';
$txt['scheduled_tasks_header'] = 'Kaikki ajoitetut tehtävät';
$txt['scheduled_tasks_name'] = 'Tehtävän nimi';
$txt['scheduled_tasks_next_time'] = 'Seuraava suoritus';
$txt['scheduled_tasks_regularity'] = 'Säännöllisyys';
$txt['scheduled_tasks_enabled'] = 'Käytössä';
$txt['scheduled_tasks_run_now'] = 'Suorita tehtävä nyt';
$txt['scheduled_tasks_save_changes'] = 'Tallenna muutokset';
$txt['scheduled_tasks_time_offset'] = '<strong>Note:</strong> All times given below are <em>server time</em> and do not take any time offsets setup within the admin panel into account.';
$txt['scheduled_tasks_were_run'] = 'Valitut tehtävät suoritettiin';
$txt['scheduled_tasks_were_run_errors'] = 'The following errors occurred while running the scheduled tasks:';

$txt['scheduled_tasks_na'] = 'ei asetettu';
$txt['scheduled_task_approval_notification'] = 'Ilmoitukset hyväksyntää odottavista viesteistä';
$txt['scheduled_task_desc_approval_notification'] = 'Lähetä valvojille tiedote sähköpostiin hyväksyntää odottavista viesteistä.';
$txt['scheduled_task_auto_optimize'] = 'Tietokannnan optimointi';
$txt['scheduled_task_desc_auto_optimize'] = 'Optimoi tietokantasi korjataksesi pirstoutumiseen liittyviä asioita.';
$txt['scheduled_task_daily_maintenance'] = 'Päivittäiset huoltotoimet';
$txt['scheduled_task_desc_daily_maintenance'] = 'Suorittaa päivittäiset tärkeät huoltotoimet - ei tule ottaa pois käytöstä.';
$txt['scheduled_task_daily_digest'] = 'Päivittäinen yhteenvetotiedote';
$txt['scheduled_task_desc_daily_digest'] = 'Lähettää tilaajille koosteena sähköpostina tiedotteen päivän aiheista.';
$txt['scheduled_task_weekly_digest'] = 'Viikottainen yhteenvetotiedote';
$txt['scheduled_task_desc_weekly_digest'] = 'Lähettää tilaajille koosteena sähköpostina tiedotteen viikon.';
$txt['scheduled_task_birthdayemails'] = 'Lähetä syntymäpäiväonnitteluja sähköpostitse';
$txt['scheduled_task_desc_birthdayemails'] = 'Lähettää sähköpostiviestin jossa toivotetaan hyvää syntymäpäivää.';
$txt['scheduled_task_weekly_maintenance'] = 'Viikottainen huolto';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Suorittaa viikottaiset pakolliset huoltotoimet - ei tule poistaa käytöstä.';
$txt['scheduled_task_paid_subscriptions'] = 'Maksullisten jäsenyyksin tarkistukset';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Lähettää muistutukset maksuista ja poistaa päättyneet jäsenyydet.';
$txt['scheduled_task_remove_topic_redirect'] = 'Remove MOVED: Redirection Topics';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Deletes "MOVED:" topic notifications as specified when the moved notice was created.';
$txt['scheduled_task_remove_temp_attachments'] = 'Remove Temporary Attachment Files';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Deletes temporary files created while attaching a file to a post that for any reason weren\'t renamed or deleted before.';
$txt['scheduled_task_remove_old_drafts'] = 'Remove Old Drafts';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Deletes drafts older than the number of days defined in the draft settings in the admin panel.';
$txt['scheduled_task_remove_old_followups'] = 'Remove Old Follow-ups';
$txt['scheduled_task_desc_remove_old_followups'] = 'Deletes follow-up entries still present in the database, but pointing to non-existent topics.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Fetch Emails from IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Fetches emails for the mailing list feature from an IMAP box and processes them.';
$txt['scheduled_task_user_access_mentions'] = 'Users Mentions Access';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verify users access to each board and set accessibility to related mentions accordingly.';

$txt['scheduled_task_reg_starting'] = 'Alkaa kello %1$s ';
$txt['scheduled_task_reg_repeating'] = 'toistetaan joka %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minuuutti';
$txt['scheduled_task_reg_unit_h'] = 'tunti';
$txt['scheduled_task_reg_unit_d'] = 'päivä';
$txt['scheduled_task_reg_unit_w'] = 'viikko';

$txt['scheduled_task_edit'] = 'Muokkaa ajoitettua tehtävää';
$txt['scheduled_task_edit_repeat'] = 'Toista tehtävä joka';
$txt['scheduled_task_edit_pick_unit'] = 'valitse yksikkö';
$txt['scheduled_task_edit_interval'] = 'Jakso';
$txt['scheduled_task_edit_start_time'] = 'Aloitus aika';
$txt['scheduled_task_edit_start_time_desc'] = 'Aika jolloin tehtävä alkaa päivän ensimmäisen tulee alkaa (tunnit:minuutit)';
$txt['scheduled_task_time_offset'] = 'Huomaa että aika annetaan palvelimen ajassa. Tämän hetkinen palvelimen aika: %1$s';

$txt['scheduled_view_log'] = 'Katsele logia';
$txt['scheduled_log_empty'] = 'Logi on tällä hetkellä tyhjä.';
$txt['scheduled_log_time_run'] = 'Ajankohta';
$txt['scheduled_log_time_taken'] = 'Kesto';
$txt['scheduled_log_time_taken_seconds'] = 'sekuntia';
$txt['scheduled_log_completed'] = 'Task completed';
$txt['scheduled_log_empty_log'] = 'Clear Log';
$txt['scheduled_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log?';