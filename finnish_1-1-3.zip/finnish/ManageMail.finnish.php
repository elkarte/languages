<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Tältä sivulta voit muokata postin asetuksia, tutkia postijonoa sekä määritellä käytetäänkö postijonoa ';
$txt['mail_settings'] = 'Mail Settings';

$txt['mail_type'] = 'Postin tyyppi';
$txt['mail_type_default'] = '(PHP:n oletus)';
$txt['smtp_host'] = 'SMTP-palvelin';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'SMTP portti';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'SMTP tunnus';
$txt['smtp_password'] = 'SMTP salasana';

$txt['mail_queue'] = 'Enable mail queue';
$txt['mail_period_limit'] = 'Minuutin sisällä lähetettävien viestien yläraja';
$txt['mail_period_limit_desc'] = '(0 poistaa käytöstä)';
$txt['mail_batch_size'] = 'Kerralla lähetettävien viestien yläraja';

$txt['mailqueue_stats'] = 'Mail queue statistics';
$txt['mailqueue_oldest'] = 'Vanhin viesti';
$txt['mailqueue_oldest_not_available'] = 'ei asetettu';
$txt['mailqueue_size'] = 'Queue length';

$txt['mailqueue_age'] = 'Ikä';
$txt['mailqueue_priority'] = 'Tärkeys';
$txt['mailqueue_recipient'] = 'Vastaanottaja';
$txt['mailqueue_subject'] = 'Aihe';
$txt['mailqueue_clear_list'] = 'Send mail queue now';
$txt['mailqueue_no_items'] = 'Postijono on tällä hetkellä tyhjä';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Oletko varma että haluat lähettää koko postijonon nyt? Tämä ohittaa kaikki asettamasi rajoitukset.';

$txt['mq_day'] = '%1.1f päivä';
$txt['mq_days'] = '%1.1f päivää';
$txt['mq_hour'] = '%1.1f tunti';
$txt['mq_hours'] = '%1.1f tuntia';
$txt['mq_minute'] = '%1$d minuutti';
$txt['mq_minutes'] = '%1$d minuuttia';
$txt['mq_second'] = '%1$d sekunti';
$txt['mq_seconds'] = '%1$d sekuntia';

$txt['mq_mpriority_5'] = 'Erittäin matala';
$txt['mq_mpriority_4'] = 'Matala';
$txt['mq_mpriority_3'] = 'Normaali';
$txt['mq_mpriority_2'] = 'Korkea';
$txt['mq_mpriority_1'] = 'Erittäin korkea';

$txt['birthday_email'] = 'Birthday message to use';
$txt['birthday_body'] = 'Email body';
$txt['birthday_subject'] = 'Email subject';