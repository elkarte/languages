<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Tervetuloa';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Oikeuksien tarkistus';
$txt['install_step_forum'] = 'Perusasetukset';
$txt['install_step_databaseset'] = 'Tietokannan asetukset';
$txt['install_step_databasechange'] = 'Tietokannan luonti';
$txt['install_step_admin'] = 'Ylläpitäjän tunnus';
$txt['install_step_delete'] = 'Finalize Installation';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'Kielipaketti';
$txt['installer_language_set'] = 'Paketti';
$txt['congratulations'] = 'Onnittelut, asennus on suoritettu onnistuneesti!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Asennuskansiosi on edelleen kirjoitettava. Olisi ehkä syytä muokata chmod niin ettei se olisi kirjoitettava, ihan tietoturvan takia.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(ei toimi kaikilla servereillä.)</em>';
$txt['go_to_your_forum'] = 'Voit nyt katsella <a href="%1$s">juuri asentamaasi keskustelualuetta</a> ja alkaa käyttämään sitä. Sinun täytyy ensin kirjautua, että pääset muokkaamaan keskustelualueesi asetuksia.';
$txt['good_luck'] = 'Thanks for installing ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Tervetuloa';
$txt['install_welcome_desc'] = 'Welcome to ElkArte. This script will guide you through the process for installing %1$s. We\'ll gather a few details about your forum over the next few steps, and after a couple of minutes your forum will be ready for use.';
$txt['install_all_lovely'] = 'Olemme tehneet alustavat testit palvelimellasi ja kaikki näyttää olevan kunnossa. Paina &quot;Jatka&quot;-painiketta aloittaaksesi.';

$txt['user_refresh_install'] = 'Keskustelualue päivitetty';
$txt['user_refresh_install_desc'] = 'Asennuksen aikana kävi ilmi että yksi tai useampi taulu joita asennus loi, oli jo olemassa.<br />Puuttuvat taulut luotiin uudelleen oletustiedoin, mutta mitään tietoja ei kuitenkaan ole poistettu jo olemassa olleista tauluista.';

$txt['default_topic_subject'] = 'Welcome to ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Yleinen Keskustelualue';
$txt['default_board_description'] = 'Tällä alueella voit puhua vapaasti mistä mieleen juolahtaa.';
$txt['default_category_name'] = 'Yleinen kategoria';
$txt['default_time_format'] = '%d.%m.%y - klo:%H:%M';
$txt['default_news'] = 'ElkArte - Just Installed!';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[läppäse]';
$txt['default_karmaApplaudLabel'] = '[kehu]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGuest\\nroot';
$txt['default_smileyset_name'] = 'Fugue\'s Set';
$txt['default_theme_name'] = 'ElkArte Default Theme';

$txt['default_administrator_group'] = 'Ylläpitäjä';
$txt['default_global_moderator_group'] = 'Yleisvalvoja';
$txt['default_moderator_group'] = 'Aluevalvoja';
$txt['default_newbie_group'] = 'Tulokas';
$txt['default_junior_group'] = 'Jäsen';
$txt['default_full_group'] = 'Tavallinen jäsen';
$txt['default_senior_group'] = 'Seniori';
$txt['default_hero_group'] = 'Konkari';

$txt['default_smiley_smiley'] = 'Hymyilee';
$txt['default_wink_smiley'] = 'Iskee silmä';
$txt['default_cheesy_smiley'] = 'Leveä hymy';
$txt['default_grin_smiley'] = 'Virnistää';
$txt['default_angry_smiley'] = 'Vihainen';
$txt['default_sad_smiley'] = 'Surullinen';
$txt['default_shocked_smiley'] = 'Järkyttynyt';
$txt['default_cool_smiley'] = 'Cool';
$txt['default_huh_smiley'] = 'Huh?';
$txt['default_roll_eyes_smiley'] = 'Pyörittää silmiään';
$txt['default_tongue_smiley'] = 'Näyttää kieltä';
$txt['default_embarrassed_smiley'] = 'Nolostunut';
$txt['default_lips_sealed_smiley'] = 'Huulet sinetöity';
$txt['default_undecided_smiley'] = 'Miettii';
$txt['default_kiss_smiley'] = 'Pusu';
$txt['default_cry_smiley'] = 'Itkee';
$txt['default_evil_smiley'] = 'Ilkeä';
$txt['default_azn_smiley'] = 'Azn';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Nauru';
$txt['default_police_smiley'] = 'Poliisi';
$txt['default_angel_smiley'] = 'Enkeli';

$txt['error_message_click'] = 'Klikkaa tästä';
$txt['error_message_try_again'] = 'yrittääksesi uudelleen.';
$txt['error_message_bad_try_again'] = 'asentaaksesi kuitenkin, mutta huomio ettei se ole <em>suositeltavaa</em>.';

$txt['install_settings'] = 'Perusasetukset';
$txt['install_settings_info'] = 'This page requires you to define a few key settings for your forum. ElkArte has automatically detected key settings for you.';
$txt['install_settings_name'] = 'Keskustelualueen nimi';
$txt['install_settings_name_info'] = 'This is the name of your forum, e.g. &quot;The Testing Forum&quot;.';
$txt['install_settings_name_default'] = 'Minun keskustelualueeni';
$txt['install_settings_url'] = 'Keskustelualueen URL';
$txt['install_settings_url_info'] = 'Tämä on keskustelualueesi osoite <strong>ilman päätettä \'/\'!</strong>.<br />Useimmiten voit jättää oletusosoitteen voimaan - se on yleensä oikein.';
$txt['install_settings_compress'] = 'Pakattu ulosanti';
$txt['install_settings_compress_title'] = 'Pakkaa ulosanti säästääksesi liikennöintiä.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'This function does not work properly on all servers, but can save you a lot of bandwidth.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Click here to test it</a>. (it should just say "PASS".)';
$txt['install_settings_dbsession'] = 'Tietokantapohjaiset sessiot';
$txt['install_settings_dbsession_title'] = 'Käytä tietokantaa sessioihin tavallisten tiedostojen sijaan.';
$txt['install_settings_dbsession_info1'] = 'Tämä toiminto kannattaa pistää päälle, se tekee sessioista varmemmin toimivia.';
$txt['install_settings_dbsession_info2'] = 'Tämä toiminto on yleisesti ottaen hyvä idea, muttei välttämättä toimi tällä palvelimella. ';
$txt['install_settings_proceed'] = 'Jatka';

$txt['db_settings'] = 'Tietokantapalvelimen asetukset';
$txt['db_settings_info'] = 'Nämä ovat tietokantapalvelimesi yhteysasetukset ja tunnukset. Jos et tiedä oikeita asetuksia, sinun on syytä kysyä niistä palveluntarjoajaltasi.';
$txt['db_settings_type'] = 'Tietokannan tyyppi';
$txt['db_settings_type_info'] = 'Multiple supported database types were detected - which one do you wish to use?';
$txt['db_settings_server'] = 'Palvelimen nimi';
$txt['db_settings_server_info'] = 'Tämä on lähes aina localhost - eli jos et tiedä sitä, kokeile localhostilla.';
$txt['db_settings_port'] = 'Portti';
$txt['db_settings_port_info'] = 'Leave empty if your server is listening on the default port, or you are uncertain.';
$txt['db_settings_username'] = 'User name';
$txt['db_settings_username_info'] = 'Fill in the user name you need to connect to your database here.<br />If you don\'t know what it is, try the user name of your FTP account, most of the time they are the same.';
$txt['db_settings_password'] = 'Salasana';
$txt['db_settings_password_info'] = 'Here you should put the password you need to connect to your database.<br />If you don\'t know this, you should try the password to your FTP account.';
$txt['db_settings_database'] = 'Tietokannan nimi';
$txt['db_settings_database_info'] = 'Fill in the name of the database you want to use for ElkArte to store its data in.';
$txt['db_settings_database_info_note'] = 'Jos määrittelemääsi tietokantaa ei löydetä, asennus pyrkii luomaan sen.';
$txt['db_settings_database_file'] = 'Database file name';
$txt['db_settings_database_file_info'] = 'This is the name of the file in which to store the ElkArte data. We recommend you use the randomly generated name for this and set the path of this file to be outside of the public area of your webserver.';
$txt['db_settings_prefix'] = 'Taulujen etuliite';
$txt['db_settings_prefix_info'] = 'Etuliite jokaiselle taululle tietokannassa. <strong>älä asenna kahta keskustelualuetta samalla etuliitteellä!</strong><br />Tämä asetus sallii sinun asentaa useita foorumeja samaan tietokantaan.';
$txt['db_populate'] = 'Tietokanta luotu';
$txt['db_populate_info'] = 'Asetukset on tallenettuja ja keskustelualeen toimintaan tarvittvat tiedot on lisätty tietokantaan. Alla on tarkemmat tiedot:';
$txt['db_populate_info2'] = 'Paina &quot;Jatka&quot; siirtyäksesi ylläpitäjäkäyttäjän luomiseen.';
$txt['db_populate_inserts'] = 'Lisättiin %1$d riviä. ';
$txt['db_populate_tables'] = 'Luotiin %1$d taulua. ';
$txt['db_populate_insert_dups'] = 'Ohitettiin %1$d olemassa olevaa riviä.';
$txt['db_populate_table_dups'] = 'Ohitettiin %1$d olemassa olevaa taulua.';

$txt['user_settings'] = 'Luo oma tunnuksesi';
$txt['user_settings_info'] = 'Asennus luo sinulle nyt ylläpitäjän tunnuksen.';
$txt['user_settings_username'] = 'Your user name';
$txt['user_settings_username_info'] = 'Choose the name you want to login with.';
$txt['user_settings_password'] = 'Salasana';
$txt['user_settings_password_info'] = 'Kirjoita haluamasi salasana ja paina se mieleesi!';
$txt['user_settings_again'] = 'Salasana';
$txt['user_settings_again_info'] = '(varmistuksen takia.)';
$txt['user_settings_email'] = 'Sähköpostiosoite';
$txt['user_settings_email_info'] = 'Kirjoita sähköpostiosoitteesi. <strong>Tämän on oltava toimiva osoite.</strong>';
$txt['user_settings_database'] = 'Tietokannan salasana';
$txt['user_settings_database_info'] = 'Asennus edellyttää että annat vielä salasanan tietokantaasi, turvallisuussyistä.';
$txt['user_settings_skip'] = 'Ohita';
$txt['user_settings_skip_sure'] = 'Haluatko varmasti ohittaa ylläpitäjän käyttäjätunnuksen luomisen?';
$txt['user_settings_proceed'] = 'Jatka';

$txt['ftp_checking_writable'] = 'Checking if files are writable';
$txt['ftp_setup'] = 'FTP yhteyden tiedot';
$txt['ftp_setup_info'] = 'Asennus voi ottaa FTP:llä yhteyden muokatakseen tiedostojen oikeuksia, jotta ne olisi kirjoitettavia tai ei (chmod). Jos tämä ei toimi sinulla, sinun täytyy mennä muuttamaan tiedostot manuaalisesti kirjoitettaviksi. Huomioi ettei toiminto toistaiseksi tue SSL:ää.';
$txt['ftp_server'] = 'Serveri';
$txt['ftp_server_info'] = 'This should be the server address and port for your FTP server.';
$txt['ftp_port'] = 'Portti';
$txt['ftp_username'] = 'User name';
$txt['ftp_username_info'] = 'The user name to login with. <em>This will not be saved anywhere.</em>';
$txt['ftp_password'] = 'Salasana';
$txt['ftp_password_info'] = 'Salasana jolla kirjaudut sisään. <em>Tätä ei tallenneta mihinkään.</em>';
$txt['ftp_path'] = 'Asennus Polku';
$txt['ftp_path_info'] = 'Tämä on <em>suhteellinen</em> polku FTP-palvelimellesi.';
$txt['ftp_path_found_info'] = 'Yläpuolisessa laatikossa oleva polku on automaattisesti asetettu.';
$txt['ftp_connect'] = 'Yhdistä';
$txt['ftp_setup_why'] = 'Mikä on tämän toiminnon tarkoitus?';
$txt['ftp_setup_why_info'] = 'Some files need to be writable for ElkArte to work properly.  This step allows you to let the installer make them writable for you.  However, in some cases it won\'t work - in that case, please make the following files 777 (writable, 755 on some hosts):';
$txt['ftp_setup_again'] = 'testataksesi ovatko tiedostot kirjoitettavissa.';

$txt['error_php_too_low'] = 'Warning!  You do not appear to have a version of PHP installed on your webserver that meets ElkArte\'s <strong>minimum installations requirements</strong>.<br />If you are not the host, you will need to ask your host to upgrade, or use a different host - otherwise, please upgrade PHP to a recent version.<br /><br />If you know for a fact that your PHP version is high enough you may continue, although this is strongly discouraged.';
$txt['error_missing_files'] = 'Tärkeitä asennustiedostoja ei löydetty!<br /><br />Varmista että olet ladannut koko asennuspaketin, myös sql tiedoston, ja yritä sitten uudelleen.';
$txt['error_session_save_path'] = 'Kerro palvelimesi ylläpitäjälle että <strong>session.save_path php.ini:ssä</strong> on väärin! Se on muutettava hakemistoon joka on <strong>olemassa</strong>, sekä on <strong>kirjoitettavissa</strong> käyttäjälle jonka oikeuksilla PHP toimii.<br />';
$txt['error_windows_chmod'] = 'You\'re on a windows server, and some crucial files are not writable.  Please ask your host to give <strong>write permissions</strong> to the user PHP is running under for the files in your ElkArte installation.  The following files or directories need to be writable:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Yhteyttä FTP-palvelimeen ei voitu muodostaa annetuilla tiedoilla.';
$txt['error_db_file'] = 'Tietokannan lähdetiedostoa ei löydy! Tarkasta tiedosto %1$s joka on foorumisi lähdetiedostohakemistossa (Sources).';
$txt['error_db_connect'] = 'Yhteyttä tietokantaan voitu muodostaa annetuilla tiedoilla.<br /><br />Mikäli et ole varma mitä tähän tulisi kirjoittaa, ole yhteydessä palvelimesi ylläpitäjään.';
$txt['error_db_too_low'] = 'The version of your database server is very old and does not meet ElkArte\'s minimum requirements.<br /><br />Please ask your host to either upgrade it or supply a new one, and if they won\'t, please try a different host.';
$txt['error_db_database'] = 'The installer was unable to access the &quot;<em>%1$s</em>&quot; database.  With some hosts, you have to create the database in your administration panel before ElkArte can use it.  Some also add prefixes - like your username - to your database names.';
$txt['error_db_queries'] = 'Kaikkia kyselyitä ei voitu suorittaa kunnolla. Tämä voi johtua tukemattomasta tietokantaversiosta. (kehitysversio tai vanhentunut versio)<br /><br />Teknisiä tietoja epäonnistuneista kyselyistä:';
$txt['error_db_queries_line'] = 'Rivi #';
$txt['error_db_missing'] = 'The installer was unable to detect database support in PHP that ElkArte can utilize.  Please ask your host to ensure that PHP was compiled with the desired database, or that the proper php extension is being loaded.  Currently ElkArte supports the:  &quot;%1$s&quot; extensions';
$txt['error_db_script_missing'] = 'Asennusohjelma ei löytänyt asennustiedostoja tunnistetuille tietokannoille. Tarkista että olet lähettänyt kaikki tiedostot, kuten &quot;%1$s&quot;, palvelimelle.';
$txt['error_session_missing'] = 'Asennusohjelma ei havainnut palvelimellesi asennetun PHP:n tukevan sessioita. Varmista palveluntarjoajaltasi että PHP on koottu sessiotuen kanssa.'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Kirjoitit täysin erilaiset salasanat!';
$txt['error_user_settings_no_password'] = 'Salasanan tulee olla vähintään 4 merkkiä.';
$txt['error_user_settings_taken'] = 'Sorry, a member is already registered with that user name and/or email address.<br /><br />A new account has not been created.';
$txt['error_user_settings_query'] = 'Tietokantavirhe luotaessa ylläpitäjää. Virhe oli:';
$txt['error_subs_missing'] = 'Unable to find the sources/Subs.php file.  Please make sure it was uploaded properly, and then try again.';
$txt['error_db_alter_priv'] = 'The database account you specified does not have permission to ALTER, CREATE, and/or DROP tables in the database; this is necessary for ElkArte to function properly.';
$txt['error_versions_do_not_match'] = 'The installer has detected another version of ElkArte already installed with the specified information.  If you are trying to upgrade, you should use the upgrader, not the installer.<br /><br />Otherwise, you may wish to use different information, or create a backup and then delete the data currently in the database.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'The current version of your database doesn\'t support the use of the UTF-8 character set. You can not install ElkArte';
$txt['error_valid_email_needed'] = 'Sähköpostiosoite on virheellinen';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Huom!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Tietokannan tiedoston nimi on pakollinen SQLite-tietokanntaa käytettäessä.';
$txt['error_db_prefix_numeric'] = 'Valittu tietokantatyyppi ei tue numeerisia etuliitteitä.';
$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';
$txt['error_username_too_long'] = 'User name must be less than 25 characters long.';
$txt['error_username_left_empty'] = 'User name field was left empty.';
$txt['error_db_filename_exists'] = 'Tietokanta jota yrität luoda on jo olemassa. Poista nykyinen tietokanta tai anna toinen nimi.';
$txt['error_db_prefix_reserved'] = 'Etuliite on jo käytössä. Valitse joku muu.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade Utility';
$txt['upgrade_warning'] = 'Huom!';
$txt['upgrade_critical_error'] = 'Vakava virhe!';
$txt['upgrade_continue'] = 'Eteenpäin';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Ohita';
$txt['upgrade_note'] = 'Huomaa!';
$txt['upgrade_step'] = 'Vaihe';
$txt['upgrade_steps'] = 'Vaiheet';
$txt['upgrade_progress'] = 'Käynnissä';
$txt['upgrade_overall_progress'] = 'Kokonaistilanne';
$txt['upgrade_step_progress'] = 'Vaiheen edistyminen';
$txt['upgrade_time_elapsed'] = 'Aikaa kulunut';
$txt['upgrade_time_mins'] = 'min';
$txt['upgrade_time_secs'] = 'sek';

$txt['upgrade_incomplete'] = 'Kesken';
$txt['upgrade_not_quite_done'] = 'Ei valmis aivan vielä';
$txt['upgrade_paused_overload'] = 'Päivitys on pysäytetty palvelimen ylikuormituksen välttämiseksi. Tämä on normaalia - paina <label for="contbutt">Jatka-nappia</label> jatkaaksesi.';

$txt['upgrade_ready_proceed'] = 'Thank you for choosing to upgrade to ElkArte %1$s. All files appear to be in place, and we\'re ready to proceed.';

$txt['upgrade_error_script_js'] = 'The upgrade script cannot find script.js or it is out of date. Make sure your theme paths are correct. You can download a settings check and repair script from <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte tools</a>.';

$txt['upgrade_warning_lots_data'] = 'Asennusohjelma havaitsi että foorumillasi on paljon päivitettävää dataa joak vaatii päivitystä. Tämä prosessi voi kestää kauankin riippuen foorumisi koosta ja serveristäsi. Erittäis suurilla foorumeilla (~300,000 viestiä) päivitys voi kestää tuntejakin.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';