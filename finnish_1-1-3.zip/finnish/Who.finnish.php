<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... no idea, sorry</em>';
$txt['who_admin'] = 'Viewing the admin portal';
$txt['who_moderate'] = 'Viewing the moderator portal';
$txt['who_generic'] = 'Viewing the %1$s';
$txt['who_unknown'] = '<em>Tuntematon tapahtuma</em>';
$txt['who_user'] = 'Käyttäjä';
$txt['who_time'] = 'Aika';
$txt['who_action'] = 'Tapahtuma';
$txt['who_show1'] = 'Näytä ';
$txt['who_show_members_only'] = 'Vain jäsenet';
$txt['who_show_guests_only'] = 'Vain vieraat';
$txt['who_show_spiders_only'] = 'Vain hakurobotit';
$txt['who_show_all'] = 'Kaikki';
$txt['who_no_online_spiders'] = 'Hakurobotteja ei ole paikalla.';
$txt['who_no_online_guests'] = 'Vieraita ei ole paikalla.';
$txt['who_no_online_members'] = 'Jäseniä ei ole paikalla.';

$txt['whospider_login'] = 'Katselee kirjautumissivua.';
$txt['whospider_register'] = 'Katselee rekisteröitymissivua.';
$txt['whospider_reminder'] = 'Katselee muistutussivua.';

$txt['whoall_activate'] = 'Aktivoi jäsenyyttään.';
$txt['whoall_buddy'] = 'Muokkaa kaverilistaansa.';
$txt['whoall_coppa'] = 'Täyttää vanhemman/huoltajan suostumuslomaketta.';
$txt['whoall_credits'] = 'Katselee tuki ja kiitokset sivua.';
$txt['whoall_emailuser'] = 'Lähettää sähköpostia toiselle jäsenelle.';
$txt['whoall_groups'] = 'Katsoo jäsenryhmäsivua.';
$txt['whoall_help'] = 'Viewing the <a href="{help_url}">help page</a>.';
$txt['whoall_quickhelp'] = 'Katselee ylläpidon ohjeita.';
$txt['whoall_pm'] = 'Selailee yksityisviestejään.';
$txt['whoall_auth'] = 'Kirjautuu sisään keskustelualueelle.';
$txt['whoall_login'] = 'Katselee kirjautumissivua.';
$txt['whoall_login2'] = 'Katselee kirjautumissivua.';
$txt['whoall_logout'] = 'Kirjautuu ulos.';
$txt['whoall_markasread'] = 'Merkitsee alueita luetuiksi.';
$txt['whoall_mentions'] = 'Viewing their mentions list.';
$txt['whoall_modifykarma_applaud'] = 'Jakaa positiivista karmaa toiselle jäsenelle.';
$txt['whoall_modifykarma_smite'] = 'Jakaa negatiivista karmaa toiselle jäsenelle.';
$txt['whoall_news'] = 'Katselee uutisia.';
$txt['whoall_notify'] = 'Muuttaa muistutuksen asetuksia.';
$txt['whoall_notifyboard'] = 'Muuttaa muistutuksen asetuksia.';
$txt['whoall_openidreturn'] = 'Kirjautuu sisään käyttäen OpenID:tä.';
$txt['whoall_quickmod'] = 'Moderoi aluetta.';
$txt['whoall_recent'] = 'Viewing a <a href="{recent_url}">list of recent topics</a>.';
$txt['whoall_register'] = 'Rekisteröityy keskustelualueelle.';
$txt['whoall_reminder'] = 'Pyytää salasanamuistutusta.';
$txt['whoall_reporttm'] = 'Raportoi valvojille viestistä.';
$txt['whoall_spellcheck'] = 'Käyttää oikolukua';
$txt['whoall_unread'] = 'Katselee edellisen käynnin jälkeen tulleita viestejä.';
$txt['whoall_unreadreplies'] = 'Katselee onko tullut uusia vastauksia omiin viesteihin.';
$txt['whoall_who'] = 'Viewing <a href="{who_url}">Who\'s Online</a>.';

$txt['whoall_collapse_collapse'] = 'Piilottaa kategoriaa.';
$txt['whoall_collapse_expand'] = 'Avaa kategoriaa.';
$txt['whoall_pm_removeall'] = 'Poistaa kaikkia yksityisviestejään.';
$txt['whoall_pm_send'] = 'Lähettää yksityisviestiä.';
$txt['whoall_pm_send2'] = 'Lähettää yksityisviestiä.';

$txt['whotopic_announce'] = 'Announcing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Hyväksyy liitettä.';
$txt['whotopic_dlattach'] = 'Katselee liitetiedostoa.';
$txt['whotopic_deletemsg'] = 'Poistaa viestiä.';
$txt['whotopic_editpoll'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Modifying a post in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Liking a message in the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Locking the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Locking the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Merging the topic &quot;<a href="%1$s">%2$s</a>&quot; with another topic.';
$txt['whotopic_movetopic'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_movetopic2'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_post'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Printing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderating the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Removing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Removing the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Sending the topic &quot;<a href="%1$s">%2$s</a>&quot; to a friend.';
$txt['whotopic_splittopics'] = 'Splitting the topic &quot;<a href="%1$s">%2$s</a>&quot; into two topics.';
$txt['whotopic_sticky'] = 'Pinned the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Stopped watching a topic.';
$txt['whotopic_vote'] = 'Voting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Started watching a topic.';

$txt['whopost_quotefast'] = 'Quoting a post from &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Muokkaa rekisteröitymislomaketta.';
$txt['whoadmin_featuresettings'] = 'Muokkaa keskustelualueen asetuksia.';
$txt['whoadmin_modlog'] = 'Katselee valvontalogia.';
$txt['whoadmin_serversettings'] = 'Muokkaa palvelimen asetuksia.';
$txt['whoadmin_packageget'] = 'Imuroi paketteja.';
$txt['whoadmin_packages'] = 'Katselee pakettienhallintaa.';
$txt['whoadmin_permissions'] = 'Muokkaa keskustelualueen oikeuksia.';
$txt['whoadmin_pgdownload'] = 'Lataa pakettia.';
$txt['whoadmin_theme'] = 'Muokkaa teemojen asetuksia.';
$txt['whoadmin_trackip'] = 'Jäljittää IP-osoitetta.';

$txt['whoallow_manageboards'] = 'Muokkaa alueiden asetuksia.';
$txt['whoallow_admin'] = 'Viewing the <a href="{admin_url}">administration center</a>.';
$txt['whoallow_ban'] = 'Muokkaa porttikieltoja.';
$txt['whoallow_boardrecount'] = 'Laskee kokonaismääriä uudelleen.';
$txt['whoallow_calendar'] = 'Viewing the <a href="{calendar_url}">calendar</a>.';
$txt['whoallow_editnews'] = 'Muokkaa uutisia.';
$txt['whoallow_mailing'] = 'Lähettää sähköpostia.';
$txt['whoallow_maintain'] = 'Suorittaa ylläpitorutiineja.';
$txt['whoallow_manageattachments'] = 'Hallinnoi liitetiedostoja.';
$txt['whoallow_moderate'] = 'Viewing the <a href="{moderate_url}">Moderation Center</a>.';
$txt['whoallow_memberlist'] = 'Viewing the <a href="{memberlist_url}">member list</a>.';
$txt['whoallow_optimizetables'] = 'Optimoi tietokannan tauluja.';
$txt['whoallow_repairboards'] = 'Korjaa tietokannan tauluja.';
$txt['whoallow_search'] = '<a href="{search_url}">Searching</a> the forum.';
$txt['whoallow_search_results'] = 'Katselee haun tuloksia.';
$txt['whoallow_setcensor'] = 'Muokkaa sensuroituja sanoja.';
$txt['whoallow_setreserve'] = 'Muokkaa varattujen nimien listaa.';
$txt['whoallow_stats'] = 'Viewing the <a href="{stats_url}">forum stats</a>.';
$txt['whoallow_viewErrorLog'] = 'Katselee virhelogia.';
$txt['whoallow_viewmembers'] = 'Katselee listaa jäsenistä.';

$txt['who_topic'] = 'Viewing the topic <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Viewing the board <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Viewing the board index of <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Viewing <a href="%1$s">%2$s</a>\'s profile.';
$txt['who_profile'] = 'Editing the profile of <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Posting a new topic in <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Posting a new poll in <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Email starting a new topic in <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Email posting in <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Sending a personal message by email.';

// Credits text
$txt['credits'] = 'Tekijät';
$txt['credits_intro'] = 'ElkArte is 100% free and open-source. We encourage and support an active, open community that accepts contributions from the public.  We want to thank everyone who supported the project by providing code, feedback, bug reports, and opinions, as none of this would have been possible without you.  We also want to specially acknowledge <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, the project that ElkArte was born from.';
$txt['credits_contributors'] = 'Contributors';
$txt['credits_and'] = 'ja';
$txt['credits_copyright'] = 'Tekijänoikeudet';
$txt['credits_forum'] = 'Foorumi';
$txt['credits_addons'] = 'Add-ons';
$txt['credits_software_graphics'] = 'Software/Graphics';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Graphics';
$txt['credits_fonts'] = 'Fonts';
$txt['credits_groups_contrib'] = 'Contributors';
$txt['credits_contrib_list'] = 'For a complete list of the many individuals that contributed to the design and implementation of Elkarte, please refer to the official GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">list of contributors.</a>';
$txt['credits_license'] = 'License';
$txt['credits_copyright'] = 'Tekijänoikeudet';
$txt['credits_version'] = 'Versio';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Kääntäjille';
$txt['credits_translators_message'] = 'Thank you for your efforts which make it possible for people all around the world to use ElkArte.  For a complete list please refer to the offical Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">list of contributors.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';