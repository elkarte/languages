<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Oikeutesi eivät riitä tämän jäsenen profiilin muokkaamiseen.';
$txt['website_title'] = 'Sivun otsikko';
$txt['website_url'] = 'Sivun osoite';
$txt['signature'] = 'Allekirjoitus';
$txt['profile_posts'] = 'Viestit';

$txt['profile_info'] = 'Extra Details';
$txt['profile_contact'] = 'Contact Information';
$txt['profile_moderation'] = 'Moderation Information';
$txt['profile_more'] = 'Allekirjoitus';
$txt['profile_attachments'] = 'Recent Attachments';
$txt['profile_attachments_no'] = 'There are no Attachments from this member';
$txt['profile_recent_posts'] = 'Tuoreimmat viestit';
$txt['profile_posts_no'] = 'There are no posts from this member';
$txt['profile_topics'] = 'Recent Topics';
$txt['profile_topics_no'] = 'There are no topics from this member';
$txt['profile_buddies_no'] = 'You have not set any buddies';
$txt['profile_user_info'] = 'User Info';
$txt['profile_contact_no'] = 'There is no contact information for this member';
$txt['profile_signature_no'] = 'There is no signature for this member';
$txt['profile_additonal_no'] = 'There is no additional information for this member';
$txt['profile_user_summary'] = 'Profiilit';
$txt['profile_action'] = 'Currently';
$txt['profile_recent_activity'] = 'Recent Activity';
$txt['profile_activity'] = 'Aktiivisuus';
$txt['profile_loadavg'] = 'Please try again later.  This information is not currently available due to high demand on the site.';

$txt['change_profile'] = 'Muuta profiilia';
$txt['preview_signature'] = 'Preview signature';
$txt['current_signature'] = 'Current signature';
$txt['signature_preview'] = 'Signature preview';
$txt['personal_picture'] = 'Valmiit kuvat';
$txt['no_avatar'] = 'Ei avatar-kuvaa';
$txt['choose_avatar_gallery'] = 'Valitse avatar galleriasta';
$txt['preferred_language'] = 'Kielipaketin valinta';
$txt['age'] = 'Ikä';
$txt['no_pic'] = '(ei kuvaa)';
$txt['avatar_by_url'] = 'Specify your own avatar by URL. (e.g.: <em>http://www.mypage.com/mypic.png</em>)';
$txt['my_own_pic'] = 'Anna avatar kuvan URL-osoite';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'Päivämärät näkyvät koko keskustelualueella valitussa muodossa.';
$txt['time_format'] = 'Ajan muotoilu';
$txt['display_name_desc'] = 'Tämä on nimi jonka muut näkevät.';
$txt['personal_time_offset'] = 'Numeroi tunnit +/- saadaksesi ajan näyttämään paikallista aikaa (esim+2).';
$txt['dob'] = 'Syntymäaika';
$txt['dob_month'] = 'Kuukausi (MM)';
$txt['dob_day'] = 'Päivä (DD)';
$txt['dob_year'] = 'Vuosi (YYYY)';
$txt['password_strength'] = 'Parhaan tietoturvan vuoksi salasanassa tulisi olla vähintään 8 merkkiä ja olla yhdistelmä kirjaimia, numeroita ja symboleita.';
$txt['include_website_url'] = 'Jos kirjoitat kotisivusi osoitteen seuraavaan kenttään, määritä sivun otsikko tähän.';
$txt['complete_url'] = 'Osoite kokonaisuudessaan (http://www....)';
$txt['sig_info'] = 'Allekirjoitus näkyy kaikkien lähettämiesi viestien alla. Voit käyttää BBC-koodia.';
$txt['max_sig_characters'] = 'Enintään %1$d; merkkiä, jäljellä: ';
$txt['send_member_pm'] = 'Lähetä tälle käyttäjälle yksityisviesti';
$txt['hidden'] = 'piilotettu';
$txt['current_time'] = 'keskustelualueen nykyinen aika';

$txt['language'] = 'Kielipaketti';
$txt['avatar_too_big'] = 'Kuva on liian iso, ole hyvä ja pienennä sitä ja yritä uudelleen (max';
$txt['invalid_registration'] = 'Virheellinen päiväys, asianmukainen esimerkki:';
$txt['current_password'] = 'Nykyinen salasana';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Sinun täytyy aina antaa salasanasi päivittäessäsi profiiliasi.';

$txt['timeoffset_autodetect'] = 'auto detect';

$txt['secret_question'] = 'Salainen kysymys';
$txt['secret_desc'] = 'Helpottaaksesi salasanasi palautusta, anna kysymys ja vastaus jonka <strong>vain</strong> sinä tiedät. ';
$txt['secret_desc2'] = 'Valitse huolellisesti, ethän halua kenenkään arvaavan vastaustasi!';
$txt['secret_answer'] = 'Vastaus';
$txt['incorrect_answer'] = 'Valitettavasti et määritellyt salaisen kysymyksen ja vastauksen yhdistelmää profiilissasi. Paina paluu-nappia, ja käytä oletuskeinoa saadaksesi salasanasi.';
$txt['enter_new_password'] = 'Ole hyvä ja kirjoita vastaus kysymykseesi sekä salasana jota haluaisit käyttää. Salasanasi muuttuu haluamaksesi jos vastaat kysymykseen oikein.';
$txt['secret_why_blank'] = 'Miksi tässä ei lue mitään?';

$txt['authentication_reminder'] = 'Kirjautumisen muistutus';
$txt['password_reminder_desc'] = 'Jos olet unohtanut kirjautumistietosi ne voidaan palauttaa. Aloita antamlla käyttäjänimi tai sähköpostiosoite';
$txt['authentication_options'] = 'Valitse toinen seuraavista vaihtoehdoista';
$txt['authentication_openid_email'] = 'Lähetä sähköpostilla OpenID-identiteettini';
$txt['authentication_openid_secret'] = 'Vastaan &quot;salaiseenkysymykseen&quot; OpenID-identiteettini';
$txt['authentication_password_email'] = 'Lähetä sähköpostilla uusi salasana';
$txt['authentication_password_secret'] = 'Muutan salasanan vastaamalla &quot;salaiseenkysymykseen&quot;';
$txt['openid_secret_reminder'] = 'Anna vastauksesi salaiseen kysymykseen. Jos vastaat oikein OpenID-identiteettisi näytetään.';
$txt['reminder_openid_is'] = 'Tunnuksen OpenID-identiteetti on:<br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /><br />Kirjaa tämä ylös tulevaisuutta varten.';
$txt['reminder_continue'] = 'Eteenpäin';

$txt['accept_agreement_title'] = 'Accept agreement';
$txt['agreement_accepted_title'] = 'Eteenpäin';

$txt['current_theme'] = 'Nykyinen teema';
$txt['change'] = 'Change Theme';
$txt['theme_forum_default'] = 'Keskustelualueen tai alueen oletus';
$txt['theme_forum_default_desc'] = 'Tämä on oletusteema, mikä tarkoittaa sitä että teemasi muuttuu ylläpidon asetusten ja katselemasti alueen mukaan.';

$txt['profileConfirm'] = 'Haluatko varmasti poistaa tämän käyttäjän?';

$txt['custom_title'] = 'Titteli';

$txt['lastLoggedIn'] = 'Viimeksi paikalla';

$txt['notify_settings'] = 'Muistutuksen asetukset:';
$txt['notify_save'] = 'Tallenna asetukset';
$txt['notify_important_email'] = 'Ilmoita sähköpostiin uusista tiedotteista';
$txt['notify_regularity'] = 'Muistuta aiheista ja alueista, joista olen pyytänyt muistutuksen';
$txt['notify_regularity_none'] = 'Ei koskaan';
$txt['notify_regularity_instant'] = 'Heti';
$txt['notify_regularity_first_only'] = 'Heti - mutta vain ensimmäiselle uudelle viestille';
$txt['notify_regularity_daily'] = 'Päivittäin';
$txt['notify_regularity_weekly'] = 'Viikottain';
$txt['auto_notify'] = 'Turn topic notification on when you post or reply to a topic.';
$txt['auto_notify_pbe_post'] = 'This is <strong>NOT</strong> recommended if you have "board" notifications enabled.';
$txt['notify_send_types'] = 'Notify me of topics and boards I\'ve requested notification on';
$txt['notify_send_type_everything'] = 'kaikesta mitä tapahtuu';
$txt['notify_send_type_everything_own'] = 'kaikesta, jos itse aloitin aiheen';
$txt['notify_send_type_only_replies'] = 'vain vastauksista';
$txt['notify_send_type_only_replies_pbe'] = 'All messages';
$txt['notify_send_type_nothing'] = 'ei mistään';
$txt['notify_send_body'] = 'When sending notifications of a reply to a topic, send the post in the email (but please don\'t reply to these emails.)';
$txt['notify_send_body_pbe'] = 'When sending email notifications, send the full text of the post in the email';
$txt['notify_send_body_pbe_post'] = '<strong>NOT</strong> available with Daily / Weekly summary';

$txt['notify_method'] = 'Notification and:';
$txt['notify_notification'] = 'no email (only mention/alert)';
$txt['notify_email'] = 'Immediate email';
$txt['notify_email_daily'] = 'Daily email';
$txt['notify_email_weekly'] = 'Weekly email';

$txt['notify_type_likemsg'] = 'Notify when one of your messages is liked';
$txt['notify_type_mentionmem'] = 'Notify when you are @mentioned';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Notify when someone adds you as buddy';
$txt['notify_type_quotedmem'] = 'Notify when someone quotes one of your messages';
$txt['notify_type_mailfail'] = 'Notify when email notifications are disabled (mention only)';

$txt['notifications_topics'] = 'Nykyiset muistutukset <i>aiheista</i>';
$txt['notifications_topics_none'] = 'Sinulla ei ole yhtään aihetta seurannassa.';
$txt['notifications_topics_howto'] = 'To receive notifications from a specific topic, click the &quot;Notify&quot; button while viewing it.';

$txt['notifications_boards'] = 'Nykyiset muistutukset <i>alueista<i/>';
$txt['notifications_boards_none'] = 'Sinulla ei ole yhtään aluetta seurannassa.';
$txt['notifications_boards_howto'] = 'To request notifications from a specific board, either click the &quot;Notify&quot; button in the index of that board <strong>or</strong> use the checkboxes below to enable select board notifications.';
$txt['notifications_boards_current'] = 'You are receiving notifications on the boards shown in <strong>BOLD</strong>.  Use the checkboxes to turn these off or add additional boards to your notification list';
$txt['notifications_boards_update'] = 'Update';
$txt['notifications_update'] = 'Peruuta muistutus ';

$txt['statPanel_showStats'] = 'Henkilökohtaiset tilastot käyttäjältä: ';
$txt['statPanel_users_votes'] = 'Annettuja ääniä ';
$txt['statPanel_users_polls'] = 'Aloitettuja äänestyksiä';
$txt['statPanel_total_time_online'] = 'Keskustelualueella vietetty aika';
$txt['statPanel_noPosts'] = 'Ei ainuttakaan viestiä!';
$txt['statPanel_generalStats'] = 'Yleiset tilastot';
$txt['statPanel_posts'] = 'viestiä';
$txt['statPanel_topics'] = 'aihetta';
$txt['statPanel_total_posts'] = 'Viestejä yhteensä';
$txt['statPanel_total_topics'] = 'Aloitettuja aiheita yhteensä';
$txt['statPanel_votes'] = 'ääntä';
$txt['statPanel_polls'] = 'äänestystä';
$txt['statPanel_topBoards'] = 'Kirjoituksia alueittain';
$txt['statPanel_topBoards_posts'] = '%1$d viestiä alueen %2$d viestistä (%3$01.2f%%) ';
$txt['statPanel_topBoards_memberposts'] = '%1$d viestiä jäsenen %2$d viestistä (%3$01.2f%%) ';
$txt['statPanel_topBoardsActivity'] = 'Kirjoitusten osuus alueittain';
$txt['statPanel_activityTime'] = 'Aktiivisuus viestien kirjoittelun perusteella';
$txt['statPanel_activityTime_posts'] = '%1$d viestiä (%2$d%%) ';

$txt['deleteAccount_warning'] = 'Varoitus - tätä toimintoa ei voi peruuttaa!';
$txt['deleteAccount_desc'] = 'Täällä voit poistaa tämän käyttäjän ja hänen viestinsä.';
$txt['deleteAccount_member'] = 'Poista tämä jäsen ja hänen tunnuksensa';
$txt['deleteAccount_posts'] = 'Käyttäjän viestit mitkä poistetaan';
$txt['deleteAccount_none'] = 'Ei ole';
$txt['deleteAccount_all_posts'] = 'Replies Only';
$txt['deleteAccount_topics'] = 'Topics and Replies';
$txt['deleteAccount_confirm'] = 'Haluatko varmasti poistaa tämä käyttäjän?';
$txt['deleteAccount_approval'] = 'Huom! Jäsenyytesi häviää vasta kun ylläpito on hyväksynyt tunnuksen poistamisen.';

$txt['profile_of_username'] = '%1$s:n profiili';
$txt['profileInfo'] = 'Profiili';
$txt['showPosts'] = 'Näytä kirjoitukset';
$txt['showPosts_help'] = 'Tässä osiossa voit tarkastella kaikkia tämän jäsenen viestejä. Huomaa, että näet viestit vain niiltä alueilta, joihin sinulla on pääsy.';
$txt['showMessages'] = 'Viestit';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = 'Aiheet';
$txt['showUnwatched'] = 'Unwatched topics';
$txt['showAttachments'] = 'Liitteet';
$txt['viewWarning_help'] = 'This section allows you to view all warnings issued to this member.';
$txt['statPanel'] = 'Näytä tilastot';
$txt['editBuddyIgnoreLists'] = 'Kaverit/estolista';
$txt['editBuddies'] = 'Muokkaa kavereita';
$txt['editIgnoreList'] = 'Muokkaa estolistaa';
$txt['trackUser'] = 'Jäljitä käyttäjä';
$txt['trackActivity'] = 'Aktiivisuus';
$txt['trackIP'] = 'IP osoite';
$txt['trackLogins'] = 'Logins';

$txt['likes_show'] = 'Show Likes';
$txt['likes_given'] = 'Posts you liked';
$txt['likes_profile_received'] = 'received';
$txt['likes_profile_given'] = 'given';
$txt['likes_received'] = 'Your posts liked by others';
$txt['likes_none_given'] = 'You have not liked any posts';
$txt['likes_none_received'] = 'No one has liked any of your posts :\'(';
$txt['likes_confirm_delete'] = 'Remove this like?';
$txt['likes_show_who'] = 'Show the members that liked this post';
$txt['likes_by'] = 'Liked by';
$txt['likes_delete'] = 'Poista';

$txt['authentication'] = 'Kirjautuminen';
$txt['change_authentication'] = 'Täältä voit muuttaa tapaa jolla kirjaudut keskustelualueelle. Valittavana on joko OpenID-tunnistus tai käyttäjätunnuksen ja salasanan käyttö.';

$txt['profileEdit'] = 'Muokkaa profiilia';
$txt['account_info'] = 'Käyttäjätunnuksesi tärkeät tiedot ovat täällä. Jos muutat tietoja, sinun on annettava salasanasi.';
$txt['forumProfile_info'] = 'You can change your personal information on this page. This information will be displayed throughout {forum_name_html_safe}. If you aren\'t comfortable with sharing some information, simply skip it - nothing here is required.';
$txt['theme_info'] = 'Täällä voi muokata keskustelualueen ulkoasua.';
$txt['notification_info'] = 'This allows you to be notified of replies to posts, newly posted topics, and forum announcements. You can change those settings here, or oversee the topics and boards you are currently receiving notifications for.';
$txt['groupmembership'] = 'Ryhmien jäsenyys';
$txt['groupMembership_info'] = 'Täältä voit hallita ryhmiä joihin kuulut.';
$txt['ignoreboards'] = 'Huomiotta jätetyt alueet';
$txt['ignoreboards_info'] = 'This page lets you ignore particular boards.  When a board is ignored, the new post indicator will not show up on the board index.  New posts will not show up using the "unread post" search link (when searching it will not look in those boards). However, ignored boards will still appear on the board index and upon entering will show which topics have new posts.  When using the "unread replies" link, new posts in an ignored board will still be shown.';
$txt['contactprefs'] = 'Messaging';

$txt['profileAction'] = 'Toiminnot';
$txt['deleteAccount'] = 'Poista tämä tunnus';
$txt['profileSendIm'] = 'Lähetä yksityisviesti';
$txt['profile_sendpm_short'] = 'Lähetä YV';

$txt['profileBanUser'] = 'Anna porttikielto';

$txt['display_name'] = 'Tämä on nimi/nimimerkki, joka; näkyy kaikille keskustelualueella.';
$txt['enter_ip'] = 'Syötä IP ';
$txt['errors_by'] = 'Virheilmoitukset käyttäjältä';
$txt['errors_desc'] = 'Alla on lista käyttäjän aiheuttamista ja kohtaamista virheistä.';
$txt['errors_from_ip'] = 'Virheilmoitukset IP-numerosta ';
$txt['errors_from_ip_desc'] = 'Alla on tämän käyttäjän saamat virheilmoitukset.';
$txt['ip_address'] = 'IP-osoite';
$txt['ips_in_errors'] = 'Virhetilanteissa käytetty IP-osoite';
$txt['ips_in_messages'] = 'Viime viesteissä käytetty IP-osoite ';
$txt['members_from_ip'] = 'Jäsenet IP-osoitteesta';
$txt['members_in_range'] = 'Mahdollisesti samoista osoitteista tulevat jäsenet';
$txt['messages_from_ip'] = 'Viestit jotka lähetetty IP-osoitteesta';
$txt['messages_from_ip_desc'] = 'Alla on lista viesteistä jotka ovat tulleet tästä IP-osoitteesta.';
$txt['trackLogins_desc'] = 'Below is a list of all times this account was logged into.';
$txt['most_recent_ip'] = 'Viimeisin IP-osoite';
$txt['why_two_ip_address'] = 'Miksi näytetään kaksi IP-osoitetta?';
$txt['no_errors_from_ip'] = 'Ei virheilmoituksia tästä IP-osoitteesta.';
$txt['no_errors_from_user'] = 'Ei virheilmoituksia tältä käyttäjältä.';
$txt['no_members_from_ip'] = 'Yhtään jäsentä ei löytynyt tästä IP-osoitteesta';
$txt['no_messages_from_ip'] = 'Yhtään viestiä ei löytynyt tästä IP-osoitteesta';
$txt['trackLogins_none_found'] = 'No recent logins were found';
$txt['none'] = 'Ei ole';
$txt['own_profile_confirm'] = 'Haluatko varmasti poistaa oman jäsenyytesi?';
$txt['view_ips_by'] = 'Katso IP-osoite jota käyttää jäsen';

$txt['avatar_will_upload'] = 'Ladata avatar palvelimelle';

$txt['activate_changed_email_title'] = 'Sähköpostiosoite vaihdettu';
$txt['activate_changed_email_desc'] = 'Muutit sähköpostiosoitteesi, uuden osoitteen varmistamikseksi saat sähköpostin jossa on linkki, jolla voit aktivoida tunnuksesi uudelleen.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Muistutusviesti&#228; ei voitu l&#228;hett&#228;&#228;.';
$txt['send_email'] = 'L&#228;het&#228; s&#228;hk&#246;postia j&#228;senelle';
$txt['to_ask_password'] = 'kysyäksesi salasanaa';

$txt['user_email'] = 'Tunnus tai sähköpostiosoite';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'Viesti on lähetetty sähköpostiisi. Klikkaa viestissä näkyvää linkkiä määrittääksesi uuden salasanan.';
$txt['reminder_openid_sent'] = 'Tämän hetkinen OpenID-identiteettisi on lähetetty sähköpostiisi.';
$txt['reminder_set_password'] = 'Määritä salasana';
$txt['reminder_password_set'] = 'Salasanan määritys onnistui';
$txt['reminder_error'] = '%1$s antoi väärän vastauksen salaiseen kysymykseen yrittäessään palauttaa unohtunutta salasanaa.';

$txt['registration_not_approved'] = 'Valitettavasti jäsenyyttäsi ei ole vielä hyväksytty. Jos tahdot muuttaasähköpostiosoitetta, ole hyvä ja klikkaa';
$txt['registration_not_activated'] = 'Valitettavasti jäsenyyttäsi ei ole vielä aktivoitu. Jos tarvitset uuden aktivointisähköpostiviestin, ole hyvä ja klikkaa';

$txt['primary_membergroup'] = 'Ensisijainen jäsenryhmä';
$txt['additional_membergroups'] = 'Muut jäsenryhmät';
$txt['additional_membergroups_show'] = 'Show additional groups';
$txt['no_primary_membergroup'] = '(ei ensisijaista jäsenryhmää)';
$txt['deadmin_confirm'] = 'Haluatko poistaa itseltäsi ylläpitäjän aseman?';

$txt['account_activate_method_2'] = 'Jäsenyys täytyy aktivoida uudelleen sähköpostiosoitteen muuttamisen jälkeen';
$txt['account_activate_method_3'] = 'Jäsenyyttä ei ole hyväksytty';
$txt['account_activate_method_4'] = 'Jäsenyyden poisto odottaa hyväksymistä';
$txt['account_activate_method_5'] = 'Jäsenyys on &quot;alaikäisen&quot; tili odottamassa hyväksyntää';
$txt['account_not_activated'] = 'Jäsenyyttä ei ole aktivoitu';
$txt['account_activate'] = 'aktivoi';
$txt['account_approve'] = 'hyväksy';
$txt['user_is_banned'] = 'Jäsen on tällä hetkellä porttikiellossa';
$txt['view_ban'] = 'Katso tarkemmin';
$txt['user_banned_by_following'] = 'Käyttäjää rajoittavat seuraavanlaiset estot';
$txt['user_cannot_due_to'] = 'Jäsen ei voi %1$s seuraavan eston vuoksi: &quot;%2$s&quot; ';
$txt['ban_type_post'] = 'lähettää viestejä';
$txt['ban_type_register'] = 'rekisteröityä';
$txt['ban_type_login'] = 'kirjautua';
$txt['ban_type_access'] = 'päästä keskustelualueelle';

$txt['show_online'] = 'Näytä muille kun olet paikalla.';

$txt['return_to_post'] = 'Palaa aina viestiin lähettämisen jälkeen.';
$txt['no_new_reply_warning'] = 'Älä varoita jos kirjoittamisen aikana on lähetetty uusia viestejä.';
$txt['recent_pms_at_top'] = 'Näytä uusimmat yksityisviestit ylimmäisenä.';
$txt['wysiwyg_default'] = 'Käytä WYSIWYG -muokkaajaa oletuksena viestin kirjoituksessa?';

$txt['timeformat_default'] = '(keskustelualueen oletus)';
$txt['timeformat_easy1'] = 'Kuukauden päivä, Vuosi, TT:MM:SS am/pm';
$txt['timeformat_easy2'] = 'Kuukauden päivä, Vuosi, TT:MM:SS (24h)';
$txt['timeformat_easy3'] = 'VVVV-KK-PP, TT:MM:SS';
$txt['timeformat_easy4'] = 'PP Kuukausi VVVV, TT:MM:SS';
$txt['timeformat_easy5'] = 'PP-KK-VVVV, TT:MM:SS';

$txt['poster'] = 'Kirjoittaja';

$txt['use_sidebar_menu'] = 'Use sidebar menu instead of dropdowns.';
$txt['use_click_menu'] = 'Use click to open menus, instead of hover to open.';
$txt['show_no_avatars'] = 'Älä näytä käyttäjien avatar-kuvia.';
$txt['show_no_signatures'] = 'Älä näytä muiden allekirjoituksia.';
$txt['show_no_censored'] = 'Jätä sanojen sensurointi pois.';
$txt['topics_per_page'] = 'Aiheita sivulla:';
$txt['messages_per_page'] = 'Viestejä sivulla:';
$txt['hide_poster_area'] = 'Hide the poster information area.';
$txt['per_page_default'] = 'keskustelualeen oletus';
$txt['calendar_start_day'] = 'First day of the week on the calendar:';
$txt['display_quick_reply'] = 'Käytä pikavastausta keskusteluissa: ';
$txt['use_editor_quick_reply'] = 'Use full editor in Quick Reply.';
$txt['display_quick_mod'] = 'Show quick-moderation as:';
$txt['display_quick_mod_none'] = 'älä näytä';
$txt['display_quick_mod_check'] = 'valintalaatikot';
$txt['display_quick_mod_image'] = 'kuvakkeet';

$txt['whois_title'] = 'Etsi IP-osoitetta alueelliselta kukaonkuka-palvelimelta';
$txt['whois_afrinic'] = 'AfriNIC (Afrikka)';
$txt['whois_apnic'] = 'APNIC (Aasia)';
$txt['whois_arin'] = 'ARIN (Pohjois-Amerikka, osa Karibiaa sekä osa Afrikkaa)';
$txt['whois_lacnic'] = 'LACNIC (Latinalainen Amerikka sekä Karibia)';
$txt['whois_ripe'] = 'RIPE (Eurooppa, Lähi-itä sekä osia Afrikasta ja Aasiasta)';

$txt['moderator_why_missing'] = 'Miksei aluevalvoja ole täällä?';
$txt['username_change'] = 'muuta';
$txt['username_warning'] = 'Muuttaakseen tämän jäsenen tunnusta, keskustelualueen on muutettava myös salasanaa, joka lähetetään jäsenelle yhdessä uuden tunnuksen kanssa.';

$txt['show_member_posts'] = 'Näytä jäsenen viestit';
$txt['show_member_topics'] = 'Näytä jäsenen aiheet';
$txt['show_member_attachments'] = 'Näytä jäsenen liitetiedostot';
$txt['show_posts_none'] = 'Käyttäjä ei ole vielä lähettänyt viestejä.';
$txt['show_topics_none'] = 'Aiheita ei ole vielä lähetetty.';
$txt['unwatched_topics_none'] = 'You don\'t have any topic in the unwatch list.';
$txt['show_attachments_none'] = 'Käyttäjä ei ole vielä lähettänyt liitetiedostoja.';
$txt['show_attach_filename'] = 'Tiedoston nimi';
$txt['show_attach_downloads'] = 'latausta';
$txt['show_attach_posted'] = 'Lisätty';

$txt['showPermissions'] = 'Näytä oikeudet';
$txt['showPermissions_status'] = 'Vaikuttavat ryhmät';
$txt['showPermissions_help'] = 'Täältä näet kaikki tämän jäsenen oikeudet (estetyt oikeudet on <del>yliviivattu</del>)';
$txt['showPermissions_given'] = 'Sallinut ryhmä(t)';
$txt['showPermissions_denied'] = 'Kieltänyt ryhmä(t)';
$txt['showPermissions_permission'] = 'Permission (denied permissions are shown <del>struck through</del>)';
$txt['showPermissions_none_general'] = 'Tämän jäsenen oikeuksia ei ole asetettu.';
$txt['showPermissions_none_board'] = 'Tällä jäsenellä ei ole asetettu aluekohtaisia oikeuksia.';
$txt['showPermissions_all'] = 'Ylläpitäjänä tällä jäsenellä on kaikki oikeudet.';
$txt['showPermissions_select'] = 'Kategoriakohtaiset oikeudet';
$txt['showPermissions_general'] = 'Keskeisimmät oikeudet';
$txt['showPermissions_global'] = 'Kaikki alueet';
$txt['showPermissions_restricted_boards'] = 'Kielletyt alueet';
$txt['showPermissions_restricted_boards_desc'] = 'Tämä käyttäjä ei pääse seuraaville alueille';

$txt['local_time'] = 'Paikallinen aika';
$txt['posts_per_day'] = 'viestiä per päivä';

$txt['buddy_ignore_desc'] = 'Täällä voit hallita kaveri ja estolistaasi. Lisäämällä jäseniä näille listoille, voit mm. suodattaa yksityisviestejä ja sähköposteja riippuen asetuksistasi.';

$txt['buddy_add'] = 'Add to buddy list';
$txt['buddy_remove'] = 'Remove from buddy list';
$txt['buddy_add_button'] = 'Lisää';
$txt['no_buddies'] = 'Sinulla ei ole yhtään kaveria listassa';

$txt['ignore_add'] = 'Add to ignore list';
$txt['ignore_remove'] = 'Remove from ignore list';
$txt['ignore_add_button'] = 'Lisää';
$txt['no_ignore'] = 'Estolistasi on tyhjä';

$txt['regular_members'] = 'Rekisteröityneet jäsenet';
$txt['regular_members_desc'] = 'Jokainen tämän keskustelualueen jäsen kuuluu tähän ryhmään.';
$txt['group_membership_msg_free'] = 'Jäsenyytesi päivitettiin onnistuneesti.';
$txt['group_membership_msg_request'] = 'Hakemuksesi on lähetetty, ole kärsivällinen harkinnan aikana.';
$txt['group_membership_msg_primary'] = 'Ensisijainen ryhmäsi on päivitetty';
$txt['current_membergroups'] = 'Nykyiset ryhmät';
$txt['available_groups'] = 'Saatavilla olevat ryhmät';
$txt['join_group'] = 'Liity ryhmään';
$txt['leave_group'] = 'Jätä ryhmä';
$txt['request_group'] = 'Hae jäsenyyttä';
$txt['approval_pending'] = 'Odottaa hyväksymistä';
$txt['make_primary'] = 'Tee ensisijainen ryhmä';

$txt['request_group_membership'] = 'Hae ryhmän jäsenyyttä';
$txt['request_group_membership_desc'] = 'Ennen kuin voit liittyä tähän ryhmään, hakemus tulee hyväksyä. Anna syy miksi haluat liittyä tähän ryhmään';
$txt['submit_request'] = 'Lähetä hakemus';

$txt['profile_updated_own'] = 'Profiilisi on päivitetty onnistuneesti';
$txt['profile_updated_else'] = 'The profile for <strong>%1$s</strong> has been updated successfully.';

$txt['profile_error_signature_max_length'] = 'Allekirjoitus saa olla enintään %1$d merkkiä';
$txt['profile_error_signature_max_lines'] = 'Allekirjoituksessa saa olla enintään %1$d riviä';
$txt['profile_error_signature_max_image_size'] = 'Kuvat allekirjoituksessa saavat olla enint&auml&aumln %1$dx%2$d pikseli&auml';
$txt['profile_error_signature_max_image_width'] = 'Kuvat allekirjoituksessa eiv&aumlt saa olla leveämpiä kuin %1$d pikseliä';
$txt['profile_error_signature_max_image_height'] = 'Kuvat allekirjoituksessa eiv&aumlt saa olla korkeampia kuin %1$d pikseliä';
$txt['profile_error_signature_max_image_count'] = 'Allekirjoituksessa ei saa olla yli %1$d kuvaa';
$txt['profile_error_signature_max_font_size'] = 'Teksti allekirjoituksessa ei voi olla suurempi kuin %1$s';
$txt['profile_error_signature_allow_smileys'] = 'Et saa käyttää hymiöitä allekirjoituksessa';
$txt['profile_error_signature_max_smileys'] = 'Allekirjoituksessa ei sallita enempää kuin %1$d hymiötä';
$txt['profile_error_signature_disabled_bbc'] = 'Seuraavia BBC-koodeja ei voi käyttää allekirjoituksessa: %1$s ';

$txt['profile_view_warnings'] = 'Näytä varoitukset';
$txt['profile_issue_warning'] = 'Anna varoitus';
$txt['profile_warning_level'] = 'Varoitustaso';
$txt['profile_warning_desc'] = 'Täällä voit muokata käyttäjän varoitustasoa ja antaa kirjallisen varoituksen mikäli tarpeellista. Voit myös tarkastella hänen varoitushistoriaansa ja nähdä mitä vaikutuksia varoitustasolla on.';
$txt['profile_warning_name'] = 'Nimi';
$txt['profile_warning_impact'] = 'Tulos';
$txt['profile_warning_reason'] = 'Varoituksen syy';
$txt['profile_warning_reason_desc'] = 'Tämä kirjataan ja on pakollinen.';
$txt['profile_warning_effect_none'] = 'Ei mitään.';
$txt['profile_warning_effect_watch'] = 'Jäsen listään tarkkailulistalle.';
$txt['profile_warning_effect_own_watched'] = 'Olet valvojien seurannassa';
$txt['profile_warning_is_watch'] = 'tarkkaillaan';
$txt['profile_warning_effect_moderate'] = 'Jäsenen viestit ennakkovalvotaan.';
$txt['profile_warning_effect_own_moderated'] = 'Kaikki viestisi moderoidaan';
$txt['profile_warning_is_moderation'] = 'viestit ennakkovalvotaan';
$txt['profile_warning_effect_mute'] = 'Jäsen menettää mahdollisuuden kirjoittaa viestej&auml.';
$txt['profile_warning_effect_own_muted'] = 'Et voi kirjoittaa viestejä';
$txt['profile_warning_is_muted'] = 'ei voi lähettää viestejä';
$txt['profile_warning_effect_text'] = 'Taso >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Lähetä huomautus';
$txt['profile_warning_notify_template'] = 'Valitse pohja:';
$txt['profile_warning_notify_subject'] = 'Huomautuksen aihe';
$txt['profile_warning_notify_body'] = 'Huomautuksen viesti';
$txt['profile_warning_notify_template_subject'] = 'Olet saanut varoituksen';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},

You have received a warning for %1$s. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},

You have received a warning for %1$s in regards to the message:
{MESSAGE}.

Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'roskapostituksesta';
$txt['profile_warning_notify_title_spamming'] = 'Roskapostitus';
$txt['profile_warning_notify_for_offence'] = 'loukkaavan materiaalin lähettämisestä';
$txt['profile_warning_notify_title_offence'] = 'Loukkaavan materiaalin lähett&aumlmisest&auml';
$txt['profile_warning_notify_for_insulting'] = 'muiden käyttäjien ja/tai valvojien haukkumisesta';
$txt['profile_warning_notify_title_insulting'] = 'Käyttäjien/Valvojien haukkuminen';
$txt['profile_warning_issue'] = 'Anna varoitus';
$txt['profile_warning_max'] = '(Maksimi 100)';
$txt['profile_warning_limit_attribute'] = 'Et voi muokata tämän jäsenen varoitustasoa enempään kuin %1$d%% 24 tunnin aikana.';
$txt['profile_warning_errors_occurred'] = 'Varoitusta ei annettu seuraavien virheiden takia';
$txt['profile_warning_success'] = 'Varoitus annettu onnistuneesti';
$txt['profile_warning_new_template'] = 'Uusi pohja';

$txt['profile_warning_previous'] = 'Aikaisemmat varoitukset';
$txt['profile_warning_previous_none'] = 'Tätä käyttäjää ei ole varoitettu ennen.';
$txt['profile_warning_previous_issued'] = 'Antoi';
$txt['profile_warning_previous_time'] = 'Aika';
$txt['profile_warning_previous_level'] = 'Pisteet';
$txt['profile_warning_previous_reason'] = 'Syy';
$txt['profile_warning_previous_notice'] = 'Näytä käyttäjälle lähetetty viesti';

$txt['viewwarning'] = 'Näytä varoitukset';
$txt['profile_viewwarning_for_user'] = 'Käyttäjän %1$s varoituset';
$txt['profile_viewwarning_no_warnings'] = 'No warnings have been issued.';
$txt['profile_viewwarning_desc'] = 'Alla on yhteenveto kaikista varoituksista joita valvojat ovat antaneet.';
$txt['profile_viewwarning_previous_warnings'] = 'Aikaisemmat varoitukset';
$txt['profile_viewwarning_impact'] = 'Varoituksen vaikutus';

$txt['subscriptions'] = 'Maksulliset jäsenyydet';

$txt['pm_settings_desc'] = 'Täältä voit muokata joitakin yksityisviestinnän asetuksia, kuten miten viestit näytetään. Voit myös listata henkilöt, joilta et halua yksityisviestejä.';
$txt['email_notify'] = 'Muistuta minua kun saan yksityisviestin:';
$txt['email_notify_never'] = 'Ei koskaan';
$txt['email_notify_buddies'] = 'Vain kavereilta';
$txt['email_notify_always'] = 'Aina';

$txt['receive_from'] = 'Members allowed to contact me:';
$txt['receive_from_everyone'] = 'Kaikki jäsenet';
$txt['receive_from_ignore'] = 'Kaikki jäsenet, paitsi he jotka ovat estolistallani';
$txt['receive_from_admins'] = 'Vain ylläpitäjät';
$txt['receive_from_buddies'] = 'Vain kaverit ja ylläpitäjät';
$txt['receive_from_description'] = 'This setting applies to both Personal Messages and emails (if the option to email members is enabled)';

$txt['popup_messages'] = 'Näytä ponnahdusikkuna kun saan uuden viestin';
$txt['pm_remove_inbox_label'] = 'Remove the inbox label when applying another label.';
$txt['pm_display_mode'] = 'Näytä yksityisviestit';
$txt['pm_display_mode_all'] = 'Kaikki kerralla';
$txt['pm_display_mode_one'] = 'Yksitellen';
$txt['pm_display_mode_linked'] = 'Keskusteluna';

$txt['history'] = 'History';
$txt['history_description'] = 'This section allows you to review certain profile actions performed on this member\'s profile as well as track their IP address and login history.';

$txt['trackEdits'] = 'Profiilin muokkaukset';
$txt['trackEdit_deleted_member'] = 'Poisti jäsenen';
$txt['trackEdit_no_edits'] = 'Tällä käyttäjälle ei ole kirjattu muutoksia.';
$txt['trackEdit_action'] = 'Kenttä';
$txt['trackEdit_before'] = 'Arvo ennen';
$txt['trackEdit_after'] = 'Arvo jälkeen';
$txt['trackEdit_applicator'] = 'Muuttaja';

$txt['trackEdit_action_real_name'] = 'Nimi';
$txt['trackEdit_action_usertitle'] = 'Titteli';
$txt['trackEdit_action_member_name'] = 'Käyttäjänimi';
$txt['trackEdit_action_email_address'] = 'Sähköpostiosoite';
$txt['trackEdit_action_id_group'] = 'Ensisijainen jäsenryhmä';
$txt['trackEdit_action_additional_groups'] = 'Muut jäsenryhmät';

$txt['otp_enabled_help'] = 'Enabling this will add a second factor (one-time password) for authentication.';
$txt['otp_token_help'] = 'This generates a secret token for time-based one-time password  apps such as Authy or Google Authenticator. Once the secret was generated use your favorite authenticator app and scan the qrcode.<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
