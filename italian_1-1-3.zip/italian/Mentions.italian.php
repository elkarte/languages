<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Le mie notifiche';
$txt['my_unread_mentions'] = 'Mie notifiche non lette';
$txt['my_mentions_pages'] = 'pagina %1$d';
$txt['no_mentions_yet'] = 'Nessuna menzione';
$txt['no_new_mentions'] = 'Non ci sono nuove notifiche';

$txt['mentions_from'] = 'Utente';
$txt['mentions_when'] = 'Quando';
$txt['mentions_what'] = 'Messaggio';
$txt['mentions_all'] = 'Visualizza tutti';
$txt['mentions_unread'] = 'Visualizza non letti';
$txt['mentions_action'] = 'Azioni';
$txt['mentions_delete_warning'] = 'Sicuro di voler eliminare questa voce?';
$txt['mentions_markread'] = 'Segna come letto';
$txt['mentions_markunread'] = 'Segna come non letto';

$txt['mentions_settings'] = 'Impostazioni notifiche';
$txt['mentions_settings_desc'] = 'In quest\'area puoi configurare i metodi che i tuoi utenti possono selezionare per poter ricevere notifiche. Le notifiche "in forum" non possono essere negate, per qualsiasi altro metodo puoi decidere se abilitarle o no.';
$txt['mentions_enabled'] = 'Abilita notifiche dal sito';
$txt['mentions_buddy'] = 'Aggiungi una menzione quando un utente è aggiunto nella lista di amici di qualcuno';
$txt['mentions_dont_notify_rlike'] = 'Non informare l\'utente quando un post ha rimosso un "mi piace"';

$txt['mention_mentionmem'] = 'Ti ha menzionato nel messaggio {msg_link}';
$txt['mention_likemsg'] = 'Gli piace il tuo post {msg_link}';
$txt['mention_rlikemsg'] = 'Non gli piace più il tuo post {msg_link}';
$txt['mention_buddy'] = 'Ti ha aggiunto nella sua lista di amici';
$txt['mention_quotedmem'] = 'Ha citato un tuo messaggio in {msg_link}';
$txt['mention_mailfail'] = 'Notifiche email disabilitate per invio non riuscito';

$txt['mentions_type_all'] = 'Tutte le notifiche';
$txt['mentions_type_mentionmem'] = 'Menzioni';
$txt['mentions_type_likemsg'] = 'Mi Piace';
$txt['mentions_type_rlikemsg'] = 'Non piace più';
$txt['mentions_type_buddy'] = 'Amici';
$txt['mentions_type_quotedmem'] = 'Citazioni';
$txt['mentions_type_mailfail'] = 'Invio non riuscito';

$txt['mentions_mark_all_read'] = 'Marca queste menzioni come lette';

$txt['setting_notify_enable_this'] = 'Abilita le notifiche utente per questo evento.';

$txt['setting_buddy'] = 'Amici';
$txt['setting_likemsg'] = 'Mi Piace';
$txt['setting_rlikemsg'] = '"Mi piace" rimossi';
$txt['setting_mentionmem'] = '@menzioni';
$txt['setting_quotedmem'] = 'Citazioni';
$txt['setting_mailfail'] = 'Invii non riusciti';