<?php
// Version: 1.1; UserNotifications

$txt['usernotif_title'] = 'Impostazioni Notifiche Utente';
$txt['usernotif_desktop_enable'] = 'Abilita notifiche sul desktop';
$txt['usernotif_favicon_enable'] = 'Abilita Numero di notifiche in favicon';

$txt['usernotif_favicon_position'] = 'Posizione notifica:';
$txt['usernotif_favicon_up'] = 'Alto-destra';
$txt['usernotif_favicon_down'] = 'Basso-destra';
$txt['usernotif_favicon_left'] = 'Basso-sinistra';
$txt['usernotif_favicon_upleft'] = 'Alto-sinistra';

$txt['usernotif_favicon_bgColor'] = 'Colore sfondo:';
$txt['usernotif_favicon_textColor'] = 'Colore testo:';

$txt['usernotif_favicon_fontStyle'] = 'Stile font:';
$txt['usernotif_favicon_style_normal'] = 'Normale';
$txt['usernotif_favicon_style_italic'] = 'Corsivo';
$txt['usernotif_favicon_style_oblique'] = 'Obliquo';
$txt['usernotif_favicon_style_bold'] = 'Grassetto';
$txt['usernotif_favicon_style_bolder'] = 'Più evidente';
$txt['usernotif_favicon_style_lighter'] = 'Più leggero';

$txt['usernotif_favicon_type'] = 'Forma:';
$txt['usernotif_favicon_shape_circle'] = 'Cerchio';
$txt['usernotif_favicon_shape_rectangle'] = 'Rettangolo';