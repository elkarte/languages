<?php
// Version: 1.1; ManageThemes

$txt['themeadmin_explain'] = 'I temi creano un look differente nel tuo sito. La sezione "Impostazioni Globali Temi" permette all\'amministratore di selezionare il tema da usare come default. Gli amministratori possono anche permettere ai membri di selezionare qualsiasi tema installato da usare e abilitare i temi selezionabili. La sezione "Installa un nuovo tema" permette all\'amministratore di installare i temi.';
$txt['themeadmin_manage'] = 'Gestisci ed installa';
$txt['theme_forum_theme'] = 'Impostazioni globali tema';
$txt['theme_allow'] = 'Consenti agli utenti di selezionare i propri temi.';
$txt['theme_guests'] = 'Tema predefinito del forum:';
$txt['theme_select'] = 'seleziona...';
$txt['theme_reset'] = 'Reimposta le preferenze di tutti i membri con questo tema:';
$txt['theme_nochange'] = 'Nessun cambiamento';
$txt['theme_forum_default'] = 'Tema predefinito';

$txt['theme_remove'] = 'Disinstalla';
$txt['theme_remove_confirm'] = 'Sei sicuro di voler disinstallare questo tema?';

$txt['theme_install'] = 'Installa un nuovo tema';
$txt['theme_install_file'] = 'Da archivio locale: (e.g. .zip o .tar.gz)';
$txt['theme_install_dir'] = 'Da una cartella nel server';
$txt['theme_install_error'] = 'La cartella del tema specificato non esiste, o non contiene un tema.';
$txt['theme_install_write_error'] = 'La cartella dei temi deve essere scrivibile per continuare.';
$txt['theme_install_go'] = 'Installa';
$txt['theme_install_new'] = 'Crea una copia del tema di default di ElkArte chiamato:';
$txt['theme_install_new_confirm'] = 'Sicuro di voler installare questo nuovo tema?';
$txt['theme_install_writable'] = 'Attenzione - non puoi creare o installare un nuovo tema poiché la cartella dei temi non è scrivibile.';
$txt['theme_install_general'] = 'Il tema non sembra essere dove dovrebbe essere, controllare nuovamente le informazioni fornite.';
$txt['theme_installed'] = 'Installato con successo';
$txt['theme_installed_message'] = 'è stato installato con successo.';

$txt['theme_pick'] = 'Seleziona un tema...';
$txt['theme_preview'] = 'Anteprima del tema';
$txt['theme_set'] = 'Utilizza questo tema';
$txt['theme_user'] = 'utente sta usando questo tema.';
$txt['theme_users'] = 'utenti stanno usando questo tema.';
$txt['theme_pick_variant'] = 'Seleziona variante:';

$txt['theme_edit'] = 'Modifica il tema';
$txt['theme_edit_style'] = 'Modifica il foglio di stile (colori, caratteri, ecc.)';
$txt['theme_edit_index'] = 'Modifica il file di index (il template principale)';
$txt['theme_edit_no_save'] = 'Il file non può essere salvato perchè non è scrivibile. Controllare che il seguente file abbia i permessi impostati su 777.';
$txt['theme_edit_save'] = 'Salva le modifiche';
$txt['theme_edit_not_writable'] = 'Non modificabile';

$txt['theme_global_description'] = 'Questo è il tema predefinito: significa che cambierà in base alle scelte dell\'amministratore e della sezione che si sta visualizzando.';

$txt['theme_url_config'] = 'URL e configurazione dei temi';
$txt['theme_variants'] = 'Varianti del tema';
$txt['theme_options'] = 'Opzioni e impostazioni dei temi';
$txt['actual_theme_name'] = 'Nome del tema: ';
$txt['actual_theme_dir'] = 'Cartella del tema: ';
$txt['actual_theme_url'] = 'URL del tema: ';
$txt['actual_images_url'] = 'URL delle immagini del tema: ';

$txt['theme_variants_default'] = 'Variante predefinita del tema:';
$txt['theme_variants_user_disable'] = 'Disabilita selezione della variante per gli utenti.';

$txt['site_slogan'] = 'Slogan del sito:';
$txt['site_slogan_desc'] = '(Add your own text for a slogan here.)';
$txt['header_layout'] = 'Layout intestazione:';
$txt['header_layout_desc'] = '(queste impostazioni ti permettono di seleziona da 1 a 3 layout per l\'intesazione)';
$txt['header_layout_default_name'] = 'Default:';
$txt['header_layout_default_desc'] = 'Il logo è posizionato sulla destra ed il nome del forum sulla sinistra.';
$txt['header_layout_logo_only_name'] = 'Solo logo:';
$txt['header_layout_logo_only_desc'] = 'Solo il logo è mostrato, in una posizione centrata.';
$txt['header_layout_inverted_name'] = 'Logo a sinistra:';
$txt['header_layout_inverted_desc'] = 'Simile al default, ma con il logo e il nome invertiti (nome a destra, logo a sinistra).';
$txt['header_layout_default'] = 'Predefinito';
$txt['header_layout_logo_only'] = 'Solo logo';
$txt['header_layout_inverted'] = 'Logo a sinistra';
$txt['forum_width'] = 'Larghezza forum:';
$txt['forum_width_desc'] = '(Imposta la larghezza del forum. Esempio: 950px, 80%, 1240px.)';

$txt['enable_news'] = 'Barra delle News nell\'intestazione del forum:';
$txt['enable_news_off'] = 'Off';
$txt['enable_news_random'] = 'Casuale';
$txt['enable_news_fader'] = 'Dissolvenza';
$txt['enable_news_off_name'] = 'Off:';
$txt['enable_news_off_desc'] = 'Nessuna novità visibile.';
$txt['enable_news_random_name'] = 'Casuale:';
$txt['enable_news_random_desc'] = 'Una News scelta a caso.';
$txt['enable_news_fader_name'] = 'Dissolvenza:';
$txt['enable_news_fader_desc'] = 'Tutte le notizie sono mostrate in sequenza.';

$txt['show_group_key'] = 'Mostra i gruppi chiave sull\'indice.';
$txt['additional_options_collapsible'] = 'Abilita opzioni aggiuntive post, con menu a scomparsa.';
$txt['who_display_viewing'] = 'Mostra chi sta guardando la homepage ed i post:';
$txt['who_display_viewing_off'] = 'Non mostrare';
$txt['who_display_viewing_numbers'] = 'Mostra solo i numeri';
$txt['who_display_viewing_names'] = 'Mostra i nomi degli utenti';
$txt['show_stats_index'] = 'Mostra statistiche sulla homepage.';
$txt['latest_members'] = 'Mostra gli ultimi membri nella homepage.';
$txt['last_modification'] = 'Mostra l\'ultima modifica ai post nella homepage.';
$txt['user_avatars'] = 'Mostra gli avatar nei messaggi personali (MP).';
$txt['member_list_bar'] = 'Visualizza la barra degli utenti nell\'indice del forum';
$txt['current_pos_text_img'] = 'Mostra la posizione nel forum come link invece che testo.';
$txt['show_view_profile_button'] = 'Mostra il tasto "vedi profilo" sotto ogni post.';
$txt['enable_mark_as_read'] = 'Abilita e mostra il tasto "segna come letto"';
$txt['header_logo_url'] = 'URL del logo:';
$txt['header_logo_url_desc'] = '(Lasciare vuoto per mostrare il nome del forum o il logo predefinito)';

$txt['recent_post_topics'] = 'Show recent posts or recent topics on board index.';
$txt['show_recent_topics'] = 'Visualizza topic recenti';
$txt['show_recent_posts'] = 'Visualizza post recenti';
$txt['number_recent_posts'] = 'Number of recent posts or topics to display on board index:';
$txt['number_recent_posts_desc'] = '(To disable the recent posts/topics bar set this value to zero.)';
$txt['hide_post_group'] = 'Hide post group titles for grouped members.';
$txt['hide_post_group_desc'] = '(Enabling this will not display a member\'s post group title on the message view if they are assigned to a non-post based group.)';

$txt['theme_options_defaults'] = 'Questi sono i valori predefiniti per alcune impostazioni personali degli utenti. Un\'eventuale modifica avrà effetto solo sui nuovi iscritti.';
$txt['theme_options_title'] = 'Cambia o ripristina le opzioni predefinite';

$txt['themeadmin_title'] = 'Gestione Temi e Opzioni';
$txt['themeadmin_description'] = 'Da qui si possono modificare le impostazioni dei temi, aggiornare le scelte dei temi, azzerare le opzioni degli utenti e altro ancora.';
$txt['themeadmin_admin_desc'] = 'Themes provide the different \'looks and feels\' of your forum. Theme Management and Options allow you to install new site themes, change the default theme, reset all members to use a certain theme, and choose other settings related to theme selection. Remember to look at the theme settings for your different themes for their individual layout options.';
$txt['themeadmin_list_desc'] = 'In the Theme Settings area you can view the list of themes that you have installed, change their directory paths and settings, and uninstall them.';
$txt['themeadmin_reset_desc'] = 'In the Member Options area you have the ability to change theme-specific options that affect all members. You will only see those themes that have their own set of option settings.';
$txt['themeadmin_edit_desc'] = 'In the Modify Themes area you can alter the stylesheet and source code of your installed themes. You will need a basic understanding of CSS and PHP to effectively change a theme and not break your forum at the same time.';
$txt['themeadmin_modify_styles'] = 'Changing a themes style is risky so be certain of what you are doing. Always have a backup copy of the theme directory that you are working in to use to recover from an error with. For help with this before you start, visit the <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">ElkArte Community</a>.';

$txt['themeadmin_list_heading'] = 'Impostazioni Temi';
$txt['themeadmin_list_tip'] = 'The layout settings may be different for each installed theme. Edit the installed themes to set their individual options, change their directory or URL settings, or to find other options.';
$txt['themeadmin_list_theme_dir'] = 'Cartella del tema: (templates)';
$txt['themeadmin_list_invalid'] = '(Attenzione! Il percorso non è corretto.)';
$txt['themeadmin_list_theme_url'] = 'Indirizzo della cartella superiore:';
$txt['themeadmin_list_images_url'] = 'URL della cartella di immagini:';
$txt['themeadmin_list_reset'] = 'Resetta gli indirizzi e le cartelle del tema';
$txt['themeadmin_list_reset_dir'] = 'Percorso di base alla cartella Themes:';
$txt['themeadmin_list_reset_url'] = 'Indirizzo di base alla stessa cartella:';
$txt['themeadmin_list_reset_go'] = 'Prova a reimpostare tutti i temi';

$txt['themeadmin_reset_tip'] = 'Each theme may have custom options available for selection by your members. These include options like &quot;quick reply&quot;, avatars, signatures, layout options and other similar options.  This is where you can change the defaults or reset everyone\'s options.<br /><br />Remember this: A theme may be designed with some settings as the default. In which case you will not see a setting for those options.';
$txt['themeadmin_reset_defaults'] = 'Imposta le opzioni per i visitatori ed i nuovi utenti per questo tema';
$txt['themeadmin_reset_defaults_current'] = 'opzioni attualmente impostate.';
$txt['themeadmin_reset_members'] = 'Modifica le opzioni per tutti gli utenti che utilizzano questo tema';
$txt['themeadmin_reset_remove'] = 'Rimuove tutte le opzioni impostate dagli utenti e reimposta quelle predefinite';
$txt['themeadmin_reset_remove_current'] = 'utenti al momento utilizzano le proprie opzioni.';
// Don't use entities in the below string.
$txt['themeadmin_reset_remove_confirm'] = 'Vuoi azzerare tutte le impostazioni del tema?\\nCiò potrebbe eliminare anche alcuni campi personalizzati del profilo.';
$txt['themeadmin_reset_options_info'] = 'The options below will reset options for <em>everyone</em>.  To change an option, select &quot;change&quot; in the box next to it, and then select a value for it.  To use the default, select &quot;default&quot;.  Otherwise, use &quot;don\'t change&quot; to keep it as-is.';
$txt['themeadmin_reset_options_change'] = 'Modifica';
$txt['themeadmin_reset_options_none'] = 'Non modificare';
$txt['themeadmin_reset_options_default'] = 'Predefinito';

$txt['themeadmin_edit_browse'] = 'Sfoglia i template e i file di questo tema.';
$txt['themeadmin_edit_style'] = 'Modifica il foglio di stile per questo tema.';
$txt['themeadmin_edit_copy_template'] = 'Copia un template dal tema su cui si basa questo.';
$txt['themeadmin_edit_exists'] = 'è già esistente';
$txt['themeadmin_edit_do_copy'] = 'copia';
$txt['themeadmin_edit_copy_warning'] = 'When the system needs a template or language file which is not in the current theme, it looks in the theme it is based on, or the default theme.<br />Unless you need to modify a template, it\'s better not to copy it.';
$txt['themeadmin_edit_copy_confirm'] = 'Si vuole copiare questo template?';
$txt['themeadmin_edit_overwrite_confirm'] = 'Are you sure you want to copy this template over the one that already exists?\nThis will OVERWRITE any changes you\\\'ve made';
$txt['themeadmin_edit_no_copy'] = '<em>(impossibile copiare)</em>';
$txt['themeadmin_edit_filename'] = 'Nome file';
$txt['themeadmin_edit_modified'] = 'Ultima modifica';
$txt['themeadmin_edit_size'] = 'Dimensione';
$txt['themeadmin_edit_error'] = 'Il file che hai tentato di salvare ha generato il seguente errore:';
$txt['themeadmin_edit_on_line'] = 'Beginning on line:';
$txt['themeadmin_edit_preview'] = 'Anteprima';
$txt['themeadmin_selectable'] = 'Temi selezionabili dagli utenti:';
$txt['themeadmin_themelist_link'] = 'Mostra la lista dei temi';

// Strings for the variants
$txt['variant_light'] = 'ElkArte Light';
$txt['variant_besocial'] = 'ElkArte Be Social!';
