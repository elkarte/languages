<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Gestione sezioni e categorie';
$txt['order'] = 'Ordine';
$txt['full_name'] = 'Nome completo';
$txt['name_on_display'] = 'Questo è il nome che verrà visualizzato.';
$txt['boards_and_cats_desc'] = 'Modifica qui le tue categorie e sezioni. Elenca i moderatori <em>&quot;username&quot;, &quot;username&quot;</em>. (inserire gli Username e NON i nomi reali)<br />Per creare una nuova sezione, clica il bottone "Aggiungi Sezione".<br />Puoi spostare una sezione tramite Drag&Drop in una nuova posizione nell\'elenco (attraverso categorie e posizioni orfane)<br />To create a new board as a child of a current board, select "Child of..." from the Order drop down menu when creating the board.';
$txt['parent_members_only'] = 'Utenti Normali';
$txt['parent_guests_only'] = 'Visitatori';
$txt['catConfirm'] = 'Sei sicuro di voler eliminare questa categoria?';
$txt['boardConfirm'] = 'Sei sicuro di voler eliminare questa sezione?';

$txt['catEdit'] = 'Modifica categoria';
$txt['collapse_enable'] = 'Contraibile';
$txt['collapse_desc'] = 'Consente agli utenti di contrarre questa categoria';
$txt['catModify'] = '[modifica]';

$txt['mboards_order_after'] = 'Dopo ';
$txt['mboards_order_first'] = 'In prima posizione';
$txt['mboards_board_error'] = 'Impossibile completare lo spostamento.';

$txt['mboards_new_board'] = 'Aggiungi sezione';
$txt['mboards_new_cat_name'] = 'Nuova categoria';
$txt['mboards_add_cat_button'] = 'Aggiungi categoria';
$txt['mboards_new_board_name'] = 'Nuova sezione';

$txt['mboards_modify'] = 'modifica';
$txt['mboards_permissions'] = 'permessi';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Vuoi convertire questa sezione all\'utilizzo dei permessi locali?';

$txt['mboards_delete_cat'] = 'Elimina categoria';
$txt['mboards_delete_board'] = 'Elimina sezione';

$txt['mboards_delete_cat_contains'] = 'Eliminando questa categoria verranno rimosse anche le sezioni contenute, inclusi tutti i topic, i post e gli allegati';
$txt['mboards_delete_option1'] = 'Elimina la categoria e tutte le sezioni contenute.';
$txt['mboards_delete_option2'] = 'Elimina la categoria e sposta tutte le sezioni contenute in';
$txt['mboards_delete_board_contains'] = 'Eliminando questa sezione verranno spostate anche le sottosezioni qui sotto, compresi tutti i topic, i post e gli allegati all\'interno di ogni sottosezione';
$txt['mboards_delete_board_option1'] = 'Elimina la sezione e sposta le sottosezioni in essa contenute al livello della categoria.';
$txt['mboards_delete_board_option2'] = 'Elimina la sezione e sposta le sottosezioni in essa contenute in';
$txt['mboards_delete_what_do'] = 'Scegliere cosa fare con queste sezioni';
$txt['mboards_delete_confirm'] = 'Conferma';
$txt['mboards_delete_cancel'] = 'Annulla';

$txt['mboards_category'] = 'Categoria';
$txt['mboards_description'] = 'Descrizione';
$txt['mboards_description_desc'] = 'Una breve descrizione della sezione.<br />Puoi usare codici BBC per formattare la tua descrizione.';
$txt['mboards_groups'] = 'Gruppi autorizzati';
$txt['mboards_groups_desc'] = 'Gruppi autorizzati ad accedere a questa sezione.<br /><em>Nota: se l\'utente ha spuntato qualsiasi gruppo o gruppo messaggi, avrà accesso a questa sezione.</em>';
$txt['mboards_groups_regular_members'] = 'Questo gruppo contiene tutti gli utenti a cui non è stato assegnato un gruppo primario.';
$txt['mboards_groups_post_group'] = 'Questo gruppo è basato sul numero di post.';
$txt['mboards_moderators'] = 'Moderatori';
$txt['mboards_moderators_desc'] = 'Gli utenti che hanno i privilegi di moderatore in questa sezione. Non è necessario elencare gli amministratori.';
$txt['mboards_count_posts'] = 'Numero messaggi';
$txt['mboards_count_posts_desc'] = 'Nuovi post o topic inseriti in questa sezione incrementano il contatore dei messaggi dell\'utente.';
$txt['mboards_unchanged'] = 'Non modificata';
$txt['mboards_theme'] = 'Tema sezione';
$txt['mboards_theme_desc'] = 'Permette di cambiare lo stile del forum all\'interno di una specifica sezione.';
$txt['mboards_theme_default'] = '(predefinito del forum)';
$txt['mboards_override_theme'] = 'Sostituzione tema dell\'utente';
$txt['mboards_override_theme_desc'] = 'Utilizza questo tema per la sezione, anche se l\'utente ha specificato un tema personalizzato.';

$txt['mboards_redirect'] = 'Reindirizza ad un sito web';
$txt['mboards_redirect_desc'] = 'Abilita questa opzione per reindirizzare chiunque clicchi su questa sezione verso un altro indirizzo web.';
$txt['mboards_redirect_url'] = 'Sito di reindirizzamento';
$txt['mboards_redirect_url_desc'] = 'Ad esempio: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Azzerra il contatore dei reindirizzamenti';
$txt['mboards_redirect_reset_desc'] = 'Selezionando questa opzione, verrà azzerato il conteggio dei reindirizzamenti per questa sezione.';
$txt['mboards_current_redirects'] = 'Attualmente: %1$s';
$txt['mboards_redirect_disabled'] = 'Nota: la sezione deve essere vuota per poter abilitare questa opzione.';
$txt['mboards_redirect_disabled_recycle'] = 'Nota: non puoi impostare la sezione dedicata ai post eliminati (Cestino) come sezione di reindirizzamento.';

$txt['mboards_order_before'] = 'Prima';
$txt['mboards_order_child_of'] = 'Sottosezione di';
$txt['mboards_order_in_category'] = 'Nella categoria';
$txt['mboards_current_position'] = 'Posizione corrente';
$txt['no_valid_parent'] = 'La sottosezione %1$s non appartiene ad alcuna sezione valida. Utilizza la funzione "Cerca e ripara gli errori" per risolvere il problema.';

$txt['mboards_recycle_disabled_delete'] = 'Devi selezionare un cestino alternativo o disabilitare il "riciclaggio" prima di poter eliminare questa sezione.';

$txt['mboards_settings_desc'] = 'Modifica impostazioni generali per la sezione e la categoria.';
$txt['groups_manage_boards'] = 'Gruppi che possono gestire sezioni e categorie';
$txt['recycle_enable'] = 'Abilita cestino per i topic eliminati';
$txt['recycle_board'] = 'Sezione per i topic eliminati';
$txt['recycle_board_unselected_notice'] = 'Hai abilitato il riciclo dei topic senzare specificare la sezione-cestino. Questa opzione non verrà abilitata fino a quando non avrai specificato una sezione dedicata ai topic eliminati.';
$txt['countChildPosts'] = 'Calcola i post delle sottosezioni nei totali della sezione principale';
$txt['allow_ignore_boards'] = 'Permetti di ignorare alcune sezioni';
$txt['deny_boards_access'] = 'Abilita l\'opzione per impedire l\'accesso alla sezione in base al gruppo';
$txt['boardsaccess_option_desc'] = 'Per ogni autorizzazione puoi scegliere \'Consenti\' (C), \'Ignora\' (X), o <span class="alert">\'Nega\' (N)</span>.<br /><br />Ricordarsi che se si nega un\'autorizzazione, sarà negata anche a ogni utente - (inclusi i moderatori) - presente in quel gruppo.<br />Per questa ragione, occorre usare con attenzione la funzione nega e solo quando <strong>necessario</strong>. D\'altra parte, \'ignora\' nega l\'autorizzazione a meno che questa non venga assegnata altrove.';

$txt['mboards_select_destination'] = 'Seleziona destinazione per la sezione \'<strong>%1$s</strong>\'';
$txt['mboards_cancel_moving'] = 'Annulla spostamento';
$txt['mboards_move'] = 'sposta';

$txt['mboards_no_cats'] = 'Al momento non sono presenti categorie o sezioni configurate.';
