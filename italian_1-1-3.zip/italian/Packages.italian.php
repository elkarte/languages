<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Procedi';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Elenca i file nel pacchetto MOD';
$txt['files_archive'] = 'File contenuti nell\'archivio';
$txt['package_browse'] = 'Sfoglia';
$txt['add_server'] = 'Aggiungi server';
$txt['server_name'] = 'Nome server';
$txt['serverurl'] = 'URL';
$txt['no_packages'] = 'Non è presente alcuna MOD.';
$txt['download'] = 'Scarica';
$txt['download_success'] = 'Pacchetto MOD scaricato con successo';
$txt['package_downloaded_successfully'] = 'Il pacchetto MOD è stato scaricato con successo';
$txt['package_manager'] = 'Gestione MOD';
$txt['install_mod'] = 'Installa Add-on';
$txt['uninstall_mod'] = 'Disinstalla Add-on';
$txt['no_adds_installed'] = 'Nessun addon attualmente installato.';
$txt['uninstall'] = 'Disinstalla';
$txt['delete_list'] = 'Elimina lista add-on';
$txt['package_delete_list_warning'] = 'Sei sicuro di voler eliminare la lista degli addon installati?';

$txt['package_manager_desc'] = 'Da questa interfaccia semplice da usare, puoi scaricare e installare addon da usare sul tuo forum.';
$txt['installed_packages_desc'] = 'È possibile utilizzare l\'interfaccia qui sotto per visualizzare le MOD installate al momento nel forum ed eliminare quelle non più necessarie.';
$txt['download_packages_desc'] = 'Da questa sezione puoi aggiungere o rimuovere server di pacchetti, sfogliare i pacchetti, o scaricare nuovi pacchetti dai server.';
$txt['package_servers_desc'] = 'Da questa interfaccia semplice da usare, puoi gestire i tuoi server di pacchetti e scaricare archivi di addon nel tuo forum.';
$txt['upload_packages_desc'] = 'Da qui puoi caricare un file di pacchetti dal tuo computer direttamente nel forum.';

$txt['upload_new_package'] = 'Carica un nuovo pacchetto';
$txt['view_and_remove'] = 'Visualizza e rimuovi i pacchetti installati';
$txt['modification_package'] = 'Pacchetti add-on';
$txt['avatar_package'] = 'Pacchetti avatar';
$txt['language_package'] = 'Pacchetti di traduzioni';
$txt['unknown_package'] = 'Altri pacchetti';
$txt['smiley_package'] = 'Pacchetto di smiley';
$txt['use_avatars'] = 'Utilizzare avatar';
$txt['add_languages'] = 'Aggiungi traduzione';
$txt['list_files'] = 'Elenco dei file';
$txt['package_type'] = 'Tipo di pacchetto';
$txt['extracting'] = 'Estrazione in corso';
$txt['avatars_extracted'] = 'Gli avatar sono stati installati e sono ora utilizzabili.';
$txt['language_extracted'] = 'Il pacchetto della lingua è stato installato, ora puoi abilitarne l\'uso nelle impostazioni delle';

$txt['mod_name'] = 'Nome add-on';
$txt['mod_version'] = 'Versione';
$txt['mod_author'] = 'Autore';
$txt['author_website'] = 'Sito web dell\'autore';
$txt['package_no_description'] = 'Nessuna descrizione disponibile';
$txt['package_description'] = 'Descrizione';
$txt['file_location'] = 'Scarica';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Supporto';
$txt['mod_hooks'] = 'Nessuna modifica al codice sorgente';
$txt['mod_date'] = 'Ultimo aggiornamento';
$txt['mod_section_count'] = 'Sfoglia i (%1d) addons in questa sezione';

// Package Server strings
$txt['package_current'] = '(%s <em>Hai la versione attuale %s</em>)';
$txt['package_update'] = '(%s <em>Un aggiornamento per la tua versione %s è disponibile</em>)';
$txt['package_installed'] = 'Installato';
$txt['package_downloaded'] = 'scaricato';

$txt['package_installed_key'] = 'Addon installati:';
$txt['package_installed_current'] = 'versione aggiornata';
$txt['package_installed_old'] = 'versione obsoleta';
$txt['package_installed_warning1'] = 'Questo pacchetto è già installato e non è stato trovato alcun aggiornamento.';
$txt['package_installed_warning2'] = 'Disinstalla prima la versione precedente per evitare problemi, oppure chiedi all\'autore di creare un aggiornamento per questo pacchetto.';
$txt['package_installed_warning3'] = 'Ricordati di effettuare sempre un backup del database e dei file contenuti nella cartella "Sources" prima di effettuare le modifiche, specialmente se la MOD è ancora in versione beta.';
$txt['package_installed_extract'] = 'Estrazione del pacchetto in corso';
$txt['package_installed_done'] = 'Il pacchetto è stato installato con successo. Dovrebbe essere ora possibile utilizzare le funzionalità aggiunte dalla MOD oppure visualizzare le modifiche apportate.';
$txt['package_installed_redirecting'] = 'Reindirizzamento in corso...';
$txt['package_installed_redirect_go_now'] = 'Reindirizza ora';
$txt['package_installed_redirect_cancel'] = 'Torna alla gestione pacchetti';

$txt['package_upgrade'] = 'Aggiorna';
$txt['package_uninstall_readme'] = 'Leggimi della Disinstallazione';
$txt['package_install_readme'] = 'Istruzioni per l\'installazione';
$txt['package_install_license'] = 'Licenza';
$txt['package_install_type'] = 'Tipo';
$txt['package_install_action'] = 'Azione';
$txt['package_install_desc'] = 'Descrizione';
$txt['install_actions'] = 'Processo di installazione';
$txt['perform_actions'] = 'Questo eseguirà le seguenti azioni:';
$txt['corrupt_compatible'] = 'Il pacchetto che stai provando a scaricare o installare è corrotto o non compatibile con questa versione del software.';
$txt['package_create'] = 'Crea';
$txt['package_move'] = 'Sposta';
$txt['package_delete'] = 'Cancella';
$txt['package_extract'] = 'Estrai';
$txt['package_file'] = 'File';
$txt['package_tree'] = 'Albero';
$txt['execute_modification'] = 'Esegui modifiche';
$txt['execute_code'] = 'Esegui codice';
$txt['execute_database_changes'] = 'Esegui file';
$txt['execute_hook_add'] = 'Aggiungi hook';
$txt['execute_hook_remove'] = 'Rimuovi hook';
$txt['execute_hook_action'] = 'Adattamento hook %1$s';
$txt['package_requires'] = 'Richiede modifica';
$txt['package_check_for'] = 'Verificare per l\'installazione:';
$txt['execute_credits_add'] = 'Aggiungi ringraziamenti';
$txt['execute_credits_action'] = 'Ringraziamenti: %1$s';

$txt['package_install_actions'] = 'Azioni per l\'installazione di';
$txt['package_will_fail_title'] = 'Errore nel pacchetto %1$s';
$txt['package_will_fail_warning'] = 'Si è verificato almeno un errore durante la prova %1$s di questo pacchetto. Si consiglia <strong>caldamente</strong> di non continuare con l\'installazione in caso di dubbi su quello che si sta facendo e di avere una copia di sicurezza molto recente. Tale errore potrebbe essere causato da un conflitto tra il pacchetto che si sta installando e un\'altro già installato, da un problema nel pacchetto, da un pacchetto che necessita di un altro pacchetto non ancora installato, oppure da un pacchetto preparato per un\'altra versione del software.';
$txt['package_will_fail_unknown_action'] = 'Il pacchetto sta tentando di eseguire un azione sconosciuta: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Vuoi continuare ad installare questo addon, anche se non verrà installato correttamente?';
$txt['package_will_fail_popup_uninstall'] = 'Sei sicuro di voler continuare la disinstallazione di questo pacchetto, anche se la procedura darà luogo ad errori?';
$txt['package_install'] = 'installazione';
$txt['package_uninstall'] = 'rimozione';
$txt['package_install_now'] = 'Installa ora';
$txt['package_uninstall_now'] = 'Disinstalla ora';
$txt['package_other_themes'] = 'Installa in altri temi';
$txt['package_other_themes_uninstall'] = 'Disinstalla in altri temi';
$txt['package_other_themes_desc'] = 'Usa questo addon nei temi oltre a quello base, il gestore pacchetti dovrà fare ulteriori modifiche agli altri temi. Se vuoi installare questo addon negli altri temi, selezionali qui sotto.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Almeno un errore è stato riscontrato durante un test di installazione di questo tema. Vuoi veramente continuare con l\'installazione?';

$txt['package_bytes'] = 'byte';

$txt['package_action_missing'] = '<strong class="error">File non trovato</strong>';
$txt['package_action_error'] = '<strong class="error">Errore durante il parsing della modifica</strong>';
$txt['package_action_failure'] = '<strong class="error">Test fallito</strong>';
$txt['package_action_success'] = '<strong>Prova eseguita con successo</strong>';
$txt['package_action_skipping'] = '<strong>Sto ignorando il file</strong>';

$txt['package_uninstall_actions'] = 'Azioni di disinstallazione';
$txt['package_uninstall_done'] = 'Il pacchetto è stato disinstallato correttamente.';
$txt['package_uninstall_cannot'] = 'Questo pacchetto non può essere disinstallato, perchè non è stata trovata la procedura di disinstallazione.<br /><br />Contatta l\'autore del pacchetto per ulteriori informazioni.';

$txt['package_install_options'] = 'Opzioni di disinstallazione';
$txt['package_install_options_desc'] = 'Imposta varie opzioni su come il gestore pacchetti installa addon, compresi backup e accesso FTP.';
$txt['package_install_options_ftp_why'] = 'L\'utilizzo della funzionalità FTP della Gestione pacchetti è la via più semplice per evitare la modifica manuale, tramite FTP, dei permessi in scrittura dei file per il corretto funzionamento della gestione pacchetti.<br />Qui è possibile impostare i valori predefiniti per alcuni campi.';
$txt['package_install_options_ftp_server'] = 'Server FTP';
$txt['package_install_options_ftp_port'] = 'Porta';
$txt['package_install_options_ftp_user'] = 'Username';
$txt['package_install_options_make_backups'] = 'Crea versioni di backup dei file sostituiti aggiungendo una tilde (~) alla fine del nome.';
$txt['package_install_options_make_full_backups'] = 'Crea un backup di tutta l\'installazione di ElkArte (escludendo smiley, avatar e allegati).';

$txt['package_ftp_necessary'] = 'Informazioni FTP necessarie';
$txt['package_ftp_why'] = 'Alcuni file che devono essere modificati dal manger pacchetti non sono scrivibili. Questi dovranno essere modificati tramite FTP usando chmod o creando nuovi file e directory. I tuoi dati di login verranno salvati temporaneamente per svolgere tutte le operazioni. Puoi anche effettuare manualmente queste operazioni tramite FTP - <a href="#" onclick="%1$s">per vedere la lista dei cambiamenti clicca qui</a>.';
$txt['package_ftp_why_file_list'] = 'Per continuare l\'installazione, è necessario che i seguenti file vengano impostati come scrivibili:';
$txt['package_ftp_why_download'] = 'Per scaricare i pacchetti, la directory dei pacchetti stessa ed ogni file incluso devono essere scrivibili. Attualmente il sistema non ha i permessi necessari per farlo. Il manger pacchetti può usare i tuoi dati FTP per risolvere questo problema.';
$txt['package_ftp_server'] = 'Server FTP';
$txt['package_ftp_port'] = 'Porta';
$txt['package_ftp_username'] = 'Username';
$txt['package_ftp_password'] = 'Password';
$txt['package_ftp_path'] = 'Percorso locale per ElkArte';
$txt['package_ftp_test'] = 'Test';
$txt['package_ftp_test_connection'] = 'Test della connessione';
$txt['package_ftp_test_success'] = 'Connessione FTP stabilita.';
$txt['package_ftp_test_failed'] = 'Non è stato possibile contattare il server.';
$txt['package_ftp_bad_server'] = 'Non è stato possibile contattare il server.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Il pacchetto che si sta per eliminare è al momento installato! Se viene eliminato non sarà possibile disinstallarlo in seguito.\\n\\nVuoi procedere comunque?';

$txt['package_examine_file'] = 'Visualizza file nel pacchetto';
$txt['package_file_contents'] = 'Contenuto del file';

$txt['package_upload_title'] = 'Carica un pacchetto';
$txt['package_upload_select'] = 'Pacchetto da caricare';
$txt['package_upload'] = 'Carica';
$txt['package_uploaded_success'] = 'Pacchetto caricato con successo';
$txt['package_uploaded_successfully'] = 'Il pacchetto è stato caricato con successo';

$txt['package_modification_malformed'] = 'File addon malformato o non valido.';
$txt['package_modification_missing'] = 'Il file non è stato trovato.';
$txt['package_no_zlib'] = 'Spiacente, la configurazione di PHP non fornisce la libreria <strong>zlib</strong>.  Senza di essa la gestione dei pacchetti non può funzionare.  Contattare il servizio di hosting riguardo questo problema per ulteriori informazioni.';

$txt['package_cleanperms_title'] = 'Ripristina permessi';
$txt['package_cleanperms_desc'] = 'Questa interfaccia permette di modificare i permessi per i file su tutta l\'installazione, così da poter aumentare la sicurezza o risolvere qualsiasi problema di permessi sorto durante l\'installazione dei pacchetti.';
$txt['package_cleanperms_type'] = 'Cambia tutti i permessi per i file su tutto il forum in maniera tale che';
$txt['package_cleanperms_standard'] = 'Solo i file standard siano accessibili in scrittura.';
$txt['package_cleanperms_free'] = 'Tutti i file siano accessibili in scrittura.';
$txt['package_cleanperms_restrictive'] = 'Il numero minimo di file sia accessibile in scrittura.';
$txt['package_cleanperms_go'] = 'Cambia i permessi dei file';

$txt['package_download_by_url'] = 'Scarica un pacchetto dall\'URL';
$txt['package_download_filename'] = 'Nome del file';
$txt['package_download_filename_info'] = 'Valore opzionale. Deve essere utilizzato quando l\'url non finisce con il nome del file. Ad esempio: index.php?mod=5';

$txt['package_db_uninstall'] = 'Cancella tutti i dati relativi a questo addon.';
$txt['package_db_uninstall_details'] = 'Dettagli';
$txt['package_db_uninstall_actions'] = 'Selezionare questa opzione comporterà le seguenti azioni';
$txt['package_db_remove_table'] = 'Scarta tabella &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Rimuovi colonna &quot;%1$s&quot; da &quot;%2$s&quot;';
$txt['package_db_remove_index'] = 'Rimuovi l\'indice &quot;%1$s&quot; da &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Installa emulatore:';
$txt['package_emulate_uninstall'] = 'Disinstalla emulatore:';

// Operations.
$txt['operation_find'] = 'Trova';
$txt['operation_replace'] = 'Sostituisci';
$txt['operation_after'] = 'Aggiungi dopo';
$txt['operation_before'] = 'Aggiungi prima';
$txt['operation_title'] = 'Operazioni';
$txt['operation_ignore'] = 'Ignora errori';
$txt['operation_invalid'] = 'L\'operazione selezionata non è valida.';

$txt['package_file_perms_desc'] = 'Puoi utilizzare questa sezione per rivedere i permessi di scrittura per i file e le cartelle importanti presenti nella tua directory del forum. N.B: verranno considerati solo i i file e le cartelle chiave di SMF, utilizza un client FTP per informazioni aggiuntive su altri file.';
$txt['package_file_perms_name'] = 'Nome file/cartella';
$txt['package_file_perms_status'] = 'Stato attuale';
$txt['package_file_perms_new_status'] = 'Nuovo stato';
$txt['package_file_perms_status_read'] = 'Letto';
$txt['package_file_perms_status_write'] = 'Scrittura';
$txt['package_file_perms_status_execute'] = 'Esecuzione';
$txt['package_file_perms_status_custom'] = 'Personalizzato';
$txt['package_file_perms_status_no_change'] = 'Nessun cambiamento';
$txt['package_file_perms_writable'] = 'Scrivibile';
$txt['package_file_perms_not_writable'] = 'Non modificabile';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Ulteriori file';

$txt['package_file_perms_change'] = 'Cambia i permessi del file';
$txt['package_file_perms_predefined'] = 'Utilizza il profilo predefinito per i permessi';
$txt['package_file_perms_predefined_note'] = 'Si noti che questo vale solo il profilo predefinito alle directory principali ed i file.';
$txt['package_file_perms_apply'] = 'Applica le impostazioni, selezionate in alto, dei permessi individuali.';
$txt['package_file_perms_custom'] = 'Se è stato selezionato &quot;Personalizzato&quot;, utilizza il valore chmod ';
$txt['package_file_perms_pre_restricted'] = 'Ristretto - Numero minimo di file scrivibili';
$txt['package_file_perms_pre_standard'] = 'Standard - I file chiave sono scrivibili';
$txt['package_file_perms_pre_free'] = 'Libero - Tutti i file sono scrivibili';
$txt['package_file_perms_ftp_details'] = 'Nella maggior parte dei server, è possibile cambiare i permessi dei file solo utilizzando un account FTP. Inserisci i relativi dati in basso';
$txt['package_file_perms_ftp_retain'] = 'Nota, il sistema conserverà solo le informazioni sulla password temporaneamente per aiutare il funzionamento del gestore di pacchetti.';
$txt['package_file_perms_go'] = 'Effettua le modifiche';

$txt['package_file_perms_applying'] = 'Applicazione delle modifiche in corso';
$txt['package_file_perms_items_done'] = 'Completati %1$d oggetti di %2$d ';
$txt['package_file_perms_skipping_ftp'] = '<strong>Attenzione:</strong> Non è stato possibile collegarsi al server FTP, è in corso il cambio dei permessi senza il supporto FTP. E\' <em>probabile</em> che questa operazione fallisca - verifica i risultati al completamento e se necessario, riprova la connessione con i dati FTP corretti.';

$txt['package_file_perms_dirs_done'] = 'Completate %1$d cartelle di %2$d ';
$txt['package_file_perms_files_done'] = 'Eseguiti %1$d file di %2$d nell\'attuale cartella';

$txt['chmod_value_invalid'] = 'Hai inserito un valore chmod errato. I chmod devono essere compresi tra 0444 e 0777';

$txt['package_restore_permissions'] = 'Ripristina permessi file';
$txt['package_restore_permissions_desc'] = 'I seguenti permessi verranno modificati per poter installare i pacchetti selezionati. Puoi ripristinare questi file allo stato originale cliccando &quot;Restore&quot; sotto.';
$txt['package_restore_permissions_restore'] = 'Ripristina';
$txt['package_restore_permissions_filename'] = 'Nome file';
$txt['package_restore_permissions_orig_status'] = 'Stato originale';
$txt['package_restore_permissions_cur_status'] = 'Stato attuale';
$txt['package_restore_permissions_result'] = 'Risultato';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - era %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Saltato</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Riuscito</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Fallito</span>';
$txt['package_restore_permissions_action_done'] = 'Un tentativo di ripristinare i file selezionati ai permessi originali è stato completato, puoi vedere le modifiche di seguito. Se una modifica è fallita, o per maggiori dettagli, visita la sezione <a href="%1$s">Permessi File</a> .';

$txt['package_file_perms_warning'] = 'Fai attenzione';
$txt['package_file_perms_warning_desc'] = '
	Attenzione quando vengono modificati i permessi in questa sezione - permessi sbagliati possono influenzare negativamente il funzionamento del tuo forum!<br />
	Su alcune configurazioni del server, selezionando i permessi sbagliati si può bloccare il forum.<br />
	Alcune directory come <em> allegati </ em> devono essere scrivibili per utilizzare tale funzionalità.<br />
	Questa funzionalità è principalmente applicabile su server "non Windows" -  su Windows i permessi non funzioneranno come previsto.<br />
	Prima di procedere assicuratevi di aver un client FTP installato, per porvi rimedio nel caso di errore.';

$txt['package_confirm_view_package_content'] = 'Vuoi realmente visualizzare i contenuti di questo pacchetto da:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Procedi';
$txt['package_confirm_go_back'] = 'Torna indietro';

$txt['package_readme_default'] = 'Predefinito';
$txt['package_available_readme_language'] = 'Traduzioni disponibili per file Leggimi:';
$txt['package_license_default'] = 'Predefinito';
$txt['package_available_license_language'] = 'Licenza disponibile nelle lingue:';