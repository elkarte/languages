<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Manutenzioni programmate';
$txt['scheduled_tasks_header'] = 'Tutte le azioni programmate';
$txt['scheduled_tasks_name'] = 'Nome azione';
$txt['scheduled_tasks_next_time'] = 'La prossima è prevista per';
$txt['scheduled_tasks_regularity'] = 'Regolarità';
$txt['scheduled_tasks_enabled'] = 'Abilitata';
$txt['scheduled_tasks_run_now'] = 'Esegui ora la manutenzione programmata';
$txt['scheduled_tasks_save_changes'] = 'Salva le modifiche';
$txt['scheduled_tasks_time_offset'] = '<strong>Nota:</strong> Tutti gli orari forniti qui adottano il <em>fuso orario del server</em> e non usano nessun set orario impostato nel pannello admin.';
$txt['scheduled_tasks_were_run'] = 'Tutte le azioni selezionate sono state eseguite';
$txt['scheduled_tasks_were_run_errors'] = 'I seguenti errori si sono verificati durante le attività di manutenzione:';

$txt['scheduled_tasks_na'] = 'N/D';
$txt['scheduled_task_approval_notification'] = 'Approvazione notifiche';
$txt['scheduled_task_desc_approval_notification'] = 'Invia e-mail a tutti i moderatori per segnalare i post in attesa di approvazione.';
$txt['scheduled_task_auto_optimize'] = 'Ottimizza database';
$txt['scheduled_task_desc_auto_optimize'] = 'Ottimizza il database per risolvere problemi di frammentazione.';
$txt['scheduled_task_daily_maintenance'] = 'Manutenzione giornaliera';
$txt['scheduled_task_desc_daily_maintenance'] = 'Esegue la manutenzione giornaliera ed essenziale sul forum - non deve essere disabilitata.';
$txt['scheduled_task_daily_digest'] = 'Sommario delle notifiche giornaliere';
$txt['scheduled_task_desc_daily_digest'] = 'Invia per e-mail un riassunto giornaliero a chi ha sottoscritto la notifica.';
$txt['scheduled_task_weekly_digest'] = 'Sommario delle notifiche settimanali';
$txt['scheduled_task_desc_weekly_digest'] = 'Invia per e-mail un riassunto settimanale a chi ha sottoscritto la notifica.';
$txt['scheduled_task_birthdayemails'] = 'Manda e-mail di compleanno';
$txt['scheduled_task_desc_birthdayemails'] = 'Invia e-mail di auguri agli utenti per augurare loro un buon compleanno.';
$txt['scheduled_task_weekly_maintenance'] = 'Manutenzione settimanale';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Esegui la manutenzione essenziale e settimanale del forum - non dovrebbe essere disabilitata.';
$txt['scheduled_task_paid_subscriptions'] = 'Controllo delle sottoscrizioni a pagamento';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Invia i promemoria per le sottoscrizioni a pagamento ancora non rinnovate e rimuovi quelle già scadute.';
$txt['scheduled_task_remove_topic_redirect'] = 'Remove MOVED: Redirection Topics';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Deletes "MOVED:" topic notifications as specified when the moved notice was created.';
$txt['scheduled_task_remove_temp_attachments'] = 'Rimuove i file allegati temporanei';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Elimina file temporanei creati postando dei file che per qualsiasi ragione non sono stati rinominati o eliminati precedentemente.';
$txt['scheduled_task_remove_old_drafts'] = 'Rimuovi bozze vecchie';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Deletes drafts older than the number of days defined in the draft settings in the admin panel.';
$txt['scheduled_task_remove_old_followups'] = 'Remove Old Follow-ups';
$txt['scheduled_task_desc_remove_old_followups'] = 'Deletes follow-up entries still present in the database, but pointing to non-existent topics.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Fetch Emails from IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Fetches emails for the mailing list feature from an IMAP box and processes them.';
$txt['scheduled_task_user_access_mentions'] = 'Users Mentions Access';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verify users access to each board and set accessibility to related mentions accordingly.';

$txt['scheduled_task_reg_starting'] = 'Inizio alle %1$s';
$txt['scheduled_task_reg_repeating'] = 'ripeti ogni %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minuto/i';
$txt['scheduled_task_reg_unit_h'] = 'ora/e';
$txt['scheduled_task_reg_unit_d'] = 'giorno/i';
$txt['scheduled_task_reg_unit_w'] = 'settimana/e';

$txt['scheduled_task_edit'] = 'Modifica l\'azione programmata';
$txt['scheduled_task_edit_repeat'] = 'Ripeti l\'azione ogni';
$txt['scheduled_task_edit_pick_unit'] = 'Seleziona un\'unità';
$txt['scheduled_task_edit_interval'] = 'Intervallo';
$txt['scheduled_task_edit_start_time'] = 'Orario di inizio';
$txt['scheduled_task_edit_start_time_desc'] = 'Orario di inizio della prima istanza giornaliera (ore:minuti)';
$txt['scheduled_task_time_offset'] = 'L\'orario di inizio deve essere regolato rispetto all\'ora attuale del server. Ora attuale del server: %1$s';

$txt['scheduled_view_log'] = 'Visualizza registro';
$txt['scheduled_log_empty'] = 'Non sono presenti elementi nel registro delle attività.';
$txt['scheduled_log_time_run'] = 'Tempo di esecuzione';
$txt['scheduled_log_time_taken'] = 'Tempo impiegato';
$txt['scheduled_log_time_taken_seconds'] = 'secondi';
$txt['scheduled_log_completed'] = 'Operazione completata';
$txt['scheduled_log_empty_log'] = 'Elimina log';
$txt['scheduled_log_empty_log_confirm'] = 'Sei sicuro di voler svuotare completamente il log?';