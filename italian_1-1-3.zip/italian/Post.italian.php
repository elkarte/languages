<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Aggiungi una risposta';
$txt['post_in_board'] = 'Crea discussione';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Inserisci citazione';
$txt['disable_smileys'] = 'Disabilita smiley';
$txt['dont_use_smileys'] = 'Non usare smiley.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Inviato il';
$txt['standard'] = 'Standard';
$txt['thumbs_up'] = 'Pollice su';
$txt['thumbs_down'] = 'Pollice giù';
$txt['exclamation_point'] = 'Punto esclamativo';
$txt['question_mark'] = 'Punto interrogativo';
$txt['icon_poll'] = 'Sondaggio';
$txt['lamp'] = 'Lampadina';
$txt['add_smileys'] = 'Aggiungi smiley';
$txt['topic_notify_no'] = 'Non ci sono discussioni con notifica.';

$txt['rich_edit_wont_work'] = 'Il tuo browser non supporta il formato Rich Text.';
$txt['rich_edit_function_disabled'] = 'Il tuo browser non supporta questa funzione.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Disattiva le notifiche per questa discussione seguendo questo link';

$txt['lock_after_post'] = 'Chiudi il topic dopo l\'inserimento del post';
$txt['notify_replies'] = 'Invia una notifica per ogni risposta.';
$txt['lock_topic'] = 'Chiudi il topic.';
$txt['shortcuts'] = 'scorciatoie: SHIFT+ALT+S per inviare il post o SHIFT+ALT+P per l\'anteprima';
$txt['shortcuts_drafts'] = 'scorciatoie: SHIFT+ALT+S per inviare il post, SHIFT+ALT+P per l\'anteprima e SHIFT+ALT+D per salvare la bozza';
$txt['option'] = 'Opzioni';
$txt['reset_votes'] = 'Azzera il conteggio dei voti';
$txt['reset_votes_check'] = 'Selezionare questa casella se si desidera azzerare il conteggio dei voti.';
$txt['votes'] = 'voti';
$txt['attach'] = 'Allega';
$txt['clean_attach'] = 'Rimuovi allegato';
$txt['attached'] = 'Allegati'; // @deprecated since 1.1
$txt['allowed_types'] = 'Tipi di allegati permessi';
$txt['cant_upload_type'] = 'Non puoi caricare questo tipo di file. Le estensioni accettate sono %1$s';
$txt['uncheck_unwatchd_attach'] = 'Deseleziona gli allegati che si vogliono rimuovere'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Questo file utilizza un nome riservato. Riprova con un nome diverso.';
$txt['topic_locked_no_reply'] = 'Attezione! Questo topic è chiuso<br />Solo gli amministratori e i moderatori possono inserire ulteriori risposte.';
$txt['attachment_requires_approval'] = 'N.B: ogni file allegato non verrà mostrato fino a quando non sarà approvato da un moderatore.';
$txt['error_temp_attachments'] = 'Sono stati trovati allegati caricati ma non postati. Questi allegati verranno ora aggiunti a questo post. Se non vuoi includerli, puoi <a href="#postAttachment">rimoverli qui</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Promemoria: questo post non verrà mostrato fino a quando non sarà approvato da un moderatore.';

$txt['enter_comment'] = 'Inserisci commento';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'post segnalato';
$txt['reported_to_mod_by'] = 'da';
$txt['rtm10'] = 'Invia';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'i seguenti post, "%1$s" di';
$txt['reported_by'] = 'sono stati segnalati da';
$txt['board_moderate'] = 'in una sezione che puoi moderare';
$txt['report_comment'] = 'Nella segnalazione è stato incluso il seguente commento';

$txt['attach_drop_files'] = 'Aggiungi file con il drag & drop o <a class="drop_area_fileselect_text" href="javascript:void(0)">selezionandoli</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Aggiungi file</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'Dimensione totale massima %1$sKB';
$txt['attach_restrict_attachmentSizeLimit'] = 'Dimensione individuale massima: %1$sKB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d per post';
$txt['attach_restrictions'] = 'Restrizioni:';

$txt['post_additionalopt_attach'] = 'Allegati ed altre opzioni';
$txt['post_additionalopt'] = 'Altre opzioni';
$txt['sticky_after'] = 'Imposta in rilievo topic.';
$txt['move_after2'] = 'Sposta il topic.';
$txt['back_to_topic'] = 'Ritorna a questo post.';
$txt['approve_this_post'] = 'Approva questo post';

$txt['retrieving_quote'] = 'Recupero quote...';

$txt['post_visual_verification_label'] = 'Verifica';
$txt['post_visual_verification_desc'] = 'Per favore, inserisci il codice nell\'immagine in alto per inviare questo post.';

$txt['poll_options'] = 'Opzioni del sondaggio';
$txt['poll_run'] = 'Il sondaggio sarà valido per';
$txt['poll_run_limit'] = '(Lascia vuoto per nessun limite.)';
$txt['poll_results_visibility'] = 'Visibilità dei risultati';
$txt['poll_results_anyone'] = 'Mostra a tutti i risultati del sondaggio.';
$txt['poll_results_voted'] = 'Visualizza i risultati del sondaggio solo dopo il voto.';
$txt['poll_results_after'] = 'Visualizza i risultati solamente al termine del sondaggio.';
$txt['poll_max_votes'] = 'Numero massimo di voti per utente';
$txt['poll_do_change_vote'] = 'Permetti agli utenti di cambiare il voto';
$txt['poll_too_many_votes'] = 'Sono state inserite troppe opzioni. In questo sondaggio puoi inserirne un massimo di %1$s';
$txt['poll_add_option'] = 'Aggiungi opzione';
$txt['poll_guest_vote'] = 'Permetti ai visitatori di votare';

$txt['spellcheck_done'] = 'Controllo ortografico completato.';
$txt['spellcheck_change_to'] = 'Cambia in:';
$txt['spellcheck_suggest'] = 'Suggerimenti:';
$txt['spellcheck_change'] = 'Modifica';
$txt['spellcheck_change_all'] = 'Cambia tutto';
$txt['spellcheck_ignore'] = 'Ignora';
$txt['spellcheck_ignore_all'] = 'Ignora tutto';

$txt['more_attachments'] = 'altri allegati';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Spiacente, non è possibile inserire ulteriori allegati.';

$txt['more_smileys'] = 'altri';
$txt['more_smileys_title'] = 'Smiley aggiuntivi';
$txt['more_smileys_pick'] = 'Scegli uno smiley';
$txt['more_smileys_close_window'] = 'Chiudi la finestra';

$txt['error_new_reply'] = 'Mentre scrivevi, è stato aggiunta una nuova risposta. Verifica il tuo messaggio.';
$txt['error_new_replies'] = 'Mentre scrivevi, %1$d nuove risposte sono state aggiunte. Verifica il messaggio.';
$txt['error_new_reply_reading'] = 'Mentre leggevi, è stato aggiunta una nuova risposta. Verifica il tuo messaggio!';
$txt['error_new_replies_reading'] = 'Mentre leggevi, sono state aggiunte %1$d nuove risposte. Verifica il tuo messaggio!';

$txt['announce_this_topic'] = 'Invia agli utenti un annuncio relativo a questo topic:';
$txt['announce_title'] = 'Invia un annuncio';
$txt['announce_desc'] = 'Questo modulo permette di inviare ai membri di un gruppo un annuncio relativo a questo topic.';
$txt['announce_sending'] = 'Invio dell\'annuncio relativo al topic';
$txt['announce_done'] = 'fatto';
$txt['announce_continue'] = 'Continua';
$txt['announce_topic'] = 'Annuncia topic.';
$txt['announce_regular_members'] = 'Utenti Normali';

$txt['digest_subject_daily'] = 'Riepilogo giornaliero';
$txt['digest_subject_weekly'] = 'Riepilogo settimanale';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'I seguenti topic sono stati iniziati';
$txt['digest_new_topics_line'] = '"%1$s" nella sezione %2$s';
$txt['digest_new_replies'] = 'Risposte inviate nei seguenti topic';
$txt['digest_new_replies_one'] = 'Una risposta in "%1$s"';
$txt['digest_new_replies_many'] = '%1$d risposte in "%2$s"';
$txt['digest_mod_actions'] = 'Sono state eseguite le seguenti azioni di moderazione';
$txt['digest_mod_act_sticky'] = '"%1$s" è in rilievo';
$txt['digest_mod_act_lock'] = '"%1$s" è stato chiuso';
$txt['digest_mod_act_unlock'] = '"%1$s" è stato riaperto';
$txt['digest_mod_act_remove'] = '"%1$s" è stato rimosso';
$txt['digest_mod_act_move'] = '"%1$s" è stato spostato';
$txt['digest_mod_act_merge'] = '"%1$s" è stato unito con un altro topic';
$txt['digest_mod_act_split'] = '"%1$s" è stato diviso';

$txt['attach_error_title'] = 'Si è verificato un errore nel caricamento degli allegati.';
$txt['attach_warning'] = 'C\'è stato un problema durante il caricamento di <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Spiacenti, sei fuori dallo spazio allegati. La dimensione totale allegati permessa per post è di %1$s KB. Rimangono %2$s KB.';
$txt['attach_folder_warning'] = 'Impossibile trovare la cartella degli allegati. Notificare l\'amministratore di questo problema.';
$txt['attach_folder_admin_warning'] = 'La cartella per gli allegati (%1$s) non è corretta. Correggerla nelle impostazioni degli allegati del pannello admin.';
$txt['attach_limit_nag'] = 'Hai raggiunto il numero massimo di allegati permessi per post.';
$txt['attach_no_upload'] = 'C\'è stato un problema e i tuoi allegati non sono stati caricati.';
$txt['attach_remaining'] = '%1$d rimanenti';
$txt['attach_available'] = '%1$s KB disponibili';
$txt['attach_kb'] = '(%1$s KB)';
$txt['attach_0_byte_file'] = 'Il file sembra essere vuoto. Contattare l\'amministratore se il problema persiste.';
$txt['attached_files_in_session'] = '<em>I seguenti file sottolineati sono caricati, ma non collegati al post finchè non viene pubblicato.</em>';

$txt['attach_php_error'] = 'A causa di un errore, il tuo allegato non può essere caricato. Contattare l\'amministratore se il problema persiste.';
$txt['php_upload_error_1'] = 'Il file caricato supera la direttiva upload_max_filesize in php.ini. Contatta il tuo host se non sei in grado di correggere il problema.';
$txt['php_upload_error_3'] = 'Il file è stato parzialmente caricato. E\' un errore legato a PHP. Contatta il tuo host se il problema persiste.';
$txt['php_upload_error_4'] = 'Nessun file è stato caricato. E\' un errore legato a PHP. Contatta il tuo host se il problema persiste.';
$txt['php_upload_error_6'] = 'Impossibile salvare. Cartella temporanea mancante. Contatta il tuo host se il problema persiste.';
$txt['php_upload_error_7'] = 'Scrittura su disco fallita. E\' un errore legato a PHP. Contatta il tuo host se il problema persiste.';
$txt['php_upload_error_8'] = 'Una estensione PHP ha fermato l\'upload del file. E\' un errore legato a PHP. Contatta il tuo host se il problema persiste.';
$txt['error_temp_attachments_new'] = 'Ci sono allegati precedentemente caricati ma non inseriti nel post. Questi allegati sono ancora collegati al post. Devi inviare questo post prima che gli allegati siano disponibili. Puoi <a href="#postAttachment">farlo qui</a>';
$txt['error_temp_attachments_found'] = 'Ci sono allegati precedentemente caricati ma non inseriti nel post. È consigliabile rimuoveli o inserirli nel post prima di inviarlo. <br />Clicca <a href="%1$s">per rimuovere</a>gli allegati. O <a href="%2$s">qui per tornare al post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'I seguenti allegati sono stati trovati in un post precedentemente creato ma non ancora pubblicato. E\' consigliato di non caricare ulteriori allegati fino a quando questi allegati non vengono rimossi o quel messaggio non viene pubblicato. .<br />Clicca<a href="%1$s">qui per rimuovere questi allegati</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Gli allegati sono stati rimossi e sei stato riportato alla pagine dove eri precedentemente';
$txt['error_temp_attachments_flushed'] = 'Qualsiasi file precedentemente caricato, ma non postato, è stato ora rimosso.';
$txt['error_topic_already_announced'] = 'Questo topic è già stato annunciato.';

$txt['cant_access_upload_path'] = 'Impossibile accedere al percorso di caricamento degli allegati!';
$txt['file_too_big'] = 'Il file è troppo grande. La dimensione massima consentita è di %1$s KB.';
$txt['attach_timeout'] = 'L\'allegato non può essere salvato. La causa è da ricercare nel tempo di caricamento troppo lungo o nella dimensione del file, superiore a quella ammessa dal server.<br /><br />Consultare l\'amministratore del server per ulteriori informazioni.';
$txt['bad_attachment'] = 'Il tuo allegato non ha superato i controlli di sicurezza e non può essere caricato. Consulta l\'amministratore del forum.';
$txt['ran_out_of_space'] = 'La cartella degli allegati è piena. Notificare l\'amministratore del problema.';
$txt['attachments_no_write'] = 'La cartella di caricamento degli allegati non ha i permessi di scrittura. Non è quindi possibile salvare allegati o avatar.';
$txt['attachments_no_create'] = 'Impossibile creare una nuova cartella di allegati. L\'allegato o l\'avatar non può essere salvato.';
$txt['attachments_limit_per_post'] = 'Non è possibile caricare più di %1$d allegati per post';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Inserisci Allegato %1$d nel messaggio';
$txt['ila_title'] = 'Alla fine del messaggio come miniatura espandibile';
$txt['insert'] = 'Inserisci';
$txt['ila_opt_size'] = 'Dimensione';
$txt['ila_opt_align'] = 'Allineamento';
$txt['ila_opt_size_thumb'] = 'Miniatura';
$txt['ila_option2'] = 'Testo link';
$txt['ila_option3'] = 'Breve testo link';
$txt['ila_opt_size_full'] = 'Dimensione intera';
$txt['ila_opt_size_cust'] = 'Dimensione personalizzata';
$txt['ila_opt_align_none'] = 'Nessuno';
$txt['ila_opt_align_left'] = 'Sinistra';
$txt['ila_opt_align_right'] = 'Destra';
$txt['ila_opt_align_center'] = 'Centrato';
$txt['ila_confirm_removal'] = 'Sicuro di voler rimuovere definitivamente questo allegato?';
/*
$txt['ila_thereare'] = 'Ci sono solo';
$txt['ila_attachment'] = 'allegato(i)';
$txt['ila_none'] = 'come miniatura espandibile';
$txt['ila_img'] = 'come immagine intera';
$txt['ila_url'] = 'come collegamento';
$txt['ila_mini'] = 'come link compatto';
*/