<?php
// Version: 1.1; Validation

$txt['_validate_required'] = 'Il campo %1$s è obbligatorio.';
$txt['_validate_valid_email'] = 'Il campo %1$s deve contenere un indirizzo email valido.';
$txt['_validate_max_length'] = 'Il campo %1$s può contenere un massimo di %2$s caratteri.';
$txt['_validate_min_length'] = 'Il campo %1$s deve contenere almeno  %2$s caratteri.';
$txt['_validate_length'] = 'Il campo %1$s deve contenere esattamente %2$s caratteri.';
$txt['_validate_alpha'] = 'Il campo %1$s può contenere solo lettere.';
$txt['_validate_alpha_numeric'] = 'Il campo %1$s può contenere solo lettere e numeri.';
$txt['_validate_alpha_dash'] = 'Il campo %1$s può contenere solo lettere &amp; trattini.';
$txt['_validate_numeric'] = 'Il campo %1$s deve essere numerico.';
$txt['_validate_integer'] = 'Il campo %1$s può contenere solo un numero intero.';
$txt['_validate_boolean'] = 'Il campo %1$s può contenere solo un valore booleano.';
$txt['_validate_float'] = 'Il campo %1$s può contenere solo un numero a virgola mobile.';
$txt['_validate_valid_url'] = 'Il campo %1$s deve contenere un indirizzo URL valido.';
$txt['_validate_url_exists'] = 'L\'indirizzo URL %1$s non esiste.';
$txt['_validate_valid_ip'] = 'Il campo %1$s deve contenere un indirizzo IPv4 valido.';
$txt['_validate_valid_ipv6'] = 'Il campo %1$s deve contenere un indirizzo IPv6 valido.';
$txt['_validate_contains'] = 'Il campo %1$s deve contenere uno di questi valori: %2$s.';
$txt['_validate_invalid_function'] = 'La funzione di convalida specificata %1$s non esiste.';
$txt['_validate_without'] = 'Il campo %1$s non può contenere il carattere %2$s.';
$txt['_validate_notequal'] = 'Il campo %1$s non contiene un valore valido.';
$txt['_validate_isarray'] = 'Il campo %1$s non contiene una matrice valida.';
$txt['_validate_php_syntax'] = 'Errore di sintassi PHP: %2$s.';
$txt['_validate_limits'] = 'Il campo %1$s contiene un valore oltre i limiti consentiti %2$s.';
$txt['_validate_generic'] = 'Il campo %1$s contiene un valore non valido.';
$txt['validation_failure'] = 'Sono stati riscontrati i seguenti errori nella tua registrazione. Correggili per continuare:';