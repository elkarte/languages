<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... non ne ho idea, spiacente</em>';
$txt['who_admin'] = 'Sta visualizzando il portale di amministrazione';
$txt['who_moderate'] = 'Sta visualizzando il portale di moderazione';
$txt['who_generic'] = 'Sta visualizzando %1$s';
$txt['who_unknown'] = '<em>Azione sconosciuta</em>';
$txt['who_user'] = 'Utente';
$txt['who_time'] = 'Periodo';
$txt['who_action'] = 'Azione';
$txt['who_show1'] = 'Mostra';
$txt['who_show_members_only'] = 'Solo utenti';
$txt['who_show_guests_only'] = 'Solo visitatori';
$txt['who_show_spiders_only'] = 'Solo crawler';
$txt['who_show_all'] = 'Tutti';
$txt['who_no_online_spiders'] = 'Non sono presenti crawler in linea.';
$txt['who_no_online_guests'] = 'Non sono presenti visitatori in linea.';
$txt['who_no_online_members'] = 'Non sono presenti utenti in linea.';

$txt['whospider_login'] = 'Sta effettuando il login.';
$txt['whospider_register'] = 'Sta visualizzando la pagina di registrazione.';
$txt['whospider_reminder'] = 'Sta visualizzando la pagina di promemoria per la password.';

$txt['whoall_activate'] = 'Sta attivando il proprio account.';
$txt['whoall_buddy'] = 'Sta modificando la lista amici.';
$txt['whoall_coppa'] = 'Sta compilando il modulo per il consenso del genitore/tutore.';
$txt['whoall_credits'] = 'Sta visualizzando la pagina dei crediti.';
$txt['whoall_emailuser'] = 'Sta inviando una e-mail ad un altro utente.';
$txt['whoall_groups'] = 'Sta visualizzando la pagina dei gruppi utenti.';
$txt['whoall_help'] = 'Sta visualizzando <a href="{help_url}">la pagina di aiuto</a>.';
$txt['whoall_quickhelp'] = 'Sta visualizzando una finestra pop-up di aiuto.';
$txt['whoall_pm'] = 'Sta visualizzando i propri messaggi personali.';
$txt['whoall_auth'] = 'Login nel forum in corso.';
$txt['whoall_login'] = 'Sta effettuando il login.';
$txt['whoall_login2'] = 'Sta effettuando il login.';
$txt['whoall_logout'] = 'Sta uscendo dal forum.';
$txt['whoall_markasread'] = 'Sta marcando i topic come letti o non letti.';
$txt['whoall_mentions'] = 'Sta visualizzando l\'elenco delle proprie notifiche';
$txt['whoall_modifykarma_applaud'] = 'Sta applaudendo un utente.';
$txt['whoall_modifykarma_smite'] = 'Sta denigrando un utente.';
$txt['whoall_news'] = 'Sta visualizzando le notizie.';
$txt['whoall_notify'] = 'Sta modificando le impostazioni per le notifiche.';
$txt['whoall_notifyboard'] = 'Sta modificando le impostazioni per le notifiche.';
$txt['whoall_openidreturn'] = 'Sta effettuando l\'accesso tramite OpenID.';
$txt['whoall_quickmod'] = 'Sta moderando una sezione.';
$txt['whoall_recent'] = 'Sta visualizzando <a href="{recent_url}">l\'elenco dei  topic recenti</a>.';
$txt['whoall_register'] = 'Sta registrando un account sul forum.';
$txt['whoall_reminder'] = 'Sta richiedendo un promemoria per la password.';
$txt['whoall_reporttm'] = 'Sta segnalando un topic ad un moderatore.';
$txt['whoall_spellcheck'] = 'Sta utilizzando il controllo ortografico.';
$txt['whoall_unread'] = 'Sta visualizzando i topic nuovi rispetto all\'ultima visita.';
$txt['whoall_unreadreplies'] = 'Sta visualizzando le nuove risposte dall\'ultima visita.';
$txt['whoall_who'] = 'Sta visualizzando <a href="{who_url}">Chi è online</a>.';

$txt['whoall_collapse_collapse'] = 'Sta compattando una categoria.';
$txt['whoall_collapse_expand'] = 'Sta espandendo una categoria.';
$txt['whoall_pm_removeall'] = 'Sta cancellando i propri messaggi personali.';
$txt['whoall_pm_send'] = 'Sta inviando un messaggio personale.';
$txt['whoall_pm_send2'] = 'Sta inviando un messaggio personale.';

$txt['whotopic_announce'] = 'Annuncia il topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Sta approvando un allegato.';
$txt['whotopic_dlattach'] = 'Sta visualizzando un allegato.';
$txt['whotopic_deletemsg'] = 'Sta eliminando un messaggio.';
$txt['whotopic_editpoll'] = 'Sta modificando il sondaggio in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Sta modificando il sondaggio in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Sta modificando un post in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Sta inserendo un "Mi piace" nel topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Sta chiudendo il topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Sta chiudendo il sondaggio in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Sta unendo il topic &quot;<a href="%1$s">%2$s</a>&quot; con un altro topic.';
$txt['whotopic_movetopic'] = 'Sta spostando il topic &quot;<a href="%1$s">%2$s</a>&quot; in un\'altra sezione.';
$txt['whotopic_movetopic2'] = 'Sta spostando il topic &quot;<a href="%1$s">%2$s</a>&quot; in un\'altra sezione.';
$txt['whotopic_post'] = 'Sta scrivendo in <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Sta scrivendo in <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Sta stampando il topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Sta moderando il topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Sta rimuovendo il sondaggio in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Sta rimuovendo il topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Sta inviando il topic &quot;<a href="%1$s">%2$s</a>&quot; ad un amico.';
$txt['whotopic_splittopics'] = 'Sta dividendo il topic &quot;<a href="%1$s">%2$s</a>&quot; in due topic distinti.';
$txt['whotopic_sticky'] = 'Sta impostando in evidenza il topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Ha finito di guardare un topic.';
$txt['whotopic_vote'] = 'Sta votando in <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Ha iniziato a guardare un topic.';

$txt['whopost_quotefast'] = 'Sta citando un post da &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Sta modificando le condizioni di registrazione.';
$txt['whoadmin_featuresettings'] = 'Sta modificando le funzioni e le opzioni del forum.';
$txt['whoadmin_modlog'] = 'Sta visualizzando il registro di moderazione.';
$txt['whoadmin_serversettings'] = 'Sta modificando le impostazioni del forum.';
$txt['whoadmin_packageget'] = 'Sta scaricando dei pacchetti.';
$txt['whoadmin_packages'] = 'Sta visualizzando la gestione dei pacchetti.';
$txt['whoadmin_permissions'] = 'Sta modificando i permessi del forum.';
$txt['whoadmin_pgdownload'] = 'Sta scaricando un pacchetto.';
$txt['whoadmin_theme'] = 'Sta modificando le impostazioni del tema.';
$txt['whoadmin_trackip'] = 'Sta tracciando un indirizzo IP.';

$txt['whoallow_manageboards'] = 'Sta modificando le impostazioni del forum e delle categorie.';
$txt['whoallow_admin'] = 'Sta visualizzando il <a href="{admin_url}">pannello di amministrazione</a>.';
$txt['whoallow_ban'] = 'Sta modificando la lista degli utenti esclusi.';
$txt['whoallow_boardrecount'] = 'Sta ricalcolando le statistiche del forum.';
$txt['whoallow_calendar'] = 'Sta visualizzando <a href="{calendar_url}">l\'agenda</a>.';
$txt['whoallow_editnews'] = 'Sta modificando le notizie.';
$txt['whoallow_mailing'] = 'Sta inviando una e-mail dal forum.';
$txt['whoallow_maintain'] = 'Sta eseguendo la manutenzione ordinaria del forum.';
$txt['whoallow_manageattachments'] = 'Sta gestendo gli allegati.';
$txt['whoallow_moderate'] = 'Sta visualizzando <a href="{moderate_url}">Centro Moderazione</a>.';
$txt['whoallow_memberlist'] = 'Sta visualizzando <a href="{memberlist_url}">l\'elenco degli iscritti</a>.';
$txt['whoallow_optimizetables'] = 'Sta ottimizzando le tabelle del database.';
$txt['whoallow_repairboards'] = 'Sta riparando le tabelle del database.';
$txt['whoallow_search'] = '<a href="{search_url}">Sta cercando</a> nel forum.';
$txt['whoallow_search_results'] = 'Sta visualizzando i risultati della ricerca.';
$txt['whoallow_setcensor'] = 'Sta modificando le parole censurate.';
$txt['whoallow_setreserve'] = 'Sta modificando i nomi utente riservati.';
$txt['whoallow_stats'] = 'Sta visualizzando <a href="{stats_url}">le statistiche del forum</a>.';
$txt['whoallow_viewErrorLog'] = 'Sta visualizzando il registro degli errori.';
$txt['whoallow_viewmembers'] = 'Sta visualizzando l\'elenco degli iscritti.';

$txt['who_topic'] = 'Sta visualizzando il topic <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Sta visualizzando la sezione <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Sta visualizzando l\'indice della sezione <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Sta visualizzando il profilo di <a href="%1$s">%2$s</a>.';
$txt['who_profile'] = 'Sta modificando il profilo di <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Sta inserendo un nuovo topic in <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Sta inserendo un nuovo sondaggio in <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Sta inserendo un nuovo topic da email in <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Sta scrivendo un post via email in <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Sta inviando un messaggio personale tramite e-mail.';

// Credits text
$txt['credits'] = 'Ringraziamenti';
$txt['credits_intro'] = 'ElkArte è 100% libero e open-source. Incoraggiamo e supportiamo una comunità attiva ed aperta, che accetta contributi dal pubblico. Vogliamo ringraziare chiunque supporti il progetto fornendo codice, riscontri, segnalazioni di bug ed opinioni, perché niente di tutto questo sarebbe stato possibile senza te. Una menzione speciale va ad <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, il progetto da cui ElkArte è nato.';
$txt['credits_contributors'] = 'Collaboratori';
$txt['credits_and'] = 'e';
$txt['credits_copyright'] = 'Copyright';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Add-ons';
$txt['credits_software_graphics'] = 'Software/Grafica';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Grafica';
$txt['credits_fonts'] = 'Fonts';
$txt['credits_groups_contrib'] = 'Collaboratori';
$txt['credits_contrib_list'] = 'Per una lista completa di chi ha contribuito alla creazione di ElkArte, consultare la <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">lista contributori</a> ufficiale di GitHub.';
$txt['credits_license'] = 'Licenza';
$txt['credits_copyright'] = 'Copyright';
$txt['credits_version'] = 'Versione';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Traduttori';
$txt['credits_translators_message'] = 'Ringraziamo per il tuo contributo che sta dando la possibilità a persone di tutto il mondo di utilizzare ElkArte.  Per un elenco completo potete visualizzare la lista ufficiale su <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">Transifex.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';