<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Data';
$txt['badbehaviorlog_protocol'] = 'Protocollo';
$txt['badbehaviorlog_method'] = 'Metodo';
$txt['badbehaviorlog_request'] = 'Richiesta';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'ID Membro';
$txt['badbehaviorlog_username'] = 'Nome Utente';
$txt['badbehaviorlog_headers'] = 'Intestazione';
$txt['badbehaviorlog_agent'] = 'Browser';
$txt['badbehaviorlog_entity'] = 'Post';
$txt['badbehaviorlog_key'] = 'Chiave';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Voci totali';
$txt['badbehaviorlog_error_valid_code'] = 'Codice Motivo';
$txt['badbehaviorlog_error_valid_response'] = 'Stato HTTP';
$txt['badbehaviorlog_error_valid_explaination'] = 'Motivo HTTP';
$txt['badbehaviorlog_error_valid_log'] = 'Dettagli';
$txt['badbehaviorlog_log'] = 'Registro BadBehavior';
$txt['badbehaviorlog_desc'] = 'La seguente è la lista di tutte le voci di BadBehavior che sono state registrate';
$txt['badbehaviorlog_details'] = 'Dettagli Aggiuntivi';
$txt['badbehaviorlog_no_entries_found'] = 'Attualmente non c\'è nessun elenco di voci di BadBehavior';

$txt['badbehaviorlog_remove_selection'] = 'Elimina selezionati';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Sei sicuro di voler eliminare i log selezionati?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Rimuovi tutti i risultati filtrati';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Sei sicuro di voler eliminare le voci filtrate?';
$txt['badbehaviorlog_sure_remove'] = 'Sei sicuro di voler cancellare interamente il registro delle voci di BadBehavior?';

$txt['badbehaviorlog_remove'] = 'Elimina selezionati';
$txt['badbehaviorlog_removeall'] = 'Elimina log';
$txt['badbehaviorlog_clear_filter'] = 'Rimuovi filtro';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Applica filtro del tipo';
$txt['badbehaviorlog_apply_filter'] = 'Applica filtro';
$txt['badbehaviorlog_applying_filter'] = 'Applicazione filtro';
$txt['badbehaviorlog_filter_only_member'] = 'Mostra solamente le voci di BadBehavior registrate di questo utente.';
$txt['badbehaviorlog_filter_only_ip'] = 'Mostra solamente le voci di BadBehavior registrate di questo indirizzo IP.';
$txt['badbehaviorlog_filter_only_session'] = 'Mostra solamente le voci di BadBehavior registrate di questa sessione.';
$txt['badbehaviorlog_filter_only_headers'] = 'Mostra solamente le voci di BadBehavior registrate di questo URL.';
$txt['badbehaviorlog_filter_only_agent'] = 'Mostra solamente le voci con lo stesso user agent.';

$txt['badbehaviorlog_session'] = 'Sessione';
$txt['badbehaviorlog_error_url'] = 'URL della pagina che è stato registrato';

$txt['badbehaviorlog_reverse_direction'] = 'Inverti l\'ordine cronologico della lista';
$txt['badbehaviorlog_filter_only_type'] = 'Mostra solamente i registri con questo codice';