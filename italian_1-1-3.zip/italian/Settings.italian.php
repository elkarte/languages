<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Tema di default di ElkArte.<br /><br />Autore: contributori di ElkArte';