<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Visualizza bozze';
$txt['drafts_show_desc'] = 'Questa pagina mostra tutte le bozze attualmente salvate. Qui puoi modificarle prima di postarle, o eliminarle.';

// misc
$txt['drafts'] = 'Bozze';
$txt['draft_save'] = 'Salva bozza';
$txt['draft_save_note'] = 'Questo salverà il testo del tuo post, ma non salverà allegati, sondaggi o informazioni degli eventi.';
$txt['draft_none'] = 'Non hai bozze.';
$txt['draft_edit'] = 'Modifica bozza';
$txt['draft_load'] = 'Carica bozza';
$txt['draft_hide'] = 'Nascondi bozze';
$txt['draft_delete'] = 'Elimina bozza';
$txt['draft_days_ago'] = '%s giorni fa';
$txt['draft_retain'] = 'verrà mantenuta per altri %s giorni';
$txt['draft_remove'] = 'Rimuovi questa bozza';
$txt['draft_remove_selected'] = 'Rimuovi tutte le bozze selezionate?';
$txt['draft_saved'] = 'I contenuti sono stati salvati come bozze e sono accessibili dall\'<a href="%1$s">area bozze</a> del tuo profilo';
$txt['draft_pm_saved'] = 'I contenuti sono stati salvati come bozze e sono accessibili dall\'<a href="%1$s">area bozze</a> del tuo centro messaggi.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Abilita salvataggio automatico bozze';
$txt['drafts_autosave_enabled_subnote'] = 'Qui è possibile salvare automaticamente le bozze in background con una determinata frequenza. L\'utente deve avere inoltre le autorizzazioni appropriate.';
$txt['drafts_keep_days'] = 'Massimo n° di giorni per conservare una bozza';
$txt['drafts_keep_days_subnote'] = 'Inserisci 0 per mantenere per sempre le bozze salvate';
$txt['drafts_autosave_frequency'] = 'Quanto spesso possono essere salvate automaticamente le bozze?';
$txt['drafts_autosave_frequency_subnote'] = 'Il minimo valore possibile è di 30 secondi';
$txt['drafts_pm_enabled'] = 'Abilita il salvataggio delle bozze degli MP';
$txt['drafts_post_enabled'] = 'Abilita salvataggio delle bozze dei post';
$txt['drafts_none'] = 'Nessun oggetto';
$txt['drafts_saved'] = 'La bozza è stata salvata';