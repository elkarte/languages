<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Imposta i parametri della ricerca';
$txt['choose_board'] = 'Sezioni comprese nella ricerca';
$txt['all_words'] = 'Confronta tutte le parole';
$txt['any_words'] = 'Confronta qualsiasi parola';
$txt['by_user'] = 'Dall\'utente';

$txt['search_post_age'] = 'Data';
$txt['search_between'] = 'tra';
$txt['search_and'] = 'e';
$txt['search_options'] = 'Opzioni';
$txt['search_show_complete_messages'] = 'Mostra i risultati come messaggi';
$txt['search_subject_only'] = 'Cerca solo nell\'oggetto delle discussioni';
$txt['search_relevance'] = 'Rilevanza';
$txt['search_date_posted'] = 'Data di inserimento';
$txt['search_order'] = 'Ordina i risultati per';
$txt['search_orderby_relevant_first'] = 'Prima i risultati più rilevanti';
$txt['search_orderby_large_first'] = 'Prima le discussioni più lunghe';
$txt['search_orderby_small_first'] = 'Prima le discussioni più brevi';
$txt['search_orderby_recent_first'] = 'Prima le discussioni più recenti';
$txt['search_orderby_old_first'] = 'Prima le discussioni più vecchie';
$txt['search_visual_verification_label'] = 'Verifica';
$txt['search_visual_verification_desc'] = 'Inserisci il codice in alto per iniziare la ricerca.';

$txt['search_specific_topic'] = 'Cerca solo nei messaggi della discussione';

$txt['groups_search_posts'] = 'Gruppi abilitati alla funzione di ricerca';
$txt['search_dropdown'] = 'Abilita la ricerca veloce a scomparsa';
$txt['search_results_per_page'] = 'Numero di risultati della ricerca per pagina';
$txt['search_weight_frequency'] = 'Peso specifico della ricerca per numero di messaggi corrispondenti in una discussione';
$txt['search_weight_age'] = 'Peso specifico della ricerca per età dell\'ultimo messaggio corrispondente';
$txt['search_weight_length'] = 'Peso specifico della ricerca per lunghezza della discussione';
$txt['search_weight_subject'] = 'Peso specifico della ricerca per corrispondenza nell\'oggetto';
$txt['search_weight_first_message'] = 'Peso specifico della ricerca per corrispondenza nel primo messaggio';
$txt['search_weight_sticky'] = 'Peso relativo per i topic importanti';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Qui puoi cambiare le impostazioni di base per la funzione ricerca.';
$txt['search_settings_title'] = 'Impostazioni ricerca';

$txt['search_weights_desc'] = 'Opzioni per modificare i singoli componenti dell\'indice di rilevanza.';
$txt['search_weights_sphinx'] = 'Per aggiornare i fattori di peso in Sphinx devi generare ed installare un nuovo file sphinx.conf';
$txt['search_weights_title'] = 'Pesi della ricerca';
$txt['search_weights_total'] = 'Totale';
$txt['search_weights_save'] = 'Salva';

$txt['search_method_desc'] = 'Opzioni per impostare il modo in cui viene effettuata una ricerca.';
$txt['search_method_title'] = 'Metodo di ricerca';
$txt['search_method_save'] = 'Salva';
$txt['search_method_messages_table_space'] = 'Spazio utilizzato dai messaggi del forum nel database';
$txt['search_method_messages_index_space'] = 'Spazio utilizzato per indicizzare i messaggi nel database';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Indice di tutto il testo';
$txt['search_method_no_index_exists'] = 'non esiste attualmente';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'non può essere creato perché il messaggio più lungo supera i 65.535 caratteri o la tabella non è di tipo MyISAM';
$txt['search_method_index_already_exists'] = 'l\'indice è già esistente';
$txt['search_method_fulltext_remove'] = 'elimina indice di tutto il testo';
$txt['search_method_index_partial'] = 'creato parzialmente';
$txt['search_index_custom_resume'] = 'riprendi';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'Per poter abilitare la ricerca <em>fulltext</em> devi prima creare un indice <em>fulltext</em>.';
$txt['search_index_custom_warning'] = 'Per poter utilizzare una ricerca secondo un indice personalizzato, è necessario per prima cosa creare l\'indice stesso!';

$txt['search_index'] = 'Ricerca nell\'indice';
$txt['search_index_none'] = 'Nessun indice';
$txt['search_index_custom'] = 'Indice personalizzato';
$txt['search_index_label'] = 'Indice';
$txt['search_index_size'] = 'Dimensione';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Obbliga ad utilizzare un indice di ricerca';
$txt['search_match_words'] = 'Solo corrispondenza di parole intere';
$txt['search_max_results'] = 'Numero massimo di risultati da visualizzare';
$txt['search_max_results_disable'] = '(0 = nessun limite)';
$txt['search_floodcontrol_time'] = 'Tempo richiesto tra una ricerca e l\'altra da parte dello stesso utente';
$txt['search_floodcontrol_time_desc'] = '(0 per nessun limite, in secondi)';

$txt['additional_search_engines'] = 'Motori di ricerca aggiuntivi';
$txt['setup_search_engine_add_more'] = 'Aggiungi un altro motore di ricerca';

$txt['search_create_index'] = 'Crea un indice';
$txt['search_create_index_why'] = 'Perché	 creare un indice di ricerca?';
$txt['search_create_index_start'] = 'Crea';
$txt['search_predefined'] = 'Profilo definito precedentemente';
$txt['search_predefined_small'] = 'Indice di piccole dimensioni';
$txt['search_predefined_moderate'] = 'Indice di medie dimensioni';
$txt['search_predefined_large'] = 'Indice di grandi dimensioni';
$txt['search_create_index_continue'] = 'Continua';
$txt['search_create_index_not_ready'] = 'ElkArte sta creando l\'indice di ricerca per i tuoi messaggi. Per evitare sovraccaricamenti del server, il lavoro è temporaneamente sospeso. Roprenderà automaticamente tra qualche secondo. In caso non riprenda, clicca Continua qui sotto.';
$txt['search_create_index_progress'] = 'Avanzamento';
$txt['search_create_index_done'] = 'Indice di ricerca personalizzato creato con successo.';
$txt['search_create_index_done_link'] = 'Continua';
$txt['search_double_index'] = 'Al momento esistono due indici della tabella dei messaggi. Per ottimizzare le prestazioni è preferibile cancellarne uno.';

$txt['search_error_indexed_chars'] = 'Numero di caratteri indicizzati non valido. Affinché un indice sia utilizzabile, sono necessari almeno tre caratteri.';
$txt['search_error_max_percentage'] = 'Percentuale di parole da evitare non valida. Utilizzare un valore pari almeno al 5%.';
$txt['error_string_too_long'] = 'La stringa di ricerca deve inferiore ai %1$d caratteri.';

$txt['search_warning_ignored_word'] = 'Questo termine è stato ignorato nella ricerca';
$txt['search_warning_ignored_words'] = 'Questi termini sono stati ignorati nella ricerca';

$txt['search_adjust_query'] = 'Correggi i parametri di ricerca';
$txt['search_adjust_submit'] = 'Rivedi la ricerca';
$txt['search_did_you_mean'] = 'Forse volevi cercare';

$txt['search_example'] = '<em>es.:</em> Orwell "La Fattoria degli Animali" -film';

$txt['search_engines_description'] = 'Da questa area puoi decidere con quale dettaglio tracciare il modo in cui i motori di ricerca indicizzano il tuo forum, come controllare i registri relativi alla loro attività.';
$txt['spider_mode'] = 'Livello di monitoraggio dei motori di ricerca';
$txt['spider_mode_note'] = 'Attenzione: maggiore il livello di monitoraggio, maggiori saranno le risorse necessarie al server.';
$txt['spider_mode_off'] = 'Disabilitato';
$txt['spider_mode_standard'] = 'Standard';
$txt['spider_mode_high'] = 'Modera';
$txt['spider_mode_vhigh'] = 'Aggressivo';
$txt['spider_settings_desc'] = 'Puoi cambiare le impostazioni degli spider in questa pagina. Nota, se vuoi <a href="%1$s">abilitare l\'eliminazione automatica dei registri di riscontro, puoi farlo qui</a>';

$txt['spider_group'] = 'Applica permessi restrittivi dal gruppo';
$txt['spider_group_note'] = 'Per abilitare l\'arresto dell\'indicizzazione di alcune pagine.';
$txt['spider_group_none'] = 'Disabilitato';

$txt['show_spider_online'] = 'Mostra i crawler nella lista di chi è online';
$txt['show_spider_online_no'] = 'Non a tutti';
$txt['show_spider_online_summary'] = 'Mostra la quantità di crawler';
$txt['show_spider_online_detail'] = 'Mostra i dettagli del crawler';
$txt['show_spider_online_detail_admin'] = 'Mostra i dettagli del crawler - Solo amministratori';

$txt['spider_name'] = 'Nome crawler';
$txt['spider_last_seen'] = 'Visto l\'ultima volta';
$txt['spider_last_never'] = 'Mai';
$txt['spider_agent'] = 'User Agent';
$txt['spider_ip_info'] = 'Indirizzo IP';
$txt['spiders_add'] = 'Aggiungi un nuovo crawler';
$txt['spiders_edit'] = 'Modifica crawler';
$txt['spiders_remove_selected'] = 'Elimina selezionati';
$txt['spider_remove_selected_confirm'] = 'Sei sicuro di voler riuovere questi spiders?\\n\\nTutte le statistiche associate verranno eliminate!';
$txt['spiders_no_entries'] = 'Al momento non ci sono spider di motori di ricerca configurati.';

$txt['add_spider_desc'] = 'In questa pagina potrai modificare i parametri secondo cui un crawler viene catalogato. Se lo user agent/indirizzo IP di un visitatore corrispondono a quelli inseriti in basso, quest\'ultimo verrà identificato come crawler di un motore di ricerca e tracciato come tale nelle preferenze del forum.';
$txt['spider_name_desc'] = 'Nome secondo il quale verrà identificato il crawler';
$txt['spider_agent_desc'] = 'User agent associato a questo crawler';
$txt['spider_ip_info_desc'] = 'Lista di indirizzi IP associati a questo crawler.';

$txt['spider_time'] = 'Periodo';
$txt['spider_viewing'] = 'Visualizzando';
$txt['spider_logs_empty'] = 'Al momento non sono presenti elementi nel registro delle attività degli spider.';
$txt['spider_logs_info'] = 'N.B: la registrazione di ogni azione del crawler avviene solo se il livello di tracciamento è impostato su &quot;alto&quot; o &quot;molto alto&quot;. I dettagli di ogni azione del crawler vengono registrati se il tracciamento è impostato su &quot;molto alto&quot;.';
$txt['spider_disabled'] = 'Disabilitato';
$txt['spider_log_empty_log'] = 'Elimina log';
$txt['spider_log_empty_log_confirm'] = 'Sicuro di voler eliminare completamente l\'elenco?';

$txt['spider_logs_delete'] = 'Cancella dati';
$txt['spider_logs_delete_older'] = 'Elimina tutti gli elementi più vecchi di %1$s giorni.';
$txt['spider_logs_delete_submit'] = 'Cancella';

$txt['spider_stats_delete_older'] = 'Elimina tutte le statistiche spiders dagli spiders non viste in %1$s giorni.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Desideri realmente cancellare tutte le voci appartenenti al log?';

$txt['spider_stats_select_month'] = 'Salta al mese';
$txt['spider_stats_page_hits'] = 'Visualizzazioni della pagina';
$txt['spider_stats_no_entries'] = 'Al momento non sono disponibili statistiche per gli spider dei motori di ricerca.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'Non hai ancora selezionato l\'uso di Sphinx o SphinxQL come metodo di ricerca';
$txt['sphinx_test_passed'] = 'Tutti i test sono positivi, il sistema può connettersi al motore di ricerca sphinx usando le API Sphinx';
$txt['sphinxql_test_passed'] = 'Tutti i test sono stati positivi, il sistema è in grado di connettersi al motore di ricerca sphinx usando i comandi SphinxQL';
$txt['sphinx_test_connect_failed'] = 'Impossibile connettersi al motore Sphinx. Assicurati che sia attivo e configurato correttamente. La ricerca Sphinx non funzionerà finchè non risolvi il problema.';
$txt['sphinxql_test_connect_failed'] = 'Impossibile accedere a SphinxQL. Assicurati che il file sphinx.conf abbia direttive di ascolto separate per la porta SphinxQL. SphinxQL non funzionerà finchè non risolvi il problema.';
$txt['sphinx_test_api_missing'] = 'Il file sphinxapi.php manca nella cartella &quot;sources&quot;.  Ti serve una copia di questo file da Sphinx distribution. Sphinx non funzionerà finchè non risolvi il problema.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Percorso dati dell\'indice:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Percorso file di log:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';