<?php
// Version: 1.1; Admin

$txt['admin_boards'] = '版块';
$txt['admin_back_to'] = '返回管理中心';
$txt['admin_users'] = '会员';
$txt['admin_newsletters'] = '通讯';
$txt['include_these'] = '包括成员';
$txt['exclude_these'] = '拒绝成员';
$txt['admin_newsletters_select_groups'] = 'Groups to include';
$txt['admin_newsletters_exclude_groups'] = 'Groups to exclude';
$txt['admin_edit_news'] = '消息';
$txt['admin_groups'] = '会员组';
$txt['admin_members'] = '会员管理';
$txt['admin_members_list'] = '以下成员列表为论坛已注册会员。';
$txt['admin_next'] = '下一个';
$txt['admin_censored_words'] = 'Censored Words';
$txt['admin_censored_where'] = 'Enter the word to be censored into the left box and the word to change it to, into the right box. Then select if you want to check the whole word and the case. When you\'re finished with each word, click Save. Multiple entries can be made prior to saving by clicking the \'Add another word\' button.';
$txt['admin_censored_desc'] = 'Due to the public nature of forums there may be some words that you wish to prohibit being posted by users of your forum. You can enter any words below that you wish to be censored whenever used by a member.<br />Clear a box to remove that word from the censor.';
$txt['admin_reserved_names'] = '保留的名称';
$txt['admin_template_edit'] = '编辑你的论坛模板';
$txt['admin_modifications'] = '附加设置';
$txt['admin_security_moderation'] = 'Security and Moderation';
$txt['admin_server_settings'] = '服务器设置';
$txt['admin_reserved_set'] = '设置保留名称';
$txt['admin_reserved_line'] = 'One reserved word per line.';
$txt['admin_basic_settings'] = '此页面允许你更改论坛的基本设置，请谨慎使用这些设置，以防论坛出现问题。';
$txt['admin_maintain'] = '启用维护模式';
$txt['admin_title'] = '论坛名称';
$txt['admin_url'] = '论坛网址';
$txt['cookie_name'] = 'Cookie name';
$txt['admin_webmaster_email'] = '站长邮箱地址';
$txt['boarddir'] = 'ElkArte 目录';
$txt['sourcesdir'] = 'Sources 目录';
$txt['cachedir'] = '缓存目录';
$txt['admin_news'] = '启用新闻';
$txt['admin_guest_post'] = '启用游客发布';
$txt['admin_manage_members'] = '会员';
$txt['admin_main'] = '主页';
$txt['admin_config'] = '配置';
$txt['admin_version_check'] = '检查版本';
$txt['admin_elkfile'] = 'ElkArte File';
$txt['admin_elkpackage'] = 'ElkArte Package';
$txt['admin_logoff'] = 'End Admin Session';
$txt['admin_maintenance'] = '维护';
$txt['admin_image_text'] = '显示按钮图像';
$txt['admin_credits'] = '勋绩';
$txt['admin_agreement'] = '注册时显示注册协议';
$txt['admin_checkbox_agreement'] = 'Show a checkbox for the agreement in registration form instead of a full page';
$txt['admin_checkbox_accept_agreement'] = '强制所有用户在下次访问论坛时接受此新协议';
$txt['admin_agreement_default'] = '默认';
$txt['admin_agreement_select_language'] = '编辑语言';
$txt['admin_agreement_select_language_change'] = '更改';

$txt['admin_privacypol'] = '显示并要求在注册时接受隐私政策';
$txt['admin_checkbox_accept_privacypol'] = '强制所有用户在下次访问论坛时接受新版本的隐私政策';

$txt['admin_delete_members'] = '删除选定的会员';
$txt['admin_change_primary_membergroup'] = '更改主要成员组';
$txt['admin_change_secondary_membergroup'] = '更改/添加成员组';
$txt['confirm_remove_membergroup'] = '选择此项将删除所有成员组！您确定吗？';
$txt['confirm_change_primary_membergroup'] = '您确定要更改所选成员的主要组吗？';
$txt['confirm_change_secondary_membergroup'] = '您确定要更改所选成员的其附加组吗？';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = '删除所有组';

$txt['admin_repair'] = '修复所有版块和主题';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Please place one news item per box. BBC tags, such as <span>[b]</span>, <span>[i]</span> and <span>[u]</span> are allowed in your news, as well as smileys. Clear a news item\'s text box to remove it.';
$txt['administrators'] = '论坛管理员';
$txt['admin_reserved_desc'] = '用户注册时不可注册已保留的名称，在下方选择你要的选项。';
$txt['admin_activation_email'] = '新成员注册时发送激活邮件';
$txt['admin_match_whole'] = '搜索名字时，不选择搜索属性，结果只匹配全名。';
$txt['admin_match_case'] = '如果不设定选项，搜索将不区分大小写。';
$txt['admin_check_user'] = '检查用户名。';
$txt['admin_check_display'] = '检查显示名称。';
$txt['admin_newsletter_send'] = '在此页你可以给任何人发送邮件，你可以在下面选择会员组邮箱，也可以添加或删除任何邮箱，如果是群发请确保邮箱如下分隔： \'address1; address2\'.';
$txt['admin_fader_delay'] = 'Fading delay between items for the news fader';
$txt['zero_for_no_limit'] = '( 0为不限制 )';
$txt['zero_to_disable'] = '( 0为禁用 )';

$txt['admin_backup_fail'] = 'Failed to make backup of Settings.php - make sure Settings_bak.php exists and is writable.';
$txt['modSettings_info'] = 'Settings for General features, Karma, Signatures, Likes and much more that control how this forum operates.';
$txt['database_server'] = '数据库服务器';
$txt['database_user'] = '数据库用户';
$txt['database_password'] = '数据库密码';
$txt['database_name'] = '数据库名称';
$txt['registration_agreement'] = '注册协议';
$txt['registration_agreement_desc'] = '当用户注册论坛帐号时，必须接受注册协议才可以继续。';
$txt['privacy_policy'] = '隐私政策';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = '数据库表前缀';
$txt['errors_list'] = '论坛的错误列表';
$txt['errors_found'] = '以下是你论坛的的错误';
$txt['errors_fix'] = '你想尝试修复这些错误？';
$txt['errors_do_recount'] = 'All errors have been fixed and a salvage area has been created. Please click the button below to recount some key statistics.';
$txt['errors_recount_now'] = 'Recount Statistics';
$txt['errors_fixing'] = '修复论坛错误';
$txt['errors_fixed'] = 'All errors fixed. Please check on any categories, boards, or topics created to decide what to do with them.';
$txt['attachments_avatars'] = '附件和头像';
$txt['attachments_desc'] = '在这里你可以管理系统上的附件。你可以通过选择大小或日期删除附件。附件的统计数据显示如下。';
$txt['attachment_stats'] = '附件统计';
$txt['attachment_integrity_check'] = '附件完整性检验';
$txt['attachment_integrity_check_desc'] = 'This function will check the integrity and sizes of attachments and filenames listed in the database and, if necessary, fix errors it encounters.';
$txt['attachment_check_now'] = '运行检查';
$txt['attachment_pruning'] = '附件修剪';
$txt['attachment_pruning_message'] = '添加发布信息';
$txt['attachment_pruning_warning'] = '你确定要删除这些附件？\\n 这不能撤消！';

$txt['attachment_total'] = '附件总数';
$txt['attachmentdir_size'] = '所有附件目录的总大小';
$txt['attachmentdir_size_current'] = '当前附件目录的总大小';
$txt['attachmentdir_files_current'] = '在当前目录中的附件总数';
$txt['attachment_space'] = '可用空间';
$txt['attachment_files'] = '剩余文件的总数';

$txt['attachment_options'] = '附件选项';
$txt['attachment_log'] = '附件日志';
$txt['attachment_remove_old'] = '删除 %1$s 天以前的附件';
$txt['attachment_remove_size'] = '删除大于 %1$s KiB的附件';
$txt['attachment_name'] = '附件名称';
$txt['attachment_file_size'] = '文件大小';
$txt['attachmentdir_size_not_set'] = '当前没有设置目录大小';
$txt['attachmentdir_files_not_set'] = 'No directory file limit is currently set';
$txt['attachment_delete_admin'] = '[attachment deleted by admin]';
$txt['live'] = '最新软件更新';
$txt['remove_all'] = '清除日志';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(more detailed)';

$txt['lfyi'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['manage_calendar'] = '日历';
$txt['manage_search'] = '搜索';
$txt['viewmembers_online'] = '在线';

$txt['smileys_manage'] = '表情和邮件图标';
$txt['smileys_manage_info'] = 'Install new smiley sets, add smileys to existing sets or manage your message icons.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = '添加、删除和编辑公告栏。';

$txt['package_info'] = 'Install, download and upload Modification packages; check File Permissions and FTP settings.';
$txt['theme_admin'] = '主题管理';
$txt['theme_admin_info'] = 'Install new themes, select themes that are available for your users and set or reset theme options.';
$txt['registration_center'] = '注册';
$txt['member_center_info'] = '查看会员列表，搜索会员，或管理帐户的审核和激活。';
$txt['viewmembers_online'] = '在线';

$txt['display_name'] = '显示名称';
$txt['email_address'] = '邮箱地址';
$txt['ip_address'] = 'IP地址';
$txt['member_id'] = 'ID';

$txt['unknown'] = '未知';
$txt['security_wrong'] = 'Administration login attempt!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Send in HTML format.  (with this you can put normal HTML in the email.)';
$txt['email_parsed_html'] = 'Add &lt;br /&gt;s and &amp;nbsp;s to this message.';
$txt['email_variables'] = 'In this message you can use a few &quot;variables&quot;.<a href="{help_emailmembers}" class="help"> Click here for more information</a>.';
$txt['email_force'] = 'Send this to members even if they have chosen not to receive announcements.';
$txt['email_as_pms'] = 'Send this to these groups using personal messages.';
$txt['email_continue'] = '继续';
$txt['email_done'] = 'done.';
$txt['email_members_succeeded'] = '你已经成功发送你的简讯!';

$txt['ban_title'] = 'Ban List';
$txt['ban_ip'] = '禁止IP：(例如：192.168.12.213或128.0.*.*) - 每行一条';
$txt['ban_email'] = '禁止邮件：( 例如：badguy@somewhere.com ) - 每行一条';
$txt['ban_username'] = '禁止用户名：(例如：l33tuser) - 每行一条';

$txt['ban_errors_detected'] = 'The following error or errors occurred while saving or editing the ban or the trigger';
$txt['ban_description'] = 'Here you can ban troublesome people either by IP, hostname, user name, or email.';
$txt['ban_add_new'] = 'Add new ban';
$txt['ban_banned_entity'] = 'Banned entity';
$txt['ban_on_ip'] = 'Ban on IP (e.g. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Ban on Hostname (e.g. *.mil)';
$txt['ban_on_email'] = 'Ban on Email Address (e.g. *@badsite.com)';
$txt['ban_on_username'] = 'Ban on User Name';
$txt['ban_notes'] = 'Notes';
$txt['ban_restriction'] = 'Restriction';
$txt['ban_full_ban'] = 'Full ban';
$txt['ban_partial_ban'] = 'Partial ban';
$txt['ban_cannot_post'] = '不能发布';
$txt['ban_cannot_register'] = '无法注册';
$txt['ban_cannot_login'] = '无法登录';
$txt['ban_add'] = '添加';
$txt['ban_edit_list'] = 'Ban List';
$txt['ban_type'] = 'Ban Type';
$txt['ban_days'] = 'day(s)';
$txt['ban_will_expire_within'] = 'Ban will expire after';
$txt['ban_added'] = '添加';
$txt['ban_expires'] = 'Expires';
$txt['ban_hits'] = '点击';
$txt['ban_actions'] = '动作';
$txt['ban_expiration'] = 'Expiration';
$txt['ban_reason_desc'] = 'Reason for ban, to be displayed to banned member.';
$txt['ban_notes_desc'] = 'Notes that may assist other staff members.';
$txt['ban_remove_selected'] = '删除选定';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Are you sure you want to remove the selected bans?';
$txt['ban_modify'] = '修改';
$txt['ban_name'] = 'Ban name';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Edit ban';
$txt['ban_add_notes'] = '<strong>Note</strong>: after creating the above ban, you can add additional entries that trigger the ban, like IP addresses, hostnames and email addresses.';
$txt['ban_expired'] = 'Expired / disabled';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'No restriction selected.';

$txt['ban_triggers'] = 'Triggers';
$txt['ban_add_trigger'] = 'Add ban trigger';
$txt['ban_add_trigger_submit'] = '添加';
$txt['ban_edit_trigger'] = '修改';
$txt['ban_edit_trigger_title'] = 'Edit ban trigger';
$txt['ban_edit_trigger_submit'] = '修改';
$txt['ban_remove_selected_triggers'] = 'Remove selected ban triggers';
$txt['ban_no_entries'] = 'There are currently no bans in effect.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Are you sure you want to remove the selected ban triggers?';
$txt['ban_trigger_browse'] = 'Browse Ban Triggers';
$txt['ban_trigger_browse_description'] = 'This screen shows all banned entities grouped by IP address, hostname, email address and user name.';

$txt['ban_log'] = 'Ban Log';
$txt['ban_log_description'] = 'The ban log shows all attempts to enter the forum by banned users (\'full ban\' and \'cannot register\' ban only).';
$txt['ban_log_no_entries'] = 'There are currently no ban log entries.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = '邮件地址';
$txt['ban_log_member'] = '成员';
$txt['ban_log_date'] = '日期';
$txt['ban_log_remove_all'] = '清除日志';
$txt['ban_log_remove_all_confirm'] = 'Are you sure you want to delete all ban log entries?';
$txt['ban_log_remove_selected'] = '删除选定';
$txt['ban_log_remove_selected_confirm'] = 'Are you sure you want to delete all selected ban log entries?';
$txt['ban_no_triggers'] = 'There are currently no ban triggers.';

$txt['settings_not_writable'] = 'These settings cannot be changed because Settings.php is read only.';

$txt['maintain_title'] = '论坛维护';
$txt['maintain_info'] = 'Basic forum backups, Database error checking, Clearing the Cache, Integration Hooks and more.';
$txt['maintain_sub_database'] = 'Database';
$txt['maintain_sub_routine'] = 'Routine';
$txt['maintain_sub_members'] = '会员';
$txt['maintain_sub_topics'] = '主题';
$txt['maintain_sub_attachments'] = '附件';
$txt['maintain_done'] = 'The maintenance task \'%1$s\' was executed successfully.';
$txt['maintain_fail'] = 'The maintenance task \'%1$s\' failed.';
$txt['maintain_no_errors'] = 'Congratulations, no errors were found.  Thanks for checking.';

$txt['maintain_tasks'] = '任务计划';
$txt['maintain_tasks_desc'] = '管理所有的预定任务。';

$txt['scheduled_log'] = '任务日志';
$txt['scheduled_log_desc'] = '列出已运行的任务日志。';
$txt['admin_log'] = '管理日志';
$txt['admin_log_desc'] = 'Lists administrative tasks that have been performed by admins of your forum.';
$txt['moderation_log'] = '审核日志';
$txt['moderation_log_desc'] = 'Lists moderation activities that have been performed by moderators on your forum.';
$txt['badbehavior_log'] = '不良行为记录';
$txt['badbehavior_log_desc'] = 'Lists requests that were blocked or marked suspicious by bad behavior.  If verbose logging is on all HTTP requests are listed.';
$txt['spider_log_desc'] = 'Review the entries related to search engine spider activity on your forum.';
$txt['pruning_log_desc'] = 'Use these tools to prune older entries in the various logs.';

$txt['mailqueue_title'] = 'Mail';

$txt['db_error_send'] = '发送数据库错误的反馈邮件';
$txt['db_persist'] = '使用永久连接';
$txt['ssi_db_user'] = 'Database user name to use in SSI mode';
$txt['ssi_db_passwd'] = 'Database password to use in SSI mode';

$txt['default_language'] = '论坛默认语言';

$txt['maintenance_subject'] = '显示主题';
$txt['maintenance_message'] = '显示信息';

$txt['errlog_desc'] = 'The error log tracks every error encountered by your forum.  To delete any errors from the database, mark the checkbox, and click the %1$s button at the bottom of the page.';
$txt['errlog_no_entries'] = 'There are currently no error log entries.';

$txt['theme_settings'] = '主题设置';
$txt['theme_edit_settings'] = '编辑主题';
$txt['theme_current_settings'] = '当前主题';

$txt['dvc_your'] = '你的版本';
$txt['dvc_current'] = '当前版本';
$txt['dvc_sources'] = 'Sources';
$txt['dvc_admin'] = '管理员';
$txt['dvc_controllers'] = 'Controllers';
$txt['dvc_database'] = 'Databases';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = '默认模板';
$txt['dvc_templates'] = '当前模板';
$txt['dvc_languages'] = '语言文件';

$txt['smileys_default_set_for_theme'] = 'Select default smiley set for this theme:';
$txt['smileys_no_default'] = '使用默认表情组';

$txt['censor_test'] = 'Test Censored Words';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Ignore case when censoring.';
$txt['censor_whole_words'] = 'Check only whole words.';
$txt['censor_allow'] = 'Allow users to turn off word censoring.';

$txt['admin_confirm_password'] = '(confirm password)';
$txt['admin_incorrect_password'] = 'Incorrect Password';

$txt['date_format'] = '(YYYY-MM-DD)';
$txt['undefined_gender'] = 'Undefined';
$txt['age'] = 'User age';
$txt['activation_status'] = '激活状态';
$txt['activated'] = '激活';
$txt['not_activated'] = '未激活';
$txt['is_banned'] = '禁止';
$txt['primary'] = 'Primary';
$txt['additional'] = '其他';
$txt['wild_cards_allowed'] = 'wildcard characters * and ? are allowed';
$txt['member_part_of_these_membergroups'] = 'Member is part of these member groups';
$txt['membergroups'] = '会员组';
$txt['confirm_delete_members'] = '你确定要删除选定的成员吗？';

$txt['support_credits_title'] = 'Support &amp; Credits';
$txt['support_credits_info'] = 'Support links for most common issues, the relevant forum version information you will be asked for when you request help and a list of contributors to the ElkArte project.';
$txt['support_title'] = '支持信息';
$txt['support_versions_current'] = '当前版本';
$txt['support_versions_forum'] = '这个版本';
$txt['support_versions_db'] = '%1$s version';
$txt['support_versions_server'] = '服务器版本';
$txt['support_versions_gd'] = 'GD版本';
$txt['support_versions_imagick'] = 'Imagick版本';
$txt['support_versions'] = '版本信息';
$txt['support_resources'] = 'Support Resources';
$txt['support_resources_p1'] = 'Our <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> provides the main documentation for ElkArte. The ElkArte Online Manual has many documents to help answer support questions and explain <a href="%2$s" target="_blank" class="new_win">Features</a>, <a href="%3$s" target="_blank" class="new_win">Settings</a>, <a href="%4$s" target="_blank" class="new_win">Themes</a>, <a href="%5$s" target="_blank" class="new_win">Packages</a>, etc. The Online Manual documents each area of ElkArte thoroughly and should answer most questions quickly.';
$txt['support_resources_p2'] = 'If you can\'t find the answers to your questions in the Documentation Wiki, you may want to search our <a href="%1$s" target="_blank" class="new_win">Support Community</a> or ask for assistance in our support boards. The ElkArte Support Community can be used for <a href="%2$s" target="_blank" class="new_win">support</a>, <a href="%3$s" target="_blank" class="new_win">customization</a>, and many other things such as discussing ElkArte, finding a host, and discussing administrative issues with other forum administrators.';

$txt['latest_updates'] = 'Latest noteworthy updates';
$txt['new_in_1_0_2'] = 'The most significant change in ElkArte 1.0.2 is avatar permission management. Currently each method of setting an avatar is permission-based, requiring the enabling/disabling of each method for each group. With 1.0.2 avatars are simply enabled/disabled by user group, this allows the enabled groups to add an avatar (by all available methods).<br />
The only permission available is a general one to allow members to change or not their avatars. Additionally there is only one setting for maximum width and height of avatars, these values apply to all avatar methods.<br /><br />
Due to the nature of the changes it was not impossible to migrate existing settings to the new format, for that reason you are encouraged to visit the <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Settings</a> page and set the options you prefer.';

$txt['edit_permissions_info'] = 'Use permission settings to manage global and specific board features and what actions that guest, members and moderators can do.';
$txt['membergroups_members'] = '普通会员';
$txt['membergroups_guests'] = '游客';
$txt['membergroups_add_group'] = '添加组';
$txt['membergroups_permissions'] = '权限';

$txt['permitgroups_restrict'] = 'Restrictive';
$txt['permitgroups_standard'] = 'Standard';
$txt['permitgroups_moderator'] = '版主';
$txt['permitgroups_maintenance'] = '维护';

$txt['confirm_delete_attachments'] = '确定要删除所选的附件？';
$txt['attachment_manager_browse_files'] = '浏览文件';
$txt['attachment_manager_repair'] = '维护';
$txt['attachment_manager_avatars'] = '头像';
$txt['attachment_manager_attachments'] = '附件';
$txt['attachment_manager_thumbs'] = '缩略图';
$txt['attachment_manager_last_active'] = '最后活动';
$txt['attachment_manager_member'] = '成员';
$txt['attachment_manager_avatars_older'] = '成员超过 %1$s 天不活动删除头像。';
$txt['attachment_manager_total_avatars'] = 'Total avatars';

$txt['attachment_manager_avatars_no_entries'] = '目前没有头像。';
$txt['attachment_manager_attachments_no_entries'] = '目前没有任何附件。';
$txt['attachment_manager_thumbs_no_entries'] = '目前没有缩略图。';

$txt['attachment_manager_settings'] = '附件设置';
$txt['attachment_manager_avatar_settings'] = '头像设置';
$txt['attachment_manager_browse'] = '浏览文件';
$txt['attachment_manager_maintenance'] = '文件维护';
$txt['attachmentEnable'] = 'Attachments mode';
$txt['attachmentEnable_deactivate'] = '禁用附件';
$txt['attachmentEnable_enable_all'] = '启用所有附件';
$txt['attachmentEnable_disable_new'] = '禁用新的附件';
$txt['attachmentCheckExtensions'] = '检查附件的扩展';
$txt['attachmentExtensions'] = '允许附件扩展';
$txt['attachmentRecodeLineEndings'] = 'Recode line endings in textual attachments';
$txt['attachmentShowImages'] = 'Display image attachments as pictures under post';
$txt['attachmentUploadDir'] = 'Attachments directory';
$txt['attachmentUploadDir_multiple_configure'] = '管理附件目录';
$txt['attachmentDirSizeLimit'] = '附件目录最大空间';
$txt['attachmentPostLimit'] = '每个帖子附件最大尺寸';
$txt['attachmentSizeLimit'] = '每个附件的最大尺寸';
$txt['attachmentNumPerPostLimit'] = '每个帖子附件最大数量';
$txt['attachment_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Image re-encoding is not possible.';
$txt['attachment_postsize_warning'] = 'The current php.ini setting \'post_max_size\' may not support this.';
$txt['attachment_filesize_warning'] = 'The current php.ini setting \'upload_max_filesize\' may not support this.';
$txt['attachment_image_reencode'] = 'Re-encode potentially dangerous image attachments';
$txt['attachment_image_reencode_note'] = '(requires GD module or ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'The extensive security checks can result in a large number of rejected attachments.';
$txt['attachment_image_paranoid'] = 'Perform extensive security checks on uploaded image attachments';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '（不适用于此系统）';
$txt['attachmentThumbnails'] = 'Resize images when showing under posts';
$txt['attachment_thumb_png'] = '缩略图保存为PNG';
$txt['attachment_thumb_memory'] = 'Adaptive thumbnail memory';
$txt['attachment_thumb_memory_note2'] = 'If the system can not get the memory no thumbnail will be created.';
$txt['attachment_thumb_memory_note1'] = 'Leave this unchecked to always attempt to create a thumbnail';
$txt['attachmentThumbWidth'] = '缩略图的最大宽度';
$txt['attachmentThumbHeight'] = '缩略图的最大高度';
$txt['attachment_thumbnail_settings'] = '缩略图设置';
$txt['attachment_security_settings'] = '附件安全设置';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = '只显示基本菜单';
$txt['attachment_inline_quotes'] = '选中以在引用中显示内联附件';

$txt['attach_dir_does_not_exist'] = 'Does Not Exist';
$txt['attach_dir_not_writable'] = 'Not Writable';
$txt['attach_dir_files_missing'] = 'Files Missing (<a href="{repair_url}">Repair</a>)';
$txt['attach_dir_unused'] = 'Unused';
$txt['attach_dir_empty'] = 'Empty';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Base directory';

$txt['attach_dir_desc'] = 'Create new directories or change the current directory below. Directories can be renamed as long as they do not contain a sub-directory. If the new directory is to be created within the forum directory structure, you\'ll just need to type the directory name. To remove a directory, blank the path input field. Directories can not be deleted if they contain either files or sub-directories (shown in brackets next to the file count).';
$txt['attach_dir_base_desc'] = 'You may use the area below to change the current base directory or create a new one. New base directories are also added to the Attachment Directory list. You may also designate an existing directory to be a base directory.';
$txt['attach_dir_save_problem'] = 'Oops, there seems to be a problem.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory. Please do so using a FTP client or your site file manager.';
$txt['attachments_no_write'] = 'This directory has been created but is not writable. Please attempt to do so using a FTP client or your site file manager.';
$txt['attach_dir_reserved'] = '无法添加。此目录是一个系统目录，不能用于附件。';
$txt['attach_dir_duplicate_msg'] = '无法添加。此目录已经存在。';
$txt['attach_dir_exists_msg'] = '无法移动。一个目录已经存在于该路径中。';
$txt['attach_dir_base_dupe_msg'] = 'Unable to add. This base directory has already been created.';
$txt['attach_dir_base_no_create'] = 'Unable to create. Please verify the path input or create this directory using an FTP client or site file manager and re-try.';
$txt['attach_dir_no_rename'] = 'Unable to move or rename. Please verify that the path is correct or that this directory does not contain any sub-directories.';
$txt['attach_dir_no_delete'] = 'Is not empty and can not be deleted. Please do so using a FTP client or site file manager.';
$txt['attach_dir_no_remove'] = 'Still contains files or is a base directory and can not be deleted.';
$txt['attach_dir_is_current'] = 'Unable to remove while it is selected as the current directory.';
$txt['attach_dir_is_current_bd'] = 'Unable to remove while it is selected as the current base directory.';
$txt['attach_last_dir'] = 'Last active attachment directory';
$txt['attach_current_dir'] = 'Current attachment directory';
$txt['attach_current'] = 'Current';
$txt['attach_path_manage'] = '管理附件路径';
$txt['attach_directories'] = 'Attachment Directories';
$txt['attach_paths'] = 'Attachment directory paths';
$txt['attach_path'] = 'Path';
$txt['attach_current_size'] = 'Size (KiB)';
$txt['attach_num_files'] = 'Files';
$txt['attach_dir_status'] = '状态';
$txt['attach_add_path'] = '添加路径';
$txt['attach_path_current_bad'] = 'Invalid current attachment path.';
$txt['attachmentDirFileLimit'] = 'Maximum number of files per directory';

$txt['attach_base_paths'] = 'Base directory paths';
$txt['attach_num_dirs'] = '目录';
$txt['max_image_width'] = 'Max display width of posted or attached images';
$txt['max_image_height'] = 'Max display height of posted or attached images';

$txt['automanage_attachments'] = 'Choose the method for the management of the attachment directories';
$txt['attachments_normal'] = '(Manual) ElkArte default behaviour';
$txt['attachments_auto_years'] = '(Auto) Subdivide by years';
$txt['attachments_auto_months'] = '(Auto) Subdivide by years and months';
$txt['attachments_auto_days'] = '(Auto) Subdivide by years, months and days';
$txt['attachments_auto_16'] = '(Auto) 16 random directories';
$txt['attachments_auto_16x16'] = '(Auto) 16 random directories with 16 random sub-directories';
$txt['attachments_auto_space'] = '(Auto) When either directory space limit is reached';

$txt['use_subdirectories_for_attachments'] = 'Create new directories within a base directory';
$txt['use_subdirectories_for_attachments_note'] = 'Otherwise any new directories will be created within the forum\'s main directory.';
$txt['basedirectory_for_attachments'] = 'Set a base directory for attachments';
$txt['basedirectory_for_attachments_current'] = 'Current base directory';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Please note that the directory is wrong. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">There seems to be a problem with this directory. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';

$txt['attachment_transfer'] = 'Transfer Attachments';
$txt['attachment_transfer_desc'] = 'Transfer files between directories.';
$txt['attachment_transfer_select'] = '选择目录';
$txt['attachment_transfer_now'] = 'Transfer';
$txt['attachment_transfer_from'] = 'Transfer files from';
$txt['attachment_transfer_auto'] = 'Move them automatically by space or file count';
$txt['attachment_transfer_auto_select'] = 'Select base directory';
$txt['attachment_transfer_to'] = 'Or move them to a specific directory.';
$txt['attachment_transfer_empty'] = 'Move all files from the source directory.';
$txt['attachment_transfer_no_base'] = 'No base directories available.';
$txt['attachment_transfer_forum_root'] = 'Forum root directory.';
$txt['attachment_transfer_no_room'] = 'Directory size or file count limit reached.';
$txt['attachment_transfer_no_find'] = 'No files were found to transfer.';
$txt['attachments_transfered'] = '%1$d files were transferred to %2$s';
$txt['attachments_not_transfered'] = '%1$d files were not transferred.';
$txt['attachment_transfer_no_dir'] = 'Either the source directory or one of the target options were not selected.';
$txt['attachment_transfer_same_dir'] = 'You cannot select the same directory as both the source and target.';
$txt['attachment_transfer_progress'] = 'Please wait. Transfer in progress.';

$txt['avatar_settings'] = 'General avatar settings';
$txt['avatar_default'] = 'Enable a default avatar for all users without their own avatar';
$txt['avatar_directory'] = 'Avatars directory';
$txt['avatar_url'] = 'Avatars URL';
$txt['avatar_max_width'] = '头像的最大宽度 (px)';
$txt['avatar_max_height'] = '头像的最大高度 (px)';
$txt['avatar_action_too_large'] = '如果头像太大…';
$txt['option_refuse'] = 'Refuse it';
$txt['option_resize'] = 'Let the CSS resize it';
$txt['option_download_and_resize'] = 'Download and resize it (requires GD module or ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Enable use of gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'Use PNG for resized avatars';
$txt['avatar_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Some avatar features are disabled.';
$txt['avatar_external'] = '外部头像';
$txt['avatar_external_enabled'] = 'Enable use of external (remote/URL) avatars';
$txt['avatar_upload'] = '上传头像';
$txt['avatar_resize_options'] = '服务器存储选项';
$txt['avatar_upload_enabled'] = '启用头像上传';
$txt['avatar_server_stored'] = '系统头像';
$txt['avatar_stored_enabled'] = '启用选择系统头像';
$txt['profile_set_avatar'] = '会员组允许选择头像';
$txt['avatar_select_permission'] = 'Select permissions for each group';
$txt['avatar_download_external'] = 'Download avatar at given URL';
$txt['custom_avatar_enabled'] = '上传头像到...';
$txt['option_attachment_dir'] = '附件目录';
$txt['option_specified_dir'] = 'Specific directory...';
$txt['custom_avatar_dir'] = '上传目录';
$txt['custom_avatar_dir_desc'] = 'This should be a valid and writable directory, different than the server-stored directory.';
$txt['custom_avatar_url'] = 'Upload URL';
$txt['custom_avatar_check_empty'] = 'The custom avatar directory you have specified may be empty or invalid. Please ensure these settings are correct.';
$txt['avatar_reencode'] = 'Re-encode potentially dangerous avatars';
$txt['avatar_reencode_note'] = '(requires GD module)';
$txt['avatar_paranoid_warning'] = '安全检查可能会导致大量头像被驳回。';
$txt['avatar_paranoid'] = '上传头像进行安全检查';

$txt['repair_attachments'] = '维护附件';
$txt['repair_attachments_complete'] = '维护完成';
$txt['repair_attachments_complete_desc'] = 'All selected errors have now been corrected';
$txt['repair_attachments_no_errors'] = 'No errors were found';
$txt['repair_attachments_error_desc'] = 'The follow errors were found during maintenance. Check the box next to the errors you wish to fix and hit continue.';
$txt['repair_attachments_continue'] = '继续';
$txt['repair_attachments_cancel'] = '撤销';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d thumbnails are missing a parent attachment';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d parents are flagged as having thumbnails but don\'t';
$txt['attach_repair_file_missing_on_disk'] = '%1$d attachments/avatars have an entry but no longer exist on disk';
$txt['attach_repair_file_wrong_size'] = '%1$d attachments/avatars are being reported as the wrong filesize';
$txt['attach_repair_file_size_of_zero'] = '%1$d attachments/avatars have a size of zero on disk. (These will be deleted)';
$txt['attach_repair_attachment_no_msg'] = '%1$d attachments no longer have a message associated with them';
$txt['attach_repair_avatar_no_member'] = '%1$d avatars no longer have a member associated with them';
$txt['attach_repair_wrong_folder'] = '%1$d attachments are in the wrong directory';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d files do not have a corresponding entry in the database. (These will be deleted)';

$txt['news_title'] = '新闻和简报';
$txt['news_settings_desc'] = 'Here you can change the settings and permissions related to news and newsletters.';
$txt['news_mailing_desc'] = 'From this menu you can send messages to all users who\'ve registered and entered their email addresses. You may edit the distribution list, or send messages to all. Useful for important update/news information.';
$txt['news_error_no_news'] = '没有可预览项';
$txt['groups_edit_news'] = 'Groups allowed to edit news items';
$txt['groups_send_mail'] = 'Groups allowed to send out forum newsletters';
$txt['xmlnews_enable'] = 'Enable XML/RSS news';
$txt['xmlnews_maxlen'] = 'Maximum message length';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Number of items in a news feed';
$txt['xmlnews_maxlen_note'] = '(0 to disable, bad idea.)';
$txt['editnews_clickadd'] = 'Add another item';
$txt['editnews_remove_selected'] = '删除选定';
$txt['editnews_remove_confirm'] = '你确定要删除选定的新闻项目吗？';
$txt['censor_clickadd'] = 'Add another word';

$txt['layout_controls'] = '论坛';
$txt['logs'] = '日志';
$txt['generate_reports'] = '报告';

$txt['update_available'] = '可用更新';
$txt['update_message'] = 'You\'re using an outdated version of ElkArte, which contains some bugs which have since been fixed.
	It is recommended that you <a href="#" id="update-link">update your forum</a> to the latest version as soon as possible. It only takes a minute!';

$txt['manageposts'] = '帖子和话题';
$txt['manageposts_title'] = '管理帖子和话题';
$txt['manageposts_description'] = '在这里你可以管理所有与话题和帖子相关的设置。';

$txt['manageposts_seconds'] = '秒';
$txt['manageposts_minutes'] = '分钟';
$txt['manageposts_characters'] = '字符';
$txt['manageposts_days'] = '天';
$txt['manageposts_posts'] = '帖子';
$txt['manageposts_topics'] = '话题';

$txt['pollMode'] = '启用调查';

$txt['manageposts_settings'] = '发布设置';
$txt['manageposts_settings_description'] = 'Here you can set everything related to posts and posting.';

$txt['manageposts_bbc_settings'] = 'Bulletin Board Code';
$txt['manageposts_bbc_settings_description'] = 'Bulletin board code can be used to add markup to forum messages. For example, to highlight the word \'house\' you can type [b]house[/b]. All Bulletin board code tags are surrounded by square brackets (\'[\' and \']\').';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code settings';

$txt['manageposts_topic_settings'] = '话题设置';
$txt['manageposts_topic_settings_description'] = '在这里你可以设置涉及话题功能。';

$txt['managedrafts_settings'] = '草案设置';
$txt['managedrafts_settings_description'] = '在这里你可以设置涉及草案的功能。';
$txt['manage_drafts'] = '草稿';

$txt['mail_center'] = '订阅邮件中心';
$txt['mm_emailerror'] = 'Failed Emails';
$txt['mm_emailfilters'] = 'Filters';
$txt['mm_emailparsers'] = 'Parsers';
$txt['mm_emailtemplates'] = '模板';
$txt['mm_emailsettings'] = '设置';

$txt['removeNestedQuotes'] = 'Remove nested quotes when quoting';
$txt['enableSpellChecking'] = '启用拼写检查';
$txt['enableSpellChecking_warning'] = '这不在所有服务器上运行。';
$txt['enableSpellChecking_error'] = '这不在服务器上运行。';
$txt['enableVideoEmbeding'] = '启用自动嵌入视频链接。';
$txt['enableCodePrettify'] = '启用美化代码标签';
$txt['max_messageLength'] = 'Maximum allowed post size';
$txt['max_messageLength_zero'] = '0 for no max.';
$txt['convert_to_mediumtext'] = 'Your database is not setup to accept messages longer than 65535 characters. Please use the <a href="%1$s">database maintenance</a> page to convert the database and then come back to increase the maximum allowed post size.';
$txt['topicSummaryPosts'] = '帖子显示主题摘要';
$txt['spamWaitTime'] = 'Time required between posts from the same IP';
$txt['edit_wait_time'] = 'Courtesy edit wait time';
$txt['edit_disable_time'] = '允许编辑发布的最长时间';
$txt['edit_disable_time_zero'] = '0为禁用';
$txt['preview_characters'] = '最新/第一篇文章预览的最大长度';
$txt['preview_characters_units'] = '字符';
$txt['preview_characters_zero'] = '0 展示整个信息';
$txt['message_index_preview'] = '在信息主页显示帖子预览';
$txt['message_index_preview_off'] = '不显示预览';
$txt['message_index_preview_first'] = '显示第一个帖子的文本';
$txt['message_index_preview_last'] = '显示最近帖子的文本';

$txt['enableBBC'] = 'Enable bulletin board code (BBC)';
$txt['enablePostHTML'] = 'Enable <em>basic</em> HTML in posts';
$txt['autoLinkUrls'] = 'Automatically link posted URLs';
$txt['disabledBBC'] = '启用BBC标签';
$txt['bbcTagsToUse'] = '启用BBC标签';
$txt['bbcTagsToUse_select'] = '选择允许使用的标签';
$txt['bbcTagsToUse_select_all'] = '选择所有标签';

$txt['enableParticipation'] = 'Enable participation icons';
$txt['enableFollowup'] = 'Enable followups';
$txt['enable_unwatch'] = 'Enable unwatching of topics';
$txt['oldTopicDays'] = 'Time before topic is warned as old on reply';
$txt['oldTopicDays_zero'] = '0为禁用';
$txt['defaultMaxTopics'] = '在信息主页的每页话题数量';
$txt['defaultMaxMessages'] = '话题每页的帖子数';
$txt['disable_print_topic'] = '禁用打印主题功能';
$txt['hotTopicPosts'] = '热门话题的帖子数量';
$txt['hotTopicVeryPosts'] = '非常热门的话题为帖子数量';
$txt['useLikesNotViews'] = '热门话题为用户喜欢数量';
$txt['enableAllMessages'] = 'Max topic size to show &quot;All&quot; posts';
$txt['enableAllMessages_zero'] = '0 to never show &quot;All&quot;';
$txt['disableCustomPerPage'] = 'Disable user defined topic/message count per page';
$txt['enablePreviousNext'] = '启用上一个/下一个主题链接';

$txt['not_done_title'] = '尚未完成';
$txt['not_done_reason'] = '为了避免超载的服务器，进程已经暂停。它应该自动持续几秒钟。如果没有，请点击继续下面。';
$txt['not_done_continue'] = '继续';

$txt['general_settings'] = '一般';
$txt['database_paths_settings'] = '数据库和路径';
$txt['cookies_sessions_settings'] = 'cookie和session';
$txt['caching_settings'] = '缓存';
$txt['loadavg'] = '服务器负载';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = '地区设定';
$txt['phpinfo_defaultsettings'] = '默认设置';
$txt['phpinfo_itemsettings'] = '设置';

$txt['language_configuration'] = '语言';
$txt['language_description'] = '此部分允许您编辑安装在论坛语言或从ElkArte站点下载新的。你也可以在这里编辑语言相关的设置。';
$txt['language_edit'] = '编辑语言';
$txt['language_add'] = '添加语言';
$txt['language_settings'] = '设置';

$txt['advanced'] = 'Advanced';
$txt['simple'] = 'Simple';

$txt['admin_news_select_recipients'] = '请选择接收简报的人';
$txt['admin_news_select_group'] = '会员组';
$txt['admin_news_select_group_desc'] = '选择要接收简报的组。';
$txt['admin_news_select_members'] = '会员';
$txt['admin_news_select_members_desc'] = 'Additional members to receive the newsletter.';
$txt['admin_news_select_excluded_members'] = 'Excluded Members';
$txt['admin_news_select_excluded_members_desc'] = '不接收简报的成员。';
$txt['admin_news_select_excluded_groups'] = '排除组';
$txt['admin_news_select_excluded_groups_desc'] = 'Select groups who should definitely not receive the newsletter.';
$txt['admin_news_select_email'] = '邮件地址';
$txt['admin_news_select_email_desc'] = 'A semi-colon separated list of email addresses which should be sent this newsletter. (i.e. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Override notification settings';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'You cannot send a personal message to an email address. If you continue all entered email addresses will be ignored.\\n\\nAre you sure you wish to do this?';

$txt['mailqueue_browse'] = 'Browse Queue';
$txt['mailqueue_settings'] = '设置';

$txt['admin_search'] = '快速搜索';
$txt['admin_search_type_internal'] = '任务/设置';
$txt['admin_search_type_member'] = '成员';
$txt['admin_search_type_online'] = '在线手册';
$txt['admin_search_go'] = 'Go';
$txt['admin_search_results'] = '搜索结果';
$txt['admin_search_results_desc'] = '搜索结果： &quot;%1$s&quot;';
$txt['admin_search_results_again'] = '重新搜索';
$txt['admin_search_results_none'] = '未发现结果。';

$txt['admin_search_section_sections'] = 'Section';
$txt['admin_search_section_settings'] = '设置';

$txt['core_settings_title'] = '核心功能';
$txt['core_settings_desc'] = '本页可以让您打开或关闭您的论坛的可选功能。';
$txt['mods_cat_features'] = '一般';
$txt['mods_cat_security_general'] = '一般';
$txt['antispam_title'] = 'Anti-Spam';
$txt['badbehavior_title'] = '不良行为';
$txt['mods_cat_modifications_misc'] = 'Miscellaneous';
$txt['mods_cat_layout'] = '布局';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderation';
$txt['signature_settings_short'] = '签名';
$txt['custom_profile_shorttitle'] = 'Profile Fields';
$txt['pruning_title'] = '日志清理';

$txt['core_settings_activation_message'] = '该功能 {core_feature} 已被激活，点击标题来配置它';
$txt['core_settings_deactivation_message'] = '该功能 {core_feature} 已停用';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = '修改版块';
$txt['mboards_new_cat'] = '创建新类别';
$txt['manage_holidays'] = '管理假期';
$txt['calendar_settings'] = '日程设置';
$txt['search_weights'] = 'Weights';
$txt['search_method'] = '搜索方式';
$txt['search_sphinx'] = 'Configure Sphinx';

$txt['smiley_sets'] = '表情组';
$txt['smileys_add'] = '添加表情';
$txt['smileys_edit'] = '编辑表情';
$txt['smileys_set_order'] = 'Set Smiley order';
$txt['icons_edit_message_icons'] = '编辑信息图标';

$txt['membergroups_new_group'] = '添加成员组';
$txt['membergroups_edit_groups'] = '编辑成员组';
$txt['permissions_groups'] = '常规权限';
$txt['permissions_boards'] = '版主权限';
$txt['permissions_profiles'] = 'Edit Profiles';
$txt['permissions_post_moderation'] = 'Post Moderation';

$txt['browse_packages'] = '浏览软件包';
$txt['download_packages'] = '下载软件包';
$txt['upload_packages'] = '上传软件包';
$txt['installed_packages'] = '安装的软件包';
$txt['package_file_perms'] = '文件权限';
$txt['package_settings'] = '设置';
$txt['package_servers'] = 'Package Servers';
$txt['themeadmin_admin_title'] = '管理和安装';
$txt['themeadmin_list_title'] = '主题设置';
$txt['themeadmin_reset_title'] = '会员选项';
$txt['themeadmin_edit_title'] = '修改主题';
$txt['admin_browse_register_new'] = '注册新会员';

$txt['search_engines'] = '搜索引擎';
$txt['spider_logs'] = '蜘蛛日志';
$txt['spider_stats'] = '统计';

$txt['paid_subscriptions'] = '付费订阅';
$txt['paid_subs_view'] = '查看订阅';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks';
$txt['hooks_field_hook_name'] = 'Hook Name';
$txt['hooks_field_function_name'] = 'Function Name';
$txt['hooks_field_function'] = '功能';
$txt['hooks_field_included_file'] = '包含文件';
$txt['hooks_field_file_name'] = '文件名';
$txt['hooks_field_hook_exists'] = '状态';
$txt['hooks_active'] = 'Exists';
$txt['hooks_disabled'] = '禁用'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = '未找到';
$txt['hooks_no_hooks'] = '系统中没有钩子。';
$txt['hooks_disable_legend'] = 'Legend';
$txt['hooks_disable_legend_exists'] = '钩存在且处于活动状态';
$txt['hooks_disable_legend_disabled'] = '钩存在但已被禁用';
$txt['hooks_disable_legend_missing'] = '未找到钩';
$txt['hooks_reset_filter'] = '重设过滤';

$txt['board_perms_allow'] = '允许';
$txt['board_perms_ignore'] = '忽略';
$txt['board_perms_deny'] = '拒绝';
$txt['all_boards_in_cat'] = '该类别下所有版块';

$txt['url'] = 'URL';
$txt['words_sep'] = '单词分隔符';

$txt['admin_order_title'] = '排序错误';
$txt['admin_order_error'] = '处理您的请求时出现未知错误';

// Known controllers that can work on the front page
$txt['default'] = '默认';
$txt['front_page'] = '选择要在首页显示的动作：';

$txt['BoardIndex_Controller'] = '版块目录';
$txt['MessageIndex_Controller'] = '版块内容';
$txt['message_index_frontpage'] = '选择要在首页显示的版块：';
$txt['Recent_Controller'] = '最近的帖子';
$txt['recent_frontpage'] = '要显示的消息数：';
