<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = '管理版块和类别';
$txt['order'] = 'Order';
$txt['full_name'] = '全名';
$txt['name_on_display'] = '这是将显示的名称。';
$txt['boards_and_cats_desc'] = 'Edit your categories and boards here. List multiple moderators as <em>&quot;username&quot;, &quot;username&quot;</em>. (these must be usernames and *not* display names)<br />To create a new board, click the Add Board button.<br />To move a board you can drag and drop it to its new location in the list (across cataegories and Child of locations)<br />To create a new board as a child of a current board, select "Child of..." from the Order drop down menu when creating the board.';
$txt['parent_members_only'] = '普通会员';
$txt['parent_guests_only'] = '游客';
$txt['catConfirm'] = '你确定要删除这个类别？';
$txt['boardConfirm'] = '你确定要删除这个版块吗？';

$txt['catEdit'] = '编辑类别';
$txt['collapse_enable'] = 'Collapsible';
$txt['collapse_desc'] = '允许用户折叠类别';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'After ';
$txt['mboards_order_first'] = 'In first place';
$txt['mboards_board_error'] = 'Failed to resolve move location.';

$txt['mboards_new_board'] = 'Add Board';
$txt['mboards_new_cat_name'] = '新类别';
$txt['mboards_add_cat_button'] = '添加类别';
$txt['mboards_new_board_name'] = 'New Board';

$txt['mboards_modify'] = 'modify';
$txt['mboards_permissions'] = 'permissions';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Are you sure you want to switch this board to use local permissions?';

$txt['mboards_delete_cat'] = '删除类别';
$txt['mboards_delete_board'] = '删除版块';

$txt['mboards_delete_cat_contains'] = 'Deleting this category will also delete the below boards, including all topics, posts and attachments within each board';
$txt['mboards_delete_option1'] = '删除类别和其中包含的所有版块。';
$txt['mboards_delete_option2'] = '删除类别并移动其中包含的所有版块';
$txt['mboards_delete_board_contains'] = 'Deleting this board will also move the sub-boards below, including all topics, posts and attachments within each board';
$txt['mboards_delete_board_option1'] = 'Delete board and move sub-boards contained within to category level.';
$txt['mboards_delete_board_option2'] = 'Delete board and move all sub-boards contained within to';
$txt['mboards_delete_what_do'] = 'Please select what you would like to do with these boards';
$txt['mboards_delete_confirm'] = 'Confirm';
$txt['mboards_delete_cancel'] = '撤销';

$txt['mboards_category'] = '类别';
$txt['mboards_description'] = '描述';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Allowed Groups';
$txt['mboards_groups_desc'] = 'Groups allowed to access this board.<br /><em>Note: if the member is in any group or post group checked, they will have access to this board.</em>';
$txt['mboards_groups_regular_members'] = 'This group contains all members that have no primary group set.';
$txt['mboards_groups_post_group'] = 'This group is a post count based group.';
$txt['mboards_moderators'] = '版主';
$txt['mboards_moderators_desc'] = 'Additional members to have moderation privileges on this board.  Note that administrators don\'t have to be listed here.';
$txt['mboards_count_posts'] = 'Count Posts';
$txt['mboards_count_posts_desc'] = 'Makes new replies and topics raise members\' post counts.';
$txt['mboards_unchanged'] = 'Unchanged';
$txt['mboards_theme'] = '版块主题';
$txt['mboards_theme_desc'] = 'This allows you to change the look of your forum inside only this board.';
$txt['mboards_theme_default'] = '(overall forum default.)';
$txt['mboards_override_theme'] = 'Override Member\'s Theme';
$txt['mboards_override_theme_desc'] = 'Use this board\'s theme even if the member didn\'t choose to use the defaults.';

$txt['mboards_redirect'] = '重定向到一个网址';
$txt['mboards_redirect_desc'] = 'Enable this option to redirect anyone who clicks on this board to another web address.';
$txt['mboards_redirect_url'] = '将用户地址重定向到';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Reset redirect count';
$txt['mboards_redirect_reset_desc'] = '选择此项将重置版块重定向计数为零。';
$txt['mboards_current_redirects'] = 'Currently: %1$s';
$txt['mboards_redirect_disabled'] = '注意：启动此项，版块必须是空的。';
$txt['mboards_redirect_disabled_recycle'] = 'Note: You cannot set the recycle bin board to be a redirection board.';

$txt['mboards_order_before'] = 'Before';
$txt['mboards_order_child_of'] = 'Child of';
$txt['mboards_order_in_category'] = 'In category';
$txt['mboards_current_position'] = 'Current Position';
$txt['no_valid_parent'] = 'Board %1$s does not have a valid parent. Use the \'find and repair errors\' function to fix this.';

$txt['mboards_recycle_disabled_delete'] = 'You must select an alternative recycle bin board or disable recycling before you can delete this board.';

$txt['mboards_settings_desc'] = 'Edit general board and category settings.';
$txt['groups_manage_boards'] = 'Membergroups allowed to manage boards and categories';
$txt['recycle_enable'] = 'Enable recycling of deleted topics';
$txt['recycle_board'] = 'Board for recycled topics';
$txt['recycle_board_unselected_notice'] = 'You have enabled the recycling of topics without specifying a board to place them in.  This feature will not be enabled until you specify a board to place recycled topics into.';
$txt['countChildPosts'] = 'Count child\'s posts in parent\'s totals';
$txt['allow_ignore_boards'] = 'Allow boards to be ignored';
$txt['deny_boards_access'] = 'Enable the option to deny board access based on membergroup';
$txt['boardsaccess_option_desc'] = 'For each permission you can choose \'Allow\' (A), \'Ignore\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />If you deny access, any member - (including moderators) - in that group will be denied access.<br />For this reason, you should set deny carefully, only when <strong>necessary</strong>. Ignore, on the other hand, denies unless otherwise granted.';

$txt['mboards_select_destination'] = 'Select destination for board \'<strong>%1$s</strong>\'';
$txt['mboards_cancel_moving'] = 'Cancel moving';
$txt['mboards_move'] = '移动';

$txt['mboards_no_cats'] = '目前没有类别或版块配置。';
