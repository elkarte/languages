<?php
// Version: 1.1; mentions

$txt['my_mentions'] = '我的通知';
$txt['my_unread_mentions'] = '我的未读通知';
$txt['my_mentions_pages'] = 'page %1$d';
$txt['no_mentions_yet'] = '没有提及';
$txt['no_new_mentions'] = '没有新的通知';

$txt['mentions_from'] = '成员';
$txt['mentions_when'] = '时间';
$txt['mentions_what'] = '信息';
$txt['mentions_all'] = '显示所有';
$txt['mentions_unread'] = '显示未读';
$txt['mentions_action'] = '操作';
$txt['mentions_delete_warning'] = '您确定要删除该条目？';
$txt['mentions_markread'] = '标记为已读';
$txt['mentions_markunread'] = '标记为未读';

$txt['mentions_settings'] = '通知设置';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = '启用站点通知';
$txt['mentions_buddy'] = 'Add a mention when a member is added to someone\'s buddy list';
$txt['mentions_dont_notify_rlike'] = 'Don\'t inform the member when a post has a liked removed';

$txt['mention_mentionmem'] = 'Mentioned you in the message {msg_link}';
$txt['mention_likemsg'] = 'Liked your message {msg_link}';
$txt['mention_rlikemsg'] = 'Unliked your message {msg_link}';
$txt['mention_buddy'] = '将您添加到他们的好友列表中。';
$txt['mention_quotedmem'] = 'Quoted a message of yours in {msg_link}';
$txt['mention_mailfail'] = 'Disabled email notification due to delivery failure';

$txt['mentions_type_all'] = '所有提及';
$txt['mentions_type_mentionmem'] = '提到我的';
$txt['mentions_type_likemsg'] = '喜欢';
$txt['mentions_type_rlikemsg'] = '不喜欢';
$txt['mentions_type_buddy'] = '好友';
$txt['mentions_type_quotedmem'] = '引用';
$txt['mentions_type_mailfail'] = '发送失败';

$txt['mentions_mark_all_read'] = '将所有通知标记为已读';

$txt['setting_notify_enable_this'] = 'Enable user notifications of this event.';

$txt['setting_buddy'] = '朋友';
$txt['setting_likemsg'] = '喜欢';
$txt['setting_rlikemsg'] = '移除喜欢';
$txt['setting_mentionmem'] = '@mentions';
$txt['setting_quotedmem'] = 'Quoting';
$txt['setting_mailfail'] = '发送失败';