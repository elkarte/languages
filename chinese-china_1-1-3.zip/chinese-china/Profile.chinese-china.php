<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = '你无权更改此人的个人资料。';
$txt['website_title'] = '网站标题';
$txt['website_url'] = '网址';
$txt['signature'] = '签名';
$txt['profile_posts'] = '帖子';

$txt['profile_info'] = '额外详情';
$txt['profile_contact'] = '联系信息';
$txt['profile_moderation'] = '审核信息';
$txt['profile_more'] = '签名';
$txt['profile_attachments'] = '最近的附件';
$txt['profile_attachments_no'] = '这个成员没有附件';
$txt['profile_recent_posts'] = '最新文章';
$txt['profile_posts_no'] = '这里没有该成员的帖子';
$txt['profile_topics'] = '最近的话题';
$txt['profile_topics_no'] = '没有来自该会员的话题';
$txt['profile_buddies_no'] = '你还没有设置任何好友';
$txt['profile_user_info'] = '用户信息';
$txt['profile_contact_no'] = '这里没有该成员的联系信息';
$txt['profile_signature_no'] = '该成员没有签名';
$txt['profile_additonal_no'] = '该成员没有其他信息';
$txt['profile_user_summary'] = '简介';
$txt['profile_action'] = '当前';
$txt['profile_recent_activity'] = '近期活动';
$txt['profile_activity'] = '活动';
$txt['profile_loadavg'] = '请稍后再试。由于网站需求量很大，目前无法提供此信息。';

$txt['change_profile'] = '修改简介';
$txt['preview_signature'] = '预览签名';
$txt['current_signature'] = '当前签名';
$txt['signature_preview'] = '签名预览';
$txt['personal_picture'] = '个性化图片';
$txt['no_avatar'] = '无头像';
$txt['choose_avatar_gallery'] = '从图库中选择头像';
$txt['preferred_language'] = '首选语言';
$txt['age'] = '年龄';
$txt['no_pic'] = '（无图片）';
$txt['avatar_by_url'] = 'Specify your own avatar by URL. (e.g.: <em>http://www.mypage.com/mypic.png</em>)';
$txt['my_own_pic'] = '以图床链接来指定头像';
$txt['gravatar'] = '头像';
$txt['date_format'] = '此处的格式将用于显示整个论坛的日期。';
$txt['time_format'] = '时间格式';
$txt['display_name_desc'] = '这是公开展示的名称。';
$txt['personal_time_offset'] = 'Number of hours to +/- to make displayed time equal to your local time.';
$txt['dob'] = '生日';
$txt['dob_month'] = 'Month (MM)';
$txt['dob_day'] = 'Day (DD)';
$txt['dob_year'] = 'Year (YYYY)';
$txt['password_strength'] = '为了最佳安全性，您至少应该使用八个字符，并结合字母、数字和符号。';
$txt['include_website_url'] = '如果您在下面指定了URL，则必须包括此项。';
$txt['complete_url'] = '这必须是一个完整的URL。';
$txt['sig_info'] = '签名会显示在每个帖子和个人信息的底部。在你的签名中可以设置高亮和表情符号。';
$txt['max_sig_characters'] = 'Max characters: %1$d; characters remaining: ';
$txt['send_member_pm'] = '给该成员发私信';
$txt['hidden'] = '隐藏';
$txt['current_time'] = '当前论坛时间';

$txt['language'] = '语言';
$txt['avatar_too_big'] = '头像尺寸过大，请调整大小并重试 (max';
$txt['invalid_registration'] = '无效日期注册值，有效示例：';
$txt['current_password'] = '当前密码';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = '出于安全原因，您需要使用当前密码来修改账号信息。';

$txt['timeoffset_autodetect'] = '自动检测';

$txt['secret_question'] = '安全问题';
$txt['secret_desc'] = 'To help retrieve your password, enter a question here with an answer that <strong>only</strong> you know.';
$txt['secret_desc2'] = '请认真填写，不要让别人猜出您的答案！';
$txt['secret_answer'] = '答案';
$txt['incorrect_answer'] = '非常抱歉，您没有在个人资料中选择有效的安全问题的组合和答案。请单击返回按钮，并使用获取密码的默认方式。';
$txt['enter_new_password'] = 'Please enter the answer to your question, and the password you would like to use.  Your password will be changed to the one you select provided you answer the question correctly.';
$txt['secret_why_blank'] = '为何这是空白的？';

$txt['authentication_reminder'] = '身份验证提醒';
$txt['password_reminder_desc'] = '如果您忘记了登录详细信息，请不要担心，可以检索它们。要开始此过程，请在下面输入您的用户名或电子邮件地址。';
$txt['authentication_options'] = '请从以下两个选项中选择一个';
$txt['authentication_openid_email'] = '通过电子邮件向我提醒OpenID身份';
$txt['authentication_openid_secret'] = 'Answer my &quot;secret question&quot; to display my OpenID identity';
$txt['authentication_password_email'] = '通过邮件发送新密码';
$txt['authentication_password_secret'] = 'Let me set a new password by answering my &quot;secret question&quot;';
$txt['openid_secret_reminder'] = 'Please enter your answer to the question below. If you get it correct your OpenID identity will be shown.';
$txt['reminder_openid_is'] = 'The OpenID identity associated with your account is:<br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /><br />Please make a note of this for future reference.';
$txt['reminder_continue'] = '继续';

$txt['accept_agreement_title'] = '接受协议';
$txt['agreement_accepted_title'] = '继续';

$txt['current_theme'] = '当前主题';
$txt['change'] = '修改主题';
$txt['theme_forum_default'] = '论坛或版块默认';
$txt['theme_forum_default_desc'] = '这是默认的主题，这意味着您的主题随管理员的设置和您正在查看的版块一起更改。';

$txt['profileConfirm'] = '你真的想删除这名成员吗？';

$txt['custom_title'] = '自定义标题';

$txt['lastLoggedIn'] = '最后活动';

$txt['notify_settings'] = '通知设置:';
$txt['notify_save'] = '保存设置';
$txt['notify_important_email'] = '通过邮件接收论坛简报、公告和重要通知。';
$txt['notify_regularity'] = '对于我已请求通知的话题和版块，请通知我';
$txt['notify_regularity_none'] = '从不';
$txt['notify_regularity_instant'] = '立即';
$txt['notify_regularity_first_only'] = '立即 - 但仅限第一个未读回复';
$txt['notify_regularity_daily'] = '每日';
$txt['notify_regularity_weekly'] = '每周';
$txt['auto_notify'] = '发布或回复话题时，请启用话题通知。';
$txt['auto_notify_pbe_post'] = 'This is <strong>NOT</strong> recommended if you have "board" notifications enabled.';
$txt['notify_send_types'] = '对于我已经请求通知的话题和版块，请通知我。';
$txt['notify_send_type_everything'] = '回复和审核';
$txt['notify_send_type_everything_own'] = '只有当我开始讨论话题时才开始审核';
$txt['notify_send_type_only_replies'] = '仅回复';
$txt['notify_send_type_only_replies_pbe'] = '所有消息';
$txt['notify_send_type_nothing'] = '什么都没有';
$txt['notify_send_body'] = 'When sending notifications of a reply to a topic, send the post in the email (but please don\'t reply to these emails.)';
$txt['notify_send_body_pbe'] = 'When sending email notifications, send the full text of the post in the email';
$txt['notify_send_body_pbe_post'] = '<strong>NOT</strong> available with Daily / Weekly summary';

$txt['notify_method'] = 'Notification and:';
$txt['notify_notification'] = 'no email (only mention/alert)';
$txt['notify_email'] = '立即发送邮件';
$txt['notify_email_daily'] = '每日邮件';
$txt['notify_email_weekly'] = '每周邮件';

$txt['notify_type_likemsg'] = 'Notify when one of your messages is liked';
$txt['notify_type_mentionmem'] = 'Notify when you are @mentioned';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Notify when someone adds you as buddy';
$txt['notify_type_quotedmem'] = 'Notify when someone quotes one of your messages';
$txt['notify_type_mailfail'] = 'Notify when email notifications are disabled (mention only)';

$txt['notifications_topics'] = '当前话题通知';
$txt['notifications_topics_none'] = '您目前没有收到任何话题的通知。';
$txt['notifications_topics_howto'] = 'To receive notifications from a specific topic, click the &quot;Notify&quot; button while viewing it.';

$txt['notifications_boards'] = '当前版块的通知';
$txt['notifications_boards_none'] = '您现在没有收到任何版块的通知。';
$txt['notifications_boards_howto'] = 'To request notifications from a specific board, either click the &quot;Notify&quot; button in the index of that board <strong>or</strong> use the checkboxes below to enable select board notifications.';
$txt['notifications_boards_current'] = 'You are receiving notifications on the boards shown in <strong>BOLD</strong>.  Use the checkboxes to turn these off or add additional boards to your notification list';
$txt['notifications_boards_update'] = '升级';
$txt['notifications_update'] = '不通知';

$txt['statPanel_showStats'] = '用户统计信息：';
$txt['statPanel_users_votes'] = '投票数量';
$txt['statPanel_users_polls'] = '创建的投票数量';
$txt['statPanel_total_time_online'] = '在线总时间';
$txt['statPanel_noPosts'] = 'No posts to speak of!';
$txt['statPanel_generalStats'] = '一般数据';
$txt['statPanel_posts'] = '帖子';
$txt['statPanel_topics'] = '话题';
$txt['statPanel_total_posts'] = '全部帖子';
$txt['statPanel_total_topics'] = 'Total Topics Started';
$txt['statPanel_votes'] = '票数';
$txt['statPanel_polls'] = '投票';
$txt['statPanel_topBoards'] = '最热门的版块话题';
$txt['statPanel_topBoards_posts'] = '%1$d posts of the board\'s %2$d posts (%3$01.2f%%)';
$txt['statPanel_topBoards_memberposts'] = '%1$d posts of the member\'s %2$d posts (%3$01.2f%%)';
$txt['statPanel_topBoardsActivity'] = 'Most Popular Boards By Activity';
$txt['statPanel_activityTime'] = 'Posting Activity By Time';
$txt['statPanel_activityTime_posts'] = '%1$d posts (%2$d%%)';

$txt['deleteAccount_warning'] = '注意 - 此操作不可逆转！';
$txt['deleteAccount_desc'] = 'From this page you can delete this user\'s account and posts.';
$txt['deleteAccount_member'] = '删除此会员的帐号';
$txt['deleteAccount_posts'] = '删除此成员发布的帖子';
$txt['deleteAccount_none'] = 'None';
$txt['deleteAccount_all_posts'] = 'Replies Only';
$txt['deleteAccount_topics'] = '话题和回复';
$txt['deleteAccount_confirm'] = '您确定要删除此帐户吗？';
$txt['deleteAccount_approval'] = 'Please note that the forum moderators will have to approve this account\'s deletion before it will be removed.';

$txt['profile_of_username'] = 'Profile of %1$s';
$txt['profileInfo'] = '资料信息';
$txt['showPosts'] = '显示帖子';
$txt['showPosts_help'] = 'This section allows you to view all posts made by this member. Note that you can only see posts made in areas you currently have access to.';
$txt['showMessages'] = '信息';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = '主题';
$txt['showUnwatched'] = 'Unwatched topics';
$txt['showAttachments'] = '附件';
$txt['viewWarning_help'] = 'This section allows you to view all warnings issued to this member.';
$txt['statPanel'] = '显示统计数据';
$txt['editBuddyIgnoreLists'] = 'Buddies/Ignore List';
$txt['editBuddies'] = '编辑好友';
$txt['editIgnoreList'] = '编辑忽略列表';
$txt['trackUser'] = '追踪用户';
$txt['trackActivity'] = '活动';
$txt['trackIP'] = 'IP地址';
$txt['trackLogins'] = '登录';

$txt['likes_show'] = 'Show Likes';
$txt['likes_given'] = 'Posts you liked';
$txt['likes_profile_received'] = 'received';
$txt['likes_profile_given'] = 'given';
$txt['likes_received'] = 'Your posts liked by others';
$txt['likes_none_given'] = 'You have not liked any posts';
$txt['likes_none_received'] = 'No one has liked any of your posts :\'(';
$txt['likes_confirm_delete'] = 'Remove this like?';
$txt['likes_show_who'] = 'Show the members that liked this post';
$txt['likes_by'] = 'Liked by';
$txt['likes_delete'] = '删除';

$txt['authentication'] = 'Authentication';
$txt['change_authentication'] = 'From this section you can change how you login to the forum. You may choose to either use an OpenID account for your authentication, or alternatively switch to use a username and password.';

$txt['profileEdit'] = '修改简介';
$txt['account_info'] = 'These are your account settings. This page holds all critical information that identifies you on this forum. For security reasons, you will need to enter your (current) password to make changes to this information.';
$txt['forumProfile_info'] = 'You can change your personal information on this page. This information will be displayed throughout {forum_name_html_safe}. If you aren\'t comfortable with sharing some information, simply skip it - nothing here is required.';
$txt['theme_info'] = '此部分允许您自定义论坛的外观和布局。';
$txt['notification_info'] = 'This allows you to be notified of replies to posts, newly posted topics, and forum announcements. You can change those settings here, or oversee the topics and boards you are currently receiving notifications for.';
$txt['groupmembership'] = 'Group Membership';
$txt['groupMembership_info'] = 'In this section of your profile you can change which groups you belong to.';
$txt['ignoreboards'] = '忽略版块选项';
$txt['ignoreboards_info'] = 'This page lets you ignore particular boards.  When a board is ignored, the new post indicator will not show up on the board index.  New posts will not show up using the "unread post" search link (when searching it will not look in those boards). However, ignored boards will still appear on the board index and upon entering will show which topics have new posts.  When using the "unread replies" link, new posts in an ignored board will still be shown.';
$txt['contactprefs'] = 'Messaging';

$txt['profileAction'] = '操作';
$txt['deleteAccount'] = '删除此帐户';
$txt['profileSendIm'] = 'Send personal message';
$txt['profile_sendpm_short'] = 'Send PM';

$txt['profileBanUser'] = 'Ban this user';

$txt['display_name'] = '显示名称';
$txt['enter_ip'] = 'Enter IP (range)';
$txt['errors_by'] = 'Error messages by';
$txt['errors_desc'] = 'Below is a list of all the recent errors that this user has generated/experienced.';
$txt['errors_from_ip'] = 'Error messages from IP (range)';
$txt['errors_from_ip_desc'] = 'Below is a list of all recent error messages generated by this IP (range).';
$txt['ip_address'] = 'IP地址';
$txt['ips_in_errors'] = 'IPs used in error messages';
$txt['ips_in_messages'] = 'IPs used in recent posts';
$txt['members_from_ip'] = 'Members from IP (range)';
$txt['members_in_range'] = 'Members possibly in the same range';
$txt['messages_from_ip'] = 'Messages posted from IP (range)';
$txt['messages_from_ip_desc'] = 'Below is a list of all messages posted from this IP (range).';
$txt['trackLogins_desc'] = 'Below is a list of all times this account was logged into.';
$txt['most_recent_ip'] = 'Most recent IP address';
$txt['why_two_ip_address'] = 'Why are there two IP addresses listed?';
$txt['no_errors_from_ip'] = 'No error messages from the specified IP (range) found';
$txt['no_errors_from_user'] = 'No error messages from the specified user found';
$txt['no_members_from_ip'] = 'No members from the specified IP (range) found';
$txt['no_messages_from_ip'] = 'No messages from the specified IP (range) found';
$txt['trackLogins_none_found'] = 'No recent logins were found';
$txt['none'] = 'None';
$txt['own_profile_confirm'] = 'Are you sure you want to delete your account?';
$txt['view_ips_by'] = 'View IPs used by';

$txt['avatar_will_upload'] = '上传头像';

$txt['activate_changed_email_title'] = 'Email Address Changed';
$txt['activate_changed_email_desc'] = 'You\'ve changed your email address. In order to validate this address you will receive an email. Click the link in that email to reactivate your account.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Unable to send reminder email.';
$txt['send_email'] = 'Send an email to';
$txt['to_ask_password'] = 'to ask for your authentication details';

$txt['user_email'] = 'Username/Email';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'A mail has been sent to your email address. Click the link in that mail to set a new password.';
$txt['reminder_openid_sent'] = 'Your current OpenID identity has been sent to your email address.';
$txt['reminder_set_password'] = '设置密码';
$txt['reminder_password_set'] = '密码成功设置';
$txt['reminder_error'] = '%1$s failed to answer their secret question correctly when attempting to change a forgotten password.';

$txt['registration_not_approved'] = '抱歉，此帐户尚未获得批准。如果您需要更改电子邮件地址，请单击';
$txt['registration_not_activated'] = '抱歉，此帐号尚未激活。如果您需要重新发送激活电子邮件，请单击';

$txt['primary_membergroup'] = '主要会员组';
$txt['additional_membergroups'] = 'Additional Membergroups';
$txt['additional_membergroups_show'] = 'Show additional groups';
$txt['no_primary_membergroup'] = '(no primary membergroup)';
$txt['deadmin_confirm'] = 'Are you sure you wish to irrevocably remove your admin status?';

$txt['account_activate_method_2'] = 'Account requires reactivation after email change';
$txt['account_activate_method_3'] = 'Account is not approved';
$txt['account_activate_method_4'] = 'Account is awaiting approval for deletion';
$txt['account_activate_method_5'] = 'Account is an &quot;under age&quot; account awaiting approval';
$txt['account_not_activated'] = 'Account is currently not activated';
$txt['account_activate'] = 'activate';
$txt['account_approve'] = 'approve';
$txt['user_is_banned'] = 'User is currently banned';
$txt['view_ban'] = '浏览';
$txt['user_banned_by_following'] = 'This user is currently affected by the following bans';
$txt['user_cannot_due_to'] = 'User cannot %1$s as a result of ban: &quot;%2$s&quot;';
$txt['ban_type_post'] = 'post';
$txt['ban_type_register'] = '注册';
$txt['ban_type_login'] = '登录';
$txt['ban_type_access'] = '访问论坛';

$txt['show_online'] = '向别人展示我的在线状态';

$txt['return_to_post'] = '默认情况下发布后返回话题。';
$txt['no_new_reply_warning'] = '不要在发布时发出新的回复提醒。';
$txt['recent_pms_at_top'] = 'Show most recent personal messages at top.';
$txt['wysiwyg_default'] = 'Show WYSIWYG editor on post page by default.';

$txt['timeformat_default'] = '(论坛默认)';
$txt['timeformat_easy1'] = 'Month Day, Year, HH:MM:SS am/pm';
$txt['timeformat_easy2'] = 'Month Day, Year, HH:MM:SS (24 hour)';
$txt['timeformat_easy3'] = 'YYYY-MM-DD, HH:MM:SS';
$txt['timeformat_easy4'] = 'DD Month YYYY, HH:MM:SS';
$txt['timeformat_easy5'] = 'DD-MM-YYYY, HH:MM:SS';

$txt['poster'] = 'Poster';

$txt['use_sidebar_menu'] = 'Use sidebar menu instead of dropdowns.';
$txt['use_click_menu'] = 'Use click to open menus, instead of hover to open.';
$txt['show_no_avatars'] = 'Don\'t show users\' avatars.';
$txt['show_no_signatures'] = 'Don\'t show users\' signatures.';
$txt['show_no_censored'] = 'Leave words uncensored.';
$txt['topics_per_page'] = 'Topics to display per page:';
$txt['messages_per_page'] = 'Messages to display per page:';
$txt['hide_poster_area'] = 'Hide the poster information area.';
$txt['per_page_default'] = '论坛默认';
$txt['calendar_start_day'] = 'First day of the week on the calendar:';
$txt['display_quick_reply'] = 'Use quick reply on topic display: ';
$txt['use_editor_quick_reply'] = 'Use full editor in Quick Reply.';
$txt['display_quick_mod'] = 'Show quick-moderation as:';
$txt['display_quick_mod_none'] = 'don\'t show.';
$txt['display_quick_mod_check'] = 'checkboxes.';
$txt['display_quick_mod_image'] = 'icons.';

$txt['whois_title'] = 'Look up IP on a regional whois-server';
$txt['whois_afrinic'] = 'AfriNIC (Africa)';
$txt['whois_apnic'] = 'APNIC (Asia Pacific region)';
$txt['whois_arin'] = 'ARIN (North America, a portion of the Caribbean and sub-Saharan Africa)';
$txt['whois_lacnic'] = 'LACNIC (Latin American and Caribbean region)';
$txt['whois_ripe'] = 'RIPE (Europe, the Middle East and parts of Africa and Asia)';

$txt['moderator_why_missing'] = 'why isn\'t moderator here?';
$txt['username_change'] = 'change';
$txt['username_warning'] = 'To change this member\'s username, the forum must also reset their password, which will be emailed to the member with their new username.';

$txt['show_member_posts'] = '查看会员帖子';
$txt['show_member_topics'] = '查看会员话题';
$txt['show_member_attachments'] = '查看会员附件';
$txt['show_posts_none'] = '还没有帖子发布。';
$txt['show_topics_none'] = 'No topics have been posted yet.';
$txt['unwatched_topics_none'] = 'You don\'t have any topic in the unwatch list.';
$txt['show_attachments_none'] = 'No attachments have been posted yet.';
$txt['show_attach_filename'] = '文件名';
$txt['show_attach_downloads'] = '下载';
$txt['show_attach_posted'] = '发布';

$txt['showPermissions'] = '显示权限';
$txt['showPermissions_status'] = 'Permission status';
$txt['showPermissions_help'] = 'This section allows you to view all permissions for this member (denied permissions are <del>struck out</del>).';
$txt['showPermissions_given'] = 'Given by';
$txt['showPermissions_denied'] = 'Denied by';
$txt['showPermissions_permission'] = 'Permission (denied permissions are shown <del>struck through</del>)';
$txt['showPermissions_none_general'] = 'This member has no general permissions set.';
$txt['showPermissions_none_board'] = 'This member has no board specific permissions set.';
$txt['showPermissions_all'] = 'As an administrator, this member has all possible permissions.';
$txt['showPermissions_select'] = 'Board specific permissions for';
$txt['showPermissions_general'] = '常规权限';
$txt['showPermissions_global'] = '所有版块';
$txt['showPermissions_restricted_boards'] = 'Restricted boards';
$txt['showPermissions_restricted_boards_desc'] = 'The following boards are not accessible by this user';

$txt['local_time'] = '当地时间';
$txt['posts_per_day'] = 'per day';

$txt['buddy_ignore_desc'] = 'This area allows you to maintain your buddy and ignore lists for this forum. Adding members to these lists will, amongst other things, help control mail and PM traffic, depending on your preferences.';

$txt['buddy_add'] = '添加到好友列表';
$txt['buddy_remove'] = '从好友列表中删除';
$txt['buddy_add_button'] = '添加';
$txt['no_buddies'] = '你的好友列表目前是空的';

$txt['ignore_add'] = '添加到忽略列表';
$txt['ignore_remove'] = '从忽略列表中移除';
$txt['ignore_add_button'] = '添加';
$txt['no_ignore'] = '您的忽略列表目前为空';

$txt['regular_members'] = '已注册的会员';
$txt['regular_members_desc'] = '论坛的每个成员都是该组的成员。';
$txt['group_membership_msg_free'] = '您的群组成员资格已成功更新。';
$txt['group_membership_msg_request'] = '您的请求已提交，请耐心等待。';
$txt['group_membership_msg_primary'] = '您的主要群组已更新';
$txt['current_membergroups'] = '当前成员组';
$txt['available_groups'] = 'Available Groups';
$txt['join_group'] = '加入组织';
$txt['leave_group'] = '离开组织';
$txt['request_group'] = '申请会员资格';
$txt['approval_pending'] = '等待批准';
$txt['make_primary'] = 'Make Primary Group';

$txt['request_group_membership'] = 'Request Group Membership';
$txt['request_group_membership_desc'] = '在您加入此论坛之前，您的会员资格必须得到版主的批准。请说明加入这个小组的原因';
$txt['submit_request'] = '提交请求';

$txt['profile_updated_own'] = '您的个人资料已成功更新。';
$txt['profile_updated_else'] = 'The profile for <strong>%1$s</strong> has been updated successfully.';

$txt['profile_error_signature_max_length'] = 'Your signature cannot be greater than %1$d characters';
$txt['profile_error_signature_max_lines'] = 'Your signature cannot span more than %1$d lines';
$txt['profile_error_signature_max_image_size'] = 'Images in your signature must be no greater than %1$dx%2$d pixels';
$txt['profile_error_signature_max_image_width'] = 'Images in your signature must be no wider than %1$d pixels';
$txt['profile_error_signature_max_image_height'] = 'Images in your signature must be no higher than %1$d pixels';
$txt['profile_error_signature_max_image_count'] = 'You cannot have more than %1$d images in your signature';
$txt['profile_error_signature_max_font_size'] = 'Text in your signature must be smaller than %1$s in size';
$txt['profile_error_signature_allow_smileys'] = '您不得在签名中使用任何表情';
$txt['profile_error_signature_max_smileys'] = 'You are not allowed to use more than %1$d smileys within your signature';
$txt['profile_error_signature_disabled_bbc'] = 'The following BBC is not allowed within your signature: %1$s';

$txt['profile_view_warnings'] = 'View Warnings';
$txt['profile_issue_warning'] = 'Issue a Warning';
$txt['profile_warning_level'] = 'Warning Level';
$txt['profile_warning_desc'] = 'From this section you can adjust the user\'s warning level and issue them with a written warning if necessary. You can also track their warning history and view the effects of their current warning level as determined by the administrator.';
$txt['profile_warning_name'] = 'Member Name';
$txt['profile_warning_impact'] = 'Result';
$txt['profile_warning_reason'] = 'Reason for Warning';
$txt['profile_warning_reason_desc'] = 'This is required and will be logged.';
$txt['profile_warning_effect_none'] = 'None.';
$txt['profile_warning_effect_watch'] = 'User will be added to moderator watch list.';
$txt['profile_warning_effect_own_watched'] = 'You are on the moderator watch list.';
$txt['profile_warning_is_watch'] = 'being watched';
$txt['profile_warning_effect_moderate'] = 'All users posts will be moderated.';
$txt['profile_warning_effect_own_moderated'] = 'All your posts will be moderated.';
$txt['profile_warning_is_moderation'] = 'posts are moderated';
$txt['profile_warning_effect_mute'] = 'User will not be able to post.';
$txt['profile_warning_effect_own_muted'] = 'You will not be able to post.';
$txt['profile_warning_is_muted'] = 'cannot post';
$txt['profile_warning_effect_text'] = 'Level >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Send a Notification';
$txt['profile_warning_notify_template'] = 'Select template:';
$txt['profile_warning_notify_subject'] = 'Notification Subject';
$txt['profile_warning_notify_body'] = 'Notification Message';
$txt['profile_warning_notify_template_subject'] = 'You have received a warning';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},

You have received a warning for %1$s. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},

You have received a warning for %1$s in regards to the message:
{MESSAGE}.

Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'spamming';
$txt['profile_warning_notify_title_spamming'] = 'Spamming';
$txt['profile_warning_notify_for_offence'] = 'posting offensive material';
$txt['profile_warning_notify_title_offence'] = 'Posting Offensive Material';
$txt['profile_warning_notify_for_insulting'] = 'insulting other users and/or staff members';
$txt['profile_warning_notify_title_insulting'] = 'Insulting Users/Staff';
$txt['profile_warning_issue'] = 'Issue Warning';
$txt['profile_warning_max'] = '(Max 100)';
$txt['profile_warning_limit_attribute'] = 'Note you can not adjust this user\'s level by more than %1$d%% in a 24 hour period.';
$txt['profile_warning_errors_occurred'] = 'Warning has not been sent due to following errors';
$txt['profile_warning_success'] = 'Warning Successfully Issued';
$txt['profile_warning_new_template'] = 'New Template';

$txt['profile_warning_previous'] = 'Previous Warnings';
$txt['profile_warning_previous_none'] = 'This user has not received any previous warnings.';
$txt['profile_warning_previous_issued'] = 'Issued By';
$txt['profile_warning_previous_time'] = '时间';
$txt['profile_warning_previous_level'] = 'Points';
$txt['profile_warning_previous_reason'] = '原因';
$txt['profile_warning_previous_notice'] = 'View Notice Sent to Member';

$txt['viewwarning'] = 'View Warnings';
$txt['profile_viewwarning_for_user'] = 'Warnings for %1$s';
$txt['profile_viewwarning_no_warnings'] = 'No warnings have been issued.';
$txt['profile_viewwarning_desc'] = 'Below is a summary of all the warnings that have been issued by the forum moderation team.';
$txt['profile_viewwarning_previous_warnings'] = 'Previous Warnings';
$txt['profile_viewwarning_impact'] = 'Warning Impact';

$txt['subscriptions'] = '付费订阅';

$txt['pm_settings_desc'] = 'From this page you can change a variety of personal messaging options, including how messages are displayed and who may send them to you.';
$txt['email_notify'] = 'Notify by email every time you receive a personal message:';
$txt['email_notify_never'] = '从不';
$txt['email_notify_buddies'] = 'From Buddies Only';
$txt['email_notify_always'] = '总是';

$txt['receive_from'] = 'Members allowed to contact me:';
$txt['receive_from_everyone'] = '所有成员';
$txt['receive_from_ignore'] = '所有成员，除了忽略列表中的成员';
$txt['receive_from_admins'] = '仅限管理员';
$txt['receive_from_buddies'] = 'Buddies and Administrators only';
$txt['receive_from_description'] = 'This setting applies to both Personal Messages and emails (if the option to email members is enabled)';

$txt['popup_messages'] = 'Show a popup when I receive new messages.';
$txt['pm_remove_inbox_label'] = 'Remove the inbox label when applying another label.';
$txt['pm_display_mode'] = 'Display personal messages';
$txt['pm_display_mode_all'] = 'All at once';
$txt['pm_display_mode_one'] = 'One at a time';
$txt['pm_display_mode_linked'] = 'As a conversation';

$txt['history'] = '历史';
$txt['history_description'] = 'This section allows you to review certain profile actions performed on this member\'s profile as well as track their IP address and login history.';

$txt['trackEdits'] = '编辑简介';
$txt['trackEdit_deleted_member'] = '删除成员';
$txt['trackEdit_no_edits'] = 'No edits have so far been recorded for this member.';
$txt['trackEdit_action'] = 'Field';
$txt['trackEdit_before'] = 'Value Before';
$txt['trackEdit_after'] = 'Value After';
$txt['trackEdit_applicator'] = 'Changed By';

$txt['trackEdit_action_real_name'] = 'Member Name';
$txt['trackEdit_action_usertitle'] = '自定义标题';
$txt['trackEdit_action_member_name'] = '用户名';
$txt['trackEdit_action_email_address'] = '邮箱地址';
$txt['trackEdit_action_id_group'] = '主要会员组';
$txt['trackEdit_action_additional_groups'] = 'Additional Membergroups';

$txt['otp_enabled_help'] = '启用此项将添加第二个因素（一次性密码）进行身份验证。';
$txt['otp_token_help'] = '这会生成基于时间的一次性密码应用的秘密令牌，此类常见应用有Authy和Google身份验证器。生成令牌后，您可以使用您最喜欢的身份验证器应用来扫描二维码。<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
