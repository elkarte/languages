<?php
// Version: 1.1; Reports

$txt['generate_reports_desc'] = '在这里可以生成各种报告，以帮助你管理论坛。只需按照下面的步骤来选择你所需要的选项。';
$txt['generate_reports_continue'] = '继续';
$txt['generate_reports_type'] = '选择报告类型';
$txt['gr_type_boards'] = '版块';
$txt['gr_type_desc_boards'] = '报告显示论坛上每个版块的当前设置和访问级别。';
$txt['gr_type_board_perms'] = '版主权限';
$txt['gr_type_desc_board_perms'] = 'Generate reports showing permissions each membergroup has across the different boards in your forum.';
$txt['gr_type_member_groups'] = '会员组';
$txt['gr_type_desc_member_groups'] = '报告显示论坛上每个成员组的设置。';
$txt['gr_type_group_perms'] = '组权限';
$txt['gr_type_desc_group_perms'] = '每个会员组在论坛的权限报告。';
$txt['gr_type_staff'] = 'Staff';
$txt['gr_type_desc_staff'] = '该报告总结了目前论坛上有权限的所有成员。';

$txt['full_member'] = 'Full Member';
$txt['results'] = '结果';

// Board permissions
$txt['board_perms_permission'] = 'Permission';
$txt['board_perms_allow'] = '允许';
$txt['board_perms_deny'] = '拒绝';
$txt['board_perms_name_announce_topic'] = 'Announce topic';
$txt['board_perms_name_approve_posts'] = 'Approve posts';
$txt['board_perms_name_delete_any'] = 'Delete any posts';
$txt['board_perms_name_delete_own'] = '删除自己的帖子';
$txt['board_perms_name_delete_replies'] = '删除自己的主题回复';
$txt['board_perms_name_lock_any'] = '锁定任何话题';
$txt['board_perms_name_lock_own'] = '锁定自己的主题';
$txt['board_perms_name_make_sticky'] = '置顶话题';
$txt['board_perms_name_mark_any_notify'] = '请求所有话题的通知';
$txt['board_perms_name_mark_notify'] = '请求自己的话题的通知';
$txt['board_perms_name_merge_any'] = '合并话题';
$txt['board_perms_name_moderate_board'] = 'Moderate the board';
$txt['board_perms_name_modify_any'] = 'Modify any post';
$txt['board_perms_name_modify_own'] = 'Modify own posts';
$txt['board_perms_name_modify_replies'] = 'Modify replies to own topics';
$txt['board_perms_name_move_any'] = '移动所有话题';
$txt['board_perms_name_move_own'] = '移动自己的话题';
$txt['board_perms_name_poll_add_any'] = 'Add poll to any topics';
$txt['board_perms_name_poll_add_own'] = '为自己的话题添加投票';
$txt['board_perms_name_poll_edit_any'] = '编辑任何调查';
$txt['board_perms_name_poll_edit_own'] = '编辑自己的投票';
$txt['board_perms_name_poll_lock_any'] = 'Lock any poll';
$txt['board_perms_name_poll_lock_own'] = 'Lock own polls';
$txt['board_perms_name_poll_post'] = 'Post new poll';
$txt['board_perms_name_poll_remove_any'] = 'Remove any poll';
$txt['board_perms_name_poll_remove_own'] = 'Remove own polls';
$txt['board_perms_name_poll_view'] = '查看投票';
$txt['board_perms_name_poll_vote'] = 'Vote in polls';
$txt['board_perms_name_post_attachment'] = '上传附件';
$txt['board_perms_name_post_new'] = '发布新话题';
$txt['board_perms_name_post_reply_any'] = '任何话题的帖子回复';
$txt['board_perms_name_post_reply_own'] = '在自己的话题中回复';
$txt['board_perms_name_post_unapproved_attachments'] = '发布未审核的附件';
$txt['board_perms_name_post_unapproved_topics'] = '发布未审核的话题';
$txt['board_perms_name_post_unapproved_replies_any'] = '在任何主题发布未经审核的回复';
$txt['board_perms_name_post_unapproved_replies_own'] = 'Post unapproved replies in own topic';
$txt['board_perms_name_remove_any'] = '删除任何话题';
$txt['board_perms_name_remove_own'] = '删除自己的话题';
$txt['board_perms_name_report_any'] = '举报任何帖子';
$txt['board_perms_name_send_topic'] = '给朋友发送话题';
$txt['board_perms_name_split_any'] = '拆分任何话题';
$txt['board_perms_name_view_attachments'] = '查看附件';

$txt['board_perms_group_no_polls'] = '此版块不允许投票';
$txt['board_perms_group_reply_only'] = 'This board only allows users to make replies to topics';
$txt['board_perms_group_read_only'] = '此版块不允许发布';

// Membergroup info!
$txt['member_group_color'] = 'Color';
$txt['member_group_min_posts'] = 'Minimum Posts';
$txt['member_group_max_messages'] = 'Max Personal Messages';
$txt['member_group_icons'] = 'Icons';
$txt['member_group_settings'] = '设置';
$txt['member_group_access'] = 'Board Access';

// Board info.
$txt['none'] = 'None';
$txt['board_category'] = '类别';
$txt['board_parent'] = '父版块';
$txt['board_num_topics'] = '话题数量';
$txt['board_num_posts'] = '帖子数量';
$txt['board_count_posts'] = 'Count Posts';
$txt['board_theme'] = '版块主题';
$txt['board_override_theme'] = 'Force Board Theme';
$txt['board_profile'] = 'Permissions Profile';
$txt['board_moderators'] = '版主';
$txt['board_groups'] = 'Groups with Access';
$txt['board_disallowed_groups'] = 'Groups with Access Denied';

// Group Permissions.
$txt['group_perms_name_access_mod_center'] = 'Access Moderation Center';
$txt['group_perms_name_admin_forum'] = '管理论坛';
$txt['group_perms_name_calendar_edit_any'] = '编辑任何活动';
$txt['group_perms_name_calendar_edit_own'] = '编辑自己的活动';
$txt['group_perms_name_calendar_post'] = '发布活动';
$txt['group_perms_name_calendar_view'] = '查看活动';
$txt['group_perms_name_edit_news'] = '编辑论坛新闻';
$txt['group_perms_name_issue_warning'] = 'Issue warnings';
$txt['group_perms_name_karma_edit'] = 'Edit user karma';
$txt['group_perms_name_manage_attachments'] = '管理附件';
$txt['group_perms_name_manage_bans'] = 'Manage bans';
$txt['group_perms_name_manage_boards'] = 'Manage boards';
$txt['group_perms_name_manage_membergroups'] = 'Manage member groups';
$txt['group_perms_name_manage_permissions'] = 'Manage permissions';
$txt['group_perms_name_manage_smileys'] = 'Manage smileys and message icons';
$txt['group_perms_name_moderate_forum'] = '管理该论坛';
$txt['group_perms_name_pm_read'] = '查看个人信息';
$txt['group_perms_name_pm_send'] = '发私信';
$txt['group_perms_name_profile_extra_any'] = 'Edit any additional options';
$txt['group_perms_name_profile_extra_own'] = 'Edit own additional options';
$txt['group_perms_name_profile_identity_any'] = 'Edit any account settings';
$txt['group_perms_name_profile_identity_own'] = 'Edit own account settings';
$txt['group_perms_name_profile_set_avatar'] = 'Select an avatar';
$txt['group_perms_name_profile_remove_any'] = 'Delete any account';
$txt['group_perms_name_profile_remove_own'] = 'Delete own account';
$txt['group_perms_name_profile_title_any'] = 'Edit any custom title';
$txt['group_perms_name_profile_title_own'] = 'Edit own custom title';
$txt['group_perms_name_profile_view_any'] = 'View any profile';
$txt['group_perms_name_profile_view_own'] = 'View own profile';
$txt['group_perms_name_search_posts'] = 'Search for posts';
$txt['group_perms_name_send_mail'] = 'Send a forum email to members';
$txt['group_perms_name_view_mlist'] = 'View the member list';
$txt['group_perms_name_view_stats'] = 'View forum stats';
$txt['group_perms_name_who_view'] = 'See who\'s online';

$txt['report_error_too_many_staff'] = 'You have too many staff members. The report will not work with more than 300 staff members.';
$txt['report_staff_position'] = '会员组';
$txt['report_staff_moderates'] = 'Moderates';
$txt['report_staff_posts'] = '帖子';
$txt['report_staff_last_login'] = '上次登录';
$txt['report_staff_all_boards'] = '所有版块';
$txt['report_staff_no_boards'] = 'No boards';