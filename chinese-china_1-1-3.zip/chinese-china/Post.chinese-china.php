<?php
// Version: 1.1; Post

$txt['post_reply'] = '回复';
$txt['post_in_board'] = '发布到版块';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = '插入引用';
$txt['disable_smileys'] = '禁用表情';
$txt['dont_use_smileys'] = '不要使用表情符号。';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = '发表于';
$txt['standard'] = 'Standard';
$txt['thumbs_up'] = 'Thumb Up';
$txt['thumbs_down'] = 'Thumb Down';
$txt['exclamation_point'] = 'Exclamation point';
$txt['question_mark'] = '标记问题';
$txt['icon_poll'] = '投票';
$txt['lamp'] = 'Lamp';
$txt['add_smileys'] = '添加表情';
$txt['topic_notify_no'] = 'There are no topics with notification.';

$txt['rich_edit_wont_work'] = '您的浏览器不支持富文本编辑。';
$txt['rich_edit_function_disabled'] = '您的浏览器不支持此功能。';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = '点击取消订阅此话题';

$txt['lock_after_post'] = '发表后锁定';
$txt['notify_replies'] = '回复时通知我。';
$txt['lock_topic'] = '锁定这个话题。';
$txt['shortcuts'] = '快捷键：SHIFT + ALT+ S提交/发布 或 SHIFT + ALT+ P预览';
$txt['shortcuts_drafts'] = '快捷键：SHIFT + ALT+ S提交/发布，SHIFT + ALT+ P预览或Shift + Alt + D保存草稿';
$txt['option'] = '选项';
$txt['reset_votes'] = '复位计票';
$txt['reset_votes_check'] = '如果你想重置所有的投票数为0。';
$txt['votes'] = '票数';
$txt['attach'] = 'Attach';
$txt['clean_attach'] = '清除附件';
$txt['attached'] = 'Attached'; // @deprecated since 1.1
$txt['allowed_types'] = '允许文件类型';
$txt['cant_upload_type'] = '无法上载该文件类型。唯一允许的扩展是  %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Uncheck the attachments you no longer want attached'; // @deprecated since 1.1
$txt['restricted_filename'] = '此文件名受限制，请尝试不同的文件名。';
$txt['topic_locked_no_reply'] = '警告！此话题目前被锁定<br />只有管​​理员和版主可以回复。';
$txt['attachment_requires_approval'] = 'Note that any files attached will not be displayed until approved by a moderator.';
$txt['error_temp_attachments'] = 'There are attachments found, which you have attached before but not posted. These attachments are now attached to this post. If you do not want to include them in this post, <a href="#postAttachment">you can remove them here</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = '注意：此帖在版主批准之前不会显示。';

$txt['enter_comment'] = '输入评论';
// Use numeric entities in the below two strings.
$txt['reported_post'] = '举报';
$txt['reported_to_mod_by'] = 'by';
$txt['rtm10'] = '提交';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'The following post, "%1$s" by';
$txt['reported_by'] = 'has been reported by';
$txt['board_moderate'] = 'on a board you moderate';
$txt['report_comment'] = 'The reporter has made the following comment';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximum total size %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximum individual size %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d per post';
$txt['attach_restrictions'] = '限制：';

$txt['post_additionalopt_attach'] = '附件和其他选项';
$txt['post_additionalopt'] = '其他选项';
$txt['sticky_after'] = 'Pin this topic.';
$txt['move_after2'] = '移动此话题。';
$txt['back_to_topic'] = '返回主题。';
$txt['approve_this_post'] = '审核此帖';

$txt['retrieving_quote'] = 'Retrieving quote...';

$txt['post_visual_verification_label'] = '验证';
$txt['post_visual_verification_desc'] = 'Please enter the code in the image above to make this post.';

$txt['poll_options'] = '投票选项';
$txt['poll_run'] = 'Run the poll for';
$txt['poll_run_limit'] = '(Leave blank for no limit.)';
$txt['poll_results_visibility'] = 'Result visibility';
$txt['poll_results_anyone'] = 'Show the poll\'s results to anyone.';
$txt['poll_results_voted'] = 'Only show the results after someone has voted.';
$txt['poll_results_after'] = 'Only show the results after the poll has expired.';
$txt['poll_max_votes'] = 'Maximum votes per user';
$txt['poll_do_change_vote'] = 'Allow users to change vote';
$txt['poll_too_many_votes'] = 'You selected too many options.  For this poll, you may only select %1$s options.';
$txt['poll_add_option'] = '添加选项';
$txt['poll_guest_vote'] = '允许访客投票';

$txt['spellcheck_done'] = '拼写检查完成。';
$txt['spellcheck_change_to'] = 'Change To:';
$txt['spellcheck_suggest'] = '建议：';
$txt['spellcheck_change'] = '更改';
$txt['spellcheck_change_all'] = '全部更改';
$txt['spellcheck_ignore'] = '忽略';
$txt['spellcheck_ignore_all'] = '忽略所有';

$txt['more_attachments'] = '更多附件';
// Don't use entities in the below string.
$txt['more_attachments_error'] = '很抱歉，您不能再发布任何附件。';

$txt['more_smileys'] = '更多';
$txt['more_smileys_title'] = '其他表情';
$txt['more_smileys_pick'] = '选择一个笑脸';
$txt['more_smileys_close_window'] = '关闭窗口';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = '发送一个通知关于这个话题的成员:';
$txt['announce_title'] = 'Send an announcement';
$txt['announce_desc'] = 'This form allows you to send an announcement to the selected membergroups about this topic.';
$txt['announce_sending'] = 'Sending announcement of topic';
$txt['announce_done'] = 'done';
$txt['announce_continue'] = '继续';
$txt['announce_topic'] = 'Announce topic.';
$txt['announce_regular_members'] = '普通会员';

$txt['digest_subject_daily'] = 'Daily Digest';
$txt['digest_subject_weekly'] = 'Weekly Digest';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'The following topics were started';
$txt['digest_new_topics_line'] = '"%1$s" in the %2$s board';
$txt['digest_new_replies'] = 'Replies have been made in the following topics';
$txt['digest_new_replies_one'] = '1 reply in "%1$s"';
$txt['digest_new_replies_many'] = '%1$d replies in "%2$s"';
$txt['digest_mod_actions'] = 'The following moderation actions have taken place';
$txt['digest_mod_act_sticky'] = '"%1$s" was pinned';
$txt['digest_mod_act_lock'] = '"%1$s" was locked';
$txt['digest_mod_act_unlock'] = '"%1$s" was unlocked';
$txt['digest_mod_act_remove'] = '"%1$s" was removed';
$txt['digest_mod_act_move'] = '"%1$s" was moved';
$txt['digest_mod_act_merge'] = '"%1$s" was merged';
$txt['digest_mod_act_split'] = '"%1$s" was split';

$txt['attach_error_title'] = '上传附件时出错。';
$txt['attach_warning'] = 'There was a problem during the uploading of <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Sorry, you are out of attachment space. The total attachment size allowed per post is %1$s KB. Space remaining is %2$s KB.';
$txt['attach_folder_warning'] = '附件目录中无法找到,请通知管理员这个问题。';
$txt['attach_folder_admin_warning'] = 'The path to the attachments directory (%1$s) is incorrect. Please correct it in the attachment settings area of your admin panel.';
$txt['attach_limit_nag'] = 'You have reached the maximum number of attachments allowed per post.';
$txt['attach_no_upload'] = 'There was a problem and your attachments could not be uploaded';
$txt['attach_remaining'] = '%1$d remaining';
$txt['attach_available'] = '%1$s KB available';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'The file appears to be empty. Please contact your forum administrator if this continues to be a problem';
$txt['attached_files_in_session'] = '<em>The above underlined file(s) have been uploaded but will not be attached to this post until it is submitted.</em>';

$txt['attach_php_error'] = 'Due to an error, your attachment could not be uploaded. Please contact the forum administrator if this problem continues.';
$txt['php_upload_error_1'] = 'The uploaded file exceeds the upload_max_filesize directive in php.ini. Please contact your host if you are unable to correct this issue.';
$txt['php_upload_error_3'] = 'The uploaded file was only partially uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_4'] = 'No file was uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_6'] = 'Unable to save. Missing a temporary directory. Please contact your host if you are unable to correct this problem.';
$txt['php_upload_error_7'] = 'Failed to write file to disk. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_8'] = 'A PHP extension stopped the file upload. This is a PHP related error. Please contact your host if this problem continues.';
$txt['error_temp_attachments_new'] = 'There are attachments which you had previously attached but not posted. These attachments are still attached to this post. This post does need to be submitted before these attachments are either saved or removed. You <a href="#postAttachment">can do that here</a>';
$txt['error_temp_attachments_found'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not post until these are either removed or that post has been submitted.<br />Click <a href="%1$s">here to remove </a>those attachments. Or <a href="%2$s">here to return to that post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not upload any more attachments until these are removed or that post has been submitted.<br />Click <a href="%1$s">here to remove these attachments</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Those attachments have now been removed and you have been returned to the page you were previously on';
$txt['error_temp_attachments_flushed'] = 'Please note that any files which had been previously attached, but not posted, have now been removed.';
$txt['error_topic_already_announced'] = 'Please note that this topic has already been announced.';

$txt['cant_access_upload_path'] = 'Cannot access attachments upload path!';
$txt['file_too_big'] = 'Your file is too large. The maximum attachment size allowed is %1$s KB.';
$txt['attach_timeout'] = 'Your attachment couldn\'t be saved. This might happen because it took too long to upload or the file is bigger than the server will allow.<br /><br />Please consult your server administrator for more information.';
$txt['bad_attachment'] = 'Your attachment has failed security checks and cannot be uploaded. Please consult the forum administrator.';
$txt['ran_out_of_space'] = 'The upload directory is full. Please contact an administrator about this problem.';
$txt['attachments_no_write'] = 'The attachments upload directory is not writable.  Your attachment or avatar cannot be saved.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory.  Your attachment or avatar cannot be saved.';
$txt['attachments_limit_per_post'] = 'You may not upload more than %1$d attachments per post';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = '插入';
$txt['ila_opt_size'] = 'Size';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'None';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = '居中';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/