<?php
// Version: 1.1; Settings

$txt['theme_description'] = '默认ElkArte主题。<br /><br />作者：ElkArte贡献者';