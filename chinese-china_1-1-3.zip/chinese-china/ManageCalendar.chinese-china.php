<?php
// Version: 1.1; ManageCalendar

$txt['calendar_desc'] = '在这里你可以修改日程。';

// Calendar Settings
$txt['calendar_settings_desc'] = '在这你可以启用并设置日程。';
$txt['groups_calendar_view'] = '会员组允许查看日程表';
$txt['groups_calendar_post'] = '允许会员组创建活动';
$txt['groups_calendar_edit_own'] = '允许会员组编辑自己的活动';
$txt['groups_calendar_edit_any'] = '允许会员组编辑任何活动';
$txt['setting_cal_enabled'] = '启用日程';
$txt['setting_cal_daysaslink'] = 'Show days as links to \'Post Event\'';
$txt['setting_cal_days_for_index'] = 'Max days in advance on board index';
$txt['setting_cal_showholidays'] = '显示假期';
$txt['setting_cal_showbdays'] = '显示生日';
$txt['setting_cal_showevents'] = '显示活动';
$txt['setting_cal_export'] = 'Allow events to be exported in iCal format';
$txt['setting_cal_show_never'] = '从不';
$txt['setting_cal_show_cal'] = 'In calendar only';
$txt['setting_cal_show_index'] = 'On board index only';
$txt['setting_cal_show_all'] = 'On board index and calendar';
$txt['setting_cal_defaultboard'] = 'Default board to post events in';
$txt['setting_cal_allow_unlinked'] = 'Allow events not linked to posts';
$txt['setting_cal_minyear'] = 'Minimum year';
$txt['setting_cal_maxyear'] = 'Maximum year';
$txt['setting_cal_allowspan'] = 'Allow events to span multiple days';
$txt['setting_cal_maxspan'] = 'Max number of days an event can span';
$txt['setting_cal_showInTopic'] = '在话题展示里显示活动链接';

// Adding/Editing/Viewing Holidays
$txt['manage_holidays_desc'] = '在这里可以添加和删除论坛日程中的假日。';
$txt['current_holidays'] = 'Current Holidays';
$txt['holidays_title'] = 'Holiday';
$txt['holidays_title_label'] = '标题';
$txt['holidays_delete_confirm'] = 'Are you sure you wish to remove these holidays?';
$txt['holidays_add'] = 'Add new holiday';
$txt['holidays_edit'] = 'Edit existing holiday';
$txt['holidays_button_add'] = '添加';
$txt['holidays_button_edit'] = '编辑';
$txt['holidays_button_remove'] = '移除';
$txt['holidays_no_entries'] = 'There are currently no holidays configured.';
$txt['every_year'] = 'Every Year';