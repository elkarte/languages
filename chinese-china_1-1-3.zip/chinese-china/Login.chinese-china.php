<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = '注册协议';
$txt['registration_privacy_policy'] = '隐私政策';
$txt['agreement_agree'] = '我接受许可协议中的条款。';
$txt['agreement_no_agree'] = '我不接受协议的条款。';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = '我接受协议的条款，我至少 %1$d 岁。';
$txt['agreement_agree_coppa_below'] = '我接受协议的条款，我未超 %1$d 岁。';
$txt['agree_coppa_above'] = '我至少 %1$d 岁。';
$txt['agree_coppa_below'] = '我的年龄未超 %1$d 岁。';

// Registration form.
$txt['registration_form'] = '注册表';
$txt['error_too_quickly'] = '你的操作过频繁，请稍等片刻，再试一次。';
$txt['error_token_verification'] = '验证失败，请再试一次。';
$txt['need_username'] = '您需要填写用户名。';
$txt['no_password'] = '请输入密码。';
$txt['improper_password'] = '密码太长。';
$txt['incorrect_password'] = '密码错误';
$txt['openid_not_found'] = '未找到OpenID提供的标识符。';
$txt['maintain_mode'] = '维护模式';
$txt['registration_successful'] = '注册成功';
$txt['valid_email_needed'] = '请输入有效的邮箱地址，%1$s.';
$txt['required_info'] = '需要的信息';
$txt['additional_information'] = '附加信息';
$txt['warning'] = '警告！';
$txt['only_members_can_access'] = '只有注册会员才可以访问此内容。';
$txt['login_below'] = '请登陆';
$txt['login_below_or_register'] = '请登陆或 <a href="%1$s">注册账户</a> with %2$s.';
$txt['checkbox_agreement'] = '我接受注册协议';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = '密码安全最近已升级。<br />请再次输入您的密码。';

$txt['ban_register_prohibited'] = '对不起，您不能在这个论坛注册。';
$txt['under_age_registration_prohibited'] = '对不起， %1$d 岁以下的用户不允许在此论坛注册。';

$txt['activate_account'] = '账号激活';
$txt['activate_success'] = '您的帐户已成功激活，您可以前往论坛。';
$txt['activate_not_completed1'] = '您需要验证邮件地址，然后才能登录。';
$txt['activate_not_completed2'] = '需要激活其他电子邮件？';
$txt['activate_after_registration'] = '感谢您注册，您将很快收到一封电子邮件，其中包含激活您帐户的链接，如果没有收到电子邮件，请检查您邮箱的垃圾邮件文件夹。';
$txt['invalid_userid'] = '用户不存在';
$txt['invalid_activation_code'] = '无效的激活码';
$txt['invalid_activation_username'] = '用户名或电子邮件';
$txt['invalid_activation_new'] = '如果你的邮箱地址是错误的，请在这里填写新的并填写你的密码。';
$txt['invalid_activation_new_email'] = '新的邮箱地址';
$txt['invalid_activation_password'] = '旧密码';
$txt['invalid_activation_resend'] = '重新发送激活码';
$txt['invalid_activation_known'] = '请在此输入激活码。';
$txt['invalid_activation_retry'] = '激活码';
$txt['invalid_activation_submit'] = '激活';

$txt['coppa_no_concent'] = '管理员未收到家长/监护人同意注册您帐户的信息。';
$txt['coppa_need_more_details'] = '需要更多资料？';

$txt['awaiting_delete_account'] = '您的账户已被删除！<br />如果你想恢复账户，请检查 &quot;激活我的账户&quot; box,并登录。';
$txt['undelete_account'] = '重新启用帐户';

$txt['in_maintain_mode'] = '该板块处于维护模式。';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = '注册前请阅读并接受协议。';
$txt['register_passwords_differ_js'] = '密码输入不一样！';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = '感谢您的注册。您的申请正在审核，审核通过前您还不能登陆论坛，结果将发送到您的邮箱。';

$txt['admin_settings_desc'] = '在这里你可以改变新成员注册的相关设置。';

$txt['setting_enableOpenID'] = '允许用户使用OpenID注册';

$txt['setting_registration_method'] = '会员注册方式';
$txt['setting_registration_disabled'] = '注册禁用';
$txt['setting_registration_standard'] = '立即注册';
$txt['setting_registration_activate'] = '邮箱激活';
$txt['setting_registration_approval'] = '管理员审核';
$txt['setting_notify_new_registration'] = '有新会员注册时通知管理员';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = '发送欢迎电子邮件给新会员';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = '低于申请注册限制年龄';
$txt['setting_coppaAge_desc'] = '(Set to 0 to disable)';
$txt['setting_coppaType'] = '当用户注册年龄低于最低标准时采取限制';
$txt['setting_coppaType_reject'] = '拒绝其注册';
$txt['setting_coppaType_approval'] = '要求家长/监护人同意';
$txt['setting_coppaPost'] = 'Postal address to which approval forms should be sent';
$txt['setting_coppaPost_desc'] = 'Only applies if age restriction is in place';
$txt['setting_coppaFax'] = 'Fax number to which approval forms should be faxed';
$txt['setting_coppaPhone'] = 'Contact number for parents to contact with age restriction queries';

$txt['admin_register'] = '注册新会员';
$txt['admin_register_desc'] = 'From here you can register new members into the forum, and if desired, email them their details.';
$txt['admin_register_username'] = '新的用户名';
$txt['admin_register_email'] = '邮箱地址';
$txt['admin_register_password'] = '密码';
$txt['admin_register_username_desc'] = '新会员的用户名';
$txt['admin_register_email_desc'] = '该会员的邮箱地址';
$txt['admin_register_password_desc'] = '新会员的密码';
$txt['admin_register_email_detail'] = '将新密码通过邮件发送给用户';
$txt['admin_register_email_detail_desc'] = 'Email address required even if unchecked';
$txt['admin_register_email_activate'] = '要求用户激活帐号';
$txt['admin_register_group'] = '主要会员组';
$txt['admin_register_group_desc'] = 'Primary membergroup new member will belong to';
$txt['admin_register_group_none'] = '(no primary membergroup)';
$txt['admin_register_done'] = '会员 %1$s 已经注册成功！';

$txt['coppa_title'] = '限制年龄的论坛';
$txt['coppa_after_registration'] = 'Thank you for registering with {forum_name_html_safe}.<br /><br />Because you fall under the age of {MINIMUM_AGE}, it is a legal requirement to obtain your parent or guardian\'s permission before you may begin to use your account.  To arrange for account activation please print off the form below:';
$txt['coppa_form_link_popup'] = '新窗口打开';
$txt['coppa_form_link_download'] = '下载文本文件';
$txt['coppa_send_to_one_option'] = 'Then arrange for your parent/guardian to send the completed form by:';
$txt['coppa_send_to_two_options'] = '然后安排你的父母/监护人发送完成的表格：';
$txt['coppa_send_by_post'] = '发送到以下地址：';
$txt['coppa_send_by_fax'] = '传真至以下号码：';
$txt['coppa_send_by_phone'] = '另外，安排他们致电管理员 {PHONE_NUMBER}。';

$txt['coppa_form_title'] = 'Permission form for registration at {forum_name_html_safe}';
$txt['coppa_form_address'] = '地址';
$txt['coppa_form_date'] = '日期';
$txt['coppa_form_body'] = 'I {PARENT_NAME},<br /><br />give permission for {CHILD_NAME} (child name) to become a fully registered member of the forum: {forum_name_html_safe}, with the username: {USER_NAME}.<br /><br />I understand that certain personal information entered by {USER_NAME} may be shown to other users of the forum.<br /><br />Signed:<br />{PARENT_NAME} (Parent/Guardian).';

$txt['visual_verification_sound_again'] = '重播';
$txt['visual_verification_sound_close'] = '关闭窗口';
$txt['visual_verification_sound_direct'] = 'Having problems hearing this?  Try a direct link to it.';

// Use numeric entities in the below.
$txt['registration_username_available'] = '用户名可用';
$txt['registration_username_unavailable'] = '用户名不可用';
$txt['registration_username_check'] = '检查用户名';
$txt['registration_password_short'] = '密码太短';
$txt['registration_password_reserved'] = '密码不能是用户名/电子邮件';
$txt['registration_password_numbercase'] = '密码必须包含大写、小写和数字';
$txt['registration_password_no_match'] = '密码错误';
$txt['registration_password_valid'] = '密码有效';

$txt['registration_errors_occurred'] = '在您的注册中检测到以下错误。请纠正他们再继续：';

$txt['authenticate_label'] = '验证方法';
$txt['authenticate_password'] = '密码';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'OpenID验证网址';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = '禁用两步验证';

// Contact form
$txt['admin_contact_form'] = '联系管理员';
$txt['contact_your_message'] = '你的留言';
$txt['errors_contact_form'] = '在处理您的请求时出现以下错误';
$txt['contact_subject'] = '有人给你发信息';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
