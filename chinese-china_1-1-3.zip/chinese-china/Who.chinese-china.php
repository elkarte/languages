<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>呃。。。我也不知道浏览的是什么！</em>';
$txt['who_admin'] = '查看管理中心';
$txt['who_moderate'] = '查看版主中心';
$txt['who_generic'] = '查看%1$s';
$txt['who_unknown'] = '<em>未知动作</em>';
$txt['who_user'] = '会员';
$txt['who_time'] = '时间';
$txt['who_action'] = '动作';
$txt['who_show1'] = '显示';
$txt['who_show_members_only'] = '只有会员';
$txt['who_show_guests_only'] = '只有访客';
$txt['who_show_spiders_only'] = '只有蜘蛛';
$txt['who_show_all'] = '所有';
$txt['who_no_online_spiders'] = '目前没有蜘蛛在线。';
$txt['who_no_online_guests'] = '目前没有游客在线。';
$txt['who_no_online_members'] = '目前没有会员在线。';

$txt['whospider_login'] = '查看登录页面。';
$txt['whospider_register'] = '查看注册页面';
$txt['whospider_reminder'] = '查看密码提示页面。';

$txt['whoall_activate'] = '激活会员帐号。';
$txt['whoall_buddy'] = '修改他们的好友名单';
$txt['whoall_coppa'] = '填写他们的父母/监护人同意表。';
$txt['whoall_credits'] = '查看荣誉表。';
$txt['whoall_emailuser'] = '发送 Email 给其他会员。';
$txt['whoall_groups'] = '查看群组页面。';
$txt['whoall_help'] = '查看<a href="{help_url}">说明文件</a>';
$txt['whoall_quickhelp'] = '查看说明。';
$txt['whoall_pm'] = '查看短信。';
$txt['whoall_auth'] = '登录论坛。';
$txt['whoall_login'] = '查看登录页面。';
$txt['whoall_login2'] = '查看登录页面。';
$txt['whoall_logout'] = '注销论坛。';
$txt['whoall_markasread'] = '标示帖子已读或未读。';
$txt['whoall_mentions'] = '查看他们的@通知列表';
$txt['whoall_modifykarma_applaud'] = '赞赏一个会员。';
$txt['whoall_modifykarma_smite'] = '打击一会会员。';
$txt['whoall_news'] = '查看最新消息。';
$txt['whoall_notify'] = '变更通知设定。';
$txt['whoall_notifyboard'] = '变更通知设定。';
$txt['whoall_openidreturn'] = '使用 OpenID 登录。';
$txt['whoall_quickmod'] = '监控一个版块';
$txt['whoall_recent'] = '查看<a href="{recent_url}">最新帖子</a>';
$txt['whoall_register'] = '注册帐号。';
$txt['whoall_reminder'] = '请求密码提示。';
$txt['whoall_reporttm'] = '举报帖子。';
$txt['whoall_spellcheck'] = '使用拼字检查';
$txt['whoall_unread'] = '查看未读主题。';
$txt['whoall_unreadreplies'] = '查看未读回复。';
$txt['whoall_who'] = '查看<a href="{who_url}">线上会员</a>';

$txt['whoall_collapse_collapse'] = '收合类别。';
$txt['whoall_collapse_expand'] = '展开类别。';
$txt['whoall_pm_removeall'] = '移除全部短信。';
$txt['whoall_pm_send'] = '发送短信。';
$txt['whoall_pm_send2'] = '发送短信。';

$txt['whotopic_announce'] = '公告主题 &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = '正在批复一个附件';
$txt['whotopic_dlattach'] = '查看附件。';
$txt['whotopic_deletemsg'] = '删除一个信息';
$txt['whotopic_editpoll'] = '编辑投票&quot;<a href="%1$s">%2$s</a>&quot;。';
$txt['whotopic_editpoll2'] = '编辑投票&quot;<a href="%1$s">%2$s</a>&quot;。';
$txt['whotopic_jsmodify'] = '修改文章在 &quot;<a href="%1$s">%2$s</a>&quot;。';
$txt['whotopic_likes'] = '点赞主题 &quot;<a href="%1$s">%2$s</a>&quot;。';
$txt['whotopic_lock'] = '锁定主题 &quot;<a href="%1$s">%2$s</a>&quot;。';
$txt['whotopic_lockvoting'] = '锁定调查 &quot;<a href="%1$s">%2$s</a>&quot;。';
$txt['whotopic_mergetopics'] = '合并主题 &quot;<a href="%1$s">%2$s</a>&quot; 到其他主题。';
$txt['whotopic_movetopic'] = '移动主题 &quot;<a href="%1$s">%2$s</a>&quot; 到其他版块。';
$txt['whotopic_movetopic2'] = '移动主题 &quot;<a href="%1$s">%2$s</a>&quot; 到其他版块。';
$txt['whotopic_post'] = '发布在<a href="%1$s">%2$s</a>。';
$txt['whotopic_post2'] = '发布在<a href="%1$s">%2$s</a>。';
$txt['whotopic_printpage'] = '打印主题 &quot;<a href="%1$s">%2$s</a>&quot;。';
$txt['whotopic_quickmod2'] = '审核主题<a href="%1$s">%2$s</a>。';
$txt['whotopic_poll_remove'] = '在 &quot;<a href="%1$s">%2$s</a>&quot; 删除调查。';
$txt['whotopic_removetopic2'] = '删除主题<a href="%1$s">%2$s</a>。';
$txt['whotopic_sendtopic'] = '给朋友发送主题 &quot;<a href="%1$s">%2$s</a>&quot; 。';
$txt['whotopic_splittopics'] = '将主题 &quot;<a href="%1$s">%2$s</a>&quot; 拆分为两个主题。';
$txt['whotopic_sticky'] = '置顶主题 &quot;<a href="%1$s">%2$s</a>&quot;。';
$txt['whotopic_unwatch'] = '关闭主题。';
$txt['whotopic_vote'] = '在<a href="%1$s">%2$s</a>投票。';
$txt['whotopic_watch'] = '打开主题。';

$txt['whopost_quotefast'] = '引用&quot;<a href="%1$s">%2$s</a>&quot;的帖子。';

$txt['whoadmin_editagreement'] = '编辑注册协议。';
$txt['whoadmin_featuresettings'] = '编辑论坛功能与选项。';
$txt['whoadmin_modlog'] = '查看版主日志';
$txt['whoadmin_serversettings'] = '编辑论坛设置。';
$txt['whoadmin_packageget'] = '获取软件包。';
$txt['whoadmin_packages'] = '查看软件包管理器。';
$txt['whoadmin_permissions'] = '编辑论坛权限。';
$txt['whoadmin_pgdownload'] = '下载软件包。';
$txt['whoadmin_theme'] = '编辑主题设置。';
$txt['whoadmin_trackip'] = '追踪IP。';

$txt['whoallow_manageboards'] = '编辑版块和类别设置。';
$txt['whoallow_admin'] = '进入<a href="{admin_url}">管理中心</a>。';
$txt['whoallow_ban'] = '编辑黑名单。';
$txt['whoallow_boardrecount'] = '重新计算版块数量。';
$txt['whoallow_calendar'] = '查看<a href="{calendar_url}">日历</a>。';
$txt['whoallow_editnews'] = '编辑最新消息。';
$txt['whoallow_mailing'] = '发送论坛邮件。';
$txt['whoallow_maintain'] = '执行日常论坛维护。';
$txt['whoallow_manageattachments'] = '管理附件。';
$txt['whoallow_moderate'] = '查看<a href="{moderate_url}">版主中心</a>';
$txt['whoallow_memberlist'] = '查看<a href="{memberlist_url}">会员列表</a>。';
$txt['whoallow_optimizetables'] = '优化数据库表。';
$txt['whoallow_repairboards'] = '修复数据库表。';
$txt['whoallow_search'] = '<a href="{search_url}">搜索</a>论坛。';
$txt['whoallow_search_results'] = '查看搜索结果。';
$txt['whoallow_setcensor'] = '编辑审查文本。';
$txt['whoallow_setreserve'] = '编辑保留名称。';
$txt['whoallow_stats'] = '查看<a href="{stats_url}">论坛统计</a>。';
$txt['whoallow_viewErrorLog'] = '查看错误日志。';
$txt['whoallow_viewmembers'] = '查看会员名单。';

$txt['who_topic'] = '查看主题<a href="%1$s">%2$s</a>。';
$txt['who_board'] = '查看版块<a href="%1$s">%2$s</a>。';
$txt['who_index'] = '查看版块主页<a href="{script_url}">{forum_name}</a>。';
$txt['who_viewprofile'] = '查看<a href="%1$s">%2$s</a>的简介。';
$txt['who_profile'] = '编辑<a href="%1$s">%2$s</a>的简介。';
$txt['who_post'] = '发布新的主题在 <a href="%1$s">%2$s</a>';
$txt['who_poll'] = '发布新的调查在<a href="%1$s">%2$s</a>';
$txt['who_topicbyemail'] = '编辑新的邮件主题在<a href="%1$s">%2$s</a>';

$txt['whotopic_postbyemail'] = '邮件发送到 <a href="%1$s">%2$s</a>';
$txt['whoall_pm_byemail'] = '通过邮件发送个人信息。';

// Credits text
$txt['credits'] = '勋绩';
$txt['credits_intro'] = 'ElkArte是100％免费和开源的。我们鼓励并支持一个接受公众贡献的积极、开放的社区。我们要感谢所有支持该项目的人，感谢他们提供代码、反馈、错误报告和意见。如果没有您，这一切都不可能实现。我们还要特别感谢让ElkArte诞生的 <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>。.';
$txt['credits_contributors'] = '贡献者';
$txt['credits_and'] = '和';
$txt['credits_copyright'] = '版权';
$txt['credits_forum'] = '论坛';
$txt['credits_addons'] = '附加组件';
$txt['credits_software_graphics'] = '软件/图形';
$txt['credits_software'] = '软件';
$txt['credits_graphics'] = '图形';
$txt['credits_fonts'] = '字体';
$txt['credits_groups_contrib'] = '贡献者';
$txt['credits_contrib_list'] = 'For a complete list of the many individuals that contributed to the design and implementation of Elkarte, please refer to the official GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">list of contributors.</a>';
$txt['credits_license'] = '许可证';
$txt['credits_copyright'] = '版权';
$txt['credits_version'] = '版本';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = '语言翻译';
$txt['credits_translators_message'] = '因为你们的努力, 世界各地的人才得以使用 ElkArte, 感谢<a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">你们</a>。';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';