<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = '用户帮助';

$txt['manual_welcome'] = '欢迎来到%s, powered by ElkArte 论坛软件';
$txt['manual_introduction'] = 'ElkArte是优雅、高效、强大且免费的论坛软件解决方案，该网站基于它运行。它允许用户以一种巧妙和有组织的方式在讨论话题中进行交流。此外，它还具有一些强大的功能，让许多用户可以利用它。通过单击相关部分旁边的问号图标或选择此页面上的其中一个链接，可以找到许多ElkArte功能的帮助。这些链接将带您领略ElkArte官方网站上的中心文档。';
$txt['manual_docs_and_credits'] = '更多关于如何使用elkarte的信息，请看<a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a>看看<a href="%2$s">credits</a>找出是哪些人成就了今天的ElkArte。';

$txt['manual_section_registering_title'] = '注册';
$txt['manual_section_logging_in_title'] = '登录';
$txt['manual_section_profile_title'] = '简介';
$txt['manual_section_search_title'] = '搜索';
$txt['manual_section_posting_title'] = '发布';
$txt['manual_section_bbc_title'] = 'Bulletin Board Code (BBC)';
$txt['manual_section_personal_messages_title'] = '个人消息';
$txt['manual_section_memberlist_title'] = '成员名单';
$txt['manual_section_calendar_title'] = '日历';
$txt['manual_section_features_title'] = '特性';

$txt['manual_section_registering_desc'] = '用户在论坛注册，可以获得更多访问权限。';
$txt['manual_section_logging_in_desc'] = '注册后，用户登录论坛可以访问自己的帐户。';
$txt['manual_section_profile_desc'] = '每个成员都有自己的个人资料。';
$txt['manual_section_search_desc'] = '查找帖子或话题等信息可以使用搜索工具。';
$txt['manual_section_posting_desc'] = '一个论坛的意义，就是让用户表达自己。';
$txt['manual_section_bbc_desc'] = '主题可以用BBC来润色';
$txt['manual_section_personal_messages_desc'] = '用户可以将个人信息发送给对方。';
$txt['manual_section_memberlist_desc'] = '成员名单显示论坛的所有会员。';
$txt['manual_section_calendar_desc'] = '用户可以跟踪事件、假期与日程。';
$txt['manual_section_features_desc'] = '下面是ElkArte最流行的功能列表。';