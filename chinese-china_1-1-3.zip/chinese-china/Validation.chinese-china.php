<?php
// Version: 1.1; Validation

$txt['_validate_required'] = '需要%1$s个字段';
$txt['_validate_valid_email'] = '该%1$s字段必须是一个有效的邮件地址';
$txt['_validate_max_length'] = '该%1$s字段最多可填写%2$s个字符';
$txt['_validate_min_length'] = '该%1$s字段至少需要%2$s个字符';
$txt['_validate_length'] = '该%1$s字段需要精确的%2$s字符长度';
$txt['_validate_alpha'] = '该%1$s字段只能包含字母。';
$txt['_validate_alpha_numeric'] = '该%1$s字段只能包含字母和数字。';
$txt['_validate_alpha_dash'] = '%1$s字段只能包含字母和破折号。';
$txt['_validate_numeric'] = '该%1$s应该是数字';
$txt['_validate_integer'] = '该%1$s字段只能包含一个整数。';
$txt['_validate_boolean'] = '该%1$s字段只能包含一个布尔值。';
$txt['_validate_float'] = '该%1$s字段只能包含一个浮点数。';
$txt['_validate_valid_url'] = '该%1$s字段必须是一个有效的网址';
$txt['_validate_url_exists'] = '该网址%1$s不存在';
$txt['_validate_valid_ip'] = '该%1$s字段需要包含一个有效的IPv4地址。';
$txt['_validate_valid_ipv6'] = '该%1$s字段需要包含一个有效的IPv6地址。';
$txt['_validate_contains'] = '该%1$s字段需要包含这些值中的一个：%2$s';
$txt['_validate_invalid_function'] = '指定的验证函数%1$s不存在。';
$txt['_validate_without'] = '该%1$s字段不能包含%2$s字符。';
$txt['_validate_notequal'] = '该%1$s字段不包含有效值。';
$txt['_validate_isarray'] = '该%1$s字段不包含有效数组。';
$txt['_validate_php_syntax'] = 'PHP语法错误：%2$s';
$txt['_validate_limits'] = '该%1$s字段包含超出允许范围%2$s之外的值。';
$txt['_validate_generic'] = '%1$s字段包含无效值。';
$txt['validation_failure'] = '表单有以下错误，在继续之前必须更正：';