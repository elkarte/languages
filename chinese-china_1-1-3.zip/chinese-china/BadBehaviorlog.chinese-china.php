<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = '日期';
$txt['badbehaviorlog_protocol'] = '协议';
$txt['badbehaviorlog_method'] = 'Method';
$txt['badbehaviorlog_request'] = 'Request';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = '会员ID';
$txt['badbehaviorlog_username'] = '用户名';
$txt['badbehaviorlog_headers'] = '标题';
$txt['badbehaviorlog_agent'] = '浏览器';
$txt['badbehaviorlog_entity'] = '发帖';
$txt['badbehaviorlog_key'] = 'Key';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = '总条目数';
$txt['badbehaviorlog_error_valid_code'] = '原因代码';
$txt['badbehaviorlog_error_valid_response'] = 'HTTP Status';
$txt['badbehaviorlog_error_valid_explaination'] = 'HTTP Reason';
$txt['badbehaviorlog_error_valid_log'] = '详细信息';
$txt['badbehaviorlog_log'] = 'BadBehavior日志';
$txt['badbehaviorlog_desc'] = 'Below is a list of all the bad behavior entries that have been logged';
$txt['badbehaviorlog_details'] = '其他细节信息';
$txt['badbehaviorlog_no_entries_found'] = 'There are currently no bad behavior log entries.';

$txt['badbehaviorlog_remove_selection'] = '删除所选';
$txt['badbehaviorlog_remove_selection_confirm'] = '你确定要删除所选的日志条目吗？';
$txt['badbehaviorlog_remove_filtered_results'] = '删除所有筛选结果';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = '你确定要删除筛选的条目？';
$txt['badbehaviorlog_sure_remove'] = '你确定要完全清除不良行为日志吗？';

$txt['badbehaviorlog_remove'] = '删除所选';
$txt['badbehaviorlog_removeall'] = '清除日志';
$txt['badbehaviorlog_clear_filter'] = '清除过滤';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Apply filter of type';
$txt['badbehaviorlog_apply_filter'] = 'Apply Filter';
$txt['badbehaviorlog_applying_filter'] = 'Applying Filter';
$txt['badbehaviorlog_filter_only_member'] = 'Only show the badbehavior logs of this member';
$txt['badbehaviorlog_filter_only_ip'] = 'Only show the badbehavior logs of this IP address';
$txt['badbehaviorlog_filter_only_session'] = 'Only show the badbehaviorlogs of this session';
$txt['badbehaviorlog_filter_only_headers'] = 'Only show the badbehavior logs of this URL';
$txt['badbehaviorlog_filter_only_agent'] = 'Only show the entries with the same user agent';

$txt['badbehaviorlog_session'] = 'Session';
$txt['badbehaviorlog_error_url'] = 'URL of the page that was logged';

$txt['badbehaviorlog_reverse_direction'] = 'Reverse chronological order of list';
$txt['badbehaviorlog_filter_only_type'] = 'Only show the logs with this code';