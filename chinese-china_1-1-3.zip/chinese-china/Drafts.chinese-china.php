<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = '显示草稿';
$txt['drafts_show_desc'] = '此区域显示了所有当前已保存的草稿。从这里你可以发布前对其进行编辑，也可以将其删除';

// misc
$txt['drafts'] = '草稿';
$txt['draft_save'] = '保存草稿';
$txt['draft_save_note'] = '将会保存您的文章的文字，但不会保存附件、投票或活动信息。';
$txt['draft_none'] = '没有草稿。';
$txt['draft_edit'] = '编辑草稿';
$txt['draft_load'] = '加载草稿';
$txt['draft_hide'] = '隐藏草稿';
$txt['draft_delete'] = '删除草稿';
$txt['draft_days_ago'] = '%s天前';
$txt['draft_retain'] = '这将被保留%s天';
$txt['draft_remove'] = '删除此草稿';
$txt['draft_remove_selected'] = '删除所有选定的草稿？';
$txt['draft_saved'] = '本内容已经保存为草稿，你可从你的个人资料<a href="%1$s">访问草稿</a>。';
$txt['draft_pm_saved'] = '本内容已经保存为草稿，将可从你的消息中心<a href="%1$s">访问草稿</a>。';

// Admin options
$txt['drafts_autosave_enabled'] = '启用自动保存草稿';
$txt['drafts_autosave_enabled_subnote'] = '这将自动默认保存用户的草稿。用户还必须具有适当的权限。';
$txt['drafts_keep_days'] = '草案保存最大天数';
$txt['drafts_keep_days_subnote'] = '输入0永久保存草稿';
$txt['drafts_autosave_frequency'] = '多久会自动保存草稿？';
$txt['drafts_autosave_frequency_subnote'] = '最小允许值为30秒';
$txt['drafts_pm_enabled'] = '启用短信草稿保存';
$txt['drafts_post_enabled'] = '启用帖子草稿保存';
$txt['drafts_none'] = '无主题';
$txt['drafts_saved'] = '草稿已成功保存';