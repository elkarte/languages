<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Indstil søgeparametre';
$txt['choose_board'] = 'Vælg et board at søge i eller søg i alle';
$txt['all_words'] = 'Match alle ord';
$txt['any_words'] = 'Match ethvert ord';
$txt['by_user'] = 'Efter bruger';

$txt['search_post_age'] = 'Alder på indlæg';
$txt['search_between'] = 'mellem';
$txt['search_and'] = 'og';
$txt['search_options'] = 'Valgmuligheder';
$txt['search_show_complete_messages'] = 'Vis søgeresultater som indlæg';
$txt['search_subject_only'] = 'Søg kun i emnets overskrift';
$txt['search_relevance'] = 'Relevans';
$txt['search_date_posted'] = 'Postet dato';
$txt['search_order'] = 'Søge rækkefølge';
$txt['search_orderby_relevant_first'] = 'Mest relevante resultater først';
$txt['search_orderby_large_first'] = 'Største emner først';
$txt['search_orderby_small_first'] = 'Mindste emner først';
$txt['search_orderby_recent_first'] = 'Nyeste emner først';
$txt['search_orderby_old_first'] = 'Ældste emner først';
$txt['search_visual_verification_label'] = 'Bekræftigelse';
$txt['search_visual_verification_desc'] = 'Angiv venligst koden fra billedet herover for at bruge søg.';

$txt['search_specific_topic'] = 'Søger kun i emnetekst';

$txt['groups_search_posts'] = 'Medlemsgrupper med adgang til søgefunktionen';
$txt['search_dropdown'] = 'Aktiver hurtig søgning dropdown';
$txt['search_results_per_page'] = 'Antal søgeresultater per side';
$txt['search_weight_frequency'] = 'Relativ søgevægt efter antallet af matchende beskeder inden for et emne';
$txt['search_weight_age'] = 'Relativ søgevægt efter alder for nyest matchende beskeder';
$txt['search_weight_length'] = 'Relativ søgevægt efter emnelængde';
$txt['search_weight_subject'] = 'Relativ søgevægt efter match i emnets tema';
$txt['search_weight_first_message'] = 'Relativ søgevægt efter match i første besked';
$txt['search_weight_sticky'] = 'Relativ søgevægt for et fremhævet emne';
$txt['search_weight_likes'] = 'Relativ søgevægt for emne Likes';

$txt['search_settings_desc'] = 'Her kan du ændre standardindstillingerne på søgefunktionen.';
$txt['search_settings_title'] = 'Søgefunktion indstillinger';

$txt['search_weights_desc'] = 'Her kan du ændre de individuelle komponenter af relevansen.';
$txt['search_weights_sphinx'] = 'For at opdatere vægt faktorer til Sphinx, skal du generere og installere en ny sphinx.conf fil.';
$txt['search_weights_title'] = 'Søg - vægt på';
$txt['search_weights_total'] = 'Total';
$txt['search_weights_save'] = 'Gem';

$txt['search_method_desc'] = 'Her kan du indstille hvordan søgning fungerer.';
$txt['search_method_title'] = 'Søg - metode';
$txt['search_method_save'] = 'Gem';
$txt['search_method_messages_table_space'] = 'Plads brugt af forumbeskeder i databasen';
$txt['search_method_messages_index_space'] = 'Plads brugt til at indeksere beskeder i databasen';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Fuldtekst indeks';
$txt['search_method_no_index_exists'] = 'Eksisterer i øjeblikket ikke';
$txt['search_method_fulltext_create'] = 'Opret en fuld-tekst indeks';
$txt['search_method_fulltext_cannot_create'] = 'Kan ikke oprettes, da max. længden på beskeder er over 65,535 eller tabeltypen ikke er MyISAM';
$txt['search_method_index_already_exists'] = 'allerede oprettet';
$txt['search_method_fulltext_remove'] = 'fjern fuldtekst indeks';
$txt['search_method_index_partial'] = 'Delvist oprettet';
$txt['search_index_custom_resume'] = 'fortsæt';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'For at kunne bruge fuldtekst søgning, skal du først oprette en fuldtekst indeks.';
$txt['search_index_custom_warning'] = 'For at kunne bruge en brugerdefineret indekssøgning, skal du først oprette et brugerdefineret indeks!';

$txt['search_index'] = 'Søgeindeks';
$txt['search_index_none'] = 'Ingen indeks';
$txt['search_index_custom'] = 'Brugerdefineret indeks';
$txt['search_index_label'] = 'Indeks';
$txt['search_index_size'] = 'Størrelse';
$txt['search_index_create_custom'] = 'Opret en brugerdefineret indeks';
$txt['search_index_custom_remove'] = 'Fjern brugerdefineret indeks';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'For at ændre Sphinx indstillinger, brug <a class="linkbutton" href="{managesearch_url}">Konfigurer Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'For at ændre SphinxQL indstillinger, brug <a class="linkbutton" href="{managesearch_url}">Konfigurer Sphinx</a>';

$txt['search_force_index'] = 'Gennemtving brugen af et søgeindeks';
$txt['search_match_words'] = 'Match kun hele ord';
$txt['search_max_results'] = 'Maks. antal resultater at vise';
$txt['search_max_results_disable'] = '(0: ingen grænse)';
$txt['search_floodcontrol_time'] = 'Tid der kræves mellem søgninger fra samme bruger';
$txt['search_floodcontrol_time_desc'] = '(0 for ubegrænset, i sekunder)';

$txt['additional_search_engines'] = 'Yderligere søgemaskiner';
$txt['setup_search_engine_add_more'] = 'Tilføj en ny søgemaskine';

$txt['search_create_index'] = 'Opret indeks';
$txt['search_create_index_why'] = 'Hvorfor oprette et søgeindeks?';
$txt['search_create_index_start'] = 'Opret';
$txt['search_predefined'] = 'Pre-defineret profil';
$txt['search_predefined_small'] = 'Lille indeks';
$txt['search_predefined_moderate'] = 'Moderat indeks';
$txt['search_predefined_large'] = 'Stort indeks';
$txt['search_create_index_continue'] = 'Fortsæt';
$txt['search_create_index_not_ready'] = 'ElkArte er ved at oprette et søgeindeks af dine indlæg. For at undgå overbelastning af din server, er processen midlertidigt stoppet. Processen bliver automatisk genoptaget om et par sekunder. Hvis dette ikke sker, så klik herunder for at fortsætte.';
$txt['search_create_index_progress'] = 'Progres';
$txt['search_create_index_done'] = 'Brugerdefineret søgeindeks oprettet.';
$txt['search_create_index_done_link'] = 'Fortsæt';
$txt['search_double_index'] = 'I øjeblikket har du oprettet to indekser i beskedtabellen. For bedste ydelse, rådes det at slette en af dem.';

$txt['search_error_indexed_chars'] = 'Forkert antal af indekserede karakterer. Mindst 3 karakterer er nødvendigt til et brugbart indeks.';
$txt['search_error_max_percentage'] = 'Forkert procenttal af ord der skal skippes. Brug et tal på mindst 5%.';
$txt['error_string_too_long'] = 'Søgestrengen skal være mindre end %1$d karakterer lang.';

$txt['search_warning_ignored_word'] = 'Det følgende begreb er blevet ignoreret i din søgning';
$txt['search_warning_ignored_words'] = 'De følgende begreber er blevet ignoreret i din søgning';

$txt['search_adjust_query'] = 'Juster Søgeparametre';
$txt['search_adjust_submit'] = 'Ret søgning';
$txt['search_did_you_mean'] = 'Måske søgte du efter';

$txt['search_example'] = '<em>eks.</em> Mads "James Bond" -film';

$txt['search_engines_description'] = 'Fra dette område kan du beslutte hvor detaljeret du ønsker at spore søgemaskiner efterhånden som de indekserer dit forum, såvel som se søgemaskine logs.';
$txt['spider_mode'] = 'Søgemaskine sporings niveau';
$txt['spider_mode_note'] = 'Bemærk at højere sporings niveau forøger server ressourcer.';
$txt['spider_mode_off'] = 'Deaktiveret';
$txt['spider_mode_standard'] = 'Standard';
$txt['spider_mode_high'] = 'Moderer';
$txt['spider_mode_vhigh'] = 'Aggressiv';
$txt['spider_settings_desc'] = 'Du kan ændre indstillinger for søgerobotter fra denne side. Bemærk, hvis du ønsker at <a href="%1$s">aktivere automatisk beskæring af logs over hits, kan du sætte dette op her</a>';

$txt['spider_group'] = 'Anvend restriktive tilladelser fra gruppe';
$txt['spider_group_note'] = 'For at tillade dig at stoppe søgerobotter fra at indeksere visse sider.';
$txt['spider_group_none'] = 'Deaktiveret';

$txt['show_spider_online'] = 'Vis søgerobotter i hvem er online listen';
$txt['show_spider_online_no'] = 'Slet ikke';
$txt['show_spider_online_summary'] = 'Vis mængden af søgerobotter';
$txt['show_spider_online_detail'] = 'Vis navne på søgerobotter';
$txt['show_spider_online_detail_admin'] = 'Vis navn på søgerobotter - kun admin';

$txt['spider_name'] = 'Navn på Søgerobot';
$txt['spider_last_seen'] = 'Sidst Set';
$txt['spider_last_never'] = 'Aldrig';
$txt['spider_agent'] = 'User Agent';
$txt['spider_ip_info'] = 'IP Adresser';
$txt['spiders_add'] = 'Tilføj Ny Søgerobot';
$txt['spiders_edit'] = 'Rediger Søgerobot';
$txt['spiders_remove_selected'] = 'Slet markerede';
$txt['spider_remove_selected_confirm'] = 'Er du sikker på at du vil fjerne disse søgerobotter?\\n\\nAlle associerede statistikker bliver også slettet!';
$txt['spiders_no_entries'] = 'Der er i øjeblikket ikke konfigureret nogen søgerobotter.';

$txt['add_spider_desc'] = 'Fra denne side kan du redigere parametrene for hvordan en søgerobot er kategoriseret. Hvis en gæsts user agent/IP addresse matcher dem angivet herunder, vil den blive detekteret som en søgemaskine robot efter forum indstillingerne.';
$txt['spider_name_desc'] = 'Navnet søgerobotten vil blive refereret som.';
$txt['spider_agent_desc'] = 'User Agent associeret med denne søgerobot.';
$txt['spider_ip_info_desc'] = 'Kommaseppareret liste af IP adresser associeret med denne søgerobot.';

$txt['spider_time'] = 'Tid';
$txt['spider_viewing'] = 'Læser';
$txt['spider_logs_empty'] = 'Der er i øjeblikket ingen logs over søgerobotter på nuværende tidspunkt.';
$txt['spider_logs_info'] = 'Bemærk at logging af enhver aktivitet fra søgerobotter kun opstår hvis sporing er sat til enten &quot;høj&quot; eller &quot;meget høj&quot;. Detaljer over alle søgerobotters handlinger bliver kun logget hvis sporing er sat til &quot;meget høj&quot;. ';
$txt['spider_disabled'] = 'Deaktiveret';
$txt['spider_log_empty_log'] = 'Ryd Log';
$txt['spider_log_empty_log_confirm'] = 'Er du sikker på du vil rydde hele log?';

$txt['spider_logs_delete'] = 'Slet alle logger';
$txt['spider_logs_delete_older'] = 'Slet alle elementer ældre end %1$s dage.';
$txt['spider_logs_delete_submit'] = 'Slet';

$txt['spider_stats_delete_older'] = 'Slet alle søgerobotstatistikker fra søgerobotter der ikke er blevet set i %1$s dage.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Er du sikker på du ønsker at slette alle log poster?';

$txt['spider_stats_select_month'] = 'Spring Til Måned';
$txt['spider_stats_page_hits'] = 'Side Hits';
$txt['spider_stats_no_entries'] = 'Der er i øjeblikket ingen statistikker tilgængelig over søgerobotter.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'Du har endnu ikke valgt om du vil bruge Sphinx eller SphinxQL som din søge metode';
$txt['sphinx_test_passed'] = 'Alle test lykkedes, systemet er i stand til at forbinde til sphinx søge service ved at bruge Sphinx API.';
$txt['sphinxql_test_passed'] = 'Alle test lykkedes, systemet er i stand til at forbinde til sphinx søge service ved at bruge SphinxQL kommandoer.';
$txt['sphinx_test_connect_failed'] = 'Kunne ikke forbinde til Sphinx service. Sørg for at den kører og er konfigureret rigtigt. Sphinx søgning vil ikke virke før du løser problemet.';
$txt['sphinxql_test_connect_failed'] = 'Kunne ikke forbinde til SphinxQL. Sørg for at din sphinx.conf fil har et separat direktiv til lytte porten for SphinxQL.SphinxQL søgning vil ikke virke før du løser problemet.';
$txt['sphinx_test_api_missing'] = 'Sphinxapi.php filen blev ikke fundet i &quot;sources&quot; mappen. Du skal kopiere denne fil fra Sphinx distibutionen. Sphinx søgning vil ikke virke før du løser problemet.';
$txt['sphinx_description'] = 'Brug dette interface for at definere adgangs detaljer til din Sphinx søge service. <strong>Disse indstillinger er kun brugt til at oprette</strong> en første sphinx.conf konfigurations fil som du skal gemme i din Sphinx konfigurations mappe (typisk /usr/local/etc eller /etc/sphinxsearch). Generelt kan mulighederne nedenunder blive efterladt som de er, men de antager at Sphinx software er installeret i /usr/local og bruger /var/sphinx til at gemme søge data. For at holde Sphinx opdateret, skal du bruge et cron job for at opdatere indekses, ellers vil nye eller slettet indhold ikke blive reflekteret i søge resultaterne. Konfigurations filen definerer to indekses:<br /><br/><strong>elkarte_delta_index</strong>, en indeks der kun gemmer nye ændringer og kan blive kaldt ofte. <strong>elkarte_base_index</strong>, en indeks der gemmer en fuld database og bør kaldes mindre ofte. Eksempel:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Indeks præfiks:';
$txt['sphinx_index_prefix_desc'] = 'Dette er præfiks for base og delta indekser.<br />Som standard bruges elkarte og de 2 indekser vil være elkarte_base_index og elkarte_delta_index. Sphinx vil forbinde til elkarte_index (prefix_index).  Hvis du ændrer dette, så vær sikker på at bruge det korrekte præfiks i dit cron job.';
$txt['sphinx_index_data_path'] = 'Indeks data sti:';
$txt['sphinx_index_data_path_desc'] = 'Dette er stien der indeholder søge indeks filer der bruges af Sphinx.<br />Den <strong>skal</strong> eksistere og være tilgængelig for læsning og skrivning af Sphinx indeks og søge service.';
$txt['sphinx_log_file_path'] = 'Logfil sti:';
$txt['sphinx_log_file_path_desc'] = 'Server sti som vil indeholde log filer genereret af Sphinx.<br />Denne mappe skal eksistere på din server og skal være skrivbar af sphinx søge service og indekser.';
$txt['sphinx_stop_word_path'] = 'Stopword sti:';
$txt['sphinx_stop_word_path_desc'] = 'Server sti til stopword listen (efterlad tom for ingen stopword liste).';
$txt['sphinx_memory_limit'] = 'Sphinx indekser hukommelses grænse:';
$txt['sphinx_memory_limit_desc'] = 'Maksimalt antal af (RAM) hukommelse det er tilladt for indekseren at bruge.';
$txt['sphinx_searchd_server'] = 'Søge service server:';
$txt['sphinx_searchd_server_desc'] = 'Adressen på serveren søge service kører på. Dette skal være en gyldig hostnavn eller IP adresse.<br />Hvis den ikke er sat, vil localhost blive brugt.';
$txt['sphinx_searchd_port'] = 'Søge service port:';
$txt['sphinx_searchd_port_desc'] = 'Porten som søge service kører på.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL service port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port som søge service vil lytte efter SphinxQL forespørgsler på.';
$txt['sphinx_max_matches'] = 'Maksimal antal af resultater:';
$txt['sphinx_max_matches_desc'] = 'Maksimal antal af resultater som søge service vil returnere.';
$txt['sphinx_create_config'] = 'Opret Sphinx konfiguration';
$txt['sphinx_test_connection'] = 'Test forbindelse til Sphinx service';