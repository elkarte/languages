<?php
// Version: 1.1; ManageSettings

$txt['modSettings_desc'] = 'Denne side giver dig mulighed for at ændre indstillinger på funktioner og grundlæggende valgmuligheder for dit forum. Se <a href="%1$s">tema indstillinger</a> for flere valgmuligheder.  Klik hjælpeikonerne for mere information om en indstilling.';
$txt['security_settings_desc'] = 'Denne side tillader dig at ændre valgmuligheder specielt relateret til sikkerheden og modificering af dit forum, inklusive anti-spam indstillinger.';
$txt['modification_settings_desc'] = 'Denne side indeholder indstillinger tilføjet til dit forum af modifikationer';

$txt['modification_no_misc_settings'] = 'Der er ikke nogen add-ons installeret som har tilføjet nogen indstillinger til dette område endnu.';

$txt['allow_guestAccess'] = 'Tillad gæster at browse forummet';
$txt['userLanguage'] = 'Aktiver brugervalgbar sprogsupport';
$txt['allow_editDisplayName'] = 'Tillad brugere at redigere deres skærmnavn';
$txt['allow_hideOnline'] = 'Tillad ikke-administratorer at skjule deres online status';
$txt['titlesEnable'] = 'Aktiver brugerdefinerede titler';
$txt['enable_buddylist'] = 'Aktiver venner/ignoreringslister';
$txt['default_personal_text'] = 'Standard personlig tekst';
$txt['default_personal_text_note'] = 'Personlig tekst der skal tildeles til nye registrerede brugere.';
$txt['time_format'] = 'Standard tidsformat';
$txt['setting_time_offset'] = 'Overordnet tidsforskydning';
$txt['setting_time_offset_note'] = '(tilføjes til brugerspecifikke valg)';
$txt['setting_default_timezone'] = 'Server tidszone';
$txt['failed_login_threshold'] = 'Maksimalt antal loginforsøg';
$txt['loginHistoryDays'] = 'Antal af dage login historik skal gemmes';
$txt['lastActive'] = 'Brugere online tærskelværdi';
$txt['trackStats'] = 'Spor daglig statistik';
$txt['hitStats'] = 'Spor daglige hits (statistik skal være aktiveret)';
$txt['enableCompressedOutput'] = 'Aktiver komprimeret output';
$txt['databaseSession_enable'] = 'Brug databasedrevne sessioner';
$txt['databaseSession_loose'] = 'Tillad browsere at gå tilbage til cachede sider';
$txt['databaseSession_lifetime'] = 'Sekunder før en ubrugt session udløber';
$txt['enableErrorLogging'] = 'Aktiver fejllog';
$txt['enableErrorQueryLogging'] = 'Inkluder databaseforespørgsler i fejlloggen';
$txt['pruningOptions'] = 'Aktiver oprydning af logs';
$txt['pruneErrorLog'] = 'Fjern log elementer for fejl ældre end';
$txt['pruneModLog'] = 'Fjern log elementer for moderation ældre end';
$txt['pruneBanLog'] = 'Fjern log elementer for bans ældre end';
$txt['pruneReportLog'] = 'Fjern log elementer for rappoteringer til moderator ældre end';
$txt['pruneScheduledTaskLog'] = 'Fjern log elementer for planlagte opgaver ældre end';
$txt['pruneSpiderHitLog'] = 'Fjern log elementer for søgemaskiner ældre end';
$txt['pruneBadbehaviorLog'] = 'Fjern log elementer for Bad Behavior ældre end';
$txt['cookieTime'] = 'Standard cookielængde for login';
$txt['localCookies'] = 'Aktiver lokal gemning af cookies';
$txt['localCookies_note'] = '(SSI virker ikke ordentligt med dette)';
$txt['globalCookies'] = 'Brug underdomæne uafhængige cookies';
$txt['globalCookies_note'] = '(slå først lokale cookies fra)';
$txt['globalCookiesDomain'] = 'Hoveddomæne der skal bruges til underdomæne uafhængige cookies';
$txt['globalCookiesDomain_note'] = '(aktiver underdomæne uafhængige cookies først!<br />Domænet kan f.eks være: "webside.com" eller "webside.co.uk" uden http:// eller skråstreger)';
$txt['invalid_cookie_domain'] = 'Det indtastede domænenavn er ikke gyldigt, kontroller det og gem igen.';
$txt['secureCookies'] = 'Kræv at cookies er sikre';
$txt['secureCookies_note'] = '(Dette gælder kun hvis du bruger HTTPS - brug ikke ellers)';
$txt['httponlyCookies'] = 'Kræv at cookies kun er tilgængelige over HTTP protokollen';
$txt['httponlyCookies_note'] = '(Cookies vil ikke være tilgængelige fra scripting sprog, såsom JavaScript. Denne indstilling kan hjælpe med at reducere identitetstyveri igennem XSS angreb.)';
$txt['admin_session_lifetime'] = 'Antal af minutter en administrations session opretholdes';
$txt['auto_admin_session'] = 'Opret automatisk en administrations session ved log ind';
$txt['securityDisable'] = 'Deaktiver administrationssikkerhed';
$txt['securityDisable_moderate'] = 'Deaktiver moderation sikkerhed';
$txt['enableOTP'] = 'Aktiver to faktor autentificering (Tids-basered  engangskode)';
$txt['send_validation_onChange'] = 'Kræv genaktivering ved ændring af e-mailadresse';
$txt['approveAccountDeletion'] = 'Forlang godkendelse fra administrator, hvis medlemmet sletter sin konto';
$txt['autoOptMaxOnline'] = 'Maksimal antal af brugere der kan være online når der optimeres';
$txt['autoFixDatabase'] = 'Reparer automatisk ødelagte tabeller';
$txt['allow_disableAnnounce'] = 'Tillad brugere at deaktivere annonceringer';
$txt['disallow_sendBody'] = 'Tillad ikke indlæggets indhold bliver sendt med ved e-mail notifikation';
$txt['jquery_source'] = 'Kilde for jQuery bibliotek';
$txt['jquery_local'] = 'Lokalitet';
$txt['jquery_cdn'] = 'Google CDN';
$txt['jquery_auto'] = 'Auto';
$txt['jquery_version'] = 'Angiv hvilken version der skal bruges f.eks. 1.11.1';
$txt['jquery_default'] = 'Angiv hvilken version af jQuery der skal bruges med ElkArte';
$txt['jqueryui_default'] = 'Angiv hvilken version af jQueryUI der skal bruges med ElkArte';
$txt['jquery_custom_after'] = 'Lokal kopi søger efter jquery-<strong>X.XX.X</strong>.min.js';
$txt['jqueryui_custom_after'] = 'Lokal kopi søger efter jquery-ui-<strong>X.XX.X</strong>.min.js';
$txt['minify_css_js'] = 'Minimer antallet af Javascript og CSS filer';
$txt['clean_hives'] = 'Ryd hive cache';
$txt['clean_hives_sucess'] = 'CSS og JS hives slettet.';
$txt['clean_hives_failed'] = 'Et problem opstod, hives blev ikke slettet.';
$txt['enable_contactform'] = 'Aktiver kontaktform';
$txt['contact_form_disabled'] = 'Deaktiveret';
$txt['contact_form_registration'] = 'Vis kun ved registrering';
$txt['contact_form_menu'] = 'Vis i menuen';
$txt['queryless_urls'] = 'Søgemaskine venlige webadresser';
$txt['queryless_urls_note'] = 'Virker kun i Apache/Lighthttpd';
$txt['queryless_urls_work'] = 'Denne funktion vil virke på din server.';
$txt['queryless_urls_notwork'] = 'Denne funktion vil ikke virke på din server.';
$txt['enableReportPM'] = 'Aktiver anmeldelse af personlige beskeder';
$txt['antispam_PM'] = 'Begrænsninger for personlige beskeder';
$txt['max_pm_recipients'] = 'Maksimale antal af modtagere tilladt i en personlig besked';
$txt['max_pm_recipients_note'] = '(0 for ubegrænset, administratorer er undtaget)';
$txt['compactTopicPagesEnable'] = 'Begræns antallet af viste sidelinks';
$txt['compactTopicPagesContiguous'] = 'Tilstødende sider at vise';
$txt['to_display'] = 'at vise';
$txt['todayMod'] = 'Aktiver kort version af datovisning';
$txt['today_disabled'] = 'Deaktiveret';
$txt['today_only'] = 'Kun i dag';
$txt['yesterday_today'] = 'I dag &amp; I går';
$txt['relative_time'] = 'Relativ tid';
$txt['onlineEnable'] = 'Vis online/offline i emner og personlige beskeder';
$txt['enableVBStyleLogin'] = 'Vis hurtig-login på alle sider';
$txt['defaultMaxMembers'] = 'Antal medlemmer per side i medlemslisten';
$txt['displayMemberNames'] = 'Vis brugerens navn istedet for "Min Konto" på profil konto knappen';
$txt['timeLoadPageEnable'] = 'Vist indlæsningstid for hver side';
$txt['disableHostnameLookup'] = 'Deaktiver opslag af hostnavn';
$txt['who_enabled'] = 'Aktiver &quot;brugere online&quot; listen';
$txt['settings_error'] = 'Advarsel: Opdatering af Settings.php mislykkedes, indstillinger kan ikke gemmes.';
$txt['core_settings_saved'] = 'Indstillinger blev gemt';
$txt['action'] = 'Current Action';

$txt['karmaMode'] = 'Karma-tilstand';
$txt['karma_options'] = 'Deaktiver karma|Aktiver karma total|Aktiver karma positiv/negativ';
$txt['karmaMinPosts'] = 'Indstil det mindste antal indlæg der er påkrævet, for at kunne give karma';
$txt['karmaWaitTime'] = 'Sæt ventetid i timer';
$txt['karmaTimeRestrictAdmins'] = 'Begræns administratorer til ventetid';
$txt['karmaDisableSmite'] = 'Disable the ability for members to smite';
$txt['karmaLabel'] = 'Karma mærkat';
$txt['karmaApplaudLabel'] = 'Betegnelse for god karma';
$txt['karmaSmiteLabel'] = 'Betegnelse for dårlig karma';

$txt['likes_enabled'] = 'Aktiver Likes';
$txt['likeMinPosts'] = 'Angiv minimum antal af indlæg en bruger skal have for at kunne like et indlæg';
$txt['likeWaitTime'] = 'Angiv ventetid i minutter';
$txt['likeWaitCount'] = 'Angiv maksimale antal af likes/fjernelse af like en bruger kan udføre i den ovenstående tidsperiode';
$txt['likeRestrictAdmins'] = 'Begræns også administratorer til den angivne grænse';
$txt['likeAllowSelf'] = 'Tillad brugere at like deres egne indlæg';
$txt['likeDisplayLimit'] = 'Angiv maksimale antal af "likes" navne der skal vises i emnet, 0 for ubegrænset, -1 for at deaktivere';

$txt['caching_information'] = 'ElkArte understøtter caching igennem brugen af accelerators. De nuværende supporterede accelerators er:
<ul class="bbc_list">
	<li>APC</li>
	<li>eAccelerator</li>
	<li>Turck MMCache</li>
	<li>Memcached</li>
	<li>Zend Platform/Performance Suite (Ikke Zend Optimizer)</li>
	<li>XCache</li>
</ul>
Caching virker bedst hvis du har PHP kompileret med en af de ovenstående programmer, eller har memcache tilgængelig. Hvis du ikke har nogen af de ovenstående installeret, vil fil baseret caching blive brugt.';
$txt['detected_accelerators'] = 'De følgende accelerators blev fundet: <strong class="success">%1$s</strong>';

$txt['cache_enable'] = 'Caching niveau';
$txt['cache_off'] = 'Ingen caching';
$txt['cache_level1'] = 'Level 1 caching (anbefalet)';
$txt['cache_level2'] = 'Level 2 caching';
$txt['cache_level3'] = 'Level 3 caching (Ikke anbefalet)';
$txt['cache_memcached'] = 'Memcache indstillinger';
$txt['cache_memcache'] = 'Memcache indstillinger';
$txt['cache_memcached_servers'] = '<br />Tilføjede servere:<ul class="bbc_list"><li>';
$txt['cache_accelerator'] = 'Caching Accelerator';
$txt['cache_uid'] = 'Cache Accelerator BrugerID';
$txt['cache_password'] = 'Cache Accelerator Kodeord';

$txt['loadavg_warning'] = '<span class="error">Bemærk: Indstillingerne herunder skal redigeres med forsigtighed. Hvis nogen af dem indstilles for lavt, kan det gøre dit forum <strong>ubrugeligt</strong>! Nuværende load gennemsnit er <strong>%01.2f</strong></span>';
$txt['loadavg_enable'] = 'Aktiver load balancing ved load gennemsnit';
$txt['loadavg_auto_opt'] = 'Tærskel for deaktivering af automatisk databaseoptimering';
$txt['loadavg_search'] = 'Tærskel for deaktivering af søgning';
$txt['loadavg_allunread'] = 'Tærskel for deaktivering af all ulæste emner';
$txt['loadavg_unreadreplies'] = 'Tærskel for deaktivering af ulæste indlæg';
$txt['loadavg_show_posts'] = 'Tærskel for deaktivering af visning af brugerens indlæg';
$txt['loadavg_userstats'] = 'Tærskel for deaktivering af visning af bruger statistikker';
$txt['loadavg_bbc'] = 'Tærskel for deaktivering af BBC formatering ved visning af indlæg';
$txt['loadavg_forum'] = 'Tærskel for at deaktivere forummet <strong>fuldstændigt</strong>';
$txt['loadavg_disabled_windows'] = '<span class="error">Load balancing support er ikke tilgængelig i Windows.</span> ';
$txt['loadavg_disabled_conf'] = '<span class="error">Load balancing support er deaktiveret af konfigurationen af din host-.</span>';

$txt['setting_password_strength'] = 'Krævet styrke på brugeres kodeord';
$txt['setting_password_strength_low'] = 'Lav - minimum 4 karakterer';
$txt['setting_password_strength_medium'] = 'Medium - kan ikke indeholde brugernavn';
$txt['setting_password_strength_high'] = 'Høj - en blanding af forskellige karakterer';
$txt['setting_enable_password_conversion'] = 'Tillad kodeord hash konvertering';

$txt['antispam_Settings'] = 'Anti-spam-godkendelse';
$txt['antispam_Settings_desc'] = 'Denne sektion tillader dig at justere anvendelsen af verifikationscheck for at sikre dig at brugeren er et menneske (og ikke en robot), samt justere hvordan og hvor dette har indvirkning.';
$txt['setting_reg_verification'] = 'Forlang verificering på registreringssiden';
$txt['posts_require_captcha'] = 'Antal indlæg, hvorunder brugere skal bestå en verificering for at kunne poste';
$txt['posts_require_captcha_desc'] = '(0 for ubegrænset, moderatorer er undtaget)';
$txt['search_enable_captcha'] = 'Forlang verificering på alle gæstesøgninger';
$txt['setting_guests_require_captcha'] = 'Gæster skal igennem en verificering når de opretter indlæg';
$txt['setting_guests_require_captcha_desc'] = '(Indstilles automatisk hvis du angiver et minimum antal indlæg herunder)';
$txt['guests_report_require_captcha'] = 'Gæster skal bestå en verificering når de rapporterer et indlæg';

$txt['badbehavior_title'] = 'Bad Behavior Indstillinger';
$txt['badbehavior_details'] = 'Detaljer';
$txt['badbehavior_desc'] = 'Bad Behavior er designet til at køre så tidligt som muligt for at afvise spambots før de har mulighed for at ødelægge dit site eller før de kan indsamle email adresser og formularer til udfyldining.<br />Bad Behavior blokerer også many email adresse indsamlingsmaskiner, resulterende i mindre email spam, og mange automatiserede website cracking værktøjer, alle disse hjælper til at forbedre sikkerheden på din webside.';
$txt['badbehavior_wl_desc'] = 'Upassende whitelisting VIL udsætte dig for spam, eller forhindre Bad Behavior i overhovedet at virke! <strong>WHITELIST IKKE</strong> med mindre du er 100% SIKKER PÅ at du skal og ved hvad du laver.';
$txt['badbehavior_enabled'] = 'Aktiver Bad Behavior Kontrollering';
$txt['badbehavior_enabled_desc'] = 'Afkryds for at aktivere Bad Behavior beskttelse af dit site.';
$txt['badbehavior_strict'] = 'Aktiver streng operations tilstand';
$txt['badbehavior_logging'] = 'Aktiver logning';
$txt['badbehavior_offsite_forms'] = 'Tillad offsite formularer';
$txt['badbehavior_verbose'] = 'Aktiver detaljeret logning';
$txt['badbehavior_verbose_desc'] = 'Det er anbefalet at du ikke aktiverer detaljeret tilstand';
$txt['badbehavior_httpbl_key'] = 'http:BL API Key';
$txt['badbehavior_httpbl_key_invalid'] = 'Den supplerede http:BL API Key er ikke gyldig';
$txt['badbehavior_httpbl_threat'] = 'http:BL trusselsniveau';
$txt['badbehavior_httpbl_threat_desc'] = '(standard 25)';
$txt['badbehavior_httpbl_maxage'] = 'http:BL Maksimum alder';
$txt['badbehavior_httpbl_maxage_desc'] = '(standard 30)';
$txt['badbehavior_reverse_proxy'] = 'Aktiver Reverse Proxy';
$txt['badbehavior_reverse_proxy_header'] = 'Reverse Proxy Header';
$txt['badbehavior_reverse_proxy_header_desc'] = '(standard X-Forwarded-For)';
$txt['badbehavior_reverse_proxy_addresses'] = 'Reverse Proxy Adresser';
$txt['badbehavior_default_on'] = '(standard til)';
$txt['badbehavior_default_off'] = '(standard fra)';
$txt['badbehavior_whitelist_title'] = 'Whitelisting indstillinger';
$txt['badbehavior_postcount_wl'] = 'Whitelist brugere over et vist antal af indlæg';
$txt['badbehavior_postcount_wl_desc'] = '(0 for at deaktivere)';
$txt['badbehavior_ip_wl'] = 'Whitelist efter IP adresse';
$txt['badbehavior_ip_wl_desc'] = 'IP Adresse (CIDR Format 127.0.0.1 eller 127.0.0.0/24)';
$txt['badbehavior_ip_wl_add'] = 'Tilføj en ny IP adresse';
$txt['badbehavior_useragent_wl'] = 'Whitelist efter Bruger Agent streng';
$txt['badbehavior_useragent_wl_desc'] = 'Eksempel: Mozilla/4.0 (Det er mig, lad mig komme ind)';
$txt['badbehavior_useragent_wl_add'] = 'Tilføj en ny Bruger Agent streng';
$txt['badbehavior_url_wl'] = 'Whitelist efter URL';
$txt['badbehavior_url_wl_desc'] = 'Eksempel: /subscriptions.php';
$txt['badbehavior_url_wl_add'] = 'Tilføj en ny URL';
$txt['badbehavior_wl_comment'] = 'Kommentar';

$txt['configure_emptyfield'] = 'Verifikation tomt felt';
$txt['configure_emptyfield_desc'] = '<span class="smalltext">Herunder kan du aktivere metoden for det tomme verifikationsfelt.  Dette vil indsætte et skjult felt der skal være tomt som vil blive brugt til at narre spambots til at sende forkert information. Selvom dette kan bruges alene, er det bedst at aktivere det sammen med en CAPTCHA verifikation.</span>';
$txt['enable_emptyfield'] = 'Aktiver tomt verfikationsfelt';
$txt['configure_verification_means'] = 'Konfigurer verifikationsmetoder';
$txt['setting_qa_verification_number'] = 'Antallet af verificeringsspørgsmål brugeren skal besvare';
$txt['setting_qa_verification_number_desc'] = '(0 for at deaktivere; spørgsmålene angives herunder)';
$txt['configure_verification_means_desc'] = '<span class="smalltext">Herunder kan du justere hvilke anti-spam funktioner du ønsker at have aktiveret hver gang en bruger skal verificere han/hun er et menneske. Bemærk at brugere skal igennem <em>alle</em> verificeringer, så hvis du aktiverer både et verificeringsbillede og en spørgsmål/svar test, skal de igennem begge for at fortsætte.</span>';
$txt['configure_captcha'] = 'Verification CAPTCHA';
$txt['setting_visual_verification_num_chars'] = 'Antal af karakterer i verifikationsbillede';
$txt['setting_visual_verification_type'] = 'Visuel verificeringsbillede der skal vises';
$txt['setting_visual_verification_type_desc'] = 'Jo mere komplekst et billede, jo sværere er det for robotter at komme forbi';
$txt['setting_image_verification_off'] = 'Ingen';
$txt['setting_image_verification_vsimple'] = 'Meget simpel - ren tekst på billedet';
$txt['setting_image_verification_simple'] = 'Simpel - overlappende farverde bogstaver, ingen støj';
$txt['setting_image_verification_medium'] = 'Medium - overlappende farvede bogstaver, med støj/linier';
$txt['setting_image_verification_high'] = 'Høj - hældende bogstaver, en del støj/linier';
$txt['setting_image_verification_extreme'] = 'Ekstrem - vinklede bogstaver, støj, linier, samt blokke';
$txt['setting_image_verification_sample'] = 'Eksempel';
$txt['setup_verification_questions'] = 'Verifikationsspørgsmål';
$txt['setup_verification_questions_desc'] = '<span class="smalltext">Hvis du vil have brugere til at svare på verifikationsspørgsmål for at stoppe spamrobotter, skal du oprette forskellige spørgsmål i tabellen herunder. Du bør vælge relativt nemme spørgsmål; svar er ikke case sensitive. Du kan bruge BBC i spørgsmålet for formatteringens skyld. For at slette et spørgsmål skal du simpelthen slette indholdet af linien.</span>';
$txt['setup_verification_question'] = 'Spørgsmål';
$txt['setup_verification_answer'] = 'Svar';
$txt['setup_verification_add_more'] = 'Tilføj et nyt spørgsmål';
$txt['setup_verification_add_more_answers'] = 'Tilføj et nyt svar';

$txt['moderation_settings'] = 'Moderations-indstillinger';
$txt['setting_warning_enable'] = 'Aktiver advarselssystemet for brugere';
$txt['warning_enable'] = '<strong>Bruger Advarselssystem</strong><br />Denne funktion giver administratorer og moderatorer adgang til at uddele advarsler til brugere - samt at anvende en brugers advarselsniveau til at bestemme hvilke aktioner de har adgang til på forum. Ved aktivering af denne funktion vil en ny tilladelse blive tilgængelig i tilladelses sektionen til at definere hvilket grupper der kan udstede advarsler til brugere. Advarselsniveauer kan justeres i en brugers profil.';
$txt['setting_warning_watch'] = 'Advarselsniveau for bruger overvågning';
$txt['setting_warning_watch_note'] = 'Advarselsniveau hvorefter en bruger er tilføjet til overvågning - 0 for at deaktivere.';
$txt['setting_warning_moderate'] = 'Advarselsniveau for indlægsmoderation';
$txt['setting_warning_moderate_note'] = 'Advarselsniveau hvorefter en brugers indlæg skal modereres - 0 for at deaktivere.';
$txt['setting_warning_mute'] = 'Advarselsniveau for postban';
$txt['setting_warning_mute_note'] = 'Advarselsniveau hvorefter en bruger ikke længere kan poste - 0 for at deaktivere.';
$txt['setting_user_limit'] = 'Maksimal antal af advarselspoint per dag';
$txt['setting_user_limit_note'] = 'Denne værdi er det maksimale antal af advarselspoint en enkelt moderator kan tildele en bruger over en 24 timers periode - 0 for ubegrænset.';
$txt['setting_warning_decrement'] = 'Antal af advarselspoint der er fratrukket efter 24 timer';
$txt['setting_warning_decrement_note'] = 'Gælder kun for brugere der ikke er blevet advaret inden for de seneste 24 timer - 0 for at deaktivere.';
$txt['setting_warning_show'] = 'Brugere som kan se status over advarsler';
$txt['setting_warning_show_note'] = 'Fastsætter hvem der kan se advarselsniveau af brugere på forum.';
$txt['setting_warning_show_mods'] = 'Kun moderatorer';
$txt['setting_warning_show_user'] = 'Moderatorer samt advarede brugere';
$txt['setting_warning_show_all'] = 'Alle brugere';

$txt['signature_settings'] = 'Signatur-indstillinger';
$txt['signature_settings_desc'] = 'Brug indstillinger på denne side til at bestemme hvordan brugersignaturer skal håndteres.';
$txt['signature_settings_warning'] = 'Bemærk at indstillnger som standard ikke omfatter nuværende signaturer.<br /><a class="button_submit" href="%1$s">Kør opgave nu</a>';
$txt['signature_settings_applied'] = 'De opdaterede regler er blevet sat til eksisterende signaturer.';
$txt['signature_enable'] = 'Aktiver signaturer';
$txt['signature_repetition_guests'] = 'Vis signaturer til gæster:';
$txt['signature_repetition_members'] = 'Vis signaturer til brugere:';
$txt['signature_always'] = 'Altid';
$txt['signature_onlyfirst'] = 'Kun den første af hver bruger';
$txt['signature_never'] = 'Aldrig';
$txt['signature_max_length'] = 'Maksimal antal af karakterer';
$txt['signature_max_lines'] = 'Maksimal antal af linjer';
$txt['signature_max_images'] = 'Maksimal antal af billeder';
$txt['signature_max_images_note'] = '(0 for ubegrænset - eksluderer smileys)';
$txt['signature_allow_smileys'] = 'Tillad smileys i signaturer';
$txt['signature_max_smileys'] = 'Maksimal antal af smileys';
$txt['signature_max_image_width'] = 'Maksimal bredde af signatur billeder (i pixels)';
$txt['signature_max_image_height'] = 'Maksimal højde af signatur billeder (i pixels)';
$txt['signature_max_font_size'] = 'Maksimal fontstørrelse tilladt i signaturer (i pixels)';
$txt['signature_bbc'] = 'Aktiverede BBC-tags';

$txt['groups_pm_send'] = 'Brugergrupper der har adgang til at sende personlige beskeder';
$txt['pm_posts_verification'] = 'Antal af indlæg, hvorunder brugere skal bestå verificering for at kunne sende personlige beskeder';
$txt['pm_posts_verification_note'] = '(0 for ubegrænset, administratorer er undtaget)';
$txt['pm_posts_per_hour'] = 'Antal af personlige beskeder en bruger kan sende per time';
$txt['pm_posts_per_hour_note'] = '(0 for ubegrænset, moderatorer er undtaget)';

$txt['custom_profile_title'] = 'Brugerdefinerede profilfelter';
$txt['custom_profile_desc'] = 'Fra denne side kan du oprette dine egne brugerdefinerede profilfelter som passer til dit forums behov';
$txt['custom_profile_active'] = 'Aktiv';
$txt['custom_profile_order'] = 'Feltrækkefølge';
$txt['custom_profile_fieldname'] = 'Feltnavn';
$txt['custom_profile_fieldtype'] = 'Felttype';
$txt['custom_profile_make_new'] = 'Nyt Felt';
$txt['custom_profile_none'] = 'Du har endnu ikke oprettet nogen brugerdefinerede profiler!';
$txt['custom_profile_icon'] = 'Ikon';
$txt['custom_profile_sort'] = 'For at ændre rækkefølgen af brugerdefinerede felter, flyt dem til den ønskede placering.';

$txt['custom_profile_type_text'] = 'Tekst';
$txt['custom_profile_type_url'] = 'Webadresse';
$txt['custom_profile_type_date'] = 'Dato';
$txt['custom_profile_type_email'] = 'E-mail';
$txt['custom_profile_type_color'] = 'Farve';
$txt['custom_profile_type_textarea'] = 'Stor Tekst';
$txt['custom_profile_type_select'] = 'Kombinationsboks';
$txt['custom_profile_type_radio'] = 'Radioboks';
$txt['custom_profile_type_check'] = 'Checkboks';
$txt['custom_profile_reordered'] = 'Profilfelter omorganiseret';

$txt['custom_add_title'] = 'Tilføj profilfelt';
$txt['custom_edit_title'] = 'Rediger profilfelt';
$txt['custom_edit_general'] = 'Visningsindstillinger';
$txt['custom_edit_input'] = 'Input indstillinger';
$txt['custom_edit_advanced'] = 'Avancerede indstillinger';
$txt['custom_edit_name'] = 'Navn';
$txt['custom_edit_desc'] = 'Beskrivelse';
$txt['custom_edit_profile'] = 'Profilsektion';
$txt['custom_edit_profile_desc'] = 'Sektion i profilen feltet redigeres i.';
$txt['custom_edit_profile_none'] = 'Ingen';
$txt['custom_edit_registration'] = 'Vis ved registrering';
$txt['custom_edit_registration_disable'] = 'Nej';
$txt['custom_edit_registration_allow'] = 'Ja';
$txt['custom_edit_registration_require'] = 'Ja, og forlang indtastning';
$txt['custom_edit_display'] = 'Vis i emnevisning';
$txt['custom_edit_memberlist'] = 'Vis på brugerlisten';
$txt['custom_edit_picktype'] = 'Felttype';

$txt['custom_edit_max_length'] = 'Maksimale længde';
$txt['custom_edit_max_length_desc'] = '(0 for ubegrænset)';
$txt['custom_edit_dimension'] = 'Dimensioner';
$txt['custom_edit_dimension_row'] = 'Rækker';
$txt['custom_edit_dimension_col'] = 'Kolonner';
$txt['custom_edit_bbc'] = 'Tillad BBC';
$txt['custom_edit_options'] = 'Valgmuligheder';
$txt['custom_edit_options_desc'] = 'Lad valgboksen være blank for at fjerne. Radioknapper vælger standardindstillinger.';
$txt['custom_edit_options_more'] = 'Mere';
$txt['custom_edit_options_no_default'] = 'Sæt ikke en standard værdi.';
$txt['custom_edit_default'] = 'Standard tilstand';
$txt['custom_edit_default_value'] = 'Standard Værdi';
$txt['custom_edit_active'] = 'Aktiv';
$txt['custom_edit_active_desc'] = 'Hvis ikke valgt vil dette felt ikke blive vist til nogen.';
$txt['custom_edit_privacy'] = 'Privatliv';
$txt['custom_edit_privacy_desc'] = 'Hvem kan se og redigere dette felt.';
$txt['custom_edit_privacy_all'] = 'Brugere kan se dette felt, ejere kan redigere det';
$txt['custom_edit_privacy_see'] = 'Brugere kan se dette felt, kun administratorer kan redigere det';
$txt['custom_edit_privacy_owner'] = 'Brugere kan ikke se dette felt; ejer og administratorer kan redigere det';
$txt['custom_edit_privacy_none'] = 'Dette felt er kun synligt for administratorer';
$txt['custom_edit_can_search'] = 'Søgbar';
$txt['custom_edit_can_search_desc'] = 'Skal dette felt inkluderes i søgning fra brugerlisten?';
$txt['custom_edit_mask'] = 'Input maskering';
$txt['custom_edit_mask_desc'] = 'For tekstfelter kan en input maskering vælges for at validere dataene.';
$txt['custom_edit_mask_email'] = 'Gyldig e-mail';
$txt['custom_edit_mask_number'] = 'Numerisk';
$txt['custom_edit_mask_nohtml'] = 'Ingen HTML';
$txt['custom_edit_mask_regex'] = 'Regulært udtryk (avanceret)';
$txt['custom_edit_enclose'] = 'Linjebrud i bruger input (Valgfri)';
$txt['custom_edit_enclose_desc'] = 'Vi anbefaler <strong>på det kraftigste</strong> brugen af en maskering til at validere input givet af brugeren.';

$txt['custom_edit_placement'] = 'Vælg placering';
$txt['custom_edit_placement_standard'] = 'Standard (med titel)';
$txt['custom_edit_placement_withicons'] = 'Med ikoner';
$txt['custom_edit_placement_abovesignature'] = 'Ovenover signaturen';
$txt['custom_edit_placement_aboveicons'] = 'Ovenstående Ikoner (ingen titel)';
$txt['custom_profile_placement'] = 'Placering';
$txt['custom_profile_placement_standard'] = 'Standard';
$txt['custom_profile_placement_withicons'] = 'Med ikoner';
$txt['custom_profile_placement_abovesignature'] = 'Ovenover signaturen';
$txt['custom_profile_placement_aboveicons'] = 'Ovenstående Ikoner';

// Use numeric entities in the string below!
$txt['custom_edit_delete_sure'] = 'Er du sikker på du vil slette dette felt? Alle relaterede brugerdata vil blive slettet!';

$txt['standard_profile_title'] = 'Standard profilfelter';
$txt['standard_profile_field'] = 'Felt';

$txt['core_settings_welcome_msg'] = 'Velkommen til dit nye forum';
$txt['core_settings_welcome_msg_desc'] = 'For at få dig i gang foreslår vi dig at vælge hvilke af ElkArte\'s grundlæggende funktioner du ønsker at aktivere. Vi anbefaler kun at aktivere de funktionen du har brug for.'; // don't scream from the beginning :P
$txt['core_settings_item_cd'] = 'Kalender';
$txt['core_settings_item_cd_desc'] = 'Aktivering af denne  funktion vil åbne et udvalg af indstillinger for at give dine brugere adgang til kalenderen, tilføje og gennemse begivenheder, se brugeres fødselsdage i kalenderen og meget, meget mere.';
$txt['core_settings_item_dr'] = 'Kladder';
$txt['core_settings_item_dr_desc'] = 'Aktivering af denne funktion vil tillade brugere at gemme kladder af deres indlæg så de kan færdigøre dem senere.';
$txt['core_settings_item_cp'] = 'Avancerede profilfelter';
$txt['core_settings_item_cp_desc'] = 'Dette gør dig i stand til at skjule standard profilfelter, tilføje profilfelter til registreringen, og oprette nye profilfelter til dit forum.';
$txt['core_settings_item_ih'] = 'Integrations Hooks administration';
$txt['core_settings_item_ih_desc'] = 'Denne funktion tillader dig at aktivere/deaktivere integrations hooks som er tilføjet af addons. Ændring af hooks kan forhindre dit forum i at fungerer korrekt, så brug denne funktion kun hvis du ved hvad du laver.';
$txt['core_settings_item_k'] = 'Karma';
$txt['core_settings_item_k_desc'] = 'Karma er en funktion der viser populariteten af et medlem. Medlemmer kan, hvis tilladt, give \'god\' eller \'dårlig\' karma til andre medlemmer, hvilket er hvordan deres popularitet beregnes.';
$txt['core_settings_item_pe'] = 'Indlæg via email administration';
$txt['core_settings_item_pe_desc'] = 'Dette vil tillade brugere på dit forum at svare på email meddelelser og personlige beskeder og lade disse email svar indgå direkte som et svar på et indlæg eller personlig besked. Dette fil give en velkendt mailliste følelse. Brug af denne funktion kræver yderligere opsætninger af din hostudbyder.';
$txt['core_settings_item_l'] = 'Likes';
$txt['core_settings_item_l_desc'] = 'Likes er en funktion der tillader brugere at like et indlæg for at vise deres godkendelse og popularitet af indholdet af beskeden.';
$txt['core_settings_item_ml'] = 'Moderation, administration- og brugerlogs';
$txt['core_settings_item_ml_desc'] = 'Aktiver moderations- og administrationslogs for at have en revision af alle nøglehandlinger der bliver foretaget i dit forum. Tillader også forum-moderatorer at se en historie over vigtige ændringer, brugere foretager sig i deres profil.';
$txt['core_settings_item_pm'] = 'Moderation af indlæg';
$txt['core_settings_item_pm_desc'] = 'Moderation af indlæg gør dig i stand til at vælge grupper samt boards hvor indlæg skal godkendes før de bliver offentliggjort. Så snart du aktiverer denne funktion, skal du huske at besøge sektionen &quot;Tilladelser&quot; for at fastlægge de relevante tilladelser.';
$txt['core_settings_item_ps'] = 'Betalt abonnement';
$txt['core_settings_item_ps_desc'] = 'Betalte abonnementer giver brugere en mulighed for at betale et kontingent for at skifte brugergrupper på forum og derved at ændre deres adgangsrettigheder.';
$txt['core_settings_item_rg'] = 'Rapportgenerering';
$txt['core_settings_item_rg_desc'] = 'Denne administrationsfunktion tillader generering af rapporter (som kan udskrives) for at præsentere dit aktuelle forumsetup på en mere læsbar maner - især brugbart til store fora.';
$txt['core_settings_item_sp'] = 'Søgemaskine-sporing';
$txt['core_settings_item_sp_desc'] = 'Aktivering af denne funktion vil tillade administratorer at spore søgemaskiner efterhånden som de indekserer dit forum.';
$txt['core_settings_item_w'] = 'Advarselssystem';
$txt['core_settings_item_w_desc'] = 'Dette system tillader administratorer og moderatorer at udstede advarsler til brugere, og kan automatisk fjerne brugerrettigheder når deres advarselsniveau stiger. For at få fuld udbytte af dette system, skal &quot;Indlægsmoderation&quot; være aktiveret.';
$txt['core_settings_switch_on'] = 'Klik for at aktivere';
$txt['core_settings_switch_off'] = 'Klik for at deaktivere';
$txt['core_settings_enabled'] = 'Aktiveret';
$txt['core_settings_disabled'] = 'Deaktiveret';

$txt['languages_lang_name'] = 'Sprognavn';
$txt['languages_locale'] = 'Lokalitet';
$txt['languages_default'] = 'Standard';
$txt['languages_users'] = 'Brugere';
$txt['language_settings_writable'] = 'Advarsel: Settings.php er ikke skrivbar, så standard sprogindstillingen kan ikke gemmes.';
$txt['edit_languages'] = 'Rediger sprog';
$txt['lang_file_not_writable'] = '<strong>Advarsel:</strong> Den primære sprogfil (%1$s) er ikke skrivbar. Du skal gøre denne skrivbar, før du kan foretage nogle ændringer.';
$txt['lang_entries_not_writable'] = '<strong>Advarsel:</strong> Sprogfilen du ønsker at redigere (%1$s), er ikke skrivbar. Den skal gøres skrivbar, før du kan foretage nogle ændringer.';
$txt['languages_ltr'] = 'Højre til Venstre';

$txt['add_language'] = 'Tilføj sprog';
$txt['add_language_elk'] = 'Download fra ElkArte Sprog Repository';
$txt['add_language_elk_browse'] = 'Skriv navnet på sproget der skal søges efter eller efterlad feltet blank for at søge efter alle sprog.';
$txt['add_language_elk_install'] = 'Installer';
$txt['add_language_elk_found'] = 'Følgende sprog blev fundet. Klik på installer linket ved siden af sproget du ønsker at installere og du vil så blive dirigeret videre til pakkemanageren for at installere det.';
$txt['add_language_error_no_response'] = 'ElkArte hjemmesiden svarer ikke. Prøv igen senere.';
$txt['add_language_error_no_files'] = 'Ingen filer kunne findes.';
$txt['add_language_elk_desc'] = 'Beskrivelse';
$txt['add_language_elk_utf8'] = 'UTF-8';
$txt['add_language_elk_version'] = 'Version';

$txt['edit_language_entries_primary'] = 'Herunder er de primære sprogindstillinger for denne sprogpakke.';
$txt['edit_language_entries'] = 'Rediger sprogtekster';
$txt['edit_language_entries_file'] = 'Vælg indtastninger der skal redigeres';
$txt['languages_dictionary'] = 'Ordbog';
$txt['languages_spelling'] = 'Stavekontrol';
$txt['languages_for_pspell'] = 'Dette er for <a href="http://www.php.net/function.pspell-new" target="_blank" class="new_win">pSpell</a> - hvis installeret';
$txt['languages_rtl'] = 'Aktiver &quot;højre til venstre&quot; tilstand';

$txt['lang_file_desc_index'] = 'Generelle strenge';
$txt['lang_file_desc_EmailTemplates'] = 'E-mail skabeloner';

$txt['languages_download'] = 'Download sprogpakke';
$txt['languages_download_note'] = 'Denne side viser alle filer der er indeholdt i sprogpakken og brugbar information om hver af dem. Alle filer der har deres associereede checkboks markeret vil blive kopieret.';
$txt['languages_download_info'] = '<strong>Bemærk:</strong>
	<ul class="normallist">
		<li>Filstatus &quot;Ikke Skrivbar&quot; betyder at systemet ikke kan kopiere denne fil til mappen og at du skal gøre destinationen skrivbar enten ved at bruge en FTP klient eller ved at udfylde detaljerne i bunden af siden.</li>
		<li>Versionsinformationer for en fil viser den nyeste forum version som den blev opdateret til. Hvis den er indikeret i grøn så er den af nyere version end du har, gul indikerer at det er den samme version som du benytter, rød indkierer at du har en nyere version installeret end der er inkluderet i pakken.</li>
		<li>I tilfælde af at en fil allerede eksisterer på dit forum, vil kolonnen &quot;Eksisterer Allerede&quot; have en af to værdier: &quot;Identisk&quot; indikerer at filen der allerede er installeret er identisk med den inkluderede, og behøver ikke at overskrive. &quot;Anderledes&quot; betyder at indhold er forskellig og at overskrive er sandsynligvis den bedste løsning.</li>
	</ul>';

$txt['languages_download_main_files'] = 'Primære filer';
$txt['languages_download_theme_files'] = 'Tema-relaterede filer';
$txt['languages_download_filename'] = 'Filnavn';
$txt['languages_download_dest'] = 'Destination';
$txt['languages_download_writable'] = 'Skrivbar';
$txt['languages_download_version'] = 'Version';
$txt['languages_download_older'] = 'Du har allerede en nyere version af denne fil installeret, overskrivning er ikke anbefalet.';
$txt['languages_download_exists'] = 'Eksisterer allerede';
$txt['languages_download_exists_same'] = 'Identisk';
$txt['languages_download_exists_different'] = 'Forskellig';
$txt['languages_download_copy'] = 'Kopier';
$txt['languages_download_not_chmod'] = 'Du kan ikke fortsætte med installationen før alle de valgte filer der skal kopieres er skrivbare.';
$txt['languages_download_illegal_paths'] = 'Pakke indeholder ugyldige stier - Kontakt venligst ElkArte';
$txt['languages_download_complete'] = 'Installationen er Færdig';
$txt['languages_download_complete_desc'] = 'Sprogpakke blev korrekt installeret. Klik <a href="%1$s">her for at returnere til sprogsiden</a>';
$txt['languages_delete_confirm'] = 'Er du sikker på du ønsker at slette dette sprog?';

$txt['setting_frame_security'] = 'Frame Sikkerhedsindstillinger';
$txt['setting_frame_security_SAMEORIGIN'] = 'Tillad fra samme oprindelse';
$txt['setting_frame_security_DENY'] = 'Nægt alle frames';
$txt['setting_frame_security_DISABLE'] = 'Deaktiveret';
