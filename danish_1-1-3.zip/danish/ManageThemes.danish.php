<?php
// Version: 1.1; ManageThemes

$txt['themeadmin_explain'] = 'Temaer skaber det anderledes udseende og fornemmelse på dit forum. De globale tema indstillinger lader site administratorer vælge et tema som standard site tema. Administratorer kan også vælge at lade brugere selv vælge hvilken af de installerede temaer de vil bruge. Sektionen for at installere et nyt tema er stedet for administratorer at installere nye temaer.';
$txt['themeadmin_manage'] = 'Administrer og installer';
$txt['theme_forum_theme'] = 'Globale tema indstillinger';
$txt['theme_allow'] = 'Tillad medlemmer at vælge deres egne temaer.';
$txt['theme_guests'] = 'Overordnet forum standard tema:';
$txt['theme_select'] = 'vælg...';
$txt['theme_reset'] = 'Nulstil alle brugere til at benytte det følgende tema:';
$txt['theme_nochange'] = 'Ingen ændring';
$txt['theme_forum_default'] = 'Forumstandard';

$txt['theme_remove'] = 'Afinstaller';
$txt['theme_remove_confirm'] = 'Er du sikker på du vil afinstallere dette tema?';

$txt['theme_install'] = 'Installer et nyt tema';
$txt['theme_install_file'] = 'Fra et lokalt arkiv: (eks .zip eller .tar.gz)';
$txt['theme_install_dir'] = 'Fra en mappe på serveren:';
$txt['theme_install_error'] = 'Mappen for det tema eksisterer ikke, eller indeholder ikke et tema.';
$txt['theme_install_write_error'] = 'Tema mappen skal være skrivbar for at fortsætte.';
$txt['theme_install_go'] = 'Installer';
$txt['theme_install_new'] = 'Lav en kopi af ElkArte standardtema kaldet:';
$txt['theme_install_new_confirm'] = 'Er du sikker på du ønsker at installere dette nye tema?';
$txt['theme_install_writable'] = 'Advarsel - du kan ikke oprette eller inistallere et nyt tema da tema mappen ikke er skrivbar.';
$txt['theme_install_general'] = 'Temaet ser ikke ud til at være hvor det skal, kontroller at informationerne du angav er korrekte.';
$txt['theme_installed'] = 'Installeret med succes';
$txt['theme_installed_message'] = 'blev installeret med succes.';

$txt['theme_pick'] = 'Vælg et tema...';
$txt['theme_preview'] = 'Forhåndsvis temaet';
$txt['theme_set'] = 'Anvend dette tema';
$txt['theme_user'] = 'person anvender dette tema.';
$txt['theme_users'] = 'folk anvender dette tema.';
$txt['theme_pick_variant'] = 'Vælg variant:';

$txt['theme_edit'] = 'Rediger tema';
$txt['theme_edit_style'] = 'Rediger de forskellige stylesheet. (farver, fonte mv.)';
$txt['theme_edit_index'] = 'Ændrer index skabelonen. (den primære skabelon)';
$txt['theme_edit_no_save'] = 'Denne fil kan ikke gemmes da den ikke er skrivbar. Kontroller at den følgende fil er chmod 777 og har de korrekte tilladelser';
$txt['theme_edit_save'] = 'Gem ændringerne';
$txt['theme_edit_not_writable'] = 'Ikke-skrivbar';

$txt['theme_global_description'] = 'Dette er standard temaet, som betyder at dit tema vil ændre sig sammen med administratorers indstillinger og boardet du læser.';

$txt['theme_url_config'] = 'Tema webadresser og konfiguration';
$txt['theme_variants'] = 'Temavarianter';
$txt['theme_options'] = 'Temaindstillinger og preferencer';
$txt['actual_theme_name'] = 'Dette temas navn: ';
$txt['actual_theme_dir'] = 'Dette temas mappe: ';
$txt['actual_theme_url'] = 'Dette temas webadresse: ';
$txt['actual_images_url'] = 'Dette temas webadresse til billeder (ikoner m.m.): ';

$txt['theme_variants_default'] = 'Standard tema variant:';
$txt['theme_variants_user_disable'] = 'Deaktiver brugervalg af varianter.';

$txt['site_slogan'] = 'Side slogan:';
$txt['site_slogan_desc'] = '(Tilføj dit eget slogan her.)';
$txt['header_layout'] = 'Header layout:';
$txt['header_layout_desc'] = '(Denne indstilling lader dig vælge en af tre layout for header.)';
$txt['header_layout_default_name'] = 'Standard:';
$txt['header_layout_default_desc'] = 'Logoet er placeret til højre og navnet på forum til venstre.';
$txt['header_layout_logo_only_name'] = 'Kun logo:';
$txt['header_layout_logo_only_desc'] = 'Kun logoet er vist, i en centreret position.';
$txt['header_layout_inverted_name'] = 'Logo til venstre:';
$txt['header_layout_inverted_desc'] = 'Svarende til standard, men logo og navn er byttet om (dvs. navn til højre, og logo til venstre)';
$txt['header_layout_default'] = 'Standard';
$txt['header_layout_logo_only'] = 'Kun logo';
$txt['header_layout_inverted'] = 'Logo til venstre';
$txt['forum_width'] = 'Forum bredde:';
$txt['forum_width_desc'] = '(Indstil forum bredde. Eksempler: 950px, 80%, 1240px)';

$txt['enable_news'] = 'Nyhedslinje i forum header:';
$txt['enable_news_off'] = 'Fra';
$txt['enable_news_random'] = 'Tilfældig';
$txt['enable_news_fader'] = 'Fortoning';
$txt['enable_news_off_name'] = 'Fra:';
$txt['enable_news_off_desc'] = 'Ingen nyheder vist.';
$txt['enable_news_random_name'] = 'Tilfældig:';
$txt['enable_news_random_desc'] = 'Vis en tilfældig nyhed.';
$txt['enable_news_fader_name'] = 'Fortoning:';
$txt['enable_news_fader_desc'] = 'Alle nyheder er vist i rækkefølge.';

$txt['show_group_key'] = 'Vis gruppenøgle på boardindeks.';
$txt['additional_options_collapsible'] = 'Aktiver sammenfoldelige yderligere indstillinger for indlæg.';
$txt['who_display_viewing'] = 'Vis hvem der viser boardindeks og indlæg:';
$txt['who_display_viewing_off'] = 'Vis ikke';
$txt['who_display_viewing_numbers'] = 'Vis kun numre';
$txt['who_display_viewing_names'] = 'Vis medlemsnavne';
$txt['show_stats_index'] = 'Vis statistikker på boardindeks.';
$txt['latest_members'] = 'Vis nyeste bruger på boardindeks.';
$txt['last_modification'] = 'Vis seneste redigeringsdato på ændrede indlæg.';
$txt['user_avatars'] = 'Vis bruger avatarer i emnevisning.';
$txt['member_list_bar'] = 'Vis medlemslisten på boardindekset';
$txt['current_pos_text_img'] = 'Hvis aktuel position i forum som et link i stedet for tekst.';
$txt['show_view_profile_button'] = 'Vis profilknappen under indlæg.';
$txt['enable_mark_as_read'] = 'Aktiver og vis \'Marker som læst\' knapper.';
$txt['header_logo_url'] = 'Logo billede URL:';
$txt['header_logo_url_desc'] = '(Efterlad blank for at vise forum navn eller standard logo.)';

$txt['recent_post_topics'] = 'Vis nye indlæg eller nye emner på board indeks.';
$txt['show_recent_topics'] = 'Vis nye emner';
$txt['show_recent_posts'] = 'Vis nye indlæg';
$txt['number_recent_posts'] = 'Antal af nye indlæg eller emner der skal vises på board indeks:';
$txt['number_recent_posts_desc'] = '(For at deaktivere nye indlæg/emner bar sæt denne værdi til nul.)';
$txt['hide_post_group'] = 'Skjul indlægsgruppe titler for grupperede brugere.';
$txt['hide_post_group_desc'] = '(Aktiveres dette, vil brugerers indlægsgruppe tittel ikke blive vist i emnevisning hvis de ikke er knyttet til en indlægsbaseret gruppe.)';

$txt['theme_options_defaults'] = 'Dette er standard værdier for nogle medlemspecifikke indstillinger. Ændring af disse vil kun vedrøre nye medlemmer og gæster.';
$txt['theme_options_title'] = 'Ændrer eller nulstil standard funktioner';

$txt['themeadmin_title'] = 'Tema administration og indstillinger';
$txt['themeadmin_description'] = 'Her kan du ændre indstillingerne for dine temaer, opdatere valg af temaer, nulstille medlemmers valg, og meget andet.';
$txt['themeadmin_admin_desc'] = 'Temaer skaber det anderledes udseende og fornemmelse på dit forum. Tema administration og indstillinger, lader dig installere nye site temaer, ændre standard temaet, nulstille alle brugere til at bruge et specifikt tema, og vælge andre indstillinger relateret til tema valg. Husk at kontrollere tema indstillinger til de forskellige temaer for deres individuelle layoutindstillinger.';
$txt['themeadmin_list_desc'] = 'I tema indstillinger området kan du se en liste over de temaer du har indstillaret, ændre stien og indstillinger til dem, og afinstallere dem.';
$txt['themeadmin_reset_desc'] = 'I brugervalg området kan du ændre temaspecifikke indstillinger som påvirker alle brugere. Du vil kun se de temaer som har deres egne indstillinger.';
$txt['themeadmin_edit_desc'] = 'I rediger tema området kan du ændre i stylesheet og kildekoden på dine indstallerede temaer. Du skal bruge en grundlæggende forståelse for CSS og PHP for effektivt at ændre et tema og ikke at ødelægge dit forum på samme tid.';
$txt['themeadmin_modify_styles'] = 'Changing a themes style is risky so be certain of what you are doing. Always have a backup copy of the theme directory that you are working in to use to recover from an error with. For help with this before you start, visit the <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">ElkArte Community</a>.';

$txt['themeadmin_list_heading'] = 'Temaindstillinger';
$txt['themeadmin_list_tip'] = 'Layoutindstillinger kan være forskellige for de indstallerede temaer. Rediger de indstallerede temaer for at ændre deres individuelle indstillinger, ændre mappen eller URL indstillinger til dem, eller finde andre indstillinger.';
$txt['themeadmin_list_theme_dir'] = 'Tema mappe: (skabeloner)';
$txt['themeadmin_list_invalid'] = '(Advarsel! stien er ikke korrekt.)';
$txt['themeadmin_list_theme_url'] = 'URL til ovenstående mappe:';
$txt['themeadmin_list_images_url'] = 'URL til billede mappen:';
$txt['themeadmin_list_reset'] = 'Nulstil webadresser og mapper';
$txt['themeadmin_list_reset_dir'] = 'Grundlæggende sti til tema mappen:';
$txt['themeadmin_list_reset_url'] = 'Grundlæggende URL til den samme mappe:';
$txt['themeadmin_list_reset_go'] = 'Forsøg at nulstille alle temaer';

$txt['themeadmin_reset_tip'] = 'Hvert tema kan have deres egne indstillinger som brugere kan vælge. Disse inkluderer mulgheder såsom &quot;hurtig svar&quot;, avatarer, signaturer, layout indstillinger og andre lignende indstillinger.  Her kan du ændre standardindstillinger eller nulstille indstillinger for alle brugere.<br /><br />Husk at: Et tema kan være designet med nogle standardindstillinger. I hvilket tilfælde vil du ikke se disse indstillinger.';
$txt['themeadmin_reset_defaults'] = 'Konfigurer indstillinger for gæster og nye brugere for dette tema';
$txt['themeadmin_reset_defaults_current'] = 'indstillinger er sat.';
$txt['themeadmin_reset_members'] = 'Skift nuværende indstillinger for alle medlemmer der anvender dette tema';
$txt['themeadmin_reset_remove'] = 'Fjern alle medlemmers indstillinger, og brug standardindstillingerne';
$txt['themeadmin_reset_remove_current'] = 'medlemmer benytter i øjeblikket deres egne indstillinger.';
// Don't use entities in the below string.
$txt['themeadmin_reset_remove_confirm'] = 'Er du sikker på du vil fjerne alle temaindstillinger?\\n Dette nulstiller måske også brugerdefinerede profilfelter.';
$txt['themeadmin_reset_options_info'] = 'Indstillingerne herunder vil nulstille indstillinger for <em>alle</em>.  For at ændre en indstilling, vælg &quot;skift&quot; i boksen ved siden af den indstilling, og vælg da en værdi for den.  For at bruge standard, vælg &quot;standard&quot;.  Ellers vælg, &quot;bibehold&quot; for at beholde som den er.';
$txt['themeadmin_reset_options_change'] = 'Skift';
$txt['themeadmin_reset_options_none'] = 'Bibehold';
$txt['themeadmin_reset_options_default'] = 'Standard';

$txt['themeadmin_edit_browse'] = 'Gennemse skabeloner og filer i dette tema.';
$txt['themeadmin_edit_style'] = 'Rediger dette temas stylesheets.';
$txt['themeadmin_edit_copy_template'] = 'Kopier en skabelon fra teamet som dette tema er baseret på.';
$txt['themeadmin_edit_exists'] = 'eksisterer allerede';
$txt['themeadmin_edit_do_copy'] = 'kopier';
$txt['themeadmin_edit_copy_warning'] = 'Når systemet skal bruge en skabelon eller sprogfil som ikke er inkluderet i det aktuelle tema, vil den lede i temaet den er baseret på, eller standardtemaet.<br />Med mindre du har behov for at modificere en skabelon, er det bedre ikke at kopiere den.';
$txt['themeadmin_edit_copy_confirm'] = 'Er du sikker på du vil kopiere denne skabelon?';
$txt['themeadmin_edit_overwrite_confirm'] = 'Er du sikker på du vil kopiere denne skabelon over den der allerede eksisterer?\nDette vil OVERKSRIVE alle ændringer du har lavet';
$txt['themeadmin_edit_no_copy'] = '<em>(Kan ikke kopiere)</em>';
$txt['themeadmin_edit_filename'] = 'Filnavn';
$txt['themeadmin_edit_modified'] = 'Sidst ændret';
$txt['themeadmin_edit_size'] = 'Størrelse';
$txt['themeadmin_edit_error'] = 'Filen du forsøgte at gemme, genererede følgende fejl:';
$txt['themeadmin_edit_on_line'] = 'Startende på linje:';
$txt['themeadmin_edit_preview'] = 'Udkast';
$txt['themeadmin_selectable'] = 'Temaer som brugeren har adgang til at vælge:';
$txt['themeadmin_themelist_link'] = 'Vis listen over indstallerede temaer';

// Strings for the variants
$txt['variant_light'] = 'ElkArte Light';
$txt['variant_besocial'] = 'ElkArte Vær Social!';
