<?php
// Version: 1.1; ManageSmileys

$txt['smiley_sets_save'] = 'Gem ændringerne';
$txt['smiley_sets_add'] = 'Nyt smileysæt';
$txt['smiley_sets_delete'] = 'Slet markerede';
$txt['smiley_sets_confirm'] = 'Er du sikker på at du vil fjerne disse smileysæt?\\n\\nBemærk: Dette vil ikke fjerne ikonerne, kun valgmulighederne.';
$txt['smiley_sets_none'] = 'Der er i øjeblikket ikke nogen smileysæt.';

$txt['setting_smiley_sets_default'] = 'Standard smileysæt';
$txt['setting_smiley_sets_enable'] = 'Aktiver frit valg af smileysæt for medlemmer';
$txt['setting_smiley_enable'] = 'Aktiver brugerdefinerede smileys';
$txt['setting_smileys_url'] = 'Basis webadresse for alle smileysæt';
$txt['setting_smileys_dir'] = 'Absolut sti til alle smileysæt';
$txt['setting_messageIcons_enable'] = 'Aktiver brugerdefinerede indlægsikoner';
$txt['setting_messageIcons_enable_note'] = '(ellers vil standard indlægsikonerne blive anvendt.)';
$txt['groups_manage_smileys'] = 'Grupper med tilladelse til at administrere smileys og indlægsikoner';

$txt['smiley_sets_name'] = 'Navn';
$txt['smiley_sets_url'] = 'Webadresse';
$txt['smiley_sets_default'] = 'Standard';

$txt['smileys_add_method'] = 'Billedkilde';
$txt['smileys_add_existing'] = 'Benyt eksisterende fil';
$txt['smileys_add_upload'] = 'Upload ny smiley';
$txt['smileys_add_upload_choose'] = 'Fil der skal uploades';
$txt['smileys_add_upload_choose_desc'] = 'Billedet der skal anvendes af alle smileysæt.';
$txt['smileys_add_upload_all'] = 'Samme billede for alle sæt';
$txt['smileys_add_upload_for1'] = 'Billede for ';
$txt['smileys_add_upload_for2'] = 'sættet';

$txt['smileys_enable_note'] = '(ellers, vil standard smileysættet blive anvendt.)';
$txt['smileys_code'] = 'Kode';
$txt['smileys_filename'] = 'Filnavn';
$txt['smileys_description'] = 'Værktøjstip eller beskrivelse';
$txt['smileys_remove'] = 'Fjern';
$txt['smileys_save'] = 'Gem ændringerne';
$txt['smileys_delete'] = 'Slet smiley';
// Don't use entities in the below string.
$txt['smileys_delete_confirm'] = 'Er du sikker på du ønsker at slette denne smiley?';
$txt['smileys_with_selected'] = 'Med valgte';
$txt['smileys_make_hidden'] = 'Skjul denne';
$txt['smileys_show_on_post'] = 'Vis i postformular';
$txt['smileys_show_on_popup'] = 'Vis i popup';

$txt['smiley_settings_explain'] = 'Ændringerne her tillader dig at ændre standard smileysættet, tillader folk at vælge deres egne smileys, og redigerer filplacering og konfigurationsdata.';
$txt['smiley_editsets_explain'] = 'Smileysæt er grupper af smileys, som dine brugere kan vælge mellem. For eksempel, kan du have gule og røde smileys.<br />Her kan du ændre navn og sti til hvert smileysæts placering - husk dog at alle sæt deler de samme smileys.';
$txt['smiley_editsmileys_explain'] = 'Du kan ændre dine smileys her ved at klikke på den smiley du ønsker at modificere. Husk at alle disse smileys skal eksistere i alle sæt ellers vil nogle smileys ikke vises. Glem ikke at gemme dine ændringer når du er færdig med at redigere.';
$txt['smiley_setorder_explain'] = 'Ændrer rækkefølgen på smileys her.';
$txt['smiley_addsmiley_explain'] = 'Her kan du tilføje ny smileys - enten fra en eksisterende fil eller ved at uploade nye.';

$txt['smiley_set_select_default'] = 'Standard smileysæt';
$txt['smiley_set_new'] = 'Opret nyt smileysæt';
$txt['smiley_set_modify_existing'] = 'Modificer eksisterende smileysæt';
$txt['smiley_set_modify'] = 'Rediger';
$txt['smiley_set_import_directory'] = 'Importer smileys der allerede er i denne mappe';
$txt['smiley_set_import_single'] = 'Der er en smiley i dette sæt som endnu ikke er importeret. Klik';
$txt['smiley_set_import_multiple'] = 'Der er %1$d smileys i mappen som endnu ikke er importeret. Klik';
$txt['smiley_set_to_import_single'] = 'for at importere den nu.';
$txt['smiley_set_to_import_multiple'] = 'for at importere dem nu.';

$txt['smileys_location'] = 'Lokation';
$txt['smileys_location_form'] = 'Postformular';
$txt['smileys_location_hidden'] = 'Skjult';
$txt['smileys_location_popup'] = 'Popup';
$txt['smileys_modify'] = 'Rediger';
$txt['smileys_not_found_in_set'] = 'Smiley ikke fundet i sætte(ne)';
$txt['smileys_default_description'] = '(Indsæt en beskrivelse)';
$txt['smiley_new'] = 'Tilføj ny smiley';
$txt['smiley_modify_existing'] = 'Ændrer smiley';
$txt['smiley_preview'] = 'Udkast';
$txt['smiley_preview_using'] = 'ved anvendelse af smileysættet';
$txt['smileys_confirm'] = 'Er du sikker på at du vil fjerne disse smileys?\\n\\nBemærk: Dette vil ikke fjerne ikonerne, kun valgmulighederne.';
$txt['smileys_location_form_description'] = 'Disse smileys vil blive vist over skrivefeltet, når der postes et nyt forumindlæg eller en ny personlig besked.';
$txt['smileys_location_popup_description'] = 'Disse smileys vil blive vist i en popup, der dukker op når en bruger har klikket på \'[flere]\'';
$txt['smileys_move_select_destination'] = 'Vælg destinationen for smileyen';
$txt['smileys_move_select_smiley'] = 'Vælg den smiley du vil flytte eller hiv den til den ønskede lokation';
$txt['smileys_move_here'] = 'Flyt smileyen til denne lokation';
$txt['smileys_no_entries'] = 'Der er i øjeblikket ikke konfigureret nogen smileys.';
$txt['smileys_moved_done'] = 'Smiley blev flyttet';
$txt['smileys_moved_fail'] = 'Kunne ikke flytte smiley';

$txt['icons_edit_icons_explain'] = 'Her kan du ændre hvilke indlægsikoner der skal være tilgængelige i alle boards. Du kan tilføje, ændre og fjerne ikoner, såvel som begrænse brugen i visse boards.';
$txt['icons_edit_icons_all_boards'] = 'Tilgængelig i alle boards';
$txt['icons_board'] = 'Board';
$txt['icons_confirm'] = 'Er du sikker på du vil fjerne disse ikoner?\\n\\nBemærk at dette kun vil forhindre nye indlæg og personlige beskeder fra at indeholde ikonerne, billederne bliver ikke slettet.';
$txt['icons_add_new'] = 'Tilføj nyt ikon';

$txt['icons_edit_icon'] = 'Rediger beskedsikon';
$txt['icons_new_icon'] = 'Ny beskedsikon';
$txt['icons_location_first_icon'] = 'Som første ikon';
$txt['icons_location_after'] = 'Efter';
$txt['icons_filename_all_png'] = 'Alle filer skal være &quot;png&quot; filer';
$txt['icons_no_entries'] = 'Der er i øjeblikket ikke konfigureret nogen indlægsikoner.';
$txt['icons_reordered'] = 'Beskedsikoner er blevet omorganiseret';
$txt['icons_reorder_note'] = 'Du kan ændre rækkefølgen på beskedsikoner ved at flytte dem til en ny lokation i listen.';