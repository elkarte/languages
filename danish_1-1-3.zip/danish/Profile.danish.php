<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Du har ikke tilladelse til at ændre denne persons profil.';
$txt['website_title'] = 'Webside titel';
$txt['website_url'] = 'Webside adresse';
$txt['signature'] = 'Signatur';
$txt['profile_posts'] = 'Indlæg';

$txt['profile_info'] = 'Yderligere detaljer';
$txt['profile_contact'] = 'Kontakt information';
$txt['profile_moderation'] = 'Moderation information';
$txt['profile_more'] = 'Signatur';
$txt['profile_attachments'] = 'Seneste Vedhæftninger';
$txt['profile_attachments_no'] = 'Der er ikke nogen vedhæftninger fra denne bruger';
$txt['profile_recent_posts'] = 'Nylige indlæg';
$txt['profile_posts_no'] = 'Der er ikke nogen indlæg fra denne bruger';
$txt['profile_topics'] = 'Seneste Emner';
$txt['profile_topics_no'] = 'Der er ikke nogen emner fra denne bruger';
$txt['profile_buddies_no'] = 'Du har ikke sat nogen venner';
$txt['profile_user_info'] = 'Bruger Info';
$txt['profile_contact_no'] = 'Der er ikke nogen kontakt information for denne bruger';
$txt['profile_signature_no'] = 'Der er ikke nogen signatur for denne bruger';
$txt['profile_additonal_no'] = 'Der er ikke yderligere information for denne bruger';
$txt['profile_user_summary'] = 'Profil';
$txt['profile_action'] = 'Aktuel';
$txt['profile_recent_activity'] = 'Seneste Aktivitet';
$txt['profile_activity'] = 'Aktivitet';
$txt['profile_loadavg'] = 'Prøv venligst igen senere. Denne information er ikke tilgængelig i øjeblikket på grund af høj server aktivitet';

$txt['change_profile'] = 'Gem profil';
$txt['preview_signature'] = 'Forhåndsvisning af signatur';
$txt['current_signature'] = 'Nuværende signatur';
$txt['signature_preview'] = 'Signatur forhåndsvisning';
$txt['personal_picture'] = 'Personligt billede';
$txt['no_avatar'] = 'Ingen avatar';
$txt['choose_avatar_gallery'] = 'Vælg en avatar fra galleriet';
$txt['preferred_language'] = 'Foretrukken sprog';
$txt['age'] = 'Brugerens alder';
$txt['no_pic'] = '(ingen billede)';
$txt['avatar_by_url'] = 'Angiv din egen avatar fra en webadresse. (F.eks: <em>http://www.mypage.com/mypic.png</em>)';
$txt['my_own_pic'] = 'Benyt en avatar fra en webadresse';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = '(YYYY-MM-DD)';
$txt['time_format'] = 'Tidsformat';
$txt['display_name_desc'] = 'Dette er skærmnavnet folk vil se.';
$txt['personal_time_offset'] = 'Antallet af timer at +/- for at få den viste tid til at passe med din lokale tid.';
$txt['dob'] = 'Fødselsdato';
$txt['dob_month'] = 'Måned (MM)';
$txt['dob_day'] = 'Dag (DD)';
$txt['dob_year'] = 'År (YYYY)';
$txt['password_strength'] = 'Som god sikkerhed, bør du bruge otte eller flere karakterer med en kombination af bogstaver, tal og symboler.';
$txt['include_website_url'] = 'Dette skal inkluderes hvis du angiver en webadresse herunder.';
$txt['complete_url'] = 'Dette skal være en komplet webadresse.';
$txt['sig_info'] = 'Signaturer vises i bunden af hvert indlæg og personlige beskeder. BBC kode og smileys kan benyttes i din signatur.';
$txt['max_sig_characters'] = 'Maks. antal karakterer: %1$d; karakterer tilbage: ';
$txt['send_member_pm'] = 'Send dette medlem en personlig besked';
$txt['hidden'] = 'skjult';
$txt['current_time'] = 'Aktuel forumtid';

$txt['language'] = 'Sprog';
$txt['avatar_too_big'] = 'Dit avatar billede er for stort, venligst reducer det og prøv igen (maks';
$txt['invalid_registration'] = 'Ugyldig dato registreret, gyldigt eksempel:';
$txt['current_password'] = 'Aktuel kodeord';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Af sikkerhedshensyn er dit kodeord krævet for at foretage ændringer af din konto.';

$txt['timeoffset_autodetect'] = 'auto';

$txt['secret_question'] = 'Hemmeligt spørgsmål';
$txt['secret_desc'] = 'For at hjælpe med at gendanne dit kodeord, skal du angive et spørgsmål her med et svar <strong>kun</strong> du kender.';
$txt['secret_desc2'] = 'Vælg med omhu, du ønsker ikke at nogen kan gætte dit svar!';
$txt['secret_answer'] = 'Svar';
$txt['incorrect_answer'] = 'Beklager, men du angav ikke en gyldig kombination af hemmeligt spørgsmål og svar i din profil. Klik venligst på tilbage knappen, og brug standard metoden til at få dit kodeord igen.';
$txt['enter_new_password'] = 'Angiv venligst svaret til dit spørgsmål, samt kodeordet du ønsker at bruge. Dit kodeord vil blive ændret til det du vælger forudsat du svarer korrekt på spørgsmålet.';
$txt['secret_why_blank'] = 'Hvorfor er dette blankt?';

$txt['authentication_reminder'] = 'Autentificeringspåminder';
$txt['password_reminder_desc'] = 'Hvis du har glemt dine login-detaljer, så fortvivl ikke, da de kan genskabes. For at starte processen skal du venligst angive dit brugernavn eller kodeord herunder.';
$txt['authentication_options'] = 'Vælg venligst et af de to valg herunder';
$txt['authentication_openid_email'] = 'E-mail mig en påmindelse på min OpenID identitet';
$txt['authentication_openid_secret'] = 'Svar på mit &quot;hemmelige spørgsmål&quot; for at vise min OpenID identitiet';
$txt['authentication_password_email'] = 'E-mail mig et nyt kodeord';
$txt['authentication_password_secret'] = 'Lad mig vælge et nyt kodeord ved at svare på mit &quot;hemmelige spørgsmål&quot; ';
$txt['openid_secret_reminder'] = 'Angiv venligst svaret til spørgsmålet herunder. Hvis du angiver det korrekt vil din OpenID identitet blive vist.';
$txt['reminder_openid_is'] = 'OpenID identiteten der er associeret med din konto er:<br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /><br />Noter venligst dette for fremtidig reference. ';
$txt['reminder_continue'] = 'Fortsæt';

$txt['accept_agreement_title'] = 'Accepter aftale';
$txt['agreement_accepted_title'] = 'Fortsæt';

$txt['current_theme'] = 'Aktuelt tema';
$txt['change'] = 'Skift Tema';
$txt['theme_forum_default'] = 'Forum eller boardstandard';
$txt['theme_forum_default_desc'] = 'Dette er standardtemaet, hvilket betyder dit tema vil ændres med administratorens indstillinger og for boards du læser.';

$txt['profileConfirm'] = 'Ønsker du virkeligt at slette dette medlem?';

$txt['custom_title'] = 'Brugerdefineret titel';

$txt['lastLoggedIn'] = 'Senest Aktiv';

$txt['notify_settings'] = 'Meddelelsesindstillinger:';
$txt['notify_save'] = 'Gem indstillinger';
$txt['notify_important_email'] = 'Modtag nyhedsbreve, annonceringer og vigtige notifikationer via e-mail.';
$txt['notify_regularity'] = 'Giv besked for emner og boards jeg har forespurgt meddelelser fra';
$txt['notify_regularity_none'] = 'Aldrig';
$txt['notify_regularity_instant'] = 'Omgående';
$txt['notify_regularity_first_only'] = 'Øjeblikkelig - men kun for det første ulæste svar';
$txt['notify_regularity_daily'] = 'Dagligt';
$txt['notify_regularity_weekly'] = 'Ugentlig';
$txt['auto_notify'] = 'Aktiver emne meddelelse når du opretter eller svarer på et emne.';
$txt['auto_notify_pbe_post'] = 'Dette er <strong>IKKE</strong> anbefalet hvis du har "board" meddelelser slået til.';
$txt['notify_send_types'] = 'Giv besked for emner og boards jeg har bedt om meddelelser for';
$txt['notify_send_type_everything'] = 'Svar og ændringer';
$txt['notify_send_type_everything_own'] = 'Ændringer, hvis jeg startede emnet';
$txt['notify_send_type_only_replies'] = 'Kun svar';
$txt['notify_send_type_only_replies_pbe'] = 'Alle beskeder';
$txt['notify_send_type_nothing'] = 'Ingen';
$txt['notify_send_body'] = 'Når der udsendes meldinger om et svar i et emne, send indlæg i emailen (men svar venligst ikke til disse emails.)';
$txt['notify_send_body_pbe'] = 'Når der udsendes email meddelelser, send fuld tekst af indlæg i emailen';
$txt['notify_send_body_pbe_post'] = '<strong>IKKE</strong> tilgængelig med Daglig / Ugentlig resume';

$txt['notify_method'] = 'Notifikation og:';
$txt['notify_notification'] = 'ingen email (kun omtale/advarsel)';
$txt['notify_email'] = 'Øjeblikkelig email';
$txt['notify_email_daily'] = 'Daglig email';
$txt['notify_email_weekly'] = 'Ugentlig email';

$txt['notify_type_likemsg'] = 'Notificer når en af dine beskeder bliver liked';
$txt['notify_type_mentionmem'] = 'Notificer når du er @omtalt';
$txt['notify_type_rlikemsg'] = 'Notificer når en like er fjernet fra en af dine beskeder';
$txt['notify_type_buddy'] = 'Notificer når nogen tilføjer dig som ven';
$txt['notify_type_quotedmem'] = 'Notificer når nogen citerer en af dine beskeder';
$txt['notify_type_mailfail'] = 'Notificer når email notifikationer er deaktiveret (kun omtale)';

$txt['notifications_topics'] = 'Aktuelle abonnementer på emner';
$txt['notifications_topics_none'] = 'Du abonnerer i øjeblikket ikke på svar fra nogen emner.';
$txt['notifications_topics_howto'] = 'For at modtage meddelelser fra et specifikt emne, klik på &quot;Abonner&quot; knappen i emnet.';

$txt['notifications_boards'] = 'Aktuelle abonnementer på boards';
$txt['notifications_boards_none'] = 'Du abonnerer i øjeblikket ikke på nogen boards.';
$txt['notifications_boards_howto'] = 'For at modtage meddelelser fra et specifikt board, klik enten på &quot;Abonner&quot; knappen på indekset af det pågældende board, <strong>eller</strong> brug afkrydsningsfeltet nedenunder for at aktivere board meddelelser.';
$txt['notifications_boards_current'] = 'Du modtager meddelelser fra de boards der vises i <strong>FED SKRIFT</strong>. Brug afkrydsningsfeltet for at slå disse fra eller tilføj yderligere boards til din meddelelses liste';
$txt['notifications_boards_update'] = 'Opdater';
$txt['notifications_update'] = 'Fjern abonnement';

$txt['statPanel_showStats'] = 'Brugerstatistik over: ';
$txt['statPanel_users_votes'] = 'Antal af stemmer afgivet';
$txt['statPanel_users_polls'] = 'Antal af oprettede afstemninger';
$txt['statPanel_total_time_online'] = 'Sammenlagt tid brugt online';
$txt['statPanel_noPosts'] = 'Ingen indlæg der er værd at nævne!';
$txt['statPanel_generalStats'] = 'Generel statistik';
$txt['statPanel_posts'] = 'oprette indlæg';
$txt['statPanel_topics'] = 'emner';
$txt['statPanel_total_posts'] = 'Antal indlæg i alt';
$txt['statPanel_total_topics'] = 'Total antal emner startet';
$txt['statPanel_votes'] = 'stemmer';
$txt['statPanel_polls'] = 'afstemninger';
$txt['statPanel_topBoards'] = 'Populæreste boards efter antal indlæg';
$txt['statPanel_topBoards_posts'] = '%1$d indlæg af boardets %2$d indlæg (%3$01.2f%%)';
$txt['statPanel_topBoards_memberposts'] = '%1$d indlæg af medlemmet %2$d \\\'s indlæg (%3$01.2f%%)';
$txt['statPanel_topBoardsActivity'] = 'Populæreste boards efter aktivitet';
$txt['statPanel_activityTime'] = 'Aktivitet efter klokkeslet';
$txt['statPanel_activityTime_posts'] = '%1$d indlæg (%2$d%%)';

$txt['deleteAccount_warning'] = 'Advarsel - Disse handlinger kan ikke fortrydes!';
$txt['deleteAccount_desc'] = 'Fra denne side kan du slette denne brugers konto og indlæg.';
$txt['deleteAccount_member'] = 'Slet dette medlems konto';
$txt['deleteAccount_posts'] = 'Slet indlæg oprettet af dette medlem';
$txt['deleteAccount_none'] = 'Ingen';
$txt['deleteAccount_all_posts'] = 'Kun svar';
$txt['deleteAccount_topics'] = 'Emner og svar';
$txt['deleteAccount_confirm'] = 'Er du fuldstændig sikker på du vil slette denne konto?';
$txt['deleteAccount_approval'] = 'Vær opmærksom på at dette forums moderatorer skal godkende sletningen af denne konto, før dette sker.';

$txt['profile_of_username'] = '%1$s\'s profil';
$txt['profileInfo'] = 'Profil-info';
$txt['showPosts'] = 'Vis indlæg';
$txt['showPosts_help'] = 'Denne sektion tillader dig at se alle indlæg oprettet af dette medlem. Bemærk at du kun kan se indlæg der er oprettet i områder du i øjeblikket har adgang til.';
$txt['showMessages'] = 'Beskeder';
$txt['showGeneric_help'] = 'Denne sektion tillader dig at se alle %1$s lavet af denne bruger. Bemærk at du kun kan se %1$s lavet i områder du har adgang til.';
$txt['showTopics'] = 'Emner';
$txt['showUnwatched'] = 'Ikke overvågede emner';
$txt['showAttachments'] = 'Vedhæftninger';
$txt['viewWarning_help'] = 'Denne sektion viser dig alle udstedte advarsler til denne bruger.';
$txt['statPanel'] = 'Vis statistik';
$txt['editBuddyIgnoreLists'] = 'Venner/ignorerings-liste';
$txt['editBuddies'] = 'Rediger venner';
$txt['editIgnoreList'] = 'Rediger listen over ignorerede medlemmer';
$txt['trackUser'] = 'Spor bruger';
$txt['trackActivity'] = 'Aktivitet';
$txt['trackIP'] = 'IP addresse';
$txt['trackLogins'] = 'Logins';

$txt['likes_show'] = 'Vis Likes';
$txt['likes_given'] = 'Indlæg du har tilføjet likes til';
$txt['likes_profile_received'] = 'modtaget';
$txt['likes_profile_given'] = 'Tildelt';
$txt['likes_received'] = 'Dine indlæg som andre har tildelt likes';
$txt['likes_none_given'] = 'Du har ikke tildelt likes til nogen indlæg';
$txt['likes_none_received'] = 'Der er ingen der har tilføjet likes til nogen af dine indlæg :\'(';
$txt['likes_confirm_delete'] = 'Fjern denne like?';
$txt['likes_show_who'] = 'Vis brugere der har tildelt likes til dette indlæg';
$txt['likes_by'] = 'Likes';
$txt['likes_delete'] = 'Slet';

$txt['authentication'] = 'Autentificering';
$txt['change_authentication'] = 'Fra denne sektion kan du ændre hvordan du logger ind i forummet. Du kan vælge enten at bruge en OpenID konto som din godkendelse, eller alternativt skifte til at bruge et brugernavn og kodeord.';

$txt['profileEdit'] = 'Rediger profil';
$txt['account_info'] = 'Dette er dine kontoindstillinger. Denne side indeholder alle kritiske informationer som identificerer dig i dette forum. Af sikkerhedshensyn, skal du angive dit (aktuelle) kodeord for at ændre disse informationer.';
$txt['forumProfile_info'] = 'Du kan ændre dine personlige informationer på denne side. Disse informationer bliver vist diverse steder på {forum_name_html_safe}. Hvis du ikke er komfortabel med at dele visse informationer, kan du blot springe disse over - der er ikke noget her der er påkrævet.';
$txt['theme_info'] = 'Denne sektion tillader dig at skræddersy udseendet og layoutet på forummet.';
$txt['notification_info'] = 'Dette tillader dig at abonnere på svar på indlæg, nye emner og forum annonceringer. Du kan ændre disse indstillinger her, og gennemse de emner og boards du i øjeblikket modtager meddelselser fra.';
$txt['groupmembership'] = 'Gruppemedlemsskab';
$txt['groupMembership_info'] = 'I denne sektion af din profil kan du ændre hvilke grupper du tilhører.';
$txt['ignoreboards'] = 'Ignorer Boardindstillinger';
$txt['ignoreboards_info'] = 'Denne side lader dig ignorere specifikke boards. Når et board er ignoreret vil Nye indlæg indikation ikke blive vist på boardindeks. Nye indlæg bliver ikke vist under "ulæste indlæg" (søgning vil ignorere disse boards). Dog vil ignorerede board stadig blive vist på boardindeks og når disse tilgås vil der vises hvilke emner der har nye indlæg. Når "ulæste svar" bruges, vil nye indlæg i et ignoreret board stadig blive vist.';
$txt['contactprefs'] = 'Beskeder';

$txt['profileAction'] = 'Handlinger';
$txt['deleteAccount'] = 'Slet denne konto';
$txt['profileSendIm'] = 'Send personlig besked';
$txt['profile_sendpm_short'] = 'Send personlig besked';

$txt['profileBanUser'] = 'Bandlys denne bruger';

$txt['display_name'] = 'Skærmnavn';
$txt['enter_ip'] = 'Angiv IP (område)';
$txt['errors_by'] = 'Fejlmeldinger efter';
$txt['errors_desc'] = 'Herunder er en liste over de seneste fejl som denne bruger har genereret/oplevet.';
$txt['errors_from_ip'] = 'Fejlmeldinger fra IP (område)';
$txt['errors_from_ip_desc'] = 'Herunder er en liste af alle nylige fejlmeldinger genereret fra dette IP (område).';
$txt['ip_address'] = 'IP adresse';
$txt['ips_in_errors'] = 'IP adresser brugt i fejlmeldinger';
$txt['ips_in_messages'] = 'IP-adresser brugt i seneste beskeder';
$txt['members_from_ip'] = 'Medlemmer fra IP (område)';
$txt['members_in_range'] = 'Medlemmer som formentlig ligger inden for samme område';
$txt['messages_from_ip'] = 'Indlæg oprettet fra IP (område)';
$txt['messages_from_ip_desc'] = 'Herunder er en liste over alle indlæg oprettet fra dette IP (område).';
$txt['trackLogins_desc'] = 'Herunder er en liste over logins på denne konto.';
$txt['most_recent_ip'] = 'Nyeste IP adresser';
$txt['why_two_ip_address'] = 'Hvorfor er der vist to IP adresser?';
$txt['no_errors_from_ip'] = 'Ingen fejl fundet fra det angivede IP (område)';
$txt['no_errors_from_user'] = 'Ingen fejlmeddelelser fundet fra den angivede bruger';
$txt['no_members_from_ip'] = 'Ingen medlemmer fundet i det specificerede IP (område)';
$txt['no_messages_from_ip'] = 'Ingen indlæg fundet fra det angivede IP (område)';
$txt['trackLogins_none_found'] = 'Ingen nylige logins';
$txt['none'] = 'Ingen';
$txt['own_profile_confirm'] = 'Er du sikker på du vil slette din konto?';
$txt['view_ips_by'] = 'Vis IP\'er brugt af';

$txt['avatar_will_upload'] = 'Upload en avatar';

$txt['activate_changed_email_title'] = 'E-mail adressen blev ændret';
$txt['activate_changed_email_desc'] = 'Du har ændret din e-mail adresse. For at validere denne, vil du modtage en e-mail. Klik på linket i e-mailen for at reaktivere din konto.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Ikke i stand til at sende en påmindelses-e-mail.';
$txt['send_email'] = 'Send en e-mail til';
$txt['to_ask_password'] = 'for at spørge til dine autentificeringsdetaljer';

$txt['user_email'] = 'Brugernavn/e-mail';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'En mail er blevet sendt til din e-mail-adresse. Klik på linket i den mail for at oprette et nyt kodeord.';
$txt['reminder_openid_sent'] = 'Din aktuelle OpenID identitet er blevet sendt til din e-mail-adresse.';
$txt['reminder_set_password'] = 'Indstil kodeord';
$txt['reminder_password_set'] = 'Kodeord oprettet';
$txt['reminder_error'] = '%1$s fejlede i at svare korrekt på deres hemmelige spørgsmål da de forsøgte at ændre et glemt kodeord.';

$txt['registration_not_approved'] = 'Beklager, denne konto er endnu ikke blevet godkendt. Hvis du er nødt til at ændre din e-mail-adresse så klik venligst';
$txt['registration_not_activated'] = 'Beklager, denne konto er endnu ikke aktiveret. Hvis du har behov for at gensende aktiverings-e-mailen så klik venligst';

$txt['primary_membergroup'] = 'Primær medlemsgruppe';
$txt['additional_membergroups'] = 'Yderligere medlemsgrupper';
$txt['additional_membergroups_show'] = 'Vis yderligere grupper';
$txt['no_primary_membergroup'] = '(ingen primær medlemsgruppe)';
$txt['deadmin_confirm'] = 'Er du sikker på at du uigenkaldelig ønsker at fjerne din admin status?';

$txt['account_activate_method_2'] = 'Kontoen skal reaktiveres ved ændring af e-mail-adressen';
$txt['account_activate_method_3'] = 'Kontoen er ikke godkendt';
$txt['account_activate_method_4'] = 'Kontoen afventer godkendelse for sletning';
$txt['account_activate_method_5'] = 'Kontoen er en &quot;under lavalder&quot; konto, der afventer godkendelse';
$txt['account_not_activated'] = 'Kontoen er i øjeblikket ikke aktiveret';
$txt['account_activate'] = 'aktiver';
$txt['account_approve'] = 'godkend';
$txt['user_is_banned'] = 'Brugeren er i øjeblikket bandlyst';
$txt['view_ban'] = 'Se';
$txt['user_banned_by_following'] = 'Denne bruger er i øjeblikket berørt af følgende bandlysninger';
$txt['user_cannot_due_to'] = 'Brugeren kan i øjeblikket ikke %1$s som et resultat af følgende bandlysning: &quot;%2$s&quot;';
$txt['ban_type_post'] = 'oprette indlæg';
$txt['ban_type_register'] = 'registrere sig';
$txt['ban_type_login'] = 'logge ind';
$txt['ban_type_access'] = 'få adgang til forummet';

$txt['show_online'] = 'Vis andre min onlinestatus';

$txt['return_to_post'] = 'Vend som standard tilbage til emnet efter at have postet.';
$txt['no_new_reply_warning'] = 'Advar ikke om nye svar, der er skrevet mens jeg selv svarer.';
$txt['recent_pms_at_top'] = 'Vis nyeste personlige beskeder i toppen.';
$txt['wysiwyg_default'] = 'Vis som standard WYSIWYG editoren på posteringssiden.';

$txt['timeformat_default'] = '(forumstandard)';
$txt['timeformat_easy1'] = 'Måned Dag, År, HH:MM:SS am/pm';
$txt['timeformat_easy2'] = 'Måned Dag, År, HH:MM:SS (24 timer)';
$txt['timeformat_easy3'] = 'YYYY-MM-DD, HH:MM:SS';
$txt['timeformat_easy4'] = 'DD Måned YYYY, HH:MM:SS';
$txt['timeformat_easy5'] = 'DD-MM-YYYY, HH:MM:SS';

$txt['poster'] = 'Medlem';

$txt['use_sidebar_menu'] = 'Brug sidebar menuer istedet for dropdown menuer.';
$txt['use_click_menu'] = 'Brug klik for at åbne menuer, istedet for at åbne ved hover over.';
$txt['show_no_avatars'] = 'Vis ikke andre brugeres avatarer.';
$txt['show_no_signatures'] = 'Vis ikke brugeres signaturer.';
$txt['show_no_censored'] = 'Censurer ikke ord.';
$txt['topics_per_page'] = 'Emner at vise per side:';
$txt['messages_per_page'] = 'Indlæg at vise per side:';
$txt['hide_poster_area'] = 'Skjul besked information område.';
$txt['per_page_default'] = 'forumstandard';
$txt['calendar_start_day'] = 'Første ugedag i kalenderen.';
$txt['display_quick_reply'] = 'Vis \'Hurtig svar\' i emnevisning:';
$txt['use_editor_quick_reply'] = 'Brug fuld tekst editor i Hurtig Svar.';
$txt['display_quick_mod'] = 'Vis hurtig-moderation som:';
$txt['display_quick_mod_none'] = 'vis ikke.';
$txt['display_quick_mod_check'] = 'checkbokse.';
$txt['display_quick_mod_image'] = 'ikoner.';

$txt['whois_title'] = 'Slå IP op på en regional whois-server';
$txt['whois_afrinic'] = 'AfriNIC (Afrika)';
$txt['whois_apnic'] = 'APNIC (Asiatisk Pacific region)';
$txt['whois_arin'] = 'ARIN (Nord Amerika, en del af Karibien og sub-Sahara Afrika)';
$txt['whois_lacnic'] = 'LACNIC (Latin Amerika og karibiske region)';
$txt['whois_ripe'] = 'RIPE (Europa, Mellemøste og dele af Afrika og Asien)';

$txt['moderator_why_missing'] = 'hvorfor vises moderatorer ikke her?';
$txt['username_change'] = 'skift';
$txt['username_warning'] = 'For at ændre dette medlems brugernavn, er forummet også nødt til at nulstille vedkommendes kodeord, hvilket vil blive e-mailet til medlemmet med det nye brugernavn.';

$txt['show_member_posts'] = 'Vis medlemmets indlæg';
$txt['show_member_topics'] = 'Vis medlemmets emner';
$txt['show_member_attachments'] = 'Vis medlemmets vedhæftninger';
$txt['show_posts_none'] = 'Der er endnu ikke oprettet nogle indlæg.';
$txt['show_topics_none'] = 'Der er endnu ikke blevet oprettet nogle emner.';
$txt['unwatched_topics_none'] = 'Der er ikke nogen emner i listen.';
$txt['show_attachments_none'] = 'Der er endnu ikke blevet postet nogen vedhæftninger.';
$txt['show_attach_filename'] = 'Filnavn';
$txt['show_attach_downloads'] = 'Downloads';
$txt['show_attach_posted'] = 'Afsendt';

$txt['showPermissions'] = 'Vis rettigheder';
$txt['showPermissions_status'] = 'Status for tilladelser';
$txt['showPermissions_help'] = 'Denne sektion gør dig i stand til at se alle tilladelser for det pågældende medlem (nægtede tilladelser er <del>gennemstreget</del>). ';
$txt['showPermissions_given'] = 'Tildelt fra';
$txt['showPermissions_denied'] = 'Nægtet fra';
$txt['showPermissions_permission'] = 'Tilladelser (nægtede tilladelser er vist som <del>gennemstreget</del>)';
$txt['showPermissions_none_general'] = 'Dette medlem har ikke nogen generelle rettigheder sat.';
$txt['showPermissions_none_board'] = 'Dette medlem har ingen specifikke board rettigheder sat.';
$txt['showPermissions_all'] = 'Som administrator, har dette medlem alle mulige rettigheder.';
$txt['showPermissions_select'] = 'Board specifikke tilladelser for';
$txt['showPermissions_general'] = 'Generelle Tilladelser';
$txt['showPermissions_global'] = 'Alle boards';
$txt['showPermissions_restricted_boards'] = 'Begrænsede boards';
$txt['showPermissions_restricted_boards_desc'] = 'Denne bruger har ikke adgang til følgende boards';

$txt['local_time'] = 'Lokal tid';
$txt['posts_per_day'] = 'per dag';

$txt['buddy_ignore_desc'] = 'Dette område tillader dig at vedligeholde din venne- og ignoreringsliste i dette forum. Tilføjelse af medlemmer til disse lister, vil hjælpe dig med at kontrollere trafikken af personlige beskeder, afhængig af dine preferencer.';

$txt['buddy_add'] = 'Tilføj til venneliste';
$txt['buddy_remove'] = 'Fjern fra venneliste';
$txt['buddy_add_button'] = 'Tilføj';
$txt['no_buddies'] = 'Din venneliste er i øjeblikket tom';

$txt['ignore_add'] = 'Tilføj til ignoreringslisten';
$txt['ignore_remove'] = 'Fjern fra ignoreringslisten';
$txt['ignore_add_button'] = 'Tilføj';
$txt['no_ignore'] = 'Din ignoreringsliste er i øjeblikket tom';

$txt['regular_members'] = 'Registrerede medlemmer';
$txt['regular_members_desc'] = 'Alle medlemmer i forummet er medlem af denne gruppe.';
$txt['group_membership_msg_free'] = 'Dit gruppemedlemsskab er blevet opdateret.';
$txt['group_membership_msg_request'] = 'Din anmodning er blevet indsendt, hav venligst tålmodighed mens forespørgslen bliver behandlet.';
$txt['group_membership_msg_primary'] = 'Din primære gruppe er blevet opdateret';
$txt['current_membergroups'] = 'Aktuelle medlemsgrupper';
$txt['available_groups'] = 'Tilgængelige grupper';
$txt['join_group'] = 'Stød til gruppe';
$txt['leave_group'] = 'Forlad gruppe';
$txt['request_group'] = 'Anmod om medlemsskab';
$txt['approval_pending'] = 'Afventer godkendelse';
$txt['make_primary'] = 'Gør til primær gruppe';

$txt['request_group_membership'] = 'Anmod om gruppemedlemsskab';
$txt['request_group_membership_desc'] = 'Før du kan blive medlem af denne gruppe skal du godkendes af en moderator. Angiv venligst årsagen for at melde dig til denne gruppe';
$txt['submit_request'] = 'Indsend anmodning';

$txt['profile_updated_own'] = 'Din profil er blevet opdateret.';
$txt['profile_updated_else'] = 'Profilen for <strong>%1$s</strong> blev opdateret.';

$txt['profile_error_signature_max_length'] = 'Din signatur må ikke være på mere end %1$d karakterer';
$txt['profile_error_signature_max_lines'] = 'Din signatur kan ikke strække sig over mere end %1$d linier';
$txt['profile_error_signature_max_image_size'] = 'Billeder i din signatur må ikke være større end %1$dx%2$d pixels';
$txt['profile_error_signature_max_image_width'] = 'Billeder i din signatur må ikke være bredere end %1$d pixels';
$txt['profile_error_signature_max_image_height'] = 'Billeder i din signatur må ikke være højere end %1$d pixels';
$txt['profile_error_signature_max_image_count'] = 'Du kan ikke have mere end %1$d billeder i din signatur';
$txt['profile_error_signature_max_font_size'] = 'Tekst i din signatur skal være mindre end %1$s i størrelse';
$txt['profile_error_signature_allow_smileys'] = 'Det er ikke tilladt at benytte smileys i din signatur';
$txt['profile_error_signature_max_smileys'] = 'Du har ikke tilladelse til at bruge mere end %1$d smileys i din signatur';
$txt['profile_error_signature_disabled_bbc'] = 'Følgende BBC er ikke tilladt i din signatur: %1$s';

$txt['profile_view_warnings'] = 'Se Advarsler';
$txt['profile_issue_warning'] = 'Udsend en advarsel';
$txt['profile_warning_level'] = 'Advarselsniveau';
$txt['profile_warning_desc'] = 'Fra denne sektion kan du justere brugernes advarselsniveau og udstede en skriftlig advarsel hvis det er nødvendigt. Du kan også spore deres tidligere advarsler og se effekten af deres aktuelle advarselsniveau sat af administratoren.';
$txt['profile_warning_name'] = 'Medlemsnavn';
$txt['profile_warning_impact'] = 'Resultat';
$txt['profile_warning_reason'] = 'Begrundelse for advarslen';
$txt['profile_warning_reason_desc'] = 'Dette er påkrævet og vil blive logget.';
$txt['profile_warning_effect_none'] = 'Ingen';
$txt['profile_warning_effect_watch'] = 'Brugeren vil blive tilføjet til moderators overvågningsliste.';
$txt['profile_warning_effect_own_watched'] = 'Du er på moderatorernes overvågningsliste.';
$txt['profile_warning_is_watch'] = 'er under overvågning';
$txt['profile_warning_effect_moderate'] = 'Alle bruger indlæg vil blive modereret.';
$txt['profile_warning_effect_own_moderated'] = 'Alle dine indlæg vil blive modereret.';
$txt['profile_warning_is_moderation'] = 'indlæg er modererede';
$txt['profile_warning_effect_mute'] = 'Brugeren vil ikke være i stand til at oprette indlæg.';
$txt['profile_warning_effect_own_muted'] = 'Du vil ikke være i stand til at oprette indlæg.';
$txt['profile_warning_is_muted'] = 'kan ikke oprette indlæg';
$txt['profile_warning_effect_text'] = 'Niveau >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Send en advarsel';
$txt['profile_warning_notify_template'] = 'Vælg skabelon:';
$txt['profile_warning_notify_subject'] = 'Overskrift for advarslen';
$txt['profile_warning_notify_body'] = 'Meddelelse';
$txt['profile_warning_notify_template_subject'] = 'Du har modtaget en advarsel';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER}

Du har modtaget en advarsel for %1$s. Disse aktiviteter bedes øjeblikkeligt ophørt. Følg venligst forum reglerne, ellers vil vi blive nødsaget til yderligere tiltag.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER}

Du har modtaget en advarsel for %1$s i forbindelse med beskeden:
{MESSAGE}

Disse aktiviteter bedes øjeblikkeligt ophørt. Følg venligst forum reglerne, ellers vil vi blive nødsaget til yderligere tiltag.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'spamming';
$txt['profile_warning_notify_title_spamming'] = 'Spamming';
$txt['profile_warning_notify_for_offence'] = 'poster fornærmende materiale';
$txt['profile_warning_notify_title_offence'] = 'Poster fornærmende Materiale';
$txt['profile_warning_notify_for_insulting'] = 'fornærmer andre brugere og/eller stabsmedlemmer';
$txt['profile_warning_notify_title_insulting'] = 'Fornærmer brugere/Staben';
$txt['profile_warning_issue'] = 'Udsted advarsel';
$txt['profile_warning_max'] = '(Maks 100)';
$txt['profile_warning_limit_attribute'] = 'Bemærk du kan ikke justere denne brugers niveau med mere end %1$d%% over en 24 timers periode.';
$txt['profile_warning_errors_occurred'] = 'Advarslen er ikke blevet send på grund af følgende fejl';
$txt['profile_warning_success'] = 'Advarsel udstedt';
$txt['profile_warning_new_template'] = 'Ny Skabelon';

$txt['profile_warning_previous'] = 'Tidligere advarsler';
$txt['profile_warning_previous_none'] = 'Denne bruger har ikke før modtaget nogen advarsler.';
$txt['profile_warning_previous_issued'] = 'Udstedt af';
$txt['profile_warning_previous_time'] = 'Tid';
$txt['profile_warning_previous_level'] = 'Point';
$txt['profile_warning_previous_reason'] = 'Grund';
$txt['profile_warning_previous_notice'] = 'Se varsling sendt til medlemmet';

$txt['viewwarning'] = 'Se Advarsler';
$txt['profile_viewwarning_for_user'] = 'Advarsler for %1$s';
$txt['profile_viewwarning_no_warnings'] = 'Ingen advarsler er udstedt.';
$txt['profile_viewwarning_desc'] = 'Herunder er en oversigt over alle advarsler der er blevet udstedt af forummets moderationsteam.';
$txt['profile_viewwarning_previous_warnings'] = 'Tidligere advarsler';
$txt['profile_viewwarning_impact'] = 'Indvirkning på advarsel';

$txt['subscriptions'] = 'Betalt abonnement';

$txt['pm_settings_desc'] = 'Fra denne side kan du ændre forskellige indstillinger for beskedcenteret, inklusive hvordan beskeder bliver vist, samt hvem der må sende beskeder til dig.';
$txt['email_notify'] = 'Meddel per e-mail hver gang du modtager en personlig besked:';
$txt['email_notify_never'] = 'Aldrig';
$txt['email_notify_buddies'] = 'Kun fra venner';
$txt['email_notify_always'] = 'Altid';

$txt['receive_from'] = 'Brugere der kan kontakte mig:';
$txt['receive_from_everyone'] = 'Alle medlemmer';
$txt['receive_from_ignore'] = 'Alle medlemmer, med undtagelse af dem på min ignoreringsliste';
$txt['receive_from_admins'] = 'Kun administratorer';
$txt['receive_from_buddies'] = 'Kun fra venner samt administratorer';
$txt['receive_from_description'] = 'Denne indstilling gælder både Personlige Beskeder og emails (hvis indstilling til at emaile brugere er aktiv)';

$txt['popup_messages'] = 'Vis en pop-up meddelelse når jeg modtager nye personlige beskeder.';
$txt['pm_remove_inbox_label'] = 'Slet indbakkemærkatet når du tager et andet mærkat i brug.';
$txt['pm_display_mode'] = 'Vis personlige beskeder';
$txt['pm_display_mode_all'] = 'Alle på en gang';
$txt['pm_display_mode_one'] = 'En ad gangen';
$txt['pm_display_mode_linked'] = 'Som en samtale';

$txt['history'] = 'Historie';
$txt['history_description'] = 'Denne sektion viser dig visse profilaktioner der er udført på denne brugers profil såvel som at spore deres IP adresse og login historie.';

$txt['trackEdits'] = 'Profilændringer';
$txt['trackEdit_deleted_member'] = 'Slettet medlem';
$txt['trackEdit_no_edits'] = 'Ingen redigeringer er indtil videre blevet noteret for dette medlem';
$txt['trackEdit_action'] = 'Felt';
$txt['trackEdit_before'] = 'Værdi før';
$txt['trackEdit_after'] = 'Værdi efter';
$txt['trackEdit_applicator'] = 'Ændret af';

$txt['trackEdit_action_real_name'] = 'Medlemsnavn';
$txt['trackEdit_action_usertitle'] = 'Brugerdefineret titel';
$txt['trackEdit_action_member_name'] = 'Brugernavn';
$txt['trackEdit_action_email_address'] = 'E-mail-adresse';
$txt['trackEdit_action_id_group'] = 'Primær medlemsgruppe';
$txt['trackEdit_action_additional_groups'] = 'Yderligere medlemsgrupper';

$txt['otp_enabled_help'] = 'Aktivering af dette vil tilføje endnu en autentifikations faktor (engangskode)';
$txt['otp_token_help'] = 'Dette genererer en hemmelig kode for tids-baseret engangskode apps såsom Authy eller Google Authenticator. Når den hemmelig kode er genereret, brug din favorit autentifikations app og skan qr koden.<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
