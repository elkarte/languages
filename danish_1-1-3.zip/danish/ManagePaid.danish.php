<?php
// Version: 1.1; ManagePaid

// Symbols.
$txt['usd_symbol'] = '$%1.2f';
$txt['eur_symbol'] = '&euro;%1.2f';
$txt['gbp_symbol'] = '&pund;%1.2f';

$txt['usd'] = 'USD ($)';
$txt['eur'] = 'EURO (&euro;)';
$txt['gbp'] = 'GBP (&pound;)';
$txt['other'] = 'Andre';

$txt['paid_username'] = 'Brugernavn';

$txt['paid_subscriptions_desc'] = 'Fra denne sektion kan du tilføje, fjerne samt redigere metoder for betalte kontingenter til dit forum.';
$txt['paid_subs_settings'] = 'Indstillinger';
$txt['paid_subs_settings_desc'] = 'Herfra kan du redigere betalingsmetoderne tilgængelig for dine brugere.';
$txt['paid_subs_view'] = 'Vis kontingenter';
$txt['paid_subs_view_desc'] = 'Fra denne sektion kan du se alle kontingenter du har til rådighed.';

// Setting type strings.
$txt['paid_enabled'] = 'Aktiver betalte kontingenter';
$txt['paid_enabled_desc'] = 'Dette skal være markeret for at betalte kontingenter kan benyttes i forummet.';
$txt['paid_email'] = 'Send notifikationer per e-mail';
$txt['paid_email_desc'] = 'Informer administratoren når et kontingent automatisk ændres.';
$txt['paid_email_to'] = 'E-mail til korrespondence.';
$txt['paid_email_to_desc'] = 'Komma-separeret liste af adresser der skal mailes notifikationer til, foruden forum-administratorer.';
$txt['paidsubs_test'] = 'Aktiver testtilstand';
$txt['paidsubs_test_desc'] = 'Dette sætter betalte kontingenter i  &quot;test&quot; tilstand, som vil, hvor end det er muligt, anvende sandkasse betalingsmetoder hos paypal o.s.v. Aktiver ikke dette, med mindre du ved hvad du gør!';
$txt['paidsubs_test_confirm'] = 'Er du sikker på du vil aktivere testtilstand?';
$txt['paid_email_no'] = 'Send ikke nogen notifikationer';
$txt['paid_email_error'] = 'Informer hvis hvis kontingentet fejler';
$txt['paid_email_all'] = 'Informer om alle automatiske ændringer af kontingenter';
$txt['paid_currency'] = 'Vælg Møntenhed';
$txt['paid_currency_code'] = 'Kode for Møntenhed';
$txt['paid_currency_code_desc'] = 'Kode brugt af betalingsforretninger';
$txt['paid_currency_symbol'] = 'Symbol brugt af betalingsmetode';
$txt['paid_currency_symbol_desc'] = 'Brug \'%1.2f\' til at specificere hvor numrene passer, for eksempel $%1.2f, %1.2fDM o.s.v ';

$txt['paypal_email'] = 'Paypal e-mailadresser';
$txt['paypal_email_desc'] = 'Lad denne være blank hvis du ikke ønsker at bruge paypal.';

$txt['authorize_id'] = 'Authorize.net Installations-ID';
$txt['authorize_id_desc'] = 'Installations-ID\'et genereret af Authorize.net. Efterlad blank hvis du ikke anvender Authorize.net ';
$txt['authorize_transid'] = 'Authorize.Net Transaktions-ID';

$txt['2co_id'] = '2checkout.com Installations ID';
$txt['2co_id_desc'] = 'Installations-ID\'et genereret af 2co.com. Efterlad blank hvis du ikke anvender 2co.com';
$txt['2co_password'] = 'Dit 2checkout.com hemmelige ord';
$txt['2co_password_desc'] = 'Dit 2checkout hemmelige ord.';
$txt['2co_password_wrong'] = 'Dit 2checkout hemmelige ord var ikke godkendt';

$txt['paid_settings_save'] = 'Gem';

$txt['paid_note'] = '<strong class="alert">Bemærk:</strong><br />For at automatisk opdatere kontingenter for dine brugere, skal du
	indstille en retur URL for hver af dine betalings metoder. For alle betalings metoder, denne retur URL skal være indstillet til: <br /><br />
	&nbsp;&nbsp;&bull;&nbsp;&nbsp;<strong>{board_url}/subscriptions.php</strong><br /><br />
	Du kan editere linket til PayPal direkte ved at <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ipn-notify" target="_blank">klikke her</a>.<br />
	For andre metoder (hvis installeret) kan den normalt findes i dit kunde panel, normalt under betegnelsen &quot;Return URL&quot; eller &quot;Callback URL&quot;.';

// View subscription strings.
$txt['paid_name'] = 'Navn';
$txt['paid_status'] = 'Status';
$txt['paid_cost'] = 'Omkostninger';
$txt['paid_duration'] = 'Varighed';
$txt['paid_active'] = 'Aktiv';
$txt['paid_pending'] = 'Afventende Betalinger';
$txt['paid_finished'] = 'Fuldført';
$txt['paid_total'] = 'Total';
$txt['paid_is_active'] = 'Aktiveret';
$txt['paid_none_yet'] = 'Du har endnu ikke opsat nogen kontingenter.';
$txt['paid_none_ordered'] = 'Du har ikke nogen kontingenter.';
$txt['paid_payments_pending'] = 'Afventende Betalinger';
$txt['paid_order'] = 'Bestil';

$txt['yes'] = 'Ja';
$txt['no'] = 'Nej';

// Add/Edit/Delete subscription.
$txt['paid_add_subscription'] = 'Tilføj kontingent';
$txt['paid_edit_subscription'] = 'Rediger kontingent';
$txt['paid_delete_subscription'] = 'Slet kontingent';

$txt['paid_mod_name'] = 'Navn på kontingentet';
$txt['paid_mod_desc'] = 'Beskrivelse';
$txt['paid_mod_reminder'] = 'Send Påmindelses-email';
$txt['paid_mod_reminder_desc'] = 'Antal dage før kontingentet er forfalden til at udløbe og sende en påmindelse. (I dage, 0 for at deaktivere)';
$txt['paid_mod_email'] = 'E-mail der skal sendes til ved færdiggørelse';
$txt['paid_mod_email_desc'] = 'Hvor {NAME} er medlemmets navn; {FORUM} er navnet på dit forum. Overskriften på e-mailen bør være på første linie. Efterlad blank hvis der ikke skal sendes en e-mail notifikation.';
$txt['paid_mod_cost_usd'] = 'Pris (USD)';
$txt['paid_mod_cost_eur'] = 'Pris (EUR)';
$txt['paid_mod_cost_gbp'] = 'Pris (GBR)';
$txt['paid_mod_cost_blank'] = 'Efterlad denne blank for ikke at tilbyde denne møntenhed.';
$txt['paid_mod_span'] = 'Løbetid på kontingent';
$txt['paid_mod_span_days'] = 'Dage';
$txt['paid_mod_span_weeks'] = 'Uger';
$txt['paid_mod_span_months'] = 'Måneder';
$txt['paid_mod_span_years'] = 'År';
$txt['paid_mod_active'] = 'Aktiv';
$txt['paid_mod_active_desc'] = 'Et kontingent skal være aktiv for at nye medlemmer kan slutte sig til.';
$txt['paid_mod_prim_group'] = 'Primær gruppe for kontigent';
$txt['paid_mod_prim_group_desc'] = 'Primær gruppe brugeren skal tilknyttes når de abonnerer.';
$txt['paid_mod_add_groups'] = 'Yderligere grupper for kontigent';
$txt['paid_mod_add_groups_desc'] = 'Yderligere grupper brugeren skal tilknyttes når de abonnerer.';
$txt['paid_mod_no_group'] = 'Skift Ikke';
$txt['paid_mod_edit_note'] = 'Bemærk at da denne gruppe har eksisterende abonnenter kan gruppe indstillinger ikke ændres!';
$txt['paid_mod_delete_warning'] = '<strong>ADVARSEL</strong><br /><br />Hvis du sletter dette kontingent vil alle brugere der i øjeblikket allererede abonnerer på det, miste enhver adgang der er givet ud fra kontingentet. Med mindre du er sikker på at du vil gøre dette, anbefales det at du simpelthen deaktiverer kontingentet fremfor at slette det.<br />';
$txt['paid_mod_repeatable'] = 'Tillad brugere automatisk at forny dette kontingent';
$txt['paid_mod_allow_partial'] = 'Tillad delvis kontingent';
$txt['paid_mod_allow_partial_desc'] = 'Hvis denne funktion er aktiveret, i tilfælde af en bruger betaler mindre end krævet vil de blive tildelt kontigent for procentdelen af løbetiden de har betalt for.';
$txt['paid_mod_fixed_price'] = 'Kontigent for statisk pris og periode';
$txt['paid_mod_flexible_price'] = 'Kontigent pris varierer baserede på købt løbetid';
$txt['paid_mod_price_breakdown'] = 'Fleksibel pris oversigt';
$txt['paid_mod_price_breakdown_desc'] = 'Definer her hvor meget kontigentet skal koste udfra den periode de abonnerer for. For eksempel, 12USD for at abonnere for en måned, men kun 100USD for et år. Hvis du vil definere en pris for en periode kan du lade feltet være tomt.';
$txt['flexible'] = 'Fleksibel';

$txt['paid_per_day'] = 'Pris Per Dag';
$txt['paid_per_week'] = 'Pris Per Uge';
$txt['paid_per_month'] = 'Pris Per Måned';
$txt['paid_per_year'] = 'Pris Per År';
$txt['day'] = 'Dag';
$txt['week'] = 'Uge';
$txt['month'] = 'Måned';
$txt['year'] = 'År';

// View subscribed users.
$txt['viewing_users_subscribed'] = 'Viser Brugere';
$txt['view_users_subscribed'] = 'Viser brugere der har kontingent til: &quot;%1$s&quot;';
$txt['no_subscribers'] = 'Der er i øjeblikket ingen der anvender dette kontingent.';
$txt['add_subscriber'] = 'Tilføj et nyt medlem';
$txt['edit_subscriber'] = 'Rediger medlem';
$txt['delete_selected'] = 'Slet markerede';
$txt['complete_selected'] = 'Færdiggør Valgte';

// @todo These strings are used in conjunction with JavaScript.  Use numeric entities.
$txt['delete_are_sure'] = 'Er du sikker på du vil slette alle enheder for det valgte kontigent?';
$txt['complete_are_sure'] = 'Er du sikker på du vil udføre valgte kontigenter?';

$txt['start_date'] = 'Start Dato';
$txt['end_date'] = 'Slut Dato';
$txt['start_date_and_time'] = 'Start Dato og Tid';
$txt['end_date_and_time'] = 'Slut Dato og Tid';
$txt['one_username'] = 'Angiv kun et brugernavn.';
$txt['minute'] = 'Minut';
$txt['error_member_not_found'] = 'Angivne bruger kunne ikke findes';
$txt['member_already_subscribed'] = 'Denne bruger abonnerer allerede på dette kontigent. Rediger deres eksisterende kontigent.';
$txt['search_sub'] = 'Find Bruger';

// Make payment.
$txt['paid_confirm_payment'] = 'Bekræft Betaling';
$txt['paid_confirm_desc'] = 'For at fortsætte med betalingen bedes du venligst kontrollere detaljerne herunder og derefter klikke &quot;Bestil&quot;';
$txt['paypal'] = 'PayPal';
$txt['paid_confirm_paypal'] = 'For at betale med <a href="http://www.paypal.com">PayPal</a> skal du klikke på knappen herunder. Du vil blive dirigeret videre til PayPal for at gennemføre betalingen.';
$txt['paid_paypal_order'] = 'Bestil med PayPal';
$txt['authorize'] = 'Authorize.Net';
$txt['paid_confirm_authorize'] = 'For at betale med <a href="http://www.authorize.net">Authorize.Net</a> skal du klikke på knappen herunder. Du vil blive dirigeret videre til Authorize.Net for at gennemføre betalingen.';
$txt['paid_authorize_order'] = 'Bestil med Authorize.Net';
$txt['2co'] = '2checkout';
$txt['paid_confirm_2co'] = 'For at betale med <a href="http://www.2com.com">2co.com</a> skal du klikke på knappen herunder. Du vil blive dirigeret videre til 2co.com for at gennemføre betalingen.';
$txt['paid_2co_order'] = 'Bestil med 2co.com';
$txt['paid_done'] = 'Betalingen er gennemført';
$txt['paid_done_desc'] = 'Tak for din betaling. Kontigentet vil blive aktiveret når transaktionen er verificeret.';
$txt['paid_sub_return'] = 'Returner til kontigenter';
$txt['paid_current_desc'] = 'Nedenunder er en liste over alle dine nuværende og tidligere kontigenter. Vælg fra listen ovenover for at forlænge et eksisterende kontigent.';
$txt['paid_admin_add'] = 'Tilføj dette kontigent';

$txt['paid_not_set_currency'] = 'Du har endnu ikke opsat din valuta. Gør venligst dette fra sektionen <a href-"%1$s">Indstillinger</a> før du fortsætter.';
$txt['paid_no_cost_value'] = 'Du skal angive en pris og kontigent længde.';
$txt['paid_all_freq_blank'] = 'Du skal angive en pris for mindst en af de fire varigheder.';

// Some error strings.
$txt['paid_no_data'] = 'Ingen gyldige data blev sendt til scriptet.';

$txt['paypal_could_not_connect'] = 'Kunne ikke forbinde til PayPal server';
$txt['paypal_currency_unkown'] = 'Valuta koden fra PayPal (%1$s) stemmer ikke overens med koden i dine indstillinger (%2$s)';
$txt['paid_sub_not_active'] = 'Dette kontingent modtager ikke nye brugere.';
$txt['paid_disabled'] = 'Betalte kontingenter er ikke aktiv.';
$txt['paid_unknown_transaction_type'] = 'Ukendt Betalt kontigent transaktions type.';
$txt['paid_empty_member'] = 'Betalt kontigent håndtering kunne ikke finde medlemsID';
$txt['paid_could_not_find_member'] = 'Der kunne ikke findes en betalt kontingent håndtering for brugeren med ID %1$d.';
$txt['paid_count_not_find_subscription'] = 'Betalt kontigent håndtering kunne ikke finde kontigent for bruger ID: %1$s, kontigent ID: %2$s';
$txt['paid_count_not_find_subscription_log'] = 'Betalt kontigent håndtering kunne ikke finde kontigent log postering for bruger ID: %1$s, kontigent ID: %2$s';
$txt['paid_count_not_find_outstanding_payment'] = 'Kunne ikke finde udestående betaltingspostering for bruger ID: %1$s, kontigent ID: %2$s så ignorerer';
$txt['paid_admin_not_setup_gateway'] = 'Beklager, administratoren har ikke færdigjort opsætningen af betale kontigenter. Kom tilbage senere.';
$txt['paid_make_recurring'] = 'Gør dette til en tilbagevendende indbetaling';

$txt['subscriptions'] = 'Kontingenter';
$txt['subscription'] = 'Kontingent';
$txt['subscribers'] = 'Kontingenter';
$txt['paid_subs_desc'] = 'Herunder er en liste over alle kontingenter der er til rådighed på dette site.';
$txt['paid_subs_none'] = 'Der er i øjeblikket ingen betalte kontingenter tilgængelige.';

$txt['paid_current'] = 'Eksisterende kontingenter';
$txt['pending_payments'] = 'Afventende Betalinger';
$txt['pending_payments_desc'] = 'Denne bruger har forsøgt at lave følgende indbetaling for dette kontigent men verificering er ikke blevet modtaget af forum. Hvis du er sikker på at betalingen er modtaget klik &quot;accepter&quot; til kontigent. Alternativt kan du klikke &quot;Fjern&quot; for at fjerne alle referencer til betalingen.';
$txt['pending_payments_value'] = 'Værdi';
$txt['pending_payments_accept'] = 'Accepter';
$txt['pending_payments_remove'] = 'Fjern';