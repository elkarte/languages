<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'ElkArte bruger hjælp';

$txt['manual_welcome'] = 'Velkommen til %s, drevet af ElkArte Forum software!';
$txt['manual_introduction'] = 'ElkArte er den elegante, effektive, kraftfulde og gratis forum software som dette site benytter. Det tillader brugere at kommunikere i diskussionsemner ud fra et givent emne, på en udtænkt og organiseret måde. Ydermere, besidder det en række funktioner som slutbrugere kan benytte sig af. Hjælpen til mange af funktionerne, kan fås ved at klikke på spørgsmålstegnet, ud fra den pågældende funktion eller sektion. Eller ved at benytte en af de tilstedeværende links på denne side. Disse links vil bringe dig til ElkArte\'s centralt placerede dokumentation, på ElkArte officielle site.';
$txt['manual_docs_and_credits'] = 'For yderligere information om hvordan ElkArte benyttes, kan du besøge <a href="%1$s" target="_blank" class="new_win">Dokumentation Wiki</a> eller læse <a href="%2$s">credits</a> for at finde ud af hvem der har gjort ElkArte til hvad det er i dag.';

$txt['manual_section_registering_title'] = 'Registrering';
$txt['manual_section_logging_in_title'] = 'Logge ind';
$txt['manual_section_profile_title'] = 'Profil';
$txt['manual_section_search_title'] = 'Søg';
$txt['manual_section_posting_title'] = 'At poste';
$txt['manual_section_bbc_title'] = 'Bulletin Board Code (BBC)';
$txt['manual_section_personal_messages_title'] = 'Personlige beskeder';
$txt['manual_section_memberlist_title'] = 'Medlemsliste';
$txt['manual_section_calendar_title'] = 'Kalender';
$txt['manual_section_features_title'] = 'Funktioner';

$txt['manual_section_registering_desc'] = 'Mange fora forlanger at brugerne registrerer sig, for at få fuld adgang.';
$txt['manual_section_logging_in_desc'] = 'Når først brugere er registreret, skal de logge ind på deres konto.';
$txt['manual_section_profile_desc'] = 'Hvert medlem har sin egen personlige profil.';
$txt['manual_section_search_desc'] = 'Søgeværktøjet er et ekstremt hjælpsomt værktøj, til at finde information i emner og indlæg.';
$txt['manual_section_posting_desc'] = 'Hele ideen med et forum, er at brugere kan udtrykke sig.';
$txt['manual_section_bbc_desc'] = 'Indlæg kan peppes op med brug af en smule BBC.';
$txt['manual_section_personal_messages_desc'] = 'Brugere kan sende personlige beskeder til hinanden.';
$txt['manual_section_memberlist_desc'] = 'Medlemslisten viser alle medlemmerne i et forum.';
$txt['manual_section_calendar_desc'] = 'Brugere kan med kalenderen holde styr på begivenheder, ferie- og helligdage, samt fødselsdage.';
$txt['manual_section_features_desc'] = 'Her er en liste over de mest populære funktioner i ElkArte.';