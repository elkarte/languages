<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Administrer tilladelser';
$txt['permissions_modify'] = 'Rediger';
$txt['permissions_view'] = 'Se';
$txt['permissions_allowed'] = 'Tilladt';
$txt['permissions_denied'] = 'Nægtet';
$txt['permission_cannot_edit'] = '<strong>Bemærk:</strong> Du kan ikke redigere denne tilladelsesprofil, da den er inkluderet i forum softwaren som en prædefineret profil. Hvis du ænsker at ændre tilladelser i denne profil, skal du først oprette en kopi af profilen. Du kan <a href="%1$s">udføre denne opgave ved at klikke her</a>.';

$txt['permissions_for_profile'] = 'Tilladelser for profil';
$txt['permissions_boards_desc'] = 'Listen herunder viser hvilke sæt af tilladelser der er blevet tildelt til hvert board i dit forum. Du kan redigere den tildelte tilladelsesprofil ved enten at klikke på boardnavnet eller vælg &quot;rediger alle&quot; fra bunden af siden. For at redigere selve profilen, skal du blot klikke på profilnavnet.';
$txt['permissions_board_all'] = 'Rediger alle';
$txt['permission_profile'] = 'Tilladelsesprofil';
$txt['permission_profile_desc'] = 'Hvilken <a href="%1$s">tilladelsesprofil</a> boardet skal anvende.';
$txt['permission_profile_inherit'] = 'Nedarv fra ovenliggende board';

$txt['permissions_profile'] = 'Profil';
$txt['permissions_profiles_desc'] = 'Tilladelsesprofiler er tildelt til  individuelle boards for at tillade dig nemt at administrere dine sikkerhedsindstillinger. Fra dette område kan du oprette, redigere og slette tilladelsesprofiler.';
$txt['permissions_profiles_change_for_board'] = 'Rediger tilladelsesprofil for: &quot;%1$s&quot;';
$txt['permissions_profile_default'] = 'Standard';
$txt['permissions_profile_no_polls'] = 'Ingen afstemninger';
$txt['permissions_profile_reply_only'] = 'Kun svar';
$txt['permissions_profile_read_only'] = 'Kun læsning';

$txt['permissions_profile_rename'] = 'Omdøb alle';
$txt['permissions_profile_edit'] = 'Rediger profiler';
$txt['permissions_profile_new'] = 'Ny profil';
$txt['permissions_profile_new_create'] = 'Opret';
$txt['permissions_profile_name'] = 'Profilnavn';
$txt['permissions_profile_used_by'] = 'Brugt af';
$txt['permissions_profile_used_by_one'] = '1 board';
$txt['permissions_profile_used_by_many'] = '%1$d Boards';
$txt['permissions_profile_used_by_none'] = 'Ingen boards';
$txt['permissions_profile_do_edit'] = 'Rediger';
$txt['permissions_profile_do_delete'] = 'Slet';
$txt['permissions_profile_copy_from'] = 'Kopier tilladelser fra';

$txt['permissions_includes_inherited'] = 'Nedarvede grupper';
$txt['permissions_includes_inherited_from'] = 'Nedarvet fra:';

$txt['permissions_all'] = 'alle';
$txt['permissions_none'] = 'ingen';
$txt['permissions_set_permissions'] = 'Sæt tilladelser';

$txt['permissions_advanced_options'] = 'Avancerede valgmuligheder';
$txt['permissions_with_selection'] = 'Med det valgte';
$txt['permissions_apply_pre_defined'] = 'Indstil pre-defineret tilladelsesprofil';
$txt['permissions_select_pre_defined'] = 'Vælg en pre-defineret profil';
$txt['permissions_copy_from_board'] = 'Kopier tilladelser fra dette board';
$txt['permissions_select_board'] = 'Vælg et board';
$txt['permissions_like_group'] = 'Sæt tilladelser som i denne gruppe';
$txt['permissions_select_membergroup'] = 'Vælg en medlemsgruppe';
$txt['permissions_add'] = 'Tilføj tilladelse';
$txt['permissions_remove'] = 'Fjern tilladelse';
$txt['permissions_deny'] = 'Nægt tilladelse';
$txt['permissions_select_permission'] = 'Vælg en tilladelse';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Du kan kun vælge en handling til at ændre tilladelserne';
$txt['permissions_no_action'] = 'Ingen handling valgt';
$txt['permissions_deny_dangerous'] = 'Du er ved at nægte en eller flere tilladelser.\\nDette kan være farligt og medføre uventede resultater, hvis du ikke er sikker at ingen \\"ved et uheld\\" er i gruppen eller grupperne du nægter tilladelser til.\\n\\nEr du sikker på at du vil fortsætte?';

$txt['permissions_modify_group'] = 'Rediger gruppe';
$txt['permissions_general'] = 'Generelle Tilladelser';
$txt['permissions_board'] = 'Standard board-tilladelser';
$txt['permissions_board_desc'] = '<strong>Bemærk</strong>: ændring af disse boardtilladelser vil påvirke alle boards som i øjeblikket er tildelt &quot;Standard&quot; tilladelsesprofilen. Boards som ikke anvender &quot;Standard&quot; profilen, vil ikke blive berørt af ændringer på denne side.';
$txt['permissions_commit'] = 'Gem ændringer';
$txt['permissions_on'] = 'i profilen';
$txt['permissions_local_for'] = 'Tilladelser for gruppe';
$txt['permissions_option_on'] = 'N';
$txt['permissions_option_off'] = 'A';
$txt['permissions_option_deny'] = 'N';
$txt['permissions_option_desc'] = 'For hver tilladelse kan du vælge enten \'Tillad\' (T), \'Afvis\' (A), eller <span class="alert">\'Nægt\' (N)</span>.<br /><br />Husk på at hvis du nægter en tilladelse, vil alle medlemmer - inklusiv moderatører - i den gruppe blive nægtet adgang.<br />Af denne grund, bør du bruge Nægt med forsigtighed, kun når det er <strong>nødvendigt</strong>. Modsat, forbyder Afvis kun adgang, medmindre tilladt af andre tilladelser.';

$txt['permissiongroup_general'] = 'Generelt';
$txt['permissionname_view_stats'] = 'Se forumstatistik';
$txt['permissionhelp_view_stats'] = 'Forumstatistik er en side med optælning af al statistik på forummet, såsom medlemsantal, antal daglige posteringer, og forskellige top 10 statistikker. Aktivering af dette link, tilføjer et link i bunden af indexet (\'[Flere stats]\').';
$txt['permissionname_view_mlist'] = 'Vis bruger liste og grupper';
$txt['permissionhelp_view_mlist'] = 'Brugerlisten viser alle brugere som er registreret i dit forum. Der kan sorteres og søges i listen. Der er linket til brugerlisten både fra boardindekset og stats siden, ved at klikke på antallet af brugere. Dette gælder også for guppesiden, som er en mini-brugerliste over brugere i den pågældende gruppe.';
$txt['permissionname_who_view'] = 'Se hvem er online';
$txt['permissionhelp_who_view'] = 'Hvem er online viser alle medlemmer som nu er online, og hvad de i øjeblikket foretager sig. Denne tilladelse vil virke hvis du har aktiveret den i \'Funktioner og Indstillinger\'. Du kan tilgå \'Hvem er online\' skærmen ved at klikke linket i  \'Brugere online\' sektionen på boardindexet.';
$txt['permissionname_search_posts'] = 'Søge efter indlæg og emner';
$txt['permissionhelp_search_posts'] = 'Søgetilladelsen giver brugeren ret til at søge i alle boards vedkommende har adgang til. Når \'Søg efter indlæg og emner\' er aktiveret, vil en \'Søg\' knap være synlig i forummets topbar (Menuen i toppen).';
$txt['permissionname_karma_edit'] = 'Ændre andre personers karma';
$txt['permissionhelp_karma_edit'] = 'Karma er en funktion der viser populariteten af en bruger. For at kunne bruge denne funktion, skal du have aktiveret den i \'Funktioner og Indstillinger\'. Denne tilladelse vil give en brugergruppe muligheden for at stemme. Tilladelsen har ikke effekt på gæster.';
$txt['permissionname_like_posts'] = 'Tillad at like andre brugeres indlæg';
$txt['permissionhelp_like_posts'] = 'Like er en funktion der viser populariteten af et indlæg. For at kunne bruge denne funktion, skal du have aktiveret den i \'Funktioner og Indstillinger\'. Denne tilladelse vil give en brugergruppe muligheden for at like et indlæg, eller fjerne deres like. Tilladelsen har ikke effekt på gæster.';
$txt['permissionname_like_posts_stats'] = 'Se Like indlæg statistik';
$txt['permissionhelp_like_posts_stats'] = 'Dette vil tillade brugere at se statistik af Like indlæg';
$txt['permissionname_disable_censor'] = 'Deaktiv censur af ord';
$txt['permissionhelp_disable_censor'] = 'Tillad brugere at deaktivere censur af ord.';

$txt['permissiongroup_pm'] = 'Personlige besked-indstillinger';
$txt['permissionname_pm_read'] = 'Læse personlige beskeder';
$txt['permissionhelp_pm_read'] = 'Denne tilladelse giver brugere adgang til det personlige beskedcenter, samt ret til at læse deres personlige beskeder. Uden denne tilladelse, er en bruger ikke i stand til at sende personlige beskeder.';
$txt['permissionname_pm_send'] = 'Sende personlige beskeder';
$txt['permissionhelp_pm_send'] = 'Sende personlige beskeder til andre registrerede medlemmer. Kræver at \'Læse personlige beskeder\' også er markeret.';
$txt['permissionname_send_email_to_members'] = 'Send email';
$txt['permissionhelp_send_email_to_members'] = 'Send email til andre registrerede brugere.';

$txt['permissiongroup_calendar'] = 'Kalender';
$txt['permissionname_calendar_view'] = 'Se kalenderen';
$txt['permissionhelp_calendar_view'] = 'Kalenderen viser for hver måned fødselsdage, begivenheder og feriedage. Tilladelsen her giver adgang til denne. Såfremt tilladelsen er aktiveret, vil en knap blive tilføjet til menuen i toppen og en liste vil blive vist i bunden af boardindekset med nuværende og kommende fødselsdage, begivenheder og feriedage. Kalenderen skal yderligere være aktiveret fra \'Grundlæggende funktioner\'.';
$txt['permissionname_calendar_post'] = 'Oprette begivenheder i kalenderen';
$txt['permissionhelp_calendar_post'] = 'En begivenhed er et emne, som er linket til en bestemt eller flere datoer. Oprettelse af begivenheder kan gøres fra kalenderen. En begivenhed kan kun oprettes, hvis brugeren har tilladelse til at oprette nye emner.';
$txt['permissionname_calendar_edit'] = 'Redigere begivenheder i kalenderen';
$txt['permissionhelp_calendar_edit'] = 'En begivenhed er et emne der linker til en eller flere sammenhængende datoer. En begivenhed kan redigeres ved at klikke på det røde jokertegn (*) ved begivenheden i kalenderen. For at kunne redigere en begivenhed, skal brugeren have tilstrækkelige tilladelser til at redigere det første indlæg i emnet som linker til begivenheden.';
$txt['permissionname_calendar_edit_own'] = 'Egne begivenheder';
$txt['permissionname_calendar_edit_any'] = 'Enhver begivenhed';

$txt['permissiongroup_maintenance'] = 'Forum administration';
$txt['permissionname_admin_forum'] = 'Administrere forum og database';
$txt['permissionhelp_admin_forum'] = 'Denne tilladelse gør en bruger i stand til at:
	<ul class="normallist">
		<li>ændre forum, database- samt temaindstilinger</li>
		<li>administrere pakker</li>
		<li>bruge forum- og vedligeholdelsesværktøjer til databasen</li>
		<li>Læse fejl- og moderationslogs</li>
	</ul> Brug denne tilladelse med forsigtighed, da den er meget magtfuld.';
$txt['permissionname_manage_boards'] = 'Administrere boards og kategorier';
$txt['permissionhelp_manage_boards'] = 'Denne tilladelse giver adgang til at oprette, redigere, samt fjerne boards og kategorier.';
$txt['permissionname_manage_attachments'] = 'Administrere vedhæftninger og avatarer';
$txt['permissionhelp_manage_attachments'] = 'Denne tilladelse tillader adgang til \'vedhæftingsadministrering\' under \'Forum\', hvor alle vedhæftinger og  avatars er listet og kan blive fjernet.';
$txt['permissionname_manage_smileys'] = 'Administrere smileys og indlægsikoner';
$txt['permissionhelp_manage_smileys'] = 'Dette giver adgang til smileycenteret. I det kan du tilføje, redigere og fjerne smileys og smileysæt. Hvis du har aktiveret brugerdefinerede indlægsikoner, kan du også tilføje og redigere disse med denne tilladelse.';
$txt['permissionname_edit_news'] = 'Redigere nyheder';
$txt['permissionhelp_edit_news'] = 'Denne funktion tillader en tilfældig nyhedslinie at blive vist på hver side. For at bruge nyhedsfunktionen skal den aktiveres i forumindstillingerne.';
$txt['permissionname_access_mod_center'] = 'Have adgang til moderationscentret';
$txt['permissionhelp_access_mod_center'] = 'Med denne tilladelse kan ethvert medlem i denne gruppe få adgang til moderationscentret hvorfra de vil have adgang til funktionaliteter for at gøre moderation lettere. Bemærk at dette ikke giver øvrige moderationsprivilegier.';

$txt['permissiongroup_member_admin'] = 'Medlemsadministration';
$txt['permissionname_moderate_forum'] = 'Moderere forummedlemmer';
$txt['permissionhelp_moderate_forum'] = 'Denne tilladelse inkluderer alle vigtige medlems moderationsfunktioner:<ul class="normallist"><li>adgang til registrerings administration</li><li>adgang til at se/slette medlemmers skærmvisning</li><li>udviddet profil-info, inklusive spor IP/bruger og (skjult) onlinestatus</li><li>aktivere kontoer</li><li>modtage godkendelsesbeskeder og godkende konti</li><li>imun til at ignorere PM</li><li>andre små ting</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Administrere og tildele medlemsgrupper';
$txt['permissionhelp_manage_membergroups'] = 'Denne tilladelse giver en bruger lov til at redigere medlemsgrupper og tilegne  medlemsgrupper til andre medlemmer.';
$txt['permissionname_manage_permissions'] = 'Administrere tilladelser';
$txt['permissionhelp_manage_permissions'] = 'Denne funktion tillalder en bruger at redigere alle tilladelser til en medlemgruppe, globalt eller for individuelle boards.';
$txt['permissionname_manage_bans'] = 'Administrere bandlysningslisten';
$txt['permissionhelp_manage_bans'] = 'Denne tilladelse giver en bruger mulighed for at tilføje eller fjerne brugernavne, IP adresser, hostnavne og email adresser til og fra en liste over bandlyste brugere. Den giver også tilladelse til at vise og slette log poster over bandlyste brugere der forsøger at logge ind.';
$txt['permissionname_send_mail'] = 'Broadcast til flere brugere';
$txt['permissionhelp_send_mail'] = 'Masse-email alle forumbrugere eller et par enkelte brugergrupper enten via email eller personlig besked (den sidste kræver \'Send Personlige Beskeder\' tilladelsen).';
$txt['permissionname_issue_warning'] = 'Udstede advarsler til medlemmer';
$txt['permissionhelp_issue_warning'] = 'Udstede en advarsel til medlemmer i forummet og ændre medlemmets advarselsniveau. Kræver at advarselssystemet er aktiveret.';

$txt['permissiongroup_profile'] = 'Medlemsprofiler';
$txt['permissionname_profile_view'] = 'Se oversigt over profil samt statistik';
$txt['permissionhelp_profile_view'] = 'Denne tilladelse giver brugere tilladelse til at klikke på et brugernavn og se en oversigt over profilindstillinger, statistikker og alle indlæg fra den bruger.';
$txt['permissionname_profile_view_own'] = 'Egen profil';
$txt['permissionname_profile_view_any'] = 'Enhver profil';
$txt['permissionname_profile_identity'] = 'Redigere kontoindstillinger';
$txt['permissionhelp_profile_identity'] = 'Kontoindstillinger er de grundlæggende indstillinger for en profil, såsom kodeord, email adresse, brugergrupper og foretrukket sprog.';
$txt['permissionname_profile_identity_own'] = 'Egen profil';
$txt['permissionname_profile_identity_any'] = 'Enhver profil';
$txt['permissionname_profile_extra'] = 'Redigere yderligere profil-indstillinger';
$txt['permissionhelp_profile_extra'] = 'Yderligere profilindstillinger indeholder indstillinger for avatars, temaindstillinger, abonnement og personlige beskeder.';
$txt['permissionname_profile_extra_own'] = 'Egen profil';
$txt['permissionname_profile_extra_any'] = 'Enhver profil';
$txt['permissionname_profile_title'] = 'Redigere brugerdefinerede titler';
$txt['permissionhelp_profile_title'] = 'Den brugerdefinerede titel vises i emnevisning under hver brugers profil, for de brugere der har angivet en brugerdefineret titel.';
$txt['permissionname_profile_title_own'] = 'Egen profil';
$txt['permissionname_profile_title_any'] = 'Enhver profil';
$txt['permissionname_profile_remove'] = 'Slette konto';
$txt['permissionhelp_profile_remove'] = 'Denne funktion giver en bruger ret til at slette sin konto, når sat til \'Egen konto\'.';
$txt['permissionname_profile_remove_own'] = 'Egen konto';
$txt['permissionname_profile_remove_any'] = 'Enhver konto';
$txt['permissionname_profile_set_avatar'] = 'Vælg en avatar';
$txt['permissionhelp_profile_set_avatar'] = 'Hvis valgt giver dette tilladelse til en bruger at vælge en avatar.';

$txt['permissiongroup_general_board'] = 'Generelt';
$txt['permissionname_moderate_board'] = 'Moderere board';
$txt['permissionhelp_moderate_board'] = 'Moderer board tilladelsen giver nogle få mindre tilladelser der gør en moderator til en virkelig moderator. Tilladelser inkluderer svar på låste emner, ændring af udløbstid- og læsnig af afstemingsresultater.';

$txt['permissiongroup_topic'] = 'Emner';
$txt['permissionname_post_new'] = 'Oprette nye emner';
$txt['permissionhelp_post_new'] = 'Denne tilladelse giver brugere ret til at oprette ny emner. Den giver ikke tilladelse til at oprette svar i emner.';
$txt['permissionname_merge_any'] = 'Flette ethvert emne';
$txt['permissionhelp_merge_any'] = 'Flet to eller flere emner til et. Rækkefølgen af indlæg i det flettede emne vil blive baseret på tidspunktet de blev oprettet. En bruger kan kun flette emner på de boards de har tilladelse til at flette emner på. For at flette flere emner på en gang, skal brugeren have aktiveret hurtig-moderation i deres profil indstillinger.';
$txt['permissionname_split_any'] = 'Dele ethvert emne';
$txt['permissionhelp_split_any'] = 'Dele et emne over i to separate emner.';
$txt['permissionname_send_topic'] = 'Sende emner til venner';
$txt['permissionhelp_send_topic'] = 'Denne tilladelse giver en bruger tilladelse til at maile et emne til en ven, ved at tilføje deres e-mail-adresse og tillader tilføjelsen af et indlæg.';
$txt['permissionname_make_sticky'] = 'Pin emner';
$txt['permissionhelp_make_sticky'] = 'Fremhævede emner er emner der altid forbliver i toppen af et board. Disse kan være brugbare til annonceringer eller andre vigtige beskeder.';
$txt['permissionname_move'] = 'Flyt emner';
$txt['permissionhelp_move'] = 'Flytter et emne fra et board til et andet board. Brugere kan kun vælge destinationsboards som de er tilladt adgang til.';
$txt['permissionname_move_own'] = 'Egne emner';
$txt['permissionname_move_any'] = 'Ethvert emne';
$txt['permissionname_lock'] = 'Låse emner';
$txt['permissionhelp_lock'] = 'Denne tilladelse giver en bruger adgang til at låse et emne. Dette kan gøres for at sikre at ingen kan svare på et emne. Kun brugere med en \'Moderer board\' tilladelse kan stadig skrive i låste emner.';
$txt['permissionname_lock_own'] = 'Egne emner';
$txt['permissionname_lock_any'] = 'Ethvert emne';
$txt['permissionname_remove'] = 'Slette emner';
$txt['permissionhelp_remove'] = 'Slette hele emner. Bemærk at denne tilladelse ikke giver en bruger lov til at fjerne enkelte indlæg et emne!';
$txt['permissionname_remove_own'] = 'Egne emner';
$txt['permissionname_remove_any'] = 'Ethvert emne ';
$txt['permissionname_post_reply'] = 'Oprette svar i emner';
$txt['permissionhelp_post_reply'] = 'Denne tilladelse giver lov til at svare på emner .';
$txt['permissionname_post_reply_own'] = 'Egne emner';
$txt['permissionname_post_reply_any'] = 'Ethvert emne';
$txt['permissionname_modify_replies'] = 'Ændre i svar der oprettes i egne emner';
$txt['permissionhelp_modify_replies'] = 'Denne tilladelse giver en bruger der startede et emne ret til at ændre i alle følgende svar i dette.';
$txt['permissionname_delete_replies'] = 'Slette svar i egne emner';
$txt['permissionhelp_delete_replies'] = 'Denne tilladelse giver brugeren der oprettede emnet lov til at slette svar fra emnet.';
$txt['permissionname_announce_topic'] = 'Annoncere emne';
$txt['permissionhelp_announce_topic'] = 'Dette tillader en bruger at sende en annoncerings email om et emne til alle brugere eller til nogle få brugergrupper.';

$txt['permissionname_approve_emails'] = 'Moderer indlæg efter email-fejl';
$txt['permissionhelp_approve_emails'] = 'Tillad moderatører adgang til Indlæg efter email-fejl log for at udføre handlinger såsom godkend, slet, vis og bounce. Bemærk, siden systemet muligvis ikke altid ved hvilket board et indlæg går til, bør denne tilladelse kun gives til brugere med fuld board adgang.';
$txt['permissionname_postby_email'] = 'Indlæg via email';
$txt['permissionhelp_postby_email'] = 'Denne tilladelse giver brugere mulighed for at starte og svare på emner og personlige beskeder meddelselser via email.';

$txt['permissiongroup_post'] = 'Indlæg';
$txt['permissionname_delete'] = 'Slette indlæg';
$txt['permissionhelp_delete'] = 'Fjerne indlæg. Denne tilladelse giver ikke adgang til at slette det første indlæg i et emne.';
$txt['permissionname_delete_own'] = 'Egne indlæg';
$txt['permissionname_delete_any'] = 'Ethvert indlæg';
$txt['permissionname_modify'] = 'Redigere indlæg';
$txt['permissionhelp_modify'] = 'Rediger indlæg';
$txt['permissionname_modify_own'] = 'Egne indlæg';
$txt['permissionname_modify_any'] = 'Ethvert indlæg';
$txt['permissionname_report_any'] = 'Kan anmelde indlæg til moderatorer';
$txt['permissionhelp_report_any'] = 'Denne tilladelse tilføjer et link til hvert indlæg, der tillader en bruger at anmelde et indlæg til en moderator. Ved anmeldelsen, modtager alle moderatorer i det pågældende board en e-mail med et link til det anmeldte indlæg, samt en beskrivelse af problemet (som oplyst af den anmeldende bruger).';

$txt['permissiongroup_poll'] = 'Afstemninger';
$txt['permissionname_poll_view'] = 'Se afstemninger';
$txt['permissionhelp_poll_view'] = 'Denne tilladelse tillader en bruger til at se afstemninger. Uden denne tilladelse, vil brugeren kun kunne se emnet.';
$txt['permissionname_poll_vote'] = 'Stemme i afstemninger';
$txt['permissionhelp_poll_vote'] = 'Denne tilladelse giver (registrerede) brugere lov at afgive en stemme. Dette gælder ikke gæster.';
$txt['permissionname_poll_post'] = 'Oprette afstemninger';
$txt['permissionhelp_poll_post'] = 'Denne tilladelse giver en bruger ret til at oprette nye afstemninger. Det er nødvendigt at brugeren har tilladelsen "Oprette nye emner".';
$txt['permissionname_poll_add'] = 'Tilføje afstemning til emner';
$txt['permissionhelp_poll_add'] = 'Tilføje afstemning til emner, gør en bruger i stand til at tilføje en afstemning til et emne, efter at det er blevet oprettet. Denne tilladelse kræver tilstrækkelig adgang til at redigere det første indlæg i et emne.';
$txt['permissionname_poll_add_own'] = 'Egne emner ';
$txt['permissionname_poll_add_any'] = 'Ethvert emne ';
$txt['permissionname_poll_edit'] = 'Redigere afstemninger';
$txt['permissionhelp_poll_edit'] = 'Denne tilladelse tillader at redigere de enkelte punkter i en afstemning, samt nulstille denne. For at kunne redigere maksimum antal stemmer og udløbstiden, skal en bruger have \'Moderer board\' tilladelse.';
$txt['permissionname_poll_edit_own'] = 'Egen afstemning';
$txt['permissionname_poll_edit_any'] = 'Enhver afstemning';
$txt['permissionname_poll_lock'] = 'Låse afstemninger';
$txt['permissionhelp_poll_lock'] = 'Låsning af afstemninger låser for afgivelse af flere stemmer.';
$txt['permissionname_poll_lock_own'] = 'Egen afstemning';
$txt['permissionname_poll_lock_any'] = 'Enhver afstemning';
$txt['permissionname_poll_remove'] = 'Slette afstemninger';
$txt['permissionhelp_poll_remove'] = 'Denne tilladelse tillader fjernelse af afstemninger.';
$txt['permissionname_poll_remove_own'] = 'Egen afstemning';
$txt['permissionname_poll_remove_any'] = 'Enhver afstemning';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Gem kladder over nye indlæg';
$txt['permissionname_simple_post_draft'] = 'Gem kladder over nye indlæg';
$txt['permissionhelp_post_draft'] = 'Denne tilladelse giver brugere mulighed for at gemme kladder af deres indlæg så de kan færdigøre dem senere.';
$txt['permissionhelp_simple_post_draft'] = 'Denne tilladelse giver brugere mulighed for at gemme kladder af deres indlæg så de kan færdigøre dem senere.';
$txt['permissionname_post_autosave_draft'] = 'Gem automatisk kladder for nye indlæg';
$txt['permissionname_simple_post_autosave_draft'] = 'Gem automatisk kladder for nye indlæg';
$txt['permissionhelp_post_autosave_draft'] = 'Denne tilladelse giver brugere mulighed for automatisk at gemme deres indlæg som kladder så de undgår at miste deres arbejde i tilfælde af timeout, afbrudt forbindelse eller andre fejl. Tidsinterval for automatisk gemning er defineret i admin panelet.';
$txt['permissionhelp_simple_post_autosave_draft'] = 'Denne tilladelse giver brugere mulighed for automatisk at gemme deres indlæg som kladder så de undgår at miste deres arbejde i tilfælde af timeout, afbrudt forbindelse eller andre fejl. Tidsinterval for automatisk gemning er defineret i admin panelet.';
$txt['permissionname_pm_autosave_draft'] = 'Gem automatisk kladder for nye personlige beskeder';
$txt['permissionname_simple_pm_autosave_draft'] = 'Gem automatisk kladder for nye personlige beskeder';
$txt['permissionhelp_pm_autosave_draft'] = 'Denne tilladelse giver brugere mulighed for automatisk at gemme deres indlæg som kladder så de undgår at miste deres arbejde i tilfælde af timeout, afbrudt forbindelse eller andre fejl. Tidsinterval for automatisk gemning er defineret i admin panelet.';
$txt['permissionhelp_simple_post_autosave_draft'] = 'Denne tilladelse giver brugere mulighed for automatisk at gemme deres indlæg som kladder så de undgår at miste deres arbejde i tilfælde af timeout, afbrudt forbindelse eller andre fejl. Tidsinterval for automatisk gemning er defineret i admin panelet.';
$txt['permissionname_pm_draft'] = 'Gem kladder for personlige beskeder';
$txt['permissionname_simple_pm_draft'] = 'Gem kladder for personlige beskeder';
$txt['permissionhelp_pm_draft'] = 'Denne tilladelse giver brugere mulighed for at gemme kladder af deres personlige beskeder så de kan færdigøre dem senere.';
$txt['permissionhelp_simple_pm_draft'] = 'Denne tilladelse giver brugere mulighed for at gemme kladder af deres personlige beskeder så de kan færdigøre dem senere.';

$txt['permissiongroup_approval'] = 'Moderation af indlæg';
$txt['permissionname_approve_posts'] = 'Godkende objekter der afventer moderation';
$txt['permissionhelp_approve_posts'] = 'Denne tilladelse tillader en bruger at godkende alle ikke-godkendte objekter i et board.';
$txt['permissionname_post_unapproved_replies'] = 'Oprette svar til emner, men skjul dem indtil de bliver godkendt';
$txt['permissionhelp_post_unapproved_replies'] = 'Denne tilladelse tillader en bruger at oprette svar til et emne. Svarene vil ikke vises, før de bliver godkendt af en moderator.';
$txt['permissionname_post_unapproved_replies_own'] = 'Egne emner';
$txt['permissionname_post_unapproved_replies_any'] = 'Ethvert emne';
$txt['permissionname_post_unapproved_topics'] = 'Oprette nye emner, men skjul dem indtil de er godkendt';
$txt['permissionhelp_post_unapproved_topics'] = 'Denne tilladelse gør en bruger i stand til at oprette et nyt emne, som skal godkendelse før det vises.';
$txt['permissionname_post_unapproved_attachments'] = 'Poste vedhæftninger, men skjule dem indtil de er godkendt';
$txt['permissionhelp_post_unapproved_attachments'] = 'Denne tilladelse gør brugeren i stand til at vedhæfte filer til deres indlæg De vedhæftede filer skal så godkendes før de vises for andre brugere.';

$txt['permissiongroup_notification'] = 'Abonnementer';
$txt['permissionname_mark_any_notify'] = 'Abonnere på svar';
$txt['permissionhelp_mark_any_notify'] = 'Dette valg tillader brugeren at modtage en notifikation, såfremt nogen svarer på et emne, brugeren abonnerer på.';
$txt['permissionname_mark_notify'] = 'Abonner på nye emner ';
$txt['permissionhelp_mark_notify'] = 'Abonner på ny emner er en funktion der tillader en bruger at modtage en mail hver gang et nyt emne oprettes i boards de abonnerer på.';

$txt['permissiongroup_attachment'] = 'Vedhæftninger';
$txt['permissionname_view_attachments'] = 'Se vedhæftninger';
$txt['permissionhelp_view_attachments'] = 'Vedhæftinger er filer som er vedhæftet i et indlæg. Denne funktion kan aktiveres i \'Vedhæftninger og avatarer \'. Siden der ikke linkes til vedhæftinger direkte, kan du forhindre download af dem for brugere der ikke har denne tilladelse.';
$txt['permissionname_post_attachment'] = 'Poste vedhæftninger';
$txt['permissionhelp_post_attachment'] = 'Vedhæftinger er filer der er vedhæftet til oprettede indlæg. Et indlæg kan indeholde flere vedhæftinger.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Tilladelses-indstillinger';
$txt['groups_manage_permissions'] = 'Medlemsgrupper der kan administrere tilladelser.';
$txt['permission_enable_deny'] = 'Aktiver muligheden for at kunne nægte tilladelser';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Hvis du deaktiverer denne valgmulighed, bliver \\\'Nægt\\\'-tilladelser opdateret til \\\'Afvis\\\'.';
$txt['permission_by_board_desc'] = 'Her kan du indstille hvilken tilladelsesprofil et board anvender. Du kan oprette nye tilladelsesprofiler fra menuen &quot;Rediger Profiler&quot;';
$txt['permission_settings_desc'] = 'Her kan du bestemme hvem der har adgang til at ændre tilladelser, såvel som hvor avanceret systemet med tilladelser skal være.';
$txt['permission_enable_postgroups'] = 'Aktiver tilladelser for grupper baseret på antallet af indlæg';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Deaktivering af denne indstilling vil fjerne tilladelser som i øjeblikket er sat til indlægsbaserede grupper';

$txt['permissions_post_moderation_desc'] = 'Fra denne side kan du nemt ændre hvilke grupper der har deres indlæg modereret udfra en bestemt tilladelsesprofil.';
$txt['permissions_post_moderation_deny_note'] = 'Bemærk at når du har avancerede tilladelser aktiveret, kan du ikke sætte tilladelserne &quot;nægt&quot; på denne side. Rediger venligst tilladelserne direkte såfremt du ønsker at anvende en nægtet tilladelse.';
$txt['permissions_post_moderation_select'] = 'Vælg profil';
$txt['permissions_post_moderation_new_topics'] = 'Nye emner';
$txt['permissions_post_moderation_replies_own'] = 'Egne svar';
$txt['permissions_post_moderation_replies_any'] = 'Ethvert svar';
$txt['permissions_post_moderation_attachments'] = 'Vedhæftninger';
$txt['permissions_post_moderation_legend'] = 'Tekstforklaring';
$txt['permissions_post_moderation_allow'] = 'Kan oprette';
$txt['permissions_post_moderation_moderate'] = 'Kan oprette men kræver godkendelse';
$txt['permissions_post_moderation_disallow'] = 'Kan ikke oprette';
$txt['permissions_post_moderation_group'] = 'Gruppe';

$txt['auto_approve_topics'] = 'Opret nye emner uden at kræve godkendelse';
$txt['auto_approve_replies'] = 'Skrive svar til emner uden at kræve godkendelse';
$txt['auto_approve_attachments'] = 'Vedhæfte filer uden at kræve godkendelse';
