<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Moderationscenter';
$txt['mc_main'] = 'Hovedmenu';
$txt['mc_logs'] = 'Logs';
$txt['mc_posts'] = 'Indlæg';
$txt['mc_groups'] = 'Brugere og grupper';

$txt['mc_view_groups'] = 'Se medlemsgrupper';

$txt['mc_description'] = '<strong>Velkommen, %1$s!</strong><br />Dette er dit &quot;Moderationscenter&quot;. Her fra kan du udføre alle moderationsopgaver tildelt til dig fra administratoren. Denne hovedside, indeholdet et overblik over alle de seneste aktiviteter i dit forum. Du kan <a href="%2$s">personliggøre layout ved at klikke her</a>.';
$txt['mc_group_requests'] = 'Medlemsgruppe-anmodninger';
$txt['mc_member_requests'] = 'Bruger forespørgsler';
$txt['mc_unapproved_posts'] = 'Ikke-godkendte indlæg';
$txt['mc_watched_users'] = 'Nyligt overvågede brugere';
$txt['mc_watched_topics'] = 'Overvågede emner';
$txt['mc_scratch_board'] = 'Grundlæggende Moderator Board';
$txt['mc_latest_news'] = 'Seneste nyheder';
$txt['mc_recent_reports'] = 'Seneste emnerapporter';
$txt['mc_warnings'] = 'Advarsler';
$txt['mc_notes'] = 'Moderator notater';
$txt['mc_required'] = 'Poster der afventer godkendelse';
$txt['mc_attachments'] = 'Vedhæftelser der afventer godkendelse';
$txt['mc_emailmod'] = 'Emails der afventer godkendelse';
$txt['mc_topics'] = 'Emner der afventer godkendelse';
$txt['mc_posts'] = 'Indlæg';
$txt['mc_groupreq'] = 'Gruppe forespørgsler der afventer godkendelse';
$txt['mc_memberreq'] = 'Brugere der afventer godkendelse';
$txt['mc_reports'] = 'Indlægrapporter der afventer godkendelse';
$txt['mc_pm_reports'] = 'Rapporterede personlige beskeder';

$txt['mc_cannot_connect_sm'] = 'Du er ikke i stand til at forbinde til ElkArte\'s seneste nyhedsfil.';

$txt['mc_recent_reports_none'] = 'Der er ikke nogen uafklarede rapporter';
$txt['mc_watched_users_none'] = 'Der er i øjeblikket ikke nogen overvågninger i gang.';
$txt['mc_group_requests_none'] = 'Der er ingen åbne forespørgsler for gruppemedlemsskab.';

$txt['mc_seen'] = '%1$s  senest set %2$s';
$txt['mc_seen_never'] = '%1$s aldrig set';
$txt['mc_groupr_by'] = 'af';

$txt['mc_reported_posts_desc'] = 'Her kan du evaluere alle rapporteringer af indlæg, rejst af medlemmer i forummet.';
$txt['mc_reported_pms_desc'] = 'Her kan du gennemse alle personlige beskeder der er blevet rapporteret af medlemmer af forum.';
$txt['mc_reportedp_active'] = 'Aktive rapporter';
$txt['mc_reportedp_closed'] = 'Gamle rapporter';
$txt['mc_reportedp_by'] = 'af';
$txt['mc_reportedp_reported_by'] = 'Rapporteret af';
$txt['mc_reportedp_last_reported'] = 'Senest rapporteret';
$txt['mc_reportedp_none_found'] = 'Ingen rapporter fundet';

$txt['mc_reportedp_details'] = 'Detaljer';
$txt['mc_reportedp_close'] = 'Luk';
$txt['mc_reportedp_open'] = 'Åbn';
$txt['mc_reportedp_ignore'] = 'Afvis';
$txt['mc_reportedp_unignore'] = 'Genåbne';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Er du sikker på du vil afvise og ignorere yderligere rapporteringer om dette indlæg?

Dette vil deaktivere yderligere rapporter for alle moderatører i forummet.';
$txt['mc_reportedp_close_selected'] = 'Luk valgte';

$txt['mc_groupr_group'] = 'Medlemsgrupper';
$txt['mc_groupr_member'] = 'Medlem';
$txt['mc_groupr_reason'] = 'Grund';
$txt['mc_groupr_none_found'] = 'Der er i øjeblikket ingen udestående anmodninger vedrørende medlemsgrupper.';
$txt['mc_groupr_submit'] = 'Afsend';
$txt['mc_groupr_reason_desc'] = 'Begrundelse for at afvise %1$s\'s forespørgsel for at tilslutte sig &quot;%2$s&quot;';
$txt['mc_groups_reason_title'] = 'Begrundelse for afvisning';
$txt['with_selected'] = 'Med valgte';
$txt['mc_groupr_approve'] = 'Godkend forespørgsel';
$txt['mc_groupr_reject'] = 'Afvis forespørgsel (Ingen begrundelse)';
$txt['mc_groupr_reject_w_reason'] = 'Afvis forespørgsel med en begrundelse';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Er du sikker på du ønsker at gøre dette?';

$txt['mc_unapproved_attachments_none_found'] = 'Der er i øjeblikket ingen vedhæftninger der afventer godkendelse';
$txt['mc_unapproved_attachments_desc'] = 'Herfra kan du godkende eller slette alle vedhæftninger der afventer moderation.';
$txt['mc_unapproved_replies_none_found'] = 'Der er i øjeblikket ingen indlæg der afventer godkendelse';
$txt['mc_unapproved_topics_none_found'] = 'Der er i øjeblikket ingen emner der afventer godkendelse';
$txt['mc_unapproved_posts_desc'] = 'Herfra kan du godkende eller slette ethvert indlæg der afventer moderation.';
$txt['mc_unapproved_replies'] = 'Svar';
$txt['mc_unapproved_topics'] = 'Emner';
$txt['mc_unapproved_by'] = 'af';
$txt['mc_unapproved_sure'] = 'Er du sikker på du ønsker at gøre dette?';
$txt['mc_unapproved_attach_name'] = 'Navn på vedhæftning';
$txt['mc_unapproved_attach_size'] = 'Filstørrelse';
$txt['mc_unapproved_attach_poster'] = 'Medlem';
$txt['mc_viewmodreport'] = 'Moderationsrapport for %1$s af %2$s';
$txt['mc_modreport_summary'] = 'Der har været %1$d rapporteringer angående dette indlæg. Den sidste rapport var %2$s.';
$txt['mc_view_pmreport'] = 'Moderations rapport for Personlige Beskeder sendt af %1$s';
$txt['mc_pmreport_summary'] = 'Der har været %1$d rapporteringer angående denne Personlige Besked. Den sidste rapport var %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Medlemmer som har rapporteret dette indlæg';
$txt['mc_modreport_whoreported_data'] = 'Rapporteret af %1$s den %2$s. De skrev den følgende besked:';
$txt['mc_modreport_modactions'] = 'Handlinger foretaget af andre moderatorer';
$txt['mc_modreport_mod_comments'] = 'Moderatorkommentarer';
$txt['mc_modreport_no_mod_comment'] = 'Der er i øjeblikket ingen moderatorkommentarer';
$txt['mc_modreport_add_mod_comment'] = 'Tilføj kommentar';

$txt['show_notice'] = 'Tekst på bemærkning';
$txt['show_notice_subject'] = 'Emne';
$txt['show_notice_text'] = 'Tekst';

$txt['mc_watched_users_title'] = 'Overvågede medlemmer';
$txt['mc_watched_users_desc'] = 'Her kan du holde et øje med alle medlemmer som er blevet sat på &quot;overvågning&quot; af moderationsteamet.';
$txt['mc_watched_users_post'] = 'Vis efter indlæg';
$txt['mc_watched_users_warning'] = 'Advarselsniveau';
$txt['mc_watched_users_last_login'] = 'Seneste login';
$txt['mc_watched_users_last_post'] = 'Seneste indlæg';
$txt['mc_watched_users_no_posts'] = 'Der er ingen indlæg fra overvågede brugere.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Er du sikker på du ønsker at slette dette indlæg?';
$txt['mc_watched_users_delete_posts'] = 'Er du sikker på du vil slette disse indlæg?';
$txt['mc_watched_users_posted'] = 'Afsendt';
$txt['mc_watched_users_member'] = 'Medlem';

$txt['mc_warnings_description'] = 'Fra denne sektion kan du se hvilke advarsler der er udstedt til medlemmer i forummet. Du kan også tilføje og redigere de advarsels-skabeloner der anvendes, når der udstedes en advarsel til et medlem.';
$txt['mc_warning_log'] = 'Advarselslog';
$txt['mc_warning_templates'] = 'Brugerdefineret skabelon';
$txt['mc_warning_log_title'] = 'Viser advarselslog';
$txt['mc_warning_templates_title'] = 'Brugerdefineret advarselsskabeloner';

$txt['mc_warnings_none'] = 'Ingen advarsler er udstedt.';
$txt['mc_warnings_recipient'] = 'Modtager';

$txt['mc_warning_templates_none'] = 'Ingen advarselsskabeloner er endnu blevet oprettet';
$txt['mc_warning_templates_time'] = 'Dato for oprettelse';
$txt['mc_warning_templates_name'] = 'Skabelon';
$txt['mc_warning_templates_creator'] = 'Oprettet af';
$txt['mc_warning_template_add'] = 'Tilføj skabelon';
$txt['mc_warning_template_modify'] = 'Rediger skabelon';
$txt['mc_warning_template_delete'] = 'Slet markerede';
$txt['mc_warning_template_delete_confirm'] = 'Er du sikker på du vil slette de valgte skabeloner?';

$txt['mc_warning_template_desc'] = 'Brug denne side for at udfylde skabelon detaljer. Bemærk at overskriften for email er ikke del af skabelonen. Bemærk også at eftersom beskeden er sendt som personlig besked, kan du bruge BBC kode i skabelonen. Hvis du bruger {MESSAGE} variablen, kan denne skabelon ikke bruges ved generelle advarsler (eks. Advarsler der ikke er linket til et indlæg).';
$txt['mc_warning_template_title'] = 'Titel på skabelon';
$txt['mc_warning_template_body_desc'] = 'Indholdet af besked. Du kan bruge de følgende genveje i denne skabelon.<ul><li>{MEMBER} - Bruger Navn.</li><li>{MESSAGE} - Link til det rapporterede indlæg. (Hvis relevant)</li><li>{FORUMNAME} - Forum Navn.</li><li>{SCRIPTURL} - Web adresse til forum.</li><li>{REGARDS} - Standard email signatur.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

Du har modtaget en advarsel for upassende opførsel. Disse aktiviteter bedes øjeblikkeligt ophørt. Følg venligst forum reglerne, ellers vil vi blive nødsaget til yderligere tiltag.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Personlig skabelon';
$txt['mc_warning_template_personal_desc'] = 'Hvis du vælger denne indstilling, vil kun du være i stand til at se, redigere og bruge denne skabelon. Hvis den ikke vælges vil alle moderatorer være i stand til at bruge denne skabelon.';
$txt['mc_warning_template_error_no_title'] = 'Du skal angive en tittel.';
$txt['mc_warning_template_error_no_body'] = 'Du skal angive en meddelelsestekst.';

$txt['mc_settings'] = 'Skift Indstillinger';
$txt['mc_prefs_title'] = 'Indstillinger for moderation';
$txt['mc_prefs_desc'] = 'Denne sektion tillader dig at indstille nogle personlige indstillinger til moderationsrelaterede aktiviteter såsom e-mail meddelelser.';
$txt['mc_prefs_homepage'] = 'Emner at vise på moderationshjemmesiden';
$txt['mc_prefs_latest_news'] = 'ElkArte Nyheder';
$txt['mc_prefs_show_reports'] = 'Vis antallet af åbne rapporter i sidehovedet i forummet';
$txt['mc_prefs_notify_report'] = 'Meddel om emnerapporter';
$txt['mc_prefs_notify_report_never'] = 'Aldrig';
$txt['mc_prefs_notify_report_moderator'] = 'Kun hvis det er et board jeg modererer';
$txt['mc_prefs_notify_report_always'] = 'Altid';
$txt['mc_prefs_notify_approval'] = 'Meddel om objekter der afventer godkendelse';
$txt['mc_logoff'] = 'Afslut Moderatorsession';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Tilføj et nyt notat';
$txt['mc_add_note'] = 'Tilføj';