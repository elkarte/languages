<?php
// Version: 1.1; LikePosts

global $txt;

// Like posts stats strings
$txt['like_posts_stats_desc'] = 'Statistik relateret til Liked indlæg og emner';
$txt['like_post_tab_mlm'] = 'Flest Liked indlæg';
$txt['like_post_tab_mlt'] = 'Flest Liked emner';
$txt['like_post_tab_mlb'] = 'Flest Liked boards';
$txt['like_post_tab_mlmember'] = 'Brugere med flest Likes';
$txt['like_post_tab_mlgmember'] = 'Brugere tildelt flest Likes';
$txt['like_post_generic_heading1'] = 'like(s)';
$txt['like_post_liked_by_others'] = 'Likes modtaget';
$txt['like_post_show'] = 'Vis';
$txt['like_post_hide'] = 'Skjul';

// For message
$txt['like_post_users_who_liked'] = '%1% users liked this post';

// For topic
$txt['like_post_most_popular_topic_heading1'] = 'has received a total of (%1%) like(s).';
$txt['like_post_most_popular_topic_sub_heading1'] = 'Emnet indeholder (%1%) Liked indlæg.  %2% nogle af de Liked indlæg fra det.';

// For board
$txt['like_post_most_popular_board_heading1'] = 'har modtaget';
$txt['like_post_most_popular_board_sub_heading1'] = 'Boardet indeholder';
$txt['like_post_most_popular_board_sub_heading2'] = 'topics, out of which';
$txt['like_post_most_popular_board_sub_heading3'] = 'emner er Liked.';
$txt['like_post_most_popular_board_sub_heading4'] = 'The topics contain';
$txt['like_post_most_popular_board_sub_heading5'] = 'different posts, of which';
$txt['like_post_most_popular_board_sub_heading6'] = 'posts are liked.';

// Most liked user
$txt['like_post_total_likes_received'] = 'Total antal Likes modtaget';
$txt['like_post_most_popular_user_heading1'] = '%1% this users most liked postings';

// Most like giving user
$txt['like_post_total_likes_given'] = 'Total antal Likes uddelt';
$txt['like_post_most_like_given_user_heading1'] = '%1% this users recently liked posts';

// Like posts generic strings
$txt['like_post_topic'] = 'Emne';
$txt['like_post_message'] = 'Besked';
$txt['like_post_board'] = 'Board';
$txt['like_post_total_posts'] = 'Total antal indlæg';
$txt['like_post_posted_at'] = 'Oprettet den';
$txt['like_post_read_more'] = 'Læs mere...';

// Error msgs
$txt['like_post_error_no_data'] = 'Beklager, det ser ud til at der ikke er noget at vise endnu!';
$txt['like_post_error_something_wrong'] = 'Beklager, det ser ud til at der er et problem med at hente data...';
