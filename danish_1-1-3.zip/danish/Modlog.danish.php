<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Dato';
$txt['modlog_member'] = 'Medlem';
$txt['modlog_position'] = 'Position';
$txt['modlog_action'] = 'Handling';
$txt['modlog_ip'] = 'IP';
$txt['modlog_search_result'] = 'Søgeresultat';
$txt['modlog_total_entries'] = 'Total antal';
$txt['modlog_ac_approve_topic'] = 'Godkendte emnet &quot;{topic}&quot; oprettet af &quot;{member}&quot;';
$txt['modlog_ac_unapprove_topic'] = 'Fjernede godkendelse af emne &quot;{topic}&quot; af &quot;{member}&quot;';
$txt['modlog_ac_approve'] = 'Godkendte indlægget &quot;{subject}&quot; i emnet &quot;{topic}&quot; oprettet af &quot;{member}&quot;';
$txt['modlog_ac_unapprove'] = 'Fjernede godkendelse af indlæg &quot;{subject}&quot; i &quot;{topic}&quot; af &quot;{member}&quot;';
$txt['modlog_ac_lock'] = 'Låste emnet &quot;{topic}&quot;';
$txt['modlog_ac_warning'] = 'Advarede medlemmet {member} på grundlag af &quot;{message}&quot;';
$txt['modlog_ac_unlock'] = 'Oplåste emnet &quot;{topic}&quot;';
$txt['modlog_ac_sticky'] = 'Fremhævede &quot;{topic}&quot;';
$txt['modlog_ac_unsticky'] = 'Fjernede fremhævning af &quot;{topic}&quot;';
$txt['modlog_ac_delete'] = 'Slettede &quot;{subject}&quot; af medlemmet &quot;{member}&quot; fra emnet &quot;{topic}&quot;';
$txt['modlog_ac_delete_member'] = 'Slettede medlemmet &quot;{name}&quot;';
$txt['modlog_ac_remove'] = 'Fjernede emnet &quot;{topic}&quot; fra &quot;{board}&quot;';
$txt['modlog_ac_modify'] = 'Redigerede &quot;{message}&quot; oprettet af &quot;{member}&quot;';
$txt['modlog_ac_merge'] = 'Flettede emner for at oprette emnet &quot;{topic}&quot;';
$txt['modlog_ac_split'] = 'Opdelte emnet &quot;{topic}&quot; for at oprette emnet &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = 'Flyttede emnet &quot;{topic}&quot; fra boardet &quot;{board_from}&quot; til boardet &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Redigerede profilen &quot;{member}&quot;';
$txt['modlog_ac_pruned'] = 'Fjernede nogle indlæg ældre end {days} dage gammel';
$txt['modlog_ac_news'] = 'Redigerede nyhederne';
$txt['modlog_enter_comment'] = 'Skriv kommentar på moderation';
$txt['modlog_moderation_log'] = 'Moderationslog';
$txt['modlog_moderation_log_desc'] = 'Herunder er en liste af alle de moderationshandlinger der er blevet udført af moderatorer i forummet.<br /><strong>Bemærk venligst:</strong> handlinger kan ikke fjernes før de er mindst 24 timer gamle.';
$txt['modlog_no_entries_found'] = 'Der er i øjeblikket ikke logget nogen moderationshandlinger.';
$txt['modlog_remove'] = 'Slet markerede';
$txt['modlog_removeall'] = 'Ryd Log';
$txt['modlog_remove_selected_confirm'] = 'Er du sikker på du vil slette de markerede log poster?';
$txt['modlog_remove_all_confirm'] = 'Er du sikker på du vil rydde hele log?';
$txt['modlog_go'] = 'Start';
$txt['modlog_add'] = 'Tilføj';
$txt['modlog_search'] = 'Hurtigsøgning';
$txt['modlog_by'] = 'Af';
$txt['modlog_id'] = '<em>(ID:%1$d)</em>';

$txt['modlog_ac_add_warn_template'] = 'Tilføjede advarselsskabelonen: &quot;{template}&quot;';
$txt['modlog_ac_modify_warn_template'] = 'Redigerede advarselsskabelonen: &quot;{template}&quot;';
$txt['modlog_ac_delete_warn_template'] = 'Slettede advarselsskabelonen: &quot;{template}&quot;';

$txt['modlog_ac_ban'] = 'Tilføjede bandlysningstriggere:';
$txt['modlog_ac_ban_update'] = 'Redigerede bandlysnings-triggesr:';
$txt['modlog_ac_ban_remove'] = 'Fjernede bandlysnings-triggers:';
$txt['modlog_ac_ban_trigger_member'] = '<em>Medlem:</em> {member}';
$txt['modlog_ac_ban_trigger_email'] = '<em>E-mail:</em> {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = '<em>IP:</em> {ip_range}';
$txt['modlog_ac_ban_trigger_hostname'] = '<em>Hostnavn:</em> {hostname}';

$txt['modlog_admin_log'] = 'Administrationslog';
$txt['modlog_admin_log_desc'] = 'Herunder er en liste af alle de administrationshandlinger der er blevet logget i forummet.<br /><strong>Bemærk venligst:</strong> handlinger kan ikke fjernes før de er mindst 24 timer gamle.';
$txt['modlog_admin_log_no_entries_found'] = 'Der er i øjeblikket ikke registreret nogle administrationshandlinger.';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Opgraderede forummet til version {version}';
$txt['modlog_ac_install'] = 'Installerede version {version}';
$txt['modlog_ac_add_board'] = 'Tilføjede et nyt board: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Redigerede boardet &quot;{board}&quot;';
$txt['modlog_ac_delete_board'] = 'Slettede boardet &quot;{boardname}&quot;';
$txt['modlog_ac_add_cat'] = 'Tilføjede en ny kategori, &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Redigerede kategorien &quot;{catname}&quot;';
$txt['modlog_ac_delete_cat'] = 'Slettede kategorien &quot;{catname}&quot;';

$txt['modlog_ac_delete_group'] = 'Slettede gruppen &quot;{group}&quot;';
$txt['modlog_ac_add_group'] = 'Tilføjede gruppen &quot;{group}&quot;';
$txt['modlog_ac_edited_group'] = 'Redigerede gruppen &quot;{group}&quot;';
$txt['modlog_ac_added_to_group'] = 'Tilføjede &quot;{member}&quot; til gruppen &quot;{group}&quot;';
$txt['modlog_ac_removed_from_group'] = 'Fjernede &quot;{member}&quot; fra gruppen &quot;{group}&quot;';
$txt['modlog_ac_removed_all_groups'] = 'Fjernede &quot;{member}&quot; fra alle grupper';

$txt['modlog_ac_remind_member'] = 'Udsendte en reminder til &quot;{member}&quot; om at aktivere deres konto';
$txt['modlog_ac_approve_member'] = 'Godkendte/aktiverede kontoen for &quot;{member}&quot;';
$txt['modlog_ac_newsletter'] = 'Udsendte nyhedsbrev';

$txt['modlog_ac_install_package'] = 'Installerede ny pakke: &quot;{package}&quot;, version {version}';
$txt['modlog_ac_upgrade_package'] = 'Opgraderede pakke: &quot;{package}&quot; til version {version}';
$txt['modlog_ac_uninstall_package'] = 'Afinstallerede pakken: &quot;{package}&quot;, version {version}';

$txt['modlog_ac_database_backup'] = 'Database backup taget af {member}.';
$txt['modlog_ac_editing_theme'] = '{member} redigerede et tema.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Gendannede emnet &quot;{topic}&quot; fra &quot;{board}&quot; til &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Gendannede indlæg fra &quot;{subject}&quot; til emnet &quot;{topic}&quot; i boardet &quot;{board}&quot;.';

$txt['modlog_parameter_guest'] = '<em>Gæst</em>';

$txt['modlog_ac_approve_attach'] = 'Godkendte &quot;{filename}&quot; i &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Fjernede ikke-godkendt &quot;{filename}&quot; i &quot;{message}&quot;';