<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Fra denne side kan du konfigurere dine mailindstillinger, såvel som administrere mailkøen hvis denne er aktiveret.';
$txt['mail_settings'] = 'Mail indstillinger';

$txt['mail_type'] = 'Mail type';
$txt['mail_type_default'] = '(PHP standard)';
$txt['smtp_host'] = 'SMTP server';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'SMTP port';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'SMTP brugernavn';
$txt['smtp_password'] = 'SMTP kodeord';

$txt['mail_queue'] = 'Aktiver mail kø';
$txt['mail_period_limit'] = 'Maksimalt antal e-mails at sende per minut';
$txt['mail_period_limit_desc'] = '(0 for at deaktivere)';
$txt['mail_batch_size'] = 'Maksimalt antal e-mails at sende per sideindlæsning';

$txt['mailqueue_stats'] = 'Mail kø statistik';
$txt['mailqueue_oldest'] = 'Ældste mail';
$txt['mailqueue_oldest_not_available'] = 'N/A';
$txt['mailqueue_size'] = 'Kø længde';

$txt['mailqueue_age'] = 'Brugerens alder';
$txt['mailqueue_priority'] = 'Prioritet';
$txt['mailqueue_recipient'] = 'Modtager';
$txt['mailqueue_subject'] = 'Emne';
$txt['mailqueue_clear_list'] = 'Send mail kø nu';
$txt['mailqueue_no_items'] = 'Mailkøen er i øjeblikket tom';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Er du sikker på du vil sende hele mailkøen nu? Dette vil overstyre alle andre begrænsninger du har sat.';

$txt['mq_day'] = '%1.1f Dag';
$txt['mq_days'] = '%1.1f Dage';
$txt['mq_hour'] = '%1.1f Time';
$txt['mq_hours'] = '%1.1f Timer';
$txt['mq_minute'] = '%1$d Minut';
$txt['mq_minutes'] = '%1$d Minutter';
$txt['mq_second'] = '%1$d Sekund';
$txt['mq_seconds'] = '%1$d Sekunder';

$txt['mq_mpriority_5'] = 'Meget lav';
$txt['mq_mpriority_4'] = 'Lav';
$txt['mq_mpriority_3'] = 'Normal';
$txt['mq_mpriority_2'] = 'Høj';
$txt['mq_mpriority_1'] = 'Meget høj';

$txt['birthday_email'] = 'Fødselsdagsbesked der skal benyttes';
$txt['birthday_body'] = 'Email indhold';
$txt['birthday_subject'] = 'Email emne';