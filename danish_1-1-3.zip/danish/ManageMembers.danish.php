<?php
// Version: 1.1; ManageMembers

$txt['groups'] = 'Grupper';
$txt['viewing_groups'] = 'Viser Medlemsgrupper';

$txt['membergroups_title'] = 'Administrer medlemsgrupper';
$txt['membergroups_description'] = 'Medlemsgrupper er grupper af medlemmer der har identiske tilladelser, fremtræden, eller adgang. Nogle medlemsgrupper er baseret på mængden af indlæg brugerne har oprettet. Du kan knytte brugere til en medlemsgruppe, ved at vælge deres profil og ændre deres Kontorelaterede indstillinger.';
$txt['membergroups_modify'] = 'Rediger';
$txt['membergroups_modify_parent'] = 'Rediger ovenliggende gruppe';

$txt['membergroups_add_group'] = 'Tilføj gruppe';
$txt['membergroups_regular'] = 'Almene grupper';
$txt['membergroups_post'] = 'Grupper baseret på antallet af indlæg';
$txt['membergroups_guests_na'] = 'n/a';

$txt['membergroups_group_name'] = 'Medlemsgruppens navn';
$txt['membergroups_new_board'] = 'Synlige Boards';
$txt['membergroups_new_board_desc'] = 'Boards som medlemsgruppen kan se.';
$txt['membergroups_new_board_post_groups'] = '<em>Bemærk: normalt behøver postgrupper ikke at have adgang, da den gruppe de er medlem af, automatisk giver dem adgang.</em>';
$txt['membergroups_new_as_inherit'] = 'nedarv fra';
$txt['membergroups_new_as_type'] = 'efter type';
$txt['membergroups_new_as_copy'] = 'baseret på';
$txt['membergroups_new_copy_none'] = '(ingen)';
$txt['membergroups_can_edit_later'] = 'Du kan rette disse senere.';

$txt['membergroups_edit_group'] = 'Rediger medlemsgruppe';
$txt['membergroups_edit_name'] = 'Gruppenavn';
$txt['membergroups_edit_inherit_permissions'] = 'Nedarv tilladelser';
$txt['membergroups_edit_inherit_permissions_desc'] = 'Vælg &quot;Nej&quot; for at lade gruppen have sine egne tilladelsesregler.';
$txt['membergroups_edit_inherit_permissions_no'] = 'Nej - Brug unikke tilladelser';
$txt['membergroups_edit_inherit_permissions_from'] = 'Nedarv fra';
$txt['membergroups_edit_hidden'] = 'Synlighed';
$txt['membergroups_edit_hidden_no'] = 'Synlig';
$txt['membergroups_edit_hidden_boardindex'] = 'Synlig - undtaget i gruppenøglen';
$txt['membergroups_edit_hidden_all'] = 'Usynlig';
// Do not use numeric entities in the below string.
$txt['membergroups_edit_hidden_warning'] = 'Er du sikker på du vil afvise at denne gruppe kan benyttes som en brugers primære gruppe?\\n\\nDette vil begrænse at brugere til at benytte de resterende grupper og vil opdatere alle aktuelle &quot;primære&quot; medlemmer til kun at benytte denne gruppe som supplerende gruppe.';
$txt['membergroups_edit_desc'] = 'Gruppebeskrivelse';
$txt['membergroups_edit_group_type'] = 'Gruppetype';
$txt['membergroups_edit_select_group_type'] = 'Vælg gruppetype';
$txt['membergroups_group_type_private'] = 'Privat <span class="smalltext">(Medlemskab skal tildeles)</span>';
$txt['membergroups_group_type_protected'] = 'Beskyttet <span class="smalltext">(Kun administratorer kan forvalte og tildele)</span>';
$txt['membergroups_group_type_request'] = 'Anmodning <span class="smalltext">(Brugere kan anmode medlemsskab)</span>';
$txt['membergroups_group_type_free'] = 'Fri <span class="smalltext">(Brugere kan forlade og tilslutte sig gruppen efter egen vilje)</span>';
$txt['membergroups_group_type_post'] = 'Indlægsbaseret <span class="smalltext">(Medlemmer baseres på antallet af indlæg)</span>';
$txt['membergroups_min_posts'] = 'Krævede antal indlæg';
$txt['membergroups_online_color'] = 'Farve i online listen';
$txt['membergroups_icon_count'] = 'Antal af ikonbilleder';
$txt['membergroups_icon_image'] = 'Filnavn på ikonbillede';
$txt['membergroups_icon_image_note'] = 'Upload ikonbilleder til standard temamappe for at aktivere det valgte.<br />Vælg ikonet for at ændre det.';
$txt['membergroups_max_messages'] = 'Maks. personlige beskeder';
$txt['membergroups_max_messages_note'] = '(0 = ubegrænset)';
$txt['membergroups_max_messages_desc'] = 'Her kan du angive en begrænsning på personlige beskeder en bruger kan have på serveren.<br />
Du kan angive denne til 0, for at tillade uendelig antal af personlige beskeder.';
$txt['membergroups_edit_save'] = 'Gem';
$txt['membergroups_delete'] = 'Slet';
$txt['membergroups_confirm_delete'] = 'Er du sikker på at du vil slette denne gruppe?';

$txt['membergroups_members_title'] = 'Viser gruppen';
$txt['membergroups_members_group_members'] = 'Gruppemedlemmer';
$txt['membergroups_members_no_members'] = 'Denne gruppe er i øjeblikket tom';
$txt['membergroups_members_add_title'] = 'Tilføj et medlem til denne gruppe';
$txt['membergroups_members_add_desc'] = 'Liste af medlemmer der tilføjes';
$txt['membergroups_members_add'] = 'Tilføj medlemmer';
$txt['membergroups_members_remove'] = 'Fjern fra gruppe';
$txt['membergroups_members_last_active'] = 'Senest Aktiv';
$txt['membergroups_members_additional_only'] = 'Tilføj kun som yderligere gruppe.';
$txt['membergroups_members_group_moderators'] = 'Gruppemoderatorer';
$txt['membergroups_members_description'] = 'Beskrivelse';
// Use javascript escaping in the below.
$txt['membergroups_members_deadmin_confirm'] = 'Er du sikker på du vil fjerne dig selv fra administrationsgruppen?';

$txt['membergroups_postgroups'] = 'Grupper for indlæg';
$txt['membergroups_settings'] = 'Indstillinger for medlemsgrupper';
$txt['groups_manage_membergroups'] = 'Grupper der kan ændre medlemsgrupper';
$txt['membergroups_select_permission_type'] = 'Vælg tilladelsesprofil';
$txt['membergroups_images_url'] = '{theme URL}/images/group_icons/';
$txt['membergroups_select_visible_boards'] = 'Vis boards';
$txt['membergroups_members_top'] = 'Medlemmer';
$txt['membergroups_name'] = 'Navn';
$txt['membergroups_icons'] = 'Ikoner';

$txt['admin_browse_approve'] = 'Medlemmer hvis konto afventer godkendelse';
$txt['admin_browse_approve_desc'] = 'Her kan du styre alle medlemmer som venter på at få deres konto godkendt.';
$txt['admin_browse_activate'] = 'Medlemmer hvis konto afventer aktivering';
$txt['admin_browse_activate_desc'] = 'Dette skærmbillede viser alle medlemmer der endnu ikke har aktiveres deres konto i dit forum.';
$txt['admin_browse_awaiting_approval'] = 'Afventer godkendelse [%1$d]';
$txt['admin_browse_awaiting_activate'] = 'Afventer aktivering [%1$d]';

$txt['admin_browse_username'] = 'Brugernavn';
$txt['admin_browse_email'] = 'E-mail-adresse';
$txt['admin_browse_ip'] = 'IP addresse';
$txt['admin_browse_registered'] = 'Registreret';
$txt['admin_browse_id'] = 'ID';
$txt['admin_browse_with_selected'] = 'Med valgte';
$txt['admin_browse_no_members_approval'] = 'Der er ingen medlemmer der i øjeblikket afventer godkendelse.';
$txt['admin_browse_no_members_activate'] = 'Ingen medlemmer har i øjeblikket ikke aktiveret deres konto.';

// Don't use entities in the below strings, except the main ones. (lt, gt, quot.)
$txt['admin_browse_warn'] = 'alle valgte medlemmer?';
$txt['admin_browse_outstanding_warn'] = 'alle berørte medlemmer?';
$txt['admin_browse_w_approve'] = 'Godkend';
$txt['admin_browse_w_activate'] = 'Aktiver';
$txt['admin_browse_w_delete'] = 'Slet';
$txt['admin_browse_w_reject'] = 'Afvis (Slet)';
$txt['admin_browse_w_remind'] = 'Påmindelse';
$txt['admin_browse_w_approve_deletion'] = 'Godkend (Slet konti)';
$txt['admin_browse_w_email'] = 'og send e-mail';
$txt['admin_browse_w_approve_require_activate'] = 'Godkend og kræv aktivering';

$txt['admin_browse_filter_by'] = 'Sorter efter';
$txt['admin_browse_filter_show'] = 'Viser';
$txt['admin_browse_filter_type_0'] = 'Ikke-aktiverede nye konti';
$txt['admin_browse_filter_type_2'] = 'Ikke-aktiverede email ændringer';
$txt['admin_browse_filter_type_3'] = 'Ikke-godkendte nye konti';
$txt['admin_browse_filter_type_4'] = 'Ikke-godkendte slettede konti';
$txt['admin_browse_filter_type_5'] = 'Ikke-godkendte "Under lavalder"- konti';

$txt['admin_browse_outstanding'] = 'Uafklarede medlemmer';
$txt['admin_browse_outstanding_days_1'] = 'Med medlemmer der registrede sig for mere end';
$txt['admin_browse_outstanding_days_2'] = 'dag(e) siden';
$txt['admin_browse_outstanding_perform'] = 'Udfør følgende handling';
$txt['admin_browse_outstanding_go'] = 'Udfør handling';

$txt['check_for_duplicate'] = 'Kontroller for duplikanter';
$txt['dont_check_for_duplicate'] = 'Kontroller ikke for duplikanter';
$txt['duplicates'] = 'Duplikanter';

$txt['not_activated'] = 'Ikke aktiveret';