<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Opret svar';
$txt['post_in_board'] = 'Skriv indlæg på board';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Indsæt citat';
$txt['disable_smileys'] = 'Deaktiver smileys';
$txt['dont_use_smileys'] = 'Brug ikke smileys.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Oprettet den';
$txt['standard'] = 'Standard';
$txt['thumbs_up'] = 'Tommel op';
$txt['thumbs_down'] = 'Tommel ned';
$txt['exclamation_point'] = 'Udråbstegn';
$txt['question_mark'] = 'Spørgsmålstegn';
$txt['icon_poll'] = 'Afstemning';
$txt['lamp'] = 'Lampe';
$txt['add_smileys'] = 'Tilføj smileys';
$txt['topic_notify_no'] = 'Der er ikke nogen emner med abonnement.';

$txt['rich_edit_wont_work'] = 'Din browser understøtter ikke Rich Text redigering.';
$txt['rich_edit_function_disabled'] = 'Din browser understøtter ikke denne funktion.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Afmeld abonnering fra dette emne ved at klikke her';

$txt['lock_after_post'] = 'Lås efter oprettelse';
$txt['notify_replies'] = 'Meddel mig om svar.';
$txt['lock_topic'] = 'Lås dette emne.';
$txt['shortcuts'] = 'genveje: shift+alt+s afsend eller shift+alt+p forhåndsvisning';
$txt['shortcuts_drafts'] = 'genveje: shift+alt+s afsend, shift+alt+p forhåndsvisning eller shift+alt+d gem kladde';
$txt['option'] = 'Valg';
$txt['reset_votes'] = 'Nulstil afstemningtæller';
$txt['reset_votes_check'] = 'Check denne hvis du vil sætte alle stemmer til 0.';
$txt['votes'] = 'stemmer';
$txt['attach'] = 'Vedhæft';
$txt['clean_attach'] = 'Fjern vedhæftning';
$txt['attached'] = 'Vedhæftet'; // @deprecated since 1.1
$txt['allowed_types'] = 'Tilladte filtyper';
$txt['cant_upload_type'] = 'Du kan ikke uploade filer af den type. De tilladte filnavnetyper er %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Fjern fluebenet ved de vedhæftinger du ikke længere vil have vedhæftet'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Det filnavn er et reserveret navn. Prøv venligst et andet.';
$txt['topic_locked_no_reply'] = 'Advarsel! Dette emne er/vil blive låst<br />Kun administratorer og moderatører kan svare.';
$txt['attachment_requires_approval'] = 'Bemærk at ingen vedhæftede filer vil blive vist før de er godkendt af en moderator.';
$txt['error_temp_attachments'] = 'Der blev fundet vedhæftninger, som du har vedhæftet før men ikke afsendt. Disse er nu vedhæftet til dette indlæg. Hvis du ikke ønsker at inkludere dem i dette indlæg, <a href="#postAttachment">kan du fjerne dem her</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Påmindelse: Dette indlæg vil ikke være synligt, før det bliver godkendt af en moderator.';

$txt['enter_comment'] = 'Afgiv kommentar';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Rapporteret indl&#230;g';
$txt['reported_to_mod_by'] = 'af';
$txt['rtm10'] = 'Afsend';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'F&#248;lgende indl&#230;g, "%s" fra';
$txt['reported_by'] = 'er rapporteret af';
$txt['board_moderate'] = 'i et board du modererer';
$txt['report_comment'] = 'Rapport&#248;ren har skrevet f&#248;lgende kommentar';

$txt['attach_drop_files'] = 'Tilføj filer ved at flytte dem her eller <a class="drop_area_fileselect_text" href="#">vælg dem</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Tilføj filer</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maksimal samlet størrelse %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maksimal individuel størrelse %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d per indlæg';
$txt['attach_restrictions'] = 'Restriktioner:';

$txt['post_additionalopt_attach'] = 'Vedhæftninger samt øvrige indstillinger';
$txt['post_additionalopt'] = 'Andre valg';
$txt['sticky_after'] = 'Fremhæv dette emne';
$txt['move_after2'] = 'Flyt dette emne.';
$txt['back_to_topic'] = 'Returner til dette emne.';
$txt['approve_this_post'] = 'Godkend dette indlæg';

$txt['retrieving_quote'] = 'Henter citat...';

$txt['post_visual_verification_label'] = 'Bekræftigelse';
$txt['post_visual_verification_desc'] = 'Skriv venligst koden i billedet herunder for at oprette dette indlæg.';

$txt['poll_options'] = 'Afstemningsmuligheder';
$txt['poll_run'] = 'Afvikl afstemning over';
$txt['poll_run_limit'] = '(Efterlad blank for ubegrænset.)';
$txt['poll_results_visibility'] = 'Resultatets synlighed';
$txt['poll_results_anyone'] = 'Vis afstemingsresultater til enhver.';
$txt['poll_results_voted'] = 'Vis kun resultater efter at nogen har stemt.';
$txt['poll_results_after'] = 'Vis kun resultaterne efter afstemningen er udløbet.';
$txt['poll_max_votes'] = 'Det maksimale antal stemmer per bruger';
$txt['poll_do_change_vote'] = 'Tillad brugere at ændre stemme';
$txt['poll_too_many_votes'] = 'Du har overskredet antallet af valgmuligheder. I denne afstemning kan du maks. bruge %1$s valgmuligheder.';
$txt['poll_add_option'] = 'Tilføj valgmulighed';
$txt['poll_guest_vote'] = 'Tillad gæster at stemme';

$txt['spellcheck_done'] = 'Stavetræning fulført.';
$txt['spellcheck_change_to'] = 'Ændrer til:';
$txt['spellcheck_suggest'] = 'Forslag:';
$txt['spellcheck_change'] = 'Skift';
$txt['spellcheck_change_all'] = 'Ændrer alle';
$txt['spellcheck_ignore'] = 'Ignorer';
$txt['spellcheck_ignore_all'] = 'Ignorer alle';

$txt['more_attachments'] = 'flere vedhæftinger';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Beklager, du kan ikke poste flere vedhæftninger.';

$txt['more_smileys'] = 'flere';
$txt['more_smileys_title'] = 'Øvrige smileys';
$txt['more_smileys_pick'] = 'Vælg en smiley';
$txt['more_smileys_close_window'] = 'Luk vindue';

$txt['error_new_reply'] = 'Mens du skrev, blev der indrykket et nyt svar. Du vil muligvis gennemse dit indlæg.';
$txt['error_new_replies'] = 'Mens du skrev, blev der indrykket %1$d nye svar. Du vil muligvis gennemse dit indlæg.';
$txt['error_new_reply_reading'] = 'Mens du læste, blev der indrykket et nyt svar. Du vil muligvis gennemse dit indlæg.';
$txt['error_new_replies_reading'] = 'Mens du læste, blev der indrykket %1$d nye svar. Du vil muligvis gennemse dit indlæg.';

$txt['announce_this_topic'] = 'Send en forum meddelelse om dette emne til medlemmerne:';
$txt['announce_title'] = 'Send en forum meddelelse';
$txt['announce_desc'] = 'Med denne form kan du sende en forum meddelelse til udvalgte medlemsgrupper om dette emne.';
$txt['announce_sending'] = 'Sender en forum meddelelse om emnet';
$txt['announce_done'] = 'udført';
$txt['announce_continue'] = 'Fortsæt';
$txt['announce_topic'] = 'Annoncer emne.';
$txt['announce_regular_members'] = 'Aktive medlemmer';

$txt['digest_subject_daily'] = 'Dagligt Sammendrag';
$txt['digest_subject_weekly'] = 'Ugentlig Sammendrag';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'Følgende emner blev startet';
$txt['digest_new_topics_line'] = '"%1$s" i boardet %2$s';
$txt['digest_new_replies'] = 'Nye svar er blevet oprettet i følgende emner';
$txt['digest_new_replies_one'] = '1 svar i "%1$s"';
$txt['digest_new_replies_many'] = '%1$d svar i "%2$s"';
$txt['digest_mod_actions'] = 'Følgende moderationshandlinger har fundet sted';
$txt['digest_mod_act_sticky'] = '"%1$s" var fremhævet';
$txt['digest_mod_act_lock'] = '"%1$s" var låst';
$txt['digest_mod_act_unlock'] = '"%1$s" var oplåst';
$txt['digest_mod_act_remove'] = '"%1$s" var fjernet';
$txt['digest_mod_act_move'] = '"%1$s" var flyttet';
$txt['digest_mod_act_merge'] = '"%1$s" blev flettet';
$txt['digest_mod_act_split'] = '"%1$s" blev delt';

$txt['attach_error_title'] = 'Fejl under upload af vedhæftninger.';
$txt['attach_warning'] = 'Der opstod et problem under upload af <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Beklager, du har overskredet vedhæftnings grænsen. Grænsen for vedhæftninger pr. indlæg er %1$s KB. Plads tilgængelig er %2$s KB.';
$txt['attach_folder_warning'] = 'Mappen til vedhæftninger kunne ikke findes. Informer venligst en administrator om dette problem.';
$txt['attach_folder_admin_warning'] = 'Stien til mappen for vedhæftninger (%1$s) er ikke korrekt. Ret dette i indstillinger for vedhæftninger området i dit administrationspanel.';
$txt['attach_limit_nag'] = 'Du har overskredet grænsen for maksimale antal af vedhæftninger tilladt pr. indlæg.';
$txt['attach_no_upload'] = 'Der opstod et problem og dine vedhæftninger kunne ikke uploades.';
$txt['attach_remaining'] = '%1$d tilbage';
$txt['attach_available'] = '%1$s KB tilgængelig';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'Filen ser ud til at være tom. Kontakt din forum administrator hvis dette problem fortsætter.';
$txt['attached_files_in_session'] = '<em>De ovenstående understregede fil(er) blev uploadet men vil ikke blive vedhæftet til dette indlæg før det er afsendt.</em>';

$txt['attach_php_error'] = 'På grund af en fejl kunne dine vedhæftninger ikke uploades. Kontakt vengligst en forum administrator hvis dette problem fortsætter.';
$txt['php_upload_error_1'] = 'Den uploadede fil overskrider grænsen for upload_max_filesize direktivet i php.ini. Kontakt din host hvis du ikke kan rette dette problem.';
$txt['php_upload_error_3'] = 'Den uploadede fil var kun delvist uploadet. Dette er en PHP relateret fejl. Kontakt venligst din host hvis dette problem fortsætter.';
$txt['php_upload_error_4'] = 'Ingen fil blev uploadet. Dette er en PHP relateret fejl. Kontakt venligst din host hvis dette problem fortsætter.';
$txt['php_upload_error_6'] = 'Ikke i stand til at gemme. Mangler en midlertidig mappe. Kontakt venligst din host hvis du ikke er i stand til at rette dette problem.';
$txt['php_upload_error_7'] = 'Ikke i stand til at skrive fil til disk. Dette er en PHP relateret fejl. Kontakt venligst din host hvis dette problem fortsætter.';
$txt['php_upload_error_8'] = 'En PHP udvidelse stoppede for upload af fil. Dette er en PHP relateret fejl. Kontakt venligst din host hvis dette problem fortsætter.';
$txt['error_temp_attachments_new'] = 'Der er vedhæftninger, som du har vedhæftet tidligere men ikke afsendt. Disse er stadig vedhæftet til dette indlæg. Dette indlæg skal afsendes før disse vedhæftninger er enten gemt eller fjernet. Det <a href="#postAttachment">kan du gøre her</a>';
$txt['error_temp_attachments_found'] = 'De følgende vedhæftninger blev fundet som du tidligere har vedhæftet til et andet indlæg men ikke afsendt. Det er anbefalet at du ikke afsender før disse enten er fjernet eller indlægget er afsendt.<br />Klik <a href="%1$s">her for at fjerne </a>disse vedhæftninger. Eller <a href="%2$s">her for at returnere til det indlæg</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'De følgende vedhæftninger blev fundet som du tidligere har vedhæftet til et andet indlæg men ikke afsendt. Det anbefales at du ikke uploader flere vedhæftninger før disse er fjernet eller at det indlæg er afsendt.<br />Klik <a href="%1$s">her for at fjerne disse vedhæftninger</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'De vedhæftninger er nu fjernet, og du er blevet returneret til den forrige side';
$txt['error_temp_attachments_flushed'] = 'Bemærk venligst at alle filer som tidligere blev vedhæftet, men ikke afsendt, er nu fjernet.';
$txt['error_topic_already_announced'] = 'Bemærk venligst at dette emne allerede er blevet annonceret.';

$txt['cant_access_upload_path'] = 'Kan ikke få adgang til upload stien for vedhæftninger!';
$txt['file_too_big'] = 'Din fil er for stor. Maksimale vedhæftningsstørrelse er %1$s KB.';
$txt['attach_timeout'] = 'Din vedhæftning kunne ikke gemmes. Dette kan skyldes at det tog for lang tid at uploade filen, eller også er filen større end serveren tillader.<br /><br />Kontakt venligst din server-administrator for mere information.';
$txt['bad_attachment'] = 'Din vedhæftning bestod ikke sikkerhedschecket og kan ikke uploades. Henvend dig venligst til forummets administrator.';
$txt['ran_out_of_space'] = 'Upload mappen er fuld. Kontakt venglist en administrator om dette problem.';
$txt['attachments_no_write'] = 'Mappen til upload af vedhæftninger er ikke skrivbar. Din vedhæfting eller avatar kan ikke gemmes.';
$txt['attachments_no_create'] = 'Kunne ikke oprette ny vedhæftningsmappe. Dine vedhæftninger eller avatar kan ikke gemmes.';
$txt['attachments_limit_per_post'] = 'Du kan ikke uploade mere end %1$d vedhæftninger pr. indlæg';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Indsæt Vedhæftning %1$d i beskeden';
$txt['ila_title'] = 'Enden-af-besked udvidende miniature';
$txt['insert'] = 'Indsæt';
$txt['ila_opt_size'] = 'Størrelse';
$txt['ila_opt_align'] = 'Justering';
$txt['ila_opt_size_thumb'] = 'Miniature';
$txt['ila_option2'] = 'Tekst link';
$txt['ila_option3'] = 'Kort tekst link';
$txt['ila_opt_size_full'] = 'Fuld størrelse';
$txt['ila_opt_size_cust'] = 'Defineret størrelse';
$txt['ila_opt_align_none'] = 'Ingen';
$txt['ila_opt_align_left'] = 'Venstre';
$txt['ila_opt_align_right'] = 'Højre';
$txt['ila_opt_align_center'] = 'Centreret';
$txt['ila_confirm_removal'] = 'Er du sikker på at du vil slette denne vedhæftning permanent?';
/*
$txt['ila_thereare'] = 'Der er kun';
$txt['ila_attachment'] = 'vedhæftning(er)';
$txt['ila_none'] = 'som udvidende miniature';
$txt['ila_img'] = 'som fuld størrelse grafik';
$txt['ila_url'] = 'som et link';
$txt['ila_mini'] = 'som et kompakt link';
*/