<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Fortsæt';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Vis filer i pakken';
$txt['files_archive'] = 'Filer i arkivet';
$txt['package_browse'] = 'Gennemse';
$txt['add_server'] = 'Tilføj server';
$txt['server_name'] = 'Servernavn';
$txt['serverurl'] = 'Webadresse';
$txt['no_packages'] = 'Ingen pakker endnu.';
$txt['download'] = 'Download';
$txt['download_success'] = 'Pakke downloadet';
$txt['package_downloaded_successfully'] = 'Pakken blev downloadet';
$txt['package_manager'] = 'Pakkemanager';
$txt['install_mod'] = 'Installer Add-on';
$txt['uninstall_mod'] = 'Afinstaller Add-on';
$txt['no_adds_installed'] = 'Ingen addons er i øjeblikket installeret';
$txt['uninstall'] = 'Afinstaller';
$txt['delete_list'] = 'Slet Add-on liste';
$txt['package_delete_list_warning'] = 'Er du sikker på du vil rydde listen over installerede addons?';

$txt['package_manager_desc'] = 'Fra dette brugervenlige interface, kan du downloade og installere addons til brug i dit forum.';
$txt['installed_packages_desc'] = 'Du kan benytte interfacet herunder til at se hvilke pakker der i øjeblikket er installeret i forummet og slette dem du ikke længere behøver.';
$txt['download_packages_desc'] = 'Fra denne sektion kan du tilføje og fjerne pakke servere, søge efter pakker, eller downloade nye pakker fra servere.';
$txt['package_servers_desc'] = 'Fra dette brugervenlige interface, kan du administrere dine pake servere og downloade addon arkiver på dit forum.';
$txt['upload_packages_desc'] = 'Fra denne sektion kan du uploade en pakke fil fra din lokale computer direkte til forum.';

$txt['upload_new_package'] = 'Upload ny pakke';
$txt['view_and_remove'] = 'Vis og fjern installerede pakker';
$txt['modification_package'] = 'Add-on pakker';
$txt['avatar_package'] = 'Avatar pakker';
$txt['language_package'] = 'Sprog pakker';
$txt['unknown_package'] = 'Andre pakker';
$txt['smiley_package'] = 'Smiley pakker';
$txt['use_avatars'] = 'Brug avatarer';
$txt['add_languages'] = 'Tilføj sprog';
$txt['list_files'] = 'Vis filer';
$txt['package_type'] = 'Pakketype';
$txt['extracting'] = 'Udpakker';
$txt['avatars_extracted'] = 'Avatars blev installeret, du burde nu kunne bruge dem.';
$txt['language_extracted'] = 'Sprogpakken blev installeret, du kan nu aktivere det i sprog indstillings området i dit administrationspanel.';

$txt['mod_name'] = 'Add-on Navn';
$txt['mod_version'] = 'Version';
$txt['mod_author'] = 'Ophavsmand';
$txt['author_website'] = 'Ophavsmandens hjemmeside';
$txt['package_no_description'] = 'Ingen beskrivelse';
$txt['package_description'] = 'Beskrivelse';
$txt['file_location'] = 'Download';
$txt['bug_location'] = 'Problem tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'Ingen kilde redigeringer';
$txt['mod_date'] = 'Senest opdateret';
$txt['mod_section_count'] = 'Gennemse de (%1d) addons i denne sektion';

// Package Server strings
$txt['package_current'] = '(%s <em>Du har den nyeste version %s</em>)';
$txt['package_update'] = '(%s <em>En opdatering for din %s version er tilgængelig</em>)';
$txt['package_installed'] = 'installeret';
$txt['package_downloaded'] = 'downloadet';

$txt['package_installed_key'] = 'Installerede addons:';
$txt['package_installed_current'] = 'nuværende version';
$txt['package_installed_old'] = 'ældre version';
$txt['package_installed_warning1'] = 'Denne pakke er allerede installeret, og ingen opdateringer blev fundet.';
$txt['package_installed_warning2'] = 'Du bør afinstallere den gamle version først for at undgå problemer, eller spørg  ophavsmanden om at lave en opgradering fra din ældre version.';
$txt['package_installed_warning3'] = 'Husk venligst altid regelmæssig at tage backup af dine filer og database før du installerer modifikationer, specielt hvis det er betaversioner.';
$txt['package_installed_extract'] = 'Udpakker pakke';
$txt['package_installed_done'] = 'Pakken blev successfuldt installeret. Du skulle nu kunne bruge den funktionalitet den tilføjer eller ændrer; eller ikke være i stand til at bruge den funktionalitet den fjerner.';
$txt['package_installed_redirecting'] = 'Omdirigerer...';
$txt['package_installed_redirect_go_now'] = 'Omdiriger nu';
$txt['package_installed_redirect_cancel'] = 'Vend tilbage til pakkemanageren';

$txt['package_upgrade'] = 'Opgrader';
$txt['package_uninstall_readme'] = 'Readme fil vedr. afinstallation';
$txt['package_install_readme'] = 'Readme fra installationen';
$txt['package_install_license'] = 'Licens';
$txt['package_install_type'] = 'Type';
$txt['package_install_action'] = 'Handling';
$txt['package_install_desc'] = 'Beskrivelse';
$txt['install_actions'] = 'Installationshandlinger';
$txt['perform_actions'] = 'Dette vil udføre følgende handlinger:';
$txt['corrupt_compatible'] = 'Pakken du forsøger at downloade eller installere er enten korrupt eller er ikke kompatibel med denne software version.';
$txt['package_create'] = 'Opret';
$txt['package_move'] = 'Flyt';
$txt['package_delete'] = 'Slet';
$txt['package_extract'] = 'Udpak';
$txt['package_file'] = 'Fil';
$txt['package_tree'] = 'Filstruktur';
$txt['execute_modification'] = 'Kør modifikation';
$txt['execute_code'] = 'Kør Kode';
$txt['execute_database_changes'] = 'Kør fil';
$txt['execute_hook_add'] = 'Tilføj Hook';
$txt['execute_hook_remove'] = 'Fjern Hook';
$txt['execute_hook_action'] = 'Tilpasser hook %1$s';
$txt['package_requires'] = 'Kræver modifikation';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Tilføj Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'Installationshandlinger for';
$txt['package_will_fail_title'] = 'Fejl i pakke %1$s';
$txt['package_will_fail_warning'] = 'Mindst en fejl opstod under en test %1$s af denne pakke.<br />Det er <strong>kraftigt</strong> anbefalet at du ikke fortsætter med %1$s med mindre du ved hvad du laver, og har lavet backup for nyligt.<br /><br />Denne fejl kan skyldes en konflikt mellem pakken du forsøger at installere og en anden pakke du allerede har installeret, en fejl i pakken, en pakke som kræver en anden pakke som du ikke har installeret endnu, eller en pakke som er designet til en anden software version.';
$txt['package_will_fail_unknown_action'] = 'Pakken prøver at udføre en ukendt handling: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Er du sikker på du ønsker at fortsætte installationen af denne addon, selvom den ikke vil installere korrekt?';
$txt['package_will_fail_popup_uninstall'] = 'Er du sikker på du ønsker at fortsætte med at afinstallere denne addon, selvom den ikke vil afinstallere korrekt?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'fjernelse';
$txt['package_install_now'] = 'installer nu';
$txt['package_uninstall_now'] = 'Afinstaller nu';
$txt['package_other_themes'] = 'Installer i andre temaer';
$txt['package_other_themes_uninstall'] = 'Afinstaller i andre temaer';
$txt['package_other_themes_desc'] = 'For at bruge denne addon i andre temaer end standard, skal pakkemanageren foretage ændringer i de andre temaer. Hvis du ønsker at installere denne addon i de andre temaer, vælg disse temaer herunder.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Mindst en fejl blev fundet under en testinstallation af dette tema. Er du sikker på du vil forsøge en installation?';

$txt['package_bytes'] = 'bytes';

$txt['package_action_missing'] = '<strong class="error">Filen blev ikke fundet</strong>';
$txt['package_action_error'] = '<strong class="error">Afviklingsfejl i modifikationen</strong>';
$txt['package_action_failure'] = '<strong class="error">Testen fejlede</strong>';
$txt['package_action_success'] = '<strong>Test successfuld</strong>';
$txt['package_action_skipping'] = '<strong>Springer filen over</strong>';

$txt['package_uninstall_actions'] = 'Afinstallationshandlinger';
$txt['package_uninstall_done'] = 'Pakken blev afinstalleret.';
$txt['package_uninstall_cannot'] = 'Denne pakke kan ikke afinstalleres, fordi der er ikke noget afinstallationsværktøj.<br /><br />Kontakt addon forfatter for mere information.';

$txt['package_install_options'] = 'Installationsindstillinger';
$txt['package_install_options_desc'] = 'Indstil forskellige muligheder for hvordan pakkemanager installerer addons, inklusiv backups og ftp adgang';
$txt['package_install_options_ftp_why'] = 'At benytte sig af pakkemanagerens FTP-funktion er den nemmeste måde at undgå manuelt at skulle gøre filerne skrivbare med chmod, for at få pakkemanageren til at fungere.<br />Her kan du fastsætte standardværdierne for nogle felter.';
$txt['package_install_options_ftp_server'] = 'FTP server';
$txt['package_install_options_ftp_port'] = 'Port';
$txt['package_install_options_ftp_user'] = 'Brugernavn';
$txt['package_install_options_make_backups'] = 'Opret backup-versioner af filer der redigeres, og tilføj en tilde (~) på fil-endelsen af disse.';
$txt['package_install_options_make_full_backups'] = 'Lav en komplet backup (eksklusiv smileys, avatars og vedhæftninger) af ElkArte installationen.';

$txt['package_ftp_necessary'] = 'FTP-information påkrævet';
$txt['package_ftp_why'] = 'Nogle af de filer pakkemanageren skal ændre er ikke skrivbare. Dette skal ændres ved at logge ind på FTP og bruge chmod kommandoen eller oprette filer og mapper. Dine FTP informationer vil midlertidigt blive cached for korrekt operation af pakkemanageren. Bemærk at du kan også gøre dette manuelt ved at bruge en FTP klient - <a href="#" onclick="%1$s">for at vise en liste over de berørte filer klik her</a>.';
$txt['package_ftp_why_file_list'] = 'De følgende filer skal gøres skrivbare for at fortsætte installationen:';
$txt['package_ftp_why_download'] = 'For at kunne downloade pakker, skal mappen for pakker, og filer deri, være skrivbare. Systemet har imidlertidigt ikke de krævede rettigheder for at skrive til denne mappe. Pakkemanageren kan bruge dine FTP informationer for at forsøge at rette dette problem.';
$txt['package_ftp_server'] = 'FTP server';
$txt['package_ftp_port'] = 'Port';
$txt['package_ftp_username'] = 'Brugernavn';
$txt['package_ftp_password'] = 'Kodeord';
$txt['package_ftp_path'] = 'Lokal sti til ElkArte';
$txt['package_ftp_test'] = 'Test';
$txt['package_ftp_test_connection'] = 'Test forbindelsen';
$txt['package_ftp_test_success'] = 'FTP forbindelse oprettet.';
$txt['package_ftp_test_failed'] = 'Kunne ikke kontakte serveren.';
$txt['package_ftp_bad_server'] = 'Kunne ikke kontakte serveren.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Pakken du er ved at slette er i øjeblikket installeret! Hvis du sletter den, vil du sikkert ikke være i stand til at afinstallere den senere.\\n\\nEr du sikker?';

$txt['package_examine_file'] = 'Se fil i pakken';
$txt['package_file_contents'] = 'Indhold af fil';

$txt['package_upload_title'] = 'Upload en pakke';
$txt['package_upload_select'] = 'Pakke der skal uploades';
$txt['package_upload'] = 'Upload';
$txt['package_uploaded_success'] = 'Pakke uploadet successfuldt';
$txt['package_uploaded_successfully'] = 'Pakken er blevet uploaded successfuldt';

$txt['package_modification_malformed'] = 'Misdannet eller ugyldig addonfil.';
$txt['package_modification_missing'] = 'Filen kunne ikke findes.';
$txt['package_no_zlib'] = 'Beklager, men din PHP konfiguration understøtter ikke <strong>zlib</strong>.  Uden denne kan Pakkemanageren ikke fungere. Venligst kontakt din host omkring dette for yderligere information.';

$txt['package_cleanperms_title'] = 'Ryd op i tilladelserne';
$txt['package_cleanperms_desc'] = 'Denne grænseflade tillader dig at nulstille tilladelserne til filer i din installation, for at øge sikkerheden eller for at løse adgangsproblemer du måtte støde på når du installerer pakker.';
$txt['package_cleanperms_type'] = 'Ændrer alle filrettigheder gennem hele forummet...';
$txt['package_cleanperms_standard'] = 'Kun standardfilerne er skrivebare.';
$txt['package_cleanperms_free'] = 'Alle filer er skrivebare.';
$txt['package_cleanperms_restrictive'] = 'Minimum filerne er skrivbare.';
$txt['package_cleanperms_go'] = 'Ændrer filrettigheder';

$txt['package_download_by_url'] = 'Download pakke via en webadresse';
$txt['package_download_filename'] = 'Navn på filen';
$txt['package_download_filename_info'] = 'Valgbar værdi. Bør anvendes hvis linket i webadressen ikke ender på filnavnet. For eksempel: index.php?mod=5';

$txt['package_db_uninstall'] = 'Fjern alle data associeret med denne addon.';
$txt['package_db_uninstall_details'] = 'Detaljer';
$txt['package_db_uninstall_actions'] = 'Markering af dette valg vil resultere i de følgende handlinger';
$txt['package_db_remove_table'] = 'Slet tabel &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Fjern kolonne &quot;%2$s&quot; fra &quot;%1$s&quot;';
$txt['package_db_remove_index'] = 'Fjern index &quot;%1$s&quot; fra &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Installations emulering';
$txt['package_emulate_uninstall'] = 'Afinstallations emulering';

// Operations.
$txt['operation_find'] = 'Søg';
$txt['operation_replace'] = 'Erstat';
$txt['operation_after'] = 'Tilføj efter';
$txt['operation_before'] = 'Tilføj før';
$txt['operation_title'] = 'Handlinger';
$txt['operation_ignore'] = 'Ignorer fejl';
$txt['operation_invalid'] = 'Handlingen du valgte er ugyldig.';

$txt['package_file_perms_desc'] = 'Du kan bruge denne sektion til at se læse/skrive-status på kritiske filer og mapper i dit forum. Bemærk at dette kun tager højde for vigtige filer og mapper for forummet - anvend en FTP-klient til yderligere valgmuligheder.';
$txt['package_file_perms_name'] = 'Fil/Mappe navn';
$txt['package_file_perms_status'] = 'Aktuel status';
$txt['package_file_perms_new_status'] = 'Ny status';
$txt['package_file_perms_status_read'] = 'Læs';
$txt['package_file_perms_status_write'] = 'Write';
$txt['package_file_perms_status_execute'] = 'Execute';
$txt['package_file_perms_status_custom'] = 'Brugerdefineret';
$txt['package_file_perms_status_no_change'] = 'Ingen ændringer';
$txt['package_file_perms_writable'] = 'Skrivbar';
$txt['package_file_perms_not_writable'] = 'Ikke-skrivbar';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Flere filer';

$txt['package_file_perms_change'] = 'Ændrer Filtilladelser';
$txt['package_file_perms_predefined'] = 'Anvend prædefineret tilladelsesprofil';
$txt['package_file_perms_predefined_note'] = 'Bemærk at den prædefinerede profil kun påvirker væsentlige mapper og filer.';
$txt['package_file_perms_apply'] = 'Aktiver de individuelle tilladelser for filer der er valgt ovenfor.';
$txt['package_file_perms_custom'] = 'Hvis &quot;Brugerdefineret&quot; er valgt, brug da chmod værdien';
$txt['package_file_perms_pre_restricted'] = 'Begrænset - kun minimum filer er skrivbare';
$txt['package_file_perms_pre_standard'] = 'Standard - nøglefiler er skrivbare';
$txt['package_file_perms_pre_free'] = 'Frit - alle filer er skrivbare';
$txt['package_file_perms_ftp_details'] = 'På de fleste servere er det kun muligt at ændre filtilladelser ved at benytte en FTP konto. Angiv venligst dine FTP detaljer herunder';
$txt['package_file_perms_ftp_retain'] = 'Bemærk, systemet vil kun gemme informationer om kodeord midlertidigt for at hjælpe med udføring af operationer af pakkemanageren.';
$txt['package_file_perms_go'] = 'Udfør ændringer';

$txt['package_file_perms_applying'] = 'Aktiver ændringer';
$txt['package_file_perms_items_done'] = '%1$d af %2$d emner færdiggjort';
$txt['package_file_perms_skipping_ftp'] = '<strong>Advarsel:</strong> Der kunne ikke oprettes forbindelse til FTP-serveren, forsøger at ændre tilladelserne uden. Dette vil <em>sandsynligt</em> fejle - kontroller venligst resultaterne efter gennemførelsen og forsøg igen med de korrekte FTP detaljer hvis det er nødvendigt.';

$txt['package_file_perms_dirs_done'] = '%1$d af %2$d mapper gennemført';
$txt['package_file_perms_files_done'] = '%1$d af %2$d filer færdige i den aktuelle mappe';

$txt['chmod_value_invalid'] = 'Du har forsøgt at angive en ugyldig chmod værdi. Chmod skal være mellem 0444 og 0777';

$txt['package_restore_permissions'] = 'Gendan filtilladelser';
$txt['package_restore_permissions_desc'] = 'Følgende filtilladelser blev ændret for at installere de valgte pakker. Du kan returnere disse filer tilbage til deres originale status ved at klikke &quot;Gendan&quot; herunder.';
$txt['package_restore_permissions_restore'] = 'Gendan';
$txt['package_restore_permissions_filename'] = 'Filnavn';
$txt['package_restore_permissions_orig_status'] = 'Original status';
$txt['package_restore_permissions_cur_status'] = 'Aktuel status';
$txt['package_restore_permissions_result'] = 'Resultat';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - var %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Droppet</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Succes</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Fejlede</span>';
$txt['package_restore_permissions_action_done'] = 'Et forsøg på at gendanne de valgte filer tilbage til deres originale tilladelser er fuldført, resultaterne kan ses herunder. Hvis en ændring fejlede, eller for et mere detaljeret overblik over filtilladelser, se <a href="%1$s">Filetilladelser</a> sektionen.';

$txt['package_file_perms_warning'] = 'Bemærk venligst';
$txt['package_file_perms_warning_desc'] = '
	Vær forsigtig når du ændrer tilladelser fra denne sektion - inkorrekte tilladelser kan negativt berøre brugbarheden af dit forum!<br />
	På nogle server konfigurationer kan de forkerte tilladelser forhindre forum i at virke.<br />
	Visse mapper såsom <em>vedhæftninger</em> skal være skrivbare for at bruge den funktionalitet.<br />
	Denne funktionalitet er primært gældende for ikke-windows baserede servere - Det vil ikke virke efter hensigten under Windows med hensyn til tilladelsesflag.<br />
	Før du fortsætter skal du sikre dig at du har en FTP klient installeret i tilfælde af at du laver en fejl og skal bruge FTP adgang til serveren for at rette fejlen.';

$txt['package_confirm_view_package_content'] = 'Er du sikker på du ønsker at se pakkens indhold fra denne lokation:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Fortsæt';
$txt['package_confirm_go_back'] = 'Gå tilbage';

$txt['package_readme_default'] = 'Standard';
$txt['package_available_readme_language'] = 'Tilgængelige Readme sprog:';
$txt['package_license_default'] = 'Standard';
$txt['package_available_license_language'] = 'Tilgængelige Licenssprog:';