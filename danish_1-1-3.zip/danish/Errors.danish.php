<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Beklager, vi kan ikke lade dig få adgang til denne sektion. Vi kan ikke engang fortælle dig at den eksisterer. Du er velkommen til at gå til hovedsiden og vælg din vej derfra.';
$txt['not_guests'] = 'Beklager, denne handling er ikke tilgængelig for gæster.';

$txt['mods_only'] = 'Kun moderatorer kan bruge den direkte fjern funktion, fjern beskeden igennem modificer funktionen.';
$txt['no_name'] = 'Du udfylgte ikke navnefeltet. Du kan ikke fortsætte uden et navn, beklager.';
$txt['no_email'] = 'Du udfyldte ikke email feltet. Du kan ikke fortsætte uden en email, beklager.';
$txt['topic_locked'] = 'Dette emne er låst, du kan ikke oprette eller redigere indlæg...';
$txt['no_password'] = 'Feltet til kodeord er tomt';
$txt['passwords_dont_match'] = 'Kodeordene er ikke ens.';
$txt['register_to_use'] = 'Beklager, men du skal registrere dig før du kan benytte denne funktion.';
$txt['username_reserved'] = 'Brugernavnet du forsøgte at anvende, indeholder det reserverede navn \'%1$s\'. Prøv venligst et andet navn.';
$txt['numbers_one_to_nine'] = 'Dette felt accepterer kun tallene fra 0-9';
$txt['not_a_user'] = 'Brugeren hvis profil du forsøger at se, eksisterer ikke.';
$txt['not_a_topic'] = 'Emnet eksisterer ikke i dette board.';
$txt['not_approved_topic'] = 'Dette emne er endnu ikke blevet godkendt.';
$txt['email_in_use'] = 'Mailadressen (%1$s) anvendes allerede af et registreret medlem. Hvis du mener dette er en fejl, skal du gå til log ind siden og bruge kodeordshuskeren med den adresse.';

$txt['didnt_select_vote'] = 'Du markerede ikke et valg i afstemningen.';
$txt['poll_error'] = 'Der er noget galt. Enten eksisterer afstemningen ikke, den er blevet låst, eller du forsøgte at stemme to gange.';
$txt['locked_by_admin'] = 'Denne er blevet låst af en administrator. Du kan ikke låse den op.';
$txt['not_enough_posts_karma'] = 'Beklager, men du har ikke tilstrækkelig mange indlæg til at give karma - du skal mindst have %1$d.';
$txt['cant_change_own_karma'] = 'Beklager, men du har ikke tilladelse til at redigere din egen karma.';
$txt['karma_wait_time'] = 'Beklager, men du kan ikke gentage et karmavalg uden at vente %1$s %2$s.';
$txt['feature_disabled'] = 'Beklager, men denne funktion er deaktiveret.';
$txt['feature_no_exists'] = 'Beklager, denne funktion eksisterer ikke.';
$txt['couldnt_connect'] = 'Kunne ikke forbinde til serveren eller kunne ikke finde filen';
$txt['no_board'] = 'Boardet du angav eksisterer ikke';
$txt['no_message'] = 'Beskeden er ikke længere tilgængelig';
$txt['no_topic_id'] = 'Du angav et ugyldigt emne-ID.';
$txt['split_first_post'] = 'Du kan ikke dele et emne ved det første indlæg.';
$txt['topic_one_post'] = 'Dette emne indeholder kun et indlæg og kan ikke deles.';
$txt['no_posts_selected'] = 'ingen indlæg valgt';
$txt['selected_all_posts'] = 'Det er ikke muligt at dele emnet, da du har valgt alle indlæg.';
$txt['cant_find_messages'] = 'Ikke i stand til at finde indlæg';
$txt['cant_find_user_email'] = 'Det var ikke muligt at finde brugerens e-mailadresse.';
$txt['cant_insert_topic'] = 'Emnet kunne ikke indsættes';
$txt['session_timeout'] = 'Din session udløb mens du postede. Gå tilbage og prøv igen.';
$txt['session_timeout_file_upload'] = 'Din session udløb mens du uploadede filen. Prøv igen.';
$txt['no_files_uploaded'] = 'Der er ingen filer at uploade.';
$txt['session_verify_fail'] = 'Bekræftigelse af sessionen mislykkedes. Prøv at logge ud og ind igen, og forsøg så igen.';
$txt['verify_url_fail'] = 'Ikke muligt at verificere refererende URL: %1$s. Gå tilbage og prøv igen.';
$txt['token_verify_fail'] = 'Bekræftigelse af token mislykkedes. Gå tilbage og prøv igen.';
$txt['guest_vote_disabled'] = 'Gæster kan ikke stemme i denne afstemning.';

$txt['cannot_access_mod_center'] = 'Du har ikke adgangstilladelse til moderationscentret.';
$txt['cannot_admin_forum'] = 'Du har ikke tilladelse til at administrere dette forum.';
$txt['cannot_announce_topic'] = 'Du har ikke tilladelse til at annoncere emner i dette board.';
$txt['cannot_approve_posts'] = 'Du har ikke tilladelse til at godkende objekter.';
$txt['cannot_post_unapproved_attachments'] = 'Du har ikke tilladelse til at poste ikke-godkendte vedhæftninger.';
$txt['cannot_post_unapproved_topics'] = 'Du har ikke tilladelse til at poste ikke-godkendte emner.';
$txt['cannot_post_unapproved_replies_own'] = 'Du har ikke tilladelse til at poste ikke-godkendte svar på dine emner.';
$txt['cannot_post_unapproved_replies_any'] = 'Du har ikke tilladelse til at poste ikke-godkendte svar på andre brugeres emner.';
$txt['cannot_calendar_edit_any'] = 'Du kan ikke ændre begivenheder i kalenderen.';
$txt['cannot_calendar_edit_own'] = 'Du har ikke de nødvendige tilladelser til at ændre dine egne begivenheder.';
$txt['cannot_calendar_post'] = 'Postning af begivenheder er ikke tilladt - beklager.';
$txt['cannot_calendar_view'] = 'Beklager, men du har ikke tilladelse til at se kalenderen.';
$txt['cannot_remove_any'] = 'Beklager, men du har ikke privilegier til at fjerne ethvert emne. Kontroller venligst at dette emne ikke blot er blevet flyttet til et andet board.';
$txt['cannot_remove_own'] = 'Du kan ikke slette dine egne emner i dette board. Kontroller at dette emne ikke er flyttet til et andet board';
$txt['cannot_edit_news'] = 'Du har ikke tilladelse til at ændre nyhedsemner i dette forum.';
$txt['cannot_pm_read'] = 'Beklager, du kan ikke læse dine personlige beskeder.';
$txt['cannot_pm_send'] = 'Du har ikke tilladelse til at sende personlige beskeder.';
$txt['cannot_karma_edit'] = 'Du har ikke tilladelse til at ændre andre folks karma.';
$txt['cannot_like_posts'] = 'Du har ikke adgang til at like indlæg i dette board.';
$txt['cannot_lock_any'] = 'Du har ikke tilladelse til at låse alle emner her.';
$txt['cannot_lock_own'] = 'Beklager, men du kan ikke låse dine egne emner her.';
$txt['cannot_make_sticky'] = 'Du har ikke adgang til at fremhæve dette emne.';
$txt['cannot_manage_attachments'] = 'Du har ikke tilladelse til at administrere vedhæftinger eller avatarer.';
$txt['cannot_manage_bans'] = 'Du har ikke tilladelse til at ændre listen af bandlysninger.';
$txt['cannot_manage_boards'] = 'Du har ikke tilladelse til at administrere boards og kategorier.';
$txt['cannot_manage_membergroups'] = 'Du har ikke adgang til at ændre eller tildele brugergrupper.';
$txt['cannot_manage_permissions'] = 'Du har ikke tilladelse til at administrere tilladelser.';
$txt['cannot_manage_smileys'] = 'Du har ikke tilladelse til at administrere smileys og indlægsikoner.';
$txt['cannot_mark_any_notify'] = 'Du har ikke de nødvendige tilladelser til at få meddelelser fra dette emne.';
$txt['cannot_mark_notify'] = 'Beklager, men du har desværre ikke tilladelser til at få meddelelser fra dette board.';
$txt['cannot_merge_any'] = 'Du har ikke tilladelse til at flette emner i et af de valgte boards.';
$txt['cannot_moderate_forum'] = 'Du har ikke tilladelse til at moderere dette forum.';
$txt['cannot_moderate_board'] = 'Du har ikke tilladelse til at moderere dette board.';
$txt['cannot_modify_any'] = 'Du har ikke tilladelse til at redigere ethvert indlæg.';
$txt['cannot_modify_own'] = 'Beklager, men du har ikke tilladelse til at redigere dine egne indlæg.';
$txt['cannot_modify_replies'] = 'Selvom dette indlæg er et svar på dit eget emne, kan du ikke ændre i det.';
$txt['cannot_move_own'] = 'Du har ikke tilladelse til at flytte dine egne emner i dette board.';
$txt['cannot_move_any'] = 'Du har ikke tilladelse til at flytte emner i dette board.';
$txt['cannot_poll_add_own'] = 'Beklager, men du har ikke tilladelse til at tilføje afstemninger til dine egne emner i dette board.';
$txt['cannot_poll_add_any'] = 'Du har ikke adgang til at tilføje afsteminger til dette emne.';
$txt['cannot_poll_edit_own'] = 'Du kan ikke ændre i denne afstemning, selvom det er din egen.';
$txt['cannot_poll_edit_any'] = 'Du er blevet nægtet adgang til at redigere afstemninger i dette board.';
$txt['cannot_poll_lock_own'] = 'Du har ikke tilladelse til at låse dine egne afstemninger i dette board.';
$txt['cannot_poll_lock_any'] = 'Beklager, men du har ikke tilladelse til at låse enhver afstemning.';
$txt['cannot_poll_post'] = 'Du har ikke tilladelse til at oprette afstemninger i dette board.';
$txt['cannot_poll_remove_own'] = 'Du har ikke tilladelse til at fjerne denne afstemning fra dit emne.';
$txt['cannot_poll_remove_any'] = 'Du kan ikke fjerne enhver afstemning i dette board.';
$txt['cannot_poll_view'] = 'Du har ikke tilladelse til at se afstemninger i dette board.';
$txt['cannot_poll_vote'] = 'Beklager, men du kan ikke afgive stemmer i dette board.';
$txt['cannot_post_attachment'] = 'Du har ikke tilladelse til at poste vedhæftninger her.';
$txt['cannot_post_new'] = 'Beklager, du kan ikke oprette nye emner i dette board.';
$txt['cannot_post_new_board'] = 'Beklager, du kan ikke oprette nye emner i boardet %1$s.';
$txt['cannot_post_reply_any'] = 'Du har ikke tilladelse til at oprette svar på emner i dette board.';
$txt['cannot_post_reply_own'] = 'Du har ikke tilladelse til at oprette svar, selv til dine egne emner i dette board.';
$txt['cannot_profile_remove_own'] = 'Beklager, men du har ikke tilladelser til at slette din egen konto.';
$txt['cannot_profile_remove_any'] = 'Du har ikke de rigtige rettigheder til at slette konti.';
$txt['cannot_profile_extra_any'] = 'Du har ikke tilladelse til at ændre profilindstillinger.';
$txt['cannot_profile_identity_any'] = 'Du har ikke tilladelse til at ændre kontoindstillinger.';
$txt['cannot_profile_title_any'] = 'Du kan ikke ændre folks brugerdefinerede titler.';
$txt['cannot_profile_extra_own'] = 'Beklager, men du har ikke de nødvendige tilladelser til at ændre dine profildata.';
$txt['cannot_profile_identity_own'] = 'Du kan i øjeblikket ikke ændre din identitet.';
$txt['cannot_profile_title_own'] = 'Du har ikke tilladelse til at ændre din brugerdefinerede titel.';
$txt['cannot_profile_set_avatar'] = 'Du har ikke adgang til at ændre din avatar.';
$txt['cannot_profile_view_own'] = 'Vi beklager meget, men du kan ikke se din egen profil.';
$txt['cannot_profile_view_any'] = 'Vi beklager meget, men du kan ikke læse enhver profil.';
$txt['cannot_delete_own'] = 'Beklager, du kan ikke slette dine indlæg i dette board.';
$txt['cannot_delete_replies'] = 'Beklager, men du kan ikke slette disse indlæg, selvom de er svar på dine emner.';
$txt['cannot_delete_any'] = 'Beklager, du kan ikke slette indlæg i dette board.';
$txt['cannot_report_any'] = 'Du har ikke tilladelse til at anmelde indlæg i dette board.';
$txt['cannot_search_posts'] = 'Du har ikke tilladelse til at søge efter indlæg i dette forum.';
$txt['cannot_send_mail'] = 'Du har ikke privilegier til at sende e-mails til alle.';
$txt['cannot_issue_warning'] = 'Beklager, men du har ikke tilladelse til at udstede advarsler til medlemmer.';
$txt['cannot_send_topic'] = 'Beklager, men administratoren har deaktiveret tilladelsen til at sende emner i dette board.';
$txt['cannot_send_email_to_members'] = 'Beklager, men administratoren har deaktiveret muligheden for at sende emails på dette board.';
$txt['cannot_split_any'] = 'Splitning af ethvert emne i dette board er ikke tilladt.';
$txt['cannot_view_attachments'] = 'Det ser ud til at du ikke har tilladelse til at downloade eller se vedhæftinger i dette board.';
$txt['cannot_view_mlist'] = 'Du har ikke adgang til at vise brugerlisten.';
$txt['cannot_view_stats'] = 'Du har ikke tilladelse til at se forum-statistikken.';
$txt['cannot_who_view'] = 'Beklager, men du har ikke de rigtige tilladelser til at se Hvem er online- listen.';
$txt['cannot_like_posts_stats'] = 'Beklager - du har ikke de nødvendige rettigheder til at vise Like indlæg statistik.';

$txt['no_theme'] = 'Vi kan ikke finde det tema.';
$txt['theme_dir_wrong'] = 'Standardtemaets mappe er forkert, ret det venligst til ved at klikke på denne tekst.';
$txt['registration_disabled'] = 'Beklager, men registrering er i øjeblikket deaktiveret.';
$txt['registration_agreement_missing'] = 'Registrering aftale filen, agreement.txt, er enten tom eller mangler. Registreringer er deaktiveret indtil dette er løst.';
$txt['registration_privacy_policy_missing'] = 'Privatlivsaftale fil, privacypolicy.txt, er enten tom eller mangler. Registrering er deaktiveret indtil dette er løst';
$txt['registration_no_secret_question'] = 'Beklager, men der er ikke noget hemmeligt spørgsmål sat for dette medlem.';
$txt['poll_range_error'] = 'Beklager, men afstemningen skal afvikles over mere end 0 dage.';
$txt['delFirstPost'] = 'Du har ikke adgang til at slette det første indlæg i et emne. <p>Hvis du ønsker at slette dette emne, klik på Fjern Emne link, eller spørg en moderator/administrator om at gøre det for dig.</p>';
$txt['login_cookie_error'] = 'Du var ikke i stand til at logge på. Check venligst dine cookie indstillinger.';
$txt['incorrect_answer'] = 'Beklager, men du svarede ikke dit spørgsmål korrekt. Gå venligst tilbage og prøv igen, eller klik to gange tilbage for at benytte standardmetoden til at få tilsendt dit kodeord.';
$txt['no_mods'] = 'Ingen moderatorer blev fundet!';
$txt['parent_not_found'] = 'Board strukturen er korrupt: Kan ikke finde det ovenliggende board';
$txt['modify_post_time_passed'] = 'Du kan ikke redigere dette indlæg, før minimumstiden for redigering er udløbet.';

$txt['calendar_off'] = 'Du kan ikke tilgå kalenderen lige nu, da den er deaktiveret.';
$txt['calendar_export_off'] = 'Du kan ikke eksportere kaldender begivenheder fordi funktionen er deaktiveret.';
$txt['invalid_month'] = 'Ugyldig værdi for måneden.';
$txt['invalid_year'] = 'Ugyldig værdi for året.';
$txt['invalid_day'] = 'Ugyldig datovædi.';
$txt['event_month_missing'] = 'Måneden for begivenheden mangler.';
$txt['event_year_missing'] = 'Året for begivenheden mangler.';
$txt['event_day_missing'] = 'Dagen for begivenheden mangler.';
$txt['event_title_missing'] = 'Overskrift for begivenheden mangler.';
$txt['invalid_date'] = 'Ugyldig dato.';
$txt['no_event_title'] = 'Der blev ikke angivet nogen titel på begivenheden.';
$txt['missing_board_id'] = 'Board-ID\'et mangler.';
$txt['missing_topic_id'] = 'Emne-ID\'et mangler.';
$txt['topic_doesnt_exist'] = 'Emnet eksisterer ikke.';
$txt['not_your_topic'] = 'Du er ikke ejeren af dette emne.';
$txt['board_doesnt_exist'] = 'Boardet eksisterer ikke.';
$txt['no_span'] = 'Funktionen til at spænde over flere dage er i øjeblikket deaktiveret.';
$txt['invalid_days_numb'] = 'Ugyldigt antal dage at spænde over.';

$txt['moveto_noboards'] = 'Der er ikke nogle boards at flytte dette emne til!';
$txt['topic_already_moved'] = 'Emnet %1$s er blevet flyttet til boardet %2$s, kontroller den nye lokation før det forsøges flyttes igen.';

$txt['already_activated'] = 'Vi ville meget gerne behandle din anmodning, men kontoen er allerede aktiveret.';
$txt['still_awaiting_approval'] = 'Din konto afventer stadig godkendelse fra en administrator.';

$txt['invalid_email'] = 'Ugyldig e-mail-adresse / e-mail alias.<br />Eksempel på en korrekt e-mail-adresse: evil.user@badsite.com.<br />Eksempel på et korrekt e-mail alias: *@*.badsite.com';
$txt['invalid_expiration_date'] = 'Udløbsdatoen er ikke gyldig';
$txt['invalid_hostname'] = 'Ugyldig hostnavn / hostnavn alias.<br />Eksempel på et gyldigt hostnavn: proxy4.badhost.com<br />Eksempel på et gyldigt hostnavn alias: *.badhost.com';
$txt['invalid_ip'] = 'Ugyldig IP adresse / IP område.<br />Eksempel på en gyldig IP adresse: 127.0.0.1<br />Eksempel på et gyldigt IP område: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Ugyldig IP / IP område.<br />Eksempel på en gyldig IP adresse: 127.0.0.1<br />Eksempel på et gyldigt IP område: 127.0.0.*';
$txt['invalid_username'] = 'Navnet på medlemmet blev ikke fundet!';
$txt['no_user_selected'] = 'Bruger ikke fundet';
$txt['no_ban_admin'] = 'Hey! Vi kan ikke lade dig banne en adminstrator. Hvis du er sikker på du vil det, degrader dem først!';
$txt['no_bantype_selected'] = 'Der blev ikke valgt nogen type af bandlysning';
$txt['ban_not_found'] = 'Bandlysning ikke fundet';
$txt['ban_unknown_restriction_type'] = 'Restriktionstypen er ukendt';
$txt['ban_name_empty'] = 'Navnet på bandlysningen blev ikke udfyldt';
$txt['ban_id_empty'] = 'Vi prøvede at finde dette ban ID, men det ser ikke ud til at eksistere.';
$txt['ban_group_id_empty'] = 'En ban gruppe skal bruge et gruppe ID, og denne gruppe havde ingen.';
$txt['ban_no_triggers'] = 'Har du glemt at vælge ban triggers? Vi skal bruge mindst en, og vi har ikke nogen.';
$txt['ban_ban_item_empty'] = 'Ban trigger ikke fundet';
$txt['impossible_insert_new_bangroup'] = 'En fejl opstod under indsætning af nyt ban';

$txt['like_heading_error'] = 'Fejl i likes';
$txt['like_wait_time'] = 'Beklager, du kan ikke gentage like uden først at vente %1$s %2$s.';
$txt['like_unlike_error'] = 'Oops, der opstod en fejl under like/fjern like.';
$txt['cant_like_yourself'] = 'Like dine egne indlæg... Det er lidt ligesom at grine af dine egne vittigheder når der ikke er nogen andre i nærheden...';

$txt['ban_name_exists'] = 'Navnet på bandlysningen (%1$s) eksisterer allerede. Vælg venligst et andet navn.';
$txt['ban_trigger_already_exists'] = 'Bandlysnings-triggeren (%1$s) eksisterer allerede i %2$s.';
$txt['attach_check_nag'] = 'Kunne ikke fortsætte på grund af manglende data (%1$s).';

$txt['recycle_no_valid_board'] = 'Der blev ikke valgt et gyldigt board til genetablerede emner';
$txt['post_already_deleted'] = 'Emnet eller indlægget er allerede flyttet til skraldespanden. Er du sikker på du vil slette det fuldstændigt?<br />I så fald <a href="%1$s">følg dette link</a>';

$txt['login_threshold_fail'] = 'Du har overskredet antallet af chancer for at logge på. Prøv venligst senere.';
$txt['login_threshold_brute_fail'] = 'Beklager, men du har nået din login-forsøgs tærskel. Vent venligst 30 sekunder og prøv igen.';

$txt['who_off'] = 'Vi ville meget gerne lade dig kigge på Hvem er Online, men desværre er den i øjeblikket deaktiveret.';

$txt['merge_create_topic_failed'] = 'Beklager meget. Vi forsøgte, men oprettelsen af et nyt emne mislykkedes.';
$txt['merge_need_more_topics'] = 'Fletning af emner kræver mindst to emner, men vi har ikke to. Prøv igen.';

$txt['post_WaitTime_broken'] = 'Det seneste indlæg fra din IP adresse var for mindre end  %1$d sekunder siden. Prøv venligst igen senere.';
$txt['register_WaitTime_broken'] = 'Du har allerede registreret dig for blot %1$d sekunder siden!';
$txt['login_WaitTime_broken'] = 'Beklager, men du er nødt til at vente i ca. %1$d sekunder for at logge ind igen.';
$txt['pm_WaitTime_broken'] = 'Den seneste personlige besked fra din IP adresse var for mindre end %1$d sekunder siden. Prøv venligst igen senere.';
$txt['reporttm_WaitTime_broken'] = 'Den seneste emnerapport fra din IP adresse var mindre end %1$d sekunder siden. Prøv venligst igen senere.';
$txt['sendtopic_WaitTime_broken'] = 'Det sidste emne sendt fra din IP adresse var for mindre end %1$d sekunder siden. Prøv venligst igen senere.';
$txt['sendmail_WaitTime_broken'] = 'Den sidste e-mail sendt fra din IP adresse var for mindre end %1$d sekunder siden. Prøv venligst igen senere.';
$txt['search_WaitTime_broken'] = 'Din seneste søgning var for mindre end %1$d sekunder siden. Prøv venligst igen senere.';
$txt['remind_WaitTime_broken'] = 'Din sidste påmindelse var mindre end %1$d sekunder siden. Prøv igen senere.';
$txt['contact_WaitTime_broken'] = 'Sidste gang du prøvede at bruge kontakt formular var mindre end %1$d sekunder siden. Prøv igen senere.';

$txt['topic_gone'] = 'Vi forsøgte virkelig hårdt at finde det emne eller board du leder efter, men det kan ikke findes. Ser ud til det enten mangler eller at du ikke har adgang til det.';
$txt['theme_edit_missing'] = 'Vi forsøgte virkelig hårdt at finde den fil du prøver at redigere, men den kan ikke findes.';

$txt['no_dump_database'] = 'Beklager, vi kan ikke lade dig lave database backups. Kun administratorer kan gøre dette.';
$txt['pm_not_yours'] = 'Den personlige besked du forsøger at citere er ikke din egen eller eksisterer ikke, gå venligst tilbage og prøv igen.';
$txt['mangled_post'] = 'Ødelagte formular data - gå venligst tilbage og prøv igen.';
$txt['too_many_groups'] = 'Beklager, du valgte for mange grupper, fjern nogle af dem.';
$txt['post_upload_error'] = 'Post-data mangler. Denne fejl kan skyldes afsendelse af en fil der er større end tilladt af serveren. Kontakt din administrator hvis dette problem fortsætter.';
$txt['quoted_post_deleted'] = 'Indlægget du forsøger at citere, eksister enten ikke, er slettet, eller er ikke længere synligt for dig.';
$txt['pm_too_many_per_hour'] = 'Du har overskredet begrænsningen på %1$d personlige beskeder per time.';
$txt['labels_too_many'] = 'Beklager, men %1$s beskeder har allerede det maksimale antal af mærkater der er tilladt!';

$txt['register_only_once'] = 'Beklager, men du kan ikke registrere flere konti på en gang fra den samme computer.';
$txt['admin_setting_coppa_require_contact'] = 'Du skal enten angive en post eller fax kontakt hvis der forlanges en forælder/værge godkendelse.';

$txt['error_long_name'] = 'Navnet du forsøgte at anvende, var for langt.';
$txt['error_no_name'] = 'Der blev ikke angivet noget navn.';
$txt['error_bad_name'] = 'Navnet du forsøgte at anvende, kan ikke benyttes da det er eller indeholder et reserveret navn.';
$txt['error_no_email'] = 'Der blev ikke angivet en e-mail-adresse.';
$txt['error_bad_email'] = 'Der blev angivet en ugyldig e-mail-adresse.';
$txt['error_email'] = 'email adresse';
$txt['error_message'] = 'besked';
$txt['error_no_event'] = 'Der blev ikke angivet noget navn til begivenheden.';
$txt['error_no_subject'] = 'Der blev ikke udfyldt nogen overskrift.';
$txt['error_no_question'] = 'Der blev ikke udfyldt et spørgsmål til afstemningen.';
$txt['error_no_message'] = 'Beskedfeltet er tomt.';
$txt['error_long_message'] = 'Indlægget overstiger den maksimalt tilladte længde (%1$d karakterer).';
$txt['error_no_comment'] = 'Kommentarfeltet blev ikke udfyldt.';
$txt['error_post_too_long'] = 'Din besked er for lang. Skriv maksimalt kun 255 karakterer.';
$txt['error_session_timeout'] = 'Din session udløb imens du postede. Prøv venligst at afsende din meddelelse igen.';
$txt['error_no_to'] = 'Ingen modtagere angivet.';
$txt['error_bad_to'] = 'En eller flere \'til\'-modtagere kunne ikke findes.';
$txt['error_bad_bcc'] = 'En eller flere \'bcc\'-modtagere kunne ikke findes.';
$txt['error_form_already_submitted'] = 'Du har allerede afsendt denne besked! Du har muligvis ved en fejl dobbeltklikket eller genindlæst siden.';
$txt['error_poll_few'] = 'Du skal oprette mindst to valg!';
$txt['error_poll_many'] = 'Du kan ikke have mere end 256 valg.';
$txt['error_need_qr_verification'] = 'Færdiggør venligst sektionen med bekræftigelsen herunder for at færdiggøre dit indlæg.';
$txt['error_wrong_verification_code'] = 'Bogstaverne du angav matcher ikke bogstaverne vist i billedet.';
$txt['error_wrong_verification_answer'] = 'Du besvarede ikke spørgsmålene i bekræftigelsen korrekt.';
$txt['error_need_verification_code'] = 'Skriv venligst bekræftigelseskoden herunder for at fortsætte til resultaterne.';
$txt['error_bad_file'] = 'Beklager, men den angivne fil kunne ikke åbnes: %1$s';
$txt['error_bad_line'] = 'Linien du angav er ikke korrekt.';
$txt['error_draft_not_saved'] = 'Der opstod en fejl under gemning af kladde';
$txt['error_name_in_use'] = 'Navnet %1$s er allerede i brug af en anden bruger.';

$txt['smiley_not_found'] = 'Smileyen blev ikke fundet.';
$txt['smiley_has_no_code'] = 'Der blev ikke angivet nogen kode til denne smiley.';
$txt['smiley_has_no_filename'] = 'Der blev ikke angivet noget filnavn til denne smiley.';
$txt['smiley_not_unique'] = 'En smiley med den kode eksisterer allerede.';
$txt['smiley_set_already_exists'] = 'Et smileysæt på den adresse eksisterer allerede!';
$txt['smiley_set_not_found'] = 'smileysættet blev ikke fundet';
$txt['smiley_set_dir_not_found'] = 'Mappen for smileysættet %1$s er ikke gyldig eller kan ikke tilgås.';
$txt['smiley_set_path_already_used'] = 'Adressen til smileysættet er allerede brugt af et andet smileysæt.';
$txt['smiley_set_unable_to_import'] = 'Kan ikke importere smileysættet. Enten er stien til mappen forkert, eller også kan der ikke opnås adgang til mappen.';

$txt['smileys_upload_error'] = 'Kunne ikke uploade filen.';
$txt['smileys_upload_error_blank'] = 'Alle smileysæt skal have et billede.';
$txt['smileys_upload_error_name'] = 'Alle smileys skal have det samme filnavn.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Illegal type.';

$txt['search_invalid_weights'] = 'Søgekriterier er ikke konfigureret korrekt. Mindst et kriterie skal konfigureres til ikke at være nul. Rapporter denne fejl til en administrator.';

$txt['package_no_file'] = 'Kan ikke finde pakkefilen!';
$txt['packageget_unable'] = 'Det er ikke muligt at oprette forbindelse til serveren. Prøv venligst i stedet at anvende <a href="%1$s" target="_blank" class="new_win">denne adresse</a>.';
$txt['not_valid_server'] = 'Beklager, pakker kan kun downloades på denne måde fra servere du allerede har autoriseret.';
$txt['package_cant_uninstall'] = 'Denne pakke var enten aldrig installeret eller var allerede afinstalleret - du kan ikke afinstallere den nu.';
$txt['package_cant_download'] = 'Du kan ikke downloade eller installere nye pakker, fordi mappen til &quot;pakker&quot; eller en af filerne i den ikke er skrivbare!';
$txt['package_upload_error_nofile'] = 'Du valgte ikke nogen pakke at uploade.';
$txt['package_upload_error_failed'] = 'Ikke i stand til at uploade pakken, check venligst tilladelserne for mappen!';
$txt['package_upload_error_exists'] = 'Den fil du uploadede eksisterer allerede på serveren. Slet den først og forsøg så igen.';
$txt['package_upload_already_exists'] = 'Pakken du forsøger at uploade eksisterer allerede på serveren under filnavnet: %1$s';
$txt['package_upload_error_supports'] = 'Pakke-manageren tillader i øjeblikket kun disse filtyper: %1$s.';
$txt['package_upload_error_broken'] = 'Upload af pakken fejlede på grund af følgende fejl:<br />&quot;%1$s&quot;';

$txt['package_get_error_not_found'] = 'Pakken du forsøger at installere kan ikke findes. Du kan prøve at uploade pakken manuelt til mappen for &quot;pakker&quot;';
$txt['package_get_error_missing_xml'] = 'Pakken du forsøger at installere, mangler filen package-info.xml som skal befinde sig i roden af mappen til pakken.';
$txt['package_get_error_is_zero'] = 'Selvom pakken blev downloadet til serveren, ser det ud til at den er tom. Check mappen for &quot;pakker&quot; samt &quot;temp&quot; undermappen begge er skrivbare. Hvis du fortsat oplever dette problem, prøv da at udpakke pakken til din PC og upload de udpakkede filer til en undermappe inde i mappen for &quot;pakker&quot; og prøv så igen. F.eks. Hvis pakker hedder shout.tar.gz skal du:<br />1) Download pakken til din locale PC og udpakke dets filer.<br />2) Opret en ny mappe inde i mappen for &quot;pakker&quot; ved at bruge en FTP klient, i dette eksempel kan du kalde denne mappe for "shout".<br />3) Upload alle filerne som du udpakkede fra pakken til denne mappe.<br />4) Gå tilbage til pakkemanager siden. Pakken skulle automatisk blive fundet.';
$txt['package_get_error_packageinfo_corrupt'] = 'Ikke i stand til at finde gyldig information i package-info.xml filen inkluderet i pakken. Der kan være en fejl i add-on, eller pakken er muligvis korrupt.';
$txt['package_get_error_is_theme'] = 'Du kan ikke installere et tema fra denne sektion, gå til <a href="{MANAGETHEMEURL}">Tema Behandling</a> siden for at uploade det';

$txt['no_membergroup_selected'] = 'Ingen brugergrupper valgt';
$txt['membergroup_does_not_exist'] = 'Brugergruppen eksisterer ikke eller er ugyldig.';

$txt['at_least_one_admin'] = 'Der skal mindst være en administrator i et forum!';

$txt['error_functionality_not_windows'] = 'Beklager, men denne funtion er ikke tilgængelig på servere der kører i Windows.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Vedhæftning ikke fundet';

$txt['error_no_boards_selected'] = 'Ingen gyldige boards var valgt.';
$txt['error_invalid_search_string'] = 'Glemte du at angive noget at søge efter?';
$txt['error_invalid_search_string_blacklist'] = 'Din søgning indeholdte for almindelige ord. Prøv igen med en anden søgning.';
$txt['error_search_string_small_words'] = 'Hvert ord skal mindst være to karakterer lang.';
$txt['error_query_not_specific_enough'] = 'Din søgestreng returnerede ikke noget resultat.';
$txt['error_no_messages_in_time_frame'] = 'Der blev ikke fundet nogen meddelelser inden for det angivede tidsrum.';
$txt['error_no_labels_selected'] = 'Ingen mærkater blev valgt';
$txt['error_no_search_daemon'] = 'Det er ikke muligt at få adgang til søgedæmonen.';

$txt['profile_errors_occurred'] = 'De følgende fejl opstod under opdatering af din profil';
$txt['profile_error_bad_offset'] = 'Tidsforskydningen er uden for grænsen';
$txt['profile_error_no_name'] = 'Navnefeltet var blankt';
$txt['profile_error_digits_only'] = 'Feltet \'Indlæg\' kan kun indeholde tal.';
$txt['profile_error_name_taken'] = 'Det valgte brugernavn/skærmnavn er allerede i brug';
$txt['profile_error_name_too_long'] = 'Det valgte brugernavn er for langt. Det må ikke være længere end 60 karakterer langt';
$txt['profile_error_no_email'] = 'Feltet til e-mail blev ikke udfyldt';
$txt['profile_error_bad_email'] = 'Du har ikke angivet en gyldig e-mail-adresse';
$txt['profile_error_email_taken'] = 'En anden bruger er allerede registreret med den e-mail-adresse';
$txt['profile_error_no_password'] = 'Du angav ikke dit kodeord';
$txt['profile_error_bad_new_password'] = 'De nye kodeord du skrev, er ikke identiske';
$txt['profile_error_bad_password'] = 'Kodeordet du skrev var ikke korrekt';
$txt['profile_error_bad_avatar'] = 'Den avatar du valgte er for stor, eller er ikke en gyldig avatar';
$txt['profile_error_password_short'] = 'Dit kodeord skal være mindst %1$s karakterer lang.';
$txt['profile_error_password_restricted_words'] = 'Dit kodeord må ikke indeholde dit brugernavn, email adresse eller andre almindeligt brugte ord.';
$txt['profile_error_password_chars'] = 'Dit kodeord skal bestå af en blanding af store og små bogstaver, såvel som tal.';
$txt['profile_error_already_requested_group'] = 'Du har allerede en uafklaret forespørgsel for denne gruppe!';
$txt['profile_error_openid_in_use'] = 'En anden bruger benytter allerede den pågældende OpenID webaddresse.';
$txt['profile_error_signature_not_yet_saved'] = 'Signaturen blev ikke gemt.';
$txt['profile_error_personal_text_too_long'] = 'Den personlige tekst er for lang.';
$txt['profile_error_user_title_too_long'] = 'Den brugerdefinerede tittel er for lang.';

$txt['mysql_error_space'] = ' - Tjek databasens kapacitet, eller kontakt server administratoren.';

$txt['icon_not_found'] = 'Billedikonet kunne ikke findes i standardtemaet - sikrer dig at billedet er blevet uploadet, og prøv igen.';
$txt['icon_after_itself'] = 'Ikonet kan ikke placeres efter sig selv.';
$txt['icon_name_too_long'] = 'Filnavne for ikoner kan ikke være på mere end 16 karakterer';

$txt['name_censored'] = 'Beklager, men navnet, %1$s, du forsøger at anvende, indeholder ord der er censurerede. Prøv venligst med et andet navn.';

$txt['poll_already_exists'] = 'Et emne kan kun have en afstemning.';
$txt['poll_not_found'] = 'Der er ikke associeret nogen afstemning med dette emne!';

$txt['error_while_adding_poll'] = 'Følgende fejl opstod under tilføjelse af denne afstemning';
$txt['error_while_editing_poll'] = 'Følgende fejl opstod under redigering af denne afstemning';

$txt['loadavg_search_disabled'] = 'På grund af høj aktivitet på serveren, er søgefunktionen automatisk og midlertidigt deaktiveret. Prøv igen om et øjeblik.';
$txt['loadavg_generic_disabled'] = 'Beklager, på grund af høj aktivitet på serveren, er denne funktion i øjeblikket ikke tilgængelig.';
$txt['loadavg_allunread_disabled'] = 'Serverens resourcer er midlertidigt under for stort pres til at finde alle emner du ikke har læst.';
$txt['loadavg_unreadreplies_disabled'] = 'Serveren er i øjeblikket under høj stress. Prøv igen om et øjeblik.';
$txt['loadavg_show_posts_disabled'] = 'Prøv igen senere. Dette medlems indlæg er i øjeblikket ikke tilgængelige på grund af for høj aktivitet på serveren.';
$txt['loadavg_unread_disabled'] = 'Serverens resourcer er midlertidigt under for stort pres til at vise alle emner du ikke har læst.';
$txt['loadavg_userstats_disabled'] = 'Prøv igen senere. Statistikken for denne bruger er ikke tilgængelig i øjeblikket på grund af høj server aktivitet.';

$txt['cannot_edit_permissions_inherited'] = 'Du kan ikke redigere nedarvede tilladelser direkte, du skal enten redigere den ovenliggende gruppe eller redigere nedarvingen af brugergruppen.';

$txt['mc_no_modreport_specified'] = 'Du skal angive hvilken rapport du ønsker at se.';
$txt['mc_no_modreport_found'] = 'Den angivede rapport eksisterer enten ikke, eller er uden for din rækkevidde';

$txt['st_cannot_retrieve_file'] = 'Kunne ikke hente filen %1$s.';
$txt['admin_file_not_found'] = 'Kunne ikke indlæse den ønskede fil: %1$s.';

$txt['themes_none_selectable'] = 'Mindst et tema skal være valgbart.';
$txt['themes_default_selectable'] = 'Standard forum temaet skal være et valgbart tema.';
$txt['ignoreboards_disallowed'] = 'Valget til at ignorere boards er ikke sat aktivt.';

$txt['mboards_delete_error'] = 'Ingen kategori valgt.';
$txt['mboards_delete_board_error'] = 'Ingen board valgt.';
$txt['mboards_delete_board_has_posts'] = 'Det valgte board har stadig indlæg og/eller emner.';

$txt['mboards_parent_own_child_error'] = 'Det er ikke muligt en sætte en gruppe til også at være en undergruppe af sig selv.';
$txt['mboards_board_own_child_error'] = 'Det er ikke muligt at sætte et board til også at være et underboard af sig selv.';

$txt['smileys_upload_error_notwritable'] = 'De følgende smiley mapper er ikke skrivbare: %1$s';
$txt['smileys_upload_error_types'] = 'Smiley ikoner kan kun have følgende fil-endelser: %1$s.';

$txt['change_email_success'] = 'Din e-mail-adresse er blevet ændret og en ny aktiverings-e-mail er blevet sendt til den.';
$txt['resend_email_success'] = 'En ny aktiverings-e-mail er blevet afsendt med succes.';

$txt['custom_option_need_name'] = 'Profil felt skal have et navn.';
$txt['custom_option_not_unique'] = 'Feltnavnet er ikke unikt.';
$txt['custom_option_regex_error'] = 'Den indtastede regex er ikke gyldig';

$txt['warning_no_reason'] = 'Du skal angive en begrundelse for at at give en advarsel om et medlem';
$txt['warning_notify_blank'] = 'Du valgte at udstede en advarsel til medlemmet, men udfyldte ikke overskrift/meddelelsesfelterne.';

$txt['cannot_connect_doc_site'] = 'Kunne ikke forbinde til dokumentations siden. Kontroller at din server konfiguration tillader eksterne internet forbindelser og prøv igen senere.';

$txt['movetopic_no_reason'] = 'Du skal angive en begrundelse for at flytte emnet, eller fjerne markeringen \'Post et omdirigeringsemne\'.';
$txt['movetopic_no_board'] = 'Du skal vælge et board du vil flytte emnet til.';

$txt['splittopic_no_reason'] = 'Du skal angive en grund til at opdele emnet, eller fjerne markering i feltet \'skriv en omdirigeringsbesked\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Den anmodede identifikator returnerede ikke den korrekte information.';
$txt['openid_return_no_mode'] = 'Identitetsudbyderen svarede ikke i OpenID mode.';
$txt['openid_not_resolved'] = 'Identitetsudbyderen godkendte ikke din forespørgsel.';
$txt['openid_no_assoc'] = 'Kunne ikke finde den forespurgte assosiation med Identitetsudbyderen.';
$txt['openid_sig_invalid'] = 'Signaturen fra Identitetsudbyderen er ugyldig.';
$txt['openid_load_data'] = 'Kunne ikke hente data fra din login forespørgsel. Prøv venligst igen.';
$txt['openid_not_verified'] = 'Den indtastede OpenID er endnu ikke blevet bekræftet. Log ind for at bekræfte.';

$txt['error_custom_field_too_long'] = 'Feltet &quot;%1$s&quot; kan ikke være mere end %2$d karakterer lang.';
$txt['error_custom_field_invalid_email'] = 'Feltet &quot;%1$s&quot; skal være en gyldig mailadresse.';
$txt['error_custom_field_not_number'] = 'Feltet &quot;%1$s&quot; skal være numerisk.';
$txt['error_custom_field_inproper_format'] = 'Feltet &quot;%1$s&quot; er et ugyldigt format.';
$txt['error_custom_field_empty'] = 'Feltet &quot;%1$s&quot; må ikke være blankt.';

$txt['email_no_template'] = 'E-mail skabelonen &quot;%1$s&quot; kunne ikke findes.';

$txt['search_api_missing'] = 'Søgeinterfacet kunne ikke findes. Kontakt en administrator for at bekræfte om de har uploadet de korrekte filer.';
$txt['search_api_not_compatible'] = 'Det valgte søgeinterface anvendt på forum er forældet - falder tilbage til standardsøgning. Kontroller filen %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Du kan ikke genetablere det første indlæg i et emne.';
$txt['restored_disabled'] = 'Genetableringen af emner er blevet deaktiveret.';
$txt['restore_not_found'] = 'De følgende indlæg kunne ikke gendannes; Det originale emne er muligvis blevet fjernet: %1$s Du er nødt til at flytte disse manuelt.';

$txt['error_invalid_dir'] = 'Mappen du angav er ugyldig.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'Den underbehandling du valgte er ikke defineret';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'Ingen sorterbare elementer blev fundet';

$txt['error_invalid_notification_id'] = 'En tilføjelse prøver på at registrere en underretnings metode med en eksisterende ID. ID lavere end 5 er beskyttet og kan ikke bruges af tilføjelser. Hvis ID er højere, kan to tilføjelser bruge det samme ID.';
