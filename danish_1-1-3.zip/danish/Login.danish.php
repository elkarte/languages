<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Registrationsaftale';
$txt['registration_privacy_policy'] = 'Privatlivsaftale';
$txt['agreement_agree'] = 'Jeg accepterer indholdet i registrationsaftalen.';
$txt['agreement_no_agree'] = 'Jeg accepterer ikke indholdet af aftalen.';
$txt['policy_agree'] = 'Jeg accepterer indholdet af privatlivsaftalen.';
$txt['policy_no_agree'] = 'Jeg accepterer ikke indholdet af privatlivsaftalen.';
$txt['agreement_agree_coppa_above'] = 'Jeg accepterer indholdet af registrationsaftalen og er mindst  %1$d år gammel.';
$txt['agreement_agree_coppa_below'] = 'Jeg accepterer indholdet af registrationsaftalen og er mindre end %1$d år gammel.';
$txt['agree_coppa_above'] = 'Jeg er minimum %1$d år gammel.';
$txt['agree_coppa_below'] = 'Jeg er yngre end %1$d år.';

// Registration form.
$txt['registration_form'] = 'Registreringsformular';
$txt['error_too_quickly'] = 'Du gik igennem registrerings processen for hurtigt, hurtigere end det normalt vil være muligt. Vent venligst et øjeblik og prøv igen.';
$txt['error_token_verification'] = 'Token verifikation mislykkedes. Prøv venligst igen.';
$txt['need_username'] = 'Du skal udfylde et brugernavn.';
$txt['no_password'] = 'Du angav ikke dit kodeord.';
$txt['improper_password'] = 'Den angivne kode er for lang.';
$txt['incorrect_password'] = 'Kodeordet er forkert';
$txt['openid_not_found'] = 'Angivne OpenID identitet blev ikke fundet.';
$txt['maintain_mode'] = 'Vedligeholdelsestilstand';
$txt['registration_successful'] = 'Registrering gennemført';
$txt['valid_email_needed'] = 'Angiv venligst en gyldig mailadresse, %1$s.';
$txt['required_info'] = 'Krævet information';
$txt['additional_information'] = 'Yderligere Information';
$txt['warning'] = 'Advarsel!';
$txt['only_members_can_access'] = 'Kun registrerede medlemmer har adgang til denne sektion.';
$txt['login_below'] = 'Log venligst ind herunder.';
$txt['login_below_or_register'] = 'Log venligst ind herunder eller <a href="%1$s"registrer en konto</a> med %2$s';
$txt['checkbox_agreement'] = 'Jeg accepterer indholdet i registrationsaftalen.';
$txt['checkbox_privacypol'] = 'Jeg accepterer privatlivsaftalen';
$txt['confirm_request_accept_agreement'] = 'Er du sikker på at du vil tvinge alle brugere til at acceptere aftalen?';
$txt['confirm_request_accept_privacy_policy'] = 'Er du sikker på at du vil tvinge alle brugere til at acceptere privatlivsaftalen?';

$txt['login_hash_error'] = 'Sikkerheden for kodeord er blevet opgraderet for nylig.<br />Skriv venligst dit kodeord igen.';

$txt['ban_register_prohibited'] = 'Det er desværre ikke tilladt for dig at registrere på dette forum';
$txt['under_age_registration_prohibited'] = 'Beklager, men brugere der er under %1$d år, er ikke tilladt at registrere i dette forum.';

$txt['activate_account'] = 'Kontoaktivering';
$txt['activate_success'] = 'Din konto er successfuldt blevet aktiveret. Du kan nu fortsætte med at logge på.';
$txt['activate_not_completed1'] = 'Din e-mail-adresse skal valideres før du kan logge på.';
$txt['activate_not_completed2'] = 'Har du brug for en ny aktiverings-e-mail?';
$txt['activate_after_registration'] = 'Tak for din registrering. Du vil snarest modtage en e-mail, med et link til at aktivere din konto.';
$txt['invalid_userid'] = 'Brugeren eksisterer ikke';
$txt['invalid_activation_code'] = 'Forkert aktiveringskode';
$txt['invalid_activation_username'] = 'Brugernavn eller e-mail';
$txt['invalid_activation_new'] = 'Hvis du registrerede med den forkerte e-mail-adresse, skal du angive en ny, samt dit kodeord her.';
$txt['invalid_activation_new_email'] = 'Ny e-mail-adresse';
$txt['invalid_activation_password'] = 'Gammelt kodeord';
$txt['invalid_activation_resend'] = 'Gensend aktiveringskode';
$txt['invalid_activation_known'] = 'Hvis du allerede kender din aktiveringskode, skal du venligst skrive den her.';
$txt['invalid_activation_retry'] = 'Aktiveringskode';
$txt['invalid_activation_submit'] = 'Aktiver';

$txt['coppa_no_concent'] = 'Administratoren har stadig ikke modtaget et forælder/værge samtykke for din konto.';
$txt['coppa_need_more_details'] = 'Brug for flere detaljer?';

$txt['awaiting_delete_account'] = 'Din konto er sat til at blive slettet!<br />Hvis du ønsker at genetablere din konto, skal du markere &quot;Reaktiver min konto&quot; og log ind igen.';
$txt['undelete_account'] = 'Reaktiver min konto';

$txt['in_maintain_mode'] = 'Dette board er i vedligeholdelsestilstand.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Læs og accepter venligst betingelserne før registrering.';
$txt['register_passwords_differ_js'] = 'De to kodeord du angav er ikke ens!';
$txt['register_did_you'] = 'Mente du';

$txt['approval_after_registration'] = 'Tak for registreringen. Administratoren skal godkende din registrering før du kan begynde at bruge din konto. Du vil modtage en e-mail der kort fortæller dig om administartorens afgørelse.';

$txt['admin_settings_desc'] = 'Her kan du ændre forskellige indstillinger som relaterer til registrering af nye medlemmer.';

$txt['setting_enableOpenID'] = 'Tillad brugere at registrere ved at bruge OpenID';

$txt['setting_registration_method'] = 'Metode for registration brugt til nye medlemmer';
$txt['setting_registration_disabled'] = 'Registrering deaktiveret';
$txt['setting_registration_standard'] = 'Øjeblikkelig registrering';
$txt['setting_registration_activate'] = 'E-mail aktivering';
$txt['setting_registration_approval'] = 'Administratorgodkendelse';
$txt['setting_notify_new_registration'] = 'Giv besked til administratorer når nye medlemmer slutter sig til';
$txt['setting_force_accept_agreement'] = 'Tving brugere til at acceptere registreringsaftalen når den ændres';
$txt['force_accept_privacy_policy'] = 'Tving brugere til at acceptere privatlivsaftalen når den ændres';
$txt['setting_send_welcomeEmail'] = 'Send velkomstmail til nye medlemmer';
$txt['setting_show_DisplayNameOnRegistration'] = 'Tillad brugere at skrive deres skærm navn';

$txt['setting_coppaAge'] = 'Minimumsalder hvorunder aldersrestriktioner træder i kraft';
$txt['setting_coppaAge_desc'] = '(0 for at deaktivere)';
$txt['setting_coppaType'] = 'Handling hvis en bruger under minimumsalderen registrerer';
$txt['setting_coppaType_reject'] = 'Afvis deres registrering';
$txt['setting_coppaType_approval'] = 'Forlang forælder/værge godkendelse';
$txt['setting_coppaPost'] = 'Postadresse hvortil godkendelsesformularer skal sendes';
$txt['setting_coppaPost_desc'] = 'Træder kun i kraft hvis aldersbegrænsning er på plads';
$txt['setting_coppaFax'] = 'Fax nummer hvortil formularer skal faxes';
$txt['setting_coppaPhone'] = 'Kontaktnummer for forældre at kontakte med spørgsmål til aldersbegrænsning';

$txt['admin_register'] = 'Registrering af nyt medlem';
$txt['admin_register_desc'] = 'Herfra kan du registrere nye medlemmer til forumet, og hvis ønsket, maile dem deres detaljer.';
$txt['admin_register_username'] = 'Nyt brugernavn';
$txt['admin_register_email'] = 'E-mail-adresse';
$txt['admin_register_password'] = 'Kodeord';
$txt['admin_register_username_desc'] = 'Brugernavn for det ny medlem';
$txt['admin_register_email_desc'] = 'Medlemmets e-mail-adresse';
$txt['admin_register_password_desc'] = 'Kodeord for det nye medlem';
$txt['admin_register_email_detail'] = 'E-mail nyt kodeord til brugeren';
$txt['admin_register_email_detail_desc'] = 'E-mailadresse er krævet, selvom der ikke er sat markering';
$txt['admin_register_email_activate'] = 'Forlang at brugeren aktiverer kontoen';
$txt['admin_register_group'] = 'Primær medlemsgruppe';
$txt['admin_register_group_desc'] = 'Primær medlemsgruppe det nye medlem vil tilhøre';
$txt['admin_register_group_none'] = '(ingen primær medlemsgruppe)';
$txt['admin_register_done'] = 'Medlemmet %1$s er blevet registreret!';

$txt['coppa_title'] = 'Aldersbegrænset forum';
$txt['coppa_after_registration'] = 'Tak for at registrere dig hos {forum_name_html_safe}.<br /><br />Fordi du er yngre end {MINIMUM_AGE}, er det et lovkrav at du får tilladelse af dine forældre eller værge, før du kan bruge din konto. For at arrangere konto aktivering, udprint venligst nedenstående formular:';
$txt['coppa_form_link_popup'] = 'Åbn formularen i et nyt vindue';
$txt['coppa_form_link_download'] = 'Hent formularen som en tekstfil';
$txt['coppa_send_to_one_option'] = 'Derefter skal du have en forælder/værge til at sende denne i udfyldt tilstand med:';
$txt['coppa_send_to_two_options'] = 'Arranger derefter en forælder/værge til at sende den udfyldte formular med enten:';
$txt['coppa_send_by_post'] = 'Send til følgende adresse:';
$txt['coppa_send_by_fax'] = 'Fax til følgende adresse:';
$txt['coppa_send_by_phone'] = 'Alternativt kan de ringe til administratoren på nummeret {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Tilladelses formular for registrering hos {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Adresse';
$txt['coppa_form_date'] = 'Dato';
$txt['coppa_form_body'] = 'Jeg {PARENT_NAME},<br /><br />giver hermed tilladelse til {CHILD_NAME}(barnets navn) at blive fuldgyldigt medlem på fora: {forum_name_html_safe}, med brugernavnet: {USER_NAME}.<br /><br />Jeg er indforstået med at visse personlige informationer indtastet af {USER_NAME} kan blive vist til andre brugere af dette fora.<br /><br />Underskrevet:<br />{PARENT_NAME}(Forælder/Værge).';

$txt['visual_verification_sound_again'] = 'Afspil igen';
$txt['visual_verification_sound_close'] = 'Luk vinduet';
$txt['visual_verification_sound_direct'] = 'Har du problemer med at høre dette?  Prøv et direkte link til lydfilen.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Brugernavnet er tilg&#230;ngelig';
$txt['registration_username_unavailable'] = 'Brugernavnet er ikke tilgængelig';
$txt['registration_username_check'] = 'Kontroller om brugernavnet er tilgængelig';
$txt['registration_password_short'] = 'Kodeordet er for kort';
$txt['registration_password_reserved'] = 'Kodeordet indeholder dit brugernavn eller e-mail-adresse';
$txt['registration_password_numbercase'] = 'Kodeordet skal bestå af både store og små bogstaver, samt tal';
$txt['registration_password_no_match'] = 'Kodeordene matcher ikke';
$txt['registration_password_valid'] = 'Kodeordet er gyldigt';

$txt['registration_errors_occurred'] = 'Følgende fejl blev opdaget ved din registrering. Ret dem for at fortsætte:';

$txt['authenticate_label'] = 'Metode for autentificering';
$txt['authenticate_password'] = 'Kodeord';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'Webadresse for OpenID autentificering';
$txt['otp_required'] = 'En Tids-baseret Engangskode er krævet for at logge ind!';
$txt['disable_otp'] = 'Deaktiver to faktor autentifikation.';

// Contact form
$txt['admin_contact_form'] = 'Kontakt administrator';
$txt['contact_your_message'] = 'Din besked';
$txt['errors_contact_form'] = 'Følgende fejl opstod under behandling af din kontakt anmodning';
$txt['contact_subject'] = 'En gæst har sendt dig en besked';
$txt['contact_thankyou'] = 'Tak for din besked. Du vil blive kontaktet snarest muligt.';
