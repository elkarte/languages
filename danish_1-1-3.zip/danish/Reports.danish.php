<?php
// Version: 1.1; Reports

$txt['generate_reports_desc'] = 'I denne sektion kan du generere forskellige rapporter du kan bruge som støtte til at administrere dit forum. Følg anvisningerne herunder for at generere en rapport.';
$txt['generate_reports_continue'] = 'Fortsæt';
$txt['generate_reports_type'] = 'Vælg Rapport Type';
$txt['gr_type_boards'] = 'Boards';
$txt['gr_type_desc_boards'] = 'Denne rapport viser de aktuelle indstillinger samt adgangsniveau for hver board i dit forum.';
$txt['gr_type_board_perms'] = 'Board tilladelser';
$txt['gr_type_desc_board_perms'] = 'Genererer rapporter der viser de tilladelser hver medlemsgruppe er i besiddelse af, på tværs af de forskellige boards i dit forum.';
$txt['gr_type_member_groups'] = 'Medlemsgrupper';
$txt['gr_type_desc_member_groups'] = 'Rapport der viser indstillingerne for hver medlemsgruppe i dit forum.';
$txt['gr_type_group_perms'] = 'Gruppetilladelser';
$txt['gr_type_desc_group_perms'] = 'Rapport der viser tilladelserne hver medlemsgruppe er i besiddelse af i forummet.';
$txt['gr_type_staff'] = 'Stab';
$txt['gr_type_desc_staff'] = 'Denne rapport lister alle medlemmer der i øjeblikket har en autoritets-position i forummet.';

$txt['full_member'] = 'Fuldgyldige medlemmer';
$txt['results'] = 'Resultater';

// Board permissions
$txt['board_perms_permission'] = 'Tilladelser';
$txt['board_perms_allow'] = 'Tillad';
$txt['board_perms_deny'] = 'Nægt';
$txt['board_perms_name_announce_topic'] = 'Annoncere emne';
$txt['board_perms_name_approve_posts'] = 'Godkende poster';
$txt['board_perms_name_delete_any'] = 'Slette ethvert indlæg';
$txt['board_perms_name_delete_own'] = 'Slette egne indlæg';
$txt['board_perms_name_delete_replies'] = 'Slette svar i egne emner';
$txt['board_perms_name_lock_any'] = 'Låse ethvert emne';
$txt['board_perms_name_lock_own'] = 'Låse egne emner';
$txt['board_perms_name_make_sticky'] = 'Pin emner';
$txt['board_perms_name_mark_any_notify'] = 'Anmode om besked ved respons i alle emner';
$txt['board_perms_name_mark_notify'] = 'Anmode om besked ved respons i egne emner';
$txt['board_perms_name_merge_any'] = 'Flette emner';
$txt['board_perms_name_moderate_board'] = 'Ændre boardet';
$txt['board_perms_name_modify_any'] = 'Rette i ethvert indlæg';
$txt['board_perms_name_modify_own'] = 'Redigere i egne indlæg';
$txt['board_perms_name_modify_replies'] = 'Ændre i svar der oprettes i egne emner';
$txt['board_perms_name_move_any'] = 'Flytte Ethvert Emne';
$txt['board_perms_name_move_own'] = 'Flytte Egne Emner';
$txt['board_perms_name_poll_add_any'] = 'Tilføje afstemning til ethvert emne';
$txt['board_perms_name_poll_add_own'] = 'Tilføje afstemning i egne emner';
$txt['board_perms_name_poll_edit_any'] = 'Redigere i enhver afstemning';
$txt['board_perms_name_poll_edit_own'] = 'Redigere i egne afstemninger';
$txt['board_perms_name_poll_lock_any'] = 'Låse enhver afstemning';
$txt['board_perms_name_poll_lock_own'] = 'Låse egne afstemninger';
$txt['board_perms_name_poll_post'] = 'Oprette nye afstemninger';
$txt['board_perms_name_poll_remove_any'] = 'Fjerne enhver afstemninger';
$txt['board_perms_name_poll_remove_own'] = 'Fjerne egne afstemninger';
$txt['board_perms_name_poll_view'] = 'Se afstemninger';
$txt['board_perms_name_poll_vote'] = 'Stemme i afstemninger';
$txt['board_perms_name_post_attachment'] = 'Poste vedhæftninger';
$txt['board_perms_name_post_new'] = 'Oprette nye emner';
$txt['board_perms_name_post_reply_any'] = 'Oprette svar i ethvert emne';
$txt['board_perms_name_post_reply_own'] = 'Oprette svar i egne emner';
$txt['board_perms_name_post_unapproved_attachments'] = 'Poste ikke-godkendte vedhæftninger';
$txt['board_perms_name_post_unapproved_topics'] = 'Oprette ikke-godkendte emner';
$txt['board_perms_name_post_unapproved_replies_any'] = 'Oprette ikke-godkendte svar i ethvert emne';
$txt['board_perms_name_post_unapproved_replies_own'] = 'Oprette ikke-godkendte svar i egne emner';
$txt['board_perms_name_remove_any'] = 'Slette ethvert emne';
$txt['board_perms_name_remove_own'] = 'Slette egne emner';
$txt['board_perms_name_report_any'] = 'Anmelde ethvert indlæg';
$txt['board_perms_name_send_topic'] = 'Sende emner til venner';
$txt['board_perms_name_split_any'] = 'Splitte ethvert emne';
$txt['board_perms_name_view_attachments'] = 'Se vedhæftninger';

$txt['board_perms_group_no_polls'] = 'Dette board tillader ikke afstemninger';
$txt['board_perms_group_reply_only'] = 'Dette board tillader kun brugere at oprette svar i emner';
$txt['board_perms_group_read_only'] = 'Dette board tillader ingen nye indlæg';

// Membergroup info!
$txt['member_group_color'] = 'Farve';
$txt['member_group_min_posts'] = 'Minimum antal indlæg';
$txt['member_group_max_messages'] = 'Max personlige Beskeder';
$txt['member_group_icons'] = 'Ikoner';
$txt['member_group_settings'] = 'Indstillinger';
$txt['member_group_access'] = 'Board-adgang';

// Board info.
$txt['none'] = 'Ingen';
$txt['board_category'] = 'Kategori';
$txt['board_parent'] = 'Ovenliggende Board';
$txt['board_num_topics'] = 'Antal Emner';
$txt['board_num_posts'] = 'Antal svar';
$txt['board_count_posts'] = 'Tæl svar';
$txt['board_theme'] = 'Tema for boardet';
$txt['board_override_theme'] = 'Gennemtving brug af dette tema for boardet';
$txt['board_profile'] = 'Tilladelsesprofil';
$txt['board_moderators'] = 'Moderatorer';
$txt['board_groups'] = 'Grupper med Adgang';
$txt['board_disallowed_groups'] = 'Grupper uden adgang';

// Group Permissions.
$txt['group_perms_name_access_mod_center'] = 'Få Adgang Til Moderationscenteret';
$txt['group_perms_name_admin_forum'] = 'Admin forum';
$txt['group_perms_name_calendar_edit_any'] = 'Redigere i alle begivenheder';
$txt['group_perms_name_calendar_edit_own'] = 'Redigere egne begivenheder';
$txt['group_perms_name_calendar_post'] = 'Tilføje begivenheder';
$txt['group_perms_name_calendar_view'] = 'Se begivenheder';
$txt['group_perms_name_edit_news'] = 'Redigere forumnyheder';
$txt['group_perms_name_issue_warning'] = 'Udstede advarsler';
$txt['group_perms_name_karma_edit'] = 'Redigere brugerkarma';
$txt['group_perms_name_manage_attachments'] = 'Administrere vedhæftninger';
$txt['group_perms_name_manage_bans'] = 'Administrere liste over bandlysninger';
$txt['group_perms_name_manage_boards'] = 'Administrere boards';
$txt['group_perms_name_manage_membergroups'] = 'Administrer medlems grupper';
$txt['group_perms_name_manage_permissions'] = 'Administrere tilladelser';
$txt['group_perms_name_manage_smileys'] = 'Administrere smileys og indlægsikoner';
$txt['group_perms_name_moderate_forum'] = 'Moderere forummet';
$txt['group_perms_name_pm_read'] = 'Læse personlige beskeder';
$txt['group_perms_name_pm_send'] = 'Sende personlige beskeder';
$txt['group_perms_name_profile_extra_any'] = 'Redigere yderligere indstillinger';
$txt['group_perms_name_profile_extra_own'] = 'Redigere yderligere indstillinger for egen profil';
$txt['group_perms_name_profile_identity_any'] = 'Redigere i enhvers konto';
$txt['group_perms_name_profile_identity_own'] = 'Redigere i egen konto';
$txt['group_perms_name_profile_set_avatar'] = 'Vælg en avatar';
$txt['group_perms_name_profile_remove_any'] = 'Slette enhver konto';
$txt['group_perms_name_profile_remove_own'] = 'Slette egen konto';
$txt['group_perms_name_profile_title_any'] = 'Redigere enhver brugerdefineret titel';
$txt['group_perms_name_profile_title_own'] = 'Ændre egen brugerdefineret titel';
$txt['group_perms_name_profile_view_any'] = 'Se alle profiler';
$txt['group_perms_name_profile_view_own'] = 'Vis egen profil';
$txt['group_perms_name_search_posts'] = 'Søge efter indlæg';
$txt['group_perms_name_send_mail'] = 'Sende en forum e-mail til medlemmer';
$txt['group_perms_name_view_mlist'] = 'Vis medlems liste';
$txt['group_perms_name_view_stats'] = 'Se forum-statistik';
$txt['group_perms_name_who_view'] = 'Se hvem der er online';

$txt['report_error_too_many_staff'] = 'Du har for mange stabsmedlemmer. Rapporten vil ikke virke, hvis du har mere end 300 stabsmedlemmer!';
$txt['report_staff_position'] = 'Position';
$txt['report_staff_moderates'] = 'Modererer';
$txt['report_staff_posts'] = 'Indlæg';
$txt['report_staff_last_login'] = 'Seneste login';
$txt['report_staff_all_boards'] = 'Alle boards';
$txt['report_staff_no_boards'] = 'Ingen boards';