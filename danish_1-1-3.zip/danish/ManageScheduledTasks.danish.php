<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Planlagte opgaver';
$txt['scheduled_tasks_header'] = 'Alle planlagte opgaver';
$txt['scheduled_tasks_name'] = 'Opgavenavn';
$txt['scheduled_tasks_next_time'] = 'Forfalder næste gang';
$txt['scheduled_tasks_regularity'] = 'Regelmæssighed';
$txt['scheduled_tasks_enabled'] = 'Aktiveret';
$txt['scheduled_tasks_run_now'] = 'Kør nu';
$txt['scheduled_tasks_save_changes'] = 'Gem ændringerne';
$txt['scheduled_tasks_time_offset'] = '<strong>Bemærk:</strong> Alle tider angivet herunder er <em>server tid</em> og tager ikke højde for nogen tidsforskydninger opsat i administratorpanelet.';
$txt['scheduled_tasks_were_run'] = 'Alle valgte opgaver blev færdiggjort';
$txt['scheduled_tasks_were_run_errors'] = 'Følgende fejl opstod under kørsel af planlagte opgaver:';

$txt['scheduled_tasks_na'] = 'N/A';
$txt['scheduled_task_approval_notification'] = 'Godkendelsesmeddelelser';
$txt['scheduled_task_desc_approval_notification'] = 'Send e-mails ud til alle moderatorer med en liste af indlæg der afventer godkendelse.';
$txt['scheduled_task_auto_optimize'] = 'Optimer database';
$txt['scheduled_task_desc_auto_optimize'] = 'Optimer databasen for at løse fragmenteringsproblemer.';
$txt['scheduled_task_daily_maintenance'] = 'Daglig vedligeholdelse';
$txt['scheduled_task_desc_daily_maintenance'] = 'Kør essentiel daglig vedligeholdelse af forummet - bør ikke deaktiveres.';
$txt['scheduled_task_daily_digest'] = 'Daglig opsummering af meddelelser';
$txt['scheduled_task_desc_daily_digest'] = 'Mailer det daglige sammendrag af meddelelser ud til abonnementer.';
$txt['scheduled_task_weekly_digest'] = 'Ugentlig opsummering af meddelelser';
$txt['scheduled_task_desc_weekly_digest'] = 'Mailer det ugentlige sammendrag af meddelelser ud til abonnementer.';
$txt['scheduled_task_birthdayemails'] = 'Send fødselsdags-e-mails';
$txt['scheduled_task_desc_birthdayemails'] = 'Send e-mails ud der ønsker medlemmer en god fødselsdag.';
$txt['scheduled_task_weekly_maintenance'] = 'Ugentlig vedligeholdelse';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Kører vigtige ugentlig vedligehold i forummet - bør ikke deaktiveres.';
$txt['scheduled_task_paid_subscriptions'] = 'Betalt abonnement check';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Udsender påmindelse til alle ikke-betalte abonnementer og fjerner ikke-betalte abonnementer.';
$txt['scheduled_task_remove_topic_redirect'] = 'Slet FLYTTET: Omdirigerede emner';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Sletter "FLYTTET:" emne meddelelser som de blev specificeret ved oprettelse.';
$txt['scheduled_task_remove_temp_attachments'] = 'Fjern midlertidige vedhæftnings filer';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Sletter midlertidige filer der blev oprettet ved at vedhæfte filer til indlæg der af en eller anden grund ikke blev omdøbt eller slettet før.';
$txt['scheduled_task_remove_old_drafts'] = 'Slet gamle kladder';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Sletter kladder der er ældre end det antal dage som er defineret i kladde indstillingerne i administrationspanelet.';
$txt['scheduled_task_remove_old_followups'] = 'Fjern gamle opfølgninger';
$txt['scheduled_task_desc_remove_old_followups'] = 'Sletter opfølgninger der stadig eksisterer i databasen, men som peger på ikke eksisterende emner.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Hent emails fra IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Henter emails til mailliste funktionen fra en IMAP bakke og bearbejder dem.';
$txt['scheduled_task_user_access_mentions'] = 'Bruger Omtalelse Adgang';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verificer brugeres adgang til hvert board og sæt tilgængelighed til relaterede omtalelser herefter.';

$txt['scheduled_task_reg_starting'] = 'Startende ved %1$s';
$txt['scheduled_task_reg_repeating'] = 'gentaget hver  %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minut(er)';
$txt['scheduled_task_reg_unit_h'] = 'time(r)';
$txt['scheduled_task_reg_unit_d'] = 'dag(e)';
$txt['scheduled_task_reg_unit_w'] = 'uge(r)';

$txt['scheduled_task_edit'] = 'Rediger planlagte opgaver';
$txt['scheduled_task_edit_repeat'] = 'Gentag opgave hver';
$txt['scheduled_task_edit_pick_unit'] = 'Vælg enhed';
$txt['scheduled_task_edit_interval'] = 'Interval';
$txt['scheduled_task_edit_start_time'] = 'Start dato';
$txt['scheduled_task_edit_start_time_desc'] = 'Tiden dagens første eksempel skal starte (timer:minutter)';
$txt['scheduled_task_time_offset'] = 'Bemærk at starttiden bør være forskudt op imod den aktuelle servers tid. Aktuel servertid er: %1$s';

$txt['scheduled_view_log'] = 'Se log';
$txt['scheduled_log_empty'] = 'Der er i øjeblikket ingen emner i loggen.';
$txt['scheduled_log_time_run'] = 'Dato for kørsel';
$txt['scheduled_log_time_taken'] = 'Tid';
$txt['scheduled_log_time_taken_seconds'] = '%1$d sekunder';
$txt['scheduled_log_completed'] = 'Opgave fuldført';
$txt['scheduled_log_empty_log'] = 'Ryd Log';
$txt['scheduled_log_empty_log_confirm'] = 'Er du sikker på du vil rydde hele log?';