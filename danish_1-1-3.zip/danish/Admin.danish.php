<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Boards';
$txt['admin_back_to'] = 'Tilbage til admin panel';
$txt['admin_users'] = 'Medlemmer';
$txt['admin_newsletters'] = 'Nyhedsbreve';
$txt['include_these'] = 'Inkluder disse brugere';
$txt['exclude_these'] = 'Ekskluder disse brugere';
$txt['admin_newsletters_select_groups'] = 'Grupper der skal inkluderes';
$txt['admin_newsletters_exclude_groups'] = 'Grupper der skal ekskluderes';
$txt['admin_edit_news'] = 'Nyheder';
$txt['admin_groups'] = 'Medlemsgrupper';
$txt['admin_members'] = 'Administrer medlemmer';
$txt['admin_members_list'] = 'Herunder er en liste over de medlemmer der aktuelt er registreret i dit forum.';
$txt['admin_next'] = 'Næste';
$txt['admin_censored_words'] = 'Censurerede ord';
$txt['admin_censored_where'] = 'Skriv ordet der skal censureres i den venstre boks, og order det skal erstattes med i den højre boks. Vælg så om du vil kontrollere hele ordet og om det skal checke store/små bokstaver. Når du er færdig med hvert ord, klik Gem. Flere poster kan laves af gangen før der gemmes ved at klikke på  \'Tilføj et nyt ord\' knappen.';
$txt['admin_censored_desc'] = 'Grundet den offentlige tilgængelighed af fora, kan der være ord som du ikke ønsker bliver benyttet af brugere af dit forum. Du kan indtaste ord herunder, som du ønsker skal censureres når det bliver brugt af en bruger.<br />Ryd en boks for at ucensurer det ord.';
$txt['admin_reserved_names'] = 'Reserverede navne';
$txt['admin_template_edit'] = 'Rediger din forumskabelon';
$txt['admin_modifications'] = 'Add-on Indstillinger';
$txt['admin_security_moderation'] = 'Sikkerhed og moderation';
$txt['admin_server_settings'] = 'Serverindstillinger';
$txt['admin_reserved_set'] = 'Indstil reserverede navne';
$txt['admin_reserved_line'] = 'Ét reserveret ord per linie.';
$txt['admin_basic_settings'] = 'Denne side tillader dig at ændre de grundlæggende indstillinger i dit forum. Vær meget forsigtig med disse indstillinger, da de kan gøre forummet ubrugeligt.';
$txt['admin_maintain'] = 'Aktiver vedligeholdelsestilstand?';
$txt['admin_title'] = 'Forumtitel';
$txt['admin_url'] = 'Forummets webadresse';
$txt['cookie_name'] = 'Cookienavn';
$txt['admin_webmaster_email'] = 'Webmaster email adresse';
$txt['boarddir'] = 'ElkArte Mappe';
$txt['sourcesdir'] = 'Sources mappe';
$txt['cachedir'] = 'Cache mappe';
$txt['admin_news'] = 'Aktiver nyheder';
$txt['admin_guest_post'] = 'Aktiver gæsteindlæg';
$txt['admin_manage_members'] = 'Medlemmer';
$txt['admin_main'] = 'Hovedmenu';
$txt['admin_config'] = 'Konfiguration';
$txt['admin_version_check'] = 'Detaljeret versionscheck';
$txt['admin_elkfile'] = 'ElkArte Fil';
$txt['admin_elkpackage'] = 'ElkArte Pakke';
$txt['admin_logoff'] = 'Afslut Admin Session';
$txt['admin_maintenance'] = 'Vedligeholder';
$txt['admin_image_text'] = 'Vis knapper som ikoner i stedet for tekst';
$txt['admin_credits'] = 'Credits';
$txt['admin_agreement'] = 'Vis og forlang aftalebrev når der registreres';
$txt['admin_checkbox_agreement'] = 'Vis et afkrydsningsfelt for samtykke i registreringsform istedet for en hel side';
$txt['admin_checkbox_accept_agreement'] = 'Tving alle brugere til at acceptere denne nye version af aftalen ved deres næste forum besøg';
$txt['admin_agreement_default'] = 'Standard';
$txt['admin_agreement_select_language'] = 'Rediger sprog';
$txt['admin_agreement_select_language_change'] = 'Skift';

$txt['admin_privacypol'] = 'Vis og kræv accept af privatlivsaftale ved registrering';
$txt['admin_checkbox_accept_privacypol'] = 'Tving alle brugere til at acceptere denne nye version af privatlivsaftale ved deres næste forum besøg';

$txt['admin_delete_members'] = 'Slet valgte medlemmer';
$txt['admin_change_primary_membergroup'] = 'Ændre primær bruger gruppe';
$txt['admin_change_secondary_membergroup'] = 'Ændre/tilføj alternativ medlemsgruppe';
$txt['confirm_remove_membergroup'] = 'Ved at vælge dette bliver alle medlemsgrupper slettet! Er du sikker?';
$txt['confirm_change_primary_membergroup'] = 'Er du sikker på at du vil ændre den primære gruppe for de valgte brugere?';
$txt['confirm_change_secondary_membergroup'] = 'Er du sikker på at du vil ændre den alternative gruppe for de valgte brugere?';
$txt['admin_ban_usernames'] = 'Forbyd efter brugernavne';
$txt['admin_ban_useremails'] = 'Forbyd efter email adresser';
$txt['admin_ban_userips'] = 'Forbyd efter IP adresser';
$txt['admin_ban_usernames_and_emails'] = 'Forbyd efter brugernavne og email adresser';
$txt['admin_ban_name'] = 'Massebruger forbud';
$txt['remove_groups'] = 'Fjern alle grupper';

$txt['admin_repair'] = 'Reparer alle boards og emner';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Placer venligst en nyhed pr. boks. BBC tags, såsom <span>[b]</span>, <span>[i]</span> og <span>[u]</span> er tilladt i dine nyheder, ligeledes er smileys. Ryd en nyheds tekst boks for at fjerne den.';
$txt['administrators'] = 'Forumadministratorer';
$txt['admin_reserved_desc'] = 'Reserverede navne vil afholde brugere fra at registrere visse brugernavne eller bruge disse ord i deres skærmnavn. Vælg de indstillinger du ønsker at bruge nedenunder før du gemmer.';
$txt['admin_activation_email'] = 'Send aktiverings-e-mail til nye medlemmer ved registrering';
$txt['admin_match_whole'] = 'Match kun hele navne. Hvis denne ikke er markeret, søges der også i dele af navne.';
$txt['admin_match_case'] = 'Match store og små bogstaver. Hvis denne ikke er markeret, tages der ikke højde for dette.';
$txt['admin_check_user'] = 'Check skærmnavn.';
$txt['admin_check_display'] = 'Kontroller skærmnavn.';
$txt['admin_newsletter_send'] = 'Du kan sende email til alle fra denne side. Email adresser fra alle valgte medlemsgrupper skulle være synlige herunder, men du kan fjerne eller tilføje enhver email adresse du ønsker. Vær sikker på hver adresse er opdelt på denne måde:  \'adresse1;adresse2\'.';
$txt['admin_fader_delay'] = 'Forsinkelse for fade ud mellem emner i nyhedsfaderen';
$txt['zero_for_no_limit'] = '(0 for ubegrænset)';
$txt['zero_to_disable'] = '(0 for at deaktivere)';

$txt['admin_backup_fail'] = 'Fejl ved backup af Settings.php - vær sikker på at Settings_bak.php eksisterer og er skrivbar.';
$txt['modSettings_info'] = 'Indstillinger for generale funktioner, Karma, Signaturer, Likes og flere som styrer hvordan dette forum opererer.';
$txt['database_server'] = 'Database server';
$txt['database_user'] = 'Database bruger';
$txt['database_password'] = 'Database-kodeord';
$txt['database_name'] = 'Databasenavn';
$txt['registration_agreement'] = 'Registrationsaftale';
$txt['registration_agreement_desc'] = 'Denne aftale vises når brugere registrerer en konto i dette forum, og skal godkendes, før de kan fortsætte registreringen.';
$txt['privacy_policy'] = 'Privatlivsaftale';
$txt['privacy_policy_desc'] = 'Denne privatlivsaftale vises når brugere registrerer en konto i dette forum, og kan gøres krævet, før de kan fortsætte registreringen.';
$txt['database_prefix'] = 'Database tabelprefix';
$txt['errors_list'] = 'Visning af forum fejl';
$txt['errors_found'] = 'Følgende fejl genererer problemer dit forum';
$txt['errors_fix'] = 'Vil du forsøge at rette disse fejl?';
$txt['errors_do_recount'] = 'Alle fejl er blevet rettet - et gendannelsesområde er blevet oprettet! Klik venligst på knappen herunder for at genoptælle vigtige statistikker.';
$txt['errors_recount_now'] = 'Genoptæl statistikker';
$txt['errors_fixing'] = 'Retter forum fejl';
$txt['errors_fixed'] = 'Alle fejl er blevet rettet. Kontroller alle kategorier, boards, eller emner som blev oprettet for at beslutte hvad der skal ske med dem.';
$txt['attachments_avatars'] = 'Vedhæftninger og avatarer';
$txt['attachments_desc'] = 'Herfra kan du administrere vedhæftede filer i dit system. Du kan slette vedhæftninger fra dit system, efter størrelse og dato. Statistikker over vedhæftninger vises også herunder.';
$txt['attachment_stats'] = 'Statistik over vedhæftede filer';
$txt['attachment_integrity_check'] = 'Gyldighedscheck af vedhæftninger';
$txt['attachment_integrity_check_desc'] = 'Denne funktion vil checke integriteten samt størrelsen på vedhæftninger der er listet i databasen og, hvis nødvendigt, rette fejlene der bliver fundet.';
$txt['attachment_check_now'] = 'Kør kontrollen nu';
$txt['attachment_pruning'] = 'Oprydning i vedhæftninger';
$txt['attachment_pruning_message'] = 'Meddelelse der skal føjes til indlægget';
$txt['attachment_pruning_warning'] = 'Er du sikker på du ønsker at slette disse vedhæftninger?\\nDette kan ikke fortrydes!';

$txt['attachment_total'] = 'Totalt antal vedhæftninger';
$txt['attachmentdir_size'] = 'Samlet størrelse på mapper for vedhæftninger';
$txt['attachmentdir_size_current'] = 'Samlet størrelse på den aktuelle mappe til vedhæftninger';
$txt['attachmentdir_files_current'] = 'Antal filer i den aktuelle mappe til vedhæftninger';
$txt['attachment_space'] = 'Samlet tilgængelig plads';
$txt['attachment_files'] = 'Antal filer tilbage';

$txt['attachment_options'] = 'Indstillinger for vedhæftede Filer';
$txt['attachment_log'] = 'Log over vedhæftninger';
$txt['attachment_remove_old'] = 'Fjern vedhæftninger ældre end %1$s dage';
$txt['attachment_remove_size'] = 'Fjern vedhæftninger større end %1$s KiB';
$txt['attachment_name'] = 'Navn på vedhæftning';
$txt['attachment_file_size'] = 'Fil-størrelse';
$txt['attachmentdir_size_not_set'] = 'Der er i øjeblikket ikke sat nogen maksimum størrelse på mappen';
$txt['attachmentdir_files_not_set'] = 'Ingen fil begrænsning sat for mappen';
$txt['attachment_delete_admin'] = '[vedhæftning slettet af admin]';
$txt['live'] = 'Seneste Software Opdateringer';
$txt['remove_all'] = 'Ryd Log';
$txt['agreement_not_writable'] = 'Advarsel - agreement.txt er ikke skrivbar. Enhver rettelse du laver vil IKKE blive gemt.';
$txt['agreement_backup_not_writable'] = 'Advarsel - backup mappen i forum_root/packages/backup kan ikke oprettes.';
$txt['privacypol_not_writable'] = 'Advarsen - privacypolicy.txt er ikke skrivbar. Enhver rettelse du laver vil IKKE blive gemt.';
$txt['privacypol_backup_not_writable'] = 'Advarsel - backup mappen i forum_root/packages/backup kan ikke oprettes.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(flere detaljer)';

$txt['lfyi'] = 'Du er ikke i stand til at forbinde til ElkArte\'s seneste nyhedsfil.';

$txt['manage_calendar'] = 'Kalender';
$txt['manage_search'] = 'Søg';
$txt['viewmembers_online'] = 'Sidst online';

$txt['smileys_manage'] = 'Smileys og indlægsikoner';
$txt['smileys_manage_info'] = 'Installer nye smiley sæt, tilføj smileys til eksisterende sæt eller administrer dine indlægsikoner.';

$txt['bbc_manage'] = 'Bulletin Board Koder (BBC)';
$txt['bbc_manage_info'] = 'Tilføj, fjern, og rediger bulletin board koder.';

$txt['package_info'] = 'Installer, download og upload Modifikations pakker; check Fil rettigheder og FTP indstillinger.';
$txt['theme_admin'] = 'Tema behandling';
$txt['theme_admin_info'] = 'Installer nye temaer, vælg temaer der er tilgængelige for dine brugere, og indstil eller nulstil temaindstillinger.';
$txt['registration_center'] = 'Registration';
$txt['member_center_info'] = 'Se medlemslisten, søg efter brugere, og håndter konto godkendelse og aktiveringer.';
$txt['viewmembers_online'] = 'Sidst online';

$txt['display_name'] = 'Skærmnavn';
$txt['email_address'] = 'E-mail-adresse';
$txt['ip_address'] = 'IP adresse';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'ukendt';
$txt['security_wrong'] = 'Administrations log ind forsøg!
Henvist fra: %1$s
Bruger agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Send i HTML format.  (med dette kan du indsætte normal HTML i e-mailen.)';
$txt['email_parsed_html'] = 'Tilføj &lt;br /&gt;\'er og &amp;nbsp;\'er til denne meddelelse.';
$txt['email_variables'] = 'I denne besked kan du bruge et par &quot;variabler&quot;.<a href="{help_emailmembers}" class="help"> Klik her for mere information</a>.';
$txt['email_force'] = 'Send dette til medlemmer, også selvom de har valgt ikke at modtage bekendtgørelser.';
$txt['email_as_pms'] = 'Send til ovenstående grupper som personlig besked.';
$txt['email_continue'] = 'Fortsæt';
$txt['email_done'] = 'Færdig.';
$txt['email_members_succeeded'] = 'Du har afsendt dit nyhedsbrev!';

$txt['ban_title'] = 'Liste Over bandlysninger';
$txt['ban_ip'] = 'IP bandlysning: (eks.. 192.168.12.213 eller 128.0.*.*) - en indtastning per linie';
$txt['ban_email'] = 'E-mail bandlysning: (eks. badguy@somewhere.com) - en indtastning per linie';
$txt['ban_username'] = 'Brugernavn bandlysning: (eks. l33tuser) - en indtastning per linie';

$txt['ban_errors_detected'] = 'Følgende fejl opstod under gemning eller redigering af ban eller trigger';
$txt['ban_description'] = 'Her kan du udelukke ballademagere enten efter IP, hostnavn, brugernavn eller email.';
$txt['ban_add_new'] = 'Tilføj ny ban';
$txt['ban_banned_entity'] = 'Bandlyst enhed';
$txt['ban_on_ip'] = 'Bandlys IP adresse (eks. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Bandlys hostnavn (eks. *.mil)';
$txt['ban_on_email'] = 'Bandlys e-mail-adresse (eks. *@badsite.com)';
$txt['ban_on_username'] = 'Ban efter brugernavn';
$txt['ban_notes'] = 'Bemærkninger';
$txt['ban_restriction'] = 'Begrænsning';
$txt['ban_full_ban'] = 'Fuld udelukkelse';
$txt['ban_partial_ban'] = 'Delvis udelukkelse';
$txt['ban_cannot_post'] = 'Kan ikke poste';
$txt['ban_cannot_register'] = 'Kan ikke registrere';
$txt['ban_cannot_login'] = 'Kan ikke logge ind';
$txt['ban_add'] = 'Tilføj';
$txt['ban_edit_list'] = 'Liste Over bandlysninger';
$txt['ban_type'] = 'Bandlysningstype';
$txt['ban_days'] = 'dag(e)';
$txt['ban_will_expire_within'] = 'Bandlysning vil udløbe efter';
$txt['ban_added'] = 'Tilføjet';
$txt['ban_expires'] = 'Udløber';
$txt['ban_hits'] = 'Hits';
$txt['ban_actions'] = 'Handlinger';
$txt['ban_expiration'] = 'Udløber';
$txt['ban_reason_desc'] = 'Årsagen til udelukkelsen, det bandlyste medlem vil se.';
$txt['ban_notes_desc'] = 'Notater der kan assistere andre gruppemedlemmer.';
$txt['ban_remove_selected'] = 'Fjern valgte';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Er du sikker på at du vil fjerne de valgte bandlysninger?';
$txt['ban_modify'] = 'Rediger';
$txt['ban_name'] = 'Navn på bandlysning';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Rediger bandlysning';
$txt['ban_add_notes'] = '<strong>Bemærk</strong>: Efter at have oprettet ovenstående bandlysning, kan du tilføje flere handlinger der trigger denne, såsom IP-adresser, hostnavne og e-mail-adresser.';
$txt['ban_expired'] = 'Udløbet / deaktiveret';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Der blev ikke valgt nogen restriktioner.';

$txt['ban_triggers'] = 'Triggere';
$txt['ban_add_trigger'] = 'Tilføj en bandlysnings-trigger';
$txt['ban_add_trigger_submit'] = 'Tilføj';
$txt['ban_edit_trigger'] = 'Rediger';
$txt['ban_edit_trigger_title'] = 'Rediger bandlysningstrigger';
$txt['ban_edit_trigger_submit'] = 'Rediger';
$txt['ban_remove_selected_triggers'] = 'Fjern valgte bandlysningstriggere';
$txt['ban_no_entries'] = 'Der er i øjeblikket ingen aktive bandlysninger.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Er du sikker på du vil fjerne de valgte bandlysningstriggere?';
$txt['ban_trigger_browse'] = 'Gennemse bandlysningstriggere';
$txt['ban_trigger_browse_description'] = 'Denne side viser alle udelukkelser gupperet efter IP adresse, hostname, email adresse eller brugernavn.';

$txt['ban_log'] = 'Log over bandlysninger';
$txt['ban_log_description'] = 'Loggen over bandlysninger viser forsøg fra udelukkede medlemmer på at komme ind i forummet (gælder kun typerne \'fuld udelukkelse\' og \'kan ikke registrere\' udelukkelser).';
$txt['ban_log_no_entries'] = 'Ingen forekomster af logs over bandlysninger.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'E-mail-adresse';
$txt['ban_log_member'] = 'Medlem';
$txt['ban_log_date'] = 'Dato';
$txt['ban_log_remove_all'] = 'Ryd Log';
$txt['ban_log_remove_all_confirm'] = 'Er du sikker på at du vil slette alle logs over bandlysninger?';
$txt['ban_log_remove_selected'] = 'Fjern valgte';
$txt['ban_log_remove_selected_confirm'] = 'Er du sikker på at du vil slette alle logs over bandlysninger?';
$txt['ban_no_triggers'] = 'Der er i øjeblikket ingen bandlysningstriggere.';

$txt['settings_not_writable'] = 'Indstillingerne kan ikke ændres, da Settings.php ikke er skrivbar.';

$txt['maintain_title'] = 'Forumvedligeholdelse';
$txt['maintain_info'] = 'Basale forum backups, Database fejl checkning, Rydning af Cache, Integrerede Hooks og mere.';
$txt['maintain_sub_database'] = 'Database';
$txt['maintain_sub_routine'] = 'Rutine';
$txt['maintain_sub_members'] = 'Medlemmer';
$txt['maintain_sub_topics'] = 'Emner';
$txt['maintain_sub_attachments'] = 'Vedhæftninger';
$txt['maintain_done'] = 'Vedligeholdelsesopgaven \'%1$s\' blev udført korrekt. ';
$txt['maintain_fail'] = 'Vedligeholdelsesopgaven \'%1$s\' fejlede.';
$txt['maintain_no_errors'] = 'Tilykke, der blev ikke fundet nogen fejl. Tak fordi du checkede.';

$txt['maintain_tasks'] = 'Planlagte opgaver';
$txt['maintain_tasks_desc'] = 'Administrer alle planlagte opgaver.';

$txt['scheduled_log'] = 'Opgavelog';
$txt['scheduled_log_desc'] = 'Vis log over de opgaver der blev kørt.';
$txt['admin_log'] = 'Administrationslog';
$txt['admin_log_desc'] = 'Viser administrative opgaver der er blevet foretaget af administratorer i dit forum.';
$txt['moderation_log'] = 'Moderationslog';
$txt['moderation_log_desc'] = 'Vis moderationsaktiviteter der er blevet udført af moderatorer i dit forum.';
$txt['badbehavior_log'] = 'Bad Behavior Log';
$txt['badbehavior_log_desc'] = 'Viser forespørgsler der blev blokeret eller markeret som mistænkelige af bad behavior. Hvis omfattende logging er slået til, vil alle HTTP forespørgsler blive vist.';
$txt['spider_log_desc'] = 'Gennemse indstillingerne relateret til søgemaskinerobotter i dit forum.';
$txt['pruning_log_desc'] = 'Brug disse værtøjer til at rydde op i de forskellige logs.';

$txt['mailqueue_title'] = 'Mail';

$txt['db_error_send'] = 'Send e-mails ved MySQL forbindelsesfejl';
$txt['db_persist'] = 'Brug en permanent forbindelse';
$txt['ssi_db_user'] = 'Database brugernavn der skal benyttes i SSI tilstand';
$txt['ssi_db_passwd'] = 'Database kodeordet der skal benyttes i SSI mode';

$txt['default_language'] = 'Standard forumsprog';

$txt['maintenance_subject'] = 'Overskrift der skal vises';
$txt['maintenance_message'] = 'Meddelelse der skal vises';

$txt['errlog_desc'] = 'Fejlloggen sporer enhver fejl der er opstået i dit forum. For at slette en fejl fra databasen, skal du markere checkboksen, og klikke på knappen %1$s i bunden af siden.';
$txt['errlog_no_entries'] = 'Der er i øjeblikket ikke nogen fejl i loggen';

$txt['theme_settings'] = 'Temaindstillinger';
$txt['theme_edit_settings'] = 'Rediger indstillinger for dette tema';
$txt['theme_current_settings'] = 'Aktuelt tema';

$txt['dvc_your'] = 'Din version';
$txt['dvc_current'] = 'Nuværende version';
$txt['dvc_sources'] = 'Sources';
$txt['dvc_admin'] = 'Admin';
$txt['dvc_controllers'] = 'Controllers';
$txt['dvc_database'] = 'Database';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Standard skabeloner';
$txt['dvc_templates'] = 'Nuværende skabeloner';
$txt['dvc_languages'] = 'Sprogfiler';

$txt['smileys_default_set_for_theme'] = 'Vælg standard smileysæt for dette tema:';
$txt['smileys_no_default'] = 'Brug standard smileysæt';

$txt['censor_test'] = 'Test cencurerede ord';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Tag ikke højde for store og små bogstaver når der cencureres.';
$txt['censor_whole_words'] = 'Kontroller kun hele ord.';
$txt['censor_allow'] = 'Tillad brugere at deaktivere censur.';

$txt['admin_confirm_password'] = '(bekræft kodeord)';
$txt['admin_incorrect_password'] = 'Ugyldigt kodeord';

$txt['date_format'] = '(YYYY-MM-DD)';
$txt['undefined_gender'] = 'Udefineret';
$txt['age'] = 'Brugerens alder';
$txt['activation_status'] = 'Status for aktivering';
$txt['activated'] = 'Aktiveret';
$txt['not_activated'] = 'Ikke aktiveret';
$txt['is_banned'] = 'Udelukket';
$txt['primary'] = 'Primær';
$txt['additional'] = 'Yderligere';
$txt['wild_cards_allowed'] = 'joker karaktererer * og ? er tilladt';
$txt['member_part_of_these_membergroups'] = 'Bruger er en del af disse brugergrupper';
$txt['membergroups'] = 'Medlemsgrupper';
$txt['confirm_delete_members'] = 'Er du du sikker på du vil slette de valgte medlemmer?';

$txt['support_credits_title'] = 'Support &amp; Credits';
$txt['support_credits_info'] = 'Support links til de mest almindelige problemer, de mest relevante forum version informationer du vil blive spurgt om når du søger hjælp og en liste over bidragsydere til ElkArte projektet.';
$txt['support_title'] = 'Support Information';
$txt['support_versions_current'] = 'Aktuel version';
$txt['support_versions_forum'] = 'Denne version';
$txt['support_versions_db'] = '%1$s version';
$txt['support_versions_server'] = 'Server version';
$txt['support_versions_gd'] = 'GD version';
$txt['support_versions_imagick'] = 'Imagick version';
$txt['support_versions'] = 'Versions-information';
$txt['support_resources'] = 'Support resourcer';
$txt['support_resources_p1'] = 'Vores <a href="%1$s" target="_blank" class="new_win">Dolumentations Wiki</a> yder den primære dokumentation for ElkArte. ElkArte Online Manual indeholder mange dokumenter til at hjælpe med at svare på support spørgsmål og forklare om <a href="%2$s" target="_blank" class="new_win">Funktioner</a>, <a href="%3$s" target="_blank" class="new_win">Indstillinger</a>, <a href="%4$s" target="_blank" class="new_win">Temaer</a>, <a href="%5$s" target="_blank" class="new_win">Pakker</a>, o.s.v. Manualen dokumenterer hvert område af ElkArte grundigt, og burde hurtigt besvare de fleste spørgsmål.';
$txt['support_resources_p2'] = 'Hvis du ikke kan finde svar på dine spørgsmål Dokumentations Wiki, kan du søge i vores <a href="%1$s" target="_blank" class="new_win">Support Community</a> eller spørge om assistance i vores support boards. ElkArte Support Community kan anvendes til at spørge om <a href="%2$s" target="_blank" class="new_win">support</a>, <a href="%3$s" target="_blank" class="new_win">specialløsninger</a>, og mange andre ting, såsom at diskutere ElkArte, finde en host, ogsamt diskutere administrative spørgsmål med andre forum administratorer..';

$txt['latest_updates'] = 'Seneste bemærkelsesværdige opdateringer';
$txt['new_in_1_0_2'] = 'Den største ændring i ElkArte 1.0.2 er avatar tilladelsesstyring. På nuværende tidspunkt er hver metode for indstilling af avatar tilladelsesstyret, krævende aktivering/deaktivering af hver metode for hver gruppe. Med 1.0.2 kan avatars simpelt aktiveres/deaktiveres efter brugergruppe, dette gør det muligt for de tilgængelige grupper at tilføje en avatar (til alle mulige metoder).<br />
Den eneste tilladelse tilgængelig er en general en for at give brugere muligheden for at ændre deres avatar eller ej. Ydermere er der kun en indstilling for maksimum højde og bredde for avatars, disse værdier gælder for alle avatar metoder.<br /><br />
På grund af karakteren af disse ændringer, var det ikke muligt at migrere nuværende indstillinger til det nye format, af den grund opfordrer vi dig til at besøge <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Indstillinger</a> siden og indstille hvilke indstillinger du foretrækker.';

$txt['edit_permissions_info'] = 'Brug tilladelsesindstillinger til at administrere globale og board specifikke funktioner samt hvilke handlinger gæster, brugere og moderatører kan udføre.';
$txt['membergroups_members'] = 'Aktive medlemmer';
$txt['membergroups_guests'] = 'Gæster';
$txt['membergroups_add_group'] = 'Tilføj gruppe';
$txt['membergroups_permissions'] = 'Tilladelser';

$txt['permitgroups_restrict'] = 'Begrænset';
$txt['permitgroups_standard'] = 'Standard';
$txt['permitgroups_moderator'] = 'Moderator';
$txt['permitgroups_maintenance'] = 'Vedligeholder';

$txt['confirm_delete_attachments'] = 'Er du sikker på at du vil slette de valgte vedhæftninger?';
$txt['attachment_manager_browse_files'] = 'Gennemse filer';
$txt['attachment_manager_repair'] = 'Vedligeholder';
$txt['attachment_manager_avatars'] = 'Avatarer';
$txt['attachment_manager_attachments'] = 'Vedhæftninger';
$txt['attachment_manager_thumbs'] = 'miniaturebilleder';
$txt['attachment_manager_last_active'] = 'Senest Aktiv';
$txt['attachment_manager_member'] = 'Medlem';
$txt['attachment_manager_avatars_older'] = 'Fjern avatars fra brugere der ikke har været aktive i mere end %1$s dage';
$txt['attachment_manager_total_avatars'] = 'Total antal avatars';

$txt['attachment_manager_avatars_no_entries'] = 'Der forefindes i øjeblikket ingen avatarer.';
$txt['attachment_manager_attachments_no_entries'] = 'Der forefindes i øjeblikket ingen vedhæftninger.';
$txt['attachment_manager_thumbs_no_entries'] = 'Der forefindes i øjeblikket ingen miniaturebilleder.';

$txt['attachment_manager_settings'] = 'Indstillinger for vedhæftninger';
$txt['attachment_manager_avatar_settings'] = 'Avatar-indstillinger';
$txt['attachment_manager_browse'] = 'Gennemse filer';
$txt['attachment_manager_maintenance'] = 'Vedligeholdelse af Filer';
$txt['attachmentEnable'] = 'Tilstand for Vedhæftninger';
$txt['attachmentEnable_deactivate'] = 'Deaktiver vedhæftninger';
$txt['attachmentEnable_enable_all'] = 'Tillad alle vedhæftninger';
$txt['attachmentEnable_disable_new'] = 'Deaktiver nye vedhæftninger';
$txt['attachmentCheckExtensions'] = 'Kontroller filtype for vedhæftninger';
$txt['attachmentExtensions'] = 'Tilladte vedhæftede filtyper';
$txt['attachmentRecodeLineEndings'] = 'Omkod linie endelser for tekstfiler i vedhæftninger';
$txt['attachmentShowImages'] = 'Vis vedhæftede filer som billeder under indlæg';
$txt['attachmentUploadDir'] = 'Mappe til vedhæftninger';
$txt['attachmentUploadDir_multiple_configure'] = 'Administer mapper for vedhæftninger';
$txt['attachmentDirSizeLimit'] = 'Maksimal størrelse på mapper til vedhæftninger';
$txt['attachmentPostLimit'] = 'Maksimal størrelse på vedhæftninger pr. indlæg';
$txt['attachmentSizeLimit'] = 'Maksimal størrelse pr. vedhæftning';
$txt['attachmentNumPerPostLimit'] = 'Maksimal antal af vedhæftninger pr. indlæg';
$txt['attachment_img_enc_warning'] = 'Hverken GD modul eller ImageMagick er installeret. Billede omkodning er ikke muligt.';
$txt['attachment_postsize_warning'] = 'Den nuværende php.ini indstililng for \'post_max_size\' understøtter muligvis ikke dette.';
$txt['attachment_filesize_warning'] = 'Den nuævrende php.ini indstilling for \'upload_max_filesize\' understøtter muligvis ikke dette.';
$txt['attachment_image_reencode'] = 'Re-enkoder potentielt skadelige billedvedhæftninger';
$txt['attachment_image_reencode_note'] = '(kræver GD modul eller ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Det gennemgribende sikkerhedscheck kan resultere i et stort antal af afviste filer.';
$txt['attachment_image_paranoid'] = 'Udfører gennemgribende sikkerhedscheck på uploadede billedvedhæftninger';
$txt['attachment_autorotate'] = 'Find og reparer ukorrekte roterende billeder';
$txt['attachment_autorotate_na'] = '(Ikke tilgængelig på dette system)';
$txt['attachmentThumbnails'] = 'Reducer billeder når de vises i indlæggene';
$txt['attachment_thumb_png'] = 'Gem miniaturebilleder som PNG';
$txt['attachment_thumb_memory'] = 'Tilpassende thumbnail hukommelse';
$txt['attachment_thumb_memory_note2'] = 'Hvis systemet ikke kan få hukommelsen vil thumbnail ikke blive genereret.';
$txt['attachment_thumb_memory_note1'] = 'Afkryds ikke dette felt for altid at forsøge at oprette en thumbnail';
$txt['attachmentThumbWidth'] = 'Maksimal bredde på miniaturebilleder';
$txt['attachmentThumbHeight'] = 'Maksimal højde på miniaturebilleder';
$txt['attachment_thumbnail_settings'] = 'Thumbnail indstillinger';
$txt['attachment_security_settings'] = 'Sikkerhedsindstillinger for vedhæftninger';

$txt['attachment_inline_title'] = 'In line vedhæftnings indstillinger';
$txt['attachment_inline_enabled'] = 'Aktiver visning af in line vedhæftninger';
$txt['attachment_inline_basicmenu'] = 'Vis kun basis menu';
$txt['attachment_inline_quotes'] = 'Afkryds for at aktivere visning af in line vedhæftninger i citater';

$txt['attach_dir_does_not_exist'] = 'Eksisterer ikke';
$txt['attach_dir_not_writable'] = 'Ikke-skrivbar';
$txt['attach_dir_files_missing'] = 'Manglende filer (<a href="{repair_url}">Reparer</a>)';
$txt['attach_dir_unused'] = 'Ikke brugt';
$txt['attach_dir_empty'] = 'Tom';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Basismappe';

$txt['attach_dir_desc'] = 'Opret nye mapper eller foretag ændringer af nuværende mappe herunder. Mapper kan omdøbes så længe at de ikke indeholder en undermappe. Hvis den nye mappe skal oprettes inde i forum mappe strukturen, skal du blot skrive mappenavnet. For at fjerne en mappe, ryd mappe input feltet. Mapper kan ikke slettes, hvis de indeholder filer eller undermapper (vist i parentes ved siden af fil tæller).';
$txt['attach_dir_base_desc'] = 'Du kan bruge området herunder til at ændre den nuværende basismappe eller oprette en ny. Nye basismapper bliver også tilføjet til mappe listen over vedhæftninger. Du kan også angive en eksisterende mappe som basismappe.';
$txt['attach_dir_save_problem'] = 'Oops, ser ud til at der er et problem.';
$txt['attachments_no_create'] = 'Kunne ikke oprette en ny vedhæftningsmappe. Prøv venligst at gøre dette med en FTP klient eller fil manager for dit site.';
$txt['attachments_no_write'] = 'Denne mappe er blevet oprettet men er ikke skrivbar. Prøv venligst at gøre dette med en FTP klient eller fil manager for dit site.';
$txt['attach_dir_reserved'] = 'Kunne ikke oprette. Denne mappe er en systemmappe og kan ikke bruges til vedhæftninger.';
$txt['attach_dir_duplicate_msg'] = 'Kunne ikke oprette. Denne mappe eksisterer allerede.';
$txt['attach_dir_exists_msg'] = 'Kunne ikke flytte. En mappe eksisterer allerede på den sti.';
$txt['attach_dir_base_dupe_msg'] = 'Kunne ikke oprette. Denne basismappe er allerede oprettet.';
$txt['attach_dir_base_no_create'] = 'Kunne ikke oprette. Verificer input af stien eller opret denne mappe med en FTP klient eller fil manager for dit site og prøv igen.';
$txt['attach_dir_no_rename'] = 'Kunne ikke flytte eller omdøbe. Verificer at stien er korrekt eller at mappen ikke indeholder nogen undermapper.';
$txt['attach_dir_no_delete'] = 'Er ikke tom og kan ikke slettes. Prøv venligst at gøre dette med en FTP klient eller fil manager for dit site.';
$txt['attach_dir_no_remove'] = 'Indeholder stadig filer eller er en basismappe og kan ikke slettes.';
$txt['attach_dir_is_current'] = 'Kan ikke fjerne når den stadig er valgt som nuværende mappe.';
$txt['attach_dir_is_current_bd'] = 'Kan ikke fjerne når den stadig er valgt som nuværende basismappe.';
$txt['attach_last_dir'] = 'Seneste aktive vedhæftingsmappe';
$txt['attach_current_dir'] = 'Nuværende vedhæftningsmappe';
$txt['attach_current'] = 'Nuværende';
$txt['attach_path_manage'] = 'Administrer vedhæftnings stier';
$txt['attach_directories'] = 'Mapper for vedhæftninger';
$txt['attach_paths'] = 'Vedhæftningsmappe stier';
$txt['attach_path'] = 'Sti';
$txt['attach_current_size'] = 'Størrelse (KiB)';
$txt['attach_num_files'] = 'Filer';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Tilføj sti';
$txt['attach_path_current_bad'] = 'Den aktuelle sti til vedhæftninger er ugyldig.';
$txt['attachmentDirFileLimit'] = 'Maksimum antal af filer pr. mappe';

$txt['attach_base_paths'] = 'Basismappe stier';
$txt['attach_num_dirs'] = 'Mapper';
$txt['max_image_width'] = 'Maksimum bredde af indrykket eller vedhæftede billeder';
$txt['max_image_height'] = 'Maksimum højde af indrykkede eller vedhæftede billeder';

$txt['automanage_attachments'] = 'Vælg en metode for administrering af vedhæftningsmapper';
$txt['attachments_normal'] = '(Manuel) ElkArte standard opførsel';
$txt['attachments_auto_years'] = '(Auto) Indel efter år';
$txt['attachments_auto_months'] = '(Auto) Indel efter år og måneder';
$txt['attachments_auto_days'] = '(Auto) Indel efter år, måneder og dage';
$txt['attachments_auto_16'] = '(Auto) 16 tilfældige mapper';
$txt['attachments_auto_16x16'] = '(Auto) 16 tilfældige mapper med 16 tilfældige undermapper';
$txt['attachments_auto_space'] = '(Auto) Når mappe størrelsesgrænsen er nået';

$txt['use_subdirectories_for_attachments'] = 'Opret nye mapper inde i en basismappe';
$txt['use_subdirectories_for_attachments_note'] = 'Ellers vil nye mapper blive oprettet inde i forum hovedmappen.';
$txt['basedirectory_for_attachments'] = 'Indstil en basismappe for vedhæftninger';
$txt['basedirectory_for_attachments_current'] = 'Nuværende basismappe';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Bemærk at mappen er forkert. <br />(<a href="{attach_repair_url}">Forsøg at rette</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">Det ser ud til der er et problem med denne mappe. <br />(<a href="{attach_repair_url}">Forsøg at rette</a>)</div>';

$txt['attachment_transfer'] = 'Overfør vedhæftninger';
$txt['attachment_transfer_desc'] = 'Overfør filer imellem mapper.';
$txt['attachment_transfer_select'] = 'Vælg mappe';
$txt['attachment_transfer_now'] = 'Overfør';
$txt['attachment_transfer_from'] = 'Overfør filer fra';
$txt['attachment_transfer_auto'] = 'Flyt dem automatisk efter størrelse eller antal';
$txt['attachment_transfer_auto_select'] = 'Vælg basismappe';
$txt['attachment_transfer_to'] = 'Eller flyt dem til angivet mappe.';
$txt['attachment_transfer_empty'] = 'Flyt alle filer fra kilde mappe.';
$txt['attachment_transfer_no_base'] = 'Ingen basismapper er tilgængelige.';
$txt['attachment_transfer_forum_root'] = 'Forum rodmappe.';
$txt['attachment_transfer_no_room'] = 'Mappe størrelse eller fil antal begrænsning er nået.';
$txt['attachment_transfer_no_find'] = 'Ingen filer til overførsel blev fundet.';
$txt['attachments_transfered'] = '%1$d filer blev overført til %2$s';
$txt['attachments_not_transfered'] = '%1$d filer blev ikke overført.';
$txt['attachment_transfer_no_dir'] = 'Enten kilde mappe eller en af de mulige mål er ikke valgt.';
$txt['attachment_transfer_same_dir'] = 'Du kan ikke vælge den samme mappe som både kilde og mål.';
$txt['attachment_transfer_progress'] = 'Vent venligt. Overførsel i gang.';

$txt['avatar_settings'] = 'Generelle avatar indstillinger';
$txt['avatar_default'] = 'Aktiver en standard avatar for alle brugere uden deres egen avatar';
$txt['avatar_directory'] = 'Mappe til avatarer';
$txt['avatar_url'] = 'Webadresse til Avatarer';
$txt['avatar_max_width'] = 'Maksimal bredde på avatars i pixels (px)';
$txt['avatar_max_height'] = 'Maksimal højde på avatars i pixels (px)';
$txt['avatar_action_too_large'] = 'Hvis avataren er for stor...';
$txt['option_refuse'] = 'Afvis den';
$txt['option_resize'] = 'Lad CSS ændre størrelsen';
$txt['option_download_and_resize'] = 'Download og ændre størrelsen (kræver GD modul eller ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Aktiver brugen af gravatars';
$txt['gravatar_rating'] = 'Gravatar bedømmelse';
$txt['avatar_download_png'] = 'Brug PNG til reducerede avatarer';
$txt['avatar_img_enc_warning'] = 'Hverken GD modul eller ImageMagick er installeret. Visse avatar funktioner er deaktiveret.';
$txt['avatar_external'] = 'Eksterne avatarer';
$txt['avatar_external_enabled'] = 'Aktiver brugen af eksterne (fjern/URL) avatars';
$txt['avatar_upload'] = 'Avatarer der kan uploades';
$txt['avatar_resize_options'] = 'Server lagringsmuligheder';
$txt['avatar_upload_enabled'] = 'Aktiver upload af avatars';
$txt['avatar_server_stored'] = 'Server-gemte avatarer';
$txt['avatar_stored_enabled'] = 'Aktiver brug af avatars gemt på server';
$txt['profile_set_avatar'] = 'Medlemsgrupper der har tilladelse til at vælge en avatar';
$txt['avatar_select_permission'] = 'Vælg tilladelser for hver gruppe';
$txt['avatar_download_external'] = 'Download avatar til defineret adresse';
$txt['custom_avatar_enabled'] = 'Upload avatarer til...';
$txt['option_attachment_dir'] = 'Mappe for vedhæftninger';
$txt['option_specified_dir'] = 'Angiv mappe...';
$txt['custom_avatar_dir'] = 'Upload mappe';
$txt['custom_avatar_dir_desc'] = 'Dette skal være en gyldig og skrivbar mappe, og ikke den samme som den server-gemte mappe.';
$txt['custom_avatar_url'] = 'Upload webadresse';
$txt['custom_avatar_check_empty'] = 'Den brugerdefinerede, angivne mappe du har specificeret, er enten tom eller ugyldig. Check venligst at disse indstillinger er korrekte.';
$txt['avatar_reencode'] = 'Re-enkoder potentielt skadelige avatarer';
$txt['avatar_reencode_note'] = '(kræver GD modul)';
$txt['avatar_paranoid_warning'] = 'Det gennemgribende sikkerhedscheck kan resultere i et stort antal afviste avatarer.';
$txt['avatar_paranoid'] = 'Udfører gennemgribende sikkerhedscheck på oploadede avatarer';

$txt['repair_attachments'] = 'Vedligehold vedhæftninger';
$txt['repair_attachments_complete'] = 'Vedligeholdelse færdig';
$txt['repair_attachments_complete_desc'] = 'Alle valgte fejl er nu blevet rettet';
$txt['repair_attachments_no_errors'] = 'Der blev ikke fundet nogen fejl.';
$txt['repair_attachments_error_desc'] = 'Følgende fejl blev fundet under vedligeholdelse. Klik i boksen ud for de fejl du ønsker at rette, og klik fortsæt.';
$txt['repair_attachments_continue'] = 'Fortsæt';
$txt['repair_attachments_cancel'] = 'Afbryd';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d miniaturebilleder mangler det primære billede';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d primære billeder er markeret som om de har et miniaturebillede, men har ikke et';
$txt['attach_repair_file_missing_on_disk'] = '%1$d vedhæftninger/avatarer er i brug, men eksisterer ikke længere på disken';
$txt['attach_repair_file_wrong_size'] = '%1$d vedhæftninger/avatarer angives til at have forkert filstørrelse';
$txt['attach_repair_file_size_of_zero'] = '%1$d vedhæftninger/avatarer har en filstørrelse på 0 Kb på disken. (Disse vil blive slettet)';
$txt['attach_repair_attachment_no_msg'] = '%1$d vedhæftninger er ikke længere associeret med et indlæg';
$txt['attach_repair_avatar_no_member'] = '%1$d avatarer er ikke længere associeret til et medlem';
$txt['attach_repair_wrong_folder'] = '%1$d vedhæftninger er i den forkerte mappe';
$txt['attach_repair_missing_extension'] = '%1$d vedhæftninger har ikke det rigtige filtypenavn og er muligvis i den forkerte mappe';
$txt['attach_repair_files_without_attachment'] = '%1$d filer har ikke en tilsvarende indtastning i databasen.(Disse vil blive slettet)';

$txt['news_title'] = 'Nyheder og nyhedsbreve';
$txt['news_settings_desc'] = 'Her kan du ændre indstillingerne og tilladelserne relateret til nyheder og nyhedsbreve.';
$txt['news_mailing_desc'] = 'Fra denne menu kan du sende beskeder til alle brugere som har registreret sig og angivet deres email adresse. Du kan redigere i distributionslisten, eller sende til alle. Dette er meget brugbart til vigtige opdateringer og nyhedsinformation.';
$txt['news_error_no_news'] = 'Ikke noget at forhåndsvise';
$txt['groups_edit_news'] = 'Grupper med tilladelse til at redigere i nyhedsemner';
$txt['groups_send_mail'] = 'Grupper med tilladelse til at udsende nyhedsbreve';
$txt['xmlnews_enable'] = 'Aktiver XML/RSS nyheder';
$txt['xmlnews_maxlen'] = 'Maksimum besked længde';
$txt['xmlnews_limit'] = 'XML/RSS begrænsning';
$txt['xmlnews_limit_note'] = 'Antal af elementer i en nyhedsfeed';
$txt['xmlnews_maxlen_note'] = '(0 for at deaktivere, dårlig ide.)';
$txt['editnews_clickadd'] = 'Tilføj nyt objekt';
$txt['editnews_remove_selected'] = 'Fjern valgte';
$txt['editnews_remove_confirm'] = 'Er du sikker på du vil slette de valgte nyhedsobjekter?';
$txt['censor_clickadd'] = 'Tilføj et nyt ord';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Logs';
$txt['generate_reports'] = 'Rapporter';

$txt['update_available'] = 'Opdatering tilgængelig';
$txt['update_message'] = 'Du bruger en gammel version af ElkArte, som indeholder fejl der siden er blevet rettet.
	Det er anbefalet at du <a href="#" id="update-link">opdaterer dit forum</a> til den nyeste version så hurtigt som muligt. Det tager kun et øjeblik!';

$txt['manageposts'] = 'Indlæg og emner';
$txt['manageposts_title'] = 'Administrer indlæg og emner';
$txt['manageposts_description'] = 'Her kan du administrere alle indstillinger relateret til emner og indlæg.';

$txt['manageposts_seconds'] = 'sekunder';
$txt['manageposts_minutes'] = 'minutter';
$txt['manageposts_characters'] = 'karakterer';
$txt['manageposts_days'] = 'dage';
$txt['manageposts_posts'] = 'indlæg';
$txt['manageposts_topics'] = 'emner';

$txt['pollMode'] = 'Aktiver afstemninger';

$txt['manageposts_settings'] = 'Indstillinger for forumindlæg';
$txt['manageposts_settings_description'] = 'Her kan du styre alt der vedrører forumindlæg.';

$txt['manageposts_bbc_settings'] = 'Bulletin Board Kode';
$txt['manageposts_bbc_settings_description'] = 'Bulletin Board kode (BBC) kan benyttes til at tilføje omskrivninger (markup) i forumbeskeder. For eksempel, for at fremhæve ordet \'hus\' med fed skrift, kan du skrive [b]hus[/b]. Alle Bulletin Board kodetags er omsluttet med firkantede paranteser (\'[\' og \']\').';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code indstillinger';

$txt['manageposts_topic_settings'] = 'Emneindstillinger';
$txt['manageposts_topic_settings_description'] = 'Her kan du ændre alle indstillinger der vedrører emner.';

$txt['managedrafts_settings'] = 'Kladde indstillinger';
$txt['managedrafts_settings_description'] = 'Her kan du ændre alle indstillinger vedrørende kladder.';
$txt['manage_drafts'] = 'Kladder';

$txt['mail_center'] = 'Center for Mailliste';
$txt['mm_emailerror'] = 'Mislykkede emails';
$txt['mm_emailfilters'] = 'Filtre';
$txt['mm_emailparsers'] = 'Analysering';
$txt['mm_emailtemplates'] = 'Skabeloner';
$txt['mm_emailsettings'] = 'Indstillinger';

$txt['removeNestedQuotes'] = 'Fjern tilknyttede citater når der citeres';
$txt['enableSpellChecking'] = 'Aktiver stavekontrol';
$txt['enableSpellChecking_warning'] = 'dette virker ikke på alle servere.';
$txt['enableSpellChecking_error'] = 'dette virker ikke på din server.';
$txt['enableVideoEmbeding'] = 'Aktiver auto-indlejring af video links.';
$txt['enableCodePrettify'] = 'Aktiver forskønning af kode tags';
$txt['max_messageLength'] = 'Maksimal størrelse per indlæg';
$txt['max_messageLength_zero'] = '0 for ubegrænset.';
$txt['convert_to_mediumtext'] = 'Din database er ikke sat op til at acceptere beskeder der er længere end 65535 karakterer. Brug <a href="%1$s">database vedligeholdelse</a> siden for at konvertere databasen og vend tilbage for at øge maksimum besked størrelse.';
$txt['topicSummaryPosts'] = 'Antal indlæg der skal i emneoversigten';
$txt['spamWaitTime'] = 'Tid mellem hvert nyt indlæg fra den samme IP adresse';
$txt['edit_wait_time'] = 'Ventetid for redigering';
$txt['edit_disable_time'] = 'Maksimal tid fra et emne oprettes, før redigering deaktiveres for emnet';
$txt['edit_disable_time_zero'] = '0 for at deaktivere';
$txt['preview_characters'] = 'Maksimum længde af seneste/første indlæg forhåndsvisning';
$txt['preview_characters_units'] = 'karakterer';
$txt['preview_characters_zero'] = '0 for at vise hele besked';
$txt['message_index_preview'] = 'Vis indlæg forhåndsvisning på beskedsindeks';
$txt['message_index_preview_off'] = 'Vis ikke forhåndsvisning';
$txt['message_index_preview_first'] = 'Vis tekst fra første indlæg';
$txt['message_index_preview_last'] = 'Vis tekst for seneste indlæg';

$txt['enableBBC'] = 'Aktiver bulletin board kode (BBC)';
$txt['enablePostHTML'] = 'Aktiver <em>grundlæggende</em> HTML i indlæg';
$txt['autoLinkUrls'] = 'Opret automatisk links i webadresser';
$txt['disabledBBC'] = 'Aktiverede BBC-tags';
$txt['bbcTagsToUse'] = 'Aktiverede BBC-tags';
$txt['bbcTagsToUse_select'] = 'Vælg de tags der skal være tilgængelige';
$txt['bbcTagsToUse_select_all'] = 'Vælg alle tags';

$txt['enableParticipation'] = 'Vis deltagerikoner';
$txt['enableFollowup'] = 'Aktiver opfølgninger';
$txt['enable_unwatch'] = 'Aktiver mulighed for at fjerne følgning af emner';
$txt['oldTopicDays'] = 'Tid før et emne bliver advaret som værende forældet ved svar';
$txt['oldTopicDays_zero'] = '0 for at deaktivere';
$txt['defaultMaxTopics'] = 'Antal emner pr side i emneindekset';
$txt['defaultMaxMessages'] = 'Antal indlæg per side på emnesider';
$txt['disable_print_topic'] = 'Deaktiver emne udprintning funktion';
$txt['hotTopicPosts'] = 'Antal indlæg, for et varmt emne';
$txt['hotTopicVeryPosts'] = 'Antal indlæg, for et meget varmt emne';
$txt['useLikesNotViews'] = 'Brug antal af likes istedet for indlæg for at definere varme emner';
$txt['enableAllMessages'] = 'Maksimale størrelse på emne for at &quot;Vis alle&quot; kan aktiveres';
$txt['enableAllMessages_zero'] = '0 for at deaktivere &quot;Vis alle&quot;';
$txt['disableCustomPerPage'] = 'Deaktiver brugerdefinerede ændring af antal emner/indlæg per side';
$txt['enablePreviousNext'] = 'Aktiver forrige/næste emne links';

$txt['not_done_title'] = 'Endnu ikke gjort';
$txt['not_done_reason'] = 'For at undgå overbelastning af din server, er processen midlertidigt blevet sat på pause. Denne vil automatisk fortsætte om et øjeblik.  Hvis den ikke gør, skal du klikke fortsæt herunder.';
$txt['not_done_continue'] = 'Fortsæt';

$txt['general_settings'] = 'Generelt';
$txt['database_paths_settings'] = 'Database og stier';
$txt['cookies_sessions_settings'] = 'Cookies og sessioner';
$txt['caching_settings'] = 'Caching';
$txt['loadavg'] = 'Serverbelastning';
$txt['loadavg_settings'] = 'Belastningsstyring';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Lokale Indstillinger';
$txt['phpinfo_defaultsettings'] = 'Standard Indstillinger';
$txt['phpinfo_itemsettings'] = 'Indstillinger';

$txt['language_configuration'] = 'Sprog';
$txt['language_description'] = 'Denne sektion gør dig i stand til at redigere sprog installeret på dit forum og downloade nye sprog fra ElkArte siden. Du kan også redigere sprogrelaterede indstillinger her.';
$txt['language_edit'] = 'Rediger sprog';
$txt['language_add'] = 'Tilføj sprog';
$txt['language_settings'] = 'Indstillinger';

$txt['advanced'] = 'Avanceret';
$txt['simple'] = 'Simpel';

$txt['admin_news_select_recipients'] = 'Vælg venligst hvem der skal modtage en kopi af nyhedsbrevet';
$txt['admin_news_select_group'] = 'Medlemsgrupper';
$txt['admin_news_select_group_desc'] = 'Vælg grupperne der skal modtage dette nyhedsbrev.';
$txt['admin_news_select_members'] = 'Medlemmer';
$txt['admin_news_select_members_desc'] = 'Yderligere brugere der skal modtage nyhedsbrevet.';
$txt['admin_news_select_excluded_members'] = 'Udelukkede medlemmer';
$txt['admin_news_select_excluded_members_desc'] = 'Brugere som ikke skal modtage nyhedsbrevet.';
$txt['admin_news_select_excluded_groups'] = 'Udelukkede grupper';
$txt['admin_news_select_excluded_groups_desc'] = 'Vælg grupper som absolut ikke skal modtage nyhedsbrevet.';
$txt['admin_news_select_email'] = 'E-mail-adresser';
$txt['admin_news_select_email_desc'] = 'En semikolon-separeret liste over email adresser som nyhedsbrevet skal sendes til. (eks. adresse1;adresse2)';
$txt['admin_news_select_override_notify'] = 'Tilsidesæt meddelelsesindstillinger ';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Du kan ikke sende en personlig hilsen til en e-mail-adresse. Hvis du forts&#230;tter vil alle e-mail-adresser blive ignoreret.\\n\\nEr du sikker på du vil g&#248;re dette?';

$txt['mailqueue_browse'] = 'Gennemse kø';
$txt['mailqueue_settings'] = 'Indstillinger';

$txt['admin_search'] = 'Hurtigsøgning';
$txt['admin_search_type_internal'] = 'Opgave/indstilling';
$txt['admin_search_type_member'] = 'Medlem';
$txt['admin_search_type_online'] = 'Online manual';
$txt['admin_search_go'] = 'Start';
$txt['admin_search_results'] = 'Søgeresultat';
$txt['admin_search_results_desc'] = 'Resultat af søgningen: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Søg igen';
$txt['admin_search_results_none'] = 'Ingen resultater fundet.';

$txt['admin_search_section_sections'] = 'Sektion';
$txt['admin_search_section_settings'] = 'Indstilling';

$txt['core_settings_title'] = 'Grundlæggende funktioner';
$txt['core_settings_desc'] = 'Denne side lader dig aktivere/deaktivere valgfrie forum funktioner.';
$txt['mods_cat_features'] = 'Generelt';
$txt['mods_cat_security_general'] = 'Generelt';
$txt['antispam_title'] = 'Anti-spam';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Diverse';
$txt['mods_cat_layout'] = 'Layout';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderering';
$txt['signature_settings_short'] = 'Signaturer';
$txt['custom_profile_shorttitle'] = 'Profilfelter';
$txt['pruning_title'] = 'Log-udrensning';

$txt['core_settings_activation_message'] = 'Funktionen {core_feature} er blevet aktiveret, klik på titlen for at konfigurere den';
$txt['core_settings_deactivation_message'] = 'funktionen {core_feature} er blevet deaktiveret';
$txt['core_settings_generic_error'] = 'En uforudset fejl opstod, genindlæs siden og prøv igen';

$txt['boardsEdit'] = 'Rediger boards';
$txt['mboards_new_cat'] = 'Opret ny kategori';
$txt['manage_holidays'] = 'Administrer ferie/fridage';
$txt['calendar_settings'] = 'Kalender-indstillinger';
$txt['search_weights'] = 'Vægt på';
$txt['search_method'] = 'Søgemetode';
$txt['search_sphinx'] = 'Konfigurer Sphinx';

$txt['smiley_sets'] = 'Smiley-sæt';
$txt['smileys_add'] = 'Tilføj smiley';
$txt['smileys_edit'] = 'Rediger smileys';
$txt['smileys_set_order'] = 'Vælg smiley rækkefølge';
$txt['icons_edit_message_icons'] = 'Rediger beskedsikoner';

$txt['membergroups_new_group'] = 'Tilføj medlemsgruppe';
$txt['membergroups_edit_groups'] = 'Rediger Medlemsgrupper';
$txt['permissions_groups'] = 'Generelle Tilladelser';
$txt['permissions_boards'] = 'Board tilladelser';
$txt['permissions_profiles'] = 'Rediger profiler';
$txt['permissions_post_moderation'] = 'Moderation af indlæg';

$txt['browse_packages'] = 'Gennemse pakker';
$txt['download_packages'] = 'Download pakker';
$txt['upload_packages'] = 'Upload pakke';
$txt['installed_packages'] = 'Installerede pakker';
$txt['package_file_perms'] = 'Tilladelser for filer';
$txt['package_settings'] = 'Indstillinger';
$txt['package_servers'] = 'Pakkeservere';
$txt['themeadmin_admin_title'] = 'Administrer og installer';
$txt['themeadmin_list_title'] = 'Temaindstillinger';
$txt['themeadmin_reset_title'] = 'Indstillinger for medlemmer';
$txt['themeadmin_edit_title'] = 'Rediger temaer';
$txt['admin_browse_register_new'] = 'Registrer en ny bruger';

$txt['search_engines'] = 'Søgemaskiner';
$txt['spider_logs'] = 'Logs over søgerobotter';
$txt['spider_stats'] = 'Stats';

$txt['paid_subscriptions'] = 'Betalt abonnement';
$txt['paid_subs_view'] = 'Vis kontingenter';

$txt['maintain_sub_hooks_list'] = 'Integrations hooks';
$txt['hooks_field_hook_name'] = 'Hook Navn';
$txt['hooks_field_function_name'] = 'Funktionsnavn';
$txt['hooks_field_function'] = 'Funktion';
$txt['hooks_field_included_file'] = 'Medfølgende fil';
$txt['hooks_field_file_name'] = 'Filnavn';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Eksisterer';
$txt['hooks_disabled'] = 'Deaktiveret'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Ikke fundet';
$txt['hooks_no_hooks'] = 'Der er i øjeblikket ikke nogen hooks i systemet';
$txt['hooks_disable_legend'] = 'Tekstforklaring';
$txt['hooks_disable_legend_exists'] = 'hook eksisterer og er aktiv';
$txt['hooks_disable_legend_disabled'] = 'hook eksisterer men er ikke aktiv';
$txt['hooks_disable_legend_missing'] = 'hook blev ikke fundet';
$txt['hooks_reset_filter'] = 'Nulstil filter';

$txt['board_perms_allow'] = 'Tillad';
$txt['board_perms_ignore'] = 'Ignorer';
$txt['board_perms_deny'] = 'Nægt';
$txt['all_boards_in_cat'] = 'Alle boards i denne kategori';

$txt['url'] = 'Webadresse';
$txt['words_sep'] = 'Ord seperator';

$txt['admin_order_title'] = 'Rækkefølge Fejl';
$txt['admin_order_error'] = 'En ukendt fejl opstod under behandling af din anmodning';

// Known controllers that can work on the front page
$txt['default'] = 'Standard';
$txt['front_page'] = 'Vælg handlingen der skal vises på forsiden:';

$txt['BoardIndex_Controller'] = 'Board Indeks';
$txt['MessageIndex_Controller'] = 'Indhold af et board';
$txt['message_index_frontpage'] = 'Vælg det board der skal vises på forsiden:';
$txt['Recent_Controller'] = 'Nylige indlæg';
$txt['recent_frontpage'] = 'Antal af beskeder der skal vises:';
