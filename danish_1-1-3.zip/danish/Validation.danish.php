<?php
// Version: 1.1; Validation

$txt['_validate_required'] = 'Feltet %1$s er påkrævet.';
$txt['_validate_valid_email'] = 'Feltet %1$s skal være en gyldig email adresse.';
$txt['_validate_max_length'] = 'Feltet %1$s kan ikke indeholde mere end %2$s karakterer.';
$txt['_validate_min_length'] = 'Feltet %1$s skal være minimum %2$s karakterer.';
$txt['_validate_length'] = 'Feltet %1$s skal være akkurat %2$s karakterer.';
$txt['_validate_alpha'] = 'Feltet %1$s kan kun indeholde bogstaver.';
$txt['_validate_alpha_numeric'] = 'Feltet %1$s kan kun indeholde bogstaver og numre.';
$txt['_validate_alpha_dash'] = 'Feltet %1$s kan kun indeholde alpha tegn &amp; streger.';
$txt['_validate_numeric'] = 'Feltet %1$s skal være numerisk.';
$txt['_validate_integer'] = 'Feltet %1$s kan kun indeholde et heltal.';
$txt['_validate_boolean'] = 'Feltet %1$s kan kun indeholde en sand/falsk værdi.';
$txt['_validate_float'] = 'Feltet %1$s kan kun indeholde en float værdi.';
$txt['_validate_valid_url'] = 'Feltet %1$s skal være en gyldig URL.';
$txt['_validate_url_exists'] = 'URL %1$s eksisterer ikke.';
$txt['_validate_valid_ip'] = 'Feltet %1$s skal være en gyldig IPv4 adresse.';
$txt['_validate_valid_ipv6'] = 'Feltet %1$s skal være en gyldig IPv6 adresse.';
$txt['_validate_contains'] = 'Feltet %1$s skal indeholde en af disse værdier: %2$s.';
$txt['_validate_invalid_function'] = 'Den angivne validerings funktion %1$s eksisterer ikke';
$txt['_validate_without'] = 'Feltet %1$s kan ikke indeholde tegnet %2$s.';
$txt['_validate_notequal'] = 'Feltet %1$s indeholder ikke en gyldig værdi.';
$txt['_validate_isarray'] = 'Feltet %1$s indeholder ikke en gyldig matrix.';
$txt['_validate_php_syntax'] = 'PHP syntaksfejl: %2$s.';
$txt['_validate_limits'] = 'Feltet %1$s indeholder en værdi uden for tilladte grænser %2$s.';
$txt['_validate_generic'] = 'Feltet %1$s indeholder en ugyldigt værdi.';
$txt['validation_failure'] = 'Formular har følgende fejl der skal rettes før der kan fortsættes:';