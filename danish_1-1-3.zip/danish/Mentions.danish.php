<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Mine omtalelser';
$txt['my_unread_mentions'] = 'Mine ulæste omtalelser';
$txt['my_mentions_pages'] = 'Side %1$d';
$txt['no_mentions_yet'] = 'Ingen omtalelser';
$txt['no_new_mentions'] = 'Ingen nye omtalelser';

$txt['mentions_from'] = 'Medlem';
$txt['mentions_when'] = 'Hvornår';
$txt['mentions_what'] = 'Besked';
$txt['mentions_all'] = 'Vis alle';
$txt['mentions_unread'] = 'Vis ulæste';
$txt['mentions_action'] = 'Handlinger';
$txt['mentions_delete_warning'] = 'Er du sikker på du vil slette denne post?';
$txt['mentions_markread'] = 'Marker som læst';
$txt['mentions_markunread'] = 'Marker som ulæst';

$txt['mentions_settings'] = 'Omtalelses indstillinger';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = 'Aktiver omtalelser';
$txt['mentions_buddy'] = 'Tilføj en omtalelse når en bruger bliver tilføjet til nogens venneliste';
$txt['mentions_dont_notify_rlike'] = 'Informer ikke medlemmer når en Like bliver fjernet fra et indlæg';

$txt['mention_mentionmem'] = 'Har omtalt dig i en besked {msg_link}';
$txt['mention_likemsg'] = 'Like på din besked {msg_link}';
$txt['mention_rlikemsg'] = 'Like fjernet fra din besked {msg_link}';
$txt['mention_buddy'] = 'Tilføjede dig til deres venneliste';
$txt['mention_quotedmem'] = 'Citerede en af dine beskeder i {msg_link}';
$txt['mention_mailfail'] = 'Deaktiverede email notifikationer på grund af afleverings fejl';

$txt['mentions_type_all'] = 'Alle omtalelser';
$txt['mentions_type_mentionmem'] = 'Omtalte';
$txt['mentions_type_likemsg'] = 'Likes';
$txt['mentions_type_rlikemsg'] = 'Likes fjernet';
$txt['mentions_type_buddy'] = 'Ven';
$txt['mentions_type_quotedmem'] = 'Citerede';
$txt['mentions_type_mailfail'] = 'Afleverings Fejl';

$txt['mentions_mark_all_read'] = 'Marker disse omtalelser som læst';

$txt['setting_notify_enable_this'] = 'Aktiver bruger notifikationer for denne begivenhed.';

$txt['setting_buddy'] = 'Venner';
$txt['setting_likemsg'] = 'Likes';
$txt['setting_rlikemsg'] = 'Fjernede likes';
$txt['setting_mentionmem'] = '@omtale';
$txt['setting_quotedmem'] = 'Citat';
$txt['setting_mailfail'] = 'Afleverings Fejl';