<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... ingen anelse, beklager</em>';
$txt['who_admin'] = 'Viser admin portalen';
$txt['who_moderate'] = 'Viser moderations portal';
$txt['who_generic'] = 'Viser %1$s';
$txt['who_unknown'] = '<em>Ukendt Handling</em>';
$txt['who_user'] = 'Bruger';
$txt['who_time'] = 'Tid';
$txt['who_action'] = 'Handling';
$txt['who_show1'] = 'Vis ';
$txt['who_show_members_only'] = 'Kun Medlemmer';
$txt['who_show_guests_only'] = 'Kun Gæster';
$txt['who_show_spiders_only'] = 'Kun Søgerobotter';
$txt['who_show_all'] = 'Alle';
$txt['who_no_online_spiders'] = 'Der er i øjeblikket ingen søgerobotter online.';
$txt['who_no_online_guests'] = 'Der er i øjeblikket ingen gæster online.';
$txt['who_no_online_members'] = 'Der er i øjeblikket ingen medlemmer online.';

$txt['whospider_login'] = 'Læser login siden.';
$txt['whospider_register'] = 'Læser registrationssiden.';
$txt['whospider_reminder'] = 'Læser Glemt Kodeord siden.';

$txt['whoall_activate'] = 'Aktiverer deres konto.';
$txt['whoall_buddy'] = 'Redigerer deres venneliste.';
$txt['whoall_coppa'] = 'Udfylder forælder/værge samtykkeformularen.';
$txt['whoall_credits'] = 'Læser credits siden.';
$txt['whoall_emailuser'] = 'Sender en e-mail til et andet medlem.';
$txt['whoall_groups'] = 'Læser siden medlemsgruppe.';
$txt['whoall_help'] = 'Viser <a href="{help_url}">hjælpe siden</a>.';
$txt['whoall_quickhelp'] = 'Læser en popup hjælp.';
$txt['whoall_pm'] = 'Læser deres personlige beskeder.';
$txt['whoall_auth'] = 'Logger ind i forummet.';
$txt['whoall_login'] = 'Læser login siden.';
$txt['whoall_login2'] = 'Læser login siden.';
$txt['whoall_logout'] = 'Logger ud af  forummet.';
$txt['whoall_markasread'] = 'Markerer emner som læst eller ulæst.';
$txt['whoall_mentions'] = 'Viser deres omtalelses liste.';
$txt['whoall_modifykarma_applaud'] = 'Giver et medlem positiv karma.';
$txt['whoall_modifykarma_smite'] = 'Giver et medlem negativ karma.';
$txt['whoall_news'] = 'Læser nyhederne.';
$txt['whoall_notify'] = 'Ændrer deres abonnementsindstillinger.';
$txt['whoall_notifyboard'] = 'Ændrer deres abonnementsindstillinger.';
$txt['whoall_openidreturn'] = 'Logger ind ved brug af OpenID.';
$txt['whoall_quickmod'] = 'Modererer et board.';
$txt['whoall_recent'] = 'Viser en <a href="{recent_url}">liste over seneste emner</a>.';
$txt['whoall_register'] = 'Registrerer en konto i forummet.';
$txt['whoall_reminder'] = 'Anmoder om glemt kodeord.';
$txt['whoall_reporttm'] = 'Anmelder et emne til en moderator.';
$txt['whoall_spellcheck'] = 'Anvender stavekontrollen';
$txt['whoall_unread'] = 'Læser ulæste emner siden deres sidste besøg.';
$txt['whoall_unreadreplies'] = 'Læser ulæste svar siden deres sidste besøg.';
$txt['whoall_who'] = 'Viser <a href="{who_url}">Hvem er Online</a>.';

$txt['whoall_collapse_collapse'] = 'Sammenfolder en kategori.';
$txt['whoall_collapse_expand'] = 'Udvider en kategori.';
$txt['whoall_pm_removeall'] = 'Sletter deres personlige beskeder.';
$txt['whoall_pm_send'] = 'Sender en besked.';
$txt['whoall_pm_send2'] = 'Sender en besked.';

$txt['whotopic_announce'] = 'Annoncerer emnet &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Godkender en vedhæftning.';
$txt['whotopic_dlattach'] = 'Studerer en vedhæftning.';
$txt['whotopic_deletemsg'] = 'Sletter et indlæg.';
$txt['whotopic_editpoll'] = 'Editerer afsteming i &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Editerer afsteming i &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Redigerer et indlæg i &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Tildeler en like til et indlæg i emnet &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Låser emnet &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Låser afsteming i &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Fletter emnet &quot;<a href="%1$s">%2$s</a>&quot; med et andet emne.';
$txt['whotopic_movetopic'] = 'Flytter emnet &quot;<a href="%1$s">%2$s</a>&quot; til et andet board.';
$txt['whotopic_movetopic2'] = 'Flytter emnet &quot;<a href="%1$s">%2$s</a>&quot; til et andet board.';
$txt['whotopic_post'] = 'Skriver i <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Skriver i <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Udprinter emnet &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Modererer emnet <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Fjerner afstemning i &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Fjernet emnet <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Sender emnet &quot;<a href="%1$s">%2$s</a>&quot; til en ven.';
$txt['whotopic_splittopics'] = 'Opdeler emnet &quot;<a href="%1$s">%2$s</a>&quot; til to emner.';
$txt['whotopic_sticky'] = 'Pinned emnet &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Stopper med at følge et emne.';
$txt['whotopic_vote'] = 'Afgiver en stemme i <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Starter med at følge et emne.';

$txt['whopost_quotefast'] = 'Citerer et indlæg fra &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Redigerer registreringsgodkendelsen.';
$txt['whoadmin_featuresettings'] = 'Redigerer forum funktioner- og indstillinger.';
$txt['whoadmin_modlog'] = 'Læser moderator loggen.';
$txt['whoadmin_serversettings'] = 'Redigerer i forum-indstillingerne.';
$txt['whoadmin_packageget'] = 'Henter pakker.';
$txt['whoadmin_packages'] = 'Læser i pakkemanageren.';
$txt['whoadmin_permissions'] = 'Redigerer forumtilladelserne.';
$txt['whoadmin_pgdownload'] = 'Downloader en pakke.';
$txt['whoadmin_theme'] = 'Redigerer temaindstillingerne.';
$txt['whoadmin_trackip'] = 'Sporer en IP adresse.';

$txt['whoallow_manageboards'] = 'Redigerer board- og kategori indstillingerne.';
$txt['whoallow_admin'] = 'Viser <a href="{admin_url}">administrations Center</a>.';
$txt['whoallow_ban'] = 'Redigerer listen over bandlysninger.';
$txt['whoallow_boardrecount'] = 'Optæller forumtotalerne.';
$txt['whoallow_calendar'] = 'Viser <a href="{calendar_url}">kalenderen</a>.';
$txt['whoallow_editnews'] = 'Redigerer nyhederne.';
$txt['whoallow_mailing'] = 'Sender en forum e-mail.';
$txt['whoallow_maintain'] = 'Udfører rutinemæssig forumvedligeholdelse.';
$txt['whoallow_manageattachments'] = 'Vedligeholder vedhæftningerne.';
$txt['whoallow_moderate'] = 'Viser <a href="{moderate_url}">Moderations Center</a>.';
$txt['whoallow_memberlist'] = 'Viser <a href="{memberlist_url}">brugerlisten</a>.';
$txt['whoallow_optimizetables'] = 'Optimerer databasetabellerne.';
$txt['whoallow_repairboards'] = 'Reparerer databasetabellerne.';
$txt['whoallow_search'] = '<a href="{search_url}">Søger</a> på forum.';
$txt['whoallow_search_results'] = 'Læser resultaterne af en søgning.';
$txt['whoallow_setcensor'] = 'Redigerer cencur teksten.';
$txt['whoallow_setreserve'] = 'Redigerer de reserverede navne.';
$txt['whoallow_stats'] = 'Viser <a href="{stats_url}">forum stats</a>.';
$txt['whoallow_viewErrorLog'] = 'Læser fejlloggen.';
$txt['whoallow_viewmembers'] = 'Læser en liste over medlemmer.';

$txt['who_topic'] = 'Viser emnet <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Viser board <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Viser boardindeks til <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Viser <a href="%1$s">%2$s</a>\'s profil.';
$txt['who_profile'] = 'Editerer profilen for <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Opretter et nyt emne i <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Opretter en ny afstemning i <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Starter et nyt emne via email i <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Skriver via email i <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Sender en personlig besked via email.';

// Credits text
$txt['credits'] = 'Credits';
$txt['credits_intro'] = 'ElkArte er 100% gratis og open-source. Vi tilkynder og supporter et aktiv, og åben fælleskab som accepterer bidrag fra offentligheden. Vi ønsker at takke alle som har supportet projektet ved at give kode, tilbagemeldinger, bug rapporter, og meninger, da intet af dette ville være muligt uden jer.  Vi ønsker også specielt at anerkende <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, projektet som ElkArte blev født udfra.';
$txt['credits_contributors'] = 'Bidragsydere';
$txt['credits_and'] = 'og';
$txt['credits_copyright'] = 'Copyrights';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Add-ons';
$txt['credits_software_graphics'] = 'Software/Grafik';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Grafik';
$txt['credits_fonts'] = 'Fonts';
$txt['credits_groups_contrib'] = 'Bidragsydere';
$txt['credits_contrib_list'] = 'For en komplet liste over de mange individer som har bidraget til design og implementation af ElkArte, besøg venligst den officielle GitHub side <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">liste over bidragsydere.</a>';
$txt['credits_license'] = 'Licens';
$txt['credits_copyright'] = 'Copyrights';
$txt['credits_version'] = 'Version';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Sprogoversættere';
$txt['credits_translators_message'] = 'Tak for din indsats som har gjort det muligt for folk over hele jorden at bruge ElkArte.  For en komplet liste henviser vi til den officielle Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">liste over bidragsydere.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';