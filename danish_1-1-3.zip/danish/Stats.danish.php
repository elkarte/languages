<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Flest online';

$txt['stats_center'] = 'Center for statistik';
$txt['general_stats'] = 'Generel statistik';
$txt['top_posters'] = 'Top 10 aktive brugere';
$txt['top_boards'] = 'Top 10 boards';
$txt['forum_history'] = 'Forum historik (efter forummets officielle tid)';
$txt['stats_new_topics'] = 'Nye emner';
$txt['stats_new_posts'] = 'Nye indlæg';
$txt['stats_new_members'] = 'Nye medlemmer';
$txt['page_views'] = 'Sidevisninger';
$txt['top_topics_replies'] = 'Top 10 emner (efter flest svar)';
$txt['top_topics_views'] = 'Top 10 emner (efter flest visninger)';
$txt['yearly_summary'] = 'Årlig opsummering';
$txt['top_starters'] = 'Top emneoprettere';
$txt['most_time_online'] = 'Mest tid online';

$txt['average_members'] = 'Gennemsnittlige registreringer per dag';
$txt['average_posts'] = 'Gennemsnitlig antal indlæg per dag';
$txt['average_topics'] = 'Gennemsnitlig antal emner per dag';
$txt['average_online'] = 'Gennemsnitlig antal online per dag';
$txt['users_online'] = 'Brugere online';
$txt['emails_sent'] = 'Gennemsnitlig antal Emails per dag';
$txt['users_online_today'] = 'Online i dag';
$txt['num_hits'] = 'Total antal sidevisninger';
$txt['average_hits'] = 'Gennemsnitlig antal sidevisninger per dag';

$txt['ssi_comment'] = 'kommentar';
$txt['ssi_comments'] = 'kommentarer';
$txt['ssi_write_comment'] = 'Skriv kommentar';
$txt['ssi_no_guests'] = 'Du kan ikke angive et board der ikke tillader gæster. Kontroller venligst boardets ID før du prøver igen.';
$txt['xml_rss_desc'] = 'Live information fra {forum_name}';