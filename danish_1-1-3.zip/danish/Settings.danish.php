<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Standard ElkArte tema.<br /><br />Lavet af: ElkArte bidragsydere';