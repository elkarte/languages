<?php
// Version: 1.1; UserNotifications

$txt['usernotif_title'] = 'Bruger Notifikations indstillinger';
$txt['usernotif_desktop_enable'] = 'Aktiver desktop notifikationer';
$txt['usernotif_favicon_enable'] = 'Aktiver Antal af notifikationer i favicon';

$txt['usernotif_favicon_position'] = 'Notifikations position:';
$txt['usernotif_favicon_up'] = 'Top-højre';
$txt['usernotif_favicon_down'] = 'Bund-højre';
$txt['usernotif_favicon_left'] = 'Bund-venstre';
$txt['usernotif_favicon_upleft'] = 'Top-venstre';

$txt['usernotif_favicon_bgColor'] = 'Baggrunds farve:';
$txt['usernotif_favicon_textColor'] = 'Tekst farve:';

$txt['usernotif_favicon_fontStyle'] = 'Font stil:';
$txt['usernotif_favicon_style_normal'] = 'Normal';
$txt['usernotif_favicon_style_italic'] = 'Kursiv';
$txt['usernotif_favicon_style_oblique'] = 'Skråt for';
$txt['usernotif_favicon_style_bold'] = 'Fed';
$txt['usernotif_favicon_style_bolder'] = 'Kraftigere';
$txt['usernotif_favicon_style_lighter'] = 'Lysere';

$txt['usernotif_favicon_type'] = 'Form:';
$txt['usernotif_favicon_shape_circle'] = 'Cirkel';
$txt['usernotif_favicon_shape_rectangle'] = 'Rektangel';