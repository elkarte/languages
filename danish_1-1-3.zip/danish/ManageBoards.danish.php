<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Administrer boards og kategorier';
$txt['order'] = 'Bestil';
$txt['full_name'] = 'Fuldt navn';
$txt['name_on_display'] = 'Dette er navnet der vil blive vist.';
$txt['boards_and_cats_desc'] = 'Rediger dinne kategorier og boards her. Angiv flere moderatører således <em>&quot;brugernavn&quot;, &quot;brugernavn&quot;</em>. (disse skal være bruger navne *ikke* skærm navne)<br />For at oprette et nyt board, klik på Tilføj nyt board knappen.<br />For at flytte et board, kan du drag og drop det til dets nye placering i listen (på tværs af kategorier og underboards)<br />For at oprette et nyt board som et underboard af et eksisterende board, skal du vælge "Underboard af..." fra Rækkefølge dropdown menuen når boardet oprettes.';
$txt['parent_members_only'] = 'Aktive medlemmer';
$txt['parent_guests_only'] = 'Gæster';
$txt['catConfirm'] = 'Vil du virkelig slette denne kategori?';
$txt['boardConfirm'] = 'Vil du virkelig slette dette board?';

$txt['catEdit'] = 'Rediger kategori';
$txt['collapse_enable'] = 'Sammenfoldeligt';
$txt['collapse_desc'] = 'Tillad brugere at sammenfolde denne kategori';
$txt['catModify'] = '[rediger]';

$txt['mboards_order_after'] = 'Efter ';
$txt['mboards_order_first'] = 'I første position';
$txt['mboards_board_error'] = 'Kunne ikke finde lokationen for flything.';

$txt['mboards_new_board'] = 'Tilføj nyt board';
$txt['mboards_new_cat_name'] = 'Ny kategori';
$txt['mboards_add_cat_button'] = 'Tilføj kategori';
$txt['mboards_new_board_name'] = 'Nyt board';

$txt['mboards_modify'] = 'rediger';
$txt['mboards_permissions'] = 'tilladelser';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Er du sikker på du vil ændre dette board til at benytte lokale tilladelser?';

$txt['mboards_delete_cat'] = 'Slet kategori';
$txt['mboards_delete_board'] = 'Slet board';

$txt['mboards_delete_cat_contains'] = 'Sletning af denne kategori vil også slette boards der ligger under dette, med tilhørende emner, indlæg og vedhæftinger i hvert board';
$txt['mboards_delete_option1'] = 'Slet kategori og alle underliggende boards.';
$txt['mboards_delete_option2'] = 'Slet kategori og flyt alle underliggende boards til';
$txt['mboards_delete_board_contains'] = 'Slettes dette board, flytter også underliggende boards, inklusiv alle emner, indlæg og vedhæftninger i hvert board';
$txt['mboards_delete_board_option1'] = 'Slet board og flyt underliggende boards til kategoriniveau.';
$txt['mboards_delete_board_option2'] = 'Slet board og flyt underliggende boards til';
$txt['mboards_delete_what_do'] = 'Vælg venligst hvad du vil gøre med disse boards';
$txt['mboards_delete_confirm'] = 'Bekræft';
$txt['mboards_delete_cancel'] = 'Afbryd';

$txt['mboards_category'] = 'Kategori';
$txt['mboards_description'] = 'Beskrivelse';
$txt['mboards_description_desc'] = 'En kort beskrivelse af dit board.<br />Du kan bruge BBC for at formatere din beskrivelse.';
$txt['mboards_groups'] = 'Tilladte grupper';
$txt['mboards_groups_desc'] = 'Grupper tilladt at få adgang til dette board.
<br />
<em>Bemærk: hvis et medlem er i en gruppe eller postgruppe som er markeret, vil denne have adgang til dette .</em> ';
$txt['mboards_groups_regular_members'] = 'Denne gruppe indeholder alle medlemmer der ikke er medlem af nogen primær gruppe.';
$txt['mboards_groups_post_group'] = 'Denne gruppe er en gruppe baseret på antal indlæg.';
$txt['mboards_moderators'] = 'Moderatorer';
$txt['mboards_moderators_desc'] = 'Yderligere medlemmer der skal have moderations-privilegier i dette board. Bemærk at administratorer ikke behøves at blive angivet her.';
$txt['mboards_count_posts'] = 'Tæl svar';
$txt['mboards_count_posts_desc'] = 'Tæl op på medlemmers antal af indlæg, hvis de opretter emner og svar her.';
$txt['mboards_unchanged'] = 'Uændret';
$txt['mboards_theme'] = 'Tema for boardet';
$txt['mboards_theme_desc'] = 'Dette tillader dig at ændre udseendet af forummet, kun for dette board.';
$txt['mboards_theme_default'] = '(generel forumstandard.)';
$txt['mboards_override_theme'] = 'Overskriv medlemmers tema';
$txt['mboards_override_theme_desc'] = 'Brug dette boards tema selvom medlemmerne ikke valgte at bruge standarden.';

$txt['mboards_redirect'] = 'Omdiriger til en webadresse';
$txt['mboards_redirect_desc'] = 'Aktiver dette valg for at omdirigere enhver der klikker på dette board, til en anden webadresse.';
$txt['mboards_redirect_url'] = 'Adresse brugere skal omdirigeres til';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Nulstil omstillingstæller';
$txt['mboards_redirect_reset_desc'] = 'Valget af dette vil nulstille omstillingstælleren for dette board til nul.';
$txt['mboards_current_redirects'] = 'I øjeblikket: %1$s';
$txt['mboards_redirect_disabled'] = 'Bemærk: Boardet skal være tomt for emner for aktivere dette valg.';
$txt['mboards_redirect_disabled_recycle'] = 'Bemærk: Du kan ikke sætte skraldespandsboardet til at være et redelegeringsboard.';

$txt['mboards_order_before'] = 'Før';
$txt['mboards_order_child_of'] = 'Underboard af';
$txt['mboards_order_in_category'] = 'I kategorien';
$txt['mboards_current_position'] = 'Nuværende position';
$txt['no_valid_parent'] = 'Boardet %1$s har ikke et gyldig ovenliggende board. Brug \'find og reparer fejl\' funktionen til at rette problemet.';

$txt['mboards_recycle_disabled_delete'] = 'Bemærk: Du skal vælge et andet board som skraldespand til slettede emner eller deaktivere gendannelse af slettede emner før du kan slette dette board.';

$txt['mboards_settings_desc'] = 'Rediger generelle indstillinger for boards og kategorier.';
$txt['groups_manage_boards'] = 'Medlemsgrupper der må redigere boards og kategorier';
$txt['recycle_enable'] = 'Aktiver genetablering af slettede emner';
$txt['recycle_board'] = 'Board til slettede emner';
$txt['recycle_board_unselected_notice'] = 'Du har aktiveret gendannelsen af emner uden at angive et board at placere dem i. Funktionen vil ikke blive aktiveret før end du angiver et board at placere slettede emner i.';
$txt['countChildPosts'] = 'Medtæl indlæg i underliggende boards, til det ovenliggende boards totale antal indlæg';
$txt['allow_ignore_boards'] = 'Tillad boards at blive ignoreret';
$txt['deny_boards_access'] = 'Aktiver indstillingen for at nægte adgang til boardet baseret på medlemsgruppe';
$txt['boardsaccess_option_desc'] = 'For hver tilladelse kan du vælge enten \'Tillad\' (T), \'Afvis\' (A), eller <span class="alert">\'Nægt\' (N)</span>.<br /><br />Hvis du nægter adgang, vil alle medlemmer - (inklusiv moderatører) - i den gruppe blive nægtet adgang.<br />Af denne grund, bør du bruge Nægt med forsigtighed, kun når det er <strong>nødvendigt</strong>. Modsat forbyder Afvis kun adgang, medmindre tilladt af andre tilladelser.';

$txt['mboards_select_destination'] = 'Vælg destinationen for boardet \'<strong>%1$s</strong>\'';
$txt['mboards_cancel_moving'] = 'Annuller flytning';
$txt['mboards_move'] = 'flyt';

$txt['mboards_no_cats'] = 'Der er i øjeblikket ikke konfigureret nogle boards eller kategorier.';
