<?php
// Version: 1.1; Maillist

// Email posting errors
$txt['error_locked'] = 'Dette emne er låst og kan ikke længere besvares';
$txt['error_locked_short'] = 'Emne Låst';
$txt['error_cant_start'] = 'Ikke autoriseret til at starte et nyt emne på det board';
$txt['error_cant_start_short'] = 'Kan ikke starte nyt emne';
$txt['error_cant_reply'] = 'Ikke autoriseret til at svare';
$txt['error_cant_reply_short'] = 'Utilgængeligt emne';
$txt['error_topic_gone'] = 'Emnet blev ikke fundet - det er muligvis blevet slettet eller flettet.';
$txt['error_topic_gone_short'] = 'Slettet Emne';
$txt['error_not_find_member'] = 'Din email adresse blev ikke fundet i bruger databasen, kun brugere kan skrive indlæg.';
$txt['error_not_find_member_short'] = 'Email ID ikke fundet i Database';
$txt['error_key_sender_match'] = 'Email nøglen, selvom gyldig, blev ikke sendt til den samme email adresse som svarede med nøglen. Du skal svare med den samme email som modtog beskeden.';
$txt['error_key_sender_match_short'] = 'Nøgle Fejl';
$txt['error_not_find_entry'] = 'Det ser ud til at du allerede har svaret til denne email. Hvis du ønsker at redigere dit indlæg, så benyt venligst web interface, hvis du laver et nyt svar til dette emne, så svar venligst til den seneste underretning';
$txt['error_not_find_entry_short'] = 'Nøgle Udløbet';
$txt['error_pm_not_found'] = 'Den personlige besked du svarer på, blev ikke fundet.';
$txt['error_pm_not_found_short'] = 'PB Mangler';
$txt['error_pm_not_allowed'] = 'Du har ikke tilladelse til at sende personlige beskeder!';
$txt['error_pm_not_allowed_short'] = 'Ikke autoriseret til at sende PB';
$txt['error_no_message'] = 'Vi kunne ikke finde nogen beskeder i Email, du skal skrive en for at lave indlæg';
$txt['error_no_message_short'] = 'Blank Besked';
$txt['error_no_subject'] = 'Du skal angive et Emne for at starte et nyt indlæg, ingen blev fundet';
$txt['error_no_subject_short'] = 'Intet Emne';
$txt['error_board_gone'] = 'Det board du prøvede at skrive til, er enten ugyldigt eller utilgængeligt';
$txt['error_board_gone_short'] = 'Ugyldigt eller Beskyttet Board';
$txt['error_missing_key'] = 'Kunne ikke finde nøglen i dit svar. For at emails skal accepteres, skal de sendes som et svar til en gyldig underrettelsesesmail og svaret skal sendes fra den samme email adresse underretningen blev sendt til.';
$txt['error_missing_key_short'] = 'Manglende Nøgle';
$txt['error_found_spam'] = 'Advarsel: Dit indlæg er blevet klassificeret som mulig spam af dit spam filter, og er ikke blevet oprettet.';
$txt['error_found_spam_short'] = 'Mulig Spam';
$txt['error_pm_not_find_entry'] = 'Det ser ud til at du allerede har svaret på denne personlige besked. Hvis du har brug for at lave endnu et svar, brug da venligst web interface eller vent indtil du modtager et nyt svar.';
$txt['error_pm_not_find_entry_short'] = 'PB Nøgle Udløbet';
$txt['error_not_find_board'] = 'Forsøgte at starte et nyt emne på et ikke eksisterende board, mulig hacking forsøg';
$txt['error_not_find_board_short'] = 'Intet Board';
$txt['error_no_pm_attach'] = '[PB vedhæftninger er ikke understøttet]';
$txt['error_no_attach'] = '[Email vedhæftninger er deaktiveret]';
$txt['error_in_maintenance_mode'] = 'Email modtaget i vedligeholdelsestilstand og kunne ikke indlægges på det tidspunkt';
$txt['error_in_maintenance_mode_short'] = 'Vedligeholdelse';
$txt['error_email_notenabled_short'] = 'Ikke Aktiveret';
$txt['error_email_notenabled'] = 'Indlæg via email funktionen er ikke aktiveret, email kunne ikke behandles';
$txt['error_permission'] = 'Afsender har ikke indlæg via email rettigheder på dette board';
$txt['error_permission_short'] = 'Ingen tilladelser';
$txt['error_bounced'] = 'Beskeden blev afvist af destination mail serveren';
$txt['error_bounced_short'] = 'Beskeden kunne ikke afleveres';

// Maillist page items
$txt['ml_admin_configuration'] = 'Mailliste Konfiguration';
$txt['ml_configuration_desc'] = 'Denne sektion tillader dig at indstille nogle indstillinger for alle indlæg via email aktiviteter';
$txt['ml_emailerror_none'] = 'Der er ikke nogen fejlede enheder der har brug for moderation';
$txt['ml_emailerror'] = 'Mislykkede emails';
$txt['ml_emailsettings'] = 'Indstillinger';

// Settings tab
$txt['maillist_enabled'] = 'Aktiver Maillist Funktionener (global til/fra indstilling)';
$txt['pbe_post_enabled'] = 'Tillad at skrive indlæg til forum via Email';
$txt['pbe_pm_enabled'] = 'Tillad at svare på PB via Email';
$txt['pbe_no_mod_notices'] = 'Slå moderations beskeder fra';
$txt['pbe_no_mod_notices_desc'] = 'Send ikke nogen beskeder ved flyttet, låst, slettet, flettet, etc. Disse optager din email kvote uden noget egentligt formål';
$txt['pbe_bounce_detect'] = 'Aktiver automatisk bounce detektion';
$txt['pbe_bounce_detect_desc'] = 'Forsøg at identificere mail bounces og deaktiver yderligere notifikationer';
$txt['pbe_bounce_record'] = 'Optag bounce beskeder i fejlede mail efter automatisk behandling';
$txt['pbe_bounce_record_desc'] = 'Bounce beskeder vil altid blive optaget hvis Bounce Detektion er slået fra';

$txt['saved'] = 'Informationer Gemt';

// General Sending Settings
$txt['maillist_outbound'] = 'Generelle Afsendings Indstillinger';
$txt['maillist_outbound_desc'] = 'Brug disse indstillinger til at modificere hvordan udgående emails fremstår for brugere og hvor et svar bliver sendt til.';
$txt['maillist_group_mode'] = 'Aktiver gruppe maillist tilstand';
$txt['maillist_digest_enabled'] = 'Aktiver udvidet daglig digest (indeholder emne snippets i digest)';
$txt['maillist_sitename'] = 'Side Navn der skal bruges for email (ikke email adresse)';
$txt['maillist_sitename_desc'] = 'Dette er navnet for email adressen, noget der er velkendt for brugerne da dette vil fremgå flere steder i udgående emails, inklusiv emne linjen - [Side Navn] emne';
$txt['maillist_sitename_post'] = 'f.eks. &lt;<strong>Side Navn</strong>&gt;emailpost@yourdomain.com';
$txt['maillist_sitename_address'] = 'Svar-Til og Fra email adresse';
$txt['maillist_sitename_address_desc'] = 'Email adressen hvor svar på beskeder bliver sendt til. Hvis tom bliver underretning (hvis indstillet) eller webmaster brugt.';
$txt['maillist_sitename_regards'] = 'Email "signatur"';
$txt['maillist_sitename_regards_desc'] = 'Hvad der skal stå i slutningen af udgående emails, såsom "Med venlig hilsen, Side Navn Teamet"';
$txt['maillist_sitename_address_post'] = 'f.eks. emailpost@yourdomain.com';
$txt['maillist_sitename_help'] = 'Hjælpe email adresse';
$txt['maillist_sitename_help_desc'] = 'Brugt til "Liste Ejer" brevhovede for at forhindre udgående emails at blive markeret som spam.';
$txt['maillist_sitename_help_post'] = 'f.eks. help@yourdomain.com';
$txt['maillist_mail_from'] = 'Underretnings email adresse';
$txt['maillist_mail_from_desc'] = 'Email adressen som vil blive brugt til kode påmindelser, underretninger, etc. Hvis tom bliver webmaster adressen brugt (dette er standard)';
$txt['maillist_mail_from_post'] = 'f.eks. noreply@yourdomain.com';

// Imap settings
$txt['maillist_imap'] = 'IMAP Indstillinger';
$txt['maillist_imap_host'] = 'Mailbox Server Navn';
$txt['maillist_imap_host_desc'] = 'Skriv en mail server host navn og eventuelt :port nummer. f.eks. imap.gmail.com eller imap.gmail.com:993';
$txt['maillist_imap_mailbox'] = 'Mailbox Navn';
$txt['maillist_imap_mailbox_desc'] = 'Skriv navnet på mailbox på serveren. f.eks: INBOX';
$txt['maillist_imap_uid'] = 'Mailbox Brugernavn';
$txt['maillist_imap_uid_desc'] = 'Brugernavn der skal bruges til at login til mailbox.';
$txt['maillist_imap_pass'] = 'Mailbox Kode';
$txt['maillist_imap_pass_desc'] = 'Koden til at login til mailbox.';
$txt['maillist_imap_connection'] = 'Mailbox Forbindelse';
$txt['maillist_imap_connection_desc'] = 'Forbindelsestype der skal bruges, IMAP eller POP3 (ikke krypteret, TLS eller SSL tilstand).';
$txt['maillist_imap_unsecure'] = 'IMAP';
$txt['maillist_pop3_unsecure'] = 'POP3';
$txt['maillist_imap_tls'] = 'IMAP/TLS';
$txt['maillist_imap_ssl'] = 'IMAP/SSL';
$txt['maillist_pop3_tls'] = 'POP3/TLS';
$txt['maillist_pop3_ssl'] = 'POP3/SSL';
$txt['maillist_imap_delete'] = 'Slet beskeder';
$txt['maillist_imap_delete_desc'] = 'Forsøg at fjerne mailbox beskeder der er modtaget og behandlet.';
$txt['maillist_imap_reason'] = 'Følgende bør efterlades BLANKT hvis du vil pipe beskeder ind i forum (anbefalet)';
$txt['maillist_imap_missing'] = 'IMAP funktioner er ikke installeret på dit system, ingen indstillinger er tilgængelige';
$txt['maillist_imap_cron'] = 'Fake-Cron (tidsindstillet opgave)';
$txt['maillist_imap_cron_desc'] = 'Hvis du ikke kan køre et cron job på dit system, som en sidste udvej check dette istedet for at køre dette som en ElkArte tidsindstillet opgave';
$txt['scheduled_task_desc_pbeIMAP'] = 'Kører indlæg via email IMAP mailbox programmet for at læse nye email fra den indstillede mailbox';

// General Receiving Settings
$txt['maillist_inbound'] = 'Generelle Modtagnings Indstillinger';
$txt['maillist_inbound_desc'] = 'Brug disse indstillinger for at definere hvilke valg systemet skal tage ved modtagelse af nye emne emails. Dette påvirker ikke svar til underretninger.';
$txt['maillist_newtopic_change'] = 'Tillad at starte et nyt emne ved at ændre svar tittel';
$txt['maillist_newtopic_needsapproval'] = 'Kræv Nyt Emne godkendelse';
$txt['maillist_newtopic_needsapproval_desc'] = 'Kræv godkendelse af alle nye emner sendt via email før de er indrykket for at forhindre email spoofing';
$txt['recommended'] = 'Dette er anbefalet';
$txt['experimental'] = 'Denne funktionalitet er eksperimentel';
$txt['receiving_address'] = 'Modtage email adresser';
$txt['receiving_board'] = 'Board der skal indrykkes nye beskeder til';
$txt['reply_add_more'] = 'Tilføj en ny adresse';
$txt['receiving_address_desc'] = 'Skriv en liste af email adresser efterfulgt af board hvor modtagne email skal indrykkes. Dette er krævet for at starte et NYT emne på et specifikt board, brugere skal skrive en email til denne email adresse og det vil blive indrykket på det specificerede board. For at fjerne en eksisterende enhed, fjern email adressen og gem.';
$txt['email_not_valid'] = 'Email adressen (%s) er ikke gyldig';
$txt['board_not_valid'] = 'Du har skrevet et ugyldigt board ID (%d)';

// Other settings
$txt['misc'] = 'Andre Indstillinger';
$txt['maillist_allow_attachments'] = 'Tillad at indrykke fil vedhæftninger via email (virker ikke for PBs)';
$txt['maillist_key_active'] = 'Antal dage nøgler skal gemmes i databasen';
$txt['maillist_key_active_desc'] = 'F.eks. Hvor længe efter en underretning er sendt vil du acceptere et svar';
$txt['maillist_sig_keys'] = 'Ord der signalerer starten på en signatur';
$txt['maillist_sig_keys_desc'] = 'Separer ord med | karakteren, anbefalet at bruge "med|venlig|hilsen|tak". Linjer der starter med disse vil blive anset som starten af en signatur linje';
$txt['maillist_leftover_remove'] = 'Linjer der er tilovers fra emails';
$txt['maillist_leftover_remove_desc'] = 'Anbefalede separate ord med en | karakter at bruge "Til: |To: |Sv: |Re: |Fra: |From: |Sendt: |Sent: |Dato: |Date: |Emne: |Subject: ". De fleste til vil blive fjernet af parseren men visse ting ender op som citater. Tilføj ikke til denne medmindre du ved hvad du laver.';
$txt['maillist_short_line'] = 'Kort linje længde, brugt til at dekode emails';
$txt['maillist_short_line_desc'] = 'Ændring af dette fra standard kan give usædvanlige resultater, brug forsigtighed';

// Failed log actions
$txt['approved'] = 'Email var godkendt og indrykket';
$txt['error_approved'] = 'Det opstod en fejl under forsøg på at godkende denne email';
$txt['id'] = '#';
$txt['error'] = 'Fejl';
$txt['key'] = 'Nøgle';
$txt['message_id'] = 'Besked';
$txt['message_type'] = 'Type';
$txt['message_action'] = 'Handlinger';
$txt['emailerror_title'] = 'Log over email fejl';
$txt['show_notice'] = 'Email Detaljer';
$txt['private'] = 'Privat';
$txt['show_notice_text'] = 'Tekst';
$txt['noaccess'] = 'Private Beskeder kan ikke revideres';
$txt['badid'] = 'Ugyldig eller manglende email ID';
$txt['delete_warning'] = 'Er du sikker på du vil slette denne post?';
$txt['pm_approve_warning'] = 'Godkend denne personlige besked med FORSIGTIGHED!
Den PB der svares på er blevet SLETTET.
Systemet prøver at finde andre i den samme samtale, men resultatet er ikke 100% korrekt.
Hvis i tvivl, er det bedre at bounce!';
$txt['filter_delete_warning'] = 'Er du sikker på du vil fjerne dette filter?';
$txt['parser_delete_warning'] = 'Er du sikker på du vil fjerne denne parser?';
$txt['bounce'] = 'Bounce';
$txt['heading'] = 'Dette er en liste over indlæg via email der har fejlet, herfra kan du vælge at vise, godkende (hvis muligt), slette eller bounce tilbage til sender';
$txt['cant_approve'] = 'Denne fejl tillader ikke at enheden bliver godkendt (kan ikke auto reparere)';
$txt['email_attachments'] = '[Der er %d email vedhæftninger i denne besked]';
$txt['email_failure'] = 'Fejl Årsag';

// Filters
$txt['filters'] = 'Email Filtre';
$txt['add_filter'] = 'Tilføj Filter';
$txt['sort_filter'] = 'Sorter Filtre';
$txt['edit_filter'] = 'Rediger Eksisterende Filter';
$txt['no_filters'] = 'Du har ikke defineret nogle filtre';
$txt['error_no_filter'] = 'Ude af stand til at finde/hente specificerede filter';
$txt['regex_invalid'] = 'Regex er ikke gyldig';
$txt['filter_to'] = 'Erstatnings Tekst';
$txt['filter_to_desc'] = 'Erstat funden tekst med dette';
$txt['filter_from'] = 'Tekst Søgning';
$txt['filter_from_desc'] = 'Indtast tekst du vil søge efter';
$txt['filter_type'] = 'Type';
$txt['filter_type_desc'] = 'Standard vil søge efter den nødagtige indtastning og erstatte den med tekst i erstat feltet. Regular Expression er wildcard mulighed af standard, den skal indskrives i PCRE format.';
$txt['filter_name'] = 'Navn';
$txt['filter_name_desc'] = 'Valgfrit kan du give et navn til dette filter for at hjælpe med at huske hvad det gør';
$txt['filters_title'] = 'Herfra kan du tilføje, redigere, fjerne email filtre. Filtre søger efter specifik tekst i et svar og erstatter det med tekst du har skrevet, som regel intet.';
$txt['filter_invalid'] = 'Definationen er ikke gyldig og kunne ikke gemmes';
$txt['error_no_id_filter'] = 'Filter ID er ikke gyldig';
$txt['saved_filter'] = 'Filter gemt';
$txt['filter_sort_description'] = 'Filtre er kørt i den rækkefølge de er vist, regex er kørt først, derefter standard, for at ændre dette, drag og drop en enhed til en ny placering i listen (du kan dog ikke tvinge et standard filter at køre før et regex filter)';

// Parsers
$txt['saved_parser'] = 'Parser gemt';
$txt['parser_reordered'] = 'Felter omorganiseret';
$txt['error_no_id_parser'] = 'Parser ID er ikke gyldig';
$txt['add_parser'] = 'Tilføj Parser';
$txt['sort_parser'] = 'Sorter Parsers';
$txt['edit_parser'] = 'Rediger Eksisterende Parser';
$txt['parsers'] = 'Email Parsers';
$txt['parser_from'] = 'Søgeterm i original email';
$txt['parser_from_desc'] = 'Indskriv start på søgeterm på den originale email, systemet vil skære beskeden ved dette punkt, efterladende kun den nye besked (hvis muligt). Hvis regular expression er brugt, skal det være opdelt korrekt';
$txt['parser_type'] = 'Type';
$txt['parser_type_desc'] = 'Standard vil søge efter den nødagtige indtastning og skære email ved det punkt. Regular Expression er wildcard mulighed af standard, den skal indskrives i PCRE format.';
$txt['parser_name'] = 'Navn';
$txt['parser_name_desc'] = 'Valgfrit kan du angive et navn for at hjælpe med at huske hvilken email klient denne parser er til';
$txt['no_parsers'] = 'Du har ikke defineret nogen parsers';
$txt['parsers_title'] = 'Herfra kan du tilføje, redigere, fjerne email parsers. Parsers søger efter en specifik linje af tekst og skærer beskeden ved dette punkt i et forsøg på at fjerne den originale besvarede besked. Hvis en parser ikke resulterer i nogen tekst (f.eks. et svar understående eller flettet ind i den originale besked), vil den ikke blive kørt';
$txt['option_standard'] = 'Standard';
$txt['option_regex'] = 'Regular Expression';
$txt['parser_sort_description'] = 'Parsers er kørt i den rækkefølge de er vist, for at ændre dette, drag og drop en enhed til en ny placering i listen.';

// Bounce
$txt['bounce_subject'] = 'Fejl';
$txt['bounce_error'] = 'Fejl';
$txt['bounce_title'] = 'Bounced Email Kreatør';
$txt['bounce_notify_subject'] = 'Bounce Underretningsemne';
$txt['bounce_notify'] = 'Send en Bounce Underretning';
$txt['bounce_notify_template'] = 'Vælg en skabelon';
$txt['bounce_notify_body'] = 'Bounce Underretningsbesked';
$txt['bounce_issue'] = 'Send Bounce';
$txt['bad_bounce'] = 'Bounce beskeden og/eller emne er blankt og kan ikke sendes';

// Subject tags
$txt['RE:'] = 'SV:';
$txt['FW:'] = 'FW:';
$txt['FWD:'] = 'FWD:';
$txt['SUBJECT:'] = 'EMNE:';

// Quote strings
$txt['email_wrote'] = 'Skrev';
$txt['email_quoting'] = 'Citat';
$txt['email_quotefrom'] = 'Citat fra';
$txt['email_on'] = 'På';
$txt['email_at'] = 'ved';

// Our digest strings for the digest "template"
$txt['digest_preview'] = "\n     <*> Topic Summary:\n     ";
$txt['digest_see_full'] = "\n\n     <*> Se det fulde emne på det følgende link:\n     <*> ";
$txt['digest_reply_preview'] = "\n     <*> Latest Reply:\n     ";
$txt['digest_unread_reply_link'] = "\n\n     <*> See all your unread replies to this topic at the following link:\n     <*> ";
$txt['message_attachments'] = '<*> Denne besked har %d billeder/filer tilknyttet.
<*> For at se dem besøg følgende link: %s';

// Help
$txt['maillist_help'] = 'For hjælp med at opsætte mail liste funktion, besøg mail liste sektion på <a href="https://github.com/elkarte/Elkarte/wiki/Posting-by-Email-Feature" target="_blank" class="new_win">ElkArte Wiki</a>';

// Email bounce templates
$txt['ml_bounce_templates_title'] = 'Brugerdefineret bounce email skabeloner';
$txt['ml_bounce_templates_none'] = 'Ingen brugerdefinerede bounce skabeloner er oprettet endnu';
$txt['ml_bounce_templates_time'] = 'Dato for oprettelse';
$txt['ml_bounce_templates_name'] = 'Skabelon';
$txt['ml_bounce_templates_creator'] = 'Oprettet af';
$txt['ml_bounce_template_add'] = 'Tilføj skabelon';
$txt['ml_bounce_template_modify'] = 'Rediger skabelon';
$txt['ml_bounce_template_delete'] = 'Slet markerede';
$txt['ml_bounce_template_delete_confirm'] = 'Er du sikker på du vil slette de valgte skabeloner?';
$txt['ml_bounce_body'] = 'Meddelelse';
$txt['ml_bounce_template_subject_default'] = 'Overskrift for advarslen';
$txt['ml_bounce_template_desc'] = 'Brug denne side til at indstille detaljer for skabelon. Bemærk at emne på email er ikke en del af skabelon.';
$txt['ml_bounce_template_title'] = 'Titel på skabelon';
$txt['ml_bounce_template_title_desc'] = 'Et navn til brug for skabelon liste';
$txt['ml_bounce_template_body'] = 'Skabelon Indhold';
$txt['ml_bounce_template_body_desc'] = 'Indholdet af bounced besked. Bemærk at du kan bruge følgende genveje i denne skabelon:<ul><li>{MEMBER} - Bruger navn.</li><li>{FORUMNAME} - Forum Navn.</li><li>{FORUMNAMESHORT} - Kort navn for side.</li><li>{ERROR} - Den fejl der blev skabt af email.</li><li>{SUBJECT} - Emne på den email der fejlede.</li><li>{SCRIPTURL} - Web adresse til forum.</li><li>{EMAILREGARDS} - Maillist email signatur.</li><li>{REGARDS} - Standard forum signatur.</li></ul>';
$txt['ml_bounce_template_personal'] = 'Personlig skabelon';
$txt['ml_bounce_template_personal_desc'] = 'Hvis du vælger denne mulighed er det kun dig der kan se, redigere og bruge denne skabelon, ellers kan alle moderatører bruge den.';
$txt['ml_bounce_template_error_no_title'] = 'Du skal angive en informativ tittel.';
$txt['ml_bounce_template_error_no_body'] = 'Du skal angive en email skabelon besked.';

$txt['ml_bounce'] = 'E-mail skabeloner';
$txt['ml_bounce_description'] = 'Fra denne sektion kan du tilføje og modifere hvilke email bounce skabeloner der skal bruges når indlæg via email afvises.';
$txt['ml_bounce_title'] = 'Bounce';
$txt['ml_bounce_subject'] = 'Din email kunne ikke oprettes';
$txt['ml_bounce_body'] = 'Meddelelse';
$txt['ml_inform_title'] = 'Abonner';
$txt['ml_inform_subject'] = 'Der var et problem med din email';
$txt['ml_inform_body'] = '{MEMBER},

Den email du sendte til {FORUMNAMESHORT} generede en fejl som forårsagede forskinkelser i dens behandling.  Fejlen var: {ERROR}

For at forhindre yderligere forsinkelser bedes du rette denne fejl.

{EMAILREGARDS}';
$txt['ml_bounce_template_body_default'] = 'Hej. Dette er indlæg via email programmet hos {FORUMNAMESHORT}

Jeg er bange for at jeg ikke var i stand til at levere og/eller indlægge din besked med titlen: {SUBJECT}.

Fejlen jeg modtog ved at forsøge var: {ERROR}

Dette er en permanent fejl; Jeg har givet op. Beklager at det ikke fungerede.

{EMAILREGARDS}'; // redundant?