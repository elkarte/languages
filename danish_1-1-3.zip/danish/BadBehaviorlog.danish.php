<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Dato';
$txt['badbehaviorlog_protocol'] = 'Protokol';
$txt['badbehaviorlog_method'] = 'Metode';
$txt['badbehaviorlog_request'] = 'Anmodning';
$txt['badbehaviorlog_uri'] = 'Webadresse';
$txt['badbehaviorlog_id_member'] = 'Medlems ID';
$txt['badbehaviorlog_username'] = 'Brugernavn';
$txt['badbehaviorlog_headers'] = 'Headers';
$txt['badbehaviorlog_agent'] = 'Browser';
$txt['badbehaviorlog_entity'] = 'Gem';
$txt['badbehaviorlog_key'] = 'Nøgle';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Total antal';
$txt['badbehaviorlog_error_valid_code'] = 'Begrundelses Kode';
$txt['badbehaviorlog_error_valid_response'] = 'HTTP Status';
$txt['badbehaviorlog_error_valid_explaination'] = 'HTTP Begrundelse';
$txt['badbehaviorlog_error_valid_log'] = 'Detaljer';
$txt['badbehaviorlog_log'] = 'BadBehavior Log';
$txt['badbehaviorlog_desc'] = 'Nedenstående er en liste over alle bad behavior poster der er blevet logget';
$txt['badbehaviorlog_details'] = 'Yderligere Detaljer';
$txt['badbehaviorlog_no_entries_found'] = 'Der er i øjeblikket ikke nogen bad behavior log posteringer';

$txt['badbehaviorlog_remove_selection'] = 'Slet markerede';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Er du sikker på du vil slette de markerede log poster?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Slet alle filtrerede resultater';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Er du sikker på du vil slette de filtrerede poster?';
$txt['badbehaviorlog_sure_remove'] = 'Er du sikker på du vil rydde hele bad behavior log?';

$txt['badbehaviorlog_remove'] = 'Slet markerede';
$txt['badbehaviorlog_removeall'] = 'Ryd Log';
$txt['badbehaviorlog_clear_filter'] = 'Ryd filter';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Aktiver filter af typen';
$txt['badbehaviorlog_apply_filter'] = 'Aktiver filter';
$txt['badbehaviorlog_applying_filter'] = 'Aktiverer filter';
$txt['badbehaviorlog_filter_only_member'] = 'Vis kun bad behavior logs fra denne bruger';
$txt['badbehaviorlog_filter_only_ip'] = 'Vis kun bad behavior logs fra denne IP adresse';
$txt['badbehaviorlog_filter_only_session'] = 'Vis kun bad behavior logs fra denne session';
$txt['badbehaviorlog_filter_only_headers'] = 'Vis kun bad behavior logs fra denne webadresse';
$txt['badbehaviorlog_filter_only_agent'] = 'Vis kun posteringer med den samme bruger agent';

$txt['badbehaviorlog_session'] = 'Session';
$txt['badbehaviorlog_error_url'] = 'Webadressen af siden der blev logget';

$txt['badbehaviorlog_reverse_direction'] = 'Omvendt kronologisk rækkefølge af listen';
$txt['badbehaviorlog_filter_only_type'] = 'Vis kun logs med denne kode';