<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Vis Kladder';
$txt['drafts_show_desc'] = 'Dette område viser alle kladder du har gemt. Herfra kan du editere dem før indrykning, eller du kan slette dem';

// misc
$txt['drafts'] = 'Kladder';
$txt['draft_save'] = 'Gem Kladde';
$txt['draft_save_note'] = 'Dette vil gemme alt tekst fra dit indlæg, men vedhæftede filer, afstemning og begivenheds informationer bliver ikke gemt.';
$txt['draft_none'] = 'Du har ingen kladder.';
$txt['draft_edit'] = 'Rediger kladde';
$txt['draft_load'] = 'Indlæs kladder';
$txt['draft_hide'] = 'Skjul kladder';
$txt['draft_delete'] = 'Slet kladde';
$txt['draft_days_ago'] = '%s dage siden';
$txt['draft_retain'] = 'dette bliver gemt i %s dage mere';
$txt['draft_remove'] = 'Slet denne kladde';
$txt['draft_remove_selected'] = 'Slet alle valgte kladder?';
$txt['draft_saved'] = 'Indholdet er blevet gemt som en kladde, og vil være tilgængelig fra <a href="%1$s">Vis Kladder området</a> i din profil.';
$txt['draft_pm_saved'] = 'Indholdet er blevet gemt som en kladde, og vil være tilgængelig fra <a href="%1$s">Vis Kladder området</a> i dit beskeds center.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Aktiver automatisk kladde gemning';
$txt['drafts_autosave_enabled_subnote'] = 'Dette vil automatisk gemme bruger kladder i baggrunden med en given frekvens. Brugeren skal også have de rette rettigheder';
$txt['drafts_keep_days'] = 'Maksimal antal af dage at gemme kladder';
$txt['drafts_keep_days_subnote'] = 'Skriv 0 for at gemme kladder uendeligt';
$txt['drafts_autosave_frequency'] = 'Hvor ofte skal kladder automatisk gemmes?';
$txt['drafts_autosave_frequency_subnote'] = 'Minimum tilladte værdi er 30 sekunder';
$txt['drafts_pm_enabled'] = 'Aktiver gemning af PB kladder';
$txt['drafts_post_enabled'] = 'Aktiver geming af Indlægs kladder';
$txt['drafts_none'] = 'Intet Emne';
$txt['drafts_saved'] = 'Kladde blev korrekt gemt';