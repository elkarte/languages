<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Velkommen';
$txt['install_step_exist'] = 'Eksistens Tjek';
$txt['install_step_writable'] = 'Checker skrivbarhed';
$txt['install_step_forum'] = 'Forum-indstillinger';
$txt['install_step_databaseset'] = 'Database-indstillinger';
$txt['install_step_databasechange'] = 'Database-oversigt';
$txt['install_step_admin'] = 'Admin konto';
$txt['install_step_delete'] = 'Færdiggør installation';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'Sprog';
$txt['installer_language_set'] = 'Indstil';
$txt['congratulations'] = 'Tillykke, installationsprocessen er færdig!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Din installationsmappe er stadig skrivbar. Det er af sikkerhedsmæssige grunde en god ide at ændre rettighederne med chmod, så mappen ikke længere er skrivbar.';
$txt['delete_installer'] = 'Klik her for at forsøge at slette installations mappen nu.';
$txt['delete_installer_maybe'] = '<em>(virker ikke på alle servere.)</em>';
$txt['go_to_your_forum'] = 'Nu kan du se <a href="%1$s">dit nyinstallerede forum</a> og begynde at bruge det. Du bør først sikre dig at du er logget på, hvorefter du vil være i stand til at få adgang til administrationscenteret.';
$txt['good_luck'] = 'Tak for at installere ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Velkommen';
$txt['install_welcome_desc'] = 'Velkommen til ElkArte. Dette script vil guide dig igennem processen for at installere %1$s. Vi vil opsamle et par detaljer om dit forum over de næste par skridt, og efter et par minutter vil dit forum være klar til at bruge.';
$txt['install_all_lovely'] = 'Vi har gennemført nogle få tests på din server og alting ser ud til at være i orden. Klik blot på &quot;Fortsæt&quot; knappen herunder for at gå i gang.';

$txt['user_refresh_install'] = 'Forum opdateret';
$txt['user_refresh_install_desc'] = 'Under installationen fandt installationsprogrammet ud af (med de detaljer du angav) at en eller flere af de tabeller installationsprogrammet skal oprette allerede eksisterer.<br />Enhver manglende tabel i din installation er blevet oprettet med standard dataene, men ingen data blev slettet fra eksisterende tabeller.';

$txt['default_topic_subject'] = 'Velkommen til ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Generel diskussion';
$txt['default_board_description'] = 'Føl dig fri til at tale om alt og alle i dette board.';
$txt['default_category_name'] = 'Generel kategori';
$txt['default_time_format'] = '%B %d, %Y, %I:%M:%S %p';
$txt['default_news'] = 'ElkArte - Lige installeret!';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[dårlig]';
$txt['default_karmaApplaudLabel'] = '[god]';
$txt['default_reserved_names'] = 'Admin\\nwebmaster\\ngæst\\nroot';
$txt['default_smileyset_name'] = 'Fugue\'s Sæt';
$txt['default_theme_name'] = 'ElkArte Standard Tema';

$txt['default_administrator_group'] = 'Administrator';
$txt['default_global_moderator_group'] = 'Global moderator';
$txt['default_moderator_group'] = 'Moderator';
$txt['default_newbie_group'] = 'Nyt medlem';
$txt['default_junior_group'] = 'Jr. medlem';
$txt['default_full_group'] = 'Fuldgyldige medlemmer';
$txt['default_senior_group'] = 'Senior medlem';
$txt['default_hero_group'] = 'Hyper medlem';

$txt['default_smiley_smiley'] = 'Smiley';
$txt['default_wink_smiley'] = 'Blink';
$txt['default_cheesy_smiley'] = 'Humørgrin';
$txt['default_grin_smiley'] = 'Grin';
$txt['default_angry_smiley'] = 'Vred';
$txt['default_sad_smiley'] = 'Ked af det';
$txt['default_shocked_smiley'] = 'Chokeret';
$txt['default_cool_smiley'] = 'Cool';
$txt['default_huh_smiley'] = 'Spørgsmålstegn';
$txt['default_roll_eyes_smiley'] = 'Rullende øjne';
$txt['default_tongue_smiley'] = 'Tunge';
$txt['default_embarrassed_smiley'] = 'Forlegen';
$txt['default_lips_sealed_smiley'] = 'Forseglede læber';
$txt['default_undecided_smiley'] = 'Tvær';
$txt['default_kiss_smiley'] = 'Kys';
$txt['default_cry_smiley'] = 'Græder';
$txt['default_evil_smiley'] = 'Ond';
$txt['default_azn_smiley'] = 'Azn';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Grin';
$txt['default_police_smiley'] = 'Politi';
$txt['default_angel_smiley'] = 'Angel';

$txt['error_message_click'] = 'Klik her';
$txt['error_message_try_again'] = 'for at prøve dette trin igen.';
$txt['error_message_bad_try_again'] = 'for alligevel at prøve at installere, men bemærk dette <em>på det kraftigste</em> frarådes.';

$txt['install_settings'] = 'Forum-indstillinger';
$txt['install_settings_info'] = 'Denne side kræver at du definerer et par nøgleindstillinger til dit forum. ElkArte har automatisk fundet nøgleindstillinger for dig.';
$txt['install_settings_name'] = 'Forumnavn';
$txt['install_settings_name_info'] = 'Dette er navnet på dit forum, eks. &quot;Test Forummet&quot;.';
$txt['install_settings_name_default'] = 'Mit Forum';
$txt['install_settings_url'] = 'Forummets webadresse';
$txt['install_settings_url_info'] = 'Dette er webadressen til dit forum <strong>uden \'/\'!</strong>.<br />I de fleste tilfælde kan du lade standardværdien i boksen være - den passer som regel.';
$txt['install_settings_compress'] = 'Gzip output';
$txt['install_settings_compress_title'] = 'Komprimer outputtet for at spare båndbredde.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Denne funktion virker ikke korrekt på alle servere, men kan spare dig en masse båndbredde.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Klik her for at teste</a>. (der skulle komme meldingen "PASS".)';
$txt['install_settings_dbsession'] = 'Database-sessioner';
$txt['install_settings_dbsession_title'] = 'Brug databasen til sessioner i stedet for at bruge filer.';
$txt['install_settings_dbsession_info1'] = 'Denne funktion er næsten altid til det beste, da det gør sessioner mere afhængige.';
$txt['install_settings_dbsession_info2'] = 'Denne funktion er generel en god ide, men virker måske ikke korrekt på denne server.';
$txt['install_settings_proceed'] = 'Fortsæt';

$txt['db_settings'] = 'Database server-indstillinger';
$txt['db_settings_info'] = 'Disse indstillinger skal anvendes til dine databaseindstillinger. Hvis du ikke kender værdierne for disse, så spørg din host.';
$txt['db_settings_type'] = 'Databasetype';
$txt['db_settings_type_info'] = 'Flere understøttede database typer blev fundet - hvilken en vil du benytte?';
$txt['db_settings_server'] = 'Servernavn';
$txt['db_settings_server_info'] = 'Dette er næsten altid localhost - så hvis du ikke ved det, prøv localhost.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Lad dette felt være tomt hvis din server kører på standard port, eller hvis du ikke er sikker.';
$txt['db_settings_username'] = 'Brugernavn';
$txt['db_settings_username_info'] = 'Angiv det brugernavn der kræves for at forbinde til din database her.<br />Hvis du ikke ved hvad det er, så prøv brugernavnet fra din FTP konto, de er ofte ens.';
$txt['db_settings_password'] = 'Kodeord';
$txt['db_settings_password_info'] = 'Her angives kodeordet der kræves for forbindelse til din database.<br />Hvis du ikke ved hvad det er, så prøv kodeordet til din FTP konto.';
$txt['db_settings_database'] = 'Databasenavn';
$txt['db_settings_database_info'] = 'Angiv navnet på databasen du ønsker ElkArte skal gemme sine data i.';
$txt['db_settings_database_info_note'] = 'Hvis databasen ikke eksisterer, vil installationsprogrammet forsøge at oprette den.';
$txt['db_settings_database_file'] = 'Database filnavn';
$txt['db_settings_database_file_info'] = 'Dette er navnet på filen hvori ElkArte data skal gemmes. Vi anbefaler at du bruger det tilfædigt genererede navn for denne og indstiller stien til denne fil så den er uden for det offentlige område på din webserver.';
$txt['db_settings_prefix'] = 'Tabel prefiks';
$txt['db_settings_prefix_info'] = 'Prefiks for hver tabel i databasen. <strong>Installer ikke to forummer med samme prefix!</strong><br />Værdien tillader installation af flere forummer i samme database.';
$txt['db_populate'] = 'Sammenfattet database';
$txt['db_populate_info'] = 'Dine indstillinger er nu blevet gemt og databasen er blevet oprettet med alle de data der er krævet for at få dit forum op at køre. Opsummering på oprettelsen:';
$txt['db_populate_info2'] = 'Klik på &quot;Fortsæt&quot; for at fortsætte til siden med oprettelse af administrator kontoen.';
$txt['db_populate_inserts'] = 'Indsatte %1$d rækker.';
$txt['db_populate_tables'] = 'Oprettede %1$d tabeller.';
$txt['db_populate_insert_dups'] = 'Ignorerede %1$d duplikerede indsættelser.';
$txt['db_populate_table_dups'] = 'Ignorerede %1$d duplikerede tabeller.';

$txt['user_settings'] = 'Opret din konto';
$txt['user_settings_info'] = 'Installationsprogrammet vil nu oprette en ny administrator konto for dig.';
$txt['user_settings_username'] = 'Dit brugernavn';
$txt['user_settings_username_info'] = 'Vælg det navn du vil bruge til at logge ind med.';
$txt['user_settings_password'] = 'Kodeord';
$txt['user_settings_password_info'] = 'Udfyld dit ønskede kodeord her, og husk godt på det!';
$txt['user_settings_again'] = 'Kodeord';
$txt['user_settings_again_info'] = '(blot som bekræftigelse.)';
$txt['user_settings_email'] = 'E-mail-adresse';
$txt['user_settings_email_info'] = 'Angiv også din e-mail-adresse.  <strong>Dette skal være en gyldig e-mail-adresse.</strong>';
$txt['user_settings_database'] = 'Database-kodeord';
$txt['user_settings_database_info'] = 'Installationsprogrammet kræver af sikkerhedsmæssige grunde, at du angiver kodeordet til databasen for at oprette en administrator konto.';
$txt['user_settings_skip'] = 'Spring over';
$txt['user_settings_skip_sure'] = 'Er du sikker på du vil springe over oprettelsen af en admin konto?';
$txt['user_settings_proceed'] = 'Færdig';

$txt['ftp_checking_writable'] = 'Kontrollerer om filer er skrivbare';
$txt['ftp_setup'] = 'FTP Forbindelses-information';
$txt['ftp_setup_info'] = 'Dette installationsprogram kan ikke fikse filerne der skal gøres skrivbare og som ikke er. Hvis dette ikke virker for dig, er du nødt til manuelt at gøre filerne skrivbare. Bemærk venligst at dette i øjeblikket ikke understøtter SSL.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'Dette skal være server adresse og port til din FTP server.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'Brugernavn';
$txt['ftp_username_info'] = 'Brugernavnet til at logge ind med. <em>Dette bliver ikke gemt nogen steder.</em>';
$txt['ftp_password'] = 'Kodeord';
$txt['ftp_password_info'] = 'Kodeordet til at logge ind med. <em>Dette vil ikke blive gemt nogen steder.</em>';
$txt['ftp_path'] = 'Installationssti';
$txt['ftp_path_info'] = 'Dette er den <em>relative</em> sti du benytter på din FTP server.';
$txt['ftp_path_found_info'] = 'Stien i ovenstående boks blev automatisk fundet.';
$txt['ftp_connect'] = 'Forbind';
$txt['ftp_setup_why'] = 'Hvad er dette step godt for?';
$txt['ftp_setup_why_info'] = 'Nogle filer skal være skrivbare for at ElkArte virker korrekt.  Dette trin giver dig mulighed for at lade installationen lave dem skrivbare for dig. I nogle tilfælde vil dette ikke virke - i så fald, chmod de følgende filer 777 (skrivbare, 755 på nogle hosts):';
$txt['ftp_setup_again'] = 'for igen at teste at disse filer er skrivbare.';

$txt['error_php_too_low'] = 'Advarsel!  Det ser ikke ud til at du har en version af PHP installeret på din server som understøtter ElkArte\'s <strong>minimum installationskrav</strong>.<br />Hvis du ikke er hosten, skal du spørge din host om at opgradere eller bruge en anden host - ellers, opgrader PHP til en nyere version.<br /><br />Hvis du med sikkerhed ved at din PHP version er høj nok kan du forsøge at fortsætte, dette kan dog på det kraftligste ikke anbefales.';
$txt['error_missing_files'] = 'Vitale filer i mappen til dette script kunne ikke findes!<br /><br />Vær sikker på du uploadede hele installationspakken, inklusive sql filen, og forsøg så igen.';
$txt['error_session_save_path'] = 'Informer venligst din host at <strong>session.save_path specificeret i php.ini</strong> ikke er gyldig! Den skal ændres til en mappe der <strong>eksisterer</strong>, og som er <strong>skrivbar</strong> under den bruger PHP kører under.<br />';
$txt['error_windows_chmod'] = 'Du er på en windows server, og nogle vitale filer er ikke skrivbare. Spørg venligst din host om at give <strong>skrive rettigheder</strong> til brugeren PHP kører under for filerne i din ElkArte installation. De følgende filer eller mapper skal være skrivbare:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Det er ikke muligt at forbinde til FTP-serveren med den kombination af detaljer.';
$txt['error_db_file'] = 'Kan ikke finde kilden til database scriptet! Check venligst at filen %1$s ligger indenfor roden af mappen til forummet.';
$txt['error_db_connect'] = 'Kan ikke forbinde til database serveren med de angivne data.<br /><br />Hvis du ikke er sikker på hvad der skal angives, bør du kontakte din host.';
$txt['error_db_too_low'] = 'Database versionen du benytter er meget gammel og møder ikke ElkArte\'s minimumskrav.<br /><br />Spørg venglist din host om enten at opgradere den eller give adgang til en ny, og hvis de ikke vil det, prøv en anden host.';
$txt['error_db_database'] = 'Installationen var ikke i stand til at få adgang til databasen: &quot;<em>%1$s</em>&quot;.  Hos nogle hosts, er du nødt til at oprette databasen i dit administrationspanel før ElkArte kan bruge den. Nogle tilføjer også et præfix - såsom dit brugernavn - til dine database navne.';
$txt['error_db_queries'] = 'Nogle af forespørgslerne blev ikke udført korrekt. Dette kan skyldes en ikke understøttet (udviklings- eller gammel) version af din database software.<br /><br />Teknisk information om forespørgslerne:';
$txt['error_db_queries_line'] = 'Linie #';
$txt['error_db_missing'] = 'Installationen var ikke i stand at finde database understøttelse i PHP som ElkArte kan bruge.  Undersøg venligst hos din host om PHP er kompileret med den ønskede database, eller om de rette udvidelser er indlæst.  ElkArte understøtter de følgende udvidelser: &quot;%1$s&quot;';
$txt['error_db_script_missing'] = 'Installationsprogrammet kunne ikke finde et installationsscript til den fundne database. Check venligst at du har uploaded det nødvendige installationsscript til dit forums mappe, f.eks &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Installationsprogrammet var ikke i stand til at detektere understøttelse af sessions i din PHP servers installation. Undersøg hos din host om PHP er kompileret med understøttelse af sessions (faktisk skal det specifikt compileres uden!)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'You typed in two completely different passwords!';
$txt['error_user_settings_no_password'] = 'Dit kodeord skal være mindst fire karakterer lang.';
$txt['error_user_settings_taken'] = 'Beklager, en bruger er allerede registreret med det brugernavn og/eller email adresse.<br /><br />En ny konto blev ikke oprettet.';
$txt['error_user_settings_query'] = 'En databasefejl opstod under oprettelsen af en administrator. Fejlen var:';
$txt['error_subs_missing'] = 'Ikke i stand til at finde sources/Subs.php filen.  Kontroller om filen var korrekt uploadet og forsøg igen.';
$txt['error_db_alter_priv'] = 'Den database konto du specificerede har ikke rettigheder til ALTER, CREATE, og/eller DROP tabeller i databasen; dette er en nødvendighed for at ElkArte kan fungere korrekt.';
$txt['error_versions_do_not_match'] = 'Installationen har opdaget en anden version af ElkArte allerede er installeret med de samme oplysninger.  Hvis du forsøger at opgradere, skal du bruge opgraderingen, ikke installationen.<br /><br />Ellers, kan du angive andre oplysninger, eller lave en backup og derefter slette de data der i øjeblikket er i databasen.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'Den nuværende version af din database understøtter ikke brugen af UTF-8 karaktersæt. Du kan ikke installere ElkArte';
$txt['error_valid_email_needed'] = 'Du har ikke angivet en gyldig e-mail-adresse.';
$txt['error_already_installed'] = 'Installationen har opdaget at du allerede har ElkArte installeret. Det er kraftigt anbefalet at du <strong>ikke</strong> forsøger at overskrive en eksisterende installation - fortsættelse af installationen <strong>kan resultere i tab og korruption af eksisterende data</strong>.<ul><li>Hvis du lige har færdiggjort installeringen af dit forum, slet da installations mappen fra din server. {try_delete}</li><li>Hvis du ønsker at opgradere, benyt da <a href="./upgrade.php"><strong>opdaterings script</strong></a>.</li><li>Hvis du ønsker at overskrive din eksisterende installation, inklusiv alt data, er det anbefalet at du sletter alle eksisterende database tabeller og erstatter Settings.php og forsøger igen.</li></ul>';
$txt['error_no_settings'] = 'Det ser ud til at Settings.php og/eller Settings_bak.php mangler fra standard mappen på dit forum, ElkArte vil forsøge at omdøbe prøve filerne inkluderet med installationen. Hvis denne aktion fejler, omdøb da henholdsvis Settings.sample.php og Settings_bak.sample.php til Settings.php og Settings_bak.php før du kører dette script.';
$txt['error_settings_do_not_exist'] = 'Elkarte er ikke i stand til at finde eller oprette filerne <strong>%1$s</strong>. Prøv at brug ftp til at gå til mappen på dit forum og omdøb prøve filerne inkluderet med installations pakken før du prøver at køre dette script igen: <ul>%2$s</ul> Hvis nogen af filerne ikke eksisterer, opret da en tom fil med det samme navn.';
$txt['error_warning_notice'] = 'Advarsel!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Du skal angive et navn til database filen til SQLite.';
$txt['error_db_prefix_numeric'] = 'den valgte database understøtter ikke brugen af numeriske prefikser.';
$txt['error_invalid_characters_username'] = 'Ugyldig karakter i brugernavn.';
$txt['error_username_too_long'] = 'Brugernavn skal være mindre end 25 karakterer.';
$txt['error_username_left_empty'] = 'Feltet til brugernavn blev ikke udfyldt.';
$txt['error_db_filename_exists'] = 'Databasen du forsøger at oprette, eksisterer allerede. Slet venligst den aktuelle database fil eller angiv et andet navn.';
$txt['error_db_prefix_reserved'] = 'Prefikset du angav er et reserveret prefiks. Angiv venligst et andet prefiks.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Opgraderingsværktøj';
$txt['upgrade_warning'] = 'Advarsel!';
$txt['upgrade_critical_error'] = 'kritisk fejl!';
$txt['upgrade_continue'] = 'Fortsæt';
$txt['upgrade_retry'] = 'Prøv igen';
$txt['upgrade_skip'] = 'Spring over';
$txt['upgrade_note'] = 'Bemærk!';
$txt['upgrade_step'] = 'Trin';
$txt['upgrade_steps'] = 'Trin';
$txt['upgrade_progress'] = 'Progres';
$txt['upgrade_overall_progress'] = 'Samlet fremskridt';
$txt['upgrade_step_progress'] = 'Aktuel fremskridt';
$txt['upgrade_time_elapsed'] = 'Tid gået';
$txt['upgrade_time_mins'] = 'minutter';
$txt['upgrade_time_secs'] = 'sekunder';

$txt['upgrade_incomplete'] = 'Ufuldendt';
$txt['upgrade_not_quite_done'] = 'Ikke helt færdig endnu!';
$txt['upgrade_paused_overload'] = 'Opgraderingen er blevet stoppet midlertidig for ikke at overbelaste din server. Bare rolig, intet er galt - klik blot på <label for="contbutt">fortsæt knappen</label> herunder for at fortsætte.';

$txt['upgrade_ready_proceed'] = 'Tak fordi du har valgt at opgradere til ElkArte %1$s. Alle filer ser ud til at være på plads, og vi er klar til at fortsætte.';

$txt['upgrade_error_script_js'] = 'Opgraderingsscriptet kan ikke finde script.js eller filen er uddateret. Du bør sikre dig at stierne til tema er korrekte. Du kan downloade indstillingscheck og reparer script fra <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte værktøjer</a>.';

$txt['upgrade_warning_lots_data'] = 'Dette opgraderingsscript har fundet at dit forum indeholder en masse data der behøves at opdatere. Denne proces kan tage en del tid afhængig af din server og størrelsen på dit forum, og for meget store fora (~300,000 indlæg) kan det tage flere timer at gennemføre.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';