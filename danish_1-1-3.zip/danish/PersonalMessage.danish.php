<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Personligt beskedindeks';
$txt['pm_add'] = 'Tilføj';
$txt['make_bcc'] = 'Tilføj BCC';
$txt['pm_to'] = 'Til';
$txt['pm_bcc'] = 'Bcc';
$txt['inbox'] = 'Indbakke';
$txt['conversation'] = 'Samtale';
$txt['messages'] = 'Beskeder';
$txt['sent_items'] = 'Sendte beskeder';
$txt['new_message'] = 'Ny besked';
$txt['delete_message'] = 'Slet beskeder';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Slet alle beskeder i dit personlige beskedindeks';
$txt['delete_all_confirm'] = 'Er du sikker på du vil slette alle beskeder?';

$txt['delete_selected_confirm'] = 'Er du sikker på du vil slette alle de valgte personlige beskeder?';

$txt['sent_to'] = 'Sendt til';
$txt['reply_to_all'] = 'Svar til alle';
$txt['delete_conversation'] = 'Slet samtale';

$txt['pm_capacity'] = 'Kapacitet';
$txt['pm_currently_using'] = '%1$s beskeder, %2$s%% fuld.';
$txt['pm_sent'] = 'Din meddelelse blev afsendt.';

$txt['pm_error_user_not_found'] = 'Det var ikke muligt at finde medlemmet \'%1$s\'.';
$txt['pm_error_ignored_by_user'] = 'Brugeren \'%1$s\' har blokeret for personlige beskeder fra dig.';
$txt['pm_error_data_limit_reached'] = 'Personlig besked kunne ikke sendes til \'%1$s\' da deres indbakke er fuld.';
$txt['pm_error_user_cannot_read'] = 'Brugeren \'%1$s\' kan ikke modtage personlige beskeder.';
$txt['pm_successfully_sent'] = 'Din personlige besked blev sendt til \'%1$s\'.';
$txt['pm_send_report'] = 'Send rapport';
$txt['pm_undisclosed_recipients'] = 'Unavngivne modtagere';
$txt['pm_too_many_recipients'] = 'Du kan ikke sende personlige beskeder til mere end %1$d modtagere på en gang.';

$txt['pm_read'] = 'Læs';
$txt['pm_replied'] = 'Besvaret til';
$txt['pm_mark_unread'] = 'Marker som ulæst';

// Message Pruning.
$txt['pm_prune'] = 'Ryd op i beskeder';
$txt['pm_prune_desc'] = 'Slet alle personlige beskeder som er ældre end %1$s dage.';
$txt['pm_prune_warning'] = 'Er du sikker på du vil rydde op i personlige beskeder?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Yderligere handlinger';
$txt['pm_actions_delete_selected'] = 'Slet markerede';
$txt['pm_actions_filter_by_label'] = 'Sorter efter mærkat';
$txt['pm_actions_go'] = 'Start';

// Manage Labels Screen.
$txt['pm_apply'] = 'Udfør';
$txt['pm_manage_labels'] = 'Administrer mærkater';
$txt['pm_labels_delete'] = 'Er du sikker på du vil slette de valgte mærkater?';
$txt['pm_labels_desc'] = 'Her kan du tilføje, redigere og slette mærkater du anvender i dit personlige beskedcenter.';
$txt['pm_label_add_new'] = 'Tilføj nyt mærkat';
$txt['pm_label_name'] = 'Mærkat navn';
$txt['pm_labels_no_exist'] = 'Du har i øjeblikket ikke oprettet nogen mærkater!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Mærkat';
$txt['pm_msg_label_title'] = 'Mærkat besked';
$txt['pm_msg_label_apply'] = 'Tilføj mærkat';
$txt['pm_msg_label_remove'] = 'Fjern mærkat';
$txt['pm_msg_label_inbox'] = 'Indbakke';
$txt['pm_sel_label_title'] = 'Mærkat valgt';

// Sidebar Headings.
$txt['pm_labels'] = 'Mærkat';
$txt['pm_messages'] = 'Beskeder';
$txt['pm_actions'] = 'Handlinger';
$txt['pm_preferences'] = 'Indstillinger';

$txt['pm_is_replied_to'] = 'Du har videresendt eller svaret på denne besked.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Rapporter til administrator';
$txt['pm_report_title'] = 'Rapporter personlig besked';
$txt['pm_report_desc'] = 'Her kan du anmelde de personlige beskeder du modtager til en administrator i forummet. Du skal skrive en beskrivelse på hvorfor du anmelder beskeden, da dette vil blive sendt sammen med indholdet af den originale besked.';
$txt['pm_report_admins'] = 'Administrator anmeldelsen skal sendes til';
$txt['pm_report_all_admins'] = 'Send til alle forumadministratorer';
$txt['pm_report_reason'] = 'Grunden til du anmelder denne besked';
$txt['pm_report_message'] = 'Anmeld beskeden';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[REPORT]';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} har anmeldt den personlige besked herunder, sent af {SENDER}, af følgende grund:';
$txt['pm_report_pm_other_recipients'] = 'Andre modtagere af beskeden inkluderer:';
$txt['pm_report_pm_hidden'] = '%1$d skjult(e) modtager(e)';
$txt['pm_report_pm_unedited_below'] = 'Herunder er det originale indhold af beskeden der blev anmeldt:';
$txt['pm_report_pm_sent'] = 'Sendt:';

$txt['pm_report_done'] = 'Tak fordi du du sendte denne anmeldelse. Du vil snarest høre fra teamet af administratorer.';
$txt['pm_report_return'] = 'Tilbage til Indbakke';

$txt['pm_search_title'] = 'Søg i personlige beskeder';
$txt['pm_search_bar_title'] = 'Søg i beskeder';
$txt['pm_search_text'] = 'Søg efter';
$txt['pm_search_go'] = 'Søg';
$txt['pm_search_advanced'] = 'Vis avancerede indstillinger';
$txt['pm_search_simple'] = 'Skjul avancerede indstillinger';
$txt['pm_search_user'] = 'Efter bruger';
$txt['pm_search_match_all'] = 'Match alle ord';
$txt['pm_search_match_any'] = 'Match ethvert ord';
$txt['pm_search_options'] = 'Valgmuligheder';
$txt['pm_search_post_age'] = 'Alder på indlæg';
$txt['pm_search_show_complete'] = 'Vis fulde beskeder i søgeresultatet.';
$txt['pm_search_subject_only'] = 'Søg kun efter emne og afsender.';
$txt['pm_search_sent_only'] = 'Søg kun i sendt post';
$txt['pm_search_between'] = 'mellem';
$txt['pm_search_between_and'] = 'og';
$txt['pm_search_between_days'] = 'dage';
$txt['pm_search_order'] = 'Søge rækkefølge';
$txt['pm_search_choose_label'] = 'Vælg hvilke mærkater der skal søges efter, eller søg alle';

$txt['pm_search_results'] = 'Søgeresultater';
$txt['pm_search_none_found'] = 'Ingen beskeder fundet';

$txt['pm_search_orderby_relevant_first'] = 'Mest relevante først';
$txt['pm_search_orderby_recent_first'] = 'Nyeste først';
$txt['pm_search_orderby_old_first'] = 'Ældste først';

$txt['pm_visual_verification_label'] = 'Bekræftigelse';
$txt['pm_visual_verification_desc'] = 'Indtast venligst koden i billedet herover, for at sende denne personlige besked.';

$txt['pm_settings'] = 'Skift indstillinger';
$txt['pm_change_view'] = 'Skift visning';

$txt['pm_manage_rules'] = 'Administrer regler';
$txt['pm_manage_rules_desc'] = 'Besked regler tillader dig automatisk at sortere indkomne beskeder efter kriterier du definerer. Herunder er de regler du i øjeblikket har sat op. For at redigere en regel skal du blot klikke på navnet på reglen.';
$txt['pm_rules_none'] = 'Du har endnu ikke opsat nogle besked regler.';
$txt['pm_rule_title'] = 'Regel';
$txt['pm_add_rule'] = 'Tilføj ny regel';
$txt['pm_apply_rules'] = 'Aktiver regler nu';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Er du sikker på du vil anvende reglerne på alle personlige beskeder?';
$txt['pm_edit_rule'] = 'Rediger regel';
$txt['pm_rule_save'] = 'Gem regel';
$txt['pm_delete_selected_rule'] = 'Slet valgte regler';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Er du sikker på du vil slette de valgte regler?';
$txt['pm_rule_name'] = 'Navn';
$txt['pm_rule_name_desc'] = 'Navnet denne regel skal huskes efter';
$txt['pm_rule_name_default'] = '[NAVN]';
$txt['pm_rule_description'] = 'Beskrivelse';
$txt['pm_rule_not_defined'] = 'Tilføj nogle kriterier for at bygge denne regels beskrivelse.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>Bemærk:</strong> Det ser ud til at du har deaktiveret javascript. Vi anbefaler på det kraftigste at du aktiverer javascript for at bruge denne funktion.</span> ';
$txt['pm_rule_criteria'] = 'Kriterie';
$txt['pm_rule_criteria_add'] = 'Tilføj kriterie';
$txt['pm_rule_criteria_pick'] = 'Vælg kriterie';
$txt['pm_rule_mid'] = 'Afsender navn';
$txt['pm_rule_gid'] = 'Afsender gruppe';
$txt['pm_rule_sub'] = 'Beskedens emne indeholder';
$txt['pm_rule_msg'] = 'Beskedfeltet indeholder';
$txt['pm_rule_bud'] = 'Afsender er en ven';
$txt['pm_rule_sel_group'] = 'Vælg gruppe';
$txt['pm_rule_logic'] = 'Når kriterier checkes';
$txt['pm_rule_logic_and'] = 'Alle kriterier skal opfyldes';
$txt['pm_rule_logic_or'] = 'Ethvert kriterie kan opfyldes';
$txt['pm_rule_actions'] = 'Handlinger';
$txt['pm_rule_sel_action'] = 'Vælg en handling';
$txt['pm_rule_add_action'] = 'Tilføj handling';
$txt['pm_rule_label'] = 'Mærk beskeden med';
$txt['pm_rule_sel_label'] = 'Vælg mærkat';
$txt['pm_rule_delete'] = 'Slet besked';
$txt['pm_rule_no_name'] = 'Du glemte at angive et navn for reglen.';
$txt['pm_rule_no_criteria'] = 'En regel skal indeholde mindst et kriterie eller en handling.';
$txt['pm_rule_too_complex'] = 'Reglen du er ved at oprette er for lang til at blive gemt. Prøv at bryde den op i mindre regler.';

$txt['pm_readable_and'] = '<em>og</em>';
$txt['pm_readable_or'] = '<em>eller</em>';
$txt['pm_readable_start'] = 'Hvis ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'beskeden er fra &quot;{MEMBER}&quot;';
$txt['pm_readable_group'] = 'afsenderen er fra gruppen &quot;{GROUP}&quot;';
$txt['pm_readable_subject'] = 'beskedens emne indeholder &quot;{SUBJECT}&quot;';
$txt['pm_readable_body'] = 'beskedfeltet indeholder &quot;{BODY}&quot;';
$txt['pm_readable_buddy'] = 'afsender er en ven';
$txt['pm_readable_label'] = 'aktiver mærkatet &quot;{LABEL}&quot;';
$txt['pm_readable_delete'] = 'slet beskeden';
$txt['pm_readable_then'] = '<b>så</b>';