<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Show Drafts';
$txt['drafts_show_desc'] = 'This area shows all the drafts you currently have saved. From here you can edit them before posting, or you can delete them';

// misc
$txt['drafts'] = 'Rascunhos';
$txt['draft_save'] = 'Salvar Rascunho';
$txt['draft_save_note'] = 'This will save the text of your post, but it will not save attachments, poll or event information.';
$txt['draft_none'] = 'Você não tem rascunhos';
$txt['draft_edit'] = 'Editar rascunho';
$txt['draft_load'] = 'Carregar rascunhos';
$txt['draft_hide'] = 'Ocultar rascunhos';
$txt['draft_delete'] = 'Apagar rascunho';
$txt['draft_days_ago'] = '%s dias atrás';
$txt['draft_retain'] = 'isso será retido por %s dias a mais';
$txt['draft_remove'] = 'Remover este rascunho';
$txt['draft_remove_selected'] = 'Remover todos os rascunhos selecionados';
$txt['draft_saved'] = 'The contents have been saved as a draft and will be accessible from the <a href="%1$s">Show Drafts area</a> of your profile.';
$txt['draft_pm_saved'] = 'The contents have been saved as a draft and will be accessible from the <a href="%1$s">Show Drafts area</a> of your message center.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Enable automatic saving of drafts';
$txt['drafts_autosave_enabled_subnote'] = 'This will automatically save user drafts in the background on a given frequency.  The user must also have the proper permissions';
$txt['drafts_keep_days'] = 'Maximum number of days to keep a draft';
$txt['drafts_keep_days_subnote'] = 'Enter 0 to keep drafts indefinitely';
$txt['drafts_autosave_frequency'] = 'How often should drafts be autosaved?';
$txt['drafts_autosave_frequency_subnote'] = 'The minimum allowable value is 30 seconds';
$txt['drafts_pm_enabled'] = 'Enable the saving of PM drafts';
$txt['drafts_post_enabled'] = 'Enable the saving of Post drafts';
$txt['drafts_none'] = 'No Subject';
$txt['drafts_saved'] = 'Draft was successfully saved';