<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Tanggal';
$txt['modlog_member'] = 'Anggota';
$txt['modlog_position'] = 'Posisi';
$txt['modlog_action'] = 'Aksi';
$txt['modlog_ip'] = 'IP';
$txt['modlog_search_result'] = 'Hasil Pencarian';
$txt['modlog_total_entries'] = 'Total Entri';
$txt['modlog_ac_approve_topic'] = 'Setujui topik &quot;{topic}&quot; oleh &quot;{member}&quot;';
$txt['modlog_ac_unapprove_topic'] = 'Unapproved topic &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_approve'] = 'Setujui pesan &quot;{subject}&quot; dalam &quot;{topic}&quot; oleh &quot;{member}&quot;';
$txt['modlog_ac_unapprove'] = 'Unapproved message &quot;{subject}&quot; in &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_lock'] = 'Kunci &quot;{topic}&quot;';
$txt['modlog_ac_warning'] = 'Diperingatkan {member} atas &quot;{message}&quot; ';
$txt['modlog_ac_unlock'] = 'Buka kunci &quot;{topic}&quot;';
$txt['modlog_ac_sticky'] = 'Pinned &quot;{topic}&quot;';
$txt['modlog_ac_unsticky'] = 'Unpinned &quot;{topic}&quot;';
$txt['modlog_ac_delete'] = 'Dihapus &quot;{subject}&quot; oleh &quot;{member}&quot; dari &quot;{topic}&quot;';
$txt['modlog_ac_delete_member'] = 'Dihapus anggota &quot;{name}&quot;';
$txt['modlog_ac_remove'] = 'Dihapus topik &quot;{topic}&quot; dari &quot;{board}&quot;';
$txt['modlog_ac_modify'] = 'Diedit &quot;{message}&quot; oleh &quot;{member}&quot;';
$txt['modlog_ac_merge'] = 'Digabung topike untuk membuat &quot;{topic}&quot;';
$txt['modlog_ac_split'] = 'Dipisahkan &quot;{topic}&quot; untuk membuat &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = 'Dipindahkan &quot;{topic}&quot; dari &quot;{board_from}&quot; ke &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Mengedit profil &quot;{member}&quot;';
$txt['modlog_ac_pruned'] = 'Menghapus beberapa tulisan lebih lama dari {days} hari';
$txt['modlog_ac_news'] = 'Mengedit berita';
$txt['modlog_enter_comment'] = 'Memasukkan Komentar Moderasi';
$txt['modlog_moderation_log'] = 'Log Moderasi';
$txt['modlog_moderation_log_desc'] = 'Di bawah adalah daftar semua tindakan moderasi yang sudah dilakukan oleh moderator forum.<br /><strong>Harap dicatat:</strong> Entri tidak bisa dihapus dari log ini sampai setidaknya dua-puluh empat jam lamanya.';
$txt['modlog_no_entries_found'] = 'Tidak ada entri log moderasi untuk saat ini.';
$txt['modlog_remove'] = 'Hapus Yang Dipilih';
$txt['modlog_removeall'] = 'Clear Log';
$txt['modlog_remove_selected_confirm'] = 'Are you sure you want to delete the selected log entries?';
$txt['modlog_remove_all_confirm'] = 'Are you sure you want to completely clear the log?';
$txt['modlog_go'] = 'Ayo';
$txt['modlog_add'] = 'Tambah';
$txt['modlog_search'] = 'Pencarian Cepat';
$txt['modlog_by'] = 'Dengan';
$txt['modlog_id'] = '<em>(ID:%1$d)</em>';

$txt['modlog_ac_add_warn_template'] = 'Ditambahkan template peringatan: &quot;{template}&quot;';
$txt['modlog_ac_modify_warn_template'] = 'Diedit template peringatan: &quot;{template}&quot;';
$txt['modlog_ac_delete_warn_template'] = 'Dihapus template peringatan: &quot;{template}&quot;';

$txt['modlog_ac_ban'] = 'Ditambahkan pemicu pengucilan:';
$txt['modlog_ac_ban_update'] = 'Edited ban triggers:';
$txt['modlog_ac_ban_remove'] = 'Removed ban triggers:';
$txt['modlog_ac_ban_trigger_member'] = ' <em>Anggota:</em> {member}';
$txt['modlog_ac_ban_trigger_email'] = ' <em>Email:</em> {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = ' <em>IP:</em> {ip_range}';
$txt['modlog_ac_ban_trigger_hostname'] = ' <em>Nama host:</em> {hostname}';

$txt['modlog_admin_log'] = 'Log Administrasi';
$txt['modlog_admin_log_desc'] = 'Di bawah ini adalah daftar semua tindakan administrasi yang sudah dicatat pada forum Anda.<br /><strong>Harap dicatat:</strong> Entri tidak bisa dihapus dari log ini sampai setidaknya dua-puluh empat jam lamanya.';
$txt['modlog_admin_log_no_entries_found'] = 'Tidak ada entri log administrasi untuk saat ini.';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Dimutakhirkan forum ke versi {version}';
$txt['modlog_ac_install'] = 'Diinstalasi versi {version}';
$txt['modlog_ac_add_board'] = 'Ditambahkan board baru: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Diedit board &quot;{board}&quot;';
$txt['modlog_ac_delete_board'] = 'Dihapus board &quot;{boardname}&quot;';
$txt['modlog_ac_add_cat'] = 'Ditambahkan kategori baru, &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Diedit kategori &quot;{catname}&quot;';
$txt['modlog_ac_delete_cat'] = 'Dihapus kategori &quot;{catname}&quot;';

$txt['modlog_ac_delete_group'] = 'Dihapus grup &quot;{group}&quot;';
$txt['modlog_ac_add_group'] = 'Ditambahkan grup &quot;{group}&quot;';
$txt['modlog_ac_edited_group'] = 'Diedit grup &quot;{group}&quot;';
$txt['modlog_ac_added_to_group'] = 'Ditambahkan &quot;{member}&quot; ke grup &quot;{group}&quot;';
$txt['modlog_ac_removed_from_group'] = 'Dihapus &quot;{member}&quot; dari grup &quot;{group}&quot;';
$txt['modlog_ac_removed_all_groups'] = 'Dihapus &quot;{member}&quot; dari semua grup';

$txt['modlog_ac_remind_member'] = 'Dikirimkan pengingat ke &quot;{member}&quot; untuk mengaktifkan akunnya';
$txt['modlog_ac_approve_member'] = 'Menyetujui/Mengaktifkan akun &quot;{member}&quot;';
$txt['modlog_ac_newsletter'] = 'Surat berkala dikirimkan';

$txt['modlog_ac_install_package'] = 'Instal paket baru: &quot;{package}&quot;, versi {version}';
$txt['modlog_ac_upgrade_package'] = 'Paket yang diupgrade: &quot;{package}&quot; ke versi {version}';
$txt['modlog_ac_uninstall_package'] = 'Paket yang dihapus : &quot;{package}&quot;, versi {version}';

$txt['modlog_ac_database_backup'] = 'Database backup taken by {member}.';
$txt['modlog_ac_editing_theme'] = '{member} edited a theme.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Mengembalikan topik &quot;{topic}&quot; dari &quot;{board}&quot; ke &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Mengembalikan tulisan dari &quot;{subject}&quot; ke topik &quot;{topic}&quot; dalam board &quot;{board}&quot;.';

$txt['modlog_parameter_guest'] = '<em>Pengunjung</em>';

$txt['modlog_ac_approve_attach'] = 'Approved &quot;{filename}&quot; in &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Removed unapproved &quot;{filename}&quot; in &quot;{message}&quot;';