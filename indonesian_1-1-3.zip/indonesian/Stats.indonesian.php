<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Terlama Online';

$txt['stats_center'] = 'Pusat Statistik';
$txt['general_stats'] = 'Statistik Umum';
$txt['top_posters'] = '10 Penulis Teratas';
$txt['top_boards'] = '10 Board Teratas';
$txt['forum_history'] = 'Histori Forum (menggunakan jarak waktu forum)';
$txt['stats_new_topics'] = 'Topik Baru';
$txt['stats_new_posts'] = 'Tulisan Baru';
$txt['stats_new_members'] = 'Anggota Baru';
$txt['page_views'] = 'Halaman Dilihat';
$txt['top_topics_replies'] = '10 Topik Teratas (Jawaban)';
$txt['top_topics_views'] = '10 Topik Teratas (Dilihat)';
$txt['yearly_summary'] = 'Ringkasan Tahunan';
$txt['top_starters'] = 'Memulai Topik Terbanyak';
$txt['most_time_online'] = 'Terlama Online';

$txt['average_members'] = 'Rata-rata pendaftaran per hari';
$txt['average_posts'] = 'Rata-rata tulisan per hari';
$txt['average_topics'] = 'Rata-rata topik per hari';
$txt['average_online'] = 'Rata-rata online per hari';
$txt['users_online'] = 'Pengguna Online';
$txt['emails_sent'] = 'Average Emails per day';
$txt['users_online_today'] = 'Online Hari Ini';
$txt['num_hits'] = 'Total halaman dilihat';
$txt['average_hits'] = 'Rata-rata halaman dilihat per hari';

$txt['ssi_comment'] = 'komentar';
$txt['ssi_comments'] = 'komentar';
$txt['ssi_write_comment'] = 'Tulis Komentar';
$txt['ssi_no_guests'] = 'Anda tidak bisa menetapkan board yang tidak mengijinkan pengunjung.  Silahkan periksa ID board sebelum mencoba lagi.';
$txt['xml_rss_desc'] = 'Live information from {forum_name}';