<?php
// Version: 1.1; ManageSmileys

$txt['smiley_sets_save'] = 'Ssimpan Perubahan';
$txt['smiley_sets_add'] = 'New Smiley Set';
$txt['smiley_sets_delete'] = 'Hapus yang dipilih';
$txt['smiley_sets_confirm'] = 'Anda yakin ingin menhapus set smiley ini?\\n\\nCatatan: Ini tidak akan menghapus gambar, hanya pilihannya saja.';
$txt['smiley_sets_none'] = 'There are currently no smiley sets.';

$txt['setting_smiley_sets_default'] = 'Set Smiley Standar';
$txt['setting_smiley_sets_enable'] = 'Hidupkan pemilihan set smiley oleh anggota';
$txt['setting_smiley_enable'] = 'Hidupkan smiley dikustomisasi';
$txt['setting_smileys_url'] = 'Basis URL untuk semua set smiley';
$txt['setting_smileys_dir'] = 'Path absolut ke semua set smiley';
$txt['setting_messageIcons_enable'] = 'Hidupkan ikon pesan dikustomisasi';
$txt['setting_messageIcons_enable_note'] = '(sebaliknya, ikon pesan standar yang akan dipakai.)';
$txt['groups_manage_smileys'] = 'Grup yang diijinkan untuk mengatur smiley dan ikon pesan';

$txt['smiley_sets_name'] = 'Nama';
$txt['smiley_sets_url'] = 'URL';
$txt['smiley_sets_default'] = 'Standar';

$txt['smileys_add_method'] = 'Sumber Gambar';
$txt['smileys_add_existing'] = 'Use existing file';
$txt['smileys_add_upload'] = 'Upload new smiley';
$txt['smileys_add_upload_choose'] = 'File yang di-upload';
$txt['smileys_add_upload_choose_desc'] = 'Gambar untuk dipakai oleh semua set smiley.';
$txt['smileys_add_upload_all'] = 'Gambar sama untuk semua set';
$txt['smileys_add_upload_for1'] = 'Gambar untuk';
$txt['smileys_add_upload_for2'] = 'set';

$txt['smileys_enable_note'] = '(sebaliknya, smiley standar yang akan dipakai.)';
$txt['smileys_code'] = 'Kode';
$txt['smileys_filename'] = 'Nama file';
$txt['smileys_description'] = 'Tooltip atau penjelasan';
$txt['smileys_remove'] = 'Hapus';
$txt['smileys_save'] = 'Ssimpan Perubahan';
$txt['smileys_delete'] = 'Hapus Smiley';
// Don't use entities in the below string.
$txt['smileys_delete_confirm'] = 'Anda yakin ingin menghapus smiley ini?';
$txt['smileys_with_selected'] = 'Dengan yang Dipilih';
$txt['smileys_make_hidden'] = 'Sembunyikan';
$txt['smileys_show_on_post'] = 'Show on post form';
$txt['smileys_show_on_popup'] = 'Show on popup';

$txt['smiley_settings_explain'] = 'Setelan ini mengijinkan Anda untuk mengubah set smiley standar, mengijinkan orang untuk memilih smiley sendiri serta menetapkan path dan data konfigurasi.';
$txt['smiley_editsets_explain'] = 'Set Smiley adalah grup smiley yang dapat dipilih oleh pengguna Anda.  Sebagai contoh, Anda dapat memiliki smiley kuning dan merah.<br />Di sini Anda dapat mengubah nama dan lokasi dari setiap set smiley - akan tetapi, ingat bahwa semua set berbagi smiley yang sama.';
$txt['smiley_editsmileys_explain'] = 'Change your smileys here by clicking on the smiley you want to modify. Remember that these smileys all have to exist in all the sets or some smileys won\'t show up.  Don\'t forget to save after you are done editing.';
$txt['smiley_setorder_explain'] = 'Ubah urutan smiley di sini.';
$txt['smiley_addsmiley_explain'] = 'Di sini Anda dapat menambah smiley baru - baik dari file yang sudah ada ataupun dengan meng-upload yang baru.';

$txt['smiley_set_select_default'] = 'Set Smiley Standar';
$txt['smiley_set_new'] = 'Create new Smiley Set';
$txt['smiley_set_modify_existing'] = 'Modify existing Smiley Set';
$txt['smiley_set_modify'] = 'Ubah';
$txt['smiley_set_import_directory'] = 'Impor smiley yang ada dalam direktori ini';
$txt['smiley_set_import_single'] = 'Ada satu smiley dalam set smiley ini yang belum diimpor. Klik';
$txt['smiley_set_import_multiple'] = 'Ada %1$d smiley pada direktori yang belum diimpor. Klik';
$txt['smiley_set_to_import_single'] = 'untuk mengimpornya sekarang.';
$txt['smiley_set_to_import_multiple'] = 'untuk mengimpornya sekarang.';

$txt['smileys_location'] = 'Lokasi';
$txt['smileys_location_form'] = 'Formulir tulisan';
$txt['smileys_location_hidden'] = 'Sembunyi';
$txt['smileys_location_popup'] = 'Popup';
$txt['smileys_modify'] = 'Ubah';
$txt['smileys_not_found_in_set'] = 'Smiley tidak ditemukan dalam set';
$txt['smileys_default_description'] = '(Sisipkan penjelasan)';
$txt['smiley_new'] = 'Tambah smiley baru';
$txt['smiley_modify_existing'] = 'Ubah smiley';
$txt['smiley_preview'] = 'Pratinjau';
$txt['smiley_preview_using'] = 'menggunakan set smiley';
$txt['smileys_confirm'] = 'Anda yakin ingin menghapus smiley ini?\\n\\nCatatan: Ini tidak akan menghapus gambar, hanya pilihan saja.';
$txt['smileys_location_form_description'] = 'Smiley ini akan terlihat di atas area teks, ketika menulis pesan baru pada forum atau Pesan Pribadi.';
$txt['smileys_location_popup_description'] = 'Smiley ini akan ditampilkan dalam popup ketika pengguna sudah mengklik \'[selengkapnya]\'';
$txt['smileys_move_select_destination'] = 'Pilih tujuan smiley';
$txt['smileys_move_select_smiley'] = 'Select smiley to move or drag it to the location you want';
$txt['smileys_move_here'] = 'Pindahkan smiley ke lokasi ini';
$txt['smileys_no_entries'] = 'Tidak ada smiley yang dikonfigurasi untuk saat ini.';
$txt['smileys_moved_done'] = 'Smiley successfully moved';
$txt['smileys_moved_fail'] = 'Unable to move smiley';

$txt['icons_edit_icons_explain'] = 'Dari sini Anda dapat mengubah ikon pesan mana yang tersedia dalam board Anda. Anda dapat menambah, mengedit dan menghapus ikon, juga membatasi pemakaiannya pada board tertentu.';
$txt['icons_edit_icons_all_boards'] = 'Available in all boards';
$txt['icons_board'] = 'Board';
$txt['icons_confirm'] = 'Anda yakin ingin menghapus ikon ini?\\n\\nCatatan ini hanya akan menghentikan penulis baru dari penggunaan ikon, gambar akan tetap ada.';
$txt['icons_add_new'] = 'Add new icon';

$txt['icons_edit_icon'] = 'Edit message icon';
$txt['icons_new_icon'] = 'New message icon';
$txt['icons_location_first_icon'] = 'As first icon';
$txt['icons_location_after'] = 'Setelah';
$txt['icons_filename_all_png'] = 'All files must be &quot;png&quot; files';
$txt['icons_no_entries'] = 'Tidak ada ikon pesan yang dikonfigurasi untuk saat ini.';
$txt['icons_reordered'] = 'Message Icons successfully reordered';
$txt['icons_reorder_note'] = 'You can change the message icon order by dragging and dropping an item to a new location in the list.';