<?php
// Version: 1.1; Reports

$txt['generate_reports_desc'] = 'Dari seksi ini Anda dapat membuat berbagai laporan untuk membantu administrasi forum Anda. Cukup ikuti langkah di bawah ini untuk memilih opsi pilihan Anda.';
$txt['generate_reports_continue'] = 'Lanjutkan';
$txt['generate_reports_type'] = 'Pilih Jenis Laporan';
$txt['gr_type_boards'] = 'Board';
$txt['gr_type_desc_boards'] = 'Laporan menampilkan setelan dan tingkat akses saat ini untuk setiap board pada forum Anda.';
$txt['gr_type_board_perms'] = 'Perijinan dengan Board';
$txt['gr_type_desc_board_perms'] = 'Buat laporan yang menampilkan setiap grup anggota yang berlaku di board yang berbeda dalam forum Anda.';
$txt['gr_type_member_groups'] = 'Grup anggota';
$txt['gr_type_desc_member_groups'] = 'Laporan menampilkan setelan untuk setiap grup anggota pada forum Anda.';
$txt['gr_type_group_perms'] = 'Perijinan Grup';
$txt['gr_type_desc_group_perms'] = 'Laporan atas perijinan yang dimiliki setiap grup anggota dalam forum.';
$txt['gr_type_staff'] = 'Staf';
$txt['gr_type_desc_staff'] = 'Laporan ini meringkas semua anggota yang saat ini memiliki posisi otoritas pada forum.';

$txt['full_member'] = 'Anggota Penuh';
$txt['results'] = 'Hasil';

// Board permissions
$txt['board_perms_permission'] = 'Perijinan';
$txt['board_perms_allow'] = 'Ijinkan';
$txt['board_perms_deny'] = 'Tolak';
$txt['board_perms_name_announce_topic'] = 'Umumkan topik';
$txt['board_perms_name_approve_posts'] = 'Setujui tulisan';
$txt['board_perms_name_delete_any'] = 'Hapus setiap tulisan';
$txt['board_perms_name_delete_own'] = 'Hapus tulisan sendiri';
$txt['board_perms_name_delete_replies'] = 'Hapus jawaban ke topik sendiri';
$txt['board_perms_name_lock_any'] = 'Kunci setiap topik';
$txt['board_perms_name_lock_own'] = 'Kunci topik sendiri';
$txt['board_perms_name_make_sticky'] = 'Pin topics';
$txt['board_perms_name_mark_any_notify'] = 'Minta pemberitahuan atas setiap topik';
$txt['board_perms_name_mark_notify'] = 'Minta pemberitahuan atas topik sendiri';
$txt['board_perms_name_merge_any'] = 'Gabung topik';
$txt['board_perms_name_moderate_board'] = 'Moderasi board';
$txt['board_perms_name_modify_any'] = 'Ubah setiap tulisan';
$txt['board_perms_name_modify_own'] = 'Ubah tulisan sendiri';
$txt['board_perms_name_modify_replies'] = 'Ubah jawaban ke topik sendiri';
$txt['board_perms_name_move_any'] = 'Pindahkan Setiap Topik';
$txt['board_perms_name_move_own'] = 'Pindahkan Topik Sendiri';
$txt['board_perms_name_poll_add_any'] = 'Tambah polling ke setiap topik';
$txt['board_perms_name_poll_add_own'] = 'Tambah polling ke topik sendiri';
$txt['board_perms_name_poll_edit_any'] = 'Edit setiap polling';
$txt['board_perms_name_poll_edit_own'] = 'Edit polling sendiri';
$txt['board_perms_name_poll_lock_any'] = 'Kunci setiap polling';
$txt['board_perms_name_poll_lock_own'] = 'Kunci polling sendiri';
$txt['board_perms_name_poll_post'] = 'Tulis polling baru';
$txt['board_perms_name_poll_remove_any'] = 'Hapus setiap polling';
$txt['board_perms_name_poll_remove_own'] = 'Hapus polling sendiri';
$txt['board_perms_name_poll_view'] = 'Lihat polling';
$txt['board_perms_name_poll_vote'] = 'Pilih dalam polling';
$txt['board_perms_name_post_attachment'] = 'Tulis lampiran';
$txt['board_perms_name_post_new'] = 'Tulis topik baru';
$txt['board_perms_name_post_reply_any'] = 'Tulis jawaban dalam setiap topik';
$txt['board_perms_name_post_reply_own'] = 'Tulis jawaban dalam topik sendiri';
$txt['board_perms_name_post_unapproved_attachments'] = 'Tulis lampiran yang belum disetujui';
$txt['board_perms_name_post_unapproved_topics'] = 'Tulis topik yang belum disetujui';
$txt['board_perms_name_post_unapproved_replies_any'] = 'Tulis jawaban yang belum disetujui dalams setiap topik';
$txt['board_perms_name_post_unapproved_replies_own'] = 'Tulis jawaban yang belum disetujui dalam topik sendiri';
$txt['board_perms_name_remove_any'] = 'Hapus setiap topik';
$txt['board_perms_name_remove_own'] = 'Hapus topik sendiri';
$txt['board_perms_name_report_any'] = 'Laporkan setiap tulisan';
$txt['board_perms_name_send_topic'] = 'Kirim topik ke teman';
$txt['board_perms_name_split_any'] = 'Pisahkan setiap topik';
$txt['board_perms_name_view_attachments'] = 'Lihat lampiran';

$txt['board_perms_group_no_polls'] = 'Board ini tidak mengijinkan polling';
$txt['board_perms_group_reply_only'] = 'Board ini hanya mengijinkan pengguna untuk menjawab topik';
$txt['board_perms_group_read_only'] = 'Board ini tidak mengijinkan penulisan';

// Membergroup info!
$txt['member_group_color'] = 'Warna';
$txt['member_group_min_posts'] = 'Minimum Tulisan';
$txt['member_group_max_messages'] = 'Maks Pesan Pribadi';
$txt['member_group_icons'] = 'Icons';
$txt['member_group_settings'] = 'Setelan';
$txt['member_group_access'] = 'Akses Board';

// Board info.
$txt['none'] = 'Tidak ada';
$txt['board_category'] = 'Kategori';
$txt['board_parent'] = 'Board Leluhur';
$txt['board_num_topics'] = 'Jumlah Topik';
$txt['board_num_posts'] = 'Jumlah Tulisan';
$txt['board_count_posts'] = 'Hitung Tulisan';
$txt['board_theme'] = 'Tema Board';
$txt['board_override_theme'] = 'Paksa Tema Board';
$txt['board_profile'] = 'Profil Perijinan';
$txt['board_moderators'] = 'Moderator';
$txt['board_groups'] = 'Grup dengan Akses';
$txt['board_disallowed_groups'] = 'Groups with Access Denied';

// Group Permissions.
$txt['group_perms_name_access_mod_center'] = 'Akses Pusat Moderasi';
$txt['group_perms_name_admin_forum'] = 'Admin forum';
$txt['group_perms_name_calendar_edit_any'] = 'Edit setiap event';
$txt['group_perms_name_calendar_edit_own'] = 'Edit event sendiri';
$txt['group_perms_name_calendar_post'] = 'Tulis event';
$txt['group_perms_name_calendar_view'] = 'Lihat event';
$txt['group_perms_name_edit_news'] = 'Edit berita forum';
$txt['group_perms_name_issue_warning'] = 'Terbitkan peringatan';
$txt['group_perms_name_karma_edit'] = 'Edit karma pengguna';
$txt['group_perms_name_manage_attachments'] = 'Mengatur lampiran';
$txt['group_perms_name_manage_bans'] = 'Mengatur pengucilan';
$txt['group_perms_name_manage_boards'] = 'Mengatur board';
$txt['group_perms_name_manage_membergroups'] = 'Manage member groups';
$txt['group_perms_name_manage_permissions'] = 'Mengatur perijinan';
$txt['group_perms_name_manage_smileys'] = 'Mengatur smiley dan ikon pesan';
$txt['group_perms_name_moderate_forum'] = 'Moderasi forum';
$txt['group_perms_name_pm_read'] = 'Baca pesan pribadi';
$txt['group_perms_name_pm_send'] = 'Kirim pesan pribadi';
$txt['group_perms_name_profile_extra_any'] = 'Edit setiap opsi tambahan';
$txt['group_perms_name_profile_extra_own'] = 'Edit opsi tambahan sendiri';
$txt['group_perms_name_profile_identity_any'] = 'Edit setiap setelan akun';
$txt['group_perms_name_profile_identity_own'] = 'Edit setelan akun sendiri';
$txt['group_perms_name_profile_set_avatar'] = 'Select an avatar';
$txt['group_perms_name_profile_remove_any'] = 'Hapus setiap akun';
$txt['group_perms_name_profile_remove_own'] = 'Hapus akun sendiri';
$txt['group_perms_name_profile_title_any'] = 'Edit setiap judul kustom';
$txt['group_perms_name_profile_title_own'] = 'Edit judul kustom sendiri';
$txt['group_perms_name_profile_view_any'] = 'Lihat setiap profil';
$txt['group_perms_name_profile_view_own'] = 'View own profile';
$txt['group_perms_name_search_posts'] = 'Mencari tulisan';
$txt['group_perms_name_send_mail'] = 'Kirim email forum ke anggota';
$txt['group_perms_name_view_mlist'] = 'View the member list';
$txt['group_perms_name_view_stats'] = 'Lihat statistik forum';
$txt['group_perms_name_who_view'] = 'Lihat siapa yang online';

$txt['report_error_too_many_staff'] = 'You have too many staff members. The report will not work with more than 300 staff members.';
$txt['report_staff_position'] = 'Posisi';
$txt['report_staff_moderates'] = 'Moderasi';
$txt['report_staff_posts'] = 'Tulisan';
$txt['report_staff_last_login'] = 'Terakhir Masuk';
$txt['report_staff_all_boards'] = 'Semua board';
$txt['report_staff_no_boards'] = 'Tidak ada board';