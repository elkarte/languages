<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Set Parameter Pencarian';
$txt['choose_board'] = 'Pilih board untuk dicari, atau cari semua';
$txt['all_words'] = 'Sama seluruh kata';
$txt['any_words'] = 'Sama setiap kata';
$txt['by_user'] = 'Oleh pengguna';

$txt['search_post_age'] = 'Usia pesan';
$txt['search_between'] = 'antara';
$txt['search_and'] = 'dan';
$txt['search_options'] = 'Opsi';
$txt['search_show_complete_messages'] = 'Tampilkan hasil sebagai pesan';
$txt['search_subject_only'] = 'Hanya mencari dalam subyek topik';
$txt['search_relevance'] = 'Relevansi';
$txt['search_date_posted'] = 'Tanggal Ditulis';
$txt['search_order'] = 'Urutan pencarian';
$txt['search_orderby_relevant_first'] = 'Hasil paling relevan lebih dulu';
$txt['search_orderby_large_first'] = 'Topik terbesar lebih dulu';
$txt['search_orderby_small_first'] = 'Topik terkecil lebih dulu';
$txt['search_orderby_recent_first'] = 'Topik terbaru lebih dulu';
$txt['search_orderby_old_first'] = 'Topik terlama lebih dulu';
$txt['search_visual_verification_label'] = 'Verifikasi';
$txt['search_visual_verification_desc'] = 'Silahkan masukkan kode dalam gambar di atas untuk menggunakan pencarian.';

$txt['search_specific_topic'] = 'Hanya mencari tulisan dalam topik';

$txt['groups_search_posts'] = 'Grup anggota dengan akses ke fungsi pencarian';
$txt['search_dropdown'] = 'Enable the Quick Search dropdown';
$txt['search_results_per_page'] = 'Jumlah hasil pencarian per halaman';
$txt['search_weight_frequency'] = 'Bobot pencarian relatif untuk jumlah pesan yang sama dalam sebuah topik';
$txt['search_weight_age'] = 'Bobot pencarian relatif untuk usia pesan terakhir yang sama';
$txt['search_weight_length'] = 'Bobot pencarian relatif untuk panjang topik';
$txt['search_weight_subject'] = 'Bobot pencarian relatif untuk subyek yang sama';
$txt['search_weight_first_message'] = 'Bobot pencarian relatif untuk pesan pertama yang sama';
$txt['search_weight_sticky'] = 'Relative search weight for a pinned topic';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Here you can change the basic settings of the search function.';
$txt['search_settings_title'] = 'Search Settings';

$txt['search_weights_desc'] = 'Here you can change the individual components of the relevance rating.';
$txt['search_weights_sphinx'] = 'To update weight factors with Sphinx, you must generate and install a new sphinx.conf file.';
$txt['search_weights_title'] = 'Pencarian - bobot';
$txt['search_weights_total'] = 'Total';
$txt['search_weights_save'] = 'Simpan';

$txt['search_method_desc'] = 'Di sini Anda dapat menetapkan cara pencarian diberi tenaga.';
$txt['search_method_title'] = 'Pencarian - metode';
$txt['search_method_save'] = 'Simpan';
$txt['search_method_messages_table_space'] = 'Ruang yang digunakan oleh pesan forum dalam database';
$txt['search_method_messages_index_space'] = 'Ruang yang digunakan oleh indeks pesan dalam database';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Indeks teks lengkap';
$txt['search_method_no_index_exists'] = 'saat ini tidak ada';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'tidak bisa dibuat karena maksimum panjang pesan di atas 65,535 atau tipe tabel bukan MyISAM';
$txt['search_method_index_already_exists'] = 'already created';
$txt['search_method_fulltext_remove'] = 'hapus indeks teks lengkap';
$txt['search_method_index_partial'] = 'sebagian dibuat';
$txt['search_index_custom_resume'] = 'melanjutkan';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'In order to be able to use fulltext search, you\\\'ll have to create a fulltext index first.';
$txt['search_index_custom_warning'] = 'Agar bisa menggunakan pencarian indeks kustom, Anda harus membuat indeks kustom lebih dulu!';

$txt['search_index'] = 'Indeks pencarian';
$txt['search_index_none'] = 'Tidak ada indeks';
$txt['search_index_custom'] = 'Indeks kustom';
$txt['search_index_label'] = 'Indeks';
$txt['search_index_size'] = 'Ukuran';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Paksa pemakaian indeks pencarian';
$txt['search_match_words'] = 'Hanya sama seluruh kata';
$txt['search_max_results'] = 'Maksimum hasil untuk ditampilkan';
$txt['search_max_results_disable'] = '(0: tanpa batas)';
$txt['search_floodcontrol_time'] = 'Waktu yang diperlukan diantara pencarian dari anggota yang sama';
$txt['search_floodcontrol_time_desc'] = '(0 untuk tanpa batas, dalam detik)';

$txt['additional_search_engines'] = 'Additional search engines';
$txt['setup_search_engine_add_more'] = 'Add another search engine';

$txt['search_create_index'] = 'Buat indeks';
$txt['search_create_index_why'] = 'Mengapa membuat indeks pencarian?';
$txt['search_create_index_start'] = 'Buat';
$txt['search_predefined'] = 'Profil pre-definisi';
$txt['search_predefined_small'] = 'Indeks ukuran kecil';
$txt['search_predefined_moderate'] = 'Indeks ukuran sedang';
$txt['search_predefined_large'] = 'Indeks ukuran besar';
$txt['search_create_index_continue'] = 'Lanjutkan';
$txt['search_create_index_not_ready'] = 'ElkArte is currently creating a search index of your messages. To avoid overloading your server, the process has been temporarily paused. It should automatically continue in a few seconds. If it doesn\'t, please click continue below.';
$txt['search_create_index_progress'] = 'Progres';
$txt['search_create_index_done'] = 'Custom search index successfully created.';
$txt['search_create_index_done_link'] = 'Lanjutkan';
$txt['search_double_index'] = 'Saat ini Anda mempunyai dua indeks pada tabel pesan. Untuk performansi terbaik disarankan untuk menghapus salah satu dari kedua indeks tersebut.';

$txt['search_error_indexed_chars'] = 'Jumlah karakter diindeks tidak benar. Setidaknya 3 karakter diperlukan untuk indeks yang berguna.';
$txt['search_error_max_percentage'] = 'Prosentase kata untuk dilewati tidak benar. Gunakan nilai setidaknya 5%.';
$txt['error_string_too_long'] = 'Panjang string pencarian harus kurang dari %1$d karakter.';

$txt['search_warning_ignored_word'] = 'The following term has been ignored in your search';
$txt['search_warning_ignored_words'] = 'The following terms have been ignored in your search';

$txt['search_adjust_query'] = 'Sesuaikan Parameter Pencarian';
$txt['search_adjust_submit'] = 'Perbaiki Pencarian';
$txt['search_did_you_mean'] = 'Mungkin Anda mencari';

$txt['search_example'] = '<em>misalnya</em> Orwell "Animal Farm" -movie';

$txt['search_engines_description'] = 'Dari area ini Anda dapat menentukan detail apa yang Anda inginkan untuk melacak mesin pencarian ketika mengindeks forum Anda, juga ketika meninjau log mesin pencarian.';
$txt['spider_mode'] = 'Search Engine Tracking Level';
$txt['spider_mode_note'] = 'Note higher level tracking increases server resource requirement.';
$txt['spider_mode_off'] = 'Dimatikan';
$txt['spider_mode_standard'] = 'Standar';
$txt['spider_mode_high'] = 'Moderasi';
$txt['spider_mode_vhigh'] = 'Aggressive';
$txt['spider_settings_desc'] = 'You can change settings for spider tracking from this page. Note, if you wish to <a href="%1$s">enable automatic pruning of the hit logs you can set this up here</a>';

$txt['spider_group'] = 'Apply restrictive permissions from group';
$txt['spider_group_note'] = 'To enable you to stop spiders indexing some pages.';
$txt['spider_group_none'] = 'Dimatikan';

$txt['show_spider_online'] = 'Tampilkan spider dalam daftar siapa online';
$txt['show_spider_online_no'] = 'Tidak sama sekali';
$txt['show_spider_online_summary'] = 'Tampilkan kuantitas spider';
$txt['show_spider_online_detail'] = 'Tampilkan detail spider';
$txt['show_spider_online_detail_admin'] = 'Tampilkan detail spider - hanya admin';

$txt['spider_name'] = 'Nama Spider';
$txt['spider_last_seen'] = 'Terakhir Terlihat';
$txt['spider_last_never'] = 'Tidak pernah';
$txt['spider_agent'] = 'Agent Pengguna';
$txt['spider_ip_info'] = 'Alamat IP';
$txt['spiders_add'] = 'Tambah Spider Baru';
$txt['spiders_edit'] = 'Edit Spider';
$txt['spiders_remove_selected'] = 'Hapus yang Dipilih';
$txt['spider_remove_selected_confirm'] = 'Are you sure you want to remove these spiders?\\n\\nAll associated statistics will also be deleted!';
$txt['spiders_no_entries'] = 'Tidak ada spider yang dikonfigurasi saat ini.';

$txt['add_spider_desc'] = 'Dari halaman ini Anda dapat mengedit parameter atas spider mana yang dikategorisasi. Jika agen pengguna pengunjung/alamat IP sama dengan yang dimasukkan di bawah, ia akan dideteksi sebagai spider mesin pencari dan melacak per preferensi forum.';
$txt['spider_name_desc'] = 'Nama spider yang akan dirujuk.';
$txt['spider_agent_desc'] = 'Agen pengguna dengan spider ini.';
$txt['spider_ip_info_desc'] = 'Daftar dipisahkan koma atas alamat IP yang terkait dengan spider ini.';

$txt['spider_time'] = 'Jam';
$txt['spider_viewing'] = 'Melihat';
$txt['spider_logs_empty'] = 'Tidak ada log entri spider untuk saat ini.';
$txt['spider_logs_info'] = 'Catatan bahwa pencatatan setiap tindakan spider hanya terjadi jika pelacakan disetel baik &quot;tinggi&quot; ataupun &quot;sangat tinggi&quot;. Detail dari setiap tindakan spider hanya dicatat jika pelacakan disetel ke &quot;sangat tinggi&quot;.';
$txt['spider_disabled'] = 'Dimatikan';
$txt['spider_log_empty_log'] = 'Clear Log';
$txt['spider_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log';

$txt['spider_logs_delete'] = 'Hapus Entri';
$txt['spider_logs_delete_older'] = 'Delete all entries older than %1$s days.';
$txt['spider_logs_delete_submit'] = 'Hapus';

$txt['spider_stats_delete_older'] = 'Delete all spider statistics from spiders not seen in %1$s days.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Anda yakin ingin mengosongkan semua entri log?';

$txt['spider_stats_select_month'] = 'Lompat Ke Bulan';
$txt['spider_stats_page_hits'] = 'Kunjungan Halaman';
$txt['spider_stats_no_entries'] = 'Tidak ada statistik spider yang tersedia saat ini.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'You have not yet selected to use Sphinx or SphinxQL as your Search Method';
$txt['sphinx_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using the Sphinx API.';
$txt['sphinxql_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using SphinxQL commands.';
$txt['sphinx_test_connect_failed'] = 'Unable to connect to the Sphinx daemon. Make sure it is running and configured properly. Sphinx search will not work until you fix the problem.';
$txt['sphinxql_test_connect_failed'] = 'Unable to access SphinxQL. Make sure your sphinx.conf has a separate listen directive for the SphinxQL port. SphinxQL search will not work until you fix the problem';
$txt['sphinx_test_api_missing'] = 'The sphinxapi.php file is missing in your &quot;sources&quot; directory. You need to copy this file from the Sphinx distribution. Sphinx search will not work until you fix the problem.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Index data path:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Log file path:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';