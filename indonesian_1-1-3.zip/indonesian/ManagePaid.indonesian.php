<?php
// Version: 1.1; ManagePaid

// Symbols.
$txt['usd_symbol'] = '$%1.2f';
$txt['eur_symbol'] = '&euro;%1.2f';
$txt['gbp_symbol'] = '&pound;%1.2f';

$txt['usd'] = 'USD ($)';
$txt['eur'] = 'EURO (&euro;)';
$txt['gbp'] = 'GBP (&pound;)';
$txt['other'] = 'Lainnya';

$txt['paid_username'] = 'Nama pengguna';

$txt['paid_subscriptions_desc'] = 'Dari seksi ini Anda dapat menambah, menghapus dan mengedit metode subskripsi ke forum Anda.';
$txt['paid_subs_settings'] = 'Setelan';
$txt['paid_subs_settings_desc'] = 'Dari sini Anda dapat mengedit metode pembayaran yang tersedia bagi para pengguna Anda.';
$txt['paid_subs_view'] = 'Lihat Subskripsi';
$txt['paid_subs_view_desc'] = 'Dari seksi ini Anda dapat melihat semua subskripsi yang tersedia.';

// Setting type strings.
$txt['paid_enabled'] = 'Hidupkan Subskripsi Berbayar';
$txt['paid_enabled_desc'] = 'This must be checked for the paid subscriptions to be used on the forum.';
$txt['paid_email'] = 'Kirim Email Pemberitahuan';
$txt['paid_email_desc'] = 'Informasikan admin ketika subskripsi secara otomatis berubah.';
$txt['paid_email_to'] = 'Email untuk Korespondensi';
$txt['paid_email_to_desc'] = 'Daftar dipisahkan koma atas alamat untuk pemberitahuan email sebagai tambahan bagi admin forum.';
$txt['paidsubs_test'] = 'Hidupkan mode pengujian';
$txt['paidsubs_test_desc'] = 'Ini menyimpan mod subskripsi berbayar ke dalam mode &quot;pengujian&quot;, yang akan menjadi bak percobaan metode pembayaran dalam paypal dll. Jangan hidupkan kecuali Anda mengetahui apa yang sedang Anda kerjakan!';
$txt['paidsubs_test_confirm'] = 'Apakah anda ingin menghidupkan mode tes?';
$txt['paid_email_no'] = 'Jangan kirim pemberitahuan apapun';
$txt['paid_email_error'] = 'Informasikan saat subskripsi gagal';
$txt['paid_email_all'] = 'Informasikan saat semua subskripsi otomatis berubah';
$txt['paid_currency'] = 'Pilih Kurs';
$txt['paid_currency_code'] = 'Kode Kurs';
$txt['paid_currency_code_desc'] = 'Kode yang dipakai oleh pembayaran';
$txt['paid_currency_symbol'] = 'Simbol yang dipakai oleh metode pembayaran';
$txt['paid_currency_symbol_desc'] = 'Gunakan \'%1.2f\' untuk menetapkan di mana angka berada, misalnya $%1.2f, %1.2fDM dll';

$txt['paypal_email'] = 'Alamat email Paypal';
$txt['paypal_email_desc'] = 'Biarkan kosong jika Anda tidak ingin menggunakan paypal.';

$txt['authorize_id'] = 'ID Instalasi Authorize.net';
$txt['authorize_id_desc'] = 'ID Instalasi dibuat oleh Authorize.net. Biarkan kosong jika Anda tidak menggunakan Authorize.net';
$txt['authorize_transid'] = 'ID Transaksi Authorize.Net';

$txt['2co_id'] = '2checkout.com Install ID';
$txt['2co_id_desc'] = 'ID Instalasi dibuat oleh 2co.com. Biarkan kosong jika Anda tidak menggunakan 2co.com';
$txt['2co_password'] = '2checkout.com Secret Word';
$txt['2co_password_desc'] = 'Kata rahasia 2checkout Anda.';
$txt['2co_password_wrong'] = 'Your 2checkout secret word was not accepted.';

$txt['paid_settings_save'] = 'Simpan';

$txt['paid_note'] = '<strong class="alert">Note:</strong><br />For subscriptions to be automatically updated for your users, you
	will need to setup a return URL for each of your payment methods. For all payment types, this return URL should be set as:<br /><br />
	&nbsp;&nbsp;&bull;&nbsp;&nbsp;<strong>{board_url}/subscriptions.php</strong><br /><br />
	You can edit the link for PayPal directly <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ipn-notify" target="_blank">by clicking here</a>.<br />
	For the other gateways (if installed) you can normally find it in your customer panels, usually under the term &quot;Return URL&quot; or &quot;Callback URL&quot;.';

// View subscription strings.
$txt['paid_name'] = 'Nama';
$txt['paid_status'] = 'Status';
$txt['paid_cost'] = 'Biaya';
$txt['paid_duration'] = 'Durasi';
$txt['paid_active'] = 'Aktif';
$txt['paid_pending'] = 'Pembayaran Tertunda';
$txt['paid_finished'] = 'Selesai';
$txt['paid_total'] = 'Total';
$txt['paid_is_active'] = 'Diaktifkan';
$txt['paid_none_yet'] = 'Anda belum menyiapkan subskripsi apapun.';
$txt['paid_none_ordered'] = 'You don\'t any subscriptions.';
$txt['paid_payments_pending'] = 'Pembayaran Tertunda';
$txt['paid_order'] = 'Urutan';

$txt['yes'] = 'Ya';
$txt['no'] = 'Tidak';

// Add/Edit/Delete subscription.
$txt['paid_add_subscription'] = 'Tambah Subskripsi Baru';
$txt['paid_edit_subscription'] = 'Edit Subskripsi';
$txt['paid_delete_subscription'] = 'Hapus Subskripsi';

$txt['paid_mod_name'] = 'Nama Subskripsi';
$txt['paid_mod_desc'] = 'Deskripsi';
$txt['paid_mod_reminder'] = 'Kirim Email Pengingat';
$txt['paid_mod_reminder_desc'] = 'Hari sebelum subskripsi berakhir untuk mengirimkan pengingat. (Dalam hari, 0 untuk mematikan)';
$txt['paid_mod_email'] = 'Email untuk Dikirim setelah Selesai';
$txt['paid_mod_email_desc'] = 'Di mana {NAME} adalah nama anggota; {FORUM} adalah nama komunitas. Subyek email harus pada baris pertama. Kosong untuk tanpa pemberitahuan email.';
$txt['paid_mod_cost_usd'] = 'Biaya (USD)';
$txt['paid_mod_cost_eur'] = 'Biaya (EUR)';
$txt['paid_mod_cost_gbp'] = 'Biaya (GBP)';
$txt['paid_mod_cost_blank'] = 'Biarkan ini kosong untuk tidak menawarkan kurs ini.';
$txt['paid_mod_span'] = 'Lama Subskripsi';
$txt['paid_mod_span_days'] = 'Hari';
$txt['paid_mod_span_weeks'] = 'Minggu';
$txt['paid_mod_span_months'] = 'Bulan';
$txt['paid_mod_span_years'] = 'Tahun';
$txt['paid_mod_active'] = 'Aktif';
$txt['paid_mod_active_desc'] = 'Subskripsi harus aktif agar anggota baru bisa bergabung.';
$txt['paid_mod_prim_group'] = 'Grup Utama setelah Subskripsi';
$txt['paid_mod_prim_group_desc'] = 'Grup utama untuk menyimpan anggota ketika mereka berlangganan.';
$txt['paid_mod_add_groups'] = 'Grup Tambahan setelah Subskripsi';
$txt['paid_mod_add_groups_desc'] = 'Grup tambaham untuk menambahkan pengguna setelah subskripsi.';
$txt['paid_mod_no_group'] = 'Jangan Ubah';
$txt['paid_mod_edit_note'] = 'Catatan bahwa karena grup ini mempunyai pelanggan yang sudah ada, setelan grup tidak bisa diubah!';
$txt['paid_mod_delete_warning'] = '<strong>PERINGATAN</strong><br /><br />Jika Anda menghapus subskripsi ini, semua anggota yang saat ini berlangganan akan kehilangan setiap hak akses yang diberikan dengan subskripsi. Kecuali Anda yakin ingin melakukan ini, direkomendasikan bahwa Anda cukup mematikan subskripsi daripada menghapusnya.<br />';
$txt['paid_mod_repeatable'] = 'Ijinkan pengguna untuk otomatis-memperbarui subskripsi ini';
$txt['paid_mod_allow_partial'] = 'Ijinkan subskripsi parsial';
$txt['paid_mod_allow_partial_desc'] = 'Jika opsi ini dihidupkan, dalam hal di mana pengguna membayar kurang dari yang diperlukan, mereka akan diberi hak subskripsi untuk prosentase dari durasi yang telah mereka bayarkan.';
$txt['paid_mod_fixed_price'] = 'Subskripsi untuk harga tetap dan periodik';
$txt['paid_mod_flexible_price'] = 'Harga subskripsi bervariasi dengan urutan durasi';
$txt['paid_mod_price_breakdown'] = 'Pemecahan Harga Fleksibel';
$txt['paid_mod_price_breakdown_desc'] = 'Definisikan di sini seberapa banyak biaya subskripsi berdiri sendiri tergantung pada periode subskripsi mereka. Sebagai contoh, it dikenakan 12USD untuk berlangganan satu bulan, tapi hanya 100USD untuk satu tahun. Jika Anda tidak ingin mendefinisikan harga untuk periode waktu tertentu, biarkan kosong.';
$txt['flexible'] = 'Fleksibel';

$txt['paid_per_day'] = 'Harga Per Hari';
$txt['paid_per_week'] = 'Harga Per Minggu';
$txt['paid_per_month'] = 'Harga Per Bulan';
$txt['paid_per_year'] = 'Harga Per Tahun';
$txt['day'] = 'Hari';
$txt['week'] = 'Minggu';
$txt['month'] = 'Bulan';
$txt['year'] = 'Tahun';

// View subscribed users.
$txt['viewing_users_subscribed'] = 'Melihat Pengguna';
$txt['view_users_subscribed'] = 'Melihat pengguna yang berlangganan ke: &quot;%1$s&quot;';
$txt['no_subscribers'] = 'There are currently no subscribers to this subscription.';
$txt['add_subscriber'] = 'Tambah Pelanggan Baru';
$txt['edit_subscriber'] = 'Edit Pelanggan';
$txt['delete_selected'] = 'Hapus Yang Dipilih';
$txt['complete_selected'] = 'Selesaikan Yang Dipilih';

// @todo These strings are used in conjunction with JavaScript.  Use numeric entities.
$txt['delete_are_sure'] = 'Anda yakin ingin menghapus semua rekaman subskripsi yang dipilih?';
$txt['complete_are_sure'] = 'Anda yakin ingin menyelesasikan subskripsi yang dipilih?';

$txt['start_date'] = 'Tanggal Mulai';
$txt['end_date'] = 'End Tanggal';
$txt['start_date_and_time'] = 'Tanggal dan Jam Mulai';
$txt['end_date_and_time'] = 'Tanggal dan Jam Berakhir';
$txt['one_username'] = 'Silahkan masukkan hanya satu nama pengguna.';
$txt['minute'] = 'Menit';
$txt['error_member_not_found'] = 'Anggota yang dimasukkan tidak bisa ditemukan';
$txt['member_already_subscribed'] = 'Anggota ini sudah berlangganan ke subskripsi ini. Silahkan edit subskripsi yang sudah ada.';
$txt['search_sub'] = 'Cari Pengguna';

// Make payment.
$txt['paid_confirm_payment'] = 'Konfirmasi Pembayaran';
$txt['paid_confirm_desc'] = 'Untuk melanjutkan pembayaran, silahkan centang detail di bawah ini dan tekan &quot;Pesan&quot;';
$txt['paypal'] = 'PayPal';
$txt['paid_confirm_paypal'] = 'Untuk membayar menggunakan <a href="http://www.paypal.com">PayPal</a> silahkan klik tombol di bawah. Anda akan dialihkan ke situs PayPal untuk pembayaran.';
$txt['paid_paypal_order'] = 'Pesan dengan PayPal';
$txt['authorize'] = 'Authorize.Net';
$txt['paid_confirm_authorize'] = 'Untuk membayar menggunakan <a href="http://www.authorize.net">Authorize.Net</a> silahkan klik tombol di bawah. Anda akan dialihkan ke situs Authorize.Net untuk pembayaran.';
$txt['paid_authorize_order'] = 'Pesan dengan Authorize.Net';
$txt['2co'] = '2checkout';
$txt['paid_confirm_2co'] = 'Untuk membayar menggunakan <a href="http://www.2com.com">2co.com</a> silahkan klik tombol di bawah. Anda akan dialihkan ke 2com.com untuk pembayaran.';
$txt['paid_2co_order'] = 'Pesan dengan 2co.com';
$txt['paid_done'] = 'Pembayaran Selesasi';
$txt['paid_done_desc'] = 'Terima kasih atas pembayaran Anda. Setelah transaksi diverifikasi, subskripsi akan diaktifkan.';
$txt['paid_sub_return'] = 'Kembali ke Subskripsi';
$txt['paid_current_desc'] = 'Di bawah ini adalah daftar semua subskripsi Anda saat ini dan sebelumnya. Untuk memperpanjang subskripsi cukup pilih ia dari daftar di atas.';
$txt['paid_admin_add'] = 'Tambah Subskripsi Ini';

$txt['paid_not_set_currency'] = 'Anda belum menyiapkan kurs Anda. Silahkan lakukan itu dari menu setelan sebelum melanjutkan';
$txt['paid_no_cost_value'] = 'Anda harus memasukkan biaya dan lamanya berlangganan.';
$txt['paid_all_freq_blank'] = 'Anda harus memasukkan biaya untuk setidaknya satu dari empat durasi.';

// Some error strings.
$txt['paid_no_data'] = 'Data tidak ada yang benar yang dikirimkan pada naskah.';

$txt['paypal_could_not_connect'] = 'Tidak dapat menghubungi server PayPal';
$txt['paypal_currency_unkown'] = 'The currency code from PayPal (%1$s) does not match the code in your settings (%2$s)';
$txt['paid_sub_not_active'] = 'That subscription is not taking any new users.';
$txt['paid_disabled'] = 'Paid subscriptions are currently disabled.';
$txt['paid_unknown_transaction_type'] = 'Tipe transaksi Subskripsi Berbayar Tidak Dikenal.';
$txt['paid_empty_member'] = 'Pengendali subskripsi berbayar tidak dapat menemukan ID anggota';
$txt['paid_could_not_find_member'] = 'Pengenali subskripsi berbayar tidak dapat menemukan anggota dengan ID: %1$d';
$txt['paid_count_not_find_subscription'] = 'Subskripsi berbayar tidak dapat menemukan subskripsi untuk ID anggota: %1$s, ID subskripsi: %2$s';
$txt['paid_count_not_find_subscription_log'] = 'Pengendali subskripsi berbayar tidak dapat menemukan entri log subskripsi untuk ID anggota: %1$s, ID subskripsi: %2$s';
$txt['paid_count_not_find_outstanding_payment'] = 'Tidak dapat menemukan entri pembayaran tertunda untuk ID anggota: %1$s, ID subskripsi: %2$s maka diabaikan';
$txt['paid_admin_not_setup_gateway'] = 'Maaf tapi admin belum menyelesaikan setelan subskripsi berbayar - silahkan periksa kembali nanti.';
$txt['paid_make_recurring'] = 'Jadikan ini pembayaran berulang';

$txt['subscriptions'] = 'Subskripsi';
$txt['subscription'] = 'Subskripsi';
$txt['subscribers'] = 'Subscribers';
$txt['paid_subs_desc'] = 'Below is a list of all the subscriptions which are available on this site.';
$txt['paid_subs_none'] = 'There are currently no paid subscriptions available.';

$txt['paid_current'] = 'Subskripsi Yang Ada';
$txt['pending_payments'] = 'Pembayaran Tertunda';
$txt['pending_payments_desc'] = 'Anggota ini sudah mencoba untuk melakukan pembayaran berikut untuk subskripsi ini tapi konfirmasi belum diterima oleh forum. Jika Anda yakin pembayaran sudah diterima, klik &quot;terima&quot; untuk menindak lanjuti subskripsi. Alternatifenya Anda dapat mengklik &quot;Hapus&quot; untuk menghapus semua referensi terhadap pembayaran.';
$txt['pending_payments_value'] = 'Nilai';
$txt['pending_payments_accept'] = 'Terima';
$txt['pending_payments_remove'] = 'Hapus';