<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Mengatur Board dan Kategori';
$txt['order'] = 'Urutan';
$txt['full_name'] = 'Nama lengkap';
$txt['name_on_display'] = 'Ini adalah nama yang akan ditampilkan.';
$txt['boards_and_cats_desc'] = 'Edit your categories and boards here. List multiple moderators as <em>&quot;username&quot;, &quot;username&quot;</em>. (these must be usernames and *not* display names)<br />To create a new board, click the Add Board button.<br />To move a board you can drag and drop it to its new location in the list (across cataegories and Child of locations)<br />To create a new board as a child of a current board, select "Child of..." from the Order drop down menu when creating the board.';
$txt['parent_members_only'] = 'Anggota Reguler';
$txt['parent_guests_only'] = 'Pengunjung';
$txt['catConfirm'] = 'Anda ingin menghapus kategori ini?';
$txt['boardConfirm'] = 'Anda ingin menghapus board ini?';

$txt['catEdit'] = 'Edit Kategori';
$txt['collapse_enable'] = 'Bisa disempitkan';
$txt['collapse_desc'] = 'Ijinkan pengguna untuk menyempitkan kategori ini';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'Setelah ';
$txt['mboards_order_first'] = 'Di tempat pertama';
$txt['mboards_board_error'] = 'Failed to resolve move location.';

$txt['mboards_new_board'] = 'Tambah Board';
$txt['mboards_new_cat_name'] = 'Kategori Baru';
$txt['mboards_add_cat_button'] = 'Tambah Kategori';
$txt['mboards_new_board_name'] = 'Board Baru';

$txt['mboards_modify'] = 'ubah';
$txt['mboards_permissions'] = 'perijinan';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Anda yakin ingin mengalihkan board ini untuk menggunakan perijinan lokal?';

$txt['mboards_delete_cat'] = 'Hapus Kategori';
$txt['mboards_delete_board'] = 'Hapus Board';

$txt['mboards_delete_cat_contains'] = 'Menghapus kategori ini juga akan menghapus board, termasuk seluruh topik, tulisan dan lampiran di dalam setiap board';
$txt['mboards_delete_option1'] = 'Hapus kategori dan semua board yang ada di dalamnya.';
$txt['mboards_delete_option2'] = 'Hapus kategori dan pindahkan semua board dan isi di dalamnya ke';
$txt['mboards_delete_board_contains'] = 'Deleting this board will also move the sub-boards below, including all topics, posts and attachments within each board';
$txt['mboards_delete_board_option1'] = 'Delete board and move sub-boards contained within to category level.';
$txt['mboards_delete_board_option2'] = 'Delete board and move all sub-boards contained within to';
$txt['mboards_delete_what_do'] = 'Silahkan pilih apa yang ingin Anda lakukan dengan board ini';
$txt['mboards_delete_confirm'] = 'Konfirmasi';
$txt['mboards_delete_cancel'] = 'Batal';

$txt['mboards_category'] = 'Kategori';
$txt['mboards_description'] = 'Deskripsi';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Grup Diijinkan';
$txt['mboards_groups_desc'] = 'Grup yang diijinkan untuk mengakses board ini.<br /><em>Catatan: jika anggota dari setiap grup atau grup tulisan dicentang, mereka akan mempunyai akses ke board ini.</em>';
$txt['mboards_groups_regular_members'] = 'Grup ini berisi semua anggota yang tidak disetel memiliki grup utama.';
$txt['mboards_groups_post_group'] = 'Grup ini adalah grup berbasis jumlah tulisan.';
$txt['mboards_moderators'] = 'Moderator';
$txt['mboards_moderators_desc'] = 'Anggota tambahan yang mempunyai hak moderasi pada board ini.  Catatan bahwa administrator tidak diperlihatkan di sini.';
$txt['mboards_count_posts'] = 'Hitung Tulisan';
$txt['mboards_count_posts_desc'] = 'Membuat jawaban dan topik baru memunculkan jumlah tulisan anggota.';
$txt['mboards_unchanged'] = 'Tidak berubah';
$txt['mboards_theme'] = 'Tema Board';
$txt['mboards_theme_desc'] = 'Ini mengijinkan Anda untuk mengubah tampilan forum Anda hanya di dalam board ini.';
$txt['mboards_theme_default'] = '(standar forum keseluruhan.)';
$txt['mboards_override_theme'] = 'Abaikan Tema Anggota';
$txt['mboards_override_theme_desc'] = 'Gunakan tema board ini meskipun anggota tidak memilih menggunakan yang standar.';

$txt['mboards_redirect'] = 'Alihkan ke sebuah alamat web';
$txt['mboards_redirect_desc'] = 'Hidupkan opsi ini untuk mengalihan setiap orang pada board ini ke alamat web lain.';
$txt['mboards_redirect_url'] = 'Alamat untuk mengalihkan pengguna';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Reset jumlah pengalihan';
$txt['mboards_redirect_reset_desc'] = 'Memilih ini akan mereset jumlah pengalihan untuk board ini menjadi nol.';
$txt['mboards_current_redirects'] = 'Saat ini: %1$s';
$txt['mboards_redirect_disabled'] = 'Catatan: Board harus kosong dari topik untuk menghidupkan opsi ini.';
$txt['mboards_redirect_disabled_recycle'] = 'Catatan: Anda tidak bisa menyetel board recycle bin menjadi board pengalihan.';

$txt['mboards_order_before'] = 'Sebelum';
$txt['mboards_order_child_of'] = 'Anak dari';
$txt['mboards_order_in_category'] = 'Dalam kategori';
$txt['mboards_current_position'] = 'Posisi Saat Ini';
$txt['no_valid_parent'] = 'Board %1$s tidak memiliki leluhur yang benar. Gunakan fungsi \'cari dan betulkan kesalahan\' untuk membetulkan ini.';

$txt['mboards_recycle_disabled_delete'] = 'You must select an alternative recycle bin board or disable recycling before you can delete this board.';

$txt['mboards_settings_desc'] = 'Edit setelan board umum dan kategori.';
$txt['groups_manage_boards'] = 'Grup anggota diijinkan untuk mengatur board dan kategori';
$txt['recycle_enable'] = 'Hidupkan pemulihan topik yang dihapus';
$txt['recycle_board'] = 'Board untuk topik yang dihapus';
$txt['recycle_board_unselected_notice'] = 'Anda menghidupkan pembuangan topik tanpa menetapkan board untuk menempatkannya.  Fitur ini tidak akan dihidupkan sampai Anda menetapkan sebuah board sebagai tempat pembuangan topik.';
$txt['countChildPosts'] = 'Jumlah tulisan anak dalam total leluhur';
$txt['allow_ignore_boards'] = 'Ijinkan board untuk diabaikan';
$txt['deny_boards_access'] = 'Enable the option to deny board access based on membergroup';
$txt['boardsaccess_option_desc'] = 'For each permission you can choose \'Allow\' (A), \'Ignore\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />If you deny access, any member - (including moderators) - in that group will be denied access.<br />For this reason, you should set deny carefully, only when <strong>necessary</strong>. Ignore, on the other hand, denies unless otherwise granted.';

$txt['mboards_select_destination'] = 'Pilih board tujuan \'<strong>%1$s</strong>\'';
$txt['mboards_cancel_moving'] = 'Batal memindahkan';
$txt['mboards_move'] = 'pindahkan';

$txt['mboards_no_cats'] = 'Tidak ada kategori atau board yang dikonfigurasi untuk saat ini.';
