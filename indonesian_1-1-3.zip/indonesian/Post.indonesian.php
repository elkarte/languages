<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Tulis jawaban';
$txt['post_in_board'] = 'Post in the board';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Sisipkan Kutipan';
$txt['disable_smileys'] = 'Disable smileys';
$txt['dont_use_smileys'] = 'Jangan pakai smiley.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Ditulis pada';
$txt['standard'] = 'Standar';
$txt['thumbs_up'] = 'Jempol Ke Atas';
$txt['thumbs_down'] = 'Jempol Ke Bawah';
$txt['exclamation_point'] = 'Tanda seru';
$txt['question_mark'] = 'Tanda Tanya';
$txt['icon_poll'] = 'Polling';
$txt['lamp'] = 'Lampu';
$txt['add_smileys'] = 'Add smileys';
$txt['topic_notify_no'] = 'There are no topics with notification.';

$txt['rich_edit_wont_work'] = 'Browser Anda tidak mendukung pengeditan Rich Text.';
$txt['rich_edit_function_disabled'] = 'Browser Anda tidak mendukung fungsi ini.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Batalkan subskripsi ke topik ini dengan mengklik di sini';

$txt['lock_after_post'] = 'Kunci setelah Menulis';
$txt['notify_replies'] = 'Beritahu saya atas jawaban.';
$txt['lock_topic'] = 'Kunci topik ini.';
$txt['shortcuts'] = 'shortcuts: shift+alt+s submit/post or shift+alt+p preview';
$txt['shortcuts_drafts'] = 'shortcuts: shift+alt+s submit/post, shift+alt+p preview or shift+alt+d save draft';
$txt['option'] = 'Opsi';
$txt['reset_votes'] = 'Reset vote count';
$txt['reset_votes_check'] = 'Centang ini jika Anda ingin mereset semua jumlah pilihan menjadi 0.';
$txt['votes'] = 'suara';
$txt['attach'] = 'Lampirkan';
$txt['clean_attach'] = 'Clear attachment';
$txt['attached'] = 'Dilampirkan'; // @deprecated since 1.1
$txt['allowed_types'] = 'Tipe file diijinkan';
$txt['cant_upload_type'] = 'You cannot upload that type of file. The only allowed extensions are %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Jangan centang lampiran yang tidak ingin dilampirkan'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Yakni nama file terbatas. Silahkan coba nama file berbeda.';
$txt['topic_locked_no_reply'] = 'Warning! This topic is currently/will be locked<br />Only admins and moderators can reply.';
$txt['attachment_requires_approval'] = 'Catatan bahwa setiap file yang dilampirkan tidak akan ditampilkan sampai disetujui oleh moderator.';
$txt['error_temp_attachments'] = 'There are attachments found, which you have attached before but not posted. These attachments are now attached to this post. If you do not want to include them in this post, <a href="#postAttachment">you can remove them here</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Pengingat: Tulisan ni tidak akan muncul sampai disetujui oleh moderator.';

$txt['enter_comment'] = 'Masukkan komentar';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Tulisan dilaporkan';
$txt['reported_to_mod_by'] = 'oleh';
$txt['rtm10'] = 'Kirim';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Tulisan berikut, "%1$s" oleh';
$txt['reported_by'] = 'sudah dilaporkan oleh';
$txt['board_moderate'] = 'pada board yang Anda moderasi';
$txt['report_comment'] = 'Pelapor menambahkan komentar berikut';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximum total size %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximum individual size %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d per tulisan';
$txt['attach_restrictions'] = 'Pembatasan:';

$txt['post_additionalopt_attach'] = 'Lampiran dan Opsi lainnya';
$txt['post_additionalopt'] = 'Other options';
$txt['sticky_after'] = 'Pin this topic.';
$txt['move_after2'] = 'Pindahkan topik ini.';
$txt['back_to_topic'] = 'Kembali ke topik ini.';
$txt['approve_this_post'] = 'Approve this post';

$txt['retrieving_quote'] = 'Retrieving quote...';

$txt['post_visual_verification_label'] = 'Verifikasi';
$txt['post_visual_verification_desc'] = 'Silahkan masukkan kode dalam gambar di atas untuk membuat tulisan ini.';

$txt['poll_options'] = 'Opsi Polling';
$txt['poll_run'] = 'Jalankan polling dalam';
$txt['poll_run_limit'] = '(Biarkan kosong untuk tanpa  batas.)';
$txt['poll_results_visibility'] = 'Penampakan Hasil';
$txt['poll_results_anyone'] = 'Tampilkan hasil polling ke setiap orang.';
$txt['poll_results_voted'] = 'Hanya menampilkan hasil setelah seseorang sudah memilih.';
$txt['poll_results_after'] = 'Hanya menampilkan hasil setelah polling berakhir.';
$txt['poll_max_votes'] = 'Maksimum pilihan per pengguna';
$txt['poll_do_change_vote'] = 'Ijinkan pengguna untuk mengubah pilihan';
$txt['poll_too_many_votes'] = 'Anda memilih terlalu banyak opsi.  Untuk polling ini, Anda hanya bisa memilih %1$s opsi.';
$txt['poll_add_option'] = 'Tambah Opsi';
$txt['poll_guest_vote'] = 'Ijinkan pengunjung untuk memilih';

$txt['spellcheck_done'] = 'Pemeriksaan ejaan selesai.';
$txt['spellcheck_change_to'] = 'Ubah Ke:';
$txt['spellcheck_suggest'] = 'Saran:';
$txt['spellcheck_change'] = 'Ubah';
$txt['spellcheck_change_all'] = 'Ubah Semua';
$txt['spellcheck_ignore'] = 'Abaikan';
$txt['spellcheck_ignore_all'] = 'Abaikan Semua';

$txt['more_attachments'] = 'banyak lampiran';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Maaf, Anda tidak diijinkan untuk menulis lebih banyak lampiran lagi.';

$txt['more_smileys'] = 'selengkapnya';
$txt['more_smileys_title'] = 'Smiley tambahan';
$txt['more_smileys_pick'] = 'Ambil smiley';
$txt['more_smileys_close_window'] = 'Tutup Jendela';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = 'Mengirim pengumuman mengenai topik ini ke anggota:';
$txt['announce_title'] = 'Kirim pengumuman';
$txt['announce_desc'] = 'Formulir ini mengijinkan Anda untuk mengirimkan pengumuman ke grup anggota yang dipilih atas topik ini.';
$txt['announce_sending'] = 'Mengirimkan pengumuman topik';
$txt['announce_done'] = 'selesai';
$txt['announce_continue'] = 'Lanjutkan';
$txt['announce_topic'] = 'Umumkan topik.';
$txt['announce_regular_members'] = 'Anggota Reguler';

$txt['digest_subject_daily'] = 'Pasokan Harian';
$txt['digest_subject_weekly'] = 'Pasokan Mingguan';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'The following topics were started';
$txt['digest_new_topics_line'] = '"%1$s" in the %2$s board';
$txt['digest_new_replies'] = 'Jawaban sudah dibuat dalam topik berikut';
$txt['digest_new_replies_one'] = '1 jawaban dalam "%1$s"';
$txt['digest_new_replies_many'] = '%1$d jawaban dalam "%2$s"';
$txt['digest_mod_actions'] = 'Aksi moderasi berikut sudah dilakukan';
$txt['digest_mod_act_sticky'] = '"%1$s" was pinned';
$txt['digest_mod_act_lock'] = '"%1$s" sudah dikunci';
$txt['digest_mod_act_unlock'] = '"%1$s" sudah dibuka kuncinya';
$txt['digest_mod_act_remove'] = '"%1$s" sudah dihapus';
$txt['digest_mod_act_move'] = '"%1$s" sudah dipindahkan';
$txt['digest_mod_act_merge'] = '"%1$s" sudah digabung';
$txt['digest_mod_act_split'] = '"%1$s" sudah dipisahkan';

$txt['attach_error_title'] = 'Error uploading attachments.';
$txt['attach_warning'] = 'There was a problem during the uploading of <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Sorry, you are out of attachment space. The total attachment size allowed per post is %1$s KB. Space remaining is %2$s KB.';
$txt['attach_folder_warning'] = 'The attachments directory can not be located. Please notify an administrator of this problem.';
$txt['attach_folder_admin_warning'] = 'The path to the attachments directory (%1$s) is incorrect. Please correct it in the attachment settings area of your admin panel.';
$txt['attach_limit_nag'] = 'You have reached the maximum number of attachments allowed per post.';
$txt['attach_no_upload'] = 'There was a problem and your attachments could not be uploaded';
$txt['attach_remaining'] = '%1$d remaining';
$txt['attach_available'] = '%1$s KB available';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'The file appears to be empty. Please contact your forum administrator if this continues to be a problem';
$txt['attached_files_in_session'] = '<em>The above underlined file(s) have been uploaded but will not be attached to this post until it is submitted.</em>';

$txt['attach_php_error'] = 'Due to an error, your attachment could not be uploaded. Please contact the forum administrator if this problem continues.';
$txt['php_upload_error_1'] = 'The uploaded file exceeds the upload_max_filesize directive in php.ini. Please contact your host if you are unable to correct this issue.';
$txt['php_upload_error_3'] = 'The uploaded file was only partially uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_4'] = 'No file was uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_6'] = 'Unable to save. Missing a temporary directory. Please contact your host if you are unable to correct this problem.';
$txt['php_upload_error_7'] = 'Failed to write file to disk. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_8'] = 'A PHP extension stopped the file upload. This is a PHP related error. Please contact your host if this problem continues.';
$txt['error_temp_attachments_new'] = 'There are attachments which you had previously attached but not posted. These attachments are still attached to this post. This post does need to be submitted before these attachments are either saved or removed. You <a href="#postAttachment">can do that here</a>';
$txt['error_temp_attachments_found'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not post until these are either removed or that post has been submitted.<br />Click <a href="%1$s">here to remove </a>those attachments. Or <a href="%2$s">here to return to that post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not upload any more attachments until these are removed or that post has been submitted.<br />Click <a href="%1$s">here to remove these attachments</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Those attachments have now been removed and you have been returned to the page you were previously on';
$txt['error_temp_attachments_flushed'] = 'Please note that any files which had been previously attached, but not posted, have now been removed.';
$txt['error_topic_already_announced'] = 'Please note that this topic has already been announced.';

$txt['cant_access_upload_path'] = 'Tidak bisa mengakses path upload lampiran!';
$txt['file_too_big'] = 'Your file is too large. The maximum attachment size allowed is %1$s KB.';
$txt['attach_timeout'] = 'Lampiran Anda tidak bisa disimpan. Ini mungkin terjadi karena terlalu lama meng-upload atau file terlalu besasr dari yang bisa diijinkan server.<br /><br />Silahkan hubungi administrator server Anda untuk informasi lebih lengkap.';
$txt['bad_attachment'] = 'Lampiran anda telah gagal dalam pemeriksaan keamanan dan tidak dapat di-upload. Silakan berkonsultasi dengan administrator forum.';
$txt['ran_out_of_space'] = 'The upload directory is full. Please contact an administrator about this problem.';
$txt['attachments_no_write'] = 'Direktori upload lampiran tidak bisa ditulis.  Lampiran atau avatar Anda tidak bisa disimpan.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory.  Your attachment or avatar cannot be saved.';
$txt['attachments_limit_per_post'] = 'Anda tidak bisa meng-upload lebih dari %1$d lampiran per tulisan';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Insert';
$txt['ila_opt_size'] = 'Ukuran';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Tidak ada';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Center';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/