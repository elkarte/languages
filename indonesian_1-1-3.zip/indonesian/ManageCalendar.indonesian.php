<?php
// Version: 1.1; ManageCalendar

$txt['calendar_desc'] = 'Dari sini Anda dapat mengubah seluruh aspek kalender.';

// Calendar Settings
$txt['calendar_settings_desc'] = 'Di sini Anda dapat menghidupkan kalender, dan memeriksa setelan yang seharusnya digunakan.';
$txt['groups_calendar_view'] = 'Grup anggota dibolehkan untuk melihat kalender';
$txt['groups_calendar_post'] = 'Grup anggota dibolehkan untuk membuat event';
$txt['groups_calendar_edit_own'] = 'Grup anggota diijinkan untuk mengedit event-nya sendiri';
$txt['groups_calendar_edit_any'] = 'Grup anggota diijinkan untuk mengedit setiap event';
$txt['setting_cal_enabled'] = 'Hidupkan kalender';
$txt['setting_cal_daysaslink'] = 'Tampilkan hari sebagai link ke \'Tulis Event\'';
$txt['setting_cal_days_for_index'] = 'Jumlah maksimum hari ke depan pada indeks board';
$txt['setting_cal_showholidays'] = 'Tampilkan hari libur';
$txt['setting_cal_showbdays'] = 'Tampilkan ulang tahun';
$txt['setting_cal_showevents'] = 'Tampilkan event';
$txt['setting_cal_export'] = 'Allow events to be exported in iCal format';
$txt['setting_cal_show_never'] = 'Tidak pernah';
$txt['setting_cal_show_cal'] = 'Hanya dalam kalender';
$txt['setting_cal_show_index'] = 'Hanya pada indeks board';
$txt['setting_cal_show_all'] = 'Pada indeks board dan kalender';
$txt['setting_cal_defaultboard'] = 'Board standar untuk menuliskan event';
$txt['setting_cal_allow_unlinked'] = 'Ijinkan event tidak dikaitkan ke tulisan';
$txt['setting_cal_minyear'] = 'Minimum tahun';
$txt['setting_cal_maxyear'] = 'Maksimum tahun';
$txt['setting_cal_allowspan'] = 'Ijinkan event untuk menyebrang multipel hari';
$txt['setting_cal_maxspan'] = 'Jumlah hari maksimum yang diseberangi event';
$txt['setting_cal_showInTopic'] = 'Tampilkan event terkait dalam tampilan topik';

// Adding/Editing/Viewing Holidays
$txt['manage_holidays_desc'] = 'Dari sini Anda bisa menambah dan menghapus liburan dari kalender forum Anda.';
$txt['current_holidays'] = 'Liburan Saat ini';
$txt['holidays_title'] = 'Liburan';
$txt['holidays_title_label'] = 'Judul';
$txt['holidays_delete_confirm'] = 'Anda yakin ingin menghapus liburan ini?';
$txt['holidays_add'] = 'Add new holiday';
$txt['holidays_edit'] = 'Edit existing holiday';
$txt['holidays_button_add'] = 'Tambah';
$txt['holidays_button_edit'] = 'Edit';
$txt['holidays_button_remove'] = 'Hapus';
$txt['holidays_no_entries'] = 'Tidak ada hari libur yang dikonfigurasi untuk saat ini.';
$txt['every_year'] = 'Setiap Tahun';