<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Sorry, we can\'t let you access this section. We can\'t even tell you if it exists. You\'re welcome to visit the main page and choose your way from there.';
$txt['not_guests'] = 'Sorry, this action is not available to guests.';

$txt['mods_only'] = 'Only moderators can use the direct remove function, please remove this message through the modify feature.';
$txt['no_name'] = 'You didn\'t fill the name field out. We can\'t let you continue without a name, sorry.';
$txt['no_email'] = 'You didn\'t fill the email field out. We can\'t let you continue without an email, sorry.';
$txt['topic_locked'] = 'Topik ini dikunci, Anda tidak diijinkan untuk menulis atau mengubah pesan...';
$txt['no_password'] = 'Field kata sandi kosong';
$txt['passwords_dont_match'] = 'Kata sandi tidak sama.';
$txt['register_to_use'] = 'Maaf, Anda harus mendaftar sebelum menggunakan fitur ini.';
$txt['username_reserved'] = 'The user name you tried to use contains the reserved name \'%1$s\'. Please try another user name.';
$txt['numbers_one_to_nine'] = 'Field ini hanya menerima angka dari 0-9';
$txt['not_a_user'] = 'Pengguna yang profilnya Anda coba lihat tidak ada.';
$txt['not_a_topic'] = 'Topik ini tidak ada pada board ini.';
$txt['not_approved_topic'] = 'Topik ini belum disetujui.';
$txt['email_in_use'] = 'Alamat email (%1$s) sudah dipakai oleh anggota terdaftar. Jika Anda merasa ini suatu kesalahan, pergi ke halaman masuk dan gunakan pengingat kata sandi dengan alamat email tersebut.';

$txt['didnt_select_vote'] = 'Anda tidak memilih opsi pemilihan.';
$txt['poll_error'] = 'Something isn\'t working, sorry: either that poll doesn\'t exist, the poll has been locked, or you tried to vote twice.';
$txt['locked_by_admin'] = 'Ini sudah dikunci oleh administrator.  Anda tidak bisa membukanya.';
$txt['not_enough_posts_karma'] = 'Maaf, Anda tidak memiliki jumlah tulisan yang cukup untuk mengubah karma - Anda memerlukan setidaknya %1$d.';
$txt['cant_change_own_karma'] = 'Maaf, Anda tidak diijinkan untuk mengubah karma sendiri.';
$txt['karma_wait_time'] = 'Maaf, Anda tidak bisa mengulang aksi karma tanpa menunggu %1$s %2$s.';
$txt['feature_disabled'] = 'Maaf, fitur ini dimatikan.';
$txt['feature_no_exists'] = 'Sorry, this feature doesn\'t exist.';
$txt['couldnt_connect'] = 'Tidak bisa menyambung ke server atau tidak bisa menemukan file';
$txt['no_board'] = 'Board yang Anda tetapkan tidak ada';
$txt['no_message'] = 'The message is no longer available';
$txt['no_topic_id'] = 'Anda menetapkan ID topik yang tidak benar.';
$txt['split_first_post'] = 'Anda tidak bisa memisahkan topik di tulisan pertama.';
$txt['topic_one_post'] = 'Topik ini hanya berisi satu pesan dan tidak bisa dipisahkan.';
$txt['no_posts_selected'] = 'tidak ada pesan yang dipilhi';
$txt['selected_all_posts'] = 'Tidak bisa memisahkan. Anda telah memilih setiap pesan.';
$txt['cant_find_messages'] = 'Tidak bisa menemukan pesan';
$txt['cant_find_user_email'] = 'Tidak bisa menemukan alamat email pengguna.';
$txt['cant_insert_topic'] = 'Tidak bisa menyisipkan topik';
$txt['session_timeout'] = 'Your session timed out while posting. Please go back and try again.';
$txt['session_timeout_file_upload'] = 'Your session timed out while uploading the file. Please try again.';
$txt['no_files_uploaded'] = 'There are no files to upload.';
$txt['session_verify_fail'] = 'Session verification failed. Please try logging out and back in again, and then try again.';
$txt['verify_url_fail'] = 'Unable to verify referring URL: %1$s. Please go back and try again.';
$txt['token_verify_fail'] = 'Token verification failed. Please go back and try again.';
$txt['guest_vote_disabled'] = 'Pengunjung tidak bisa memilih dalam polling ini.';

$txt['cannot_access_mod_center'] = 'Anda tidak memiliki ijin untuk mengakses pusat moderasi.';
$txt['cannot_admin_forum'] = 'Anda tidak diijinkan untuk mengadministrasi forum ini.';
$txt['cannot_announce_topic'] = 'Anda tidak diijinkan untuk mengumumkan topik pada board ini.';
$txt['cannot_approve_posts'] = 'Anda tikda mempunyai ijin untuk menyetujui item.';
$txt['cannot_post_unapproved_attachments'] = 'Anda tikda mempunyai ijin untuk menulis lampiran yang tidak disetujui.';
$txt['cannot_post_unapproved_topics'] = 'Anda tikda mempunyai ijin untuk menulis topik yang tidak disetujui.';
$txt['cannot_post_unapproved_replies_own'] = 'Anda tikda mempunyai ijin untuk menulis jawaban yang tidak disetujui ke topik Anda.';
$txt['cannot_post_unapproved_replies_any'] = 'Anda tikda mempunyai ijin untuk menulis jawaban yang tidak disetujui ke topik pengguna lain.';
$txt['cannot_calendar_edit_any'] = 'Anda tidak bisa mengedit event kalender.';
$txt['cannot_calendar_edit_own'] = 'Anda tidak mempunyai hak yang diperlukan untuk mengedit event Anda sendiri.';
$txt['cannot_calendar_post'] = 'Penulisan event tidak diijinkan - maaf.';
$txt['cannot_calendar_view'] = 'Maaf, tapi Anda tidak diijinkan untuk melihat kalender.';
$txt['cannot_remove_any'] = 'Maaf, tapi Anda tidak mempunyai hak untuk menghapus setiap topik. Periksa untuk memastikan topik ini tidak dipindahkan ke board lain.';
$txt['cannot_remove_own'] = 'Anda tidak bisa menghapus topik Anda sendiri dalam board ini. Periksa untuk memastikan topik ini tidak dipindahkan ke board lain.';
$txt['cannot_edit_news'] = 'Anda tidak diijinkan untuk mengedit item berita pada forum ini.';
$txt['cannot_pm_read'] = 'Maaf, Anda tidak bisa membaca pesan pribadi Anda.';
$txt['cannot_pm_send'] = 'Anda tidak diijinkan untuk mengirimkan pesan pribadi.';
$txt['cannot_karma_edit'] = 'Anda tidak diijinkan untuk mengubah karma orang lain.';
$txt['cannot_like_posts'] = 'You are not allowed to like messages in this board.';
$txt['cannot_lock_any'] = 'Anda tidak diijinkan untuk mengunci setiap topik di sini.';
$txt['cannot_lock_own'] = 'Mohon maaf, tapi Anda tidak bisa mengunci topik Anda sendiri di sini.';
$txt['cannot_make_sticky'] = 'You don\'t have permission to pin this topic.';
$txt['cannot_manage_attachments'] = 'Anda tidak diijinkan untuk mengatur lampiran atau avatar.';
$txt['cannot_manage_bans'] = 'Anda tidak diijinkan untuk mengubah daftar pengucilan.';
$txt['cannot_manage_boards'] = 'Anda tidak diijinkan untuk mengatur board dan kategori.';
$txt['cannot_manage_membergroups'] = 'You don\'t have permission to modify or assign member groups.';
$txt['cannot_manage_permissions'] = 'Anda tidak mempunyai ijin untuk mengatur perijinan.';
$txt['cannot_manage_smileys'] = 'Anda tidak diijinkan untuk mengatur smiley dan ikon pesan.';
$txt['cannot_mark_any_notify'] = 'Anda tidak mempunyai ijin untuk mendapatkan pemberitahuan dari topik ini.';
$txt['cannot_mark_notify'] = 'Maaf, tapi Anda tidak diijinkan untuk meminta pemberitahuan dari board ini.';
$txt['cannot_merge_any'] = 'Anda tidak diijinkan untuk menggabung topik pada salah satu board yang dipilih.';
$txt['cannot_moderate_forum'] = 'Anda tidak diijinkan untuk memmoderasi forum ini.';
$txt['cannot_moderate_board'] = 'Anda tidak diijinkan memoderasi board ini.';
$txt['cannot_modify_any'] = 'Anda tidak diijinkan untuk mengubah setiap tulisan.';
$txt['cannot_modify_own'] = 'Maaf, tapi Anda tidak diijinkan untuk mengedit tulisan Anda sendiri.';
$txt['cannot_modify_replies'] = 'Meskipun tulisan ini adalah jawaban ke topik Anda, Anda tidak bisa mengeditnya.';
$txt['cannot_move_own'] = 'Anda tidak diijinkan untuk memindahkan topik Anda sendiri dalam board ini.';
$txt['cannot_move_any'] = 'Anda tidak diijinkan untuk memindahkan topik dalam board ini.';
$txt['cannot_poll_add_own'] = 'Maaf, Anda tidak diijinkan untuk menambah polling ke topik Anda sendiri dalam board ini.';
$txt['cannot_poll_add_any'] = 'Anda tidak mempunyai akses untuk menambah polling ke topik ini.';
$txt['cannot_poll_edit_own'] = 'Anda tidak bisa mengedit polling ini, meskipun ini milik Anda sendiri.';
$txt['cannot_poll_edit_any'] = 'Akses Anda sudah ditolak untuk mengedit polling dalam board ini.';
$txt['cannot_poll_lock_own'] = 'Anda tidak diijinkan untuk mengunci polling Anda sendiri dalam board ini.';
$txt['cannot_poll_lock_any'] = 'Maaf, tapi Anda tidak diijinkan untuk mengunci setiap polling.';
$txt['cannot_poll_post'] = 'Anda tidak diijinkan untuk menulis polling dalam board saat ini.';
$txt['cannot_poll_remove_own'] = 'Anda tidak diijinkan untuk menghapus polling ini dari topik Anda.';
$txt['cannot_poll_remove_any'] = 'Anda tidak bisa menghapus setiap polling pada board ini.';
$txt['cannot_poll_view'] = 'Anda tidak diijinkan untuk melihat polling dalam board ini.';
$txt['cannot_poll_vote'] = 'Maaf, tapi Anda tidak bisa memilih dalam polling pada board ini.';
$txt['cannot_post_attachment'] = 'Anda tidak mempunyai ijin untuk menulis lampiran di sini.';
$txt['cannot_post_new'] = 'Maaf, Anda tidak bisa menulis topik baru dalam board ini.';
$txt['cannot_post_new_board'] = 'Sorry, you cannot post new topics in the board %1$s.';
$txt['cannot_post_reply_any'] = 'Anda tidak diijinkan untuk menulis jawaban ke topik pada board ini.';
$txt['cannot_post_reply_own'] = 'Anda tidak diijinkan untuk menulis jawaban walaupun ke topik Anda sendiri pada board ini.';
$txt['cannot_profile_remove_own'] = 'Maaf, tapi Anda tidak diijinkan untuk menghapus akun Anda sendiri.';
$txt['cannot_profile_remove_any'] = 'You don\'t have the appropriate permissions to remove accounts.';
$txt['cannot_profile_extra_any'] = 'Anda tidak diijinkan untuk mengubah setelan profil.';
$txt['cannot_profile_identity_any'] = 'Anda tidak diijinkan untuk mengedit setelan akun.';
$txt['cannot_profile_title_any'] = 'Anda tidak bisa mengedit judul kustom orang.';
$txt['cannot_profile_extra_own'] = 'Maaf, tapi Anda tidak mempunyai ijin yang cukup untuk mengedit data profil Anda.';
$txt['cannot_profile_identity_own'] = 'Anda tidak bisa mengubah identitas Anda pada saat ini.';
$txt['cannot_profile_title_own'] = 'Anda tidak diijinkan untuk mengubah judul kustom Anda.';
$txt['cannot_profile_set_avatar'] = 'You are not permitted to change your avatar.';
$txt['cannot_profile_view_own'] = 'Mohon maaf, tapi Anda tidak bisa melihat profil Anda sendiri.';
$txt['cannot_profile_view_any'] = 'Mohon maaf, tapi Anda tidak bisa melihat setiap profil.';
$txt['cannot_delete_own'] = 'Ouch, sorry, you cannot delete your posts on this board.';
$txt['cannot_delete_replies'] = 'Maaf, tapi Anda tidak bisa menghapus tulisan ini meskipun mereka menjawab ke topik Anda sendiri.';
$txt['cannot_delete_any'] = 'Ouch, sorry, you cannot delete posts in this board.';
$txt['cannot_report_any'] = 'Anda tidak diijinkan untuk melaporkan tulisan dalam board ini.';
$txt['cannot_search_posts'] = 'Anda tidak diijinkan untuk mencari tulisan dalam forum ini.';
$txt['cannot_send_mail'] = 'Anda tidak mempunyai hak untuk mengirimkan email ke setiap orang.';
$txt['cannot_issue_warning'] = 'Maaf, Anda tidak mempunyai ijin untuk menerbitkan peringatan untuk anggota.';
$txt['cannot_send_topic'] = 'Maaf, tapi administrator sudah tidak mengijinkan mengirimkan topik pada board ini.';
$txt['cannot_send_email_to_members'] = 'Sorry, but the administrator has disallowed sending emails on this board.';
$txt['cannot_split_any'] = 'Memisahkan setiap topik tidak diperbolehkan dalam board ini.';
$txt['cannot_view_attachments'] = 'Nampaknya Anda tidak diijinkan untuk men-download atau melihat lampiran pada board ini.';
$txt['cannot_view_mlist'] = 'You can\'t view the member list because you don\'t have permission to.';
$txt['cannot_view_stats'] = 'Anda tidak diijinkan untuk melihat statistik forum.';
$txt['cannot_who_view'] = 'Maaf - Anda tidak mempunyai ijin yang benar untuk melihat daftar Siapa yang Online.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = ' We can\'t find that theme.';
$txt['theme_dir_wrong'] = 'Direktori tema standar salah, silahkan betulkan dengan mengklik teks ini.';
$txt['registration_disabled'] = 'Maaf, registrasi saat ini dimatikan.';
$txt['registration_agreement_missing'] = 'The registration agreement file, agreement.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Maaf, tidak ada pertanyaan rahasia yang disetel untuk anggota ini.';
$txt['poll_range_error'] = 'Maaf, polling harus dijalankan lebih dari 0 hari.';
$txt['delFirstPost'] = 'You are not allowed to delete the first post in a topic.<p>If you want to delete this topic, click on the Remove link, or ask a moderator/administrator to do it for you.</p>';
$txt['login_cookie_error'] = 'Anda tidak bisa masuk.  Silahkan periksa setelan cookie Anda.';
$txt['incorrect_answer'] = 'Maaf, tapi Anda tidak menjawab pertanyaan Anda dengan benar.  Silahkan klik kembali untuk mencoba lagi, atau klik kembali dua kali untuk menggunakan metode standar mendapatkan kata sandi Anda.';
$txt['no_mods'] = 'Moderator tidak ditemukan!';
$txt['parent_not_found'] = 'Struktur board rusak: tidak bisa menemukan board leluhurnya';
$txt['modify_post_time_passed'] = 'Anda tidak boleh mengubah tulisan ini karena batas waktu mengedit sudah berakhir.';

$txt['calendar_off'] = 'Anda tidak bisa mengakses kalender sekarang karena ia dimatikan.';
$txt['calendar_export_off'] = 'You cannot export calendar events because that feature is currently disabled.';
$txt['invalid_month'] = 'Nilai bulan tidak benar.';
$txt['invalid_year'] = 'Nilai tahun tidak benar.';
$txt['invalid_day'] = 'Nilai tanggal tidak benar.';
$txt['event_month_missing'] = 'Bulan event tidak ada.';
$txt['event_year_missing'] = 'Tahun event tidak ada.';
$txt['event_day_missing'] = 'Tanggal event tidak ada.';
$txt['event_title_missing'] = 'Judul event tidak ada.';
$txt['invalid_date'] = 'Tanggal tidak benar.';
$txt['no_event_title'] = 'Judul event tidak dimasukan.';
$txt['missing_board_id'] = 'ID board tidak ada.';
$txt['missing_topic_id'] = 'ID topik tidak ada.';
$txt['topic_doesnt_exist'] = 'Topik tidak ada.';
$txt['not_your_topic'] = 'Anda bukan pemilik topik ini.';
$txt['board_doesnt_exist'] = 'Board tidak ada.';
$txt['no_span'] = 'Fitur perpanjangan saat ini dimatikan.';
$txt['invalid_days_numb'] = 'Jumlah hari tidak benar untuk diperpanjang.';

$txt['moveto_noboards'] = 'Board tidak ada untuk memindahkan topik ke sana!';
$txt['topic_already_moved'] = 'This topic %1$s has been moved to the board %2$s, please check its new location before moving it again.';

$txt['already_activated'] = 'We\'d love to process your request, but your account has already been activated.';
$txt['still_awaiting_approval'] = 'Akun Anda masih menunggu persetujuan admin.';

$txt['invalid_email'] = 'Alamat email / jangkauan alamat email tidak benar.<br />Contoh alamat email yang benar: evil.user@badsite.com.<br />Contoh jangkauan alamat email yang benar: *@*.badsite.com';
$txt['invalid_expiration_date'] = 'Tanggal berakhir tidak benar';
$txt['invalid_hostname'] = 'Nama host / jangkauan nama host tidak benar.<br />Contoh nama host yang benar: proxy4.badhost.com<br />Contoh jangkauan nama host yang benar: *.badhost.com';
$txt['invalid_ip'] = 'IP / jangkauan IP tidak benar.<br />Contoh alamat IP yang benar: 127.0.0.1<br />Contoh jangkauan IP yang benar: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Invalid IP / IP range.<br />Example of a valid IP address: 127.0.0.1<br />Example of a valid IP range: 127.0.0.*';
$txt['invalid_username'] = 'Nama anggota tidak ditemukan';
$txt['no_user_selected'] = 'Member not found';
$txt['no_ban_admin'] = 'Hey! We can\'t let you ban an admin. If you are certain about this, demote them first!';
$txt['no_bantype_selected'] = 'Tipe pengucilan yang dipilih tidak ada';
$txt['ban_not_found'] = 'Pengucilan tidak ditemukan';
$txt['ban_unknown_restriction_type'] = 'Tipe pembatasan tidak dikenal';
$txt['ban_name_empty'] = 'Nama pengucilan dibiarkan kosong';
$txt['ban_id_empty'] = 'Dang, sorry. We tried to find this ban ID, but it can\'t be found.';
$txt['ban_group_id_empty'] = 'A ban group needs a group ID, and this group didn\'t have any.';
$txt['ban_no_triggers'] = 'Did you forget to select ban triggers? We need at least one, and we haven\'t got any.';
$txt['ban_ban_item_empty'] = 'Ban trigger not found';
$txt['impossible_insert_new_bangroup'] = 'An error occurred while inserting the new ban';

$txt['like_heading_error'] = 'Error in Likes';
$txt['like_wait_time'] = 'Sorry, you can\'t repeat a like action without waiting %1$s %2$s.';
$txt['like_unlike_error'] = 'Oops, there was an error while liking/unliking the post';
$txt['cant_like_yourself'] = 'Liking your own posts ... it\'s like laughing at your own jokes when there is no one else around  ... lol ... Wait did I just lol myself?';

$txt['ban_name_exists'] = 'Nama pengucilan ini sudah ada. Silahkan pilih nama berbeda.';
$txt['ban_trigger_already_exists'] = 'Hal yang memicu ban (%1$s) sudah ada di %2$s. ';
$txt['attach_check_nag'] = 'Unable to continue due to incomplete data (%1$s).';

$txt['recycle_no_valid_board'] = 'Board yang dipilih untuk pembuangan topik tidak benar';
$txt['post_already_deleted'] = 'The topic or message has already been moved to the recycle board. Are you sure you want to delete it completely?<br />If so follow <a href="%1$s">this link</a>';

$txt['login_threshold_fail'] = 'Maaf, Anda kehilangan kesempatan masuk.  Silahkan kembali dan mencoba lagi nanti.';
$txt['login_threshold_brute_fail'] = 'Sorry, but you\'ve reached your login attempts threshold.  Please wait 30 seconds and try again.';

$txt['who_off'] = 'We would love to let you peek at Who\'s Online, but unfortunately right now it\'s disabled.';

$txt['merge_create_topic_failed'] = 'Dang, sorry. We tried, we really did, but creating a new topic failed.';
$txt['merge_need_more_topics'] = 'Merge topics requires at least two topics to merge, but we didn\'t get two. Please try again.';

$txt['post_WaitTime_broken'] = 'Penulisan terakhir dari IP Anda kurang dari %1$d detik lalu. Silahkan coba lagi nanti.';
$txt['register_WaitTime_broken'] = 'Anda sudah terdaftar %1$d detik lalu!';
$txt['login_WaitTime_broken'] = 'Anda harus menunggu sekitar %1$d detik untuk masuk lagi, maaf.';
$txt['pm_WaitTime_broken'] = 'Pesan pribadi terakhir dari IP Anda kurang dari %1$d detik lalu. Silahkan coba lagi nanti.';
$txt['reporttm_WaitTime_broken'] = 'Laporan topik terakhir dari IP Anda kurang dari %1$d detik lalu. Silahkan coba lagi nanti.';
$txt['sendtopic_WaitTime_broken'] = 'Topik yang dikirimkan terakhir dari IP Anda kurang dari %1$d detik lalu. Silahkan coba lagi nanti.';
$txt['sendmail_WaitTime_broken'] = 'Email terakhir yang dikirimkan dari IP Anda kurang dari %1$d detik lalu. Silahkan coba lagi nanti.';
$txt['search_WaitTime_broken'] = 'Pencarian terakhir Anda kurang dari %1$d detik lalu. Silahkan coba lagi nanti.';
$txt['remind_WaitTime_broken'] = 'Your last reminder was less than %1$d seconds ago. Please try again later.';
$txt['contact_WaitTime_broken'] = 'The last time you tried to use the contact form was less than %1$d seconds ago. Please try again later.';

$txt['topic_gone'] = 'We tried very hard to find the topic or board you are looking for, but it\'s nowhere to be found. It appears to be either missing or off limits to you.';
$txt['theme_edit_missing'] = 'We tried very hard to find the file you are trying to edit, but it can\'t be found.';

$txt['no_dump_database'] = 'Sorry, we can\'t let you make database backups. Only administrators can.';
$txt['pm_not_yours'] = 'Pesan pribadi yang coba Anda kutip bukan milik Anda sendiri atau tidak ada, silahkan kembali dan coba lagi.';
$txt['mangled_post'] = 'Bentuk data kompong - silahkan kembali dan coba lagi.';
$txt['too_many_groups'] = 'Sorry, you selected too many groups, please remove some.';
$txt['post_upload_error'] = 'The post data is missing. This error could be caused by trying to submit a file larger than allowed by the server.  Please contact your administrator if this problem continues.';
$txt['quoted_post_deleted'] = 'Tulisan yang coba Anda kutip tidak ada, dihapus, atau tidak lagi bisa dilihat oleh Anda.';
$txt['pm_too_many_per_hour'] = 'Anda telah melebihi batas %1$d pesan pribadi per jam.';
$txt['labels_too_many'] = 'Maaf, %1$s pesan sudah memiliki jumlah label maksimum yang diijinkan!';

$txt['register_only_once'] = 'Maaf, tapi Anda tidak diijinkan untuk mendaftarkan multipel akun pada saat yang sama dari komputer yang sama.';
$txt['admin_setting_coppa_require_contact'] = 'Anda harus memasukan alamat kontak pos atau fax jika diperlukan persetujuan orang tua/wali.';

$txt['error_long_name'] = 'Nama yang coba Anda pakai terlalu panjang.';
$txt['error_no_name'] = 'Nama tidak dilengkapi.';
$txt['error_bad_name'] = 'Nama yang Anda kirimkan tidak bisa dipakai karena berisi nama-nama terpakai.';
$txt['error_no_email'] = 'Alamat email tidak disediakan.';
$txt['error_bad_email'] = 'Alamat email yang diberikan tidak benar.';
$txt['error_email'] = 'email address';
$txt['error_message'] = 'pesan';
$txt['error_no_event'] = 'Nama event tidak ada.';
$txt['error_no_subject'] = 'Subyek tidak diisi.';
$txt['error_no_question'] = 'Pertanyaan tidak diisi untuk polling ini.';
$txt['error_no_message'] = 'Bagian pesan dibiarkan kosong.';
$txt['error_long_message'] = 'Pesan melebihi panjang maksimum yang diperbolehkan (%1$d karakter).';
$txt['error_no_comment'] = 'Isian komentar dibiarkan kosong.';
$txt['error_post_too_long'] = 'Your message is too long. Please enter a maximum of 255 characters.';
$txt['error_session_timeout'] = 'Waktu sesi Anda berakhir ketika menulis. Silahkan coba untuk mengirim ulang pesan Anda.';
$txt['error_no_to'] = 'Penerima tidak ditetapkan.';
$txt['error_bad_to'] = 'Satu atau lebih \'to\'-penerima tidak ditemukan.';
$txt['error_bad_bcc'] = 'Satu atau lebih \'bcc\'-penerima tidak bisa ditemukan.';
$txt['error_form_already_submitted'] = 'You already submitted this post!  You might have accidentally double clicked or refreshed the page.';
$txt['error_poll_few'] = 'Anda harus mempunyai setidaknya dua pilihan!';
$txt['error_poll_many'] = 'You must have no more than 256 choices.';
$txt['error_need_qr_verification'] = 'Silahkan lengkapi seksi verifikasi di bawah untuk melengkapi tulisan Anda.';
$txt['error_wrong_verification_code'] = 'Huruf yang Anda ketik tidak sama dengan huruf yang ditampilkan dalam gambar.';
$txt['error_wrong_verification_answer'] = 'Anda tidak menjawab pertanyaan verifikasi dengan benar.';
$txt['error_need_verification_code'] = 'Silahkan masukkan kode verifikasi di bawah untuk melanjutkan hasilnya.';
$txt['error_bad_file'] = 'Sorry, but the file specified could not be opened: %1$s';
$txt['error_bad_line'] = 'Baris yang Anda tetapkan tidak benar.';
$txt['error_draft_not_saved'] = 'There was an error saving the draft';
$txt['error_name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['smiley_not_found'] = 'Smiley tidak ditemukan.';
$txt['smiley_has_no_code'] = 'Kode untuk smiley ini tidak ada.';
$txt['smiley_has_no_filename'] = 'No file name for this smiley was given.';
$txt['smiley_not_unique'] = 'Smiley dengan kode sudah ada.';
$txt['smiley_set_already_exists'] = 'Set smiley dengan URL itu sudah ada';
$txt['smiley_set_not_found'] = 'Set smiley tidak ditemukan';
$txt['smiley_set_dir_not_found'] = 'The directory of the smiley set %1$s is either invalid or cannot be accessed';
$txt['smiley_set_path_already_used'] = 'URL set smiley sudah dipakai oleh set smiley lain.';
$txt['smiley_set_unable_to_import'] = 'Tidak bisa mengimpor set smiley. Baik direktori tidak benar ataupun tidak bisa diakses.';

$txt['smileys_upload_error'] = 'Gagal meng-upload file.';
$txt['smileys_upload_error_blank'] = 'All smiley sets must have an image.';
$txt['smileys_upload_error_name'] = 'All smileys must have the same file name.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Tipe tidak benar.';

$txt['search_invalid_weights'] = 'Search weights are not configured properly. At least one weight should be configured to be non-zero. Please report this error to an administrator.';

$txt['package_no_file'] = 'Tidak bisa menemukan file paket!';
$txt['packageget_unable'] = 'Tidak bisa menyambung ke server.  Sebaliknya, silahkan coba menggunakan <a href="%1$s" target="_blank">URL ini</a>.';
$txt['not_valid_server'] = 'Sorry, packages can only be downloaded like this from servers you have first authorized.';
$txt['package_cant_uninstall'] = 'Paket ini tidak pernah diinstalasi atau instalasi sudah dibuang - Anda tidak bisa membuangnya sekarang.';
$txt['package_cant_download'] = 'You cannot download or install new packages because the &quot;packages&quot; directory or one of the files in it are not writable!';
$txt['package_upload_error_nofile'] = 'Anda tidak memilih paket yang akan di-upload.';
$txt['package_upload_error_failed'] = 'Tidak bisa meng-upload paket, silahkan periksa perijinan direktori!';
$txt['package_upload_error_exists'] = 'The file you are uploading already exists on the server. Please delete it first, then try again.';
$txt['package_upload_already_exists'] = 'The package you are trying to upload already exists on the server under file name: %1$s';
$txt['package_upload_error_supports'] = 'Manajer paket saat ini hanya mengijinkan tipe file ini: %1$s.';
$txt['package_upload_error_broken'] = 'Paket yang Anda upload gagal karena kesalahan berikut:<br />&quot;%1$s&quot; ';

$txt['package_get_error_not_found'] = 'The package you are trying to install cannot be located. You may want to manually upload the package to your &quot;packages&quot; directory.';
$txt['package_get_error_missing_xml'] = 'Paket yang Anda coba instalasi tidak kekurangan package-info.xml yang harus ada dalam direktori package.';
$txt['package_get_error_is_zero'] = 'Although the package was downloaded to the server it appears to be empty. Please check the &quot;packages&quot; directory, and the &quot;temp&quot; sub-directory are both writable. If you continue to experience this problem you should try extracting the package on your PC and uploading the extracted files into a subdirectory in your &quot;packages&quot; directory and try again. For example, if the package was called shout.tar.gz you should:<br />1) Download the package to your local PC and extract its files.<br />2) Create a new directory in your &quot;packages&quot; folder using an FTP client, in this example you may call it "shout".<br />3) Upload all the files from the extracted package to this directory.<br />4) Go back to the package manager browse page. The package will be automatically found.';
$txt['package_get_error_packageinfo_corrupt'] = 'Unable to find any valid information within the package-info.xml file included within the package. There may be an error in the add-on, or the package may be corrupt.';
$txt['package_get_error_is_theme'] = 'You can\'t install a theme from this section, please use the <a href="{MANAGETHEMEURL}">Theme Management</a> page to upload it';

$txt['no_membergroup_selected'] = 'No member group selected';
$txt['membergroup_does_not_exist'] = 'The member group doesn\'t exist or is invalid.';

$txt['at_least_one_admin'] = 'Harus setidaknya ada satu administrator pada forum!';

$txt['error_functionality_not_windows'] = 'Maaf, fungsionalitas saat ini tidak tersedia pada server berbasis Windows.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Lampiran Tidak Ditemukan';

$txt['error_no_boards_selected'] = 'No valid boards were selected.';
$txt['error_invalid_search_string'] = 'Did you forget to enter something to search for?';
$txt['error_invalid_search_string_blacklist'] = 'Your search query contained trivial words. Please try again with a different query.';
$txt['error_search_string_small_words'] = 'Panjang setiap kata harus setidaknya dua karakter.';
$txt['error_query_not_specific_enough'] = 'Query pencarian Anda tidak menghasilkan yang sama.';
$txt['error_no_messages_in_time_frame'] = 'Tidak ada pesan ditemukan dalam waktu yang dipilih.';
$txt['error_no_labels_selected'] = 'No labels were selected.';
$txt['error_no_search_daemon'] = 'Tidak bisa mengakses daemon pencarian';

$txt['profile_errors_occurred'] = 'The following errors occurred when trying to update your profile';
$txt['profile_error_bad_offset'] = 'Jarak waktu di luar jangkauan';
$txt['profile_error_no_name'] = 'Field nama dibiarkan kosong';
$txt['profile_error_digits_only'] = 'Kotak \'jumlah tulisan\' hanya bisa berisi digit.';
$txt['profile_error_name_taken'] = 'The selected user name/display name has already been taken';
$txt['profile_error_name_too_long'] = 'Nama yang dipilih terlalu panjang. Ia tidak boleh lebih panjang dari 60 karakter';
$txt['profile_error_no_email'] = 'Field email dibiarkan kosong';
$txt['profile_error_bad_email'] = 'Anda belum memasukan alamat email yang benar';
$txt['profile_error_email_taken'] = 'Pengguna lain sudah terdaftar dengan alamat email itu';
$txt['profile_error_no_password'] = 'Anda tidak memasukan kata sandi';
$txt['profile_error_bad_new_password'] = 'Kata sandi baru yang Anda masukan tidak sama';
$txt['profile_error_bad_password'] = 'Kata sandi yang Anda masukan tidak benar';
$txt['profile_error_bad_avatar'] = 'Avatar yang sudah Anda pilih terlalu besar, atau bukan sebuah avatar';
$txt['profile_error_password_short'] = 'Your password must be at least %1$s characters long.';
$txt['profile_error_password_restricted_words'] = 'Your password must not contain your user name, email address or other commonly used words.';
$txt['profile_error_password_chars'] = 'Kata sandi harus berisi campuran huruf besar dan kecil, juga angka.';
$txt['profile_error_already_requested_group'] = 'Anda sudah mempunyai permintaan tertunda untuk grup ini!';
$txt['profile_error_openid_in_use'] = 'Pengguna lain sudah menggunakan URL otentikasi OpenID';
$txt['profile_error_signature_not_yet_saved'] = 'The signature has not been saved.';
$txt['profile_error_personal_text_too_long'] = 'The personal text is too long.';
$txt['profile_error_user_title_too_long'] = 'The custom title is too long.';

$txt['mysql_error_space'] = ' - periksa ruang penyimpanan database atau hubungi administrator server.';

$txt['icon_not_found'] = 'Gambar ikon tidak bisa ditemukan dalam tema standar - pastikan gambar sudah di-upload dan silahkan coba lagi.';
$txt['icon_after_itself'] = 'The icon cannot be positioned after itself.';
$txt['icon_name_too_long'] = 'Icon file names cannot be more than 16 characters long';

$txt['name_censored'] = 'Maaf, nama yang coba Anda pakai, %1$s, berisi kata yang sudah disensor.  Silahkan coba nama lain.';

$txt['poll_already_exists'] = 'A topic can only have one poll associated with it.';
$txt['poll_not_found'] = 'Tidak ada polling yang dikaitkan dengan topik ini!';

$txt['error_while_adding_poll'] = 'Kekksalahan berikut atau kesalahan terjadi saat menambahkan polling ini';
$txt['error_while_editing_poll'] = 'Kesalahan berikut atau kesalahan terjadi saat mengedit polling ini';

$txt['loadavg_search_disabled'] = 'Karena tingginya tekanan pada server, fungsi pencarian sementara sudah dimatikan secara otomatis.  Silahkan coba lagi nanti dalam beberapa waktu.';
$txt['loadavg_generic_disabled'] = 'Maaf, karena tingginya beban pada server, fitur saat ini tidak tersedia.';
$txt['loadavg_allunread_disabled'] = 'The server\'s resources are temporarily under a too high demand to find all the topics you have not read.';
$txt['loadavg_unreadreplies_disabled'] = 'Server saat ini dalam tekanan tinggi.  Silahkan coba lagi dalam waktu dekat.';
$txt['loadavg_show_posts_disabled'] = 'Silakan coba lagi nanti.  Tulisan anggota untuk saat ini tidak tersedia karena tingginya beban pada server.';
$txt['loadavg_unread_disabled'] = 'The server\'s resources are temporarily under a too high demand to list out the topics you have not read.';
$txt['loadavg_userstats_disabled'] = 'Please try again later.  This member\'s statistics are not currently available due to high load on the server.';

$txt['cannot_edit_permissions_inherited'] = 'You cannot edit inherited permissions directly, you must either edit the parent group or edit the member group inheritance.';

$txt['mc_no_modreport_specified'] = 'Anda perlu untuk menetapkan laporan mana yang ingin Anda lihat.';
$txt['mc_no_modreport_found'] = 'Laporan yang ditetapkan tidak ada atau terbatas bagi Anda';

$txt['st_cannot_retrieve_file'] = 'Tidak bisa mengambil file %1$s.';
$txt['admin_file_not_found'] = 'Tidak bisa mengambil file yang diminta: %1$s.';

$txt['themes_none_selectable'] = 'Setidaknya satu tema harus bisa dipilih.';
$txt['themes_default_selectable'] = 'Tema standar forum keseluruhan harus tema yang bisa dipilih.';
$txt['ignoreboards_disallowed'] = 'Opsi untuk mengabaikan board belum dihidupkan.';

$txt['mboards_delete_error'] = 'No category selected.';
$txt['mboards_delete_board_error'] = 'No board selected.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'You can not make a parent its own child.';
$txt['mboards_board_own_child_error'] = 'You can not make a board its own child.';

$txt['smileys_upload_error_notwritable'] = 'Direktori smiley berikut tidak bisa ditulis: %1$s';
$txt['smileys_upload_error_types'] = 'Gambar hanya boleh mempunyai ekstensi berikut: %1$s.';

$txt['change_email_success'] = 'Alamat email Anda sudah diubah, dan email aktivasi sudah dikirimkan ke alamat itu.';
$txt['resend_email_success'] = 'Email aktivasi baru sudak dikirimkan dengan sukses.';

$txt['custom_option_need_name'] = 'The profile option must have a name.';
$txt['custom_option_not_unique'] = 'Field name is not unique.';
$txt['custom_option_regex_error'] = 'The regex you entered is not valid';

$txt['warning_no_reason'] = 'Anda harus memasukan alasan untuk perubahan kondisi peringatan seorang anggota.';
$txt['warning_notify_blank'] = 'Anda memilih untuk memberitahu pengguna tapi tidak mengisi field subyek/pesan.';

$txt['cannot_connect_doc_site'] = 'Could not connect to the documentation site. Please check that your server configuration allows external internet connections and try again later.';

$txt['movetopic_no_reason'] = 'Anda harus memasukkan alasan untuk memindahkan topik, atau jangan centang opsi \'tulis topik pengalihan\'.';
$txt['movetopic_no_board'] = 'You must choose a board to move the topic to.';

$txt['splittopic_no_reason'] = 'You must enter a reason for splitting the topic, or uncheck the option to \'post a redirection message\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Pengenal yang diminta tidak mengembalikan informasi yang benar.';
$txt['openid_return_no_mode'] = 'Penyedia identitas tidak merespon dengan mode Open ID.';
$txt['openid_not_resolved'] = 'Penyedia identitas tidak menyetujui permintaan Anda.';
$txt['openid_no_assoc'] = 'Tidak menemukan asosiasi yang diminta dengan penyedia identitas.';
$txt['openid_sig_invalid'] = 'Tanda tangan dari penyedia identitas tidak benar.';
$txt['openid_load_data'] = 'Tidak dapat mengambil data dari permintaan masuk Anda.  Silahkan coba lagi.';
$txt['openid_not_verified'] = 'The supplied OpenID has not been verified yet.  Please log in to verify.';

$txt['error_custom_field_too_long'] = 'Panjang field &quot;%1$s&quot; tidak oleh lebih besar dari %2$d karakter.';
$txt['error_custom_field_invalid_email'] = 'Field &quot;%1$s&quot; harus berupa alamat email yang benar.';
$txt['error_custom_field_not_number'] = 'Field &quot;%1$s&quot; harus numerik.';
$txt['error_custom_field_inproper_format'] = 'Format field &quot;%1$s&quot; tidak benar.';
$txt['error_custom_field_empty'] = 'Field &quot;%1$s&quot; tidak boleh dibiarkan kosong.';

$txt['email_no_template'] = 'Template email &quot;%1$s&quot; tidak dapat ditemukan.';

$txt['search_api_missing'] = 'The search API could not be found. Please contact the admin to check they have uploaded the correct files.';
$txt['search_api_not_compatible'] = 'The selected search API the forum is using is out of date - falling back to standard search. Please check the file %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Anda tidak bisa mengembalikan tulisan pertama dalam sebuah topik.';
$txt['restored_disabled'] = 'Pengembalian topik sudah dimatikan.';
$txt['restore_not_found'] = 'The following messages could not be restored; the original topic may have been removed: %1$s You will need to move these manually.';

$txt['error_invalid_dir'] = 'Direktori yang Anda masukkan tidak benar.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'The Sub-action you requested is not defined';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'No sortable items were found';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
