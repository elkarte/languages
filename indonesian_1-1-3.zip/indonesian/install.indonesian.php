<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Selamat datang';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Pemeriksaan Penulisan';
$txt['install_step_forum'] = 'Setelan Dasar';
$txt['install_step_databaseset'] = 'Setelan Database';
$txt['install_step_databasechange'] = 'Populasi Database';
$txt['install_step_admin'] = 'Akun Admin';
$txt['install_step_delete'] = 'Finalize Installation';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'Bahasa';
$txt['installer_language_set'] = 'Set';
$txt['congratulations'] = 'Selamat, proses instalasi selesai!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Direktori instalasi Anda masih bisa ditulis.  Alangkah baiknya untuk melakukan chmod pada direktori itu agar tidak bisa ditulis untuk alasan keamanan.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(tidak bekerja pada semua server.)</em>';
$txt['go_to_your_forum'] = 'Sekarang Anda dapat melihat <a href="%1$s">forum yang baru saja diinstalasi</a> dan mulai menggunakannya.  Anda harus masuk lebih dulu, setelah itu Anda akan bisa mengakses pusat administrasi.';
$txt['good_luck'] = 'Thanks for installing ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Selamat datang';
$txt['install_welcome_desc'] = 'Welcome to ElkArte. This script will guide you through the process for installing %1$s. We\'ll gather a few details about your forum over the next few steps, and after a couple of minutes your forum will be ready for use.';
$txt['install_all_lovely'] = 'Kami selesai dengan beberapa pengujian awal pada server Anda dan nampaknya semua sudah sesuai. CUkup klik tombol &quot;Lanjutkan&quot; di bawah untuk memulai.';

$txt['user_refresh_install'] = 'Forum Disegarkan';
$txt['user_refresh_install_desc'] = 'Selama instalasi, instalator menemukan bahwa (dengan rincian yang Anda sediakan) satu atau lebih tabel yang akan dibuat instalator ini sudah ada.<br />Setiap tabel yang kurang dalam instalasi Anda sudah dibuat ulang dengan data standar, tapi tidak ada data yang dihapus dari tabel yang sudah ada.';

$txt['default_topic_subject'] = 'Welcome to ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Diskusi Umum';
$txt['default_board_description'] = 'Bebas untuk membicarakan apa saja dalam board ini.';
$txt['default_category_name'] = 'Kategori Umum';
$txt['default_time_format'] = '%d %B %Y, %I:%M:%S %p';
$txt['default_news'] = 'ElkArte - Just Installed!';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[tampar]';
$txt['default_karmaApplaudLabel'] = '[sanjung]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGuest\\nroot';
$txt['default_smileyset_name'] = 'Fugue\'s Set';
$txt['default_theme_name'] = 'ElkArte Default Theme';

$txt['default_administrator_group'] = 'Administrator';
$txt['default_global_moderator_group'] = 'Global Moderator';
$txt['default_moderator_group'] = 'Moderator';
$txt['default_newbie_group'] = 'Pemula';
$txt['default_junior_group'] = 'Anggota Junior';
$txt['default_full_group'] = 'Anggota Penuh';
$txt['default_senior_group'] = 'Anggota Senior';
$txt['default_hero_group'] = 'Anggota Abadi';

$txt['default_smiley_smiley'] = 'Senyum';
$txt['default_wink_smiley'] = 'Berkedip';
$txt['default_cheesy_smiley'] = 'Cheesy';
$txt['default_grin_smiley'] = 'Geram';
$txt['default_angry_smiley'] = 'Marah';
$txt['default_sad_smiley'] = 'Sedih';
$txt['default_shocked_smiley'] = 'Terkejut';
$txt['default_cool_smiley'] = 'Hebat';
$txt['default_huh_smiley'] = 'Hah?';
$txt['default_roll_eyes_smiley'] = 'Mata Bergulir';
$txt['default_tongue_smiley'] = 'Mengejek';
$txt['default_embarrassed_smiley'] = 'Malu';
$txt['default_lips_sealed_smiley'] = 'Tutup mulut';
$txt['default_undecided_smiley'] = 'Bingung';
$txt['default_kiss_smiley'] = 'Cium';
$txt['default_cry_smiley'] = 'Menangis';
$txt['default_evil_smiley'] = 'Setan';
$txt['default_azn_smiley'] = 'Azn';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Tertawa';
$txt['default_police_smiley'] = 'Polisi';
$txt['default_angel_smiley'] = 'Malaikat';

$txt['error_message_click'] = 'Klik di sini';
$txt['error_message_try_again'] = 'untuk mencoba langkah ini lagi.';
$txt['error_message_bad_try_again'] = 'untuk tetap mencoba menginstalasi, tapi catatan bahwa ini <em>sangat tidak</em> disarankan.';

$txt['install_settings'] = 'Setelan Dasar';
$txt['install_settings_info'] = 'This page requires you to define a few key settings for your forum. ElkArte has automatically detected key settings for you.';
$txt['install_settings_name'] = 'Nama forum';
$txt['install_settings_name_info'] = 'This is the name of your forum, e.g. &quot;The Testing Forum&quot;.';
$txt['install_settings_name_default'] = 'Komunitas Saya';
$txt['install_settings_url'] = 'URL Forum';
$txt['install_settings_url_info'] = 'Ini adalah URL ke forum Anda <strong>tanpa akhiran \'/\'!</strong>.<br />Dalam banyak kasus, Anda dapat membiarkan nilai standar dalam kotak ini - ia biasanya benar.';
$txt['install_settings_compress'] = 'Output Gzip';
$txt['install_settings_compress_title'] = 'Kompresi output untuk menghemat bandwidth.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'This function does not work properly on all servers, but can save you a lot of bandwidth.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Click here to test it</a>. (it should just say "PASS".)';
$txt['install_settings_dbsession'] = 'Sesi Database';
$txt['install_settings_dbsession_title'] = 'Gunakan database untuk sesi daripada menggunakan file.';
$txt['install_settings_dbsession_info1'] = 'Fitur ini hampir selalu jadi yang terbaik, karena menjadikan sesi lebih berdiri sendiri.';
$txt['install_settings_dbsession_info2'] = 'Fitur ini umumnya adalah ide yang baik, tapi mungkin tidak bekerja pada server ini.';
$txt['install_settings_proceed'] = 'Lanjutkan';

$txt['db_settings'] = 'Setelan Server Database';
$txt['db_settings_info'] = 'Ini adalah setelan untuk menggunakan server database Anda.  Jika Anda tidak mengetahui nilainya, Anda harus meminta kepada host Anda.';
$txt['db_settings_type'] = 'Tipe Database';
$txt['db_settings_type_info'] = 'Multiple supported database types were detected - which one do you wish to use?';
$txt['db_settings_server'] = 'Nama server';
$txt['db_settings_server_info'] = 'Ini hampir selalu localhost - jika Anda tidak mengetahuinya, coba localhost.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Leave empty if your server is listening on the default port, or you are uncertain.';
$txt['db_settings_username'] = 'User name';
$txt['db_settings_username_info'] = 'Fill in the user name you need to connect to your database here.<br />If you don\'t know what it is, try the user name of your FTP account, most of the time they are the same.';
$txt['db_settings_password'] = 'Kata sandi';
$txt['db_settings_password_info'] = 'Here you should put the password you need to connect to your database.<br />If you don\'t know this, you should try the password to your FTP account.';
$txt['db_settings_database'] = 'Nama database';
$txt['db_settings_database_info'] = 'Fill in the name of the database you want to use for ElkArte to store its data in.';
$txt['db_settings_database_info_note'] = 'Jika database ini tidak ada, instalator ini akan mencoba membuatnya.';
$txt['db_settings_database_file'] = 'Database file name';
$txt['db_settings_database_file_info'] = 'This is the name of the file in which to store the ElkArte data. We recommend you use the randomly generated name for this and set the path of this file to be outside of the public area of your webserver.';
$txt['db_settings_prefix'] = 'Awalan tabel';
$txt['db_settings_prefix_info'] = 'Awalan untuk setiap tabel dalam database.  <strong>Jangan menginstalasi dua forum dengan awalan yang sama!</strong><br />Nilai ini mengijinkan multipel instalasi dalam satu database.';
$txt['db_populate'] = 'Database Dipopulasi';
$txt['db_populate_info'] = 'Setelan Anda sekarang sudah disimpan dan database sudah dipopulasikan dengan semua data yang diperlukan agar forum Anda siap dijalankan. Ringkasan populasi:';
$txt['db_populate_info2'] = 'Klik &quot;Lanjutkan&quot; untuk maju ke halaman pembuatan akun admin.';
$txt['db_populate_inserts'] = 'Disisipkan %1$d baris.';
$txt['db_populate_tables'] = 'Dibuat %1$d tabel.';
$txt['db_populate_insert_dups'] = 'Diabaikan %1$d duplikasi penyisipan.';
$txt['db_populate_table_dups'] = 'Diabaikan %1$d duplikasi tabel.';

$txt['user_settings'] = 'Buat Akun Anda';
$txt['user_settings_info'] = 'Instalator sekarang akan membuat akun administrator baru bagi Anda.';
$txt['user_settings_username'] = 'Your user name';
$txt['user_settings_username_info'] = 'Choose the name you want to login with.';
$txt['user_settings_password'] = 'Kata sandi';
$txt['user_settings_password_info'] = 'Isi kata sandi yang diinginkan di sini, dan ingat dengan baik!';
$txt['user_settings_again'] = 'Kata sandi';
$txt['user_settings_again_info'] = '(hanya untuk verifikasi.)';
$txt['user_settings_email'] = 'Alamat Email';
$txt['user_settings_email_info'] = 'Lengkapi alamat email Anda juga.  <strong>Ini harus alamat email yang benar.</strong>';
$txt['user_settings_database'] = 'Kata sandi Database';
$txt['user_settings_database_info'] = 'Instalator memerlukan Anda untuk menyediakan kata sandi database untuk membuat akun administrator, untuk alasan keamanan.';
$txt['user_settings_skip'] = 'Lewati';
$txt['user_settings_skip_sure'] = 'Anda yakin ingin melewatkan pembuatan akun admin?';
$txt['user_settings_proceed'] = 'Selesai';

$txt['ftp_checking_writable'] = 'Checking if files are writable';
$txt['ftp_setup'] = 'Informasi Koneksi FTP';
$txt['ftp_setup_info'] = 'Instalator bisa menyambung via FTP untuk membetulkan file yang perlu bisa ditulis atau tidak.  Jika ini tidak bekerja bagi Anda, Anda harus melakukannya secara manual dan menjadikan file bisa ditulis.  Harap dicatat bahwa ini tidak mendukung SSL untuk saat ini.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'This should be the server address and port for your FTP server.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'User name';
$txt['ftp_username_info'] = 'The user name to login with. <em>This will not be saved anywhere.</em>';
$txt['ftp_password'] = 'Kata sandi';
$txt['ftp_password_info'] = 'Kata sandi untuk masuk. <em>Ini tidak akan disimpan di manapun.</em>';
$txt['ftp_path'] = 'Path Instalasi';
$txt['ftp_path_info'] = 'Ini adalah path <em>relatif</em> yang Anda pakai dalam server FTP Anda.';
$txt['ftp_path_found_info'] = 'Path dalam kotak di atas secara otomatis dideteksi.';
$txt['ftp_connect'] = 'Sambung';
$txt['ftp_setup_why'] = 'Untuk apa langkah ini?';
$txt['ftp_setup_why_info'] = 'Some files need to be writable for ElkArte to work properly.  This step allows you to let the installer make them writable for you.  However, in some cases it won\'t work - in that case, please make the following files 777 (writable, 755 on some hosts):';
$txt['ftp_setup_again'] = 'untuk menguji apakah file ini bisa ditulis lagi.';

$txt['error_php_too_low'] = 'Warning!  You do not appear to have a version of PHP installed on your webserver that meets ElkArte\'s <strong>minimum installations requirements</strong>.<br />If you are not the host, you will need to ask your host to upgrade, or use a different host - otherwise, please upgrade PHP to a recent version.<br /><br />If you know for a fact that your PHP version is high enough you may continue, although this is strongly discouraged.';
$txt['error_missing_files'] = 'Tidak bisa menemukan file instalasi krusial dalam direktori naskah ini!<br /><br />Pastikan Anda meng-upload seluruh paket instalasi, termasuk file sql, dan kemudian coba lagi.';
$txt['error_session_save_path'] = 'Silahkan beritahu host Anda bahwa <strong>session.save_path yang ditetapkan dalam php.ini</strong> tidak benar!  Ia perlu diubah ke direktori yang <strong>ada</strong>, dan <strong>bisa ditulis</strong> oleh pengguna di mana PHP dijalankan.<br />';
$txt['error_windows_chmod'] = 'You\'re on a windows server, and some crucial files are not writable.  Please ask your host to give <strong>write permissions</strong> to the user PHP is running under for the files in your ElkArte installation.  The following files or directories need to be writable:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Tidak bisa menyambung ke server FTP dengan kombinasi rincian.';
$txt['error_db_file'] = 'Tidak bisa menemukan naskah sumber database! Silahkan periksa file %1$s di dalam direktori sumber forum Anda.';
$txt['error_db_connect'] = 'Tidak bisa menyambung ke server database dengan data yang disediakan.<br /><br />Jika Anda tidak yakin mengenai apa yang harus diketik, silahkan hubungi host Anda.';
$txt['error_db_too_low'] = 'The version of your database server is very old and does not meet ElkArte\'s minimum requirements.<br /><br />Please ask your host to either upgrade it or supply a new one, and if they won\'t, please try a different host.';
$txt['error_db_database'] = 'The installer was unable to access the &quot;<em>%1$s</em>&quot; database.  With some hosts, you have to create the database in your administration panel before ElkArte can use it.  Some also add prefixes - like your username - to your database names.';
$txt['error_db_queries'] = 'Beberapa query tidak dijalankan dengan benar.  Ini dapat disebabkan oleh versi software database Anda yang tidak didukung (pengembangan atau lama).<br /><br />Informasi teknis mengenai query:';
$txt['error_db_queries_line'] = 'Baris #';
$txt['error_db_missing'] = 'The installer was unable to detect database support in PHP that ElkArte can utilize.  Please ask your host to ensure that PHP was compiled with the desired database, or that the proper php extension is being loaded.  Currently ElkArte supports the:  &quot;%1$s&quot; extensions';
$txt['error_db_script_missing'] = 'The installer could not find any install script files for the detected databases. Please check you have uploaded the necessary install script files to your forum directory, for example &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Instalator tidak bisa mendeteksi dukungan sesi dalam instalasi PHP server Anda.  Silahkan minta host Anda untuk memastikan bahwa PHP dikompilasi dengan dukungan sesi (sebenarnya, harus dikompilasi tanpa itu secara eksplisit.)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Anda mengetikkan dua kata sandi yang sama sekali berbeda!';
$txt['error_user_settings_no_password'] = 'Panjang kata sandi Anda harus setidaknya empat karakter.';
$txt['error_user_settings_taken'] = 'Sorry, a member is already registered with that user name and/or email address.<br /><br />A new account has not been created.';
$txt['error_user_settings_query'] = 'Kesalahan database terjadi saat mencoba untuk membuat administrator.  Kesalahan ini adalah:';
$txt['error_subs_missing'] = 'Unable to find the sources/Subs.php file.  Please make sure it was uploaded properly, and then try again.';
$txt['error_db_alter_priv'] = 'The database account you specified does not have permission to ALTER, CREATE, and/or DROP tables in the database; this is necessary for ElkArte to function properly.';
$txt['error_versions_do_not_match'] = 'The installer has detected another version of ElkArte already installed with the specified information.  If you are trying to upgrade, you should use the upgrader, not the installer.<br /><br />Otherwise, you may wish to use different information, or create a backup and then delete the data currently in the database.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'The current version of your database doesn\'t support the use of the UTF-8 character set. You can not install ElkArte';
$txt['error_valid_email_needed'] = 'Anda tidak memasukkan alamat email yang benar.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Peringatan!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Anda harus memasukkan nama file database untuk SQLite.';
$txt['error_db_prefix_numeric'] = 'Tipe database yang dipilih tidak mendukung pemakaian prefiks numerik.';
$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';
$txt['error_username_too_long'] = 'User name must be less than 25 characters long.';
$txt['error_username_left_empty'] = 'User name field was left empty.';
$txt['error_db_filename_exists'] = 'Database yang coba Anda buat sudah ada.  Silahkan hapus file database saat ini atau masukkan nama lain.';
$txt['error_db_prefix_reserved'] = 'Prefiks yang Anda masukkan adalah prefiks terpakai.  Silahkan masukkan prefiks lain.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade Utility';
$txt['upgrade_warning'] = 'Peringatan!';
$txt['upgrade_critical_error'] = 'Kesalahan Kritis!';
$txt['upgrade_continue'] = 'Lanjutkan';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Lewati';
$txt['upgrade_note'] = 'Catatan!';
$txt['upgrade_step'] = 'Maju';
$txt['upgrade_steps'] = 'Langkah';
$txt['upgrade_progress'] = 'Progres';
$txt['upgrade_overall_progress'] = 'Progres Keseluruhan';
$txt['upgrade_step_progress'] = 'Progres Langkah';
$txt['upgrade_time_elapsed'] = 'Jam Berlalu';
$txt['upgrade_time_mins'] = 'menit';
$txt['upgrade_time_secs'] = 'detik';

$txt['upgrade_incomplete'] = 'Tidak Lengkap';
$txt['upgrade_not_quite_done'] = 'Belum selesai benar!';
$txt['upgrade_paused_overload'] = 'Pemutakhiran ini sudah dihentikan guna menghindari beban berlebih pada server Anda.  Jangan khawatir, tidak ada yang salah - cukup klik <label for="contbutt">tombol lanjutkan</label> di bawah untuk melanjutkan.';

$txt['upgrade_ready_proceed'] = 'Thank you for choosing to upgrade to ElkArte %1$s. All files appear to be in place, and we\'re ready to proceed.';

$txt['upgrade_error_script_js'] = 'The upgrade script cannot find script.js or it is out of date. Make sure your theme paths are correct. You can download a settings check and repair script from <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte tools</a>.';

$txt['upgrade_warning_lots_data'] = 'Naskah pemutakhiran ini mendeteksi bahwa forum Anda berisi banyak data yang perlu dimutakhirkan. Proses ini dapat memerlukan waktu cukup lama tergantung pada ukuran forum dan server Anda, dan untuk forum yang sangat besar (~300,000 pesan) bisa berjam-jam untuk menyelesaikannya.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';