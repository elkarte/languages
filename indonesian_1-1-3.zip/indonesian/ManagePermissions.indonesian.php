<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Mengatur Perijinan';
$txt['permissions_modify'] = 'Ubah';
$txt['permissions_view'] = 'Lihat';
$txt['permissions_allowed'] = 'Diijinkan';
$txt['permissions_denied'] = 'Ditolak';
$txt['permission_cannot_edit'] = '<strong>Note:</strong> You cannot edit this permission profile as it is a predefined profile included within the forum software by default. If you wish to change the permissions of this profile you must first create a duplicate profile. You can <a href="%1$s">carry out this task by clicking here</a>.';

$txt['permissions_for_profile'] = 'Perijinan Profil';
$txt['permissions_boards_desc'] = 'Daftar berikut menampilkan set perijinan mana yang sudah ditempatkan ke setiap board pada forum. Anda dapat mengedit profil perijinan yang ditempatkan dengan mengklik nama board atau memilih &quot;edit semua&quot; dari bawah halaman. Untuk mengedit profil itu sendiri cukup klik nama profil.';
$txt['permissions_board_all'] = 'Edit Semua';
$txt['permission_profile'] = 'Profil Perijinan';
$txt['permission_profile_desc'] = 'Which <a target="_blank" href="%1$s">permission set</a> the board should use.';
$txt['permission_profile_inherit'] = 'Turunkan dari board leluhur';

$txt['permissions_profile'] = 'Profil';
$txt['permissions_profiles_desc'] = 'Profil perijinan ditempatkan ke board individual untuk mengijinkan Anda dengan mudah mengatur setelan keamanan. Dari area ini Anda dapat membuat, mengedit dan menghapus profil perijinan.';
$txt['permissions_profiles_change_for_board'] = 'Edit Profil Perijinan Untuk: &quot;%1$s&quot;';
$txt['permissions_profile_default'] = 'Standar';
$txt['permissions_profile_no_polls'] = 'Tidak ada Polling';
$txt['permissions_profile_reply_only'] = 'Hanya Jawab';
$txt['permissions_profile_read_only'] = 'Hanya Baca';

$txt['permissions_profile_rename'] = 'Rename all';
$txt['permissions_profile_edit'] = 'Edit Profil';
$txt['permissions_profile_new'] = 'Profil Baru';
$txt['permissions_profile_new_create'] = 'Buat';
$txt['permissions_profile_name'] = 'Nama Profil';
$txt['permissions_profile_used_by'] = 'Dipakai Oleh';
$txt['permissions_profile_used_by_one'] = '1 Board';
$txt['permissions_profile_used_by_many'] = '%1$d Board';
$txt['permissions_profile_used_by_none'] = 'Tidak ada Board';
$txt['permissions_profile_do_edit'] = 'Edit';
$txt['permissions_profile_do_delete'] = 'Hapus';
$txt['permissions_profile_copy_from'] = 'Copy Perijinan Dari';

$txt['permissions_includes_inherited'] = 'Turunan Grup';
$txt['permissions_includes_inherited_from'] = 'Inherited from: ';

$txt['permissions_all'] = 'semua';
$txt['permissions_none'] = 'tidak ada';
$txt['permissions_set_permissions'] = 'Setel perijinan';

$txt['permissions_advanced_options'] = 'Opsi Lanjutan';
$txt['permissions_with_selection'] = 'Dengan pilihan';
$txt['permissions_apply_pre_defined'] = 'Terapkan pra-definisi perijinan profil';
$txt['permissions_select_pre_defined'] = 'Pilih pra-definisi profil';
$txt['permissions_copy_from_board'] = 'Copy perijinan dari board ini';
$txt['permissions_select_board'] = 'Pilih board';
$txt['permissions_like_group'] = 'Setel perijinan seperti grup ini';
$txt['permissions_select_membergroup'] = 'Select a member group';
$txt['permissions_add'] = 'Tambah perijinan';
$txt['permissions_remove'] = 'Hapus perijinan';
$txt['permissions_deny'] = 'Tolak perijinan';
$txt['permissions_select_permission'] = 'Pilih perijinan';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Anda hanya bisa memilih satu aksi untuk memodifikasi perijinan';
$txt['permissions_no_action'] = 'Tindakan tidak dipilih';
$txt['permissions_deny_dangerous'] = 'Anda akan menolak satu atau lebih perijinan.\\nIni bisa berbahaya dan menyebabkan hasil yang tidak diharapkan jika Anda belum yakin tidak seorangpun \\"secara kebetulan\\" di dalam grup yang Anda tolak perijinannya.\\n\\nAnda yakin ingin melanjutkan?';

$txt['permissions_modify_group'] = 'Ubah Grup';
$txt['permissions_general'] = 'Perijinan dengan Grup anggota';
$txt['permissions_board'] = 'Perijinan Board Standar';
$txt['permissions_board_desc'] = '<strong>Catatan</strong>: mengubah perijinan board ini akan mempengaruhi semua profil perijinan &quot;Standar&quot; saat ini pada board. Board tidak menggunakan profil &quot;Standar&quot; tidak akan dipengaruhi dengan mengubah halaman ini.';
$txt['permissions_commit'] = 'Simpan Perubahan';
$txt['permissions_on'] = 'dalam profil';
$txt['permissions_local_for'] = 'Perijinan untuk grup';
$txt['permissions_option_on'] = 'A';
$txt['permissions_option_off'] = 'X';
$txt['permissions_option_deny'] = 'D';
$txt['permissions_option_desc'] = 'For each permission you can pick either \'Allow\' (A), \'Disallow\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />Remember that if you deny a permission, any member - whether moderator or otherwise - that is in that group will be denied that as well.<br />For this reason, you should use deny carefully, only when <strong>necessary</strong>. Disallow, on the other hand, denies unless otherwise granted.';

$txt['permissiongroup_general'] = 'Umum';
$txt['permissionname_view_stats'] = 'Lihat statistik forum';
$txt['permissionhelp_view_stats'] = 'Statistik forum adalah sebuah halaman yang meringkas seluruh statistik forum, seperti jumlah anggota, jumlah tulisan harian, dan beberapa statistik 10 teratas. Menghidupkan perijinan ini akan menambah link di bawah indeks board (\'[Statistik Lengkap]\').';
$txt['permissionname_view_mlist'] = 'View the member list and groups';
$txt['permissionhelp_view_mlist'] = 'The member list shows all members that have registered on your forum. The list can be sorted and searched. The member list is linked from both the board index and the stats page, by clicking on the number of members. It also applies to the groups page which is a mini memberlist of people in that group.';
$txt['permissionname_who_view'] = 'Lihat Siapa yang Online';
$txt['permissionhelp_who_view'] = 'Siapa yang online menampilkan semua anggota yang saat ini online dan apa yang mereka lakukan pada saat ini. Perijinan ini hanya akan bekerja jik Anda juga menghidupkannya dalam \'Fitur dan Opsi\'. Anda dapat mengakses layar \'Siapa Online\' dengan mengklik link dalam seksi \'Pengguna Online\' dari indeks board. Meskipun ditolak, anggota masih akan bisa melihat siapa yang online, hanya tidak di mana mereka berada.';
$txt['permissionname_search_posts'] = 'Mencari tulisan dan topik';
$txt['permissionhelp_search_posts'] = 'Perijinan pencarian membolehkan pengguna untuk mencari semua board di mana dia diijinkan untuk mengakses. Ketika perijinan pencarian dihidupkan, tombol \'Cari\' akan ditambahkan ke bar tombol forum.';
$txt['permissionname_karma_edit'] = 'Ubah karma orang lain';
$txt['permissionhelp_karma_edit'] = 'Karma is a feature that shows the popularity of a member. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to cast a vote. This permission has no effect on guests.';
$txt['permissionname_like_posts'] = 'Like other users\' posts';
$txt['permissionhelp_like_posts'] = 'Likes is a feature that shows the popularity of a post. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to like a post or unlike one they previously liked.  This permission has no effect on guests.';
$txt['permissionname_like_posts_stats'] = 'See like posts stats';
$txt['permissionhelp_like_posts_stats'] = 'This will allow users to see stats of posts liking';
$txt['permissionname_disable_censor'] = 'Disable word censor';
$txt['permissionhelp_disable_censor'] = 'Allows members the option to disable the word censor.';

$txt['permissiongroup_pm'] = 'Pesan Pribadi';
$txt['permissionname_pm_read'] = 'Baca pesan pribadi';
$txt['permissionhelp_pm_read'] = 'Perijinan ini membolehkan pengguna untuk mengakses seksi Pesan Pribadi dan membaca Pesan Pribadinya. Tanpa perijinan ini pengguna tidak bisa untuk mengirimkan Pesan Pribadi.';
$txt['permissionname_pm_send'] = 'Kirim pesan pribadi';
$txt['permissionhelp_pm_send'] = 'Kirimkan pesan pribadi ke anggota terdaftar lain. Memerlukan perijinan \'Baca pesan pribadi\'.';
$txt['permissionname_send_email_to_members'] = 'Send emails';
$txt['permissionhelp_send_email_to_members'] = 'Send emails to other registered members.';

$txt['permissiongroup_calendar'] = 'Kalender';
$txt['permissionname_calendar_view'] = 'Lihat kalender';
$txt['permissionhelp_calendar_view'] = 'Kalender menampilkan setiap ulang tahun setiap bulannya, acara dan hari libur. Perijinan ini membolehkan akses ke kalender ini. Ketika perijinan ini dihidupkan, tombol akan ditambahkan ke bar tombol atas dan sebuah daftar akan ditampilkan di bawah indeks board dengan menampilkan ulang tahun sekarang dan yang akan datang, acara dan hari libur mendatang. Kalender perlu dihidupkan dari \'Edit Fitur dan Opsi\'.';
$txt['permissionname_calendar_post'] = 'Buat event dalam kalender';
$txt['permissionhelp_calendar_post'] = 'Sebuah event adalah topik yang dihubungkan ke tanggal dan jangkauan tanggal tertentu. Pembuatan event bisa dikerjakan dari kalender. Sebuah event hanya bisa dibuat jika pengguna yang membuat event diijinkan untuk menulis topik baru.';
$txt['permissionname_calendar_edit'] = 'Edit event dalam kalender';
$txt['permissionhelp_calendar_edit'] = 'Sebuah event adalah topik yang dihubgungkan ke tanggal atau jangkauan tanggal tertentu. Event dapat diedit dengan mengklik bintang merah (*) di sebelah event dalam tampilan kalender. Untuk bisa mengedit sebuah event, pengguna harus memiliki ijin yang cukup untuk mengedit pesan pertama pada topik yang dikaitkan ke event ini.';
$txt['permissionname_calendar_edit_own'] = 'Event sendiri';
$txt['permissionname_calendar_edit_any'] = 'Setiap event';

$txt['permissiongroup_maintenance'] = 'Administrasi forum';
$txt['permissionname_admin_forum'] = 'Administrasi forum dan database';
$txt['permissionhelp_admin_forum'] = 'Perijinan ini membolehkan pengguna untuk:<ul class="normallist"><li>mengubah forum, database dan setelan tema</li><li>mengatur paket</li><li>menggunakan piranti forum dan pemeliharaan database</li><li>melihat kesalahan dan log moderasi</li></ul> Gunakan perijinan ini dengan hati-hati, karena sangat vital.';
$txt['permissionname_manage_boards'] = 'Mengatur board dan kategori';
$txt['permissionhelp_manage_boards'] = 'Perijinan ini membolehkan pembuatan, pengeditan, dan penghapusan board dan kategori.';
$txt['permissionname_manage_attachments'] = 'Mengatur lampiran dan avatar';
$txt['permissionhelp_manage_attachments'] = 'Perijinan ini membolehkan akses ke pusat lampiran, di mana semua lampiran forum dan avatar didaftarkan dan dapat dihapus.';
$txt['permissionname_manage_smileys'] = 'Mengatur smiley dan ikon pesan';
$txt['permissionhelp_manage_smileys'] = 'Ini membolehkan akses ke pusat smiley. Dalam pusat smiley Anda bisa menambah, mengedit, dan menghapus smiley dan set smiley. Jika Anda sudah menghidupkan ikon pesan dikustomisasi, Anda juga bisa menambah dan mengedit ikon pesan dengan perijinan ini.';
$txt['permissionname_edit_news'] = 'Edit berita';
$txt['permissionhelp_edit_news'] = 'The news function allows a random news line to appear on each screen. In order to use the news function, enable it in the forum settings.';
$txt['permissionname_access_mod_center'] = 'Akses pusat moderasi';
$txt['permissionhelp_access_mod_center'] = 'Dengan perijinan ini setiap anggota dari grup ini dapat mengakses pusat moderasi dari mana mereka mempunyai akses ke fungsionalitas guna memudahkan moderasi. Cattan bahwa ini tidak menjadikan dirinya diberi setiap hak moderasi.';

$txt['permissiongroup_member_admin'] = 'Administrasi anggota';
$txt['permissionname_moderate_forum'] = 'Moderasi anggota forum';
$txt['permissionhelp_moderate_forum'] = 'Perijinan ini termasuk semua fungsi moderasi penting:<ul class="normallist"><li>mengakses ke manajeman registrasi</li><li>akses ke layar lihat/hapus anggota</li><li>info profil ekstensif, termasuk jejak IP/pengguna dan status online (sembunyi)</li><li>mengaktifkan akun</li><li>memperoleh persetujuan pemberitahuan dan persetujuan akun</li><li>kebal untuk mengabaikan PM</li><li>beberapa hal kecil lainnya</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Mengatur dan menempatkan grup anggota';
$txt['permissionhelp_manage_membergroups'] = 'Perijinan ini membolehkan pengguna untuk mengedit grup anggota dan menempatkan grup anggota ke anggota lain.';
$txt['permissionname_manage_permissions'] = 'Mengatur perijinan';
$txt['permissionhelp_manage_permissions'] = 'Perijinan ini membolehkan pengguna untuk mengedit semua perijinan grup anggota, secara global atau untuk board individual.';
$txt['permissionname_manage_bans'] = 'Mengatur daftar pengucilan';
$txt['permissionhelp_manage_bans'] = 'This permission allows a user to add or remove user names, IP addresses, hostnames and email addresses to or from a list of banned users. It also allows a user to view and remove log entries of banned users that attempted to login.';
$txt['permissionname_send_mail'] = 'Broadcast to multiple members';
$txt['permissionhelp_send_mail'] = 'Mass mail all forum members or just a few member groups by email or personal message (the latter requires the \'Send Personal Message\' permission).';
$txt['permissionname_issue_warning'] = 'Terbitkan peringatan kepada anggota';
$txt['permissionhelp_issue_warning'] = 'Menerbitkan peringatan untuk anggota forum dan mengubah tingkat peringatan anggota. Memerlukan sistem peringatan untuk dihidupkan.';

$txt['permissiongroup_profile'] = 'Profil Anggota';
$txt['permissionname_profile_view'] = 'Lihat ringkasan dan statistik profil';
$txt['permissionhelp_profile_view'] = 'This permission allows users clicking on a user name to see a summary of profile settings, some statistics and all posts of the user.';
$txt['permissionname_profile_view_own'] = 'Profil sendiri';
$txt['permissionname_profile_view_any'] = 'Setiap profil';
$txt['permissionname_profile_identity'] = 'Edit setelan akun';
$txt['permissionhelp_profile_identity'] = 'Account settings are the basic settings of a profile, like password, email address, member group and preferred language.';
$txt['permissionname_profile_identity_own'] = 'Profil sendiri';
$txt['permissionname_profile_identity_any'] = 'Setiap profil';
$txt['permissionname_profile_extra'] = 'Edit setelan profil tambahan';
$txt['permissionhelp_profile_extra'] = 'Setelan profil tambahan termasuk setelan avatar, preferensi tema, pemberitahuan dan Pesan Pribadi.';
$txt['permissionname_profile_extra_own'] = 'Profil sendiri';
$txt['permissionname_profile_extra_any'] = 'Setiap profil';
$txt['permissionname_profile_title'] = 'Edit judul kustom';
$txt['permissionhelp_profile_title'] = 'Judul kustom ditampilkan pada halaman tampilan topik, di bawah profil setiap pengguna yang memiliki judul kustom.';
$txt['permissionname_profile_title_own'] = 'Profil sendiri';
$txt['permissionname_profile_title_any'] = 'Setiap profil';
$txt['permissionname_profile_remove'] = 'Hapus akun';
$txt['permissionhelp_profile_remove'] = 'Perijinan ini membolehkan pengguna untuk menghapus akunnya, ketika disetel ke \'Akun Sendiri\'.';
$txt['permissionname_profile_remove_own'] = 'Akun sendiri';
$txt['permissionname_profile_remove_any'] = 'Setiap akun';
$txt['permissionname_profile_set_avatar'] = 'Select an avatar';
$txt['permissionhelp_profile_set_avatar'] = 'If enabled this will allow a user to select an avatar.';

$txt['permissiongroup_general_board'] = 'Umum';
$txt['permissionname_moderate_board'] = 'Moderasi board';
$txt['permissionhelp_moderate_board'] = 'Perijinan memoderasi board menambahkan beberapa perijinan kecil yang membuat moderator menjadi benar-benar moderator. Perijinan termasuk menjawab ke topik yang dikunci, mengubah polling yang waktunya berakhir dan melihat hasil polling.';

$txt['permissiongroup_topic'] = 'Topik';
$txt['permissionname_post_new'] = 'Tulis topik baru';
$txt['permissionhelp_post_new'] = 'Perijinan ini membolehkan pengguna untuk menulis topik baru. Ia tidak membolehkan untuk menulis jawaban ke topik.';
$txt['permissionname_merge_any'] = 'Gabung setiap topik';
$txt['permissionhelp_merge_any'] = 'Merge two or more topics into one. The order of messages within the merged topic will be based on the time the messages were created. A user can only merge topics on those boards a user is allowed to merge. In order to merge multiple topics at once, a user has to enable quick moderation in their profile settings.';
$txt['permissionname_split_any'] = 'Pisahkan setiap topik';
$txt['permissionhelp_split_any'] = 'Pisahkan topik menjadi dua topik terpisah.';
$txt['permissionname_send_topic'] = 'Kirim topik ke teman';
$txt['permissionhelp_send_topic'] = 'Perijinan ini membolehkan pengguna untuk mengirim email topik ke temannya dengan memasukan alamat email dan diijinkan untuk menambahkan pesan.';
$txt['permissionname_make_sticky'] = 'Pin topics';
$txt['permissionhelp_make_sticky'] = 'Pinned topics are topics that always remain on top of a board. They can be useful for announcements or other important messages.';
$txt['permissionname_move'] = 'Move topics';
$txt['permissionhelp_move'] = 'Pindahkan topik dari satu board ke yang lainnya. Pengguna hanya bisa memilih target board di mana mereka diijinkan untuk mengakses.';
$txt['permissionname_move_own'] = 'Topik sendiri';
$txt['permissionname_move_any'] = 'Setiap topik';
$txt['permissionname_lock'] = 'Kunci topik';
$txt['permissionhelp_lock'] = 'This permission allows a user to lock a topic. This can be done in order to make sure no one can reply to a topic. Only users with a \'Moderate board\' permission can still post in locked topics.';
$txt['permissionname_lock_own'] = 'Topik sendiri';
$txt['permissionname_lock_any'] = 'Setiap topik';
$txt['permissionname_remove'] = 'Hapus topik';
$txt['permissionhelp_remove'] = 'Hapus topik secara keseluruhan. Catatan bahwa perijinan ini tidak membolehkan untuk menghapus pesan tertentu di dalam topik!';
$txt['permissionname_remove_own'] = 'Topik sendiri';
$txt['permissionname_remove_any'] = 'Setiap topik';
$txt['permissionname_post_reply'] = 'Tulis jawaban ke topik';
$txt['permissionhelp_post_reply'] = 'Perijinan ini membolehkan menjawab ke topik.';
$txt['permissionname_post_reply_own'] = 'Topik sendiri';
$txt['permissionname_post_reply_any'] = 'Setiap topik';
$txt['permissionname_modify_replies'] = 'Ubah jawaban ke topik sendiri';
$txt['permissionhelp_modify_replies'] = 'Perijinan ini membolehkan pengguna yang memulai topik untuk mengubah semua jawaban ke topiknya.';
$txt['permissionname_delete_replies'] = 'Hapus jawaban ke topik sendiri';
$txt['permissionhelp_delete_replies'] = 'Perijinan ini membolehkan pengguna yang memulai topik menghapus semua jawaban ke topik.';
$txt['permissionname_announce_topic'] = 'Umumkan topik';
$txt['permissionhelp_announce_topic'] = 'This allows a user to send an announcement email about a topic to all members or to a few member groups.';

$txt['permissionname_approve_emails'] = 'Moderate Post by Email Failures';
$txt['permissionhelp_approve_emails'] = 'Allow moderators to access the Post by Email failure log to perform actions including approve, delete, view and bounce.  Note, since the system may not always know what board a post goes to, this permission should be only be given to members with full board access';
$txt['permissionname_postby_email'] = 'Post by Email';
$txt['permissionhelp_postby_email'] = 'This permission allows users to start new topics as well as reply to topic and PM notifications by email.';

$txt['permissiongroup_post'] = 'Tulisan';
$txt['permissionname_delete'] = 'Hapus tulisan';
$txt['permissionhelp_delete'] = 'Hapus tulisan. Ini tidak mengijinkan pengguna untuk menghapus tulisan pertama pada topik.';
$txt['permissionname_delete_own'] = 'Tulisan sendiri';
$txt['permissionname_delete_any'] = 'Setiap tulisan';
$txt['permissionname_modify'] = 'Ubah tulisan';
$txt['permissionhelp_modify'] = 'Edit tulisan';
$txt['permissionname_modify_own'] = 'Tulisan sendiri';
$txt['permissionname_modify_any'] = 'Setiap tulisan';
$txt['permissionname_report_any'] = 'Laporkan tulisan ke moderator';
$txt['permissionhelp_report_any'] = 'Perijinan ini menambah link ke setiap pesan, mengijinkan pengguna untuk melaporkan tulisan ke moderator. Saat pelaporan, semua moderator pada board itu akan menerima email dengan link ke tulisan yang dilaporkan dan deskripsi masalah (diberikan oleh pengguna pelapor).';

$txt['permissiongroup_poll'] = 'Polling';
$txt['permissionname_poll_view'] = 'Lihat polling';
$txt['permissionhelp_poll_view'] = 'Perijinan ini membolehkan pengguna untuk melihat polling. Tanpa perijinan ini, pengguna hanya melihat topik.';
$txt['permissionname_poll_vote'] = 'Pilih dalam polling';
$txt['permissionhelp_poll_vote'] = 'Perijinan ini membolehkan pengguna (terdaftar) untuk memberikan satu suara. Ini tidak berlaku bagi pengunjung.';
$txt['permissionname_poll_post'] = 'Tulis polling';
$txt['permissionhelp_poll_post'] = 'Perijinan ini mengijinkan pengguna untuk menulis polling baru. Pengguna harus memiliki perijinan \'Tulis topik baru\'.';
$txt['permissionname_poll_add'] = 'Tambah polling ke topik';
$txt['permissionhelp_poll_add'] = 'Tambah polling ke topik membolehkan pengguna untuk menambah polling setelah topik sudah dibuat. Perijinan ini memerlukan hak yang cukup untuk mengedit tulisan pertama pada topik.';
$txt['permissionname_poll_add_own'] = 'Topik sendiri';
$txt['permissionname_poll_add_any'] = 'Setiap topik';
$txt['permissionname_poll_edit'] = 'Edit polling';
$txt['permissionhelp_poll_edit'] = 'Perijinan ini membolehkan pengguna untuk mengedit opsi polling dan mereset polling. Agar bisa mengedit jumlah pilihan maksimum dan waktu berakhirnya, pengguna perlu mempunyai perijinan \'Moderasi board\'.';
$txt['permissionname_poll_edit_own'] = 'Polling sendiri';
$txt['permissionname_poll_edit_any'] = 'Setiap polling';
$txt['permissionname_poll_lock'] = 'Kunci polling';
$txt['permissionhelp_poll_lock'] = 'Mengunci polling menghindari polling atas penerimaan suara baru.';
$txt['permissionname_poll_lock_own'] = 'Polling sendiri';
$txt['permissionname_poll_lock_any'] = 'Setiap polling';
$txt['permissionname_poll_remove'] = 'Hapus polling';
$txt['permissionhelp_poll_remove'] = 'Perijinan ini membolehkan penghapusan polling.';
$txt['permissionname_poll_remove_own'] = 'Polling sendiri';
$txt['permissionname_poll_remove_any'] = 'Setiap polling';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Save drafts of new posts';
$txt['permissionname_simple_post_draft'] = 'Save drafts of new posts';
$txt['permissionhelp_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionhelp_simple_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionname_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionname_simple_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionhelp_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionname_simple_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionhelp_pm_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid losing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionname_simple_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionhelp_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';
$txt['permissionhelp_simple_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';

$txt['permissiongroup_approval'] = 'Moderasi Tulisan';
$txt['permissionname_approve_posts'] = 'Setujui item yang menunggu moderasi';
$txt['permissionhelp_approve_posts'] = 'Perijinan ini membolehkan pengguna untuk menyetujui semua item yang belum disetujui pada sebuah board.';
$txt['permissionname_post_unapproved_replies'] = 'Tulis jawaban yang belum disetujui';
$txt['permissionhelp_post_unapproved_replies'] = 'Perijinan ini membolehkan pengguna untuk menuliskan jawaban ke topik yang tidak akan ditampilkan sampai disetujui oleh moderator.';
$txt['permissionname_post_unapproved_replies_own'] = 'Topik sendiri';
$txt['permissionname_post_unapproved_replies_any'] = 'Setiap topik';
$txt['permissionname_post_unapproved_topics'] = 'Tulis topik yang belum disetujui';
$txt['permissionhelp_post_unapproved_topics'] = 'Perijinan ini membolehkan pengguna untuk menuliskan topik baru yang memerlukan persetujuan sebelum ditampilkan.';
$txt['permissionname_post_unapproved_attachments'] = 'Tuli lampiran yang belum disetujui';
$txt['permissionhelp_post_unapproved_attachments'] = 'Perijinan ini membolehkan pengguna untuk melampirkan file ke tulisannya. Lampiran akan memerlukan persetujuan sebelum ditampilkan ke pengguna lain.';

$txt['permissiongroup_notification'] = 'Pemberitahuan';
$txt['permissionname_mark_any_notify'] = 'Minta pemberitahuan pada jawaban';
$txt['permissionhelp_mark_any_notify'] = 'Fitur ini mengijinkan Anda untuk menerima pemberitahuan kapan saja seseorang menjawab pada topik di mana mereka berlangganan.';
$txt['permissionname_mark_notify'] = 'Minta pemberitahuan pada topik baru';
$txt['permissionhelp_mark_notify'] = 'Pemberitahuan pada topik baru adalah fitur yang mengijinkan pengguna untuk menerima email setiap kali topik baru dibuat pada board di mana mereka berlangganan.';

$txt['permissiongroup_attachment'] = 'Lampiran';
$txt['permissionname_view_attachments'] = 'Lihat lampiran';
$txt['permissionhelp_view_attachments'] = 'Lampiran adalah file yang dilampirkan ke pesan yang ditulis. Fitur ini dapat dihidupkan dan dikonfigurasi dalam \'Lampiran dan Avatar\'. Karena lampiran tidak diakses secara langsung, Anda dapat melindunginya di-download oleh pengguna yang tidak memiliki ijin.';
$txt['permissionname_post_attachment'] = 'Tulis lampiran';
$txt['permissionhelp_post_attachment'] = 'Lampiran adalah file yang dilampirkan ke pesan yang ditulis. Satu pesan dapat berisi multipel lampiran.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Setelan Perijinan';
$txt['groups_manage_permissions'] = 'Member groups allowed to manage permissions';
$txt['permission_enable_deny'] = 'Hidupkan opsi untuk menolak perijinan';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Mematikan opsi ini akan memutakhirkan perijinan-\\\'Tolak\\\' ke \\\'Larang\\\'.';
$txt['permission_by_board_desc'] = 'Here you can set which permission profile a board uses. You can create new permission profiles from the &quot;Edit Profiles&quot; menu.';
$txt['permission_settings_desc'] = 'Di sini Anda dapat menyetel siapa yang memiliki perijinan untuk mengubah perijinan, juga seberapa memuaskan sistem perijinan seharusnya.';
$txt['permission_enable_postgroups'] = 'Hidupkan perijinan untuk grup berbasis jumlah tulisan';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Mematikan setelan ini akan menghapus perijinan yang saat ini disetel ke grup berbasis jumlah tulisan.';

$txt['permissions_post_moderation_desc'] = 'From this page you can easily change which groups have their posts moderated for a particular permission profile.';
$txt['permissions_post_moderation_deny_note'] = 'Catatan bahwa ketika Anda menghidupkan perijinan lanjutan, Anda tidak dapat menerapkan perijinan &quot;deny&quot; dari halaman ini. Silahkan edit perijinan secara langsung jika Anda ingin menerapkan perijinan tolak.';
$txt['permissions_post_moderation_select'] = 'Pilih Profil';
$txt['permissions_post_moderation_new_topics'] = 'Topik Baru';
$txt['permissions_post_moderation_replies_own'] = 'Jawaban Sendiri';
$txt['permissions_post_moderation_replies_any'] = 'Setiap Jawaban';
$txt['permissions_post_moderation_attachments'] = 'Lampiran';
$txt['permissions_post_moderation_legend'] = 'Legenda';
$txt['permissions_post_moderation_allow'] = 'Dapat membuat';
$txt['permissions_post_moderation_moderate'] = 'Dapat membuat tapi memerlukan persetujuan';
$txt['permissions_post_moderation_disallow'] = 'Tidak bisa membuat';
$txt['permissions_post_moderation_group'] = 'Grup';

$txt['auto_approve_topics'] = 'Post new topics without requiring approval';
$txt['auto_approve_replies'] = 'Post replies to topics without requiring approval';
$txt['auto_approve_attachments'] = 'Post attachments without requiring approval';
