<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Indeks Pesan Pribadi';
$txt['pm_add'] = 'Tambah';
$txt['make_bcc'] = 'Tambah BCC';
$txt['pm_to'] = 'Untuk';
$txt['pm_bcc'] = 'Bcc';
$txt['inbox'] = 'Kotak masuk';
$txt['conversation'] = 'Percakapan';
$txt['messages'] = 'Pesan';
$txt['sent_items'] = 'Item Terkirim';
$txt['new_message'] = 'Pesan Baru';
$txt['delete_message'] = 'Hapus Pesan';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Hapus semua pesan dalam PMBOX Anda';
$txt['delete_all_confirm'] = 'Anda yakin ingin menghapus semua pesan?';

$txt['delete_selected_confirm'] = 'Anda yakin ingin menghapus semua pesan pribadi yang dipilih?';

$txt['sent_to'] = 'Kirim ke';
$txt['reply_to_all'] = 'Jawab ke Semua';
$txt['delete_conversation'] = 'Hapus Percakapan';

$txt['pm_capacity'] = 'Kapasitas';
$txt['pm_currently_using'] = '%1$s pesan, %2$s%% penuh.';
$txt['pm_sent'] = 'Pesan anda sudah dikirimkan';

$txt['pm_error_user_not_found'] = 'Tidak bisa menemukan anggota \'%1$s\'.';
$txt['pm_error_ignored_by_user'] = 'Pengguna \'%1$s\' telah memblok pesan pribadi Anda.';
$txt['pm_error_data_limit_reached'] = 'PM could not be sent to \'%1$s\' as their inbox is full.';
$txt['pm_error_user_cannot_read'] = 'Pengguna \'%1$s\' tidak bisa menerima pesan pribadi.';
$txt['pm_successfully_sent'] = 'PM sudah dikirim dengan sukses ke \'%1$s\'.';
$txt['pm_send_report'] = 'Kirim laporan';
$txt['pm_undisclosed_recipients'] = 'Ungkap penerima';
$txt['pm_too_many_recipients'] = 'Anda tidak boleh mengirimkan pesan ke lebih dari %1$d penerima sekaligus.';

$txt['pm_read'] = 'Dibaca';
$txt['pm_replied'] = 'Jawab Ke';
$txt['pm_mark_unread'] = 'Mark as Unread';

// Message Pruning.
$txt['pm_prune'] = 'Prune messages';
$txt['pm_prune_desc'] = 'Delete all personal messages older than %1$s days.';
$txt['pm_prune_warning'] = 'Anda yakin ingin menghapus pesan pribadi Anda?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Further actions';
$txt['pm_actions_delete_selected'] = 'Hapus yang dipilih';
$txt['pm_actions_filter_by_label'] = 'Filter by label';
$txt['pm_actions_go'] = 'Ayo';

// Manage Labels Screen.
$txt['pm_apply'] = 'Terapkan';
$txt['pm_manage_labels'] = 'Manage labels';
$txt['pm_labels_delete'] = 'Anda yakin ingin menghapus label yang dipilih?';
$txt['pm_labels_desc'] = 'Dari sini Anda dapat menambah, mengedit dan menghapus label yang dipakai dalam pusat pesan pribadi Anda.';
$txt['pm_label_add_new'] = 'Add new label';
$txt['pm_label_name'] = 'Label name';
$txt['pm_labels_no_exist'] = 'Saat ini Anda tidak menyiapkan label!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Label';
$txt['pm_msg_label_title'] = 'Label message';
$txt['pm_msg_label_apply'] = 'Add label';
$txt['pm_msg_label_remove'] = 'Remove label';
$txt['pm_msg_label_inbox'] = 'Kotak masuk';
$txt['pm_sel_label_title'] = 'Label selected';

// Sidebar Headings.
$txt['pm_labels'] = 'Label';
$txt['pm_messages'] = 'Pesan';
$txt['pm_actions'] = 'Aksi';
$txt['pm_preferences'] = 'Preferensi';

$txt['pm_is_replied_to'] = 'Anda telah meneruskan atau merespon ke pesan ini.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Report to admin';
$txt['pm_report_title'] = 'Report personal message';
$txt['pm_report_desc'] = 'Dari halaman ini Anda dapat melaporkan pesan pribadi yang Anda terima ke tim admin forum. Pastikan untuk menyertakan penjelasan mengapa Anda melaporkan pesan ini, karena ini akan dikirimkan bersama dengan isi dari pesan aslinya.';
$txt['pm_report_admins'] = 'Laporan dikirimkan ke Administrator';
$txt['pm_report_all_admins'] = 'Kirim ke semua administrator forum';
$txt['pm_report_reason'] = 'Alasan mengapa Anda melaporkan pesan ini';
$txt['pm_report_message'] = 'Laporkan Pesan';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[REPORT] ';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} telah melaporkan pesan pribadi di bawah ini, dikirimkan oleh {SENDER}, untuk alasan berikut:';
$txt['pm_report_pm_other_recipients'] = 'Penerima lain dari pesan ini termasuk:';
$txt['pm_report_pm_hidden'] = '%1$d penerima tersembunyi';
$txt['pm_report_pm_unedited_below'] = 'Di bawah ini adalah konten asli pesan pribadi yang dilaporkan:';
$txt['pm_report_pm_sent'] = 'Dikirimkan:';

$txt['pm_report_done'] = 'Terima kasih telah mengirimkan laporan ini. Anda akan mendengar kembali dari tim admin dalam waktu tidak lama';
$txt['pm_report_return'] = 'Kembali ke kotak masuk';

$txt['pm_search_title'] = 'Search personal messages';
$txt['pm_search_bar_title'] = 'Search messages';
$txt['pm_search_text'] = 'Mencari';
$txt['pm_search_go'] = 'Pencarian';
$txt['pm_search_advanced'] = 'Show advanced options';
$txt['pm_search_simple'] = 'Hide advanced options';
$txt['pm_search_user'] = 'Oleh pengguna';
$txt['pm_search_match_all'] = 'Sama seluruh kata';
$txt['pm_search_match_any'] = 'Sama setiap kata';
$txt['pm_search_options'] = 'Opsi';
$txt['pm_search_post_age'] = 'Usia pesan';
$txt['pm_search_show_complete'] = 'Tampilkan pesan lengkap dalam hasil.';
$txt['pm_search_subject_only'] = 'Cari hanya dengan subyek dan pembuat.';
$txt['pm_search_sent_only'] = 'Search only in sent items.';
$txt['pm_search_between'] = 'antara';
$txt['pm_search_between_and'] = 'dan';
$txt['pm_search_between_days'] = 'hari';
$txt['pm_search_order'] = 'Urutan pencarian';
$txt['pm_search_choose_label'] = 'Pilih label untuk dicari, atau cari semua';

$txt['pm_search_results'] = 'Search results';
$txt['pm_search_none_found'] = 'No messages found';

$txt['pm_search_orderby_relevant_first'] = 'Paling relevan pertama';
$txt['pm_search_orderby_recent_first'] = 'Paling baru pertama';
$txt['pm_search_orderby_old_first'] = 'Terlama pertama';

$txt['pm_visual_verification_label'] = 'Verifikasi';
$txt['pm_visual_verification_desc'] = 'Please enter the code in the image above in order to send this PM.';

$txt['pm_settings'] = 'Change settings';
$txt['pm_change_view'] = 'Change view';

$txt['pm_manage_rules'] = 'Manage rules';
$txt['pm_manage_rules_desc'] = 'Aturan pesan mengijinkan Anda untuk mengurut secara otomatis pesan yang datang berdiri sendiri sesuai set kriteria yang Anda tetapkan. Di bawah ini adalah semua aturan yang saat ini Anda siapkan. Untuk mengedit aturan cukup klik nama aturan.';
$txt['pm_rules_none'] = 'Anda belum menyiapkan aturan pesan apapun.';
$txt['pm_rule_title'] = 'Aturan';
$txt['pm_add_rule'] = 'Add new rule';
$txt['pm_apply_rules'] = 'Apply rules now';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Anda yakin ingin menerapkan aturan saat ini untuk semua pesan pribadi?';
$txt['pm_edit_rule'] = 'Edit rule';
$txt['pm_rule_save'] = 'Save rule';
$txt['pm_delete_selected_rule'] = 'Delete selected rules';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Anda yakin ingin menghapus aturan yang dipilih?';
$txt['pm_rule_name'] = 'Nama';
$txt['pm_rule_name_desc'] = 'Nama untuk mengingat aturan ini';
$txt['pm_rule_name_default'] = '[NAME]';
$txt['pm_rule_description'] = 'Deskripsi';
$txt['pm_rule_not_defined'] = 'Tambah beberapa kriteria untuk mulai membangun deskripsi aturan ini.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>Catatan:</strong> Nampaknya Anda telah mematikan javascript. Kami sangat merekomendasikan agar Anda menghidupkan javascript untuk menggunakan fitur ini.</span>';
$txt['pm_rule_criteria'] = 'Kriteria';
$txt['pm_rule_criteria_add'] = 'Add criteria';
$txt['pm_rule_criteria_pick'] = 'Choose criteria';
$txt['pm_rule_mid'] = 'Sender name';
$txt['pm_rule_gid'] = 'Sender\'s group';
$txt['pm_rule_sub'] = 'Message subject contains';
$txt['pm_rule_msg'] = 'Message body contains';
$txt['pm_rule_bud'] = 'Sender is buddy';
$txt['pm_rule_sel_group'] = 'Select group';
$txt['pm_rule_logic'] = 'When checking criteria';
$txt['pm_rule_logic_and'] = 'Semua kriteria harus sesuai';
$txt['pm_rule_logic_or'] = 'Setiap kriteria dapat disesuaikan';
$txt['pm_rule_actions'] = 'Aksi';
$txt['pm_rule_sel_action'] = 'Select an action';
$txt['pm_rule_add_action'] = 'Add action';
$txt['pm_rule_label'] = 'Beri label pesan dengan';
$txt['pm_rule_sel_label'] = 'Select label';
$txt['pm_rule_delete'] = 'Delete message';
$txt['pm_rule_no_name'] = 'Anda lupa memasukkan nama untuk aturan.';
$txt['pm_rule_no_criteria'] = 'Aturan harus mempunyai setidaknya satu kriteria dan satu set aksi.';
$txt['pm_rule_too_complex'] = 'The rule you are creating is too long to save. Try breaking it up into smaller rules.';

$txt['pm_readable_and'] = '<em>dan</em>';
$txt['pm_readable_or'] = '<em>atau</em>';
$txt['pm_readable_start'] = 'Jika ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'pesan dari &quot;{MEMBER}&quot;';
$txt['pm_readable_group'] = 'pengirim dari grup &quot;{GROUP}&quot;';
$txt['pm_readable_subject'] = 'subyek pesan berisi &quot;{SUBJECT}&quot;';
$txt['pm_readable_body'] = 'badan pesan berisi &quot;{BODY}&quot;';
$txt['pm_readable_buddy'] = 'pengirim adalah teman';
$txt['pm_readable_label'] = 'terapkan label &quot;{LABEL}&quot;';
$txt['pm_readable_delete'] = 'hapus pesan';
$txt['pm_readable_then'] = '<strong>kemudian</strong>';