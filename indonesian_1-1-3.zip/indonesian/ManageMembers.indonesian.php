<?php
// Version: 1.1; ManageMembers

$txt['groups'] = 'Grup';
$txt['viewing_groups'] = 'Melihat Grup anggota';

$txt['membergroups_title'] = 'Melihat Grup anggota';
$txt['membergroups_description'] = 'Grup anggota adalah grup dari anggota yang memiliki setelan perijinan, tampilan, atau hak akses yang mirip. Beberapa grup anggota didasarkan pada jumlah tulisan yang telah dibuat pengguna. Anda dapat menempatkan seseorang ke grup anggota dengan memilih profilnya dan mengubah setelan akunnya.';
$txt['membergroups_modify'] = 'Ubah';
$txt['membergroups_modify_parent'] = 'Modify parent group';

$txt['membergroups_add_group'] = 'Tambah grup';
$txt['membergroups_regular'] = 'Grup reguler';
$txt['membergroups_post'] = 'Grup berbasis jumlah tulisan';
$txt['membergroups_guests_na'] = 'tidak ada';

$txt['membergroups_group_name'] = 'Nama grup anggota';
$txt['membergroups_new_board'] = 'Board Terlihat';
$txt['membergroups_new_board_desc'] = 'Board yang dapat dilihat grup anggota';
$txt['membergroups_new_board_post_groups'] = '<em>Catatan: biasanya, grup tulisan tidak memerlukan akses karena grup dengan anggota tersebut akan memberikan aksesnya.</em>';
$txt['membergroups_new_as_inherit'] = 'turunkan dari';
$txt['membergroups_new_as_type'] = 'dengan tipe';
$txt['membergroups_new_as_copy'] = 'berdasarkan';
$txt['membergroups_new_copy_none'] = '(tidak ada)';
$txt['membergroups_can_edit_later'] = 'Anda dapat mengeditnya nanti.';

$txt['membergroups_edit_group'] = 'Edit Grup anggota';
$txt['membergroups_edit_name'] = 'Nama grup';
$txt['membergroups_edit_inherit_permissions'] = 'Perijinan Turunan';
$txt['membergroups_edit_inherit_permissions_desc'] = 'Pilih &quot;Tidak&quot; untuk agar grup memiliki set perijinan sendiri.';
$txt['membergroups_edit_inherit_permissions_no'] = 'Tidak - Gunakan Perijinan Unik';
$txt['membergroups_edit_inherit_permissions_from'] = 'Turunan Dari';
$txt['membergroups_edit_hidden'] = 'Visibilitas';
$txt['membergroups_edit_hidden_no'] = 'Terlihat';
$txt['membergroups_edit_hidden_boardindex'] = 'Visible - Apart from in group key';
$txt['membergroups_edit_hidden_all'] = 'Tidak Terlihat';
// Do not use numeric entities in the below string.
$txt['membergroups_edit_hidden_warning'] = 'Anda yakin tidak ingin menempatkan grup ini sebagai grup utama pengguna?\\n\\nMelakukan ini hanya akan membatasi penempatan grup tambahan, dan akan memutakhirkan semua anggota &quot;utama&quot; untuk dimiliki hanya sebagai grup tambahan.';
$txt['membergroups_edit_desc'] = 'Deskripsi grup';
$txt['membergroups_edit_group_type'] = 'Group type';
$txt['membergroups_edit_select_group_type'] = 'Select Group type';
$txt['membergroups_group_type_private'] = 'Pribadi <span class="smalltext">(Keanggotaan harus ditempatkan)</span>';
$txt['membergroups_group_type_protected'] = 'Terproteksi <span class="smalltext">(Hanya administrator yang dapat mengelola dan menetapkan)</span> ';
$txt['membergroups_group_type_request'] = 'Dapat diminta <span class="smalltext">(Pengguna dapat meminta keanggotaan)</span>';
$txt['membergroups_group_type_free'] = 'Bebas <span class="smalltext">(Pengguna dapat meninggalkan dan bergabung sesukanya)</span>';
$txt['membergroups_group_type_post'] = 'Berbasis Tulisan <span class="smalltext">(Keanggotaan didasarkan pada jumlah tulisan)</span>';
$txt['membergroups_min_posts'] = 'Tulisan diperlukan';
$txt['membergroups_online_color'] = 'Warna dalam daftar online';
$txt['membergroups_icon_count'] = 'Number of icon images';
$txt['membergroups_icon_image'] = 'Icon image filename';
$txt['membergroups_icon_image_note'] = 'Upload icon images in to the default theme directory to enable selection.<br />Select the icon to change it.';
$txt['membergroups_max_messages'] = 'Pesan pribadi Maksimum';
$txt['membergroups_max_messages_note'] = '0 = tidak terbatas';
$txt['membergroups_max_messages_desc'] = 'Here you can set the limit of personal messages a user can keep on the server.<br />
To allow store an unlimited number of personal messages, you can set the value to 0';
$txt['membergroups_edit_save'] = 'Simpan';
$txt['membergroups_delete'] = 'Hapus';
$txt['membergroups_confirm_delete'] = 'Are you sure you want to delete this group?';

$txt['membergroups_members_title'] = 'Melihat grup';
$txt['membergroups_members_group_members'] = 'Anggota Grup';
$txt['membergroups_members_no_members'] = 'Grup saat ini kosong';
$txt['membergroups_members_add_title'] = 'Tambah anggota ke grup ini';
$txt['membergroups_members_add_desc'] = 'Daftar Anggota untuk Ditambahkan';
$txt['membergroups_members_add'] = 'Tambah Anggota';
$txt['membergroups_members_remove'] = 'Hapus dari Grup';
$txt['membergroups_members_last_active'] = 'Terakhir Aktif';
$txt['membergroups_members_additional_only'] = 'Tambah hanya sebagai grup tambahan.';
$txt['membergroups_members_group_moderators'] = 'Moderator Grup';
$txt['membergroups_members_description'] = 'Deskripsi';
// Use javascript escaping in the below.
$txt['membergroups_members_deadmin_confirm'] = 'Anda yakin ingin menghapus diri Anda sendiri dari grup Administrasi?';

$txt['membergroups_postgroups'] = 'Grup tulisan';
$txt['membergroups_settings'] = 'Setelan Grup anggota';
$txt['groups_manage_membergroups'] = 'Grup diijinkan untuk mengubah grup anggota';
$txt['membergroups_select_permission_type'] = 'Pilih profil perijinan';
$txt['membergroups_images_url'] = '{theme URL}/images/group_icons/';
$txt['membergroups_select_visible_boards'] = 'Tampilkan board';
$txt['membergroups_members_top'] = 'Anggota';
$txt['membergroups_name'] = 'Nama';
$txt['membergroups_icons'] = 'Icons';

$txt['admin_browse_approve'] = 'Anggota yang akunnya menunggu persetujuan';
$txt['admin_browse_approve_desc'] = 'Dari sini Anda dapat mengatur semua anggota yang menunggu akunnya untuk disetujui.';
$txt['admin_browse_activate'] = 'Anggota yang akunnya menunggu aktivasi';
$txt['admin_browse_activate_desc'] = 'Layar ini menampilkan seluruh anggota yang belum mengaktifkan akunnya di forum Anda.';
$txt['admin_browse_awaiting_approval'] = 'Awaiting Approval [%1$d]';
$txt['admin_browse_awaiting_activate'] = 'Awaiting Activation [%1$d]';

$txt['admin_browse_username'] = 'Nama pengguna';
$txt['admin_browse_email'] = 'Alamat Email';
$txt['admin_browse_ip'] = 'Alamat IP';
$txt['admin_browse_registered'] = 'Terdaftar';
$txt['admin_browse_id'] = 'ID';
$txt['admin_browse_with_selected'] = 'Dengan yang Dipilih';
$txt['admin_browse_no_members_approval'] = 'Tidak ada anggota saat ini yang menunggu persetujuan.';
$txt['admin_browse_no_members_activate'] = 'Tidak ada anggota saat ini yang tidak mengaktifkan akunnya.';

// Don't use entities in the below strings, except the main ones. (lt, gt, quot.)
$txt['admin_browse_warn'] = 'semua anggota yang dipilih?';
$txt['admin_browse_outstanding_warn'] = 'semua anggota yang diambil?';
$txt['admin_browse_w_approve'] = 'Setuju';
$txt['admin_browse_w_activate'] = 'Aktifkan';
$txt['admin_browse_w_delete'] = 'Hapus';
$txt['admin_browse_w_reject'] = 'Reject (Delete)';
$txt['admin_browse_w_remind'] = 'Ingatkan';
$txt['admin_browse_w_approve_deletion'] = 'Setujui (Hapus Akun)';
$txt['admin_browse_w_email'] = 'dan kirim email';
$txt['admin_browse_w_approve_require_activate'] = 'Approve and require activation';

$txt['admin_browse_filter_by'] = 'Filter Dengan';
$txt['admin_browse_filter_show'] = 'Menampilkan';
$txt['admin_browse_filter_type_0'] = 'Unactivated new accounts';
$txt['admin_browse_filter_type_2'] = 'Unactivated email changes';
$txt['admin_browse_filter_type_3'] = 'Unapproved new accounts';
$txt['admin_browse_filter_type_4'] = 'Unapproved account deletions';
$txt['admin_browse_filter_type_5'] = 'Akun "Dibawah Umur" Tidak Disetujui';

$txt['admin_browse_outstanding'] = 'Anggota Tertunda';
$txt['admin_browse_outstanding_days_1'] = 'Dengan seluruh anggota yang terdaftar lebih lama dari';
$txt['admin_browse_outstanding_days_2'] = 'hari lalu';
$txt['admin_browse_outstanding_perform'] = 'Melakukan aksi berikut';
$txt['admin_browse_outstanding_go'] = 'Aksi Dilakukan';

$txt['check_for_duplicate'] = 'Check for duplicates';
$txt['dont_check_for_duplicate'] = 'Don\'t check for duplicates';
$txt['duplicates'] = 'Duplikasi';

$txt['not_activated'] = 'Tidak diaktifkan';