<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Pusat Moderasi';
$txt['mc_main'] = 'Utama';
$txt['mc_logs'] = 'Log';
$txt['mc_posts'] = 'Tulisan';
$txt['mc_groups'] = 'Members and groups';

$txt['mc_view_groups'] = 'Lihat Grup anggota';

$txt['mc_description'] = '<strong>Welcome, %1$s!</strong><br />This is your &quot;Moderation Center&quot;. From here you can perform all the moderation actions assigned to yourself by the Administrator. This home page contains a summary of all the latest happenings in your community. You can <a href="%2$s">personalize the layout by clicking here</a>.';
$txt['mc_group_requests'] = 'Permintaan Grup anggota';
$txt['mc_member_requests'] = 'Member Requests';
$txt['mc_unapproved_posts'] = 'Tulisan Tidak Disetujui';
$txt['mc_watched_users'] = 'Recently Watched Members';
$txt['mc_watched_topics'] = 'Topik Diawasi';
$txt['mc_scratch_board'] = 'Board Sketsa Moderator';
$txt['mc_latest_news'] = 'Latest News';
$txt['mc_recent_reports'] = 'Laporan Topik Terbaru';
$txt['mc_warnings'] = 'Peringatan';
$txt['mc_notes'] = 'Catatan Moderator';
$txt['mc_required'] = 'Items Requiring Approval';
$txt['mc_attachments'] = 'Attachments needing approval';
$txt['mc_emailmod'] = 'Email Postings needing approval';
$txt['mc_topics'] = 'Topics needing approval';
$txt['mc_posts'] = 'Tulisan';
$txt['mc_groupreq'] = 'Group requests needing approval';
$txt['mc_memberreq'] = 'Members needing approval';
$txt['mc_reports'] = 'Report posts needing approval';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['mc_recent_reports_none'] = 'Tidak ada laporan tertunda';
$txt['mc_watched_users_none'] = 'Tidak ada yang diawasi saat ini.';
$txt['mc_group_requests_none'] = 'Tidak ada permintaan untuk keanggotaan grup.';

$txt['mc_seen'] = '%1$s last seen %2$s';
$txt['mc_seen_never'] = '%1$s tidak pernah terlihat';
$txt['mc_groupr_by'] = 'oleh';

$txt['mc_reported_posts_desc'] = 'Di sini Anda bisa meninjau semua laporan tulisan yang dimunculkan oleh anggota komunitas.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Laporan Aktif';
$txt['mc_reportedp_closed'] = 'Laporan Lama';
$txt['mc_reportedp_by'] = 'oleh';
$txt['mc_reportedp_reported_by'] = 'Dilaporkan Oleh';
$txt['mc_reportedp_last_reported'] = 'Terakhir Dilaporkan';
$txt['mc_reportedp_none_found'] = 'Tidak ada Laporan Ditemukan';

$txt['mc_reportedp_details'] = 'Rincian';
$txt['mc_reportedp_close'] = 'Tutup';
$txt['mc_reportedp_open'] = 'Laporan Aktif';
$txt['mc_reportedp_ignore'] = 'Dismiss';
$txt['mc_reportedp_unignore'] = 'Reopen';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Are you sure you wish to dismiss and ignore further reports about this message?

This will turn off further reports for all moderators of the forum.';
$txt['mc_reportedp_close_selected'] = 'Tutup yang Dipilih';

$txt['mc_groupr_group'] = 'Grup anggota';
$txt['mc_groupr_member'] = 'Anggota';
$txt['mc_groupr_reason'] = 'Alasan';
$txt['mc_groupr_none_found'] = 'Tidak ada permintaan grup anggota yang tertunda untuk saat ini';
$txt['mc_groupr_submit'] = 'Kirim';
$txt['mc_groupr_reason_desc'] = 'Alasan untuk menolak permintaan %1$s bergabung dengan &quot;%2$s&quot;';
$txt['mc_groups_reason_title'] = 'Reasons for rejection';
$txt['with_selected'] = 'With selected';
$txt['mc_groupr_approve'] = 'Approve request';
$txt['mc_groupr_reject'] = 'Reject request (No Reason)';
$txt['mc_groupr_reject_w_reason'] = 'Reject request with reason';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Anda yakin ingin melakukan ini?';

$txt['mc_unapproved_attachments_none_found'] = 'Tidak ada lampiran yang tidak disetujui ditemukan!';
$txt['mc_unapproved_attachments_desc'] = 'From here you can approve or delete any attachments awaiting moderation.';
$txt['mc_unapproved_replies_none_found'] = 'Tidak ada tulisan yang tidak disetujui ditemukan!';
$txt['mc_unapproved_topics_none_found'] = 'Tidak ada topik yang tidak disetujui ditemukan!';
$txt['mc_unapproved_posts_desc'] = 'Dari sini Anda dapat menyetujui atau menghapus setiap tulisan yang menunggu moderasi.';
$txt['mc_unapproved_replies'] = 'Jawaban';
$txt['mc_unapproved_topics'] = 'Topik';
$txt['mc_unapproved_by'] = 'oleh';
$txt['mc_unapproved_sure'] = 'Anda yakin ingin melakukan ini?';
$txt['mc_unapproved_attach_name'] = 'Attachment name';
$txt['mc_unapproved_attach_size'] = 'File size';
$txt['mc_unapproved_attach_poster'] = 'Penulis';
$txt['mc_viewmodreport'] = 'Moderation report for %1$s by %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Anggota yang melaporkan tulisan ini';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Aksi diambil oleh moderator lain';
$txt['mc_modreport_mod_comments'] = 'Komentar Moderator';
$txt['mc_modreport_no_mod_comment'] = 'Saat ini tidak ada komentar moderator';
$txt['mc_modreport_add_mod_comment'] = 'Tambah komentar';

$txt['show_notice'] = 'Teks Catatan';
$txt['show_notice_subject'] = 'Subyek';
$txt['show_notice_text'] = 'Teks';

$txt['mc_watched_users_title'] = 'Anggota Diawasi';
$txt['mc_watched_users_desc'] = 'Di sini Anda bisa memelihara jejak semua anggota yang sudah ditempatkan dalam &quot;pengawasan&quot; oleh tim moderasi.';
$txt['mc_watched_users_post'] = 'Lihat dengan Tulisan';
$txt['mc_watched_users_warning'] = 'Tingkat Peringatan';
$txt['mc_watched_users_last_login'] = 'Terakhir Masuk';
$txt['mc_watched_users_last_post'] = 'Tulisan Terakhir';
$txt['mc_watched_users_no_posts'] = 'Tidak ada tulisan dari anggota yang diawasi.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Anda yakin ingin menghapus tulisan ini?';
$txt['mc_watched_users_delete_posts'] = 'Anda yakin ingin menghapus tulisan ini?';
$txt['mc_watched_users_posted'] = 'Ditulis';
$txt['mc_watched_users_member'] = 'Anggota';

$txt['mc_warnings_description'] = 'Dari seksi ini Anda bisa melihat peringatan yang sudah diterbitkan kepada anggota forum. Anda juga bisa menambah dan memodifikasi template pemberitahuan yang dipakai saat mengirimkan peringatan bagi anggota.';
$txt['mc_warning_log'] = 'Log Peringatan';
$txt['mc_warning_templates'] = 'Template Kustom';
$txt['mc_warning_log_title'] = 'Viewing warning log';
$txt['mc_warning_templates_title'] = 'Custom warning templates';

$txt['mc_warnings_none'] = 'No warnings have been issued.';
$txt['mc_warnings_recipient'] = 'Penerima';

$txt['mc_warning_templates_none'] = 'Tidak ada template peringatan yang sudah dibuat';
$txt['mc_warning_templates_time'] = 'Jam Dibuat';
$txt['mc_warning_templates_name'] = 'Template';
$txt['mc_warning_templates_creator'] = 'Dibuat Oleh';
$txt['mc_warning_template_add'] = 'Tambah Template';
$txt['mc_warning_template_modify'] = 'Edit Template';
$txt['mc_warning_template_delete'] = 'Hapus Yang Dipilih';
$txt['mc_warning_template_delete_confirm'] = 'Anda yakin ingin menghapus template yang dipilih?';

$txt['mc_warning_template_desc'] = 'Use this page to fill in the details of the template. Note that the subject for the email is not part of the template. Note that as the notification is sent by PM you can use BBC within the template. If you use the {MESSAGE} variable then this template will not be available when issuing a generic warning (i.e. A warning not linked to a post).';
$txt['mc_warning_template_title'] = 'Judul Template';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Template Pribadi';
$txt['mc_warning_template_personal_desc'] = 'Jika Anda memilih opsi ini hanya Anda yang bisa melihatnya, mengedit, dan menggunakan template ini. Jika tidak dipilih, semua moderator akan bisa menggunakan template ini.';
$txt['mc_warning_template_error_no_title'] = 'You must set the title.';
$txt['mc_warning_template_error_no_body'] = 'You must set the notification body.';

$txt['mc_settings'] = 'Ubah Setelan';
$txt['mc_prefs_title'] = 'Preferensi Moderasi';
$txt['mc_prefs_desc'] = 'Seksi ini mengijinkan Anda untuk menyetel beberapa preferensi pribadi untuk aktivitas terkait moderasi seperi email pemberitahuan.';
$txt['mc_prefs_homepage'] = 'Item ditampilkan pada homepage moderasi';
$txt['mc_prefs_latest_news'] = 'ElkArte News';
$txt['mc_prefs_show_reports'] = 'Tampilkan jumlah laporan terbuka dalam header forum';
$txt['mc_prefs_notify_report'] = 'Beritahu laporan topik';
$txt['mc_prefs_notify_report_never'] = 'Tidak pernah';
$txt['mc_prefs_notify_report_moderator'] = 'Hanya jika ia adalah board yang saya moderasi';
$txt['mc_prefs_notify_report_always'] = 'Selalu';
$txt['mc_prefs_notify_approval'] = 'Beritahu item yang menunggu persetujuan';
$txt['mc_logoff'] = 'End Moderator Session';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Tambah catatan baru';
$txt['mc_add_note'] = 'Tambah';