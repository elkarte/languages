<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Dari halaman ini Anda dapat mengkonfigurasi setelan surat Anda, juga melihat dan mengadministrasi antrian surat saat ini jika ia dihidupkan.';
$txt['mail_settings'] = 'Mail Settings';

$txt['mail_type'] = 'Tipe Surat';
$txt['mail_type_default'] = '(Standar PHP)';
$txt['smtp_host'] = 'Server SMTP';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'Port SMTP';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'Nama pengguna SMTP';
$txt['smtp_password'] = 'Kata sandi SMTP';

$txt['mail_queue'] = 'Enable mail queue';
$txt['mail_period_limit'] = 'Maksimum email untuk dikirimkan per menit';
$txt['mail_period_limit_desc'] = '(0 untuk mematikan)';
$txt['mail_batch_size'] = 'Jumlah Maksimum email untuk dikirimkan per halaman';

$txt['mailqueue_stats'] = 'Mail queue statistics';
$txt['mailqueue_oldest'] = 'Surat Terlama';
$txt['mailqueue_oldest_not_available'] = 'Tidak Ada';
$txt['mailqueue_size'] = 'Queue length';

$txt['mailqueue_age'] = 'Usia';
$txt['mailqueue_priority'] = 'Prioritas';
$txt['mailqueue_recipient'] = 'Penerima';
$txt['mailqueue_subject'] = 'Subyek';
$txt['mailqueue_clear_list'] = 'Send mail queue now';
$txt['mailqueue_no_items'] = 'Antrian surat saat ini kosong';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Anda yakin ingin mengirimkan seluruh antrian surat sekarang? Ini akan mengabaikan setiap batasan yang telah Anda tetapkan.';

$txt['mq_day'] = '%1.1f Hari';
$txt['mq_days'] = '%1.1f Hari';
$txt['mq_hour'] = '%1.1f Jam';
$txt['mq_hours'] = '%1.1f Jam';
$txt['mq_minute'] = '%1$d Menit';
$txt['mq_minutes'] = '%1$d Menit';
$txt['mq_second'] = '%1$d Detik';
$txt['mq_seconds'] = '%1$d Detik';

$txt['mq_mpriority_5'] = 'Sangat Rendah';
$txt['mq_mpriority_4'] = 'Rendah';
$txt['mq_mpriority_3'] = 'Normal';
$txt['mq_mpriority_2'] = 'Tinggi';
$txt['mq_mpriority_1'] = 'Sangat Tinggi';

$txt['birthday_email'] = 'Birthday message to use';
$txt['birthday_body'] = 'Email body';
$txt['birthday_subject'] = 'Email subject';