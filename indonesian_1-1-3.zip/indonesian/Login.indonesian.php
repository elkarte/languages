<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Perjanjian Registrasi';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'Saya menerima isi perjanjian.';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Saya menerima isi perjanjian dan setidaknya saya berusia %1$d tahun.';
$txt['agreement_agree_coppa_below'] = 'Saya menerima isi perjanjian dan saya lebih muda dari usia %1$d tahun.';
$txt['agree_coppa_above'] = 'I am at least %1$d years old.';
$txt['agree_coppa_below'] = 'I am younger than %1$d years old.';

// Registration form.
$txt['registration_form'] = 'Formulir Registrasi';
$txt['error_too_quickly'] = 'You went through the registration process too quickly, faster than should normally be possible. Please wait a moment and try again.';
$txt['error_token_verification'] = 'Token verification failed. Please try again.';
$txt['need_username'] = 'Anda perlu mengisi nama pengguna.';
$txt['no_password'] = 'Anda tidak memasukkan kata sandi Anda.';
$txt['improper_password'] = 'The supplied password is too long.';
$txt['incorrect_password'] = 'Kata sandi tidak benar';
$txt['openid_not_found'] = 'Supplied OpenID identifier not found.';
$txt['maintain_mode'] = 'Mode Pemeliharaan';
$txt['registration_successful'] = 'Registrasi sukses';
$txt['valid_email_needed'] = 'Silahkan masukkan alamat email yang benar, %1$s.';
$txt['required_info'] = 'Informasi yang Diperlukan';
$txt['additional_information'] = 'Informasi Tambahan';
$txt['warning'] = 'Peringatan!';
$txt['only_members_can_access'] = 'Hanya anggota terdaftar dibolehkan untuk mengakses seksi ini.';
$txt['login_below'] = 'Please login below.';
$txt['login_below_or_register'] = 'Please login below or <a href="%1$s">register an account</a> with %2$s';
$txt['checkbox_agreement'] = 'I accept the registration agreement';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Password security has recently been upgraded.<br />Please enter your password again.';

$txt['ban_register_prohibited'] = 'Maaf, Anda tidak diperkenankan untuk mendaftar pada forum ini.';
$txt['under_age_registration_prohibited'] = 'Maaf, pengguna di bawah usia %1$d tidak diperbolehkan untuk mendaftar pada forum ini.';

$txt['activate_account'] = 'Aktivasi Akun';
$txt['activate_success'] = 'Akun Anda sudah diaktifkan dengan sukses. Sekarang Anda bisa melanjutkan untuk masuk.';
$txt['activate_not_completed1'] = 'Alamat email Anda perlu divalidasi sebelum Anda bisa masuk.';
$txt['activate_not_completed2'] = 'Perlu email aktivasi lain?';
$txt['activate_after_registration'] = 'Terima kasih atas registrasinya. Anda akan segera menerima sebuah email dengan sebuah link untuk mengaktifkan akun Anda.  Jika Anda tidak menerima email setelah beberapa waktu, periksa folder spam Anda.';
$txt['invalid_userid'] = 'Pengguna tidak ada';
$txt['invalid_activation_code'] = 'Kode aktivasi tidak benar';
$txt['invalid_activation_username'] = 'Nama pengguna atau email';
$txt['invalid_activation_new'] = 'Jika Anda terdaftar dengan alamat email yang salah, ketik yang baru dan kata sandi Anda di sini.';
$txt['invalid_activation_new_email'] = 'Alamat email baru';
$txt['invalid_activation_password'] = 'Kata sandi lama';
$txt['invalid_activation_resend'] = 'Kirim ulang kode aktivasi';
$txt['invalid_activation_known'] = 'Jika Anda sudah mengetahui kode aktivasi Anda, silahkan ketikkan di sini.';
$txt['invalid_activation_retry'] = 'Kode aktivasi';
$txt['invalid_activation_submit'] = 'Aktifkan';

$txt['coppa_no_concent'] = 'Administrator belum menerima persetujuan orang tua/wali untuk akun Anda.';
$txt['coppa_need_more_details'] = 'Perlu lebih rinci?';

$txt['awaiting_delete_account'] = 'Akun Anda sudah ditandai untuk penghapusan!<br />Jika Anda ingin mengembalikan akun Anda, silahkan centang kotak &quot;Aktivasi ulang akun saya&quot;, dan masuk lagi.';
$txt['undelete_account'] = 'Aktivasi ulang akun saya';

$txt['in_maintain_mode'] = 'Board ini dalam Mode Pemeliharaan.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Silahkan baca dan terima perjanjian sebelum mendaftar.';
$txt['register_passwords_differ_js'] = 'Dua kata sandi yang Anda masukkan tidak sama!';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Terima kasih atas registrasinya. Admin harus menyetujui registrasi Anda sebelum Anda mulai menggunakan akun, Anda akan segera menerima email mengenai keputusan admin.';

$txt['admin_settings_desc'] = 'Di sini Anda dapat mengubah berbagai setelan terkait dengan pendaftaran anggota baru.';

$txt['setting_enableOpenID'] = 'Ijinkan pengguna untuk mendaftar menggunakan OpenID';

$txt['setting_registration_method'] = 'Metode registrasi yang diberlakukan bagi anggota baru';
$txt['setting_registration_disabled'] = 'Registrasi Dimatikan';
$txt['setting_registration_standard'] = 'Registrasi Langsung';
$txt['setting_registration_activate'] = 'Aktivasi Email';
$txt['setting_registration_approval'] = 'Persetujuan Admin';
$txt['setting_notify_new_registration'] = 'Beritahu administrator saat anggota baru bergabung';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Kirim email penyambutan bagi anggota baru';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Usia terendah untuk memberlakukan pembatasan registrasi';
$txt['setting_coppaAge_desc'] = '(0 untuk mematikan)';
$txt['setting_coppaType'] = 'Tindakan yang diambil ketika pengguna di bawah usia minimum mendaftar';
$txt['setting_coppaType_reject'] = 'Tolak registrasinya';
$txt['setting_coppaType_approval'] = 'Perlukan persetujuan orang tua/wali';
$txt['setting_coppaPost'] = 'Alamat pos ke mana formulir ini harus dikirimkan';
$txt['setting_coppaPost_desc'] = 'Hanya diterapkan jika pembatasan usia dilakukan';
$txt['setting_coppaFax'] = 'Nomor faksimili ke mana formulir persetujuan di-faks';
$txt['setting_coppaPhone'] = 'Nomor kontak orang tua dengan permintaan pembatasan usia';

$txt['admin_register'] = 'Registrasi anggota baru';
$txt['admin_register_desc'] = 'Dari sini Anda dapat meregistrasi anggota baru ke dalam forum, dan jika diinginkan, email mereka untuk rinciannya.';
$txt['admin_register_username'] = 'Nama pengguna Baru';
$txt['admin_register_email'] = 'Alamat Email';
$txt['admin_register_password'] = 'Kata sandi';
$txt['admin_register_username_desc'] = 'Nama pengguna untuk anggota baru';
$txt['admin_register_email_desc'] = 'Alamat email anggota';
$txt['admin_register_password_desc'] = 'Kata sandi untuk anggota baru';
$txt['admin_register_email_detail'] = 'Email kata sandi baru ke pengguna';
$txt['admin_register_email_detail_desc'] = 'Alamat email diperlukan meskipun tidak dicentang';
$txt['admin_register_email_activate'] = 'Pengguna harus mengaktifkan akun';
$txt['admin_register_group'] = 'Grup anggota Utama';
$txt['admin_register_group_desc'] = 'Grup anggota utama di mana anggota baru akan memilikinya';
$txt['admin_register_group_none'] = '(tidak ada grup anggota utama)';
$txt['admin_register_done'] = 'Anggota %1$s sudah terdaftar dengan sukses!';

$txt['coppa_title'] = 'Forum Usia Terbatas';
$txt['coppa_after_registration'] = 'Thank you for registering with {forum_name_html_safe}.<br /><br />Because you fall under the age of {MINIMUM_AGE}, it is a legal requirement to obtain your parent or guardian\'s permission before you may begin to use your account.  To arrange for account activation please print off the form below:';
$txt['coppa_form_link_popup'] = 'Ambil Formulir Dalam Jendela Baru';
$txt['coppa_form_link_download'] = 'Download Formulir sebagai File Teks';
$txt['coppa_send_to_one_option'] = 'Kemudian atur untuk orang tua/wali Anda agar mengirimkan formulir lengkap dengan:';
$txt['coppa_send_to_two_options'] = 'Kemudian atur untuk orang tua/wali Anda agar mengirimkan formulir lengkap dengan:';
$txt['coppa_send_by_post'] = 'Kirimkan, ke alamat berikut:';
$txt['coppa_send_by_fax'] = 'Fax, ke nomor berikut:';
$txt['coppa_send_by_phone'] = 'Alternatifnya, atur agar mereka menelpon administrator di {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Permission form for registration at {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Alamat';
$txt['coppa_form_date'] = 'Tanggal';
$txt['coppa_form_body'] = 'I {PARENT_NAME},<br /><br />give permission for {CHILD_NAME} (child name) to become a fully registered member of the forum: {forum_name_html_safe}, with the username: {USER_NAME}.<br /><br />I understand that certain personal information entered by {USER_NAME} may be shown to other users of the forum.<br /><br />Signed:<br />{PARENT_NAME} (Parent/Guardian).';

$txt['visual_verification_sound_again'] = 'Mainkan lagi';
$txt['visual_verification_sound_close'] = 'Tutup jendela';
$txt['visual_verification_sound_direct'] = 'Kesulitan mendengarkan ini?  Coba link yang langsung.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Nama pengguna tersedia';
$txt['registration_username_unavailable'] = 'Nama pengguna tidak tersedia';
$txt['registration_username_check'] = 'Periksa apakah nama pengguna tersedia';
$txt['registration_password_short'] = 'Kata sandi terlalu pendek';
$txt['registration_password_reserved'] = 'Kata sandi berisi nama pengguna/email Anda';
$txt['registration_password_numbercase'] = 'Kata sandi harus berisi huruf besar dan kecil, juga angka';
$txt['registration_password_no_match'] = 'Kata sandi tidak sama';
$txt['registration_password_valid'] = 'Kata sandi tidak benar';

$txt['registration_errors_occurred'] = 'Kesalahan berikut sudah terdeteksi dalam registrasi Anda. Silahkan betulkan dan melanjutkan:';

$txt['authenticate_label'] = 'Metode Otentikasi';
$txt['authenticate_password'] = 'Kata sandi';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'URL Otentikasi OpenID';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'Contact the admins';
$txt['contact_your_message'] = 'Your message';
$txt['errors_contact_form'] = 'The following errors occurred while processing your contact request';
$txt['contact_subject'] = 'A guest has sent you a message';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
