<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Anda tidak diijinkan untuk mengubah profil orang ini.';
$txt['website_title'] = 'Judul website';
$txt['website_url'] = 'URL website';
$txt['signature'] = 'Tanda tangan';
$txt['profile_posts'] = 'Tulisan';

$txt['profile_info'] = 'Extra Details';
$txt['profile_contact'] = 'Contact Information';
$txt['profile_moderation'] = 'Moderation Information';
$txt['profile_more'] = 'Tanda tangan';
$txt['profile_attachments'] = 'Recent Attachments';
$txt['profile_attachments_no'] = 'There are no Attachments from this member';
$txt['profile_recent_posts'] = 'Tulisan Terbaru';
$txt['profile_posts_no'] = 'There are no posts from this member';
$txt['profile_topics'] = 'Recent Topics';
$txt['profile_topics_no'] = 'There are no topics from this member';
$txt['profile_buddies_no'] = 'You have not set any buddies';
$txt['profile_user_info'] = 'User Info';
$txt['profile_contact_no'] = 'There is no contact information for this member';
$txt['profile_signature_no'] = 'There is no signature for this member';
$txt['profile_additonal_no'] = 'There is no additional information for this member';
$txt['profile_user_summary'] = 'Profil';
$txt['profile_action'] = 'Currently';
$txt['profile_recent_activity'] = 'Recent Activity';
$txt['profile_activity'] = 'Aktivitas';
$txt['profile_loadavg'] = 'Please try again later.  This information is not currently available due to high demand on the site.';

$txt['change_profile'] = 'Ubah profil';
$txt['preview_signature'] = 'Preview signature';
$txt['current_signature'] = 'Current signature';
$txt['signature_preview'] = 'Signature preview';
$txt['personal_picture'] = 'Gambar Pribadi';
$txt['no_avatar'] = 'Tidak ada avatar';
$txt['choose_avatar_gallery'] = 'Pilih avatar dari galeri';
$txt['preferred_language'] = 'Bahasa Diinginkan';
$txt['age'] = 'Usia';
$txt['no_pic'] = '(tanpa gambar)';
$txt['avatar_by_url'] = 'Specify your own avatar by URL. (e.g.: <em>http://www.mypage.com/mypic.png</em>)';
$txt['my_own_pic'] = 'Tetapkan avatar dengan URL';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'Format di sini akan dipakai untuk menampilkan tanggal lewat forum ini.';
$txt['time_format'] = 'Format Jam';
$txt['display_name_desc'] = 'Ini nama tampilan yang akan dilihat orang.';
$txt['personal_time_offset'] = 'Jumlah jam +/- untuk menyamakan waktu tampilan dengan jam lokal Anda.';
$txt['dob'] = 'Tanggal lahir';
$txt['dob_month'] = 'Bulan (MM)';
$txt['dob_day'] = 'Tanggal (DD)';
$txt['dob_year'] = 'Tahun (YYYY)';
$txt['password_strength'] = 'Untuk keamanan terbaik, Anda harus mengunakan delapan atau lebih karakter dengan kombinasi huruf, angka, dan simbol.';
$txt['include_website_url'] = 'Ini harus disertakan jika Anda menetapkan URL di bawah ini.';
$txt['complete_url'] = 'Ini harus URL lengkap.';
$txt['sig_info'] = 'Tanda tangan ditampilkan di bawah setiap tulisan atau pesan pribadi. BBCode dan smileys dapat dipakai dalam tanda tangan Anda.';
$txt['max_sig_characters'] = 'Maks karakter: %1$d; karakter tersisa:';
$txt['send_member_pm'] = 'Kirim pesan pribadi ke anggota ini';
$txt['hidden'] = 'disembunyikan';
$txt['current_time'] = 'Waktu forum saat ini';

$txt['language'] = 'Bahasa';
$txt['avatar_too_big'] = 'Gambar avatar terlalu besar, silahkan ukur ulang dan coba lagi (maks';
$txt['invalid_registration'] = 'Nilai Tanggal Terdaftar tidak benar, contoh yang benar:';
$txt['current_password'] = 'Kata sandi Saat Ini';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Untuk alasan keamanan, kata sandi Anda saat ini diperlukan guna membuat perubahan ke akun Anda.';

$txt['timeoffset_autodetect'] = 'auto detect';

$txt['secret_question'] = 'Pertanyaan Rahasia';
$txt['secret_desc'] = 'Untuk membantu mendapatkan kata sandi Anda, masukkan pertanyaan di sini dengan jawaban yang <strong>hanya</strong> Anda mengetahuinya.';
$txt['secret_desc2'] = 'Pilih dengan hati-hati, Anda tidak menginginkan orang lain menebak jawaban Anda!';
$txt['secret_answer'] = 'Jawaban';
$txt['incorrect_answer'] = 'Maaf, tapi Anda tidak menetapkan kombinasi Pertanyaan dan Jawaban yang benar dalam profil Anda.  Silahkan klik pada tombol back, dan gunakan metode standar mendapatkan kata sandi Anda.';
$txt['enter_new_password'] = 'Silahkan jawab pertanyaan Anda, dan kata sandi Anda yang ingin Anda pakai.  Kata sandi Anda akan diubah jika Anda menjawab pertanyaan dengan benar.';
$txt['secret_why_blank'] = 'mengapa ini kosong?';

$txt['authentication_reminder'] = 'Pengingat Otentikasi';
$txt['password_reminder_desc'] = 'Jika Anda lupa rincian masuk Anda, jangan khawatir, ini masih bisa diambil. Untuk memulai proses ini silahkan masukkan nama pengguna dan kata sandi di bawah.';
$txt['authentication_options'] = 'Silahkan pilih salah satu dari dua opsi di bawah';
$txt['authentication_openid_email'] = 'Email saya pengingat dari identitas OpenID saya';
$txt['authentication_openid_secret'] = 'Jawab &quot;pertanyaan rahasia&quot; saya untuk menampilkan identitas OpenID saya';
$txt['authentication_password_email'] = 'Email saya kata sandi baru';
$txt['authentication_password_secret'] = 'Biarkan saya menyetel kata sandi baru dengan menjawab &quot;pertanyaan rahasia&quot; saya';
$txt['openid_secret_reminder'] = 'Silahkan masukkan jawaban Anda ke pertanyaan di bawah. Jika Anda menjawab benar, identitas OpenID Anda akan ditampilkan.';
$txt['reminder_openid_is'] = 'Identitas OpenID yang dikaitkan dengan akun Anda adalah:<br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /><br />Harap catat ini untuk referensi di kemudian hari.';
$txt['reminder_continue'] = 'Lanjutkan';

$txt['accept_agreement_title'] = 'Accept agreement';
$txt['agreement_accepted_title'] = 'Lanjutkan';

$txt['current_theme'] = 'Tema Saat Ini';
$txt['change'] = 'Change Theme';
$txt['theme_forum_default'] = 'Standar Forum atau Board';
$txt['theme_forum_default_desc'] = 'Ini adalah tema standar yang berarti tema Anda akan berubah bersamaan dengan setelan administrator dan board yang sedang Anda lihat.';

$txt['profileConfirm'] = 'Anda yakin ingin menghapus anggota ini?';

$txt['custom_title'] = 'Judul Kustom';

$txt['lastLoggedIn'] = 'Terakhir Aktif';

$txt['notify_settings'] = 'Setelan Pemberitahuan:';
$txt['notify_save'] = 'Simpan setelan';
$txt['notify_important_email'] = 'Terima berita, pengumuman forum dan pemberitahuan penting dengan email.';
$txt['notify_regularity'] = 'Untuk topik dan board yang sudah saya minta pemberitahuannya, beritahu saya';
$txt['notify_regularity_none'] = 'Tidak pernah';
$txt['notify_regularity_instant'] = 'Secara instan';
$txt['notify_regularity_first_only'] = 'Secara instan - tapi hanya untuk jawaban pertama yang belum dibaca';
$txt['notify_regularity_daily'] = 'Harian';
$txt['notify_regularity_weekly'] = 'Mingguan';
$txt['auto_notify'] = 'Turn topic notification on when you post or reply to a topic.';
$txt['auto_notify_pbe_post'] = 'This is <strong>NOT</strong> recommended if you have "board" notifications enabled.';
$txt['notify_send_types'] = 'Notify me of topics and boards I\'ve requested notification on';
$txt['notify_send_type_everything'] = 'Jawaban dan moderasi';
$txt['notify_send_type_everything_own'] = 'Hanya moderasi jika saya memulai topik';
$txt['notify_send_type_only_replies'] = 'Hanya jawaban';
$txt['notify_send_type_only_replies_pbe'] = 'All messages';
$txt['notify_send_type_nothing'] = 'Tidak sama sekali';
$txt['notify_send_body'] = 'When sending notifications of a reply to a topic, send the post in the email (but please don\'t reply to these emails.)';
$txt['notify_send_body_pbe'] = 'When sending email notifications, send the full text of the post in the email';
$txt['notify_send_body_pbe_post'] = '<strong>NOT</strong> available with Daily / Weekly summary';

$txt['notify_method'] = 'Notification and:';
$txt['notify_notification'] = 'no email (only mention/alert)';
$txt['notify_email'] = 'Immediate email';
$txt['notify_email_daily'] = 'Daily email';
$txt['notify_email_weekly'] = 'Weekly email';

$txt['notify_type_likemsg'] = 'Notify when one of your messages is liked';
$txt['notify_type_mentionmem'] = 'Notify when you are @mentioned';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Notify when someone adds you as buddy';
$txt['notify_type_quotedmem'] = 'Notify when someone quotes one of your messages';
$txt['notify_type_mailfail'] = 'Notify when email notifications are disabled (mention only)';

$txt['notifications_topics'] = 'Pemberitahuan Topik Saat Ini';
$txt['notifications_topics_none'] = 'Saat ini Anda tidak menerima pemberitahuan apapun atas topik.';
$txt['notifications_topics_howto'] = 'To receive notifications from a specific topic, click the &quot;Notify&quot; button while viewing it.';

$txt['notifications_boards'] = 'Pemberitahuan Board Saat Ini';
$txt['notifications_boards_none'] = 'Anda tidak menerima pemberitahuan apapun pada setiap board saat ini.';
$txt['notifications_boards_howto'] = 'To request notifications from a specific board, either click the &quot;Notify&quot; button in the index of that board <strong>or</strong> use the checkboxes below to enable select board notifications.';
$txt['notifications_boards_current'] = 'You are receiving notifications on the boards shown in <strong>BOLD</strong>.  Use the checkboxes to turn these off or add additional boards to your notification list';
$txt['notifications_boards_update'] = 'Update';
$txt['notifications_update'] = 'Jangan beritahu';

$txt['statPanel_showStats'] = 'Statistik pengguna untuk: ';
$txt['statPanel_users_votes'] = 'Jumlah Suara Diberikan';
$txt['statPanel_users_polls'] = 'Jumlah Polling Dibuat';
$txt['statPanel_total_time_online'] = 'Total Waktu Online';
$txt['statPanel_noPosts'] = 'Tidak pernah menulis!';
$txt['statPanel_generalStats'] = 'Statistik Umum';
$txt['statPanel_posts'] = 'tulisan';
$txt['statPanel_topics'] = 'topik';
$txt['statPanel_total_posts'] = 'Total Tulisan';
$txt['statPanel_total_topics'] = 'Total Topik Dimulai';
$txt['statPanel_votes'] = 'suara';
$txt['statPanel_polls'] = 'polling';
$txt['statPanel_topBoards'] = 'Board Terpopuler Dengan Tulisan';
$txt['statPanel_topBoards_posts'] = '%1$d tulisan dari %2$d tulisan board (%3$01.2f%%) ';
$txt['statPanel_topBoards_memberposts'] = '%1$d tulisan dari %2$d tulisan anggota (%3$01.2f%%) ';
$txt['statPanel_topBoardsActivity'] = 'Board Terpopuler Dengan Aktivitas';
$txt['statPanel_activityTime'] = 'Aktivitas Penulisan Dengan Jam';
$txt['statPanel_activityTime_posts'] = '%1$d tulisan (%2$d%%) ';

$txt['deleteAccount_warning'] = 'Peringatan - Aksi ini tidak bisa dikembalikan!';
$txt['deleteAccount_desc'] = 'Dari halaman ini Anda dapat menghapus akun dan tulisan pengguna ini.';
$txt['deleteAccount_member'] = 'Hapus akun anggota ini';
$txt['deleteAccount_posts'] = 'Hapus tulisan yang dibuat anggota ini';
$txt['deleteAccount_none'] = 'Tidak ada';
$txt['deleteAccount_all_posts'] = 'Replies Only';
$txt['deleteAccount_topics'] = 'Topics and Replies';
$txt['deleteAccount_confirm'] = 'Anda yakin ingin menghapus akun ini selamanya?';
$txt['deleteAccount_approval'] = 'Harap dicatat bahwa moderator forum harus menyetujui penghapusan akun ini sebelum ia dihapus.';

$txt['profile_of_username'] = 'Profil %1$s';
$txt['profileInfo'] = 'Info Profil';
$txt['showPosts'] = 'Perlihatkan Tulisan';
$txt['showPosts_help'] = 'Seksi ini mengijinkan Anda untuk melihat semua tulisan yang dibuat oleh anggota ini. Catatan bahwa Anda hanya bisa melihat tulisan yang dibuat dalam area di mana Anda memiliki akses terhadapnya.';
$txt['showMessages'] = 'Pesan';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = 'Topik';
$txt['showUnwatched'] = 'Unwatched topics';
$txt['showAttachments'] = 'Lampiran';
$txt['viewWarning_help'] = 'This section allows you to view all warnings issued to this member.';
$txt['statPanel'] = 'Tampilklan Statistik';
$txt['editBuddyIgnoreLists'] = 'Daftar Teman/Abaikan';
$txt['editBuddies'] = 'Edit Teman';
$txt['editIgnoreList'] = 'Edit Daftar Abaikan';
$txt['trackUser'] = 'Lacak Pengguna';
$txt['trackActivity'] = 'Aktivitas';
$txt['trackIP'] = 'Alamat IP';
$txt['trackLogins'] = 'Logins';

$txt['likes_show'] = 'Show Likes';
$txt['likes_given'] = 'Posts you liked';
$txt['likes_profile_received'] = 'received';
$txt['likes_profile_given'] = 'given';
$txt['likes_received'] = 'Your posts liked by others';
$txt['likes_none_given'] = 'You have not liked any posts';
$txt['likes_none_received'] = 'No one has liked any of your posts :\'(';
$txt['likes_confirm_delete'] = 'Remove this like?';
$txt['likes_show_who'] = 'Show the members that liked this post';
$txt['likes_by'] = 'Liked by';
$txt['likes_delete'] = 'Hapus';

$txt['authentication'] = 'Otentikasi';
$txt['change_authentication'] = 'Dari seksi ini Anda dapat mengubah bagaimana Anda masuk ke forum. Anda dapat memilih apakah menggunakan akun OpenID untuk otentikasi Anda, atau alternatif lain beralih ke nama pengguna dan kata sandi.';

$txt['profileEdit'] = 'Ubah Profil';
$txt['account_info'] = 'Ini adalah setelan akun Anda. Halaman ini menampung semua informasi kritis yang mengidentifikasi Anda pada forum ini. Untuk alasan keamanan, Anda perlu memasukkan kata sandi (saat ini) Anda guna membuat perubahan terhadap informasi ini.';
$txt['forumProfile_info'] = 'You can change your personal information on this page. This information will be displayed throughout {forum_name_html_safe}. If you aren\'t comfortable with sharing some information, simply skip it - nothing here is required.';
$txt['theme_info'] = 'Seksi ini mengijinkan Anda untuk mengkustomisasi tata letak forum Anda.';
$txt['notification_info'] = 'This allows you to be notified of replies to posts, newly posted topics, and forum announcements. You can change those settings here, or oversee the topics and boards you are currently receiving notifications for.';
$txt['groupmembership'] = 'Keanggotaan Grup';
$txt['groupMembership_info'] = 'Dalam seksi ini, profil yang bisa Anda ubah adalah grup di mana Anda berada.';
$txt['ignoreboards'] = 'Opsi Abaikan';
$txt['ignoreboards_info'] = 'This page lets you ignore particular boards.  When a board is ignored, the new post indicator will not show up on the board index.  New posts will not show up using the "unread post" search link (when searching it will not look in those boards). However, ignored boards will still appear on the board index and upon entering will show which topics have new posts.  When using the "unread replies" link, new posts in an ignored board will still be shown.';
$txt['contactprefs'] = 'Messaging';

$txt['profileAction'] = 'Aksi';
$txt['deleteAccount'] = 'Hapus akun ini';
$txt['profileSendIm'] = 'Kirim Pesan Pribadi';
$txt['profile_sendpm_short'] = 'Kirim PM';

$txt['profileBanUser'] = 'Kucilkan pengguna ini';

$txt['display_name'] = 'Nama tampilan';
$txt['enter_ip'] = 'Masukkan IP (jangkauan)';
$txt['errors_by'] = 'Pesan kesalahan dengan';
$txt['errors_desc'] = 'Di bawah ini adalah daftar dari semua kesalahan terbaru yang dibuat/dialami oleh pengguna ini.';
$txt['errors_from_ip'] = 'Pesan kesalahan dari IP (jangkauan)';
$txt['errors_from_ip_desc'] = 'Di bawah ini adalah daftar semua pesan kesalahan yang dibuat oleh IP (jangkauan) ini.';
$txt['ip_address'] = 'Alamat IP';
$txt['ips_in_errors'] = 'IP yang dipakai dalam pesan kesalahan';
$txt['ips_in_messages'] = 'IP yang dipakai dalam tulisan terbaru';
$txt['members_from_ip'] = 'Anggota dari IP (jangkauan)';
$txt['members_in_range'] = 'Anggota mungkin dari jangkauan yang sama';
$txt['messages_from_ip'] = 'Pesan ditulis dari IP (jangkauan)';
$txt['messages_from_ip_desc'] = 'Di bawah ini adalah daftar semua pesan yang ditulis dari IP (jangkauan) ini.';
$txt['trackLogins_desc'] = 'Below is a list of all times this account was logged into.';
$txt['most_recent_ip'] = 'Alamat IP paling baru';
$txt['why_two_ip_address'] = 'Mengapa ada dua alamat IP didaftarkan?';
$txt['no_errors_from_ip'] = 'Tidak ada pesan kesalahan dari IP (jangkauan) itu yang ditemukan';
$txt['no_errors_from_user'] = 'Tidak ada pesan kesalahan dari pengguna itu yang ditemukan';
$txt['no_members_from_ip'] = 'Tidak ada anggota dari IP (jangkauan) itu yang ditemukan';
$txt['no_messages_from_ip'] = 'Tidak ada pesan dari IP (jangkauan) itu yang ditemukan';
$txt['trackLogins_none_found'] = 'No recent logins were found';
$txt['none'] = 'Tidak ada';
$txt['own_profile_confirm'] = 'Anda yakiin ingin menghapus akun Anda?';
$txt['view_ips_by'] = 'Lihat IP yang dipakai oleh';

$txt['avatar_will_upload'] = 'Upload avatar';

$txt['activate_changed_email_title'] = 'Alamat Email Diubah';
$txt['activate_changed_email_desc'] = 'Anda telah merubah alamat email anda. Untuk memvalidasi alamat ini anda akan menerima email. Klik tautan dalam email tersebut untuk aktivasi ulang akun anda.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Tidak bisa mengirimkan email pengingat.';
$txt['send_email'] = 'Kirim email ke';
$txt['to_ask_password'] = 'untuk meminta kata sandi';

$txt['user_email'] = 'Nama pengguna/Email';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'Surat sudah dikirimkan ke alamat email Anda. Klik link dalam email untuk menyetel kata sandi baru.';
$txt['reminder_openid_sent'] = 'Identitas OpenID Anda saat ini sudah dikirimkan ke alamat email Anda.';
$txt['reminder_set_password'] = 'Setel Kata sandi';
$txt['reminder_password_set'] = 'Kata sandi sudah disetel dengan sukses';
$txt['reminder_error'] = '%1$s gagal menjawab ke pertanyaan rahasianya sendiri dengan benar saat mencoba untuk mengubah kata sandi yang terlupakan.';

$txt['registration_not_approved'] = 'Maaf, akun ini belum disetujui. Jika Anda perlu untuk mengubah alamat email silahkan klik';
$txt['registration_not_activated'] = 'Maaf, akun ini belum diaktivasi. Jika Anda perlu untuk mengirimkan ulang email aktivasi silahkan klik';

$txt['primary_membergroup'] = 'Grup anggota Utama';
$txt['additional_membergroups'] = 'Grup Anggota Tambahan';
$txt['additional_membergroups_show'] = 'Show additional groups';
$txt['no_primary_membergroup'] = '(tidak ada grup anggota utama)';
$txt['deadmin_confirm'] = 'Anda yakin ingin menghapus selamanya status admin Anda?';

$txt['account_activate_method_2'] = 'Akun memerlukan reaktivasi setelah perubahan email';
$txt['account_activate_method_3'] = 'Akun tidak disetujui';
$txt['account_activate_method_4'] = 'Akun menunggu persetujuan untuk penghapusan';
$txt['account_activate_method_5'] = 'Akun &quot;dibawah usia&quot; menunggu persetujuan';
$txt['account_not_activated'] = 'Akun saat ini tidak diaktivasi';
$txt['account_activate'] = 'mengaktifkan';
$txt['account_approve'] = 'menyetujui';
$txt['user_is_banned'] = 'Pengguna saat ini dikucilkan';
$txt['view_ban'] = 'Lihat';
$txt['user_banned_by_following'] = 'Pengguna saat ini dipengaruhi oleh pengucilan berikut';
$txt['user_cannot_due_to'] = 'Pengguna tidak bisa %1$s karena pengucilan: &quot;%2$s&quot;';
$txt['ban_type_post'] = 'menulis';
$txt['ban_type_register'] = 'mendaftar';
$txt['ban_type_login'] = 'masuk';
$txt['ban_type_access'] = 'mengakses forum';

$txt['show_online'] = 'Tampilkan status online saya bagi yang lain';

$txt['return_to_post'] = 'Standarnya kembali ke topik setelah menulis.';
$txt['no_new_reply_warning'] = 'Jangan peringatkan jawaban baru yang dibuat saat menulis.';
$txt['recent_pms_at_top'] = 'Tampilkan pesan pribadi terbaru di atas.';
$txt['wysiwyg_default'] = 'Tampilkan editor WYSIWYG pada halaman tulisan secara standar.';

$txt['timeformat_default'] = '(Standar Forum)';
$txt['timeformat_easy1'] = 'Bulan Tanggal, Tahun, HH:MM:SS am/pm';
$txt['timeformat_easy2'] = 'Bulan Tanggal, Tahun, HH:MM:SS (24 jam)';
$txt['timeformat_easy3'] = 'YYYY-MM-DD, HH:MM:SS';
$txt['timeformat_easy4'] = 'DD Month YYYY, HH:MM:SS';
$txt['timeformat_easy5'] = 'DD-MM-YYYY, HH:MM:SS';

$txt['poster'] = 'Penulis';

$txt['use_sidebar_menu'] = 'Use sidebar menu instead of dropdowns.';
$txt['use_click_menu'] = 'Use click to open menus, instead of hover to open.';
$txt['show_no_avatars'] = 'Jangan tampilkan avatar pengguna.';
$txt['show_no_signatures'] = 'Jangan tampilkan tanda tangan pengguna.';
$txt['show_no_censored'] = 'Biarkan kata tidak disensor.';
$txt['topics_per_page'] = 'Topik ditampilkan per halaman:';
$txt['messages_per_page'] = 'Pesan ditampilkan per halaman:';
$txt['hide_poster_area'] = 'Hide the poster information area.';
$txt['per_page_default'] = 'standar forum';
$txt['calendar_start_day'] = 'First day of the week on the calendar:';
$txt['display_quick_reply'] = 'Gunakan jawab cepat pada tampilan topik: ';
$txt['use_editor_quick_reply'] = 'Use full editor in Quick Reply.';
$txt['display_quick_mod'] = 'Show quick-moderation as:';
$txt['display_quick_mod_none'] = 'jangan tampilkan.';
$txt['display_quick_mod_check'] = 'kotak centang.';
$txt['display_quick_mod_image'] = 'ikon.';

$txt['whois_title'] = 'Lihat IP pada whois-server regional';
$txt['whois_afrinic'] = 'AfriNIC (Afrika)';
$txt['whois_apnic'] = 'APNIC (regional Asia Pasifik)';
$txt['whois_arin'] = 'ARIN (Amerika Utara, sebagian Karibia dan sub-Sahara Afrika)';
$txt['whois_lacnic'] = 'LACNIC (regional Amerika Latin dan Karibia)';
$txt['whois_ripe'] = 'RIPE (Eropa, Timur Tengah dan sebagian Afrika dan Asia)';

$txt['moderator_why_missing'] = 'mengapa tidak ada moderator di sini?';
$txt['username_change'] = 'ubah';
$txt['username_warning'] = 'Untuk mengubah nama pengguna anggota ini, forum juga harus mereset kata sandinya yang akan diemail ke anggota dengan nama pengguna barunya.';

$txt['show_member_posts'] = 'Lihat Tulisan Anggota';
$txt['show_member_topics'] = 'Lihat Topik Anggota';
$txt['show_member_attachments'] = 'Lihat Lampiran Anggota';
$txt['show_posts_none'] = 'Belum ada tulisan apapun.';
$txt['show_topics_none'] = 'Belum ada topik yang dituliskan.';
$txt['unwatched_topics_none'] = 'You don\'t have any topic in the unwatch list.';
$txt['show_attachments_none'] = 'Belum ada lampiran yang dituliskan.';
$txt['show_attach_filename'] = 'Nama file';
$txt['show_attach_downloads'] = 'Download';
$txt['show_attach_posted'] = 'Ditulis';

$txt['showPermissions'] = 'Tampilkan Perijinan';
$txt['showPermissions_status'] = 'Status perizinan';
$txt['showPermissions_help'] = 'Bagian ini mengijinkan anda untuk melihat semua perizinan untuk member ini (perizinan yang ditolak adalah <del>dikeluarkan</del>). ';
$txt['showPermissions_given'] = 'Diberikan oleh';
$txt['showPermissions_denied'] = 'Ditolak oleh';
$txt['showPermissions_permission'] = 'Permission (denied permissions are shown <del>struck through</del>)';
$txt['showPermissions_none_general'] = 'Anggota ini tidak memiliki set perijinan umum.';
$txt['showPermissions_none_board'] = 'Anggota ini tidak memiliki set perijinan board spesifik.';
$txt['showPermissions_all'] = 'Sebagai administrator, anggota ini memiliki semua kemungkinan perijinan.';
$txt['showPermissions_select'] = 'Perijinan board spesifik untuk';
$txt['showPermissions_general'] = 'Perijinan dengan Grup anggota';
$txt['showPermissions_global'] = 'Semua board';
$txt['showPermissions_restricted_boards'] = 'Board terbatas';
$txt['showPermissions_restricted_boards_desc'] = 'Board berikut tidak bisa diakses oleh pengguna ini';

$txt['local_time'] = 'Waktu Lokal';
$txt['posts_per_day'] = 'per hari';

$txt['buddy_ignore_desc'] = 'Area ini mengijinkan Anda untuk memelihara daftar teman Anda dan daftar abaikan pada forum ini. Menambahkan anggota ke daftar ini akan membantu mengontrol surat dan trafik PM, tergantung pada preferensi Anda.';

$txt['buddy_add'] = 'Add to buddy list';
$txt['buddy_remove'] = 'Remove from buddy list';
$txt['buddy_add_button'] = 'Tambah';
$txt['no_buddies'] = 'Daftar teman Anda saat ini kosong';

$txt['ignore_add'] = 'Add to ignore list';
$txt['ignore_remove'] = 'Remove from ignore list';
$txt['ignore_add_button'] = 'Tambah';
$txt['no_ignore'] = 'Daftar abaikan Anda saat ini kosong';

$txt['regular_members'] = 'Anggota Terdaftar';
$txt['regular_members_desc'] = 'Setiap anggota forum adalah anggota dari grup ini.';
$txt['group_membership_msg_free'] = 'Keanggotaan grup Anda sudah dimutakhirkan dengan sukses.';
$txt['group_membership_msg_request'] = 'Permintaan sudah dikirimkan, harap bersabar saat permintaan dipertimbangkan.';
$txt['group_membership_msg_primary'] = 'Grup utama Anda sudah dimutakhirkan';
$txt['current_membergroups'] = 'Grup anggota Saat Ini';
$txt['available_groups'] = 'Grup Tersedia';
$txt['join_group'] = 'Gabung Grup';
$txt['leave_group'] = 'Tinggalkan Grup';
$txt['request_group'] = 'Minta Keanggotaan';
$txt['approval_pending'] = 'Persetujuan Tertunda';
$txt['make_primary'] = 'Jadikan Grup Utama';

$txt['request_group_membership'] = 'Minta Keanggotaan Grup';
$txt['request_group_membership_desc'] = 'Sebelum Anda dapat bergabung dengan grup ini, keanggotaan Anda harus disetujui oleh moderator. Silahkan berikan alasan untuk bergabung dengan grup ini';
$txt['submit_request'] = 'Kirimkan Permintaan';

$txt['profile_updated_own'] = 'Profil Anda sukses dimutakhirkan';
$txt['profile_updated_else'] = 'The profile for <strong>%1$s</strong> has been updated successfully.';

$txt['profile_error_signature_max_length'] = 'Tanda tangan Anda tidak boleh lebih besar dari %1$d karakter';
$txt['profile_error_signature_max_lines'] = 'Tanda tangan Anda tidak bisa memanjang lebih dari %1$d baris';
$txt['profile_error_signature_max_image_size'] = 'Gambar dalam tanda tangan Anda harus tidak lebih besar dari %1$dx%2$d pixel';
$txt['profile_error_signature_max_image_width'] = 'Gambar dalam tanda tangan Anda harus tidak lebih lebar dari %1$d pixel';
$txt['profile_error_signature_max_image_height'] = 'Gambar dalam tanda tangan Anda harus tidak lebih tinggi dari %1$d pixel';
$txt['profile_error_signature_max_image_count'] = 'Anda tidak boleh memiliki lebih dari %1$d gambar dalam tanda tangan Anda';
$txt['profile_error_signature_max_font_size'] = 'Teks dalam tanda tangan Anda ukurannya tidak boleh lebih besar dari %1$s';
$txt['profile_error_signature_allow_smileys'] = 'Anda tidak diperbolehkan menggunakan smilies pada signature anda';
$txt['profile_error_signature_max_smileys'] = 'Anda tidak diijinkan untuk memakai lebih dari %1$d smiley di dalam tanda tangan Anda';
$txt['profile_error_signature_disabled_bbc'] = 'BBC berikut tidak diijinkan di dalam tanda tangan: %1$s';

$txt['profile_view_warnings'] = 'Lihat Peringatan';
$txt['profile_issue_warning'] = 'Terbitkan Peringatan';
$txt['profile_warning_level'] = 'Tingkat Peringatan';
$txt['profile_warning_desc'] = 'Dari seksi ini Anda bisa menyesuaikan tingkat peringatan pengguna dan menerbitkannya dengan peringatan tertulis jika diperlukan. Anda juga bisa melacak histori peringatan dan melihat pengaruh atas tingkat peringatan saat ini seperti ditentukan oleh administrator.';
$txt['profile_warning_name'] = 'Nama Anggota';
$txt['profile_warning_impact'] = 'Hasil';
$txt['profile_warning_reason'] = 'Alasan untuk Peringatan';
$txt['profile_warning_reason_desc'] = 'Ini diperlukan dan akan dicatat.';
$txt['profile_warning_effect_none'] = 'Tidak ada.';
$txt['profile_warning_effect_watch'] = 'Pengguna akan ditambahkan ke daftar pengawasan moderator.';
$txt['profile_warning_effect_own_watched'] = 'Anda ada dalam daftar pengawasan moderator.';
$txt['profile_warning_is_watch'] = 'sedang diawasi';
$txt['profile_warning_effect_moderate'] = 'Semua tulisan pengguna akan dimoderasi.';
$txt['profile_warning_effect_own_moderated'] = 'Semua tulisan Anda akan dimoderasi.';
$txt['profile_warning_is_moderation'] = 'tulisan dimoderasi';
$txt['profile_warning_effect_mute'] = 'Pengguna tidak akan bisa menulis.';
$txt['profile_warning_effect_own_muted'] = 'Anda tidak akan bisa menulis.';
$txt['profile_warning_is_muted'] = 'tidak bisa menulis';
$txt['profile_warning_effect_text'] = 'Tingkat >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Kirim Pemberitahuan';
$txt['profile_warning_notify_template'] = 'Pilih template:';
$txt['profile_warning_notify_subject'] = 'Subyek Pemberitahuan';
$txt['profile_warning_notify_body'] = 'Pesan Pemberitahuan';
$txt['profile_warning_notify_template_subject'] = 'Anda menerima sebuah peringatan';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},

You have received a warning for %1$s. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},

You have received a warning for %1$s in regards to the message:
{MESSAGE}.

Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'melakukan spam';
$txt['profile_warning_notify_title_spamming'] = 'Melakukan spam';
$txt['profile_warning_notify_for_offence'] = 'menulis material penyerangan';
$txt['profile_warning_notify_title_offence'] = 'Menulis Material Penyerangan';
$txt['profile_warning_notify_for_insulting'] = 'menghina pengguna lain dan/atau anggota staf';
$txt['profile_warning_notify_title_insulting'] = 'Menghina Pengguna/Staf';
$txt['profile_warning_issue'] = 'Terbitkan Peringatan';
$txt['profile_warning_max'] = '(Maks 100)';
$txt['profile_warning_limit_attribute'] = 'Catatan bahwa Anda tidak bisa menyesuaikan tingkat pengguna ini lebih dari %1$d%% dalam periode 24 jam.';
$txt['profile_warning_errors_occurred'] = 'Peringatan tidak dikirimkan karena kesalahan berikut';
$txt['profile_warning_success'] = 'Peringatan Sukses Diterbitkan';
$txt['profile_warning_new_template'] = 'Template Baru';

$txt['profile_warning_previous'] = 'Peringatan Sebelumnya';
$txt['profile_warning_previous_none'] = 'Pengguna ini belum menerima peringatan apapun sebelumnya.';
$txt['profile_warning_previous_issued'] = 'Diterbitkan Oleh';
$txt['profile_warning_previous_time'] = 'Jam';
$txt['profile_warning_previous_level'] = 'Poin';
$txt['profile_warning_previous_reason'] = 'Alasan';
$txt['profile_warning_previous_notice'] = 'Lihat Catatan yang Dikirimkan ke Anggota';

$txt['viewwarning'] = 'Lihat Peringatan';
$txt['profile_viewwarning_for_user'] = 'Peringatan untuk %1$s';
$txt['profile_viewwarning_no_warnings'] = 'No warnings have been issued.';
$txt['profile_viewwarning_desc'] = 'Di bawah ini adalah ringkasan dari semua peringatan yang sudah diterbitkan oleh tim moderasi forum.';
$txt['profile_viewwarning_previous_warnings'] = 'Peringatan Sebelumnya';
$txt['profile_viewwarning_impact'] = 'Pengaruh Peringatan';

$txt['subscriptions'] = 'Subskripsi Berbayar';

$txt['pm_settings_desc'] = 'Dari halaman ini Anda dapat mengubah berbagai opsi pesan pribadi - termasuk bagaimana pesan ditampilkan dan siapa yang dapat mengirimkan pesan kepada Anda.';
$txt['email_notify'] = 'Beritahu dengan email setiap kali Anda menerima pesan pribadi:';
$txt['email_notify_never'] = 'Tidak pernah';
$txt['email_notify_buddies'] = 'Hanya Dari Teman';
$txt['email_notify_always'] = 'Selalu';

$txt['receive_from'] = 'Members allowed to contact me:';
$txt['receive_from_everyone'] = 'Semua anggota';
$txt['receive_from_ignore'] = 'Semua anggota, kecuali dari daftar abaikan saya';
$txt['receive_from_admins'] = 'Hanya Administrator';
$txt['receive_from_buddies'] = 'Hanya Teman dan Administrator';
$txt['receive_from_description'] = 'This setting applies to both Personal Messages and emails (if the option to email members is enabled)';

$txt['popup_messages'] = 'Tampilkan popup ketika saya menerima pesan pribadi baru.';
$txt['pm_remove_inbox_label'] = 'Remove the inbox label when applying another label.';
$txt['pm_display_mode'] = 'Tampilkan pesan pribadi';
$txt['pm_display_mode_all'] = 'Sekaligus';
$txt['pm_display_mode_one'] = 'Satu-persatu';
$txt['pm_display_mode_linked'] = 'Sebagai tulisan';

$txt['history'] = 'History';
$txt['history_description'] = 'This section allows you to review certain profile actions performed on this member\'s profile as well as track their IP address and login history.';

$txt['trackEdits'] = 'Pengeditan Profil';
$txt['trackEdit_deleted_member'] = 'Anggota Dihapus';
$txt['trackEdit_no_edits'] = 'Sejauh ini tidak ada pengeditan yang dilakukan untuk anggota ini.';
$txt['trackEdit_action'] = 'Field';
$txt['trackEdit_before'] = 'Nilai Sebelum';
$txt['trackEdit_after'] = 'Nilai Setelah';
$txt['trackEdit_applicator'] = 'Diubah Oleh';

$txt['trackEdit_action_real_name'] = 'Nama Anggota';
$txt['trackEdit_action_usertitle'] = 'Judul Kustom';
$txt['trackEdit_action_member_name'] = 'Nama pengguna';
$txt['trackEdit_action_email_address'] = 'Alamat Email';
$txt['trackEdit_action_id_group'] = 'Grup anggota Utama';
$txt['trackEdit_action_additional_groups'] = 'Grup Anggota Tambahan';

$txt['otp_enabled_help'] = 'Enabling this will add a second factor (one-time password) for authentication.';
$txt['otp_token_help'] = 'This generates a secret token for time-based one-time password  apps such as Authy or Google Authenticator. Once the secret was generated use your favorite authenticator app and scan the qrcode.<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
