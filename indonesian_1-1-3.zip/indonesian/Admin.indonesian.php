<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Board';
$txt['admin_back_to'] = 'Back to admin panel';
$txt['admin_users'] = 'Anggota';
$txt['admin_newsletters'] = 'Surat berkala';
$txt['include_these'] = 'Members to include';
$txt['exclude_these'] = 'Members to exclude';
$txt['admin_newsletters_select_groups'] = 'Groups to include';
$txt['admin_newsletters_exclude_groups'] = 'Groups to exclude';
$txt['admin_edit_news'] = 'Berita';
$txt['admin_groups'] = 'Member groups';
$txt['admin_members'] = 'Atur Anggota';
$txt['admin_members_list'] = 'Di bawah ini adalah daftar seluruh anggota yang saat ini terdaftar pada forum Anda.';
$txt['admin_next'] = 'Berikutnya';
$txt['admin_censored_words'] = 'Kata Disensor';
$txt['admin_censored_where'] = 'Enter the word to be censored into the left box and the word to change it to, into the right box. Then select if you want to check the whole word and the case. When you\'re finished with each word, click Save. Multiple entries can be made prior to saving by clicking the \'Add another word\' button.';
$txt['admin_censored_desc'] = 'Due to the public nature of forums there may be some words that you wish to prohibit being posted by users of your forum. You can enter any words below that you wish to be censored whenever used by a member.<br />Clear a box to remove that word from the censor.';
$txt['admin_reserved_names'] = 'Nama-nama Terpakai';
$txt['admin_template_edit'] = 'Edit your forum template';
$txt['admin_modifications'] = 'Add-on Settings';
$txt['admin_security_moderation'] = 'Keamanan dan Moderasi';
$txt['admin_server_settings'] = 'Setelan Server';
$txt['admin_reserved_set'] = 'Set reserved names';
$txt['admin_reserved_line'] = 'Satu kata terpakai per baris.';
$txt['admin_basic_settings'] = 'Halaman ini membolehkan Anda untuk mengubah setelan dasar forum Anda. Harap berhati-hati dengan setelan ini, karena dapat mengakibatkan forum tidak berfungsi.';
$txt['admin_maintain'] = 'Hidupkan Mode Pemeliharaan';
$txt['admin_title'] = 'Judul Forum';
$txt['admin_url'] = 'URL Forum';
$txt['cookie_name'] = 'Cookie name';
$txt['admin_webmaster_email'] = 'Webmaster email address';
$txt['boarddir'] = 'ElkArte Directory';
$txt['sourcesdir'] = 'Direktori Sources';
$txt['cachedir'] = 'Direktori Cache';
$txt['admin_news'] = 'Hidupkan Berita';
$txt['admin_guest_post'] = 'Enable guest posting';
$txt['admin_manage_members'] = 'Anggota';
$txt['admin_main'] = 'Utama';
$txt['admin_config'] = 'Konfigurasi';
$txt['admin_version_check'] = 'Detailed version check';
$txt['admin_elkfile'] = 'ElkArte File';
$txt['admin_elkpackage'] = 'ElkArte Package';
$txt['admin_logoff'] = 'End Admin Session';
$txt['admin_maintenance'] = 'Pemeliharaan';
$txt['admin_image_text'] = 'Tampilkan tombol sebagai gambar daripada teks';
$txt['admin_credits'] = 'Penghargaan';
$txt['admin_agreement'] = 'Tampilkan dan perlukan surat perjanjian saat pendaftaran';
$txt['admin_checkbox_agreement'] = 'Show a checkbox for the agreement in registration form instead of a full page';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Standar';
$txt['admin_agreement_select_language'] = 'Bahasa untuk diedit';
$txt['admin_agreement_select_language_change'] = 'Ubah';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Hapus Anggota Terpilih';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Repair All boards and topics';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Please place one news item per box. BBC tags, such as <span>[b]</span>, <span>[i]</span> and <span>[u]</span> are allowed in your news, as well as smileys. Clear a news item\'s text box to remove it.';
$txt['administrators'] = 'Administrator Forum';
$txt['admin_reserved_desc'] = 'Reserved names will keep members from registering certain user names or using these words in their displayed names. Choose the options you wish to use from the bottom before submitting.';
$txt['admin_activation_email'] = 'Kirim email aktivasi ke anggota baru setelah pendaftaran';
$txt['admin_match_whole'] = 'Hanya sama seluruh nama. Jika tidak dicentang, mencari di dalam nama.';
$txt['admin_match_case'] = 'Jenis huruf sama. Jika tidak dicentang, pencarian akan mengabaikan jenis huruf.';
$txt['admin_check_user'] = 'Check user name.';
$txt['admin_check_display'] = 'Periksa nama tampilan.';
$txt['admin_newsletter_send'] = 'You can email anyone from this page. The email addresses of the selected member groups should appear below, but you may remove or add any email addresses you wish. Be sure that each address is separated in this fashion: \'address1; address2\'.';
$txt['admin_fader_delay'] = 'Waktu tunda peredupan antara item pada peredup berita';
$txt['zero_for_no_limit'] = '(0 tanpa batas)';
$txt['zero_to_disable'] = '(0 to disable)';

$txt['admin_backup_fail'] = 'Gagal membuat backup Settings.php - pastikan Settings_bak.php ada dan bisa ditulis.';
$txt['modSettings_info'] = 'Settings for General features, Karma, Signatures, Likes and much more that control how this forum operates.';
$txt['database_server'] = 'Server Database';
$txt['database_user'] = 'Database User';
$txt['database_password'] = 'Kata sandi Database';
$txt['database_name'] = 'Nama Database';
$txt['registration_agreement'] = 'Perjanjian Registrasi';
$txt['registration_agreement_desc'] = 'Perjanjian ini ditampilkan saat pengguna mendaftarkan akun pada forum ini dan harus menerimanya sebelum pengguna bisa melanjutkan registrasi.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Prefiks Tabel Database';
$txt['errors_list'] = 'Daftar kesalahan forum';
$txt['errors_found'] = 'Kesalahan berikut menggagalkan forum Abnda';
$txt['errors_fix'] = 'Anda ingin mencoba membetulkan kesalahan ini?';
$txt['errors_do_recount'] = 'All errors have been fixed and a salvage area has been created. Please click the button below to recount some key statistics.';
$txt['errors_recount_now'] = 'Hitung ulang Statistik';
$txt['errors_fixing'] = 'Pembetulan kesalahan forum';
$txt['errors_fixed'] = 'All errors fixed. Please check on any categories, boards, or topics created to decide what to do with them.';
$txt['attachments_avatars'] = 'Lampiran dan Avatar';
$txt['attachments_desc'] = 'Dari sini Anda dapat mengatur file yang dilampirkan pada sistem Anda. Anda dapat menghapus lampiran berdasarkan ukuran dan tanggal dari sistem Anda. Statistik pada lampiran juga ditampilkan di bawah ini.';
$txt['attachment_stats'] = 'File attachment statistics';
$txt['attachment_integrity_check'] = 'Attachment integrity check';
$txt['attachment_integrity_check_desc'] = 'Fungsi ini akan memeriksa integritas dan ukuran lampiran serta nama file yang terdaftar dalam database, jika perlu juga akan membetulkan kesalahan bila ditemukan.';
$txt['attachment_check_now'] = 'Lakukan pemeriksaan sekarang';
$txt['attachment_pruning'] = 'Penghapusan Lampiran';
$txt['attachment_pruning_message'] = 'Pesan yang ditambahkan pada tulisan';
$txt['attachment_pruning_warning'] = 'Anda yakin ingin menghapus lampiran ini?\\nIni tidak bisa dibatalkan!';

$txt['attachment_total'] = 'Total attachments';
$txt['attachmentdir_size'] = 'Total size of all attachment directories';
$txt['attachmentdir_size_current'] = 'Total size of current attachment directory';
$txt['attachmentdir_files_current'] = 'Total files in current attachment directory';
$txt['attachment_space'] = 'Total space available';
$txt['attachment_files'] = 'Total files remaining';

$txt['attachment_options'] = 'Opsi Lampiran File';
$txt['attachment_log'] = 'Log Lampiran';
$txt['attachment_remove_old'] = 'Remove attachments older than %1$s days';
$txt['attachment_remove_size'] = 'Remove attachments larger than %1$s KiB';
$txt['attachment_name'] = 'Attachment name';
$txt['attachment_file_size'] = 'Ukuran File';
$txt['attachmentdir_size_not_set'] = 'Ukuran maksimum direktori tidak disetel saat ini';
$txt['attachmentdir_files_not_set'] = 'No directory file limit is currently set';
$txt['attachment_delete_admin'] = '[lampiran dihapus oleh admin]';
$txt['live'] = 'Latest Software Updates';
$txt['remove_all'] = 'Clear Log';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(lebih rinci)';

$txt['lfyi'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['manage_calendar'] = 'Kalender';
$txt['manage_search'] = 'Pencarian';
$txt['viewmembers_online'] = 'Terakhir Online';

$txt['smileys_manage'] = 'Smiley dan Ikon Pesan';
$txt['smileys_manage_info'] = 'Install new smiley sets, add smileys to existing sets or manage your message icons.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Install, download and upload Modification packages; check File Permissions and FTP settings.';
$txt['theme_admin'] = 'Theme Management';
$txt['theme_admin_info'] = 'Install new themes, select themes that are available for your users and set or reset theme options.';
$txt['registration_center'] = 'Registrasi';
$txt['member_center_info'] = 'View the member list, search for members, or manage account approvals and activations.';
$txt['viewmembers_online'] = 'Terakhir Online';

$txt['display_name'] = 'Nama tampilan';
$txt['email_address'] = 'Alamat Email';
$txt['ip_address'] = 'Alamat IP';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'tidak dikenal';
$txt['security_wrong'] = 'Administration login attempt!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Kirim dalam format HTML.  (dengan ini Anda dapat menaruh normal HTML dalam email.)';
$txt['email_parsed_html'] = 'Tambah &lt;br /&gt;s dan &amp;nbsp;s ke pesan ini.';
$txt['email_variables'] = 'In this message you can use a few &quot;variables&quot;.<a href="{help_emailmembers}" class="help"> Click here for more information</a>.';
$txt['email_force'] = 'Kirim ini ke anggota meskipun mereka memilih untuk tidak menerima pengumuman.';
$txt['email_as_pms'] = 'Kirim ini ke grup menggunakan pesan pribadi.';
$txt['email_continue'] = 'Lanjutkan';
$txt['email_done'] = 'selesai.';
$txt['email_members_succeeded'] = 'You have successfully sent your newsletter!';

$txt['ban_title'] = 'Daftar pengucilan';
$txt['ban_ip'] = 'Pengucilan IP: (misal 192.168.12.213 or 128.0.*.*) - satu entri per baris';
$txt['ban_email'] = 'Pengucilan email: (misal badguy@somewhere.com) - satu entri per baris';
$txt['ban_username'] = 'Pengucilan nama pengguna: (misal l33tuser) - satu entri per baris';

$txt['ban_errors_detected'] = 'The following error or errors occurred while saving or editing the ban or the trigger';
$txt['ban_description'] = 'Here you can ban troublesome people either by IP, hostname, user name, or email.';
$txt['ban_add_new'] = 'Add new ban';
$txt['ban_banned_entity'] = 'Entitas dikucilkan';
$txt['ban_on_ip'] = 'Kucilkan pada IP (misal 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Kucilkan pada Hostname (misal *.mil)';
$txt['ban_on_email'] = 'Kucilkan pada Alamat Email (misal *@badsite.com)';
$txt['ban_on_username'] = 'Ban on User Name';
$txt['ban_notes'] = 'Catatan';
$txt['ban_restriction'] = 'Pembatasan';
$txt['ban_full_ban'] = 'Pengucilan penuh';
$txt['ban_partial_ban'] = 'Pengucilan sebagian';
$txt['ban_cannot_post'] = 'Tidak bisa menulis';
$txt['ban_cannot_register'] = 'Tidak bisa mendaftar';
$txt['ban_cannot_login'] = 'Tidak bisa masuk';
$txt['ban_add'] = 'Tambah';
$txt['ban_edit_list'] = 'Daftar pengucilan';
$txt['ban_type'] = 'Tipe Pengucilan';
$txt['ban_days'] = 'hari';
$txt['ban_will_expire_within'] = 'Pengucilan akan berakhir setelah';
$txt['ban_added'] = 'Ditambahkan';
$txt['ban_expires'] = 'Berakhir';
$txt['ban_hits'] = 'Kunjungan';
$txt['ban_actions'] = 'Aksi';
$txt['ban_expiration'] = 'Masa berlaku';
$txt['ban_reason_desc'] = 'Alasan untuk pengucilan, untuk ditampilkan ke anggota yang dikucilkan.';
$txt['ban_notes_desc'] = 'Catatan bahwa ini dapat membantu anggota staf lain.';
$txt['ban_remove_selected'] = 'Hapus yang dipilih';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Anda yakin ingin menghapus pengucilan yang dipilih?';
$txt['ban_modify'] = 'Ubah';
$txt['ban_name'] = 'Nama pengucilan';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Edit pengucilan';
$txt['ban_add_notes'] = '<strong>Catatan</strong>: setelah membuat pengucilan di atas, Anda bisa menambah entri tambahan yang memicu pengucilan, seperti alamat IP, hostname dan alamat email.';
$txt['ban_expired'] = 'Berakhir / dimatikan';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Tidak ada batasan dipilih.';

$txt['ban_triggers'] = 'Pemicu';
$txt['ban_add_trigger'] = 'Tambah pemicu pengucilan';
$txt['ban_add_trigger_submit'] = 'Tambah';
$txt['ban_edit_trigger'] = 'Ubah';
$txt['ban_edit_trigger_title'] = 'Edit pemicu pengucilan';
$txt['ban_edit_trigger_submit'] = 'Ubah';
$txt['ban_remove_selected_triggers'] = 'Hapus pemicu pengucilan terpilih';
$txt['ban_no_entries'] = 'Tidak ada efek pengucilan untuk saat ini.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Anda yakin ingin menghapus pemicu pengucilan yang dipilih?';
$txt['ban_trigger_browse'] = 'Lihat pemicu pengucilan';
$txt['ban_trigger_browse_description'] = 'This screen shows all banned entities grouped by IP address, hostname, email address and user name.';

$txt['ban_log'] = 'Log pengucilan';
$txt['ban_log_description'] = 'Log pengucilan menampilkan semua percobaan untuk memasuki forum hanya oleh pengguna yang dikucilkan (\'pengucilan penuh\' dan \'tidak bisa mendaftar\').';
$txt['ban_log_no_entries'] = 'Tidak ada entri log pengucilan untuk saat ini.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'Alamat email';
$txt['ban_log_member'] = 'Anggota';
$txt['ban_log_date'] = 'Tanggal';
$txt['ban_log_remove_all'] = 'Clear Log';
$txt['ban_log_remove_all_confirm'] = 'Anda yakin ingin menghapus semua entri log pengucilan?';
$txt['ban_log_remove_selected'] = 'Hapus yang dipilih';
$txt['ban_log_remove_selected_confirm'] = 'Anda yakin ingin menghapus semua entitas log pengucilan yang dipilih?';
$txt['ban_no_triggers'] = 'Tidak ada pemicu pengucilan untuk saat ini.';

$txt['settings_not_writable'] = 'Setelan ini tidak bisa diubah karena Settings.php hanya baca.';

$txt['maintain_title'] = 'Pemeliharaan Forum';
$txt['maintain_info'] = 'Basic forum backups, Database error checking, Clearing the Cache, Integration Hooks and more.';
$txt['maintain_sub_database'] = 'Database';
$txt['maintain_sub_routine'] = 'Rutin';
$txt['maintain_sub_members'] = 'Anggota';
$txt['maintain_sub_topics'] = 'Topik';
$txt['maintain_sub_attachments'] = 'Lampiran';
$txt['maintain_done'] = 'Pemeliharaan Selesai.';
$txt['maintain_fail'] = 'The maintenance task \'%1$s\' failed.';
$txt['maintain_no_errors'] = 'Congratulations, no errors were found.  Thanks for checking.';

$txt['maintain_tasks'] = 'Tugas Terjadwal';
$txt['maintain_tasks_desc'] = 'Manage all the scheduled tasks.';

$txt['scheduled_log'] = 'Log Tugas';
$txt['scheduled_log_desc'] = 'Lists logs of the tasks that were run.';
$txt['admin_log'] = 'Log Administrasi';
$txt['admin_log_desc'] = 'Daftar tugas administratif yang sudah dilakukan oleh admin forum Anda.';
$txt['moderation_log'] = 'Log Moderasi';
$txt['moderation_log_desc'] = 'Daftar aktivitas moderasi yang sudah dilakukan oleh para moderator forum Anda.';
$txt['badbehavior_log'] = 'Bad Behavior Log';
$txt['badbehavior_log_desc'] = 'Lists requests that were blocked or marked suspicious by bad behavior.  If verbose logging is on all HTTP requests are listed.';
$txt['spider_log_desc'] = 'Ulasan entri terkait aktivitas spider mesin pencari pada forum Anda.';
$txt['pruning_log_desc'] = 'Gunakan piranti ini untuk menghapus entri lama pada berbagai log.';

$txt['mailqueue_title'] = 'Surat';

$txt['db_error_send'] = 'Kirim email saat kesalahan koneksi MySQL';
$txt['db_persist'] = 'Gunakan koneksi persisten';
$txt['ssi_db_user'] = 'Database user name to use in SSI mode';
$txt['ssi_db_passwd'] = 'Kata sandi Database untuk digunakan dalam mode SSI';

$txt['default_language'] = 'Default forum language';

$txt['maintenance_subject'] = 'Subyek untuk ditampilkan';
$txt['maintenance_message'] = 'Pesan untuk ditampilkan';

$txt['errlog_desc'] = 'Jejak log kesalahan setiap kesalah ditemukan pada forum Anda.  Untuk menghapus setiap kesalahan dari database, tandai kotak centang, dan klik tombol %1$s di bawah halaman.';
$txt['errlog_no_entries'] = 'Tidak ada entri log kesalahan untuk saat ini.';

$txt['theme_settings'] = 'Setelan Tema';
$txt['theme_edit_settings'] = 'Edit this theme\'s settings';
$txt['theme_current_settings'] = 'Tema Saat Ini';

$txt['dvc_your'] = 'Versi Anda';
$txt['dvc_current'] = 'Versi Saat Ini';
$txt['dvc_sources'] = 'Sumber';
$txt['dvc_admin'] = 'Admin';
$txt['dvc_controllers'] = 'Controllers';
$txt['dvc_database'] = 'Database';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Template Standar';
$txt['dvc_templates'] = 'Template Saat Ini';
$txt['dvc_languages'] = 'File Bahasa';

$txt['smileys_default_set_for_theme'] = 'Select default smiley set for this theme:';
$txt['smileys_no_default'] = 'Use default smiley set';

$txt['censor_test'] = 'Uji Kata Disensor';
$txt['censor_test_save'] = 'Uji';
$txt['censor_case'] = 'Ignore case when censoring.';
$txt['censor_whole_words'] = 'Check only whole words.';
$txt['censor_allow'] = 'Allow users to turn off word censoring.';

$txt['admin_confirm_password'] = '(confirm password)';
$txt['admin_incorrect_password'] = 'Kata sandi tidak benar';

$txt['date_format'] = '(YYYY-MM-DD)';
$txt['undefined_gender'] = 'Tidak ditetapkan';
$txt['age'] = 'Usia pengguna';
$txt['activation_status'] = 'Status Aktivasi';
$txt['activated'] = 'Diaktifkan';
$txt['not_activated'] = 'Tidak diaktifkan';
$txt['is_banned'] = 'Banned';
$txt['primary'] = 'Utama';
$txt['additional'] = 'Tambahan';
$txt['wild_cards_allowed'] = 'karakter liar * dan ? dibolehkan';
$txt['member_part_of_these_membergroups'] = 'Member is part of these member groups';
$txt['membergroups'] = 'Member groups';
$txt['confirm_delete_members'] = 'Anda yakin ingin menghapus anggota yang dipilih?';

$txt['support_credits_title'] = 'Support &amp; Credits';
$txt['support_credits_info'] = 'Support links for most common issues, the relevant forum version information you will be asked for when you request help and a list of contributors to the ElkArte project.';
$txt['support_title'] = 'Informasi Dukungan';
$txt['support_versions_current'] = 'Current version';
$txt['support_versions_forum'] = 'This version';
$txt['support_versions_db'] = 'Versi %1$s';
$txt['support_versions_server'] = 'Versi Server';
$txt['support_versions_gd'] = 'Versi GD';
$txt['support_versions_imagick'] = 'Imagick version';
$txt['support_versions'] = 'Informasi Versi';
$txt['support_resources'] = 'Sumber Daya Dukungan';
$txt['support_resources_p1'] = 'Our <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> provides the main documentation for ElkArte. The ElkArte Online Manual has many documents to help answer support questions and explain <a href="%2$s" target="_blank" class="new_win">Features</a>, <a href="%3$s" target="_blank" class="new_win">Settings</a>, <a href="%4$s" target="_blank" class="new_win">Themes</a>, <a href="%5$s" target="_blank" class="new_win">Packages</a>, etc. The Online Manual documents each area of ElkArte thoroughly and should answer most questions quickly.';
$txt['support_resources_p2'] = 'If you can\'t find the answers to your questions in the Documentation Wiki, you may want to search our <a href="%1$s" target="_blank" class="new_win">Support Community</a> or ask for assistance in our support boards. The ElkArte Support Community can be used for <a href="%2$s" target="_blank" class="new_win">support</a>, <a href="%3$s" target="_blank" class="new_win">customization</a>, and many other things such as discussing ElkArte, finding a host, and discussing administrative issues with other forum administrators.';

$txt['latest_updates'] = 'Latest noteworthy updates';
$txt['new_in_1_0_2'] = 'The most significant change in ElkArte 1.0.2 is avatar permission management. Currently each method of setting an avatar is permission-based, requiring the enabling/disabling of each method for each group. With 1.0.2 avatars are simply enabled/disabled by user group, this allows the enabled groups to add an avatar (by all available methods).<br />
The only permission available is a general one to allow members to change or not their avatars. Additionally there is only one setting for maximum width and height of avatars, these values apply to all avatar methods.<br /><br />
Due to the nature of the changes it was not impossible to migrate existing settings to the new format, for that reason you are encouraged to visit the <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Settings</a> page and set the options you prefer.';

$txt['edit_permissions_info'] = 'Use permission settings to manage global and specific board features and what actions that guest, members and moderators can do.';
$txt['membergroups_members'] = 'Anggota Reguler';
$txt['membergroups_guests'] = 'Pengunjung';
$txt['membergroups_add_group'] = 'Tambah grup';
$txt['membergroups_permissions'] = 'Ijin';

$txt['permitgroups_restrict'] = 'Pembatasan';
$txt['permitgroups_standard'] = 'Standar';
$txt['permitgroups_moderator'] = 'Moderator';
$txt['permitgroups_maintenance'] = 'Pemeliharaan';

$txt['confirm_delete_attachments'] = 'Anda yakin ingin menghapus lampiran yang dipilih?';
$txt['attachment_manager_browse_files'] = 'Lihat file';
$txt['attachment_manager_repair'] = 'Pelihara';
$txt['attachment_manager_avatars'] = 'Avatar';
$txt['attachment_manager_attachments'] = 'Lampiran';
$txt['attachment_manager_thumbs'] = 'Thumbnail';
$txt['attachment_manager_last_active'] = 'Terakhir Aktif';
$txt['attachment_manager_member'] = 'Anggota';
$txt['attachment_manager_avatars_older'] = 'Remove avatars from members not active for more than %1$s days';
$txt['attachment_manager_total_avatars'] = 'Total avatars';

$txt['attachment_manager_avatars_no_entries'] = 'Tidak ada avatar untuk saat ini.';
$txt['attachment_manager_attachments_no_entries'] = 'Tidak ada lampiran untuk saat ini.';
$txt['attachment_manager_thumbs_no_entries'] = 'Tidak ada thumbnail untuk saat ini.';

$txt['attachment_manager_settings'] = 'Setelan Lampiran';
$txt['attachment_manager_avatar_settings'] = 'Setelan Avatar';
$txt['attachment_manager_browse'] = 'Lihat file';
$txt['attachment_manager_maintenance'] = 'Pemeliharaan file';
$txt['attachmentEnable'] = 'Mode lampiran';
$txt['attachmentEnable_deactivate'] = 'Matikan lampiran';
$txt['attachmentEnable_enable_all'] = 'Hidupkan semua lampiran';
$txt['attachmentEnable_disable_new'] = 'Matikan lampiran baru';
$txt['attachmentCheckExtensions'] = 'Periksa ekstensi lampiran';
$txt['attachmentExtensions'] = 'Ijinkan ekstensi lampiran';
$txt['attachmentRecodeLineEndings'] = 'Akhiran baris pengkodean ulang dalam lampiran tekstual';
$txt['attachmentShowImages'] = 'Tampilkan lampiran gambar sebagai gambar di bawah tulisan';
$txt['attachmentUploadDir'] = 'Direktori lampiran';
$txt['attachmentUploadDir_multiple_configure'] = 'Manage attachment directories';
$txt['attachmentDirSizeLimit'] = 'Max attachment directory space';
$txt['attachmentPostLimit'] = 'Max attachment size per post';
$txt['attachmentSizeLimit'] = 'Max size per attachment';
$txt['attachmentNumPerPostLimit'] = 'Max number of attachments per post';
$txt['attachment_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Image re-encoding is not possible.';
$txt['attachment_postsize_warning'] = 'The current php.ini setting \'post_max_size\' may not support this.';
$txt['attachment_filesize_warning'] = 'The current php.ini setting \'upload_max_filesize\' may not support this.';
$txt['attachment_image_reencode'] = 'Re-encode lampiran gambar yang potensial berbahaya';
$txt['attachment_image_reencode_note'] = '(requires GD module or ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Pemeriksaan keamanan yang luas dapat menghasilkan sejumlah besar lampiran ditolak.';
$txt['attachment_image_paranoid'] = 'Lakukan pemeriksaan keamanan menyeluruh pada lampiran gambar yang diupload';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'Ukur ulang gambar saat ditampilkan di bawah tulisan';
$txt['attachment_thumb_png'] = 'Simpan thumbnail sebagai PNG';
$txt['attachment_thumb_memory'] = 'Adaptive thumbnail memory';
$txt['attachment_thumb_memory_note2'] = 'If the system can not get the memory no thumbnail will be created.';
$txt['attachment_thumb_memory_note1'] = 'Leave this unchecked to always attempt to create a thumbnail';
$txt['attachmentThumbWidth'] = 'Maksimum panjang thumbnail';
$txt['attachmentThumbHeight'] = 'Maksimum tinggi thumbnail';
$txt['attachment_thumbnail_settings'] = 'Thumbnail Settings';
$txt['attachment_security_settings'] = 'Attachment security settings';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Tidak Ada';
$txt['attach_dir_not_writable'] = 'Tidak bisa Ditulis';
$txt['attach_dir_files_missing'] = 'Files Missing (<a href="{repair_url}">Repair</a>)';
$txt['attach_dir_unused'] = 'Tidak terpakai';
$txt['attach_dir_empty'] = 'Empty';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Base directory';

$txt['attach_dir_desc'] = 'Create new directories or change the current directory below. Directories can be renamed as long as they do not contain a sub-directory. If the new directory is to be created within the forum directory structure, you\'ll just need to type the directory name. To remove a directory, blank the path input field. Directories can not be deleted if they contain either files or sub-directories (shown in brackets next to the file count).';
$txt['attach_dir_base_desc'] = 'You may use the area below to change the current base directory or create a new one. New base directories are also added to the Attachment Directory list. You may also designate an existing directory to be a base directory.';
$txt['attach_dir_save_problem'] = 'Oops, there seems to be a problem.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory. Please do so using a FTP client or your site file manager.';
$txt['attachments_no_write'] = 'This directory has been created but is not writable. Please attempt to do so using a FTP client or your site file manager.';
$txt['attach_dir_reserved'] = 'Unable to add. This directory is a system directory and cannot be used for attachments.';
$txt['attach_dir_duplicate_msg'] = 'Unable to add. This directory already exists.';
$txt['attach_dir_exists_msg'] = 'Unable to move. A directory already exists at that path.';
$txt['attach_dir_base_dupe_msg'] = 'Unable to add. This base directory has already been created.';
$txt['attach_dir_base_no_create'] = 'Unable to create. Please verify the path input or create this directory using an FTP client or site file manager and re-try.';
$txt['attach_dir_no_rename'] = 'Unable to move or rename. Please verify that the path is correct or that this directory does not contain any sub-directories.';
$txt['attach_dir_no_delete'] = 'Is not empty and can not be deleted. Please do so using a FTP client or site file manager.';
$txt['attach_dir_no_remove'] = 'Still contains files or is a base directory and can not be deleted.';
$txt['attach_dir_is_current'] = 'Unable to remove while it is selected as the current directory.';
$txt['attach_dir_is_current_bd'] = 'Unable to remove while it is selected as the current base directory.';
$txt['attach_last_dir'] = 'Last active attachment directory';
$txt['attach_current_dir'] = 'Current attachment directory';
$txt['attach_current'] = 'Current';
$txt['attach_path_manage'] = 'Manage attachment paths';
$txt['attach_directories'] = 'Attachment Directories';
$txt['attach_paths'] = 'Attachment directory paths';
$txt['attach_path'] = 'Path';
$txt['attach_current_size'] = 'Size (KiB)';
$txt['attach_num_files'] = 'File';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Tambah Path';
$txt['attach_path_current_bad'] = 'Path lampiran saat ini tidak benar.';
$txt['attachmentDirFileLimit'] = 'Maximum number of files per directory';

$txt['attach_base_paths'] = 'Base directory paths';
$txt['attach_num_dirs'] = 'Directories';
$txt['max_image_width'] = 'Max display width of posted or attached images';
$txt['max_image_height'] = 'Max display height of posted or attached images';

$txt['automanage_attachments'] = 'Choose the method for the management of the attachment directories';
$txt['attachments_normal'] = '(Manual) ElkArte default behaviour';
$txt['attachments_auto_years'] = '(Auto) Subdivide by years';
$txt['attachments_auto_months'] = '(Auto) Subdivide by years and months';
$txt['attachments_auto_days'] = '(Auto) Subdivide by years, months and days';
$txt['attachments_auto_16'] = '(Auto) 16 random directories';
$txt['attachments_auto_16x16'] = '(Auto) 16 random directories with 16 random sub-directories';
$txt['attachments_auto_space'] = '(Auto) When either directory space limit is reached';

$txt['use_subdirectories_for_attachments'] = 'Create new directories within a base directory';
$txt['use_subdirectories_for_attachments_note'] = 'Otherwise any new directories will be created within the forum\'s main directory.';
$txt['basedirectory_for_attachments'] = 'Set a base directory for attachments';
$txt['basedirectory_for_attachments_current'] = 'Current base directory';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Please note that the directory is wrong. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">There seems to be a problem with this directory. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';

$txt['attachment_transfer'] = 'Transfer Attachments';
$txt['attachment_transfer_desc'] = 'Transfer files between directories.';
$txt['attachment_transfer_select'] = 'Select directory';
$txt['attachment_transfer_now'] = 'Transfer';
$txt['attachment_transfer_from'] = 'Transfer files from';
$txt['attachment_transfer_auto'] = 'Move them automatically by space or file count';
$txt['attachment_transfer_auto_select'] = 'Select base directory';
$txt['attachment_transfer_to'] = 'Or move them to a specific directory.';
$txt['attachment_transfer_empty'] = 'Move all files from the source directory.';
$txt['attachment_transfer_no_base'] = 'No base directories available.';
$txt['attachment_transfer_forum_root'] = 'Forum root directory.';
$txt['attachment_transfer_no_room'] = 'Directory size or file count limit reached.';
$txt['attachment_transfer_no_find'] = 'No files were found to transfer.';
$txt['attachments_transfered'] = '%1$d files were transferred to %2$s';
$txt['attachments_not_transfered'] = '%1$d files were not transferred.';
$txt['attachment_transfer_no_dir'] = 'Either the source directory or one of the target options were not selected.';
$txt['attachment_transfer_same_dir'] = 'You cannot select the same directory as both the source and target.';
$txt['attachment_transfer_progress'] = 'Please wait. Transfer in progress.';

$txt['avatar_settings'] = 'General avatar settings';
$txt['avatar_default'] = 'Enable a default avatar for all users without their own avatar';
$txt['avatar_directory'] = 'Direktori avatar';
$txt['avatar_url'] = 'URL avatar';
$txt['avatar_max_width'] = 'Maximum width of avatars in pixels (px)';
$txt['avatar_max_height'] = 'Maximum height of avatars in pixels (px)';
$txt['avatar_action_too_large'] = 'Jika avatar terlalu besar...';
$txt['option_refuse'] = 'Tolak';
$txt['option_resize'] = 'Let the CSS resize it';
$txt['option_download_and_resize'] = 'Download and resize it (requires GD module or ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Enable use of gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'Gunakan PNG untuk mengukur ulang avatar';
$txt['avatar_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Some avatar features are disabled.';
$txt['avatar_external'] = 'Avatar eksternal';
$txt['avatar_external_enabled'] = 'Enable use of external (remote/URL) avatars';
$txt['avatar_upload'] = 'Avatar dapat di-upload';
$txt['avatar_resize_options'] = 'Server storage options';
$txt['avatar_upload_enabled'] = 'Enable the upload of avatars';
$txt['avatar_server_stored'] = 'Avatar tersimpan di server';
$txt['avatar_stored_enabled'] = 'Enable the selection of server stored avatars';
$txt['profile_set_avatar'] = 'Member groups allowed to select an avatar';
$txt['avatar_select_permission'] = 'Pilih perijinan untuk setiap grup';
$txt['avatar_download_external'] = 'Download avatar pada URL yang diberikan';
$txt['custom_avatar_enabled'] = 'Upload avatar ke...';
$txt['option_attachment_dir'] = 'Direktori lampiran';
$txt['option_specified_dir'] = 'Direktori Spesifik...';
$txt['custom_avatar_dir'] = 'Direktori Upload';
$txt['custom_avatar_dir_desc'] = 'This should be a valid and writable directory, different than the server-stored directory.';
$txt['custom_avatar_url'] = 'Upload URL';
$txt['custom_avatar_check_empty'] = 'Direktori kustom avatar yang Anda tetapkan mungkin kosong atau tidak benar. Pastikan setelan ini benar.';
$txt['avatar_reencode'] = 'encoding ulang avatar yang potensial berbahaya';
$txt['avatar_reencode_note'] = '(Membutuhkan modul GD)';
$txt['avatar_paranoid_warning'] = 'Pemeriksaan keamanan yang luas dapat menghasilkan sejumlah besar avatar yang ditolak';
$txt['avatar_paranoid'] = 'Lakukan pemeriksaan keamanan menyeluruh pada  avatar yang diupload';

$txt['repair_attachments'] = 'Pelihara Lampiran';
$txt['repair_attachments_complete'] = 'Pemeliharaan Selesai';
$txt['repair_attachments_complete_desc'] = 'Semua kesalahan yang dipilih sekarang sudah dibetulkan';
$txt['repair_attachments_no_errors'] = 'No errors were found';
$txt['repair_attachments_error_desc'] = 'Kesalahan berikut ditemukan selama pemeliharaan. Centang kotak di dekat kesalahan yang ingin Anda betulkan dan tekan Lanjutkan.';
$txt['repair_attachments_continue'] = 'Lanjutkan';
$txt['repair_attachments_cancel'] = 'Batal';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d thumbnail kehilangan lampiran leluhurnya';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d leluhur ditandai memiliki thumbnails padahal tidak';
$txt['attach_repair_file_missing_on_disk'] = '%1$d lampiran/avatar memiliki entri tapi tidak ada lagi pada disk';
$txt['attach_repair_file_wrong_size'] = '%1$d lampiran/avatar dilaporkan sebagai ukuran file yang salah';
$txt['attach_repair_file_size_of_zero'] = '%1$d lampiran/avatar memiliki ukuran nol pada disk. (Ini akan dihapus)';
$txt['attach_repair_attachment_no_msg'] = '%1$d lampiran tidak lagi memiliki pesan yang terkait dengannya';
$txt['attach_repair_avatar_no_member'] = '%1$d avatar tidak lagi memiliki anggota yang terkait dengannya';
$txt['attach_repair_wrong_folder'] = '%1$d attachments are in the wrong directory';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d files do not have a corresponding entry in the database. (These will be deleted)';

$txt['news_title'] = 'Berita dan Surat berkala';
$txt['news_settings_desc'] = 'Di sini Anda bisa mengubah setelan dan perijinan terkait dengan berita dan surat berkala.';
$txt['news_mailing_desc'] = 'From this menu you can send messages to all users who\'ve registered and entered their email addresses. You may edit the distribution list, or send messages to all. Useful for important update/news information.';
$txt['news_error_no_news'] = 'Nothing to preview';
$txt['groups_edit_news'] = 'Grup diijinkan untuk mengedit item berita';
$txt['groups_send_mail'] = 'Grup diijinkan untuk mengirimkan surat berkala forum';
$txt['xmlnews_enable'] = 'Hidupkan berita XML/RSS';
$txt['xmlnews_maxlen'] = 'Maximum message length';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Number of items in a news feed';
$txt['xmlnews_maxlen_note'] = '(0 to disable, bad idea.)';
$txt['editnews_clickadd'] = 'Add another item';
$txt['editnews_remove_selected'] = 'Hapus yang dipilih';
$txt['editnews_remove_confirm'] = 'Anda yakin ingin menghapus item berita yang dipilih?';
$txt['censor_clickadd'] = 'Add another word';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Log';
$txt['generate_reports'] = 'Laporan';

$txt['update_available'] = 'Update Available';
$txt['update_message'] = 'You\'re using an outdated version of ElkArte, which contains some bugs which have since been fixed.
	It is recommended that you <a href="#" id="update-link">update your forum</a> to the latest version as soon as possible. It only takes a minute!';

$txt['manageposts'] = 'Tulisan dan Topik';
$txt['manageposts_title'] = 'Mengatur Tulisan dan Topik';
$txt['manageposts_description'] = 'Di sini Anda dapat mengatur semua setelan terkait dengan topik dan tuilisan.';

$txt['manageposts_seconds'] = 'detik';
$txt['manageposts_minutes'] = 'menit';
$txt['manageposts_characters'] = 'karakter';
$txt['manageposts_days'] = 'hari';
$txt['manageposts_posts'] = 'tulisan';
$txt['manageposts_topics'] = 'topik';

$txt['pollMode'] = 'Hidupkan polling';

$txt['manageposts_settings'] = 'Setelan Tulisan';
$txt['manageposts_settings_description'] = 'Di sini Anda dapat menyetel apapun terkait dengan tulisan dan penulisan.';

$txt['manageposts_bbc_settings'] = 'Kode Buletin Board';
$txt['manageposts_bbc_settings_description'] = 'Kode buletin board dapat dipakai untuk menambah tanda ke pesan forum. Sebagai contoh, untuk menerangi kata \'house\' Anda dapat mengetik [b]house[/b]. Semua tag kode buletin board dikelilingi kurung kotak (\'[\' dan \']\').';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code settings';

$txt['manageposts_topic_settings'] = 'Setelan Topik';
$txt['manageposts_topic_settings_description'] = 'Di sini Anda dapat menyetel semua setelan terkait topik.';

$txt['managedrafts_settings'] = 'Draft Settings';
$txt['managedrafts_settings_description'] = 'Here you can set all settings involving drafts.';
$txt['manage_drafts'] = 'Drafts';

$txt['mail_center'] = 'Maillist Center';
$txt['mm_emailerror'] = 'Failed Emails';
$txt['mm_emailfilters'] = 'Filters';
$txt['mm_emailparsers'] = 'Parsers';
$txt['mm_emailtemplates'] = 'Templates';
$txt['mm_emailsettings'] = 'Setelan';

$txt['removeNestedQuotes'] = 'Hapus kutipan berulang saat mengutip';
$txt['enableSpellChecking'] = 'Hidupkan pemeriksaan ejaan';
$txt['enableSpellChecking_warning'] = 'this does not work on all servers.';
$txt['enableSpellChecking_error'] = 'this does not work on your server.';
$txt['enableVideoEmbeding'] = 'Enable auto-embedding of video links.';
$txt['enableCodePrettify'] = 'Enable prettifying of code tags';
$txt['max_messageLength'] = 'Maksimum ukuran tulisan diijinkan';
$txt['max_messageLength_zero'] = '0 tanpa batas.';
$txt['convert_to_mediumtext'] = 'Your database is not setup to accept messages longer than 65535 characters. Please use the <a href="%1$s">database maintenance</a> page to convert the database and then come back to increase the maximum allowed post size.';
$txt['topicSummaryPosts'] = 'Tulisan untuk ditampilkan pada ringkasan topik';
$txt['spamWaitTime'] = 'Waktu diperlukan antara tulisan dari IP yang sama';
$txt['edit_wait_time'] = 'Adab waktu tunggu mengedit';
$txt['edit_disable_time'] = 'Maksimum waktu setelah penulisan untuk membolehkan diedit';
$txt['edit_disable_time_zero'] = '0 untuk mematikan';
$txt['preview_characters'] = 'Maximum length of last/first post preview';
$txt['preview_characters_units'] = 'karakter';
$txt['preview_characters_zero'] = '0 to show the entire message';
$txt['message_index_preview'] = 'Show post previews on the message index';
$txt['message_index_preview_off'] = 'Do not show the previews';
$txt['message_index_preview_first'] = 'Show the text of the first post';
$txt['message_index_preview_last'] = 'Show the text of the last post';

$txt['enableBBC'] = 'Hidupkan kode buletin board (BBC)';
$txt['enablePostHTML'] = 'Hidupkan HTML <em>dasar</em> dalam tulisan';
$txt['autoLinkUrls'] = 'Link otomatis URL yang ditulis';
$txt['disabledBBC'] = 'Hidupkan tag BBC';
$txt['bbcTagsToUse'] = 'Hidupkan tag BBC';
$txt['bbcTagsToUse_select'] = 'Pilih tag yang diijinkan untuk dipakai';
$txt['bbcTagsToUse_select_all'] = 'Pilih semua tag';

$txt['enableParticipation'] = 'Hidupkan ikon partisipasi';
$txt['enableFollowup'] = 'Enable followups';
$txt['enable_unwatch'] = 'Enable unwatching of topics';
$txt['oldTopicDays'] = 'Waktu sebelum topik diperingatkan sebagai jawaban lama';
$txt['oldTopicDays_zero'] = '0 untuk mematikan';
$txt['defaultMaxTopics'] = 'Jumlah topik per halaman dalam indeks pesan';
$txt['defaultMaxMessages'] = 'Jumlah tulisan per halaman dalam halaman topik';
$txt['disable_print_topic'] = 'Disable print topic feature';
$txt['hotTopicPosts'] = 'Jumlah tulisan untuk topik hangat';
$txt['hotTopicVeryPosts'] = 'Jumlah tulisan untuk topik panas';
$txt['useLikesNotViews'] = 'Use number of likes in place of posts to define hot topics';
$txt['enableAllMessages'] = 'Maks ukuran topik untuk menampilkan &quot;Semua&quot; tulisan';
$txt['enableAllMessages_zero'] = '0 tidak pernah menampilkan &quot;Semua&quot;';
$txt['disableCustomPerPage'] = 'Matikan kustomisasi jumlah topik pesan per halaman';
$txt['enablePreviousNext'] = 'Hidupkan link topik sebelumnya/berikutnya';

$txt['not_done_title'] = 'Not done yet';
$txt['not_done_reason'] = 'Guna menghindari kelebihan server Anda, proses sudah diistirahatkan untuk sementara.  Ia akan melanjutkan secara otomatis dalam beberapa detik.  Jika tidak, silahkan klik Lanjutkan di bawah ini.';
$txt['not_done_continue'] = 'Lanjutkan';

$txt['general_settings'] = 'Umum';
$txt['database_paths_settings'] = 'Database dan Path';
$txt['cookies_sessions_settings'] = 'Cookie dan Sesi';
$txt['caching_settings'] = 'Caching';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Local Settings';
$txt['phpinfo_defaultsettings'] = 'Default Settings';
$txt['phpinfo_itemsettings'] = 'Setelan';

$txt['language_configuration'] = 'Bahasa';
$txt['language_description'] = 'This section allows you to edit languages installed on your forum or download new ones from the ElkArte site. You may also edit language-related settings here.';
$txt['language_edit'] = 'Edit Bahasa';
$txt['language_add'] = 'Tambah Bahasa';
$txt['language_settings'] = 'Setelan';

$txt['advanced'] = 'Lanjutan';
$txt['simple'] = 'Sederhana';

$txt['admin_news_select_recipients'] = 'Silahkan pilih siapa yang harus menerima duplikat surat berkala';
$txt['admin_news_select_group'] = 'Member groups';
$txt['admin_news_select_group_desc'] = 'Pilih grup anggota untuk menerima surat berkala ini.';
$txt['admin_news_select_members'] = 'Anggota';
$txt['admin_news_select_members_desc'] = 'Additional members to receive the newsletter.';
$txt['admin_news_select_excluded_members'] = 'Anggota Dikecualikan';
$txt['admin_news_select_excluded_members_desc'] = 'Members who should not receive the newsletter.';
$txt['admin_news_select_excluded_groups'] = 'Grup Dikecualikan';
$txt['admin_news_select_excluded_groups_desc'] = 'Pilih grup yang secara pasti tidak menerima surat berkala.';
$txt['admin_news_select_email'] = 'Alamat Email';
$txt['admin_news_select_email_desc'] = 'A semi-colon separated list of email addresses which should be sent this newsletter. (i.e. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Override notification settings';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Anda tidak bisa mengirimkan pesan pribadi ke alamat email. Jika Anda melanjutkan semua alamat email yang dimasukan akan diabaikan.\\n\\nAnda yakin ingin melakukan ini?';

$txt['mailqueue_browse'] = 'Lihat Antrian';
$txt['mailqueue_settings'] = 'Setelan';

$txt['admin_search'] = 'Pencarian Cepat';
$txt['admin_search_type_internal'] = 'Tugas/Setelan';
$txt['admin_search_type_member'] = 'Anggota';
$txt['admin_search_type_online'] = 'Manual Online';
$txt['admin_search_go'] = 'Ayo';
$txt['admin_search_results'] = 'Hasil Pencarian';
$txt['admin_search_results_desc'] = 'Hasil pencarian: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Cari lagi';
$txt['admin_search_results_none'] = 'No results found.';

$txt['admin_search_section_sections'] = 'Seksi';
$txt['admin_search_section_settings'] = 'Setelan';

$txt['core_settings_title'] = 'Fitur Inti';
$txt['core_settings_desc'] = 'This page allows you to turn on or off optional features of your forum.';
$txt['mods_cat_features'] = 'Umum';
$txt['mods_cat_security_general'] = 'Umum';
$txt['antispam_title'] = 'Anti-Spam';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Lain-Lain';
$txt['mods_cat_layout'] = 'Tata Letak';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderasi';
$txt['signature_settings_short'] = 'Tanda tangan';
$txt['custom_profile_shorttitle'] = 'Field Profil';
$txt['pruning_title'] = 'Log Penghapusan';

$txt['core_settings_activation_message'] = 'The feature {core_feature} has been activated, click on the title to configure it';
$txt['core_settings_deactivation_message'] = 'The feature {core_feature} has been deactivated';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Ubah Board';
$txt['mboards_new_cat'] = 'Create new category';
$txt['manage_holidays'] = 'Atur Hari Libur';
$txt['calendar_settings'] = 'Setelan Kalender';
$txt['search_weights'] = 'Bobot';
$txt['search_method'] = 'Metode pencarian';
$txt['search_sphinx'] = 'Configure Sphinx';

$txt['smiley_sets'] = 'Set Smiley';
$txt['smileys_add'] = 'Tambah Smiley';
$txt['smileys_edit'] = 'Edit Smiley';
$txt['smileys_set_order'] = 'Set Smiley order';
$txt['icons_edit_message_icons'] = 'Edit message icons';

$txt['membergroups_new_group'] = 'Add Member Group';
$txt['membergroups_edit_groups'] = 'Edit Member Groups';
$txt['permissions_groups'] = 'Perijinan dengan Grup anggota';
$txt['permissions_boards'] = 'Perijinan dengan Board';
$txt['permissions_profiles'] = 'Edit Profil';
$txt['permissions_post_moderation'] = 'Moderasi Tulisan';

$txt['browse_packages'] = 'Lihat Paket';
$txt['download_packages'] = 'Ambil Paket';
$txt['upload_packages'] = 'Upload Package';
$txt['installed_packages'] = 'Paket Terinstalasi';
$txt['package_file_perms'] = 'Perijinan File';
$txt['package_settings'] = 'Setelan';
$txt['package_servers'] = 'Package Servers';
$txt['themeadmin_admin_title'] = 'Atur dan Instalasi';
$txt['themeadmin_list_title'] = 'Setelan Tema';
$txt['themeadmin_reset_title'] = 'Opsi Anggota';
$txt['themeadmin_edit_title'] = 'Ubah Tema';
$txt['admin_browse_register_new'] = 'Register new member';

$txt['search_engines'] = 'Mesin Pencari';
$txt['spider_logs'] = 'Log Spider';
$txt['spider_stats'] = 'Statistik';

$txt['paid_subscriptions'] = 'Subskripsi Berbayar';
$txt['paid_subs_view'] = 'Lihat Subskripsi';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks';
$txt['hooks_field_hook_name'] = 'Hook Name';
$txt['hooks_field_function_name'] = 'Function Name';
$txt['hooks_field_function'] = 'Function';
$txt['hooks_field_included_file'] = 'Included file';
$txt['hooks_field_file_name'] = 'Nama File';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Exists';
$txt['hooks_disabled'] = 'Dimatikan'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Not found';
$txt['hooks_no_hooks'] = 'There are currently no hooks in the system.';
$txt['hooks_disable_legend'] = 'Legenda';
$txt['hooks_disable_legend_exists'] = 'the hook exists and is active';
$txt['hooks_disable_legend_disabled'] = 'the hook exists but has been disabled';
$txt['hooks_disable_legend_missing'] = 'the hook has not been found';
$txt['hooks_reset_filter'] = 'Reset filter';

$txt['board_perms_allow'] = 'Ijinkan';
$txt['board_perms_ignore'] = 'Abaikan';
$txt['board_perms_deny'] = 'Tolak';
$txt['all_boards_in_cat'] = 'All boards in this category';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Words separator';

$txt['admin_order_title'] = 'Ordering Error';
$txt['admin_order_error'] = 'An unknown error occurred while processing your request';

// Known controllers that can work on the front page
$txt['default'] = 'Standar';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
