<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Zobrazit koncepty';
$txt['drafts_show_desc'] = 'Tato oblast zobrazuje všechny návrhy, které jste aktuálně uložili. Odtud je můžete před odesláním upravit nebo smazat';

// misc
$txt['drafts'] = 'Koncepty';
$txt['draft_save'] = 'Uložit koncept';
$txt['draft_save_note'] = 'Tímto se uloží text příspěvku, ale nebudou uloženy přílohy, ankety nebo informace o události.';
$txt['draft_none'] = 'Nemáte žádné koncepty.';
$txt['draft_edit'] = 'Upravit koncept';
$txt['draft_load'] = 'Načíst koncepty';
$txt['draft_hide'] = 'Skrýt koncepty';
$txt['draft_delete'] = 'Smazat koncept';
$txt['draft_days_ago'] = 'před %s dny';
$txt['draft_retain'] = 'toto bude uchováno po dobu %s dní';
$txt['draft_remove'] = 'Odstranit tento koncept';
$txt['draft_remove_selected'] = 'Odstranit všechny vybrané koncepty ?';
$txt['draft_saved'] = 'Obsah byl uložen jako koncept a bude přístupný z <a href="%1$s">oblasti konceptů</a>vašeho profilu.';
$txt['draft_pm_saved'] = 'Obsah byl uložen jako koncept a bude přístupný z <a href="%1$s">oblasti konceptů</a>vašeho centra zpráv.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Povolit automatické ukládání konceptů';
$txt['drafts_autosave_enabled_subnote'] = 'Tímto se automaticky uloží uživatelské koncepty na pozadí na určitou dobu. Uživatel musí mít však správná oprávnění';
$txt['drafts_keep_days'] = 'Maximální počet dní pro uchování konceptu';
$txt['drafts_keep_days_subnote'] = 'Pro trvalé uchování konceptu zadejte 0';
$txt['drafts_autosave_frequency'] = 'Jak často by měly být koncepty automaticky ukládány ?';
$txt['drafts_autosave_frequency_subnote'] = 'Minimální přípustná hodnota je 30 sekund';
$txt['drafts_pm_enabled'] = 'Povolit ukládání konceptů v soukromých zprávách';
$txt['drafts_post_enabled'] = 'Povolit ukládání konceptů v příspěvcích';
$txt['drafts_none'] = 'Bez předmětu';
$txt['drafts_saved'] = 'Koncept byl úspěšně uložen';