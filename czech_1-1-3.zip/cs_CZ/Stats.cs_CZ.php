<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Nejvíce přítomní';

$txt['stats_center'] = 'Statistiky';
$txt['general_stats'] = 'Hlavní statistiky';
$txt['top_posters'] = '10 nejaktivnějších uživatelů';
$txt['top_boards'] = '10 nejoblíbenějších diskuzí';
$txt['forum_history'] = 'Historie fóra (pomocí časového posunutí fóra)';
$txt['stats_new_topics'] = 'Nová témata';
$txt['stats_new_posts'] = 'Nové příspěvky';
$txt['stats_new_members'] = 'Noví uživatelé';
$txt['page_views'] = 'Zobrazení stránek';
$txt['top_topics_replies'] = '10 nejoblíbenějších témat (podle odpovědí)';
$txt['top_topics_views'] = '10 nejoblíbenějších témat (podle zhlédnutí)';
$txt['yearly_summary'] = 'Roční souhrn';
$txt['top_starters'] = 'Nejvíce nových témat';
$txt['most_time_online'] = 'Nejvíce přítomných v čase';

$txt['average_members'] = 'Průměrně registrací za den';
$txt['average_posts'] = 'Průměrně příspěvků za den';
$txt['average_topics'] = 'Průměrně témat za den';
$txt['average_online'] = 'Průměrně přítomných za den';
$txt['users_online'] = 'Přítomní uživatelé';
$txt['emails_sent'] = 'Průměrně e-mailů za den';
$txt['users_online_today'] = 'Přítomni dnes';
$txt['num_hits'] = 'Zobrazení stránek celkem';
$txt['average_hits'] = 'Průměré zobrazení stránek za den';

$txt['ssi_comment'] = 'komentář';
$txt['ssi_comments'] = 'komentáře';
$txt['ssi_write_comment'] = 'Napsat komentář';
$txt['ssi_no_guests'] = 'Nelze zadat tabuli, která neumožňuje přístup hostům. Před dalším pokusem prosím zkontrolujte ID desky.';
$txt['xml_rss_desc'] = 'Aktuální informace z {forum_name}';