<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Fórum';
$txt['admin_back_to'] = 'Zpět do administračního panelu';
$txt['admin_users'] = 'Prohlížet/Mazat uživatele';
$txt['admin_newsletters'] = 'Napsat uživatelům';
$txt['include_these'] = 'Zahrnutí uživatelé';
$txt['exclude_these'] = 'Vyloučení uživatelé';
$txt['admin_newsletters_select_groups'] = 'Zahrnuté skupiny';
$txt['admin_newsletters_exclude_groups'] = 'Vyloučené skupiny';
$txt['admin_edit_news'] = 'Novinky';
$txt['admin_groups'] = 'Skupiny';
$txt['admin_members'] = 'Spravovat členy';
$txt['admin_members_list'] = 'Níže je uveden seznam všech uživatelů, kteří jsou momentálně na vašem fóru registrováni.';
$txt['admin_next'] = 'Dále';
$txt['admin_censored_words'] = 'Spravovat cenzurovaná slova';
$txt['admin_censored_where'] = 'Vlevo zapište cenzurované slovo, poté vpravo na co jej chcete měnit.';
$txt['admin_censored_desc'] = 'Jistě existují slova, která byste jako administrátor neradi ve fóru viděli. Proto můžete níže vypsat slova, která chcete cenzurovat.<br />Pro odstranění vymažte políčka a stiskněte tlačítko uložit.';
$txt['admin_reserved_names'] = 'Nastavit zakázaná jména';
$txt['admin_template_edit'] = 'Upravit šablonu fóra';
$txt['admin_modifications'] = 'Nastavení doplňků';
$txt['admin_security_moderation'] = 'Bezpečnost a moderace';
$txt['admin_server_settings'] = 'Nastavení serveru';
$txt['admin_reserved_set'] = 'Nastavit vyhrazená jména';
$txt['admin_reserved_line'] = 'Jedno vyhrazené slovo na řádek.';
$txt['admin_basic_settings'] = 'Zde můžete měnit základní nastavení fóra. Změny provádějte velice opatrně, protože mohou snadno vyřadit fórum z provozu.';
$txt['admin_maintain'] = 'Zapnout mód údržby ?';
$txt['admin_title'] = 'Název fóra';
$txt['admin_url'] = 'URL adresa fóra';
$txt['cookie_name'] = 'Název cookie';
$txt['admin_webmaster_email'] = 'E-mail webmastera';
$txt['boarddir'] = 'ElkArte adresář';
$txt['sourcesdir'] = 'Adresář Zdroje';
$txt['cachedir'] = 'Adresář dočasné paměti';
$txt['admin_news'] = 'Povolit novinky ?';
$txt['admin_guest_post'] = 'Povolit příspěvky hostů ?';
$txt['admin_manage_members'] = 'Prohlížet/Mazat uživatele';
$txt['admin_main'] = 'Hlavní';
$txt['admin_config'] = 'Konfigurace fóra';
$txt['admin_version_check'] = 'Detailní prověření verze';
$txt['admin_elkfile'] = 'Soubor ElkArte';
$txt['admin_elkpackage'] = 'Balíček rozšíření ElkArte';
$txt['admin_logoff'] = 'Odejít z administrace';
$txt['admin_maintenance'] = 'Údržba';
$txt['admin_image_text'] = 'Zobrazovat tlačítka jako obrázky, nikoli text';
$txt['admin_credits'] = 'Uznání a poděkování';
$txt['admin_agreement'] = 'Při registraci zobrazovat a vyžadovat písemný souhlas';
$txt['admin_checkbox_agreement'] = 'Pro smlouvu v registračním formuláři zobrazit zaškrtávací tlačítko namísto povinného přejetí celé stránky';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Výchozí';
$txt['admin_agreement_select_language'] = 'Editovat jazyk';
$txt['admin_agreement_select_language_change'] = 'Změnit';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Smazat vybrané uživatele';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Opravit všechna témata a diskuze';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Napsaný text do pole níže se bude zobrazovat jako novinka na fóru. Používat můžete některé BB kódy, jako například <span>[b]</span>, <span>[i]</span> a <span>[u]</span>, stejně tak jako smajlíky. Pro vymazání novinky vymažte obsah pole.';
$txt['administrators'] = 'Administrátoři fóra';
$txt['admin_reserved_desc'] = 'Vyhrazená jména znemožní uživatelům registraci pod těmito jmény, nebo použití v zobrazovaném jméně.';
$txt['admin_activation_email'] = 'Poslat novým členům aktivační email ?';
$txt['admin_match_whole'] = 'Pouze celá jména. Je-li odškrtnuto, hledá i podřetězce.';
$txt['admin_match_case'] = 'Kontrolovat velká/malá písmena.';
$txt['admin_check_user'] = 'Kontrolovat jméno.';
$txt['admin_check_display'] = 'Kontrolovat zobrazované jméno.';
$txt['admin_newsletter_send'] = 'Z této stránky můžete posílat e-mail komukoli. Adresy uživatelů vybraných skupin by se měly nacházet níže. Ověřte, zda jsou adresy odděleny středníkem viz. \adresa1; adresa2\.';
$txt['admin_fader_delay'] = 'Čas pro zobrazení panelu novinek v milisekundách';
$txt['zero_for_no_limit'] = '(Pro žádné omezení nastavte 0)';
$txt['zero_to_disable'] = '(Pro vypnutí nastavte 0)';

$txt['admin_backup_fail'] = 'Chyba při vytváření zálohy v souboru Settings.php - ujistěte se, že soubor Settings_bak.php existuje a má nastavené právo zápisu.';
$txt['modSettings_info'] = 'Nastavení obecných funkcí, karmy, podpisů, lajkování a dalších prvků, které ovládají fungování tohoto fóra.';
$txt['database_server'] = 'Databázový server';
$txt['database_user'] = 'Uživatel databáze';
$txt['database_password'] = 'Heslo databáze';
$txt['database_name'] = 'Název databáze';
$txt['registration_agreement'] = 'Upravit registrační smlouvu';
$txt['registration_agreement_desc'] = 'Tato informace je zobrazena pouze pokud jste nastavili, aby byla zobrazována při registraci.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Předpona databázových tabulek';
$txt['errors_list'] = 'Seznam chyb na fóru';
$txt['errors_found'] = 'Následující chyby poškozují fórum';
$txt['errors_fix'] = 'Chtěli byste tyto chyby opravit ?';
$txt['errors_do_recount'] = 'Všechny chyby byly opraveny a byla vytvořena záchranná oblast. Klepnutím na tlačítko níže zobrazíte několik klíčových statistik.';
$txt['errors_recount_now'] = 'Přepočítat statistiky';
$txt['errors_fixing'] = 'Opravuji chyby fóra';
$txt['errors_fixed'] = 'Všechny chyby byly opraveny ! Měli byste prozkoumat všechny vytvořené kategorie, diskuze nebo témata a rozhodnout se co s nimi dále provedete.';
$txt['attachments_avatars'] = 'Správce příloh';
$txt['attachments_desc'] = 'Odsud můžete spravovat přílohy na tomto fóru. K dispozici jsou další statistiky a možnost promazávání podle velikosti nebo data.';
$txt['attachment_stats'] = 'Statistiky příloh';
$txt['attachment_integrity_check'] = 'Kontrola integrity přílohy';
$txt['attachment_integrity_check_desc'] = 'Tato funkce zkontroluje integritu a velikosti příloh v databázi. Pokud je to nutné, případné chyby opraví.';
$txt['attachment_check_now'] = 'Zkontrolovat nyní';
$txt['attachment_pruning'] = 'Promazávání příloh';
$txt['attachment_pruning_message'] = 'Přidat zprávu k příspěvkům';
$txt['attachment_pruning_warning'] = 'Opravdu chcete smazat tyto přílohy ?\\nTato operace je nevratná !';

$txt['attachment_total'] = 'Celkem příloh';
$txt['attachmentdir_size'] = 'Celková velikost příloh ve všech adresářích';
$txt['attachmentdir_size_current'] = 'Celková velikost příloh v aktuálním adresáři';
$txt['attachmentdir_files_current'] = 'Celkový počet příloh v aktuálním adresáři';
$txt['attachment_space'] = 'Volné místo v adresáři s přílohami';
$txt['attachment_files'] = 'Zbývá před zaplněním';

$txt['attachment_options'] = 'Možnosti příloh';
$txt['attachment_log'] = 'Seznam příloh';
$txt['attachment_remove_old'] = 'Odstranit přílohy starší než %1$s dny';
$txt['attachment_remove_size'] = 'Odstranit přílohy větší než %1$s kiB';
$txt['attachment_name'] = 'Název přílohy';
$txt['attachment_file_size'] = 'Velikost přílohy';
$txt['attachmentdir_size_not_set'] = 'Maximální velikost adresáře není nastavena';
$txt['attachmentdir_files_not_set'] = 'Není nastaven žádný limit souborů v adresáři';
$txt['attachment_delete_admin'] = '[příloha smazána administrátorem]';
$txt['live'] = 'Nejnovější aktualizace softwaru';
$txt['remove_all'] = 'Smazat záznamy';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(více podrobně)';

$txt['lfyi'] = 'Nelze se spojit se serverem ElkArte komunity pro zobrazení posledních novinek.';

$txt['manage_calendar'] = 'Kalendář';
$txt['manage_search'] = 'Hledat';
$txt['viewmembers_online'] = 'Naposledy online';

$txt['smileys_manage'] = 'Smajlíci a jejich sady';
$txt['smileys_manage_info'] = 'Instalujte nové sady smajlíků nebo přidávejte nové smajlíky do stávajících sad.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Nainstalujte, stáhněte nebo nahrajte modifikační balíčky rozšíření; zkontrolujte oprávnění a nastavení FTP.';
$txt['theme_admin'] = 'Nastavení vzhledu';
$txt['theme_admin_info'] = 'Nainstalujte nové vzhledy nebo vyberte vzhledy, které jsou již k dispozici pro vaše uživatele a nastavte nebo obnovte možnosti vzhledu.';
$txt['registration_center'] = 'Správa registrací';
$txt['member_center_info'] = 'Zobrazení seznamu uživatelů, hledání uživatelů, správa neschválených nebo neaktivovaných uživatelů.';
$txt['viewmembers_online'] = 'Naposledy online';

$txt['display_name'] = 'Jméno';
$txt['email_address'] = 'Email';
$txt['ip_address'] = 'IP adresa';
$txt['member_id'] = 'ID kód';

$txt['unknown'] = 'neznámý';
$txt['security_wrong'] = 'Pokus o přihlášení administrátora !
Odkazující: %1$s
Prohlížeč: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Odeslat v HTML formátu. (S tímto můžete do e-mailu umístit normální HTML).';
$txt['email_parsed_html'] = 'Přidat &lt;br /&gt;s a &amp;nbsp;s do této zprávy.';
$txt['email_variables'] = 'V této zprávě můžete použít několik &quot;proměnných&quot;.<a href="{help_emailmembers}" class="help">Pro více informací klikněte zde</a>.';
$txt['email_force'] = 'Poslat e-mail uživatelům, i když se rozhodli nepřijímat oznámení.';
$txt['email_as_pms'] = 'Pošlete tuto zprávu těmto skupinám pomocí osobních zpráv.';
$txt['email_continue'] = 'Pokračovat';
$txt['email_done'] = 'hotovo.';
$txt['email_members_succeeded'] = 'Úspěšně jste odeslali vaše novinky !';

$txt['ban_title'] = 'Upravit seznam banů';
$txt['ban_ip'] = 'Zabanování IP adresy: (příklad. 192.168.12.213 or 128.0.*.*) - na každý řádek jeden záznam';
$txt['ban_email'] = 'Zabanování e-mailu: (příklad. badguy@somewhere.com) - na každý řádek jeden záznam';
$txt['ban_username'] = 'Zabanování uživatele: (příklad. l33tuser) - na každý řádek jeden záznam';

$txt['ban_errors_detected'] = 'Při úpravách nebo spouštění či uložení banu došlo k následující chybě nebo chybám';
$txt['ban_description'] = 'Zde můžete zabanovat problémové osoby, buď podle IP adresy, názvu hostitele, jména uživatele nebo e-mailu.';
$txt['ban_add_new'] = 'Přidat ban';
$txt['ban_banned_entity'] = 'Banovaný subjekt';
$txt['ban_on_ip'] = 'Ban na IP adresu (příklad. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Ban na hostname (příklad. *.mil)';
$txt['ban_on_email'] = 'Ban na e-mailovou adresu (příklad. *@badsite.com)';
$txt['ban_on_username'] = 'Ban na uživatelské jméno';
$txt['ban_notes'] = 'Poznámky';
$txt['ban_restriction'] = 'Omezení';
$txt['ban_full_ban'] = 'Plný ban';
$txt['ban_partial_ban'] = 'Částečný ban';
$txt['ban_cannot_post'] = 'Nemůže posílat příspěvky';
$txt['ban_cannot_register'] = 'Nemůže se zaregistrovat';
$txt['ban_cannot_login'] = 'Nemůže se přihlásit';
$txt['ban_add'] = 'Přidat';
$txt['ban_edit_list'] = 'Upravit seznam banů';
$txt['ban_type'] = 'Typ banu';
$txt['ban_days'] = 'den(dnů)';
$txt['ban_will_expire_within'] = 'Ban vyprší za';
$txt['ban_added'] = 'Přidán';
$txt['ban_expires'] = 'Vyprší';
$txt['ban_hits'] = 'Záznamů';
$txt['ban_actions'] = 'Akce';
$txt['ban_expiration'] = 'Ukončení';
$txt['ban_reason_desc'] = 'Důvod banu, který se zobrazí zabanovanému uživateli.';
$txt['ban_notes_desc'] = 'Poznámky pro další adminy a moderátory.';
$txt['ban_remove_selected'] = 'Smazat vybrané';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Opravdu chcete smazat vybrané bany ?';
$txt['ban_modify'] = 'Změnit';
$txt['ban_name'] = 'Název banu';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Upravit ban';
$txt['ban_add_notes'] = '<strong>Poznámka</strong>: po vytvoření banu můžete přidat další metody, kterými se ban kontroluje, jako je IP adresa, jméno počítače nebo emailová adresa.';
$txt['ban_expired'] = 'Prošlý / zakázaný';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Není vybráno žádné omezení.';

$txt['ban_triggers'] = 'Metody';
$txt['ban_add_trigger'] = 'Přidat metodu banu';
$txt['ban_add_trigger_submit'] = 'Přidat';
$txt['ban_edit_trigger'] = 'Změnit';
$txt['ban_edit_trigger_title'] = 'Změnit metodu';
$txt['ban_edit_trigger_submit'] = 'Změnit';
$txt['ban_remove_selected_triggers'] = 'Odebrat vybrané metody banu';
$txt['ban_no_entries'] = 'Momentálně nejsou v platnosti žádné bany.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Opravdu chcete odebrat vybrané metody banů ?';
$txt['ban_trigger_browse'] = 'Procházet metody banů';
$txt['ban_trigger_browse_description'] = 'Zde jsou vidět všechny bany seřazené podle IP adresy, jména počítače, emailu nebo uživatelského jména.';

$txt['ban_log'] = 'Seznam banů';
$txt['ban_log_description'] = 'Seznam banů zobrazuje všechny pokusy zabanovaných uživatelů o vstup na fórum (pouze pro \'Úplný zákaz\' a \'Zákaz registrace\').';
$txt['ban_log_no_entries'] = 'Žádné záznamy';
$txt['ban_log_ip'] = 'IP adresa';
$txt['ban_log_email'] = 'Emailová adresa';
$txt['ban_log_member'] = 'Uživatel';
$txt['ban_log_date'] = 'Datum';
$txt['ban_log_remove_all'] = 'Smazat záznamy';
$txt['ban_log_remove_all_confirm'] = 'Opravdu chcete smazat všechny záznamy ?';
$txt['ban_log_remove_selected'] = 'Smazat vybrané';
$txt['ban_log_remove_selected_confirm'] = 'Opravdu chcete smazat všechny vybrané záznamy ?';
$txt['ban_no_triggers'] = 'Žádné metody banů';

$txt['settings_not_writable'] = 'Tato nastavení nemohou být změněna, protože soubor Settings.php nemá nastavené právo zápisu.';

$txt['maintain_title'] = 'Údržba fóra';
$txt['maintain_info'] = 'Optimalizujte tabulky, provádějte zálohy, kontrolujte chyby a tím pravidelně udržujte fórum v bezpečném chodu.';
$txt['maintain_sub_database'] = 'Databáze';
$txt['maintain_sub_routine'] = 'Další možnosti';
$txt['maintain_sub_members'] = 'Prohlížet/Mazat uživatele';
$txt['maintain_sub_topics'] = 'Témata';
$txt['maintain_sub_attachments'] = 'Přílohy';
$txt['maintain_done'] = 'Aktuální úloha údržby  \'%1$s \' byla provedena.';
$txt['maintain_fail'] = 'Aktuální úloha údržby  \'%1$s \' nebyla provedena.';
$txt['maintain_no_errors'] = 'Gratulujeme, nebyly nalezeny žádné chyby !';

$txt['maintain_tasks'] = 'Naplánované úlohy';
$txt['maintain_tasks_desc'] = 'V této sekci můžete spravovat všechny naplánované úlohy.';

$txt['scheduled_log'] = 'Seznam úloh';
$txt['scheduled_log_desc'] = 'Seznamy úloh, které jsou aktuálně naplánovány.';
$txt['admin_log'] = 'Administrátorské záznamy';
$txt['admin_log_desc'] = 'Seznamy úkonů prováděných administrátory Vašeho fóra.';
$txt['moderation_log'] = 'Moderátorské záznamy';
$txt['moderation_log_desc'] = 'Seznamy úkonů prováděných moderátory Vašeho fóra.';
$txt['badbehavior_log'] = 'Chybné a špatné logování';
$txt['badbehavior_log_desc'] = 'Seznamy požadavků, které byly zablokovány nebo označeny jako podezřelé v důsledku špatného chování. Je-li povolené podrobné protokolování na všech požadavcích HTTP, budou zde uvedeny.';
$txt['spider_log_desc'] = 'Zkontrolujte položky týkající se aktivity vyhledávacích robotů na vašem fóru.';
$txt['pruning_log_desc'] = 'Pomocí těchto nástrojů můžete prořezávat starší položky v různých protokolech.';

$txt['mailqueue_title'] = 'E-maily';

$txt['db_error_send'] = 'Poslat email, když dojde k chybě spojení s databází';
$txt['db_persist'] = 'Používat trvalé připojení';
$txt['ssi_db_user'] = 'Jméno databáze, které bude využíváno v režimu SSI';
$txt['ssi_db_passwd'] = 'Heslo databáze, které bude využíváno v režimu SSI';

$txt['default_language'] = 'Výchozí jazyk fóra';

$txt['maintenance_subject'] = 'Zobrazovat předmět';
$txt['maintenance_message'] = 'Zobrazovat zprávu';

$txt['errlog_desc'] = 'Do seznamu chyb se zaznamenávají všechny chyby fóra. Ke smazání záznamu z databáze ho označte a stiskněte tlačítko %1$s ve spodní části stránky.';
$txt['errlog_no_entries'] = 'Momentálně se zde nenacházejí žádné zaznamenané chyby.';

$txt['theme_settings'] = 'Nastavení vzhledu';
$txt['theme_edit_settings'] = 'Upravit nastavení tohoto vzhledu';
$txt['theme_current_settings'] = 'Současný vzhled';

$txt['dvc_your'] = 'Vaše verze';
$txt['dvc_current'] = 'Současná verze';
$txt['dvc_sources'] = 'Zdroje';
$txt['dvc_admin'] = 'Administrace';
$txt['dvc_controllers'] = 'Ovladače';
$txt['dvc_database'] = 'Databáze';
$txt['dvc_subs'] = 'Titulky';
$txt['dvc_default'] = 'Výchozí témata';
$txt['dvc_templates'] = 'Současná témata';
$txt['dvc_languages'] = 'Jazykové soubory';

$txt['smileys_default_set_for_theme'] = 'Zvolte sadu smajlíků pro tento vzhled';
$txt['smileys_no_default'] = 'Použít výchozí sadu smajlíků';

$txt['censor_test'] = 'Otestovat cenzurovaná slova';
$txt['censor_test_save'] = 'Testovat';
$txt['censor_case'] = 'Ignorovat velká/malá písmena.';
$txt['censor_whole_words'] = 'Kontrolovat pouze celá slova.';
$txt['censor_allow'] = 'Povolit uživatelům vypnout cenzuru slov.';

$txt['admin_confirm_password'] = '(potvrdit)';
$txt['admin_incorrect_password'] = 'Nesprávné heslo';

$txt['date_format'] = '(RRRR-MM-DD)';
$txt['undefined_gender'] = 'Není definováno';
$txt['age'] = 'Věk uživatele';
$txt['activation_status'] = 'Status aktivace';
$txt['activated'] = 'Aktivováno';
$txt['not_activated'] = 'Není aktivován';
$txt['is_banned'] = 'Zabanován';
$txt['primary'] = 'Primární';
$txt['additional'] = 'Další';
$txt['wild_cards_allowed'] = 'Žolíkové znaky * and ? jsou povoleny';
$txt['member_part_of_these_membergroups'] = 'Uživatel je člen těchto skupin';
$txt['membergroups'] = 'Skupiny';
$txt['confirm_delete_members'] = 'Opravdu chcete smazat vybrané uživatele ?';

$txt['support_credits_title'] = 'Uznání &amp; Poděkování';
$txt['support_credits_info'] = 'Zobrazit podporu k běžným problémům a informace o verzích software. Tyto informace budete potřebovat, pokud si vyžádáte pomoc od ElkArte komunity. ';
$txt['support_title'] = 'Informace pro podporu';
$txt['support_versions_current'] = 'Současná verze';
$txt['support_versions_forum'] = 'Tato verze';
$txt['support_versions_db'] = '%1$s verze';
$txt['support_versions_server'] = 'Verze serveru';
$txt['support_versions_gd'] = 'Verze GD knihovny';
$txt['support_versions_imagick'] = 'Verze Imagick';
$txt['support_versions'] = 'Informace o verzích';
$txt['support_resources'] = 'Zdroje podpory';
$txt['support_resources_p1'] = 'Náš <a href="%1$s" target="_blank" class="new_win">Online manuál</a> poskytuje hlavní dokumentaci k ElkArte. ElkArte Online manuál má mnoho dokumentů, které pomohou zodpovědět otázky na <a href="%2$s" target="_blank" class="new_win">funkce</a>, <a href="%3$s" target="_blank" class="new_win">nastavení</a>, <a href="%4$s" target="_blank" class="new_win">vzhledy</a>, <a href="%5$s" target="_blank" class="new_win">balíčky rozšíření</a> a další. Online manuál důkladně a rychle zodpoví každou oblast ElkArte.';
$txt['support_resources_p2'] = 'Pokud nemůžete najít odpovědi na své otázky v online manuálu, hledejte je v naší ElkArte <a href="%1$s" target="_blank" class="new_win">komunitě</a> nebo požádejte o pomoc uživatele fóra. Je možné taktéž využít přímo technickou podporu <a href="%2$s" target="_blank" class="new_win">ElkArte</a> a poradit se s ostatními <a href="%3$s" target="_blank" class="new_win">správci fóra</a>.';

$txt['latest_updates'] = 'Nejnovější pozoruhodné aktualizace';
$txt['new_in_1_0_2'] = 'The most significant change in ElkArte 1.0.2 is avatar permission management. Currently each method of setting an avatar is permission-based, requiring the enabling/disabling of each method for each group. With 1.0.2 avatars are simply enabled/disabled by user group, this allows the enabled groups to add an avatar (by all available methods).<br />
The only permission available is a general one to allow members to change or not their avatars. Additionally there is only one setting for maximum width and height of avatars, these values apply to all avatar methods.<br /><br />
Due to the nature of the changes it was not impossible to migrate existing settings to the new format, for that reason you are encouraged to visit the <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Settings</a> page and set the options you prefer.';

$txt['edit_permissions_info'] = 'Použijte nastavení oprávnění ke správě globálních a specifických funkcí fóra a zvolte jaké mohou hosté, členové a moderátoři provádět akce.';
$txt['membergroups_members'] = 'Nezařazení členové';
$txt['membergroups_guests'] = 'Hosté';
$txt['membergroups_add_group'] = 'Přidat skupinu';
$txt['membergroups_permissions'] = 'Oprávnění';

$txt['permitgroups_restrict'] = 'Omezení';
$txt['permitgroups_standard'] = 'Standardní';
$txt['permitgroups_moderator'] = 'Moderátor';
$txt['permitgroups_maintenance'] = 'Údržba';

$txt['confirm_delete_attachments'] = 'Opravdu chcete smazat vybrané přílohy ?';
$txt['attachment_manager_browse_files'] = 'Procházet soubory';
$txt['attachment_manager_repair'] = 'Spravovat';
$txt['attachment_manager_avatars'] = 'Avatary';
$txt['attachment_manager_attachments'] = 'Přílohy';
$txt['attachment_manager_thumbs'] = 'Náhledy';
$txt['attachment_manager_last_active'] = 'Naposledy aktivní';
$txt['attachment_manager_member'] = 'Uživatel';
$txt['attachment_manager_avatars_older'] = 'Smazat avatary členů neaktivních více než %1$s dnů';
$txt['attachment_manager_total_avatars'] = 'Celkem avatarů';

$txt['attachment_manager_avatars_no_entries'] = 'Momentálně zde nejsou žádné avatary.';
$txt['attachment_manager_attachments_no_entries'] = 'Momentálně zde nejsou žádné přílohy.';
$txt['attachment_manager_thumbs_no_entries'] = 'Momentálně zde nejsou žádné náhledy.';

$txt['attachment_manager_settings'] = 'Nastavení příloh';
$txt['attachment_manager_avatar_settings'] = 'Nastavení avatarů';
$txt['attachment_manager_browse'] = 'Procházet soubory';
$txt['attachment_manager_maintenance'] = 'Správa souborů';
$txt['attachmentEnable'] = 'Přílohy';
$txt['attachmentEnable_deactivate'] = 'Zakázat přílohy';
$txt['attachmentEnable_enable_all'] = 'Povolit všechny přílohy';
$txt['attachmentEnable_disable_new'] = 'Zakázat nové přílohy';
$txt['attachmentCheckExtensions'] = 'Kontrolovat přípony příloh';
$txt['attachmentExtensions'] = 'Povolené přípony příloh';
$txt['attachmentRecodeLineEndings'] = 'Překódovat konce řádků v textových přílohách';
$txt['attachmentShowImages'] = 'Zobrazovat obrázkové přílohy jako obrázky pod zprávou';
$txt['attachmentUploadDir'] = 'Adresář s přílohami';
$txt['attachmentUploadDir_multiple_configure'] = 'Správa adresářů příloh';
$txt['attachmentDirSizeLimit'] = 'Maximální velikost adresáře s přílohami';
$txt['attachmentPostLimit'] = 'Maximální velikost příloh na jednu zprávu';
$txt['attachmentSizeLimit'] = 'Maximální velikost přílohy';
$txt['attachmentNumPerPostLimit'] = 'Maximální počet příloh na jednu zprávu';
$txt['attachment_img_enc_warning'] = 'Modul GD knihovny není v současné době nainstalován. Překódování obrázku není možné.';
$txt['attachment_postsize_warning'] = 'Současné nastavení \'post_max_size\' v php.ini nemusí tuto volbu podporovat.';
$txt['attachment_filesize_warning'] = 'Současné nastavení \'upload_max_filesize\' v php.ini nemusí tuto volbu podporovat.';
$txt['attachment_image_reencode'] = 'Překódovat potenciálně nebezpečné obrázkové přílohy';
$txt['attachment_image_reencode_note'] = '(vyžaduje GD knihovnu nebo modul ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Bezpečnostní kontrola může mít za následek velký počet zamítnutých příloh.';
$txt['attachment_image_paranoid'] = 'Provádět bezpečnostní kontrolu při nahrávání obrázkových příloh';
$txt['attachment_autorotate'] = 'Detekovat a opravit nesprávně otočené snímky';
$txt['attachment_autorotate_na'] = '(V tomto systému není k dispozici)';
$txt['attachmentThumbnails'] = 'Zmenšovat obrázky, když se zobrazují pod zprávami';
$txt['attachment_thumb_png'] = 'Uložit náhledy jako PNG';
$txt['attachment_thumb_memory'] = 'Adaptivní paměť s náhledy';
$txt['attachment_thumb_memory_note2'] = 'Pokud systém nemůže získat adaptivní paměť, nebude náhled vytvořen.';
$txt['attachment_thumb_memory_note1'] = 'Nezaškrtávejte, abyste se pokaždé pokusili vytvořit náhled';
$txt['attachmentThumbWidth'] = 'Maximální šířka náhledu';
$txt['attachmentThumbHeight'] = 'Maximální výška náhledu';
$txt['attachment_thumbnail_settings'] = 'Nastavení náhledů';
$txt['attachment_security_settings'] = 'Nastavení zabezpečení příloh';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Neexistuje';
$txt['attach_dir_not_writable'] = 'Není povolen zápis';
$txt['attach_dir_files_missing'] = 'Soubory chybí (<a href="{repair_url}">Opravit</a>)';
$txt['attach_dir_unused'] = 'Nepoužívaný';
$txt['attach_dir_empty'] = 'Prázdné';
$txt['attach_dir_ok'] = 'Proveď';
$txt['attach_dir_basedir'] = 'Výchozí adresář';

$txt['attach_dir_desc'] = 'Create new directories or change the current directory below. Directories can be renamed as long as they do not contain a sub-directory. If the new directory is to be created within the forum directory structure, you\'ll just need to type the directory name. To remove a directory, blank the path input field. Directories can not be deleted if they contain either files or sub-directories (shown in brackets next to the file count).';
$txt['attach_dir_base_desc'] = 'You may use the area below to change the current base directory or create a new one. New base directories are also added to the Attachment Directory list. You may also designate an existing directory to be a base directory.';
$txt['attach_dir_save_problem'] = 'Oops, there seems to be a problem.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory. Please do so using a FTP client or your site file manager.';
$txt['attachments_no_write'] = 'This directory has been created but is not writable. Please attempt to do so using a FTP client or your site file manager.';
$txt['attach_dir_reserved'] = 'Unable to add. This directory is a system directory and cannot be used for attachments.';
$txt['attach_dir_duplicate_msg'] = 'Unable to add. This directory already exists.';
$txt['attach_dir_exists_msg'] = 'Unable to move. A directory already exists at that path.';
$txt['attach_dir_base_dupe_msg'] = 'Unable to add. This base directory has already been created.';
$txt['attach_dir_base_no_create'] = 'Unable to create. Please verify the path input or create this directory using an FTP client or site file manager and re-try.';
$txt['attach_dir_no_rename'] = 'Unable to move or rename. Please verify that the path is correct or that this directory does not contain any sub-directories.';
$txt['attach_dir_no_delete'] = 'Is not empty and can not be deleted. Please do so using a FTP client or site file manager.';
$txt['attach_dir_no_remove'] = 'Still contains files or is a base directory and can not be deleted.';
$txt['attach_dir_is_current'] = 'Unable to remove while it is selected as the current directory.';
$txt['attach_dir_is_current_bd'] = 'Unable to remove while it is selected as the current base directory.';
$txt['attach_last_dir'] = 'Last active attachment directory';
$txt['attach_current_dir'] = 'Aktuální adresář';
$txt['attach_current'] = 'Aktuální';
$txt['attach_path_manage'] = 'Spravovat cesty k přílohám';
$txt['attach_directories'] = 'Adresář příloh';
$txt['attach_paths'] = 'Cesta k adresáři příloh';
$txt['attach_path'] = 'Cesta';
$txt['attach_current_size'] = 'Velikost (KiB)';
$txt['attach_num_files'] = 'Soubory';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Přidat cestu';
$txt['attach_path_current_bad'] = 'Invalid current attachment path.';
$txt['attachmentDirFileLimit'] = 'Maximum number of files per directory';

$txt['attach_base_paths'] = 'Base directory paths';
$txt['attach_num_dirs'] = 'Directories';
$txt['max_image_width'] = 'Max display width of posted or attached images';
$txt['max_image_height'] = 'Max display height of posted or attached images';

$txt['automanage_attachments'] = 'Choose the method for the management of the attachment directories';
$txt['attachments_normal'] = '(Manual) ElkArte default behaviour';
$txt['attachments_auto_years'] = '(Auto) Subdivide by years';
$txt['attachments_auto_months'] = '(Auto) Subdivide by years and months';
$txt['attachments_auto_days'] = '(Auto) Subdivide by years, months and days';
$txt['attachments_auto_16'] = '(Auto) 16 random directories';
$txt['attachments_auto_16x16'] = '(Auto) 16 random directories with 16 random sub-directories';
$txt['attachments_auto_space'] = '(Auto) When either directory space limit is reached';

$txt['use_subdirectories_for_attachments'] = 'Create new directories within a base directory';
$txt['use_subdirectories_for_attachments_note'] = 'Otherwise any new directories will be created within the forum\'s main directory.';
$txt['basedirectory_for_attachments'] = 'Set a base directory for attachments';
$txt['basedirectory_for_attachments_current'] = 'Current base directory';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Please note that the directory is wrong. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">There seems to be a problem with this directory. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';

$txt['attachment_transfer'] = 'Transfer Attachments';
$txt['attachment_transfer_desc'] = 'Transfer files between directories.';
$txt['attachment_transfer_select'] = 'Select directory';
$txt['attachment_transfer_now'] = 'Přenos';
$txt['attachment_transfer_from'] = 'Přenos souborů z';
$txt['attachment_transfer_auto'] = 'Move them automatically by space or file count';
$txt['attachment_transfer_auto_select'] = 'Select base directory';
$txt['attachment_transfer_to'] = 'Or move them to a specific directory.';
$txt['attachment_transfer_empty'] = 'Move all files from the source directory.';
$txt['attachment_transfer_no_base'] = 'No base directories available.';
$txt['attachment_transfer_forum_root'] = 'Forum root directory.';
$txt['attachment_transfer_no_room'] = 'Directory size or file count limit reached.';
$txt['attachment_transfer_no_find'] = 'No files were found to transfer.';
$txt['attachments_transfered'] = '%1$d files were transferred to %2$s';
$txt['attachments_not_transfered'] = '%1$d files were not transferred.';
$txt['attachment_transfer_no_dir'] = 'Either the source directory or one of the target options were not selected.';
$txt['attachment_transfer_same_dir'] = 'You cannot select the same directory as both the source and target.';
$txt['attachment_transfer_progress'] = 'Please wait. Transfer in progress.';

$txt['avatar_settings'] = 'General avatar settings';
$txt['avatar_default'] = 'Enable a default avatar for all users without their own avatar';
$txt['avatar_directory'] = 'Adresář avatarů';
$txt['avatar_url'] = 'URL avatarů';
$txt['avatar_max_width'] = 'Maximum width of avatars in pixels (px)';
$txt['avatar_max_height'] = 'Maximum height of avatars in pixels (px)';
$txt['avatar_action_too_large'] = 'If the avatar is too large...';
$txt['option_refuse'] = 'Refuse it';
$txt['option_resize'] = 'Let the CSS resize it';
$txt['option_download_and_resize'] = 'Download and resize it (requires GD module or ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Enable use of gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'Use PNG for resized avatars';
$txt['avatar_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Some avatar features are disabled.';
$txt['avatar_external'] = 'External avatars';
$txt['avatar_external_enabled'] = 'Enable use of external (remote/URL) avatars';
$txt['avatar_upload'] = 'Uploadable avatars';
$txt['avatar_resize_options'] = 'Server storage options';
$txt['avatar_upload_enabled'] = 'Enable the upload of avatars';
$txt['avatar_server_stored'] = 'Server-stored avatars';
$txt['avatar_stored_enabled'] = 'Enable the selection of server stored avatars';
$txt['profile_set_avatar'] = 'Member groups allowed to select an avatar';
$txt['avatar_select_permission'] = 'Select permissions for each group';
$txt['avatar_download_external'] = 'Download avatar at given URL';
$txt['custom_avatar_enabled'] = 'Upload avatars to...';
$txt['option_attachment_dir'] = 'Attachment directory';
$txt['option_specified_dir'] = 'Specific directory...';
$txt['custom_avatar_dir'] = 'Upload directory';
$txt['custom_avatar_dir_desc'] = 'This should be a valid and writable directory, different than the server-stored directory.';
$txt['custom_avatar_url'] = 'Upload URL';
$txt['custom_avatar_check_empty'] = 'The custom avatar directory you have specified may be empty or invalid. Please ensure these settings are correct.';
$txt['avatar_reencode'] = 'Re-encode potentially dangerous avatars';
$txt['avatar_reencode_note'] = '(requires GD module)';
$txt['avatar_paranoid_warning'] = 'The extensive security checks can result in a large number of rejected avatars.';
$txt['avatar_paranoid'] = 'Perform extensive security checks on uploaded avatars';

$txt['repair_attachments'] = 'Maintain Attachments';
$txt['repair_attachments_complete'] = 'Maintenance Complete';
$txt['repair_attachments_complete_desc'] = 'All selected errors have now been corrected';
$txt['repair_attachments_no_errors'] = 'No errors were found';
$txt['repair_attachments_error_desc'] = 'The follow errors were found during maintenance. Check the box next to the errors you wish to fix and hit continue.';
$txt['repair_attachments_continue'] = 'Pokračovat';
$txt['repair_attachments_cancel'] = 'Zrušit';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d thumbnails are missing a parent attachment';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d parents are flagged as having thumbnails but don\'t';
$txt['attach_repair_file_missing_on_disk'] = '%1$d attachments/avatars have an entry but no longer exist on disk';
$txt['attach_repair_file_wrong_size'] = '%1$d attachments/avatars are being reported as the wrong filesize';
$txt['attach_repair_file_size_of_zero'] = '%1$d attachments/avatars have a size of zero on disk. (These will be deleted)';
$txt['attach_repair_attachment_no_msg'] = '%1$d attachments no longer have a message associated with them';
$txt['attach_repair_avatar_no_member'] = '%1$d avatars no longer have a member associated with them';
$txt['attach_repair_wrong_folder'] = '%1$d attachments are in the wrong directory';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d files do not have a corresponding entry in the database. (These will be deleted)';

$txt['news_title'] = 'Zprávy a zpravodaje';
$txt['news_settings_desc'] = 'Here you can change the settings and permissions related to news and newsletters.';
$txt['news_mailing_desc'] = 'From this menu you can send messages to all users who\'ve registered and entered their email addresses. You may edit the distribution list, or send messages to all. Useful for important update/news information.';
$txt['news_error_no_news'] = 'Nothing to preview';
$txt['groups_edit_news'] = 'Groups allowed to edit news items';
$txt['groups_send_mail'] = 'Groups allowed to send out forum newsletters';
$txt['xmlnews_enable'] = 'Enable XML/RSS news';
$txt['xmlnews_maxlen'] = 'Maximum message length';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Number of items in a news feed';
$txt['xmlnews_maxlen_note'] = '(0 to disable, bad idea.)';
$txt['editnews_clickadd'] = 'Add another item';
$txt['editnews_remove_selected'] = 'Smazat vybrané';
$txt['editnews_remove_confirm'] = 'Are you sure you want to delete the selected news items?';
$txt['censor_clickadd'] = 'Add another word';

$txt['layout_controls'] = 'Fórum';
$txt['logs'] = 'Logs';
$txt['generate_reports'] = 'Reports';

$txt['update_available'] = 'Update Available';
$txt['update_message'] = 'You\'re using an outdated version of ElkArte, which contains some bugs which have since been fixed.
	It is recommended that you <a href="#" id="update-link">update your forum</a> to the latest version as soon as possible. It only takes a minute!';

$txt['manageposts'] = 'Posts and Topics';
$txt['manageposts_title'] = 'Manage Posts and Topics';
$txt['manageposts_description'] = 'Here you can manage all settings related to topics and posts.';

$txt['manageposts_seconds'] = 'sekund';
$txt['manageposts_minutes'] = 'minut';
$txt['manageposts_characters'] = 'characters';
$txt['manageposts_days'] = 'dnů';
$txt['manageposts_posts'] = 'příspěvků';
$txt['manageposts_topics'] = 'témat';

$txt['pollMode'] = 'Povolit ankety';

$txt['manageposts_settings'] = 'Post Settings';
$txt['manageposts_settings_description'] = 'Here you can set everything related to posts and posting.';

$txt['manageposts_bbc_settings'] = 'Bulletin Board Code';
$txt['manageposts_bbc_settings_description'] = 'Bulletin board code can be used to add markup to forum messages. For example, to highlight the word \'house\' you can type [b]house[/b]. All Bulletin board code tags are surrounded by square brackets (\'[\' and \']\').';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code settings';

$txt['manageposts_topic_settings'] = 'Topic Settings';
$txt['manageposts_topic_settings_description'] = 'Here you can set all settings involving topics.';

$txt['managedrafts_settings'] = 'Draft Settings';
$txt['managedrafts_settings_description'] = 'Here you can set all settings involving drafts.';
$txt['manage_drafts'] = 'Koncepty';

$txt['mail_center'] = 'Maillist Center';
$txt['mm_emailerror'] = 'Failed Emails';
$txt['mm_emailfilters'] = 'Filters';
$txt['mm_emailparsers'] = 'Parsers';
$txt['mm_emailtemplates'] = 'Templates';
$txt['mm_emailsettings'] = 'Nastavení';

$txt['removeNestedQuotes'] = 'Remove nested quotes when quoting';
$txt['enableSpellChecking'] = 'Enable spell checking';
$txt['enableSpellChecking_warning'] = 'this does not work on all servers.';
$txt['enableSpellChecking_error'] = 'this does not work on your server.';
$txt['enableVideoEmbeding'] = 'Enable auto-embedding of video links.';
$txt['enableCodePrettify'] = 'Enable prettifying of code tags';
$txt['max_messageLength'] = 'Maximum allowed post size';
$txt['max_messageLength_zero'] = '0 for no max.';
$txt['convert_to_mediumtext'] = 'Your database is not setup to accept messages longer than 65535 characters. Please use the <a href="%1$s">database maintenance</a> page to convert the database and then come back to increase the maximum allowed post size.';
$txt['topicSummaryPosts'] = 'Posts to show on topic summary';
$txt['spamWaitTime'] = 'Time required between posts from the same IP';
$txt['edit_wait_time'] = 'Courtesy edit wait time';
$txt['edit_disable_time'] = 'Maximum time after posting to allow edit';
$txt['edit_disable_time_zero'] = '0 to disable';
$txt['preview_characters'] = 'Maximum length of last/first post preview';
$txt['preview_characters_units'] = 'characters';
$txt['preview_characters_zero'] = '0 to show the entire message';
$txt['message_index_preview'] = 'Show post previews on the message index';
$txt['message_index_preview_off'] = 'Do not show the previews';
$txt['message_index_preview_first'] = 'Show the text of the first post';
$txt['message_index_preview_last'] = 'Show the text of the last post';

$txt['enableBBC'] = 'Enable bulletin board code (BBC)';
$txt['enablePostHTML'] = 'Enable <em>basic</em> HTML in posts';
$txt['autoLinkUrls'] = 'Automatically link posted URLs';
$txt['disabledBBC'] = 'Enabled BBC tags';
$txt['bbcTagsToUse'] = 'Enabled BBC tags';
$txt['bbcTagsToUse_select'] = 'Select the tags allowed to be used';
$txt['bbcTagsToUse_select_all'] = 'Select all tags';

$txt['enableParticipation'] = 'Enable participation icons';
$txt['enableFollowup'] = 'Enable followups';
$txt['enable_unwatch'] = 'Enable unwatching of topics';
$txt['oldTopicDays'] = 'Time before topic is warned as old on reply';
$txt['oldTopicDays_zero'] = '0 to disable';
$txt['defaultMaxTopics'] = 'Number of topics per page in the message index';
$txt['defaultMaxMessages'] = 'Number of posts per page in a topic page';
$txt['disable_print_topic'] = 'Disable print topic feature';
$txt['hotTopicPosts'] = 'Number of posts for a hot topic';
$txt['hotTopicVeryPosts'] = 'Number of posts for a very hot topic';
$txt['useLikesNotViews'] = 'Use number of likes in place of posts to define hot topics';
$txt['enableAllMessages'] = 'Max topic size to show &quot;All&quot; posts';
$txt['enableAllMessages_zero'] = '0 to never show &quot;All&quot;';
$txt['disableCustomPerPage'] = 'Disable user defined topic/message count per page';
$txt['enablePreviousNext'] = 'Enable previous/next topic links';

$txt['not_done_title'] = 'Not done yet';
$txt['not_done_reason'] = 'To avoid overloading your server, the process has been temporarily paused.  It should automatically continue in a few seconds.  If it doesn\'t, please click continue below.';
$txt['not_done_continue'] = 'Pokračovat';

$txt['general_settings'] = 'Základní konfigurace';
$txt['database_paths_settings'] = 'Databáze';
$txt['cookies_sessions_settings'] = 'Kookies a relace';
$txt['caching_settings'] = 'Vyrovnávací pamět';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'Info o PHP';
$txt['phpinfo_localsettings'] = 'Lokální nastavení';
$txt['phpinfo_defaultsettings'] = 'Výchozí nastavení';
$txt['phpinfo_itemsettings'] = 'Nastavení';

$txt['language_configuration'] = 'Jazyky';
$txt['language_description'] = 'This section allows you to edit languages installed on your forum or download new ones from the ElkArte site. You may also edit language-related settings here.';
$txt['language_edit'] = 'Upravit jazyk';
$txt['language_add'] = 'Přidat jazyk';
$txt['language_settings'] = 'Nastavení';

$txt['advanced'] = 'Advanced';
$txt['simple'] = 'Simple';

$txt['admin_news_select_recipients'] = 'Please select who should receive a copy of the newsletter';
$txt['admin_news_select_group'] = 'Skupiny';
$txt['admin_news_select_group_desc'] = 'Select the groups to receive this newsletter.';
$txt['admin_news_select_members'] = 'Prohlížet/Mazat uživatele';
$txt['admin_news_select_members_desc'] = 'Additional members to receive the newsletter.';
$txt['admin_news_select_excluded_members'] = 'Excluded Members';
$txt['admin_news_select_excluded_members_desc'] = 'Members who should not receive the newsletter.';
$txt['admin_news_select_excluded_groups'] = 'Excluded Groups';
$txt['admin_news_select_excluded_groups_desc'] = 'Select groups who should definitely not receive the newsletter.';
$txt['admin_news_select_email'] = 'Email Addresses';
$txt['admin_news_select_email_desc'] = 'A semi-colon separated list of email addresses which should be sent this newsletter. (i.e. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Override notification settings';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'You cannot send a personal message to an email address. If you continue all entered email addresses will be ignored.\\n\\nAre you sure you wish to do this?';

$txt['mailqueue_browse'] = 'Browse Queue';
$txt['mailqueue_settings'] = 'Nastavení';

$txt['admin_search'] = 'Rychlé hledání';
$txt['admin_search_type_internal'] = 'Task/Setting';
$txt['admin_search_type_member'] = 'Uživatel';
$txt['admin_search_type_online'] = 'Online manuál';
$txt['admin_search_go'] = 'Jít';
$txt['admin_search_results'] = 'Search Results';
$txt['admin_search_results_desc'] = 'Results for search: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Search again';
$txt['admin_search_results_none'] = 'No results found.';

$txt['admin_search_section_sections'] = 'Sekce';
$txt['admin_search_section_settings'] = 'Nastavení';

$txt['core_settings_title'] = 'Základní funkce';
$txt['core_settings_desc'] = 'Tato stránka umožňuje zapnout nebo vypnout základní volitelné funkce vašeho fóra.';
$txt['mods_cat_features'] = 'Základní konfigurace';
$txt['mods_cat_security_general'] = 'Základní konfigurace';
$txt['antispam_title'] = 'Antispam';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Miscellaneous';
$txt['mods_cat_layout'] = 'Layout';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderace';
$txt['signature_settings_short'] = 'Podpisy';
$txt['custom_profile_shorttitle'] = 'Profilová pole';
$txt['pruning_title'] = 'Log Pruning';

$txt['core_settings_activation_message'] = 'The feature {core_feature} has been activated, click on the title to configure it';
$txt['core_settings_deactivation_message'] = 'The feature {core_feature} has been deactivated';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Modify Boards';
$txt['mboards_new_cat'] = 'Vytvořit novou kategorii';
$txt['manage_holidays'] = 'Spravovat svátky';
$txt['calendar_settings'] = 'Nastavení kalendáře';
$txt['search_weights'] = 'Weights';
$txt['search_method'] = 'Search Method';
$txt['search_sphinx'] = 'Configure Sphinx';

$txt['smiley_sets'] = 'Smiley Sets';
$txt['smileys_add'] = 'Přidat smajlíky';
$txt['smileys_edit'] = 'Upravovat smajlíky';
$txt['smileys_set_order'] = 'Set Smiley order';
$txt['icons_edit_message_icons'] = 'Edit message icons';

$txt['membergroups_new_group'] = 'Přidat skupinu';
$txt['membergroups_edit_groups'] = 'Upravovat skupiny';
$txt['permissions_groups'] = 'Hlavní oprávnění ';
$txt['permissions_boards'] = 'Oprávnění fóra';
$txt['permissions_profiles'] = 'Spravovat profily';
$txt['permissions_post_moderation'] = 'Moderování příspěvků';

$txt['browse_packages'] = 'Procházet rozšíření';
$txt['download_packages'] = 'Stáhnout rozšíření';
$txt['upload_packages'] = 'Nahrát rozšíření';
$txt['installed_packages'] = 'Instalovaná rozšíření';
$txt['package_file_perms'] = 'Oprávnění souborů';
$txt['package_settings'] = 'Nastavení';
$txt['package_servers'] = 'Rozšíření na serveru / vlastní URL ';
$txt['themeadmin_admin_title'] = 'Spravovat nebo instalovat';
$txt['themeadmin_list_title'] = 'Nastavení vzhledu';
$txt['themeadmin_reset_title'] = 'Možnosti uživatelů';
$txt['themeadmin_edit_title'] = 'Upravovat vzhledy';
$txt['admin_browse_register_new'] = 'Registrace uživatelů';

$txt['search_engines'] = 'Search Engines';
$txt['spider_logs'] = 'Záznamy robotů';
$txt['spider_stats'] = 'Statistiky';

$txt['paid_subscriptions'] = 'Placené odběry';
$txt['paid_subs_view'] = 'Zobrazit předplacené';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks';
$txt['hooks_field_hook_name'] = 'Hook Name';
$txt['hooks_field_function_name'] = 'Název funkce';
$txt['hooks_field_function'] = 'Funkce';
$txt['hooks_field_included_file'] = 'Včetně souboru';
$txt['hooks_field_file_name'] = 'Název souboru';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Existuje';
$txt['hooks_disabled'] = 'Vypnout'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Nenalezeno';
$txt['hooks_no_hooks'] = 'There are currently no hooks in the system.';
$txt['hooks_disable_legend'] = 'Legenda';
$txt['hooks_disable_legend_exists'] = 'the hook exists and is active';
$txt['hooks_disable_legend_disabled'] = 'the hook exists but has been disabled';
$txt['hooks_disable_legend_missing'] = 'the hook has not been found';
$txt['hooks_reset_filter'] = 'Zrušit filtr';

$txt['board_perms_allow'] = 'Povolit';
$txt['board_perms_ignore'] = 'Ignorovat';
$txt['board_perms_deny'] = 'Zakázat';
$txt['all_boards_in_cat'] = 'All boards in this category';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Words separator';

$txt['admin_order_title'] = 'Ordering Error';
$txt['admin_order_error'] = 'An unknown error occurred while processing your request';

// Known controllers that can work on the front page
$txt['default'] = 'Výchozí';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
