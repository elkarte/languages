<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Na této stránce můžete konfigurovat nastavení e-mailu nebo prohlížet a spravovat aktuální frontu pošty, pokud je povolena.';
$txt['mail_settings'] = 'Nastavení e-mailu';

$txt['mail_type'] = 'Typ e-mailu';
$txt['mail_type_default'] = '(výchozí volba PHP)';
$txt['smtp_host'] = 'Server SMTP';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'Port SMTP';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'Uživatel SMTP';
$txt['smtp_password'] = 'Heslo SMTP';

$txt['mail_queue'] = 'Zapnout frontu pošty';
$txt['mail_period_limit'] = 'Maximální počet odeslaných e-mailů za minutu';
$txt['mail_period_limit_desc'] = '(Nastavením na 0 vypnete)';
$txt['mail_batch_size'] = 'Maximální počet odesílaných e-mailů na jedno načtení stránky';

$txt['mailqueue_stats'] = 'Statistika fronty pošty';
$txt['mailqueue_oldest'] = 'Nejstarší pošta';
$txt['mailqueue_oldest_not_available'] = 'N/A';
$txt['mailqueue_size'] = 'Délka fronty';

$txt['mailqueue_age'] = 'Věk';
$txt['mailqueue_priority'] = 'Priorita';
$txt['mailqueue_recipient'] = 'Příjemce';
$txt['mailqueue_subject'] = 'Předmět';
$txt['mailqueue_clear_list'] = 'Poslat poštovní frontu nyní';
$txt['mailqueue_no_items'] = 'Fronta pošty je momentálně prázdná';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Opravdu chcete nyní poslat celou frontu pošty ? Tímto bude přeskočeno jakékoliv omezení, které jste nastavili.';

$txt['mq_day'] = '%1.1f den';
$txt['mq_days'] = '%1.1f dny';
$txt['mq_hour'] = '%1.1f hodina';
$txt['mq_hours'] = '%1.1f hodin';
$txt['mq_minute'] = '%1$d minuta';
$txt['mq_minutes'] = '%1$d minut';
$txt['mq_second'] = '%1$d sekunda';
$txt['mq_seconds'] = '%1$d sekund';

$txt['mq_mpriority_5'] = 'Velmi nízká';
$txt['mq_mpriority_4'] = 'Nízká';
$txt['mq_mpriority_3'] = 'Normální';
$txt['mq_mpriority_2'] = 'Vysoká';
$txt['mq_mpriority_1'] = 'Velmi vysoká';

$txt['birthday_email'] = 'Zpráva k narozeninám k použití';
$txt['birthday_body'] = 'Tělo e-mailu';
$txt['birthday_subject'] = 'Předmět e-mailu';