<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Přivítání a prvotní informace';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Kontrola souborů pro zápis';
$txt['install_step_forum'] = 'Nastavení fóra';
$txt['install_step_databaseset'] = 'Nastavení databáze';
$txt['install_step_databasechange'] = 'Vytvoření DB tabulek a naplnění';
$txt['install_step_admin'] = 'Účet administrátora';
$txt['install_step_delete'] = 'Dokončení instalace';

$txt['installer'] = 'Instalace systému ElkArte';
$txt['installer_language'] = 'Jazyk';
$txt['installer_language_set'] = 'Nastavit';
$txt['congratulations'] = 'Gratulujeme, proces instalace je kompletně dokončen !';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Váš instalační adresář na Vašem FTP je stále zapisovatelný. Je dobré mu nastavit chmod právo, aby nebyl z bezpečnostních důvodů zapisovatelný.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(nefunguje na všech serverech.)</em>';
$txt['go_to_your_forum'] = 'Nyní se již můžete podívat na <a href="%1$s">Vaše nově nainstalované fórum</a> a začít ho ihned používat. Nejprve se ujistěte, že jste přihlášeni, poté budete mít přístup do administračního centra Vašeho fóra.';
$txt['good_luck'] = 'Děkujeme Vám za instalaci systému ElkArte !';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Přivítání a prvotní informace';
$txt['install_welcome_desc'] = 'Vítejte u instalace. Tento skript Vás provede procesem instalace systému ElkArte verze %1$s, který je plně lokalizován do českého jazyka. Během následujících kroků instalačního procesu získáme několik podrobností o Vašem serveru, budoucím fóru a po několika minutách bude Vaše fórum plně připraveno k použití.';
$txt['install_all_lovely'] = 'Na Vašem serveru jsme automaticky dokončili nějaké potřebné počáteční testy a vše vypadá, že je v pořádku a připraveno pro systém ElkArte. Chcete li se tedy pustit do samotné instalace, jednoduše klikněte na tlačítko Pokračovat a začněte.';

$txt['user_refresh_install'] = 'Stránka byla obnovena !';
$txt['user_refresh_install_desc'] = 'Během instalace došlo k obnovení stránky a instalační script (s podrobnostmi, které jste zadali) zjistil jednu nebo více tabulek, které již byly vytvořeny.<br />Všechny chybějící tabulky byly zároveň ve Vaší instalaci vytvořeny s výchozími údaji, ale z existujících tabulek nebyla odstraněna žádná data..';

$txt['default_topic_subject'] = 'Vítejte v ElkArte !';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Obecná diskuse';
$txt['default_board_description'] = 'Nebojte se mluvit o čemkoliv.';
$txt['default_category_name'] = 'Hlavní kategorie';
$txt['default_time_format'] = '%B %d, %Y, %I:%M:%S %p ';
$txt['default_news'] = 'ElkArte - Právě nainstalováno !';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[zrušit]';
$txt['default_karmaApplaudLabel'] = '[tleskat]';
$txt['default_reserved_names'] = 'Admin\nWebmaster\nHost\nroot';
$txt['default_smileyset_name'] = 'Fugova sada';
$txt['default_theme_name'] = 'ElkArte výchozí vzhled';

$txt['default_administrator_group'] = 'Administrátor';
$txt['default_global_moderator_group'] = 'Global moderátor';
$txt['default_moderator_group'] = 'Moderátor';
$txt['default_newbie_group'] = 'Nováček';
$txt['default_junior_group'] = 'Mladší člen';
$txt['default_full_group'] = 'Plný člen';
$txt['default_senior_group'] = 'Starší člen';
$txt['default_hero_group'] = 'Superčlen';

$txt['default_smiley_smiley'] = 'Úsměv';
$txt['default_wink_smiley'] = 'Mrknutí';
$txt['default_cheesy_smiley'] = 'Smích';
$txt['default_grin_smiley'] = 'Škleb';
$txt['default_angry_smiley'] = 'Hněv';
$txt['default_sad_smiley'] = 'Smutek';
$txt['default_shocked_smiley'] = 'Šok';
$txt['default_cool_smiley'] = 'Skvělé';
$txt['default_huh_smiley'] = 'Co ?';
$txt['default_roll_eyes_smiley'] = 'Kroutím očima';
$txt['default_tongue_smiley'] = 'Vyplazuji jazyk';
$txt['default_embarrassed_smiley'] = 'Jsem v rozpacích';
$txt['default_lips_sealed_smiley'] = 'Neřeknu';
$txt['default_undecided_smiley'] = 'Nerozhodný';
$txt['default_kiss_smiley'] = 'Polibek';
$txt['default_cry_smiley'] = 'Pláč';
$txt['default_evil_smiley'] = 'Zlý';
$txt['default_azn_smiley'] = 'I ty';
$txt['default_afro_smiley'] = 'Afro účes';
$txt['default_laugh_smiley'] = 'Smích';
$txt['default_police_smiley'] = 'Policie';
$txt['default_angel_smiley'] = 'Anděl';

$txt['error_message_click'] = 'Klikněte zde';
$txt['error_message_try_again'] = 'pro zopakování tohoto kroku.';
$txt['error_message_bad_try_again'] = 'pro pokračování v instalaci, ale měj na paměti že to není <em>doporučeno</em>.';

$txt['install_settings'] = 'Nastavení fóra';
$txt['install_settings_info'] = 'Tato stránka vyžaduje, abyste definovali několik klíčových nastavení pro Vaše fórum. Instalační script systému ElkArte pro Vás již tato klíčová nastavení automaticky detekoval.';
$txt['install_settings_name'] = 'Název fóra';
$txt['install_settings_name_info'] = 'Toto je název Vašeho fóra, například &quot;Moje Testovací Fórum&quot;.';
$txt['install_settings_name_default'] = 'Komunita';
$txt['install_settings_url'] = 'URL adresa fóra';
$txt['install_settings_url_info'] = 'Toto je adresa URL Vašeho fóra <strong>bez  znaku lomítka \'/\' na konci !</strong>.<br />Ve většině případů můžete v tomto poli ponechat výchozí hodnotu - obvykle je to správně.';
$txt['install_settings_compress'] = 'Gzip výstup';
$txt['install_settings_compress_title'] = 'Komprimovat výstup pro uložení šířky pásma.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Tato funkce nefunguje správně na všech serverech, přesto Vám může ušetřit hodně šířky pásma.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Klepnutím sem můžete tuto funkci otestovat</a>. (Pokud funguje správně, objeví se slovo "PASS".)';
$txt['install_settings_dbsession'] = 'Relace databáze';
$txt['install_settings_dbsession_title'] = 'Použít pro databázi relace namísto použití souborů.';
$txt['install_settings_dbsession_info1'] = 'Tato funkce je téměř vždy nejlepší, protože relace jsou mnohem spolehlivější.';
$txt['install_settings_dbsession_info2'] = 'Tato funkce je obecně dobrý nápad, ale na tomto serveru nemusí pracovat správně.';
$txt['install_settings_proceed'] = 'Pokračovat';

$txt['db_settings'] = 'Nastavení databázového serveru';
$txt['db_settings_info'] = 'Jedná se o nastavení, které chcete použít pro Váš databázový server. Pokud tyto informace neznáte, měli byste se obrátit na svého poskytovatele hostingových služeb a požádat ho, aby Vám tyto informace sdělil.';
$txt['db_settings_type'] = 'Typ databáze';
$txt['db_settings_type_info'] = 'Bylo zjištěno více typů podporovaných databází - který z nich chcete použít ?';
$txt['db_settings_server'] = 'Jméno serveru';
$txt['db_settings_server_info'] = 'Téměř vždy je zpravidla použit localhost - pokud jméno serveru neznáte, zkuste ponechat localhost.';
$txt['db_settings_port'] = 'Port běhu databáze';
$txt['db_settings_port_info'] = 'Pokud Váš server naslouchá na výchozím portu nebo si nejste jisti, ponechte pole prázdné.';
$txt['db_settings_username'] = 'Uživatel databáze';
$txt['db_settings_username_info'] = 'Zde vyplňte uživatelské jméno, které potřebujete připojit k Vaší databázi.<br />Pokud ho neznáte, vyzkoušejte uživatelské jméno Vašeho FTP účtu, nejčastěji jsou tyto uživatelská jména stejná.';
$txt['db_settings_password'] = 'Opakovat heslo ';
$txt['db_settings_password_info'] = 'Zde byste měli zadat heslo, které potřebujete k připojení k Vaší databázi.<br />Pokud ho neznáte, vyzkoušejte heslo Vašemu FTP účtu.';
$txt['db_settings_database'] = 'Název databáze';
$txt['db_settings_database_info'] = 'Vyplňte název databáze, kterou chcete použít a do které se budou ukládat data.';
$txt['db_settings_database_info_note'] = 'Pokud databáze neexistuje, instalační script se jí pokusí vytvořit.';
$txt['db_settings_database_file'] = 'Název databázového souboru';
$txt['db_settings_database_file_info'] = 'Toto je název souboru, který bude využit pro ukládání dat ElkArte fóra. Je doporučeno použít náhodně generovaný název a nastavit cesty na svůj webový server.';
$txt['db_settings_prefix'] = 'Předpona tabulek';
$txt['db_settings_prefix_info'] = 'Předpona pro každou tabulku v databázi. <strong>Neinstalujte dvě fóra se stejnou předponou !</strong><br />Tato hodnota umožňuje více instalací v jedné databázi.';
$txt['db_populate'] = 'Vytvoření DB tabulek a naplnění';
$txt['db_populate_info'] = 'Vaše nastavení byla nyní uložena a databáze byla naplněna všemi údaji potřebnými k tomu, aby Vaše fórum fungovalo. Výsledek je zobrazen níže:';
$txt['db_populate_info2'] = 'Klikněte na tlačítko &quot;Pokračovat&quot; pro přechod na další stránku k vytváření účtu administrátora.';
$txt['db_populate_inserts'] = 'Bylo vloženo %1$d řádků.';
$txt['db_populate_tables'] = 'Bylo vytvořeno %1$d tabulek.';
$txt['db_populate_insert_dups'] = 'Bylo ignorováno %1$d duplicitních záznamů.';
$txt['db_populate_table_dups'] = 'Bylo ignorováno %1$d duplicitních tabulek.';

$txt['user_settings'] = 'Vytvořte svůj účet';
$txt['user_settings_info'] = 'Instalační script pro Vás nyní vytvoří nový účet administrátora.';
$txt['user_settings_username'] = 'Vaše jméno';
$txt['user_settings_username_info'] = 'Zvolte uživatelské jméno, se kterým se budete přihlašovat.';
$txt['user_settings_password'] = 'Opakovat heslo ';
$txt['user_settings_password_info'] = 'Zde vyplňte své preferované heslo a pečlivě si jej zapamatujte !';
$txt['user_settings_again'] = 'Opakovat heslo ';
$txt['user_settings_again_info'] = '(slouží výhradně jen pro ověření.)';
$txt['user_settings_email'] = 'Email';
$txt['user_settings_email_info'] = 'Zadejte svoji e-mailovou adresu. <strong>Zadaná e-mailová adresa musí být platná.</strong>';
$txt['user_settings_database'] = 'Heslo databáze';
$txt['user_settings_database_info'] = 'Instalační script vyžaduje, abyste z bezpečnostních důvodů pro vytvoření účtu administrátora zadali do pole níže i platné heslo k Vaší databázi.';
$txt['user_settings_skip'] = 'Přeskočit';
$txt['user_settings_skip_sure'] = 'Opravdu chcete přeskočit vytvoření účtu administrátora ?';
$txt['user_settings_proceed'] = 'Dokončit';

$txt['ftp_checking_writable'] = 'Prověření souborů na práva zápisu';
$txt['ftp_setup'] = 'Informace o FTP připojení';
$txt['ftp_setup_info'] = 'Tento nástroj nyní vyžaduje vyplnění přihlašovacích údajů k Vašemu FTP serveru. Upozornění: Tato funkce nepodporuje SSL.';
$txt['ftp_server'] = 'Jméno serveru';
$txt['ftp_server_info'] = 'To by měl být server a port Vašeho FTP připojení.';
$txt['ftp_port'] = 'Port běhu databáze';
$txt['ftp_username'] = 'Uživatel databáze';
$txt['ftp_username_info'] = 'Uživatelské jméno pro přihlášení. <em>Nebude nikde ukládáno.</em>';
$txt['ftp_password'] = 'Opakovat heslo ';
$txt['ftp_password_info'] = 'Heslo pro přihlášení. <em>Nebude nikde ukládáno.</em>';
$txt['ftp_path'] = 'Instalační cesta';
$txt['ftp_path_info'] = 'Toto je <em>relativní</em> cesta která bude použita na FTP serveru.';
$txt['ftp_path_found_info'] = 'Cesta v poli výše byla automaticky detekována.';
$txt['ftp_connect'] = 'Připojit';
$txt['ftp_setup_why'] = 'K čemu je tento krok ?';
$txt['ftp_setup_why_info'] = 'Pro správnou funkci ElkArte je potřeba, aby některé složky a soubory zůstaly otevřené pro zápis. Instalátor by měl být schopen toto nastavit automaticky. Ovšem pokud by se tak nestalo, je třeba nastavit CHMOD uvedených souborů a složek ručně na 777 (zapisovatelné, 755 u některých hostitelů):';
$txt['ftp_setup_again'] = 'pro otestování zda jsou soubory otevřeny pro zápis.';

$txt['error_php_too_low'] = 'Varování ! Zdá se, že na Vašem serveru není nainstalována verze PHP, která vyhovuje <strong>minimálním instalačním požadavkům</strong>.<br />Pokud nejste provozovatelem serveru, budete muset svého poskytovatele služeb požádat o upgrade, nebo najít jiného poskytovatele služeb, který tuto verzi PHP podporuje. V opačném případě prosíme o upgrade PHP na poslední verzi.<br /><br /> Pokud si myslíte, že máte dostatečnou verzi PHP, můžete přesto v instalaci pokračovat, nicméně se to nedoporučuje.';
$txt['error_missing_files'] = 'V adresářích skriptu nelze najít potřebné instalační soubory !<br /><br />Ujistěte se prosím, že jste nahráli celý instalační balíček včetně sql souboru a zkuste to znovu.';
$txt['error_session_save_path'] = 'Prosím informujte svého poskytovatele serveru že <strong>session.save_path specifikovaná v php.ini</strong> není platná ! Musí být změněna na adresář, který <strong>existuje</strong>, a který je <strong>zapisovatelný</strong> uživatelem, pod kterým PHP běží.';
$txt['error_windows_chmod'] = 'Jste na serveru s OS Windows a některé kritické soubory nejsou otevřeny pro zápis. Prosíme, požádejte svého poskytovatele služeb, aby dal pro Vaše instalační soubory </strong>oprávnění k zápisu</strong> uživateli, pod kterým PHP běží. Následující soubory a adresáře musí být zapisovatelné:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Pomocí těchto údajů se nelze k FTP serveru připojit.';
$txt['error_db_file'] = 'Litujeme, ale nelze najít databázový zdrojový skript ! Prosím prověřte soubor %1$s, který je ve Vašem fóru ve zdrojovém adresáři.';
$txt['error_db_connect'] = 'Nelze se připojit k databázovému serveru pomocí vložených dat.<br /><br />Pokud si nejste jisti správností údajů, obraťte se na svého poskytovatele.';
$txt['error_db_too_low'] = 'Verze databázového serveru je příliš stará a nesplňuje minimální požadavky systému ElkArte.<br /><br />Prosím informujte svého poskytovatele služeb, aby provedl upgrade databázového serveru, nebo prosím zkuste najít jiného poskytovatele služeb.';
$txt['error_db_database'] = 'Instalační script nemohl získat přístup k &quot;<em>%1$s</em>&quot; databázi. U některých poskytovatelů musíte ve Vašem ovládacím panelu nejprve databázi vytvořit, než ji systém ElkArte použije. Někdy je taktéž k názvu Vaší databáze přidána předpona s Vaším uživatelským jménem.';
$txt['error_db_queries'] = 'Některé dotazy nebyly správně provedeny. Může to být způsobeno nepodporovanou (vývojovou nebo starou) verzí vašeho databázového softwaru.<br /><br />Technické informace o proběhlých dotazech:';
$txt['error_db_queries_line'] = 'Řádek #';
$txt['error_db_missing'] = 'Instalační script nemohl zjistit podporu databází v PHP, kterou ElkArte může využít. Požádejte svého poskytovatele služeb, aby se ujistil, že bylo PHP kompilováno s požadovanou databází nebo zda je načteno správné php rozšíření. V současné době ElkArte podporuje:
&quot;%1$s&quot; rozšíření';
$txt['error_db_script_missing'] = 'Instalační script nemohl najít instalační soubory. Zkontrolujte prosím, zda jste nahráli potřebné soubory skriptu do adresáře Vašeho fóra. Například &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Instalační skript nenašel v instalaci PHP na tomto serveru podporu relací. Zeptejte se svého poskytovatele služeb, zda má jeho PHP skutečně podporu relací (ve skutečnosti musí být podpora relací při kompilaci explicitně zakázána.)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Zadali jste dvě zcela odlišná hesla !';
$txt['error_user_settings_no_password'] = 'Vaše heslo musí obsahovat minimálně 4 znaky.';
$txt['error_user_settings_taken'] = 'Litujeme, ale s tímto uživatelským jménem nebo e-mailovou adresou se již někdo registroval.<br /><br />Nový účet nebyl vytvořen.';
$txt['error_user_settings_query'] = 'Při vytváření účtu administrátora došlo k chybě v databázi. Chybou je:';
$txt['error_subs_missing'] = 'V adresáři Sources nelze najít soubor Subs.php. Ujistěte se, že byl správně nahrán, a zkuste to znovu.';
$txt['error_db_alter_priv'] = 'Litujeme, ale ve zvolené databázi nemáte u tabulek oprávnění k příkazům ALTER, CREATE nebo DROP. Toto oprávnění je potřebné ke správné funkci systému ElkArte.';
$txt['error_versions_do_not_match'] = 'Instalační skript našel jinou verzi systému ElkArte, která používá tato nastavení. Pokud se snažíte o aktualizaci, nepoužívejte instalační skript, ale upgrade balíček.<br /><br />V opačném případě použijte jiná nastavení, nebo proveďte zálohu a smažte data ze současné databáze.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'Aktuální verze databáze nepodporuje použití znakové sady UTF-8. Systém ElkArte nemůžete bohužel nainstalovat.';
$txt['error_valid_email_needed'] = 'Nezadali jste platnou e-mailovou adresu.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Varování !';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Musíte zadat název databázového souboru pro SQLite.';
$txt['error_db_prefix_numeric'] = 'Zvolený typ databáze nepodporuje používání číselných předpon.';
$txt['error_invalid_characters_username'] = 'Neplatný znak v uživatelském jméně.';
$txt['error_username_too_long'] = 'Uživatelské jméno musí být kratší než 25 znaků.';
$txt['error_username_left_empty'] = 'Pole pro uživatelské jméno je prázdné.';
$txt['error_db_filename_exists'] = 'Databáze, kterou se snažíte vytvořit, již existuje. Smažte prosím aktuální databázový soubor nebo zadejte jiný název.';
$txt['error_db_prefix_reserved'] = 'Zvolené předpony jsou vyhrazeny. Prosím zadejte jinou předponu.';

$txt['upgrade_upgrade_utility'] = 'Utility pro ElkArte upgrade';
$txt['upgrade_warning'] = 'Varování !';
$txt['upgrade_critical_error'] = 'Kritická chyba !';
$txt['upgrade_continue'] = 'Pokračovat';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Přeskočit';
$txt['upgrade_note'] = 'Upozornit !';
$txt['upgrade_step'] = 'Krok';
$txt['upgrade_steps'] = 'Kroky';
$txt['upgrade_progress'] = 'Jednotlivé kroky instalace';
$txt['upgrade_overall_progress'] = 'Celkový postup instalace';
$txt['upgrade_step_progress'] = 'Krok postupu';
$txt['upgrade_time_elapsed'] = 'Uplynulý čas';
$txt['upgrade_time_mins'] = 'minut';
$txt['upgrade_time_secs'] = 'sekund';

$txt['upgrade_incomplete'] = 'Nekompletní';
$txt['upgrade_not_quite_done'] = 'Ještě není konec !';
$txt['upgrade_paused_overload'] = 'Tento upgrade byl pozastaven, aby se zabránilo přetížení serveru. Nemusíte se ničeho bát, opravdu nic není špatně - pro pokračování v upgradu jednoduše klikněte na tlačítko <label for="contbutt">pokračovat</label>.';

$txt['upgrade_ready_proceed'] = 'Děkujeme, že jste si vybrali upgrade na ElkArte %1$s. Všechny soubory se zdají být v naprostém pořádku, tedy můžeme pokračovat dále.';

$txt['upgrade_error_script_js'] = 'Upgradovací skript nemůže najít soubor script.js nebo je tento soubor zastaralý. Ujistěte se, že jsou nastaveny správné cesty. Na stránkách ElkArte komunity můžete stáhnout <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">nástroj pro nastavení</a>.';

$txt['upgrade_warning_lots_data'] = 'Upgradovací skript zjistil, že Váše fórum obsahuje velké množství údajů, které potřebují modernizaci. Tento proces může trvat poměrně dlouhou dobu v závislosti na Vašem serveru a velikosti fóra. Na velmi velkých fórech (~ 300,000 tisíc zpráv) může upgrade trvat i několik hodin.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';