<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Výchozí vzhled ElkArte.<br /><br /> Autor: Přispěvatelé ElkArte';