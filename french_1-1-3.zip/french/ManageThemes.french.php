<?php
// Version: 1.1; ManageThemes

$txt['themeadmin_explain'] = 'Les thèmes créent les différentes apparences de votre forum. La section globale Gestion des thèmes permet à tout administrateur de site de sélectionner un thème par défaut pour le forum. Les administrateurs peuvent également permettre aux membres d\'utiliser n\'importe quel thème installé pour leur utilisation et activer des thèmes sélectionnables. La section Installer un nouveau thème explique comment un administrateur du site installe un thème.';
$txt['themeadmin_manage'] = 'Gérer et Installer';
$txt['theme_forum_theme'] = 'Réglages du thème';
$txt['theme_allow'] = 'Autoriser les membres à choisir leur propre thème.';
$txt['theme_guests'] = 'Thème général par défaut du forum :';
$txt['theme_select'] = 'choisir...';
$txt['theme_reset'] = 'Réinitialiser tous les membres avec le thème suivant :';
$txt['theme_nochange'] = 'Aucun changement';
$txt['theme_forum_default'] = 'Thème par défaut';

$txt['theme_remove'] = 'Désinstaller';
$txt['theme_remove_confirm'] = 'Êtes-vous sûr de vouloir désinstaller ce thème ?';

$txt['theme_install'] = 'Installer un nouveau thème';
$txt['theme_install_file'] = 'Depuis une archive locale : (par exemple .zip ou .tar ou .gz) ';
$txt['theme_install_dir'] = 'Depuis un répertoire du serveur : ';
$txt['theme_install_error'] = 'Ce dossier de thème n\'existe pas, ou ne contient pas un thème ! ';
$txt['theme_install_write_error'] = 'Le dossier des thèmes ne doivent pas être en lecture seule pour continuer ! ';
$txt['theme_install_go'] = 'Installer';
$txt['theme_install_new'] = 'Créer une copie du thème par défaut de ElKarte nommée : ';
$txt['theme_install_new_confirm'] = 'Êtes-vous sûr de vouloir installer ce nouveau thème ?';
$txt['theme_install_writable'] = 'Attention - vous ne pouvez pas créer ou installer un nouveau thème car votre dossier de thèmes est en lecture seule ! ';
$txt['theme_install_general'] = 'Le thème ne semble pas être là où il devrait, veuillez vérifier les informations que vous avez fournies. ';
$txt['theme_installed'] = 'Installé avec succès';
$txt['theme_installed_message'] = 'a été installé avec succès.';

$txt['theme_pick'] = 'Choisir un thème...';
$txt['theme_preview'] = 'Prévisualiser ce thème';
$txt['theme_set'] = 'Utiliser ce thème';
$txt['theme_user'] = 'personne utilise ce thème.';
$txt['theme_users'] = 'personnes utilisent ce thème.';
$txt['theme_pick_variant'] = 'Choisir une Variante : ';

$txt['theme_edit'] = 'Modifier un Thème';
$txt['theme_edit_style'] = 'Modifier les feuilles de style (couleurs, polices, etc.)';
$txt['theme_edit_index'] = 'Modifier index.template.php (le template principal)';
$txt['theme_edit_no_save'] = 'Ce fichier ne peut pas être sauvegardé parce qu\'il n\'est pas accessible en écriture ! Veuillez vous assurer que le fichier suivant possède les droits 777 ou les permissions suffisantes ';
$txt['theme_edit_save'] = 'Sauvegarder les changements';
$txt['theme_edit_not_writable'] = 'Non Inscriptible';

$txt['theme_global_description'] = 'Ceci est le thème par défaut, ce qui signifie que votre thème changera suivant les paramètres de l\'administrateur et le forum que vous consultez.';

$txt['theme_url_config'] = 'URLs et Configuration du Thème';
$txt['theme_variants'] = 'Variantes du Thème';
$txt['theme_options'] = 'Options et Préférences du Thème';
$txt['actual_theme_name'] = 'Nom de ce thème&nbsp;: ';
$txt['actual_theme_dir'] = 'Répertoire de ce thème&nbsp;: ';
$txt['actual_theme_url'] = 'URL de ce thème&nbsp;: ';
$txt['actual_images_url'] = 'URL des images de ce thème&nbsp;: ';

$txt['theme_variants_default'] = 'Variante par défaut du thème : ';
$txt['theme_variants_user_disable'] = 'Empêcher les utilisateurs de choisir une variante';

$txt['site_slogan'] = 'Slogan du site : ';
$txt['site_slogan_desc'] = '(Ajoutez votre propre texte pour un slogan ici.) ';
$txt['header_layout'] = 'Disposition de l\'en-tête : ';
$txt['header_layout_desc'] = '(Ce paramètre vous permet de sélectionner l\'une des trois mises en page pour l\'en-tête.) ';
$txt['header_layout_default_name'] = 'Par défaut : ';
$txt['header_layout_default_desc'] = 'Le logo est placé à droite et le nom du forum à gauche. ';
$txt['header_layout_logo_only_name'] = 'Seulement le logo : ';
$txt['header_layout_logo_only_desc'] = 'Seul le logo est affiché au centre. ';
$txt['header_layout_inverted_name'] = 'Logo à gauche : ';
$txt['header_layout_inverted_desc'] = 'Similaire à Par défaut, mais avec le logo et le nom inversés (c\'est-à-dire le nom à droite, le logo à gauche). ';
$txt['header_layout_default'] = 'Défaut';
$txt['header_layout_logo_only'] = 'Seulement le logo ';
$txt['header_layout_inverted'] = 'Logo à gauche ';
$txt['forum_width'] = 'Largeur du forum : ';
$txt['forum_width_desc'] = '(Définit la largeur du forum. Exemples: 950px, 80%, 1240px.) ';

$txt['enable_news'] = 'Ligne de nouvelles dans l\'en-tête du forum : ';
$txt['enable_news_off'] = 'Désactivé ';
$txt['enable_news_random'] = 'Aléatoire ';
$txt['enable_news_fader'] = 'Fondu ';
$txt['enable_news_off_name'] = 'Désactivé : ';
$txt['enable_news_off_desc'] = 'Pas de nouvelles affichées. ';
$txt['enable_news_random_name'] = 'Aléatoire : ';
$txt['enable_news_random_desc'] = 'Une nouvelle affichée choisie au hasard. ';
$txt['enable_news_fader_name'] = 'Fondu : ';
$txt['enable_news_fader_desc'] = 'Toutes les actualités sont affichées séquentiellement. ';

$txt['show_group_key'] = 'Afficher la liste des groupes sur l\'accueil du forum. ';
$txt['additional_options_collapsible'] = 'Activez les options de publication supplémentaires. ';
$txt['who_display_viewing'] = 'Afficher qui visualise l\'accueil du forum et les messages : ';
$txt['who_display_viewing_off'] = 'Ne pas montrer';
$txt['who_display_viewing_numbers'] = 'Ne montrer que les nombres';
$txt['who_display_viewing_names'] = 'Montrer les pseudonymes des membres';
$txt['show_stats_index'] = 'Afficher les statistiques sur l\'accueil du forum. ';
$txt['latest_members'] = 'Afficher le dernier membre sur l\'accueil du forum. ';
$txt['last_modification'] = 'Afficher la dernière date de modification dans les messages modifiés. ';
$txt['user_avatars'] = 'Afficher les avatars des membres dans les messages. ';
$txt['member_list_bar'] = 'Afficher la liste des membres sur l\'accueil du forum';
$txt['current_pos_text_img'] = 'Afficher la position actuelle comme des liens, plutôt que du texte simple. ';
$txt['show_view_profile_button'] = 'Afficher le bouton de profil dans les messages. ';
$txt['enable_mark_as_read'] = 'Activer et afficher les boutons &quot;Marquer comme lu&quot; et &quot;Marquer non lu&quot;';
$txt['header_logo_url'] = 'Adresse vers l\'image de logo : ';
$txt['header_logo_url_desc'] = '(Laissez vide pour afficher le nom du forum ou le logo par défaut.) ';

$txt['recent_post_topics'] = 'Afficher les messages ou les sujets récents sur la page d\'accueil du forum. ';
$txt['show_recent_topics'] = 'Afficher les sujets récents ';
$txt['show_recent_posts'] = 'Afficher les messages récents ';
$txt['number_recent_posts'] = 'Nombre de messages ou de sujets récents à afficher sur la page d\'accueil du forum :';
$txt['number_recent_posts_desc'] = '(Pour désactiver la barre des messages récents, réglez ce paramètre à zéro. )';
$txt['hide_post_group'] = 'Masquer le nom du groupe posteur pour les membres du groupe.';
$txt['hide_post_group_desc'] = 'Activer cette option n\'affichera pas le nom du groupe d\'un membre dans la vue du message si les membres font partie d\'un groupe administratif (Modérateur, Modérateur Global, Administrateur). ';

$txt['theme_options_defaults'] = 'Ceci sont les valeurs par défaut de quelques réglages spécifiques des membres.  Les modifier affectera seulement les invités et les nouveaux membres.';
$txt['theme_options_title'] = 'Changer ou réinitialiser les options par défaut';

$txt['themeadmin_title'] = 'Gestion des thèmes et options ';
$txt['themeadmin_description'] = 'Ici vous pouvez modifier les paramètres de vos thèmes, mettre à jour la liste des thèmes, réinitialiser les options des membres et autres réglages du genre.';
$txt['themeadmin_admin_desc'] = 'Les thèmes fournissent les différents apparences de votre forum. La Gestion des thèmes vous permet d\'installer de nouveaux thèmes, de modifier le thème par défaut, de réinitialiser tous les membres pour utiliser un certain thème et de choisir d\'autres paramètres liés à la sélection de thème. N\'oubliez pas de regarder les paramètres de thème de chacun de vos thèmes pour leurs options de mise en page individuelles.';
$txt['themeadmin_list_desc'] = 'Ici vous pouvez voir la liste des thèmes actuellement installés, changer leur chemin et réglages, de même que les désinstaller.';
$txt['themeadmin_reset_desc'] = 'Dans la zone Options des membres, vous avez la possibilité de modifier les options spécifiques au thème qui affectent tous les membres. Vous ne verrez que les thèmes qui ont leur propre ensemble de paramètres d\'options. ';
$txt['themeadmin_edit_desc'] = 'Dans la zone Modifier les thèmes, vous pouvez modifier la feuille de style et le code source de vos thèmes installés. Vous aurez besoin d\'une compréhension de base de CSS et PHP pour changer efficacement un thème et ne pas casser votre forum en même temps. ';
$txt['themeadmin_modify_styles'] = 'Changer le style d\'un thème est risqué, alors soyez certain de ce que vous faites. Ayez toujours une copie de sauvegarde du répertoire de thème dans lequel vous travaillez pour récupérer en cas d\'erreur. Pour obtenir de l\'aide avant de commencer, visitez <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">le forum ElkArte</a>.';

$txt['themeadmin_list_heading'] = 'Réglages du Thème';
$txt['themeadmin_list_tip'] = 'Les paramètres de mise en page peuvent être différents pour chaque thème installé. Modifiez les thèmes installés pour définir leurs options individuelles, modifier leurs paramètres de répertoire ou d\'URL, ou pour rechercher d\'autres options. ';
$txt['themeadmin_list_theme_dir'] = 'Répertoire du thème : (templates) ';
$txt['themeadmin_list_invalid'] = '(Attention, ce chemin est incorrect !) ';
$txt['themeadmin_list_theme_url'] = 'Adresse vers le répertoire au-dessus : ';
$txt['themeadmin_list_images_url'] = 'Adresse vers le répertoire des images : ';
$txt['themeadmin_list_reset'] = 'Réinitialiser l\'URL des thèmes et leur répertoire';
$txt['themeadmin_list_reset_dir'] = 'Chemin vers le répertoire des thèmes : ';
$txt['themeadmin_list_reset_url'] = 'Adresse vers le même répertoire : ';
$txt['themeadmin_list_reset_go'] = 'Tenter de réinitialiser tous les thèmes';

$txt['themeadmin_reset_tip'] = 'Chaque thème peut avoir ses propres options personnalisées à sélectionner par vos membres.  Elles incluent des réglages comme &quot;Réponse Rapide&quot;, les avatars et signatures, options de disposition et autres options similaires.  Ici vous pouvez changer les paramètres par défaut ou réinitialiser les options de tout le monde.<br /><br />Veuillez noter que certains thèmes peuvent utiliser les options par défaut, auquel cas vous ne verrez pas de paramètres pour ces options. ';
$txt['themeadmin_reset_defaults'] = 'Configurer les options des invités et des nouveaux utilisateurs pour ce thème';
$txt['themeadmin_reset_defaults_current'] = 'options actuellement réglées.';
$txt['themeadmin_reset_members'] = 'Changer les options actuelles pour tous les membres utilisant ce thème';
$txt['themeadmin_reset_remove'] = 'Enlever toutes les options des membres et les réinitialiser aux valeurs par défaut';
$txt['themeadmin_reset_remove_current'] = 'membres utilisent actuellement leurs propres options.';
// Don't use entities in the below string.
$txt['themeadmin_reset_remove_confirm'] = 'Etes-vous sûr de vouloir enlever toutes les options de thème ?\\nCeci peut aussi réinitialiser quelques champs personnalisés du profil.';
$txt['themeadmin_reset_options_info'] = 'Les options ci-dessous surclasseront les options de <em>tout le monde</em>.  Pour changer une option, sélectionner &quot;modifier&quot; dans la boîte à coté, et choisissez lui une valeur.  Pour utiliser la valeur par défaut, sélectionner &quot;par défaut&quot;. Sinon utilisez &quot;Ne pas modifier&quot; pour le laisser tel quel.';
$txt['themeadmin_reset_options_change'] = 'Changer';
$txt['themeadmin_reset_options_none'] = 'Ne pas changer';
$txt['themeadmin_reset_options_default'] = 'Défaut';

$txt['themeadmin_edit_browse'] = 'Parcourir les fichiers de template et les autres fichiers de ce thème.';
$txt['themeadmin_edit_style'] = 'Modifier les feuilles de style de ce thème.';
$txt['themeadmin_edit_copy_template'] = 'Copier un fichier de template depuis le thème sur lequel celui-ci est basé.';
$txt['themeadmin_edit_exists'] = 'existe déjà';
$txt['themeadmin_edit_do_copy'] = 'copier';
$txt['themeadmin_edit_copy_warning'] = 'Quand le système a besoin d\'un fichier de template ou d\'un fichier de langue qui n\'existe pas dans le thème actuel, il regarde dans le dossier du thème sur lequel il est basé ou du thème par défaut.<br />A moins que vous n\'ayez besoin de modifier un fichier de template, il est plus prudent de ne pas le copier.';
$txt['themeadmin_edit_copy_confirm'] = 'Etes-vous sûr de vouloir copier ce fichier de template ?';
$txt['themeadmin_edit_overwrite_confirm'] = 'Etes-vous sûr de vouloir copier ce fichier de template par-dessus celui qui existe déjà ?\\nCeci va ECRASER tous les changements que vous avez faits !';
$txt['themeadmin_edit_no_copy'] = '<em>(ne peut copier)</em>';
$txt['themeadmin_edit_filename'] = 'Nom de fichier';
$txt['themeadmin_edit_modified'] = 'Dernière modification';
$txt['themeadmin_edit_size'] = 'Taille';
$txt['themeadmin_edit_error'] = 'Le fichier que vous tentiez de sauvegarder a généré l\'erreur suivante&nbsp;:';
$txt['themeadmin_edit_on_line'] = 'Commençant à la ligne : ';
$txt['themeadmin_edit_preview'] = 'Prévisualiser';
$txt['themeadmin_selectable'] = 'Thèmes sélectionnables par l\'utilisateur : ';
$txt['themeadmin_themelist_link'] = 'Afficher la liste des thèmes installés ';

// Strings for the variants
$txt['variant_light'] = 'ElkArte Light';
$txt['variant_besocial'] = 'ElkArte Be Social!';
