<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Répondre';
$txt['post_in_board'] = 'Publier dans la section';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Citer ce message';
$txt['disable_smileys'] = 'Désactiver les émoticônes';
$txt['dont_use_smileys'] = 'Ne pas utiliser d\'émoticônes';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Publié le';
$txt['standard'] = 'Standard';
$txt['thumbs_up'] = 'Pouce en haut';
$txt['thumbs_down'] = 'Pouce en bas';
$txt['exclamation_point'] = 'Point d\'exclamation';
$txt['question_mark'] = 'Point d\'interrogation';
$txt['icon_poll'] = 'Sondage';
$txt['lamp'] = 'Lampe';
$txt['add_smileys'] = 'Ajouter des émoticônes';
$txt['topic_notify_no'] = 'Aucun sujets avec notification.';

$txt['rich_edit_wont_work'] = 'Votre navigateur ne supporte pas l\'édition en texte enrichi.';
$txt['rich_edit_function_disabled'] = 'Votre navigateur ne supporte pas cette fonction.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Cliquez ici pour vous désabonner de ce sujet';

$txt['lock_after_post'] = 'Bloquer après ce message';
$txt['notify_replies'] = 'Suivre les réponses à ce sujet';
$txt['lock_topic'] = 'Bloquer ce sujet';
$txt['shortcuts'] = 'Raccourcis clavier : shift+alt+s soumettre/publier ou shift+alt+p prévisualiser';
$txt['shortcuts_drafts'] = 'Raccourcis clavier : shift+alt+s soumettre/publier, shift+alt+p prévisualiser ou shift+alt+d enregistrer en brouillon';
$txt['option'] = 'Option';
$txt['reset_votes'] = 'Réinitialiser le décompte des votes';
$txt['reset_votes_check'] = 'Cochez ici pour mettre tous les décomptes de votes à 0.';
$txt['votes'] = 'votes';
$txt['attach'] = 'Joindre';
$txt['clean_attach'] = 'Supprimer la pièce jointe';
$txt['attached'] = 'Pièces jointes'; // @deprecated since 1.1
$txt['allowed_types'] = 'Types de fichier autorisés';
$txt['cant_upload_type'] = 'Vous ne pouvez pas téléverser ce type de fichier. Les seules extensions permises sont %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Décochez les pièces jointes que vous voulez supprimer'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Nom de fichier réservé. Merci de le renommer.';
$txt['topic_locked_no_reply'] = 'Attention : ce sujet est actuellement/sera bloqué !<br />Seuls les administrateurs et les modérateurs peuvent y répondre.';
$txt['attachment_requires_approval'] = 'Notez que les pièces jointes ne seront affichées qu\'après approbation d\'un modérateur.';
$txt['error_temp_attachments'] = 'Des fichiers joints antérieurement mais non publiés ont été trouvés. Ces fichiers sont maintenant joints à ce message, <a href="#postAttachment">vous pouvez les supprimer ici</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Attention, ce sujet n\'apparaîtra qu\'après avoir été approuvé par un modérateur.';

$txt['enter_comment'] = 'Entrez un commentaire';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Message signalé';
$txt['reported_to_mod_by'] = 'par';
$txt['rtm10'] = 'Soumettre';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Le message "%1$s", par';
$txt['reported_by'] = ', a été signalé par';
$txt['board_moderate'] = 'sur une section que vous modérez';
$txt['report_comment'] = 'Le rapporteur a fait la remarque suivante';

$txt['attach_drop_files'] = 'Ajouter des fichiers par glisser/déposer ou <a class="drop_area_fileselect_text" href="javascript:void(0)">sélectionnez les</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Ajouter des fichiers</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'taille totale maximale %1$s Ko';
$txt['attach_restrict_attachmentSizeLimit'] = 'taille individuelle maximale %1$s Ko';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d par message';
$txt['attach_restrictions'] = 'Restrictions : ';

$txt['post_additionalopt_attach'] = 'Pièces jointes et autres options';
$txt['post_additionalopt'] = 'Autres options';
$txt['sticky_after'] = 'Épingler ce sujet';
$txt['move_after2'] = 'Déplacer ce sujet';
$txt['back_to_topic'] = 'Retourner à ce sujet';
$txt['approve_this_post'] = 'Approuver ce message';

$txt['retrieving_quote'] = 'Récupération de citation...';

$txt['post_visual_verification_label'] = 'Vérification';
$txt['post_visual_verification_desc'] = 'Veuillez entrer le code contenu dans l\'image ci-dessus pour valider ce message.';

$txt['poll_options'] = 'Options de sondage';
$txt['poll_run'] = 'Lancer le sondage pour';
$txt['poll_run_limit'] = '(Laissez vide si pas de limite.)';
$txt['poll_results_visibility'] = 'Visibilité des résultats';
$txt['poll_results_anyone'] = 'Montrer les résultats du sondage à tous.';
$txt['poll_results_voted'] = 'Montrer les résultats aux seuls votants.';
$txt['poll_results_after'] = 'Ne montrer les résultats qu\'après l\'expiration du sondage.';
$txt['poll_max_votes'] = 'Votes maximum par membre';
$txt['poll_do_change_vote'] = 'Permettre à l\'utilisateur de changer d\'avis';
$txt['poll_too_many_votes'] = 'Vous avez choisi trop d\'options. Pour ce sondage, vous ne pouvez sélectionner que %1$s options.';
$txt['poll_add_option'] = 'Ajouter une option';
$txt['poll_guest_vote'] = 'Permettre aux invités de voter';

$txt['spellcheck_done'] = 'Correction d\'orthographe terminée.';
$txt['spellcheck_change_to'] = 'Changer par : ';
$txt['spellcheck_suggest'] = 'Suggestions : ';
$txt['spellcheck_change'] = 'Changer';
$txt['spellcheck_change_all'] = 'Changer tout';
$txt['spellcheck_ignore'] = 'Ignorer';
$txt['spellcheck_ignore_all'] = 'Ignorer Tout';

$txt['more_attachments'] = 'plus de pièces jointes';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Vous ne pouvez plus publier de pièces jointes.';

$txt['more_smileys'] = 'plus';
$txt['more_smileys_title'] = 'Émoticônes additionnelles';
$txt['more_smileys_pick'] = 'Choisir une émoticônes';
$txt['more_smileys_close_window'] = 'Fermer la fenêtre';

$txt['error_new_reply'] = 'Attention, une nouvelle réponse a été postée pendant que vous rédigiez votre message. Vous devriez peut-être revoir votre message avant de l\'envoyer, pour éviter toute redondance.';
$txt['error_new_replies'] = 'Attention, %1$d nouvelles réponses ont été postées pendant que vous rédigiez votre message. Vous devriez peut-être revoir votre message avant de l\'envoyer, pour éviter toute redondance.';
$txt['error_new_reply_reading'] = 'Attention, une nouvelle réponse a été postée pendant que vous lisiez votre message. Vous devriez peut-être revoir votre message avant de l\'envoyer, pour éviter toute redondance.';
$txt['error_new_replies_reading'] = 'Attention, %1$d nouvelles réponses ont été postées pendant que vous lisiez votre message. Vous devriez peut-être revoir votre message avant de l\'envoyer, pour éviter toute redondance.';

$txt['announce_this_topic'] = 'Envoyer une annonce à propos de ce sujet aux membres :';
$txt['announce_title'] = 'Envoyer une annonce';
$txt['announce_desc'] = 'Ce formulaire vous permet d\'envoyer une annonce aux groupes sélectionnés à propos de ce sujet.';
$txt['announce_sending'] = 'Envoi de l\'annonce de ce sujet';
$txt['announce_done'] = 'terminé';
$txt['announce_continue'] = 'Continuer';
$txt['announce_topic'] = 'Annoncer le sujet';
$txt['announce_regular_members'] = 'Membres inscrits';

$txt['digest_subject_daily'] = 'Résumé du jour';
$txt['digest_subject_weekly'] = 'Résumé de la semaine';
$txt['digest_intro_daily'] = 'Ci-dessous un résumé de l\'activité du jour dans les sections et sujets que vous suivez par abonnement sur %1$s. Pour vous désabonner, veuillez visiter le lien suivant.';
$txt['digest_intro_weekly'] = 'Ci-dessous un résumé de l\'activité hebdomadaire dans les sections et sujets que vous suivez par abonnement sur %1$s. Pour vous désabonner, veuillez visiter le lien suivant.';
$txt['digest_new_topics'] = 'Les sujet suivants ont été débutés';
$txt['digest_new_topics_line'] = '"%1$s" dans la section %2$s';
$txt['digest_new_replies'] = 'Des réponses ont été postées dans les sujets suivants';
$txt['digest_new_replies_one'] = '1 réponse dans "%1$s"';
$txt['digest_new_replies_many'] = '%1$d réponses dans "%2$s"';
$txt['digest_mod_actions'] = 'Les actions de modération suivantes ont été accomplies';
$txt['digest_mod_act_sticky'] = '"%1$s" a été épinglé';
$txt['digest_mod_act_lock'] = '"%1$s" a été verrouillé';
$txt['digest_mod_act_unlock'] = '"%1$s" a été déverrouillé';
$txt['digest_mod_act_remove'] = '"%1$s" a été effacé';
$txt['digest_mod_act_move'] = '"%1$s" a été déplacé';
$txt['digest_mod_act_merge'] = '"%1$s" a été fusionné';
$txt['digest_mod_act_split'] = '"%1$s" a été séparé en deux sujets';

$txt['attach_error_title'] = 'Erreur pendant le téléversement des pièces jointes.';
$txt['attach_warning'] = 'Il y a eu un problème pendant le téléversement de <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Désolé, vous êtes au-delà de l\'espace réservé pour les pièces jointes. La taille totale de l\'ensemble des pièces jointes autorisée par message est de %1$s Ko. L\'espace restant est de %2$s Ko.';
$txt['attach_folder_warning'] = 'Le répertoire des pièces jointes est introuvable. Veuillez informer un administrateur de ce problème.';
$txt['attach_folder_admin_warning'] = 'Le chemin d\'accès au répertoire des pièces jointes (%1$s) est incorrect. Veuillez le corriger dans la zone des paramètres de pièce jointe de votre panneau d\'administration.';
$txt['attach_limit_nag'] = 'Vous avez atteint le nombre maximum de pièces jointes permises par post.';
$txt['attach_no_upload'] = 'Un problème est survenu et vos pièces jointes n\'ont pas pu être téléversées';
$txt['attach_remaining'] = '%1$d restant(s)';
$txt['attach_available'] = '%1$s Ko disponibles';
$txt['attach_kb'] = '(%1$s Ko)';
$txt['attach_0_byte_file'] = 'Le fichier semble vide. Veuillez contacter votre administrateur de forum si le problème persiste';
$txt['attached_files_in_session'] = '<em>Les fichiers soulignés ci-dessus ont été téléchargés mais ne seront pas joints à ce message tant qu\'il ne sera pas enregistré.</em>';

$txt['attach_php_error'] = 'En raison d\'une erreur, votre pièce jointe n\'a pas pu être téléversée. Veuillez contacter l\'administrateur du forum si ce problème persiste.';
$txt['php_upload_error_1'] = 'Le fichier téléchargé dépasse la directive upload_max_filesize dans php.ini. Veuillez contacter votre hébergeur si vous ne parvenez pas à résoudre ce problème.';
$txt['php_upload_error_3'] = 'Le fichier téléchargé n\'a été que partiellement téléchargé. Il s\'agit d\'une erreur liée à PHP. Veuillez contacter votre hébergeur si ce problème persiste.';
$txt['php_upload_error_4'] = 'Aucun fichier n\'a été téléchargé. Il s\'agit d\'une erreur liée à PHP. Veuillez contacter votre hébergeur si ce problème persiste.';
$txt['php_upload_error_6'] = 'Impossible de sauvegarder. Il manque un répertoire temporaire. Veuillez contacter votre hébergeur si vous ne parvenez pas à résoudre ce problème.';
$txt['php_upload_error_7'] = 'Échec de l\'écriture du fichier sur le disque. Il s\'agit d\'une erreur liée à PHP. Veuillez contacter votre hébergeur si ce problème persiste.';
$txt['php_upload_error_8'] = 'Une extension PHP a arrêté le téléchargement du fichier. Il s\'agit d\'une erreur liée à PHP. Veuillez contacter votre hébergeur si ce problème persiste.';
$txt['error_temp_attachments_new'] = 'Il y a des pièces jointes que vous aviez précédemment jointes mais non publiées. Ces pièces jointes sont toujours jointes à ce message. Ce message doit être Enregistré avant que ces pièces jointes ne soient enregistrées ou supprimées. Vous <a href="#postAttachment">pouvez le faire ici</a>';
$txt['error_temp_attachments_found'] = 'Les pièces jointes suivantes que vous aviez précédemment jointes à un autre message mais non publiées ont été trouvées. Il est conseillé de ne pas publier jusqu\'à ce que celles-ci soient supprimées ou que le message ait été enregistré. <br />Cliquez <a href="%1$s">ici pour supprimer</a> ces pièces jointes. Ou <a href="%2$s">ici pour revenir à ce message</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'Les pièces jointes suivantes que vous aviez précédemment jointes à un autre message non publié ont été trouvées. Il est conseillé de ne plus télécharger de pièces jointes tant que celles-ci n\'ont pas été supprimées ou que le message n\'a pas été Enregistré. <br />Cliquez <a href="%1$s">ici pour supprimer ces pièces jointes</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Ces pièces jointes ont maintenant été supprimées et vous êtes revenu à la page sur laquelle vous étiez auparavant';
$txt['error_temp_attachments_flushed'] = 'Veuillez noter que tous les fichiers précédemment joints, mais non publiés, ont maintenant été supprimés.';
$txt['error_topic_already_announced'] = 'Veuillez noter que ce sujet a déjà été annoncé.';

$txt['cant_access_upload_path'] = 'Impossible d\'accéder au chemin des fichiers joints !';
$txt['file_too_big'] = 'Votre fichier est trop volumineux. La taille maximale autorisée des pièces jointes est de %1$s Ko.';
$txt['attach_timeout'] = 'Votre fichier joint n\'a pu être transféré. Il est possible que son transfert ait été trop long, ou que le fichier soit plus gros que la limite imposée par le serveur.<br /><br />Veuillez contacter l\'administrateur pour plus d\'informations.';
$txt['bad_attachment'] = 'Votre fichier joint a échoué aux tests de sécurité, et ne peut pas être mis en ligne. Merci de contacter l\'administrateur.';
$txt['ran_out_of_space'] = 'Le répertoire de téléchargement est plein. Veuillez contacter un administrateur à propos de ce problème.';
$txt['attachments_no_write'] = 'Le dossier de destination des fichiers joints est en lecture seule.  Votre fichier joint ou avatar ne peut pas être sauvegardé.';
$txt['attachments_no_create'] = 'Impossible de créer un nouveau répertoire de pièces jointes. Votre pièce jointe ou votre avatar ne peut pas être enregistré.';
$txt['attachments_limit_per_post'] = 'Vous ne pouvez pas transférer plus de %1$d fichiers joints par message';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Incorpore la pièce jointe %1$d dans le message';
$txt['ila_title'] = 'Vignette extensible à la fin du message';
$txt['insert'] = 'Insérer';
$txt['ila_opt_size'] = 'Taille';
$txt['ila_opt_align'] = 'Alignement';
$txt['ila_opt_size_thumb'] = 'Vignette';
$txt['ila_option2'] = 'Lien texte';
$txt['ila_option3'] = 'Lien texte court';
$txt['ila_opt_size_full'] = 'Taille réelle';
$txt['ila_opt_size_cust'] = 'Taille personnalisée';
$txt['ila_opt_align_none'] = 'Aucun';
$txt['ila_opt_align_left'] = 'Gauche';
$txt['ila_opt_align_right'] = 'Droite';
$txt['ila_opt_align_center'] = 'Centrer';
$txt['ila_confirm_removal'] = 'Voulez-vous vraiment supprimer définitivement cette pièce jointe ?';
/*
$txt['ila_thereare'] = 'Il y a seulement';
$txt['ila_attachment'] = 'pièce(s) jointe(s)';
$txt['ila_none'] = 'comme vignette extensible';
$txt['ila_img'] = 'en taille réelle';
$txt['ila_url'] = 'comme lien';
$txt['ila_mini'] = 'comme lien compact';
*/