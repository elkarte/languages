<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Le thème par défaut ElkArte.<br /><br /> Auteur : les contributeurs à ElkArte';