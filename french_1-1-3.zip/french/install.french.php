<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Bienvenue';
$txt['install_step_exist'] = 'Vérification d\'une installation antérieure';
$txt['install_step_writable'] = 'Test en Écriture';
$txt['install_step_forum'] = 'Paramètres du Forum';
$txt['install_step_databaseset'] = 'Paramètres de la Base de Données';
$txt['install_step_databasechange'] = 'Remplissage de la Base de Données';
$txt['install_step_admin'] = 'Compte Administrateur';
$txt['install_step_delete'] = 'Finalise l\'installation';

$txt['installer'] = 'Installer ElKarte';
$txt['installer_language'] = 'Langue';
$txt['installer_language_set'] = 'Régler';
$txt['congratulations'] = 'Félicitations, le processus d\'installation est terminé !';
$txt['congratulations_help'] = 'Si, à tout moment, vous avez besoin de support, ou bien si ElKarte ne fonctionne pas correctement, rappelez-vous que <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">l\'aide, en anglais, est disponible</a> en cas de besoin.';
$txt['still_writable'] = 'Votre dossier d\'installation est toujours ouvert en écriture.  Ça serait une bonne idée de changer ses droits d\'accès (chmod) afin de le fermer en écriture, pour des raisons de sécurité.';
$txt['delete_installer'] = 'Cliquez ici pour essayer de supprimer le répertoire d\'installation maintenant.';
$txt['delete_installer_maybe'] = '<em>(ne fonctionne pas sur tous les serveurs)</em>';
$txt['go_to_your_forum'] = 'Maintenant, vous pouvez aller voir <a href="%1$s">votre tout nouveau forum</a> et commencer à l\'utiliser.  Vous devrez d\'abord vous connecter, pour ensuite pouvoir accéder au Centre d\'administration.';
$txt['good_luck'] = 'Merci d\'avoir installé ElKarte !';
$txt['try_again'] = 'Cliquer ici pour essayer à nouveau.';

$txt['install_welcome'] = 'Bienvenue';
$txt['install_welcome_desc'] = 'Bienvenue sur ElKarte. Ce script vous aidera à installer %1$s. Nous allons vous demander des détails sur votre forum dans les pages à venir, et il sera prêt à être utilisé en quelques minutes à peine.';
$txt['install_all_lovely'] = 'Nous avons terminé les tests préliminaires sur votre serveur, et tout semble être en ordre. Cliquez sur le bouton &quot;Continuer&quot; ci-dessous pour commencer.';

$txt['user_refresh_install'] = 'Forum Rafraîchi';
$txt['user_refresh_install_desc'] = 'Lors de l\'installation, ElKarte a trouvé, en utilisant les détails que vous avez fournis, qu\'au moins une des tables que l\'installateur doit créer existent déjà.<br />Toutes les tables manquantes de votre installation ont été recréées avec les données par défaut, mais aucune donnée n\'a été supprimée des tables existantes.';

$txt['default_topic_subject'] = 'Bienvenue chez ElKarte !';
$txt['default_topic_message'] = 'Bienvenue dans le forum ElKarte !<br /><br />Nous espérons que vous apprécierez son usage et la mise en oeuvre de votre communauté. Pour tous problèmes n\'hésitez pas à rejoindre [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Merci !<br /> La communauté ElKarte';
$txt['default_board_name'] = 'Discussions Générales';
$txt['default_board_description'] = 'Une section pour discuter librement de tout et de rien.';
$txt['default_category_name'] = 'Catégorie Générale';
$txt['default_time_format'] = '%d %B %Y à %H:%M:%S';
$txt['default_news'] = 'ElkArte - Installé !';
$txt['default_karmaLabel'] = 'Rayonnement : ';
$txt['default_karmaSmiteLabel'] = '[huer]';
$txt['default_karmaApplaudLabel'] = '[applaudir]';
$txt['default_reserved_names'] = 'Admin
Webmestre
Invité
Superutilisateur';
$txt['default_smileyset_name'] = 'Jeu Fugue';
$txt['default_theme_name'] = 'Thème par défaut ElkArte';

$txt['default_administrator_group'] = 'Administrateur';
$txt['default_global_moderator_group'] = 'Modérateur Global';
$txt['default_moderator_group'] = 'Modérateur';
$txt['default_newbie_group'] = 'Néophyte';
$txt['default_junior_group'] = 'Membre Junior';
$txt['default_full_group'] = 'Membre Expérimenté';
$txt['default_senior_group'] = 'Membre Senior';
$txt['default_hero_group'] = 'Membre Héroïque';

$txt['default_smiley_smiley'] = 'Sourire';
$txt['default_wink_smiley'] = 'Clin d\'oeil';
$txt['default_cheesy_smiley'] = 'Très souriant';
$txt['default_grin_smiley'] = 'Grimaçant';
$txt['default_angry_smiley'] = 'Fâché';
$txt['default_sad_smiley'] = 'Triste';
$txt['default_shocked_smiley'] = 'Choqué';
$txt['default_cool_smiley'] = 'Cool';
$txt['default_huh_smiley'] = 'Hein ?';
$txt['default_roll_eyes_smiley'] = 'Roulement d\'yeux';
$txt['default_tongue_smiley'] = 'Tire la langue';
$txt['default_embarrassed_smiley'] = 'Embarrassé';
$txt['default_lips_sealed_smiley'] = 'Lèvres scellées';
$txt['default_undecided_smiley'] = 'Indécis';
$txt['default_kiss_smiley'] = 'Bisou';
$txt['default_cry_smiley'] = 'Pleure';
$txt['default_evil_smiley'] = 'Diabolique';
$txt['default_azn_smiley'] = 'Prétentieux';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Rit';
$txt['default_police_smiley'] = 'Police';
$txt['default_angel_smiley'] = 'Ange';

$txt['error_message_click'] = 'Cliquez ici';
$txt['error_message_try_again'] = 'pour réessayer une nouvelle fois cette étape.';
$txt['error_message_bad_try_again'] = 'pour malgré tout tenter l\'installation, mais notez que ceci est <em>fortement</em> déconseillé.';

$txt['install_settings'] = 'Paramètres du Forum';
$txt['install_settings_info'] = 'Dans cette page vous devez définir quelques paramètres clés pour votre forum. ElkArte en a détecté automatiquement quelques uns pour vous.';
$txt['install_settings_name'] = 'Nom du forum';
$txt['install_settings_name_info'] = 'C\'est le nom de votre forum, par exemple &quot;Le forum de test&quot ;.';
$txt['install_settings_name_default'] = 'Ma Communauté';
$txt['install_settings_url'] = 'Adresse du forum';
$txt['install_settings_url_info'] = 'Ceci est l\'URL de votre forum <strong>sans la barre oblique \'/\' finale&nbsp;!</strong>.<br />Dans la plupart des cas, vous pouvez laisser ainsi les valeurs par défaut - elles sont généralement correctes.';
$txt['install_settings_compress'] = 'Compression Gzip';
$txt['install_settings_compress_title'] = 'Compresse les données envoyées afin d\'économiser la bande passante.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Cette fonction ne fonctionne pas sur tous les serveurs, mais peut contribuer à économiser énormément la bande passante.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Cliquez ici pour la tester</a>. (Vous devriez simplement avoir un message "REUSSI".)';
$txt['install_settings_dbsession'] = 'Stocker les sessions dans la base de données';
$txt['install_settings_dbsession_title'] = 'Utilisez la base de données pour stocker les sessions plutôt que d\'utiliser des fichiers.';
$txt['install_settings_dbsession_info1'] = 'Cette fonction est une bonne solution la plupart du temps, rendant ainsi les sessions plus dépendantes du forum.';
$txt['install_settings_dbsession_info2'] = 'Cette fonction est généralement une bonne idée, mais peut ne pas fonctionner sur ce serveur.';
$txt['install_settings_proceed'] = 'Procéder';

$txt['db_settings'] = 'Paramètres du Serveur de Base de données';
$txt['db_settings_info'] = 'Ce sont les paramètres à utiliser pour votre serveur de base de données. Si vous n\'en connaissez pas les valeurs, essayez de les demander à votre hébergeur.';
$txt['db_settings_type'] = 'Type de base de données';
$txt['db_settings_type_info'] = 'Plusieurs types de bases de données pris en charge ont été détectés - lequel souhaitez-vous utiliser ? ';
$txt['db_settings_server'] = 'Nom du serveur';
$txt['db_settings_server_info'] = 'C\'est pratiquement toujours localhost - donc si vous ne savez pas, essayez localhost.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Laissez vide si votre serveur écoute sur le port par défaut ou si vous n\'êtes pas sûr. ';
$txt['db_settings_username'] = 'Nom d\'utilisateur';
$txt['db_settings_username_info'] = 'Indiquez ici le nom d\'utilisateur nécessaire à la connexion à votre base de données.<br /> Si vous ne le connaissez pas, essayez le nom d\'utilisateur de votre compte FTP, la plupart du temps ils sont identiques.';
$txt['db_settings_password'] = 'Mot de passe';
$txt['db_settings_password_info'] = 'Ici, mettez le mot de passe nécessaire à la connexion à votre base de données.<br />Si vous ne le connaissez pas, essayez le mot de passe de votre compte FTP.';
$txt['db_settings_database'] = 'Nom de la base de données';
$txt['db_settings_database_info'] = 'Indiquez le nom de la base de données que vous voulez utiliser pour stocker les données de ElKarte.';
$txt['db_settings_database_info_note'] = 'Si cette base de données n\'existe pas, cet installateur essaiera de la créer.';
$txt['db_settings_database_file'] = 'Nom du fichier de base de données';
$txt['db_settings_database_file_info'] = 'C\'est e nom du fichier dans lequel stocker les données de ElKarte. Nous vous recommandons d\'utiliser le nom généré aléatoirement et de paramétrer  le chemin d\'accès du fichier est sur un endroit non public de votre serveur.';
$txt['db_settings_prefix'] = 'Préfixe de Table';
$txt['db_settings_prefix_info'] = 'Le préfixe pour chaque table de la base de données. <strong>Ne pas installer deux forums avec le même préfixe&nbsp;!</strong><br />Cette valeur permet d\'avoir plusieurs installations différentes sur une seule base de données.';
$txt['db_populate'] = 'Base de Données remplie';
$txt['db_populate_info'] = 'Vos paramètres ont été sauvegardés, et les données requises au bon fonctionnement du forum ont été insérées dans la base de données. Résumé du remplissage&nbsp;:';
$txt['db_populate_info2'] = 'Cliquez &quot;Continuer&quot; pour accéder au processus de création du compte administrateur.';
$txt['db_populate_inserts'] = '%1$d rangées insérées.';
$txt['db_populate_tables'] = '%1$d tables créées.';
$txt['db_populate_insert_dups'] = '%1$d insertions superflues ignorées.';
$txt['db_populate_table_dups'] = '%1$d tables superflues ignorées.';

$txt['user_settings'] = 'Créer votre Compte Administrateur';
$txt['user_settings_info'] = 'L\'installateur créera maintenant un nouveau compte administrateur pour vous.';
$txt['user_settings_username'] = 'Votre nm d\'utilisateur';
$txt['user_settings_username_info'] = 'Choisissez le nom avec lequel vous souhaitez vous connecter.';
$txt['user_settings_password'] = 'Mot de passe';
$txt['user_settings_password_info'] = 'Choisissez votre mot de passe ici, et souvenez-vous-en bien !';
$txt['user_settings_again'] = 'Mot de passe';
$txt['user_settings_again_info'] = '(juste pour vérifier.)';
$txt['user_settings_email'] = 'Adresse de courriel';
$txt['user_settings_email_info'] = 'Renseignez ici votre adresse e-mail. <strong>L\'adresse e-mail doit être valide.</strong>';
$txt['user_settings_database'] = 'Mot de passe de la base de données';
$txt['user_settings_database_info'] = 'Pour des raisons de sécurité, l\'installateur demande de nouveau le mot de passe afin de créer le compte administrateur.';
$txt['user_settings_skip'] = 'Passer';
$txt['user_settings_skip_sure'] = 'Etes vous sûr de vouloir éviter la création d\'un compte administrateur&nbsp;?';
$txt['user_settings_proceed'] = 'Terminer';

$txt['ftp_checking_writable'] = 'Vérifie si les fichiers sont inscriptibles';
$txt['ftp_setup'] = 'Informations sur la connexion FTP';
$txt['ftp_setup_info'] = 'Cet installateur peut se connecter par FTP afin de spécifier les bons droits d\'accès aux fichiers du forum.  Si la procédure ne fonctionne pas, vous devrez modifier manuellement les droits d\'accès des fichiers. Veuillez noter que cette fonction ne supporte actuellement pas le SSL.';
$txt['ftp_server'] = 'Serveur';
$txt['ftp_server_info'] = 'Ceci devrait être l\'adresse et le port de votre serveur FTP.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'Nom d\'utilisateur';
$txt['ftp_username_info'] = 'Le nom d\'utilisateur avec lequel se connecter. <em>Il ne sera enregistré nulle part.</em>';
$txt['ftp_password'] = 'Mot de passe';
$txt['ftp_password_info'] = 'Le mot de passe de votre compte FTP. <em>L\'information ne sera enregistrée nulle part.</em>';
$txt['ftp_path'] = 'Chemin d\'installation';
$txt['ftp_path_info'] = 'C\'est le chemin <em>relatif</em> que vous utilisez dans votre serveur FTP.';
$txt['ftp_path_found_info'] = 'Le chemin dans le champ précédent a été détecté automatiquement..';
$txt['ftp_connect'] = 'Connexion';
$txt['ftp_setup_why'] = 'En quoi cette étape est-elle utile&nbsp;?';
$txt['ftp_setup_why_info'] = 'Certains fichiers nécessitent d\'être accessibles en écriture pour que ElKarte fonctionne correctement. Cette étape permet à l\'installateur de régler ces propriétés pour vous. Toutefois, dans certains cas, cela ne fonctionne pas. Veuillez alors mettre les droits à 777 (écriture possible 755 chez certains hébergeurs) sur les fichiers : ';
$txt['ftp_setup_again'] = 'pour vérifier si les fichiers sont de nouveaux accessibles en écriture.';

$txt['error_php_too_low'] = 'Attention ! Il semblerait que version de PHP ne réponde pas aux exigences minimales requises de ElKarte<strong>.<br />Si vous n\'êtes pas votre propre hébergeur, vous devez lui demander d\'effectuer une mise à jour, ou utiliser un autre hébergeur. Autrement, veuillez mettre à jour PHP vers une version plus récente.<br /><br />Si vous êtes certain que votre version de PHP est assez récente, vous pouvez continuer, bien que cela soit fortement déconseillé.';
$txt['error_missing_files'] = 'Incapable de trouver les fichiers nécessaires à l\'installation dans le répertoire de ce script !<br /><br />Veuillez vous assurer d\'avoir transféré la totalité des fichiers de l\'archive d\'installation, incluant le fichier SQL, et réessayez plus tard.';
$txt['error_session_save_path'] = 'Veuillez informer votre hébergeur que le <strong>session.save_path spécifié dans php.ini</strong> est invalide !  Il a besoin d\'être changé vers un répertoire <strong>existant</strong> et <strong>accessible en écriture</strong> par l\'utilisateur sur lequel fonctionne PHP.<br />';
$txt['error_windows_chmod'] = 'Vous êtes sous un serveur Windows, et quelques fichiers cruciaux ne sont pas accessibles en écriture. Veuillez contacter votre hébergeur afin qu\'il donne des <strong>permissions d\'écritures</strong> à l\'utilisateur sur lequel PHP fonctionne pour les fichiers de votre installation de ElKarte.  Les fichiers ou dossiers suivants doivent être accessibles en écriture : ';
$txt['settings_error'] = 'Vos paramètres n\'ont pas pu être enregistrés dans Settings.php, le fichier n\'est pas accessible en écriture.';
$txt['error_ftp_no_connect'] = 'Impossible de se connecter au serveur FTP avec ces renseignements.';
$txt['error_db_file'] = 'Impossible de trouver le script source de la base de données ! Veuillez vérifier que le fichier %1$s est dans le répertoire source de votre forum.';
$txt['error_db_connect'] = 'Impossible de se connecter au serveur de base de données avec les informations fournies.<br /><br />Si vous n\'êtes pas sûr de ces informations, veuillez contacter votre hébergeur.';
$txt['error_db_too_low'] = 'La version de votre base de données est très ancienne et ne répond pas aux besoins minimum de ElKarte.<br /><br /> Veuillez contacter votre hébergeur pour qu\'il mette le serveur à jour ou vous en fournisse un nouveau, et s\'il ne veut pas, essayez un autre hébergeur.';
$txt['error_db_database'] = 'L\'installateur n\'a pas pu accéder à la base de données &quot;<em>%1$s</em>&quot;. Avec certains hébergeurs, vous devez créer la base de données dans votre panneau administrateur avant que ElKarte ne puisse l\'utiliser. Certains aussi ajoutent des préfixes - comme votre nom d\'utilisateur - aux noms de vos bases de données.';
$txt['error_db_queries'] = 'Certaines requêtes n\'ont pu été exécutées normalement. C\'est peut-être dû à une version trop ancienne ou trop récente de votre base de données.<br /><br />Informations techniques sur les requêtes&nbsp;:';
$txt['error_db_queries_line'] = 'Ligne #';
$txt['error_db_missing'] = 'L\'installateur a n\'a pas pu détecter dans PHP le support pour les bases de données que ElKarte peut utiliser. Veuillez demander à votre hébergeur de s\'assurer que PHP a été compilé avec les bases de données désirées, ou que l\'extension PHP associée a bien été chargée. Actuellement ElKarte fonctionne avec les extensions suivantes : %1$s. ';
$txt['error_db_script_missing'] = 'L\'installateur n\'a pas trouvé de fichier de script pour la base de données demandée. Vérifiez que vous avez mis en ligne tous les fichiers nécessaires, par exemple &quot;%1$s&quot;';
$txt['error_session_missing'] = 'L\'installateur a été incapable de détecter le support des sessions dans la version de PHP installé sur votre serveur.  Veuillez demander à votre hébergeur de vérifier que PHP a été compilé avec le support des sessions (en fait, ça doit être explicitement spécifié compilé sans cela.)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Vous avez tapé deux mots de passe différents !';
$txt['error_user_settings_no_password'] = 'Votre mot de passe doit avoir au moins quatre caractères.';
$txt['error_user_settings_taken'] = 'Désolé, un membre est déjà inscrit avec ce nom d\'utilisateur et / ou cette adresse e-mail.<br /><br /> Un nouveau compte n\'a pas été créé.';
$txt['error_user_settings_query'] = 'Une erreur de base de données s\'est produite lors de la création d\'un administrateur.  L\'erreur était :';
$txt['error_subs_missing'] = 'Impossible de trouver le fichier sources/Subs.php.  Veuillez vous assurer qu\'il a été transféré correctement, puis réessayez à nouveau.';
$txt['error_db_alter_priv'] = 'Le compte de base de données que vous avez spécifié n\'a pas la permission de modifier (ALTER), créer (CREATE) et/ou supprimer (DROP) les tables de la base de données. Ces droits sont nécessaires au bon fonctionnement de ElKarte.';
$txt['error_versions_do_not_match'] = 'L\'installateur a détecté une autre version de ElKarte déjà installée avec les informations spécifiées. Si vous essayez de lancer la mise à jour, vous devez utiliser l\'upgradeur et non pas l\'installateur.<br /><br />Ou alors, vous pouvez utiliser des informations différentes, ou effectuer une sauvegarde puis supprimer les données actuellement dans la base de donnée.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'La version actuelle de votre base de données ne prend pas en charge l\'utilisation du jeu de caractères UTF-8. Vous ne pouvez pas installer ElkArte. ';
$txt['error_valid_email_needed'] = 'Vous n\'avez pas saisie une adresse de courriel valide.';
$txt['error_already_installed'] = 'L\'installateur a détecté que ElKarte est déjà installé. Il est fortement recommandé de ne <strong>pas</strong> essayer d\'écraser une installation existante - poursuivre l\'installation <strong>peut provoquer la perte ou la corruption des données existantes</strong>.<ul><li>Si vous venez juste de terminer l\'installation de votre forum veuillez supprimer du serveur le répertoire /install. {try_delete}</li><li>Si vous voulez effectuer une mise à jour, veuillez utiliser <a href="./upgrade.php"><strong>le script de mise à jour</strong></a>.</li><li>Si vous voulez écraser votre installation existante, y compris toutes ses données, il est recommandé d\'effacer manuellement les tables de la base de données, de remplacer le fichier Settings.php et de réessayer.';
$txt['error_no_settings'] = 'Il semble que Settings.php et/ou Settings_bak.php n\'existent pas dans le répertoire par défaut de votre forum, ElKarte va essayer de renommer les fichiers exemples copiés lors de l\'installation. Si l\'opération échoue veuillez renommer les fichiers Settings.sample.php et Settings_bak.sample.php respectivement en Settings.php et Settings_bak.php avant de relancer ce script. ';
$txt['error_settings_do_not_exist'] = 'ElKarte ne peut pas trouver et créer le(s) fichier(s) <strong>%1$s</strong>. Veuillez utiliser FTP pour accéder au répertoire de votre forum et renommer les fichiers exemples fournis avec le paquet d\'installation comme suit avant d\'exécuter à nouveau ce script : <ul>%2$s</ul>Si aucun des fichiers n\'existe créez un fichier vide avec le même nom. ';
$txt['error_warning_notice'] = 'Attention !';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Vous devez donner un nom au fichier de base de données pour SQLite.';
$txt['error_db_prefix_numeric'] = 'Le type de base de données choisi ne supporte pas l\'utilisation de nombres en tant que préfixe.';
$txt['error_invalid_characters_username'] = 'Caractère invalide dans le nom d\'utilisateur.';
$txt['error_username_too_long'] = 'Le nom d\'utilisateur doit faire moins de 25 caractères.';
$txt['error_username_left_empty'] = 'Le champ du nom d\'utilisateur est resté vide.';
$txt['error_db_filename_exists'] = 'La base de données que vous essayez de créer existe déjà. Effacez la base de données actuelle ou choisissez un autre nom.';
$txt['error_db_prefix_reserved'] = 'Le préfixe que vous avez indiqué est un préfixe réservé. Merci d\'en choisir un nouveau.';

$txt['upgrade_upgrade_utility'] = 'Utilitaire de mise à niveau ElkArte';
$txt['upgrade_warning'] = 'Attention !';
$txt['upgrade_critical_error'] = 'Erreur Critique !';
$txt['upgrade_continue'] = 'Continuer';
$txt['upgrade_retry'] = 'Recommencez';
$txt['upgrade_skip'] = 'Passer';
$txt['upgrade_note'] = 'Note !';
$txt['upgrade_step'] = 'Étape';
$txt['upgrade_steps'] = 'Étapes';
$txt['upgrade_progress'] = 'Avancement';
$txt['upgrade_overall_progress'] = 'Avancement Général';
$txt['upgrade_step_progress'] = 'Avancement de l\'Étape';
$txt['upgrade_time_elapsed'] = 'Temps Écoulé';
$txt['upgrade_time_mins'] = 'mins';
$txt['upgrade_time_secs'] = 'secondes';

$txt['upgrade_incomplete'] = 'Incomplet';
$txt['upgrade_not_quite_done'] = 'Une seconde, ce n\'est pas fini !';
$txt['upgrade_paused_overload'] = 'La mise à jour a été mise en pause afin d\'éviter de surcharger votre serveur. Ne vous inquiétez pas, aucun souci, cliquez simplement sur le bouton <label for="contbutt">Continuer</label> ci-dessous pour continuer.';

$txt['upgrade_ready_proceed'] = 'Merci d\'avoir choisi de mettre à jour ElKarte en version %1$s. Tous les fichiers sont en place, et nous sommes prêt à poursuivre.';

$txt['upgrade_error_script_js'] = 'Le script de mise à jour ne trouve pas script.js, ou le fichier n\'est pas à jour. Assurez-vous que les chemins vers les thèmes sont correctement renseignés. Vous pouvez télécharger un outil de vérification et de réparation des paramètres sur <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">Utilitaires ElKarte</a>. ';

$txt['upgrade_warning_lots_data'] = 'Le script de mise à jour a détecté de nombreux fichiers nécessitant une mise à jour. Ce processus peut éventuellement prendre du temps, en fonction de la puissance du serveur et de la taille du forum, et jusqu\'à plusieurs heures pour des forums conséquents (300,000 messages et plus).';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';