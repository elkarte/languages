<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Régler les paramètres de recherche';
$txt['choose_board'] = 'Choisir une section dans laquelle rechercher, ou chercher dans toutes les sections';
$txt['all_words'] = 'Tous les mots';
$txt['any_words'] = 'N\'importe quel mot';
$txt['by_user'] = 'Par utilisateur';

$txt['search_post_age'] = 'Âge du message';
$txt['search_between'] = 'entre';
$txt['search_and'] = 'et';
$txt['search_options'] = 'Options';
$txt['search_show_complete_messages'] = 'Afficher les résultats comme des messages';
$txt['search_subject_only'] = 'Titres des sujets seulement';
$txt['search_relevance'] = 'Pertinence';
$txt['search_date_posted'] = 'Date d\'écriture';
$txt['search_order'] = 'Ordre de recherche';
$txt['search_orderby_relevant_first'] = 'Les résultats les plus pertinents en premier';
$txt['search_orderby_large_first'] = 'Les plus longs sujets en premier';
$txt['search_orderby_small_first'] = 'Les plus courts sujets en premier';
$txt['search_orderby_recent_first'] = 'Les plus récents sujets en premier';
$txt['search_orderby_old_first'] = 'Les plus anciens sujets en premier';
$txt['search_visual_verification_label'] = 'Vérification';
$txt['search_visual_verification_desc'] = 'Veuillez entrer le code contenu dans l\'image ci-dessus pour utiliser la recherche.';

$txt['search_specific_topic'] = 'Chercher les messages seulement dans le sujet';

$txt['groups_search_posts'] = 'Groupes de membres ayant accès à la fonction de recherche';
$txt['search_dropdown'] = 'Activer la liste déroulante Recherche rapide ';
$txt['search_results_per_page'] = 'Nombre de résultats par page';
$txt['search_weight_frequency'] = 'Résultats affichés selon un facteur de fréquence de correspondance';
$txt['search_weight_age'] = 'Résultats affichés selon un facteur d\'ancienneté du dernier message corespondant dans un sujet';
$txt['search_weight_length'] = 'Résultats affichés selon un facteur de longueur du sujet';
$txt['search_weight_subject'] = 'Résultats affichés selon un facteur de correspondance avec le sujet';
$txt['search_weight_first_message'] = 'Résultats affichés selon un facteur de correspondance dans le premier message d\'une discussion';
$txt['search_weight_sticky'] = 'Résultats affichés en fonction des sujets épinglés ';
$txt['search_weight_likes'] = 'Résultats affichés en fonctions des sujets "Aimés" ';

$txt['search_settings_desc'] = 'Ici vous pouvez modifier les réglages de base de la fonction de recherche. ';
$txt['search_settings_title'] = 'Paramètres de recherche ';

$txt['search_weights_desc'] = 'Ici vous pouvez changer les éléments prioritaires dans la recherche par pertinence.';
$txt['search_weights_sphinx'] = 'Pour mettre à jour les facteurs de pondération avec Sphinx, vous devez générer et installer un nouveau fichier sphinx.conf. ';
$txt['search_weights_title'] = 'Recherche - facteurs';
$txt['search_weights_total'] = 'Total';
$txt['search_weights_save'] = 'Enregistrer';

$txt['search_method_desc'] = 'Ici vous pouvez paramétrer la façon dont la recherche est faite.';
$txt['search_method_title'] = 'Recherche - méthode';
$txt['search_method_save'] = 'Enregistrer';
$txt['search_method_messages_table_space'] = 'Espace utilisé par les messages du forum dans la base de données';
$txt['search_method_messages_index_space'] = 'Espace utilisé pour l\'indexation des messages dans la base de données';
$txt['search_method_kilobytes'] = 'Ko';
$txt['search_method_fulltext_index'] = 'Indexation du texte';
$txt['search_method_no_index_exists'] = 'n\'existe pas actuellement';
$txt['search_method_fulltext_create'] = 'Créer un index en texte intégral ';
$txt['search_method_fulltext_cannot_create'] = 'ne peut être créé car le message dépasse la taille de 65,535 caractères ou la table n\'est pas du type MyISAM';
$txt['search_method_index_already_exists'] = 'existe déjà';
$txt['search_method_fulltext_remove'] = 'enlever l\'index de texte';
$txt['search_method_index_partial'] = 'partiellement créé';
$txt['search_index_custom_resume'] = 'reprendre';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'Afin de pouvoir utiliser la recherche en texte intégral, vous devrez d\\\'abord créer un index !';
$txt['search_index_custom_warning'] = 'Pour pouvoir utiliser un index de recherche personnalisé, vous devez d\'abord créer un index personnalisé !';

$txt['search_index'] = 'Index de recherche';
$txt['search_index_none'] = 'Aucun index';
$txt['search_index_custom'] = 'Index personnalisé';
$txt['search_index_label'] = 'Index';
$txt['search_index_size'] = 'Taille';
$txt['search_index_create_custom'] = 'Créer un index personnalisé ';
$txt['search_index_custom_remove'] = 'Supprimer un index personnalisé';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'Pour ajuster les paramètres de Sphinx aller sur <a class="linkbutton" href="{managesearch_url}">Configurer Sphinx</a> ';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'Pour ajuster les paramètres de SphinxQL aller sur <a class="linkbutton" href="{managesearch_url}">Configurer Sphinx</a> ';

$txt['search_force_index'] = 'Forcer l\'utilisation d\'un index personnalisé';
$txt['search_match_words'] = 'Ne chercher que sur des mots complets';
$txt['search_max_results'] = 'Nombre maximal de résultats à afficher';
$txt['search_max_results_disable'] = '(0 : aucune limite)';
$txt['search_floodcontrol_time'] = 'Délai nécessaire entre les recherches d\'un même membre';
$txt['search_floodcontrol_time_desc'] = '(en secondes, 0 pour pas de limite)';

$txt['additional_search_engines'] = 'Moteurs de recherche supplémentaires ';
$txt['setup_search_engine_add_more'] = 'Ajouter un autre moteur de recherche ';

$txt['search_create_index'] = 'Créer un index';
$txt['search_create_index_why'] = 'Pourquoi créer un index de recherche ?';
$txt['search_create_index_start'] = 'Créer';
$txt['search_predefined'] = 'Profil pré-défini';
$txt['search_predefined_small'] = 'Index de petite taille';
$txt['search_predefined_moderate'] = 'Index de taille moyenne';
$txt['search_predefined_large'] = 'Index de taille importante';
$txt['search_create_index_continue'] = 'Continuer';
$txt['search_create_index_not_ready'] = 'ElKarte est en train de créer un index de recherche de vos messages. Afin d\'éviter une surcharge du serveur, le processus a été temporairement interrompu. Il devrait reprendre automatiquement dans quelques secondes. Si ce n\'est pas le cas, veuillez cliquer ci-dessous sur "Poursuivre". ';
$txt['search_create_index_progress'] = 'Avancement';
$txt['search_create_index_done'] = 'Index de recherche personnalisé créé. ';
$txt['search_create_index_done_link'] = 'Continuer';
$txt['search_double_index'] = 'Vous avez créé deux index pour la table des messages. Pour de meilleures performances, il est conseillé de supprimer l\'un de ces deux index.';

$txt['search_error_indexed_chars'] = 'Nombre invalide de caractères indéxés. Pour un index performant, au moins 3 caractères sont nécessaires.';
$txt['search_error_max_percentage'] = 'Pourcentage invalide de termes à ignorer. Veuillez utiliser une valeur d\'au moins 5%.';
$txt['error_string_too_long'] = 'La chaîne de caractères à rechercher doit être plus petite que %1$d caractères.';

$txt['search_warning_ignored_word'] = 'Le terme suivant a été ignoré dans votre recherche ';
$txt['search_warning_ignored_words'] = 'Les termes suivants ont été ignorés dans votre recherche ';

$txt['search_adjust_query'] = 'Ajuster les paramètres de recherche';
$txt['search_adjust_submit'] = 'Réviser la recherche';
$txt['search_did_you_mean'] = 'Vous avez peut-être voulu chercher';

$txt['search_example'] = '<em>ex :</em> Orwell "La Ferme des animaux" -film';

$txt['search_engines_description'] = 'D\'ici, vous pouvez décider dans quelle mesure vous voulez surveiller les moteurs de recherche lors de leur indexation du forum, ainsi que consulter le journal des visites de ces moteurs.';
$txt['spider_mode'] = 'Niveau de suivi des moteurs de recherche ';
$txt['spider_mode_note'] = 'Notez qu\'un niveau de suivi supérieur augmente les besoins en ressources du serveur. ';
$txt['spider_mode_off'] = 'Désactivé';
$txt['spider_mode_standard'] = 'Standard';
$txt['spider_mode_high'] = 'Modérer';
$txt['spider_mode_vhigh'] = 'Agressif ';
$txt['spider_settings_desc'] = 'Vous pouvez modifier les réglages de surveillance des robots à partir de cette page. Notez que si vous voulez activer le délestage automatique des journaux de visites, c\'est par <a href="%1$s">ici</a> que ça se passe';

$txt['spider_group'] = 'Appliquer des autorisations restrictives à partir du groupe';
$txt['spider_group_note'] = 'Pour vous permettre d\'empêcher les robots d\'indexer certaines pages.';
$txt['spider_group_none'] = 'Désactivé';

$txt['show_spider_online'] = 'Montrer les robots sur la page &quot;Qui est en ligne&quot;';
$txt['show_spider_online_no'] = 'Pas du tout';
$txt['show_spider_online_summary'] = 'Montrer le nombre de robots';
$txt['show_spider_online_detail'] = 'Montrer le nom des robots';
$txt['show_spider_online_detail_admin'] = 'Montrer le nom des robots, mais juste à l\'administrateur';

$txt['spider_name'] = 'Nom du Robot';
$txt['spider_last_seen'] = 'Dernière activité';
$txt['spider_last_never'] = 'Jamais';
$txt['spider_agent'] = 'User-Agent';
$txt['spider_ip_info'] = 'Adresses IP';
$txt['spiders_add'] = 'Ajouter un nouveau Robot';
$txt['spiders_edit'] = 'Modifier';
$txt['spiders_remove_selected'] = 'Effacer la sélection';
$txt['spider_remove_selected_confirm'] = 'Êtes-vous ceratin de vouloir supprimer ces robots ?\\n\\nToutes les statistiques associées seront aussi effacées ! ';
$txt['spiders_no_entries'] = 'Aucun robot configuré pour le moment.';

$txt['add_spider_desc'] = 'D\'ici, vous pouvez modifier les paramètres permettant de reconnaître un robot. Si le User-Agent ou l\'adresse IP d\'un invité correspond à ce qui est entré ci-dessous, il sera considéré comme un robot de moteur de recherche et surveillé comme demandé dans les préférences du forum.';
$txt['spider_name_desc'] = 'Nom avec lequel le robot sera référencé.';
$txt['spider_agent_desc'] = 'User-Agent associé à ce robot.';
$txt['spider_ip_info_desc'] = 'Séparées par des virgules, la liste des adresses IP associées à ce robot.';

$txt['spider_time'] = 'Date';
$txt['spider_viewing'] = 'A visité';
$txt['spider_logs_empty'] = 'Le journal de robots est vide pour le moment.';
$txt['spider_logs_info'] = 'Notez que l\'archivage des actions de robot ne se produit que si le suivi est réglé sur "élevé" ou "très élevé". Le détail de toutes les actions n\'est enregistré que si le suivi est fixé à "très élevé".';
$txt['spider_disabled'] = 'Désactivé';
$txt['spider_log_empty_log'] = 'Clear Log';
$txt['spider_log_empty_log_confirm'] = 'Êtes vous certain de vouloir complètement vider les journaux ?';

$txt['spider_logs_delete'] = 'Effacer les Entrées';
$txt['spider_logs_delete_older'] = 'Effacer toutes les entrées antérieures à %1$s jours. ';
$txt['spider_logs_delete_submit'] = 'Effacer';

$txt['spider_stats_delete_older'] = 'Supprimer toutes les statistiques des robots que l\'on n\'a pas vu depuis %1$s jours. ';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Êtes-vous sûr de vouloir vider le journal d\'activité des robots ?';

$txt['spider_stats_select_month'] = 'Aller au mois de';
$txt['spider_stats_page_hits'] = 'Pages visitées';
$txt['spider_stats_no_entries'] = 'Pas de statistiques disponibles sur les robots pour le moment.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'Vous n\'avez pas encore choisi d\'utiliser Sphinx ou SphinxQL comme méthode de recherche ';
$txt['sphinx_test_passed'] = 'Tous les tests ont réussi, le système a pu se connecter au démon de recherche sphinx avec l\'API Sphinx. ';
$txt['sphinxql_test_passed'] = 'Tous les tests ont réussi, le système a pu se connecter au démon de recherche sphinx avec les commandes SphinxQL. ';
$txt['sphinx_test_connect_failed'] = 'Impossible de se connecter au démon Sphinx. Assurez-vous qu\'il est en cours d\'exécution et configuré correctement. La recherche Sphinx ne fonctionnera pas tant que vous n\'aurez pas résolu le problème. ';
$txt['sphinxql_test_connect_failed'] = 'Impossible d\'accéder à SphinxQL. Assurez-vous que votre fichier sphinx.conf a une directive d\'écoute distincte pour le port SphinxQL. La recherche SphinxQL ne fonctionnera pas tant que vous n\'aurez pas résolu le problème. ';
$txt['sphinx_test_api_missing'] = 'Le fichier sphinxapi.php est absent de votre dossier /sources. Vous devez copier ce fichier depuis la distribution Sphinx. La recherche Sphinx ne fonctionnera pas tant que vous n\'aurez pas résolu le problème. ';
$txt['sphinx_description'] = 'Utilisez cette interface pour fournir les détails d\'accès à votre démon de recherche Sphinx. <strong>Ces paramètres ne sont utilisés que pour créer</strong> un fichier initial de configuration sphinx.conf que vous devrez enregistrer dans votre répertoire de configuration Sphinx (généralement /usr/local/ etc ou /etc/sphinxsearch). En général, les options ci-dessous peuvent être laissées telles quelles, mais elles supposent que le logiciel Sphinx a été installé dans /usr/local et utilisent /var/sphinx pour le stockage des données d\'index de recherche. Afin de maintenir Sphinx à jour, vous devez utiliser une tâche cron pour mettre à jour les index, sinon le contenu nouveau ou supprimé n\'apparaîtra pas dans les résultats de la recherche. Le fichier de configuration définit deux index : <br /><br/><strong>elkarte_delta_index,</strong> un index qui ne stocke que les modifications récentes et peut être appelé fréquemment ; <strong>elkarte_base_index</strong>, un index qui stocke la base de données complète et devrait être appelé moins fréquemment. Exemple : <br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Préfixe d\'index : ';
$txt['sphinx_index_prefix_desc'] = 'Il s\'agit du préfixe des index de base et delta. <br />Par défaut il utilise elkarte et les deux index seront elkarte_base_index et elkarte_delta_index. Sphinx se connectera à elkarte_index (prefix_index). Si vous modifiez cela, assurez-vous d\'utiliser le préfixe correct dans votre tâche cron. ';
$txt['sphinx_index_data_path'] = 'Chemin des données d\'index : ';
$txt['sphinx_index_data_path_desc'] = 'C\'est le chemin qui contient les fichiers d\'index de recherche utilisés par Sphinx. <br />Il <strong>doit</strong> exister et être accessible en lecture et en écriture par l\'indexeur Sphinx et le démon de recherche. ';
$txt['sphinx_log_file_path'] = 'Chemin du fichier journal : ';
$txt['sphinx_log_file_path_desc'] = 'Chemin du serveur qui contiendra les fichiers journaux créés par Sphinx. Ce répertoire doit exister sur votre serveur et doit être accessible en écriture par le démon de recherche et l\'indexeur sphinx. ';
$txt['sphinx_stop_word_path'] = 'Chemin du mot d\'arrêt : ';
$txt['sphinx_stop_word_path_desc'] = 'Le chemin du serveur vers la liste de mots d\'arrêt (laissez vide pour aucune liste de mots d\'arrêt). ';
$txt['sphinx_memory_limit'] = 'Limite de mémoire de l\'indexeur Sphinx : ';
$txt['sphinx_memory_limit_desc'] = 'La quantité maximale de mémoire (RAM) que l\'indexeur est autorisé à utiliser. ';
$txt['sphinx_searchd_server'] = 'Serveur de démon de recherche : ';
$txt['sphinx_searchd_server_desc'] = 'Adresse du serveur exécutant le démon de recherche. Il doit s\'agir d\'un nom d\'hôte ou d\'une adresse IP valide. S\'il n\'est pas défini, localhost sera utilisé. ';
$txt['sphinx_searchd_port'] = 'Port du démon de recherche : ';
$txt['sphinx_searchd_port_desc'] = 'Port sur lequel le démon de recherche écoutera. ';
$txt['sphinx_searchd_qlport'] = 'Port du démon Sphinx QL : ';
$txt['sphinx_searchd_qlport_desc'] = 'Port sur lequel le démon de recherche écoutera les requêtes SphinxQL. ';
$txt['sphinx_max_matches'] = 'Nombre maximum de correspondances : ';
$txt['sphinx_max_matches_desc'] = 'Nombre maximal de correspondances renvoyées par le démon de recherche. ';
$txt['sphinx_create_config'] = 'Créer la configuration Sphinx ';
$txt['sphinx_test_connection'] = 'Tester la connexion au démon Sphinx ';