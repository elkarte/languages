<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Procéder';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Lister les fichiers du paquet';
$txt['files_archive'] = 'Fichiers dans l\'archive';
$txt['package_browse'] = 'Parcourir';
$txt['add_server'] = 'Ajouter un serveur';
$txt['server_name'] = 'Nom du serveur';
$txt['serverurl'] = 'Adresse';
$txt['no_packages'] = 'Pas encore de paquet.';
$txt['download'] = 'Télécharger';
$txt['download_success'] = 'Paquet téléchargé avec succès';
$txt['package_downloaded_successfully'] = 'Le paquet a été téléchargé avec succès';
$txt['package_manager'] = 'Gestionnaire de paquets';
$txt['install_mod'] = 'Installer l\'extension';
$txt['uninstall_mod'] = 'Désinstaller l\'extension';
$txt['no_adds_installed'] = 'Aucune extension actuellement installée';
$txt['uninstall'] = 'Désinstaller';
$txt['delete_list'] = 'Effacer la liste des extensions';
$txt['package_delete_list_warning'] = 'Êtes-vous sûr de vouloir effacer la liste des modules complémentaires installés ? ';

$txt['package_manager_desc'] = 'À partir de cette interface facile à utiliser, vous pouvez télécharger et installer des modules complémentaires à utiliser sur votre forum. ';
$txt['installed_packages_desc'] = 'Vous pouvez utiliser l\'interface ci-dessous pour voir les paquets actuellement installés sur le forum et enlever ceux que vous ne voulez plus.';
$txt['download_packages_desc'] = 'À partir de cet espace, vous pouvez ajouter ou supprimer des serveurs de paquets, rechercher des paquets ou télécharger de nouveaux paquets à partir de serveurs. ';
$txt['package_servers_desc'] = 'Depuis cette interface simple d\'utilisation, vous pouvez gérer vos serveurs de paquets et télécharger des modules complémentaires compressés sur votre forum. ';
$txt['upload_packages_desc'] = 'À partir de cet espace vous pouvez téléverser un fichier de paquet depuis votre ordinateur local sur le forum. ';

$txt['upload_new_package'] = 'Transférer un nouveau paquet';
$txt['view_and_remove'] = 'Afficher et supprimer des paquets installés ';
$txt['modification_package'] = 'Paquets de modules complémentaires';
$txt['avatar_package'] = 'Paquets d\'avatars';
$txt['language_package'] = 'Paquets de langue';
$txt['unknown_package'] = 'Autres paquets';
$txt['smiley_package'] = 'Paquets d\'émoticônes';
$txt['use_avatars'] = 'Utiliser les avatars';
$txt['add_languages'] = 'Ajouter Langue';
$txt['list_files'] = 'Lister les fichiers';
$txt['package_type'] = 'Type de paquet';
$txt['extracting'] = 'Extraction';
$txt['avatars_extracted'] = 'Les avatars ont été installés, vous devriez maintenant pouvoir les utiliser. ';
$txt['language_extracted'] = 'Le paquet de langue a été installé, vous pouvez maintenant autoriser son utilisation dans les paramètres de langue de votre panneau de contrôle d\'administration. ';

$txt['mod_name'] = 'Nom de l\'extension';
$txt['mod_version'] = 'Version';
$txt['mod_author'] = 'Auteur';
$txt['author_website'] = 'Page web de l\'auteur';
$txt['package_no_description'] = 'Pas de description donnée';
$txt['package_description'] = 'Description';
$txt['file_location'] = 'Télécharger';
$txt['bug_location'] = 'Traqueur d\'incidents';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'Aucune source éditée ';
$txt['mod_date'] = 'Dernière mise à jour ';
$txt['mod_section_count'] = 'Parcourir les modules complémentaires (%1d) dans cet espace ';

// Package Server strings
$txt['package_current'] = '(%s <em>Vous avez la dernière version %s</em>) ';
$txt['package_update'] = '(%s <em>Une mise à jour pour votre version %s est disponible</em>) ';
$txt['package_installed'] = 'installé';
$txt['package_downloaded'] = 'téléchargé';

$txt['package_installed_key'] = 'Extensions installées : ';
$txt['package_installed_current'] = 'version actuelle';
$txt['package_installed_old'] = 'version plus ancienne';
$txt['package_installed_warning1'] = 'Ce paquet est déjà installé, et aucune mise à jour n\'a été trouvée. ';
$txt['package_installed_warning2'] = 'Vous devriez d\'abord désinstaller l\'ancienne version pour éviter des problèmes, ou demander à l\'auteur de créer une mise à jour de votre vieille version.';
$txt['package_installed_warning3'] = 'Attention, souvenez-vous de toujours sauvegarder vos fichiers sources et votre base de données avant d\'installer des modifications, surtout pour celles en version bêta.';
$txt['package_installed_extract'] = 'Extraction du paquet';
$txt['package_installed_done'] = 'Le paquet a été installé avec succès. Vous devriez maintenant pouvoir utiliser toutes les fonctionnalités qu\'il ajoute ou modifie, ou au contraire ne plus pouvoir utiliser celles qu\'il retire.';
$txt['package_installed_redirecting'] = 'Redirection...';
$txt['package_installed_redirect_go_now'] = 'Redirection immédiate';
$txt['package_installed_redirect_cancel'] = 'Revenir au gestionnaire de paquets';

$txt['package_upgrade'] = 'Mettre à jour';
$txt['package_uninstall_readme'] = 'Instructions de désinstallation';
$txt['package_install_readme'] = 'Instructions d\'installation';
$txt['package_install_license'] = 'Licence';
$txt['package_install_type'] = 'Type';
$txt['package_install_action'] = 'Action';
$txt['package_install_desc'] = 'Description';
$txt['install_actions'] = 'Actions d\'installation';
$txt['perform_actions'] = 'Cela effectuera les actions suivantes : ';
$txt['corrupt_compatible'] = 'Le package que vous essayez de télécharger ou d\'installer est soit corrompu, soit incompatible avec cette version du logiciel. ';
$txt['package_create'] = 'Créer';
$txt['package_move'] = 'Déplacer';
$txt['package_delete'] = 'Effacer';
$txt['package_extract'] = 'Extraire';
$txt['package_file'] = 'Fichier';
$txt['package_tree'] = 'Arborescence';
$txt['execute_modification'] = 'Appliquer la modification';
$txt['execute_code'] = 'Exécuter le code';
$txt['execute_database_changes'] = 'Exécuter le fichier ';
$txt['execute_hook_add'] = 'Ajouter un crochet ';
$txt['execute_hook_remove'] = 'Supprimer le crochet ';
$txt['execute_hook_action'] = 'Adaptation du crochet %1$s';
$txt['package_requires'] = 'Modifications nécessaires ';
$txt['package_check_for'] = 'Vérification de l\'installation : ';
$txt['execute_credits_add'] = 'Ajouter des Crédits';
$txt['execute_credits_action'] = 'Credits : %1$s';

$txt['package_install_actions'] = 'Actions d\'installation pour';
$txt['package_will_fail_title'] = 'Erreur dans le paquet %1$s';
$txt['package_will_fail_warning'] = 'Au moins une erreur a été rencontrée lors d\'un test d\'installation de ce paquet %1$s.
<br />Il est <strong>vivement</strong> recommandé de ne pas poursuivre l\'installation de %1$s à moins d\'être sûr de ce que vous faites et que vous avez fait très récemment une de sauvegarde de votre forum et de votre base de données.<br /><br /> Cette erreur peut être causée entre autre par un conflit avec le paquet que vous tentez d\'installer et un autre paquet que vous avez précédemment installé, une erreur dans le paquet lui-même, un paquet qui requiert un autre paquet que vous n\'avez pas encore installé, ou un paquet écrit pour une autre version de ElKarte.';
$txt['package_will_fail_unknown_action'] = 'Le paquet tente d\'effectuer une action inconnue : %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Êtes-vous sûr de vouloir continuer l\'installation de ce module complémentaire, même s\'il ne s\'installe pas correctement ? ';
$txt['package_will_fail_popup_uninstall'] = 'Êtes-vous sûr de vouloir continuer a désinstallation de ce module complémentaire, même s\'il ne se désinstalle pas correctement?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'suppression';
$txt['package_install_now'] = 'Installer maintenant ';
$txt['package_uninstall_now'] = 'Désinstaller maintenant ';
$txt['package_other_themes'] = 'Installer dans d\'autres thèmes ';
$txt['package_other_themes_uninstall'] = 'Désinstaller dans d\'autres thèmes ';
$txt['package_other_themes_desc'] = 'Pour utiliser ce module complémentaire dans d\'autres thèmes que celui par défaut, le gestionnaire de paquets a besoin de faire des changements supplémentaires dans les autres thèmes. Si vous désirez installer ce module complémentaire dans d\'autres thèmes, veuillez sélectionner ces derniers ci-dessous.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Au moins une erreur a été rencontrée durant un test d\'installation de ce thème. Êtes-vous sûr de vouloir tenter l\'installation ?';

$txt['package_bytes'] = 'octets';

$txt['package_action_missing'] = '<strong class="error">Fichier introuvable</strong>';
$txt['package_action_error'] = '<strong class="error">Erreur de syntaxe lors de la modification</strong>';
$txt['package_action_failure'] = '<strong class="error">Échec du test</strong>';
$txt['package_action_success'] = '<strong style="color: green">Réussite du test</strong>';
$txt['package_action_skipping'] = '<strong>Passer le fichier</strong>';

$txt['package_uninstall_actions'] = 'Actions de désinstallation';
$txt['package_uninstall_done'] = 'Le package a été désinstallé avec succès. ';
$txt['package_uninstall_cannot'] = 'Ce paquet ne peut pas être désinstallé car il n\'y a pas de désinstalleur.<br /><br /> Veuillez contacter l\'auteur du module complémentaire pour plus d\'informations.';

$txt['package_install_options'] = 'Options d\'installation';
$txt['package_install_options_desc'] = 'Définissez diverses options pour la façon dont le gestionnaire de packages installe les modules complémentaires, y compris les sauvegardes et l\'accès ftp';
$txt['package_install_options_ftp_why'] = 'Utiliser la fonction de transfert FTP du gestionnaire de paquets est la façon la plus simple d\'installer un paquet.  Vous devrez désigner manuellement les fichiers inscriptibles afin que le gestionnaire de paquets fonctionne.<br />Ici vous pouvez paramétrer les valeurs par défaut pour certains champs.';
$txt['package_install_options_ftp_server'] = 'Serveur FTP';
$txt['package_install_options_ftp_port'] = 'Port';
$txt['package_install_options_ftp_user'] = 'Identifiant';
$txt['package_install_options_make_backups'] = 'Créer une copie de sauvegarde des fichiers modifiés avec un tilde (~) à la fin de leurs noms.';
$txt['package_install_options_make_full_backups'] = 'Créez une sauvegarde complète (à l\'exclusion des smileys, des avatars et des pièces jointes) de l\'installation d\'ElKArte. ';

$txt['package_ftp_necessary'] = 'Informations FTP nécessaires';
$txt['package_ftp_why'] = 'Certains fichiers que le gestionnaire de paquets doit modifier ne sont pas accessibles en écriture. Cela doit être modifié en vous connectant par FTP pour changer les droits d\'accès ou créer les fichiers et dossiers. Vos informations de connexion FTP peuvent être temporairement conservées en cache pour que le gestionnaire de paquets puisse effectuer correctement les opérations. Notez que vous pouvez également faire ceci manuellement en utilisant un client FTP (pour voir une liste des fichiers concernés, veuillez cliquer <a href="#" onclick="%1$s">ici</a>)';
$txt['package_ftp_why_file_list'] = 'Les fichiers suivants ont besoin d\'être rendus inscriptibles pour continuer l\'installation&nbsp;:';
$txt['package_ftp_why_download'] = 'Pour télécharger des paquets, le dossier Packages et tous les fichiers qu\'il contient doivent être inscriptibles. Actuellement le système ne dispose pas des autorisations nécessaires pour écrire dans ce répertoire. Le gestionnaire de paquets peut utiliser vos informations FTP pour essayer de rectifier cela. ';
$txt['package_ftp_server'] = 'Serveur FTP';
$txt['package_ftp_port'] = 'Port';
$txt['package_ftp_username'] = 'Identifiant';
$txt['package_ftp_password'] = 'Mot de passe';
$txt['package_ftp_path'] = 'Chemin local vers ElkArte';
$txt['package_ftp_test'] = 'Test';
$txt['package_ftp_test_connection'] = 'Test de Connexion';
$txt['package_ftp_test_success'] = 'Connexion FTP établie.';
$txt['package_ftp_test_failed'] = 'Impossible de contacter le serveur.';
$txt['package_ftp_bad_server'] = 'Impossible de contacter le serveur.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Le paquet que vous tentez de supprimer est actuellement installé ! Si vous le supprimez maintenant, vous pourriez ne plus être capable de le désinstaller plus tard.

Voulez-vous continuer ?';

$txt['package_examine_file'] = 'Voir un fichier du paquet';
$txt['package_file_contents'] = 'Contenu du fichier';

$txt['package_upload_title'] = 'Transférer un paquet';
$txt['package_upload_select'] = 'Paquet à transférer';
$txt['package_upload'] = 'Transférer';
$txt['package_uploaded_success'] = 'Transfert du paquet réussi';
$txt['package_uploaded_successfully'] = 'Le paquet a été transféré avec succès';

$txt['package_modification_malformed'] = 'Fichier du module complémentaire mal formé ou invalide. ';
$txt['package_modification_missing'] = 'Le fichier ne peut pas être trouvé.';
$txt['package_no_zlib'] = 'Désolé, votre configuration de PHP n\'inclut pas le support pour <strong>zlib</strong>.  Sans cela, le gestionnaire de paquets ne peut pas fonctionner.  Veuillez contacter votre hébergeur pour plus d\'informations.';

$txt['package_cleanperms_title'] = 'Réinitialiser les droits d\'accès';
$txt['package_cleanperms_desc'] = 'Cette interface vous permet de réinitialiser les droits d\'accès des fichiers et répertoires de l\'installation de votre forum, afin d\'accroître la sécurité et de résoudre des éventuels problèmes liés aux droits d\'accès lors de l\'installation de paquets.';
$txt['package_cleanperms_type'] = 'Changer les droits d\'accès à travers le forum de façon à ce que';
$txt['package_cleanperms_standard'] = 'seuls les fichiers standards soient inscriptibles.';
$txt['package_cleanperms_free'] = 'tous les fichiers soient inscriptibles.';
$txt['package_cleanperms_restrictive'] = 'le moins de fichiers soient inscriptibles.';
$txt['package_cleanperms_go'] = 'Procéder au changement des droits sur les fichiers';

$txt['package_download_by_url'] = 'Télécharger un paquet par son URL';
$txt['package_download_filename'] = 'Nom du fichier';
$txt['package_download_filename_info'] = 'Valeur facultative. Doit être utilisé lorsque l\'URL ne se finit pas par le nom du fichier. Par exemple&nbsp;: index.php?mod=5';

$txt['package_db_uninstall'] = 'Supprimer toutes les données associées à ce module complémentaire. ';
$txt['package_db_uninstall_details'] = 'Détails';
$txt['package_db_uninstall_actions'] = 'Cocher cette option entraînera les actions suivantes ';
$txt['package_db_remove_table'] = 'Supprimer la table "%1$s"';
$txt['package_db_remove_column'] = 'Supprimer la colonne "%1$s" de "%2$s"';
$txt['package_db_remove_index'] = 'Supprimer l\'index "%1$s" de "%2$s"';

$txt['package_emulate_install'] = 'Installez l\'émulation : ';
$txt['package_emulate_uninstall'] = 'Désinstallez l\'émulation : ';

// Operations.
$txt['operation_find'] = 'Chercher';
$txt['operation_replace'] = 'Remplacer';
$txt['operation_after'] = 'Ajouter Après';
$txt['operation_before'] = 'Ajouter Avant';
$txt['operation_title'] = 'Opérations';
$txt['operation_ignore'] = 'Ignorer les Erreurs';
$txt['operation_invalid'] = 'L\'opération sélectionnée est invalide.';

$txt['package_file_perms_desc'] = 'Vous pouvez utiliser cette section pour vérifier si les dossiers et fichiers critiques de votre répertoire forum sont inscriptibles. Notez que seuls sont pris en compte les répertoires et fichiers-clé du forum - utilisez un client FTP pour plus d\'options.';
$txt['package_file_perms_name'] = 'Nom du fichier/répertoire ';
$txt['package_file_perms_status'] = 'État actuel';
$txt['package_file_perms_new_status'] = 'Nouvel État';
$txt['package_file_perms_status_read'] = 'Lu';
$txt['package_file_perms_status_write'] = 'Écriture';
$txt['package_file_perms_status_execute'] = 'Exécution';
$txt['package_file_perms_status_custom'] = 'Personnalisé';
$txt['package_file_perms_status_no_change'] = 'Pas de changement';
$txt['package_file_perms_writable'] = 'Inscriptible';
$txt['package_file_perms_not_writable'] = 'Non Inscriptible';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Plus de Fichiers';

$txt['package_file_perms_change'] = 'Changer les Permissions du Fichier';
$txt['package_file_perms_predefined'] = 'Utiliser un profil de permissions prédéfini';
$txt['package_file_perms_predefined_note'] = 'Notez que cela applique uniquement le profil prédéfini aux répertoires et fichiers clés. ';
$txt['package_file_perms_apply'] = 'Appliquer les permissions individuelles de fichiers choisies ci-dessus.';
$txt['package_file_perms_custom'] = 'Si "Personnalisé" a été sélectionné, utiliser la valeur chmod de';
$txt['package_file_perms_pre_restricted'] = 'Restreint - minimum de fichiers inscriptibles';
$txt['package_file_perms_pre_standard'] = 'Standard - fichiers-clé inscriptibles';
$txt['package_file_perms_pre_free'] = 'Libre - tous les fichiers sont inscriptibles';
$txt['package_file_perms_ftp_details'] = 'Sur la plupart des serveurs, il n\'est possible de changer les permissions des fichiers qu\'en utilisant un compte FTP. Veuillez entrer vos coordonnées FTP ci-dessous';
$txt['package_file_perms_ftp_retain'] = 'Notez que le système ne conservera les informations de mot de passe que temporairement pour faciliter le fonctionnement du gestionnaire de paquets. ';
$txt['package_file_perms_go'] = 'Appliquer les Changements';

$txt['package_file_perms_applying'] = 'Application des Changements';
$txt['package_file_perms_items_done'] = '%1$d éléments sur %2$d sont terminés';
$txt['package_file_perms_skipping_ftp'] = '<strong>Attention</strong>, impossible de se connecter au serveur FTP, tentative de modification des permissions sans passer par FTP. Cela va <em>probablement</em> échouer - veuillez contrôler les résultats à la fin et réessayez si nécessaire avec les coordonnées FTP correctes.';

$txt['package_file_perms_dirs_done'] = '%1$d répertoires sur %2$d sont terminés';
$txt['package_file_perms_files_done'] = '%1$d fichiers sur %2$d sont terminés dans le répertoire actuel';

$txt['chmod_value_invalid'] = 'Vous avez essayé d\'entrer une valeur de chmod invalide. Le chmod doit être entre les valeurs 0444 et 0777';

$txt['package_restore_permissions'] = 'Restaurer les autorisations de fichier ';
$txt['package_restore_permissions_desc'] = 'Les autorisations de fichier suivantes ont été modifiées afin d\'installer le(s) paquet(s) sélectionné(s). Vous pouvez ramener ces fichiers à leur état d\'origine en cliquant sur "Restaurer" ci-dessous. ';
$txt['package_restore_permissions_restore'] = 'Restaurer ce message';
$txt['package_restore_permissions_filename'] = 'Nom de fichier';
$txt['package_restore_permissions_orig_status'] = 'État d\'origine';
$txt['package_restore_permissions_cur_status'] = 'État actuel';
$txt['package_restore_permissions_result'] = 'Résultat';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - précédemment %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Ignoré</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Réussi</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="alert">Échec</span>';
$txt['package_restore_permissions_action_done'] = 'Une tentative de restauration des permissions d\'origine des fichiers sélectionnés s\'est terminée, les résultats peuvent être vus ci-dessous. Si une modification a échoué, ou pour un affichage plus détaillé des permissions de fichier, veuillez regarder la section <a href="%1$s">Permissions de Fichier</a>.';

$txt['package_file_perms_warning'] = 'Attention';
$txt['package_file_perms_warning_desc'] = '
	Faites attention lorsque vous changez les permissions de fichier à partir de cette section - des permissions incorrectes peuvent affecter défavorablement le fonctionnement de votre forum !<br />
	Sur certaines configurations serveur, appliquer de mauvaises permissions peut empêcher le forum de fonctionner.<br />
	Certains répertoires comme <em>attachments</em> ont besoin d\'être inscriptibles pour pouvoir utiliser les fichiers joints.<br />
	Cette fonctionnalité s\'applique surtout pour des serveurs non basés sur Windows - elle ne marchera pas comme voulu sur Windows en raison de modes de permission différents.<br />
	Avant de procéder soyez sûr d\'avoir un client FTP d\'installé, dans l\'éventualité ou vous feriez une erreur et que vous ayez besoin d\'accéder par FTP au serveur pour y remédier. ';

$txt['package_confirm_view_package_content'] = 'Êtes-vous sûr de vouloir visionner le contenu du paquet de l\'endroit suivant ?<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Procéder';
$txt['package_confirm_go_back'] = 'Retour';

$txt['package_readme_default'] = 'Défaut';
$txt['package_available_readme_language'] = 'Langues disponibles pour le Lisez-moi :';
$txt['package_license_default'] = 'Défaut';
$txt['package_available_license_language'] = 'Langues permises : ';