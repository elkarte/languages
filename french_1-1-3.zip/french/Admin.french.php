<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Sections';
$txt['admin_back_to'] = 'Retour au panneau d\'administration';
$txt['admin_users'] = 'Membres';
$txt['admin_newsletters'] = 'Infolettre';
$txt['include_these'] = 'Membre à ajouter';
$txt['exclude_these'] = 'Membres à exclure';
$txt['admin_newsletters_select_groups'] = 'Groupes à ajouter';
$txt['admin_newsletters_exclude_groups'] = 'Groupes à exclure';
$txt['admin_edit_news'] = 'Nouvelles';
$txt['admin_groups'] = 'Groupes';
$txt['admin_members'] = 'Gérer les membres';
$txt['admin_members_list'] = 'Ci-dessous une liste de tous les membres actuellement inscrits sur votre forum.';
$txt['admin_next'] = 'Suivant';
$txt['admin_censored_words'] = 'Mots censurés';
$txt['admin_censored_where'] = 'Entrer le mot à censurer dans la case de gauche et le mot de substitution dans la case de droite. Sélectionnez ensuite si vous voulez vérifier le mot entier et la casse. Quand chaque mot est terminé, cliquez sur Enregistrer. On peut entrer plusieurs mots avant d\'enregistrer en cliquant sur le bouton "Ajouter un autre mot".';
$txt['admin_censored_desc'] = 'Étant donné la nature publique des forums, vous souhaitez peut-être censurer certains mots que pourraient publier les utilisateurs de votre forum. Ci-dessous, vous pouvez entrer n\'importe quel mot que vous voudriez voir censuré chaque fois qu\'un membre l\'utilise. Videz un champ pour supprimer le mot de la censure. ';
$txt['admin_reserved_names'] = 'Noms réservés';
$txt['admin_template_edit'] = 'Modifier les modèles de votre forum';
$txt['admin_modifications'] = 'Paramètres des extensions';
$txt['admin_security_moderation'] = 'Sécurité et Modération';
$txt['admin_server_settings'] = 'Paramètres du Serveur';
$txt['admin_reserved_set'] = 'Déterminer les noms réservés';
$txt['admin_reserved_line'] = 'Un seul mot réservé par ligne.';
$txt['admin_basic_settings'] = 'Cette page vous permet de modifier les réglages de base de votre forum. Soyez très vigilant avec ces réglages, puisqu\'ils peuvent rendre votre forum inopérant.';
$txt['admin_maintain'] = 'Activer le Mode maintenance';
$txt['admin_title'] = 'Nom du forum';
$txt['admin_url'] = 'Adresse du forum';
$txt['cookie_name'] = 'Nom du témoin/cookie';
$txt['admin_webmaster_email'] = 'Courriel du webmestre';
$txt['boarddir'] = 'Répertoire de ElkArte';
$txt['sourcesdir'] = 'Répertoire des sources';
$txt['cachedir'] = 'Répertoire du cache';
$txt['admin_news'] = 'Afficher la barre des nouvelles';
$txt['admin_guest_post'] = 'Autoriser les invités à publier';
$txt['admin_manage_members'] = 'Membres';
$txt['admin_main'] = 'Général';
$txt['admin_config'] = 'Configuration';
$txt['admin_version_check'] = 'Vérification des détails de la version';
$txt['admin_elkfile'] = 'Fichier ElkArte';
$txt['admin_elkpackage'] = 'Paquet ElkArte';
$txt['admin_logoff'] = 'Fin de la session Admin';
$txt['admin_maintenance'] = 'Maintenance';
$txt['admin_image_text'] = 'Afficher les boutons en tant qu\'images plutôt qu\'en textes';
$txt['admin_credits'] = 'Crédits';
$txt['admin_agreement'] = 'Afficher et exiger l\'accord des conditions d\'inscription lors de l\'enregistrement';
$txt['admin_checkbox_agreement'] = 'Montrer une case à cocher au lieu de toute une page pour l\'accord sur le formulaire d\'inscription ';
$txt['admin_checkbox_accept_agreement'] = 'Oblige tous les membres à accepter cette nouvelle version de l\'accord d\'inscription lors de leur prochaine visite sur le forum';
$txt['admin_agreement_default'] = 'Par défaut';
$txt['admin_agreement_select_language'] = 'Langue à éditer';
$txt['admin_agreement_select_language_change'] = 'Modifier';

$txt['admin_privacypol'] = 'Afficher et exiger l\'accord sur la politique de protection de la vie privée lors de l\'enregistrement';
$txt['admin_checkbox_accept_privacypol'] = 'Oblige tous les membres à accepter cette nouvelle version de la politique de protection de la vie privée lors de leur prochaine visite sur le forum';

$txt['admin_delete_members'] = 'Supprimer les membres sélectionnés';
$txt['admin_change_primary_membergroup'] = 'Modifier le groupe principal des membres';
$txt['admin_change_secondary_membergroup'] = 'Modifier/ajouter un groupe additionnel pour les membres';
$txt['confirm_remove_membergroup'] = 'Si vous choisissez ceci, tous les groupes seront effacés ! Êtes-vous certain de vouloir procéder ?';
$txt['confirm_change_primary_membergroup'] = 'Êtes vous certain de vouloir modifier le groupe principal des membres sélectionnés ?';
$txt['confirm_change_secondary_membergroup'] = 'Êtes vous certain de vouloir modifier le groupe additionnel des membres sélectionnés ?';
$txt['admin_ban_usernames'] = 'Bannir par identifiants';
$txt['admin_ban_useremails'] = 'Bannir par adresses de courriel';
$txt['admin_ban_userips'] = 'Bannir par adresses IP';
$txt['admin_ban_usernames_and_emails'] = 'Bannir par identifiants et adresses de courriel';
$txt['admin_ban_name'] = 'Bannissement en masse d\'utilisateurs';
$txt['remove_groups'] = 'Supprimer tous les groupes';

$txt['admin_repair'] = 'Réparer toutes les sections et tous les sujets';
$txt['admin_main_welcome'] = 'Ceci est votre "%1$s". Ici vous pouvez modifier les paramètres, faire des opérations de maintenance sur votre forum, voir les journaux, installer des paquets, gérer les thèmes et bien plus encore.
<br /><br />Si vous avez un problème, veuillez consulter la page "Support et crédits". Si l\'information fournie ne vous aide pas, n\'hésitez pas à <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">nous contacter pour l\'aide </a> à propos de votre problème.
<br />Vous pouvez aussi trouver des réponses à vos questions en cliquant sur les symboles <i class="helpicon i-help"><s>Aide</s></i> pour voir comment fonctionnent certaines options.';
$txt['admin_news_desc'] = ' SVP ne placez qu\'une seule nouvelle par zone de texte. Quelques balises BBC, comme <span>[b]</span>, <span>[i]</span> et <span>[u]</span> sont autorisées dans vos nouvelles, ainsi que les émoticônes et du code HTML. Enlevez tout le texte d\'une zone de texte pour la supprimer. ';
$txt['administrators'] = 'Administrateurs du forum';
$txt['admin_reserved_desc'] = 'Les noms réservés empêchent les utilisateurs de s\'inscrire sous certains identifiants ou d\'utiliser ces mots dans leur pseudonyme.  Choisissez ci-dessous les options que vous souhaitez utiliser avant de soumettre la liste.';
$txt['admin_activation_email'] = 'Envoyer un courriel d\'activation aux nouveaux membres lors de l\'inscription';
$txt['admin_match_whole'] = 'Concordance avec le seul nom complet. Décoché, la recherche s\'effectuera à l\'intérieur des pseudos.';
$txt['admin_match_case'] = 'Concordance avec la casse. Si décoché, recherchera sans porter attention à la casse.';
$txt['admin_check_user'] = 'Vérifier les noms des utilisateurs';
$txt['admin_check_display'] = 'Vérifier les pseudonymes.';
$txt['admin_newsletter_send'] = 'Vous pouvez envoyer un courriel à quiconque sur cette page. Les adresses de courriel des membres du groupe sélectionnés devraient apparaître ci-dessous, mais vous pouvez enlever ou ajouter toute adresse de courriel à votre gré. Assurez-vous que chaque adresse est séparée de la manière suivante :  "addresse1; addresse2".';
$txt['admin_fader_delay'] = 'Durée du fondu entre les éléments, dans les nouvelles qui défilent';
$txt['zero_for_no_limit'] = '(0 pour pas de limite)';
$txt['zero_to_disable'] = '(0 pour désactiver)';

$txt['admin_backup_fail'] = 'Impossible de créer une sauvegarde de Settings.php.  Assurez-vous que Settings_bak.php existe et possède les bons droits d\'accès.';
$txt['modSettings_info'] = 'Réglages pour les caractéristiques générales, le rayonnement, les signatures, les "J\'aime" et beaucoup d\'autres paramètres de fonctionnement de ce forum.';
$txt['database_server'] = 'Serveur de base de données';
$txt['database_user'] = 'Utilisateur de la base de données';
$txt['database_password'] = 'Mot de passe de la base de données';
$txt['database_name'] = 'Nom de la base de données';
$txt['registration_agreement'] = 'Accord d\'inscription';
$txt['registration_agreement_desc'] = 'L\'accord d\'inscription est affiché lorsqu\'une personne crée un nouveau compte sur le forum et doit être accepté pour que l\'inscription se poursuive.';
$txt['privacy_policy'] = 'Protection de la vie privée';
$txt['privacy_policy_desc'] = 'La politique de protection de la vie privée est affichée lorsqu\'une personne enregistre un compte sur le forum et doit être acceptée avant que l\'utilisateur poursuive son inscription.';
$txt['database_prefix'] = 'Préfixe des tables';
$txt['errors_list'] = 'Liste des erreurs du forum';
$txt['errors_found'] = 'Les erreurs suivantes affectent votre forum ';
$txt['errors_fix'] = 'Voulez-vous essayer de corriger ces erreurs ?';
$txt['errors_do_recount'] = 'Toutes les erreurs ont été corrigées, et un espace de sauvegarde a été créé. Veuillez cliquer sur le bouton ci-dessous pour recalculer certaines statistiques importantes.';
$txt['errors_recount_now'] = 'Recalculer les Statistiques';
$txt['errors_fixing'] = 'Résoudre les erreurs du forum';
$txt['errors_fixed'] = 'Toutes les erreurs ont été corrigées. Veuillez examiner  toutes les catégories, sections et sujets existants afin de décider de ce que vous voulez en faire.';
$txt['attachments_avatars'] = 'Pièces jointes et avatars';
$txt['attachments_desc'] = 'Dans cette zone vous pouvez administrer les pièces jointes à votre forum par vos utilisateurs.  Vous pouvez supprimer de votre système les pièces jointes par taille et par date.  Les statistiques concernant les pièces jointes sont présentées ci-dessous.';
$txt['attachment_stats'] = 'Statistiques des pièces jointes';
$txt['attachment_integrity_check'] = 'Vérification de l\'intégrité des pièces jointes';
$txt['attachment_integrity_check_desc'] = 'Cette opération vérifiera l\'intégrité et la taille des pièces jointes et des noms de fichier listés dans la base de données, et si nécessaire corrigera les erreurs rencontrées.';
$txt['attachment_check_now'] = 'Vérifier maintenant';
$txt['attachment_pruning'] = 'Délestage des pièces jointes';
$txt['attachment_pruning_message'] = 'Messages à ajouter';
$txt['attachment_pruning_warning'] = 'Êtes-vous sûr de vouloir supprimer ces pièces jointes ?
L\'opération est irréversible !';

$txt['attachment_total'] = 'Total des pièces jointes';
$txt['attachmentdir_size'] = 'Taille totale de tous les répertoires de pièces jointes';
$txt['attachmentdir_size_current'] = 'Taille totale du répertoire actuel de pièces jointes';
$txt['attachmentdir_files_current'] = 'Nombre total de fichiers dans le répertoire actuel de pièces jointes';
$txt['attachment_space'] = 'Espace total disponible';
$txt['attachment_files'] = 'Total des fichiers restants';

$txt['attachment_options'] = 'Options des pièces jointes';
$txt['attachment_log'] = 'Journal des pièces jointes';
$txt['attachment_remove_old'] = 'Supprimer les pièces jointes de plus de %1$s jours';
$txt['attachment_remove_size'] = 'Supprimer les pièces jointes dont le poids est supérieur à %1$s KiB';
$txt['attachment_name'] = 'Nom de la pièce jointe';
$txt['attachment_file_size'] = 'Taille du fichier';
$txt['attachmentdir_size_not_set'] = 'Aucune taille maximale n\'est actuellement fixée';
$txt['attachmentdir_files_not_set'] = 'Aucune taille limite du dossier n\'est actuellement définie';
$txt['attachment_delete_admin'] = '[Pièce jointe supprimée par l\'administrateur]';
$txt['live'] = 'Dernières mise à jour du logiciel';
$txt['remove_all'] = 'Effacer les journaux';
$txt['agreement_not_writable'] = 'Attention - agreement.txt n\'est PAS accessible en écriture.  Les changements effectués ne seront PAS sauvegardés.';
$txt['agreement_backup_not_writable'] = 'Attention - le dossier de sauvegarde dans forum_root/packages/backup ne peut être créé.';
$txt['privacypol_not_writable'] = 'Attention - privacypolicy.txt n\'est PAS accessible en écriture.  Les changements effectués ne seront PAS sauvegardés.';
$txt['privacypol_backup_not_writable'] = 'Attention - le dossier de sauvegarde dans forum_root/packages/backup ne peut être créé.';

$txt['version_check_desc'] = 'Ceci vous montre la version de vos fichiers installés comparés à ceux de la dernière version. Si un de ces fichiers n\'est pas à jour, vous devriez télécharger et installer la dernière version sur <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">Le site d\'ElkArte</a>.';
$txt['version_check_more'] = '(plus de détails)';

$txt['lfyi'] = 'Vous n\'êtes pas autorisé à accéder aux dernier fichier des nouvelles d\'ElkArte.';

$txt['manage_calendar'] = 'Calendrier';
$txt['manage_search'] = 'Recherche';
$txt['viewmembers_online'] = 'Dernière connexion';

$txt['smileys_manage'] = 'Émoticônes et icônes';
$txt['smileys_manage_info'] = 'Installer de nouveaux jeux d\'émoticônes, ajouter de nouvelles émoticônes à des jeux existants ou gérez vos icônes de messages.';

$txt['bbc_manage'] = 'Table des balises BBC';
$txt['bbc_manage_info'] = 'Ajouter, effacer et modifier des codes BBC';

$txt['package_info'] = 'Installer, télécharger et téléverser des paquets d\'extensions ; vérifiez les permissions des fichiers et les réglages FTP. ';
$txt['theme_admin'] = 'Gestion des thèmes';
$txt['theme_admin_info'] = 'Installer de nouveaux thèmes, choisir ceux disponibles pour vos utilisateurs, et définir ou réinitialiser les options de thèmes. ';
$txt['registration_center'] = 'Inscriptions';
$txt['member_center_info'] = 'Afficher la liste des membres, cherchez des membres, ou gérer les approbations et activations de compte. ';
$txt['viewmembers_online'] = 'Dernière connexion';

$txt['display_name'] = 'Pseudonyme';
$txt['email_address'] = 'Adresse de courriel';
$txt['ip_address'] = 'Adresse IP';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'inconnu';
$txt['security_wrong'] = 'Tentative de connexion à l\'administration !
Référent : %1$s
Agent utilisateur : %2$s
Adresse IP : %3$s';

$txt['email_as_html'] = 'Envoyer au format HTML. (Vous pouvez utiliser du HTML normal dans ce courriel.)';
$txt['email_parsed_html'] = 'Ajouter les balises &lt;br /&gt; et &amp;nbsp; au message.';
$txt['email_variables'] = ' Vous pouvez utiliser quelques "variables" dans ce message. <a href="{help_emailmembers}" class="help">Cliquer ici pour de plus amples informations</a>. ';
$txt['email_force'] = 'Envoyer ce message aux membres même s\'ils ont choisi de ne pas recevoir d\'annonces.';
$txt['email_as_pms'] = 'Envoyer ceci à ces groupes par la messagerie personnelle.';
$txt['email_continue'] = 'Continuer';
$txt['email_done'] = 'terminé.';
$txt['email_members_succeeded'] = 'Votre bulletin de nouvelles a été expédié avec succès ! ';

$txt['ban_title'] = 'Liste des bannissements';
$txt['ban_ip'] = 'Bannissement d\'IP : (ex. 192.168.12.213 or 128.0.*.*) - une entrée par ligne';
$txt['ban_email'] = 'Bannissement de courriel : (ex. pasbeau@pasgentil.com) - une entrée par ligne';
$txt['ban_username'] = 'Bannissement de nom d\'utilisateur : (ex. pasbeau_du_75) - une entrée par ligne';

$txt['ban_errors_detected'] = 'La ou les erreurs suivante(s) s\'est (se sont) produite(s) à l\'enregistrement ou à l\'édition du bannissement ou du déclencheur. ';
$txt['ban_description'] = 'Ici, vous pouvez bannir les troubles-fête d\'après leur adresse IP, le nom de leur hôte, leur nom d\'utilisateur ou leur adresse de courriel. ';
$txt['ban_add_new'] = 'Ajouter un nouveau bannissement';
$txt['ban_banned_entity'] = 'Type de bannissement';
$txt['ban_on_ip'] = 'Bannissement par IP (ex. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Bannissement par nom d\'hôte (ex. *.mil)';
$txt['ban_on_email'] = 'Bannissement par courriel (ex. *@sitepasbien.com)';
$txt['ban_on_username'] = 'Bannir d\'après le nom d\'utilisateur';
$txt['ban_notes'] = 'Notes';
$txt['ban_restriction'] = 'Restriction';
$txt['ban_full_ban'] = 'Bannissement complet';
$txt['ban_partial_ban'] = 'Bannissement partiel';
$txt['ban_cannot_post'] = 'Ne peut pas publier';
$txt['ban_cannot_register'] = 'Ne peut pas s\'inscrire';
$txt['ban_cannot_login'] = 'Ne peut pas se connecter';
$txt['ban_add'] = 'Ajouter';
$txt['ban_edit_list'] = 'Liste des bannissements';
$txt['ban_type'] = 'Types de bannissement';
$txt['ban_days'] = 'jour(s)';
$txt['ban_will_expire_within'] = 'Le bannissement se terminera après';
$txt['ban_added'] = 'Ajouté';
$txt['ban_expires'] = 'Expiration';
$txt['ban_hits'] = 'Visites';
$txt['ban_actions'] = 'Actions';
$txt['ban_expiration'] = 'Expiration';
$txt['ban_reason_desc'] = 'Raison du bannissement, à afficher au membre banni.';
$txt['ban_notes_desc'] = 'Notes pouvant informer les autres membres de l\'équipe.';
$txt['ban_remove_selected'] = 'Supprimer la sélection';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Voulez-vous vraiment supprimer les bannissements sélectionnés ?';
$txt['ban_modify'] = 'Modifier';
$txt['ban_name'] = 'Nom du bannissement';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Modifier les bannissements';
$txt['ban_add_notes'] = '<strong>Note</strong> : après la création du bannissement ci-dessus, vous pourrez ajouter des entrées additionnelles qui déclenchent le bannissement, comme les adresses IP, les noms d\'hôtes et les adresses de courriel.';
$txt['ban_expired'] = 'Expiré / désactivé';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Aucune restriction sélectionnée.';

$txt['ban_triggers'] = 'Déclencheurs';
$txt['ban_add_trigger'] = 'Ajouter un déclencheur de bannissement';
$txt['ban_add_trigger_submit'] = 'Ajouter';
$txt['ban_edit_trigger'] = 'Modifier';
$txt['ban_edit_trigger_title'] = 'Modifier les déclencheurs de bannissement';
$txt['ban_edit_trigger_submit'] = 'Modifier';
$txt['ban_remove_selected_triggers'] = 'Supprimer les déclencheurs sélectionnés';
$txt['ban_no_entries'] = 'Aucun bannissement n\'est actuellement actif.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Êtes-vous sûr de vouloir supprimer les déclencheurs de bannissement sélectionnés ?';
$txt['ban_trigger_browse'] = 'Parcourir les déclencheurs de bannissement';
$txt['ban_trigger_browse_description'] = 'Cette interface affiche toutes les entités bannies, groupées par adresse IP, nom hôte, adresse de courriel et nom d\'utilisateur. ';

$txt['ban_log'] = 'Journal des bannissements';
$txt['ban_log_description'] = 'Le journal de bannissements montre toutes les tentatives d\'accès au forum par les utilisateurs bannis ("bannissement complet" et \'inscription interdite" uniquement).';
$txt['ban_log_no_entries'] = 'Aucune entrée pour le moment dans le journal de bannissements.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'Adresse de courriel';
$txt['ban_log_member'] = 'Membre';
$txt['ban_log_date'] = 'Date';
$txt['ban_log_remove_all'] = 'Vider les journaux';
$txt['ban_log_remove_all_confirm'] = 'Voulez-vous vraiment supprimer toutes les entrées ?';
$txt['ban_log_remove_selected'] = 'Supprimer la sélection';
$txt['ban_log_remove_selected_confirm'] = 'Voulez-vous vraiment supprimer les entrées sélectionnées ?';
$txt['ban_no_triggers'] = 'Aucun déclencheur de bannissement pour le moment.';

$txt['settings_not_writable'] = 'Ces réglages ne peuvent pas être changés car Settings.php est accessible en lecture seulement.';

$txt['maintain_title'] = 'Maintenance du forum';
$txt['maintain_info'] = 'Sauvegardes de base du forum, vérification des erreurs dans la base de données, nettoyage du cache, crochets d\'intégration et plus. ';
$txt['maintain_sub_database'] = 'Base de données';
$txt['maintain_sub_routine'] = 'Programmes réguliers';
$txt['maintain_sub_members'] = 'Membres';
$txt['maintain_sub_topics'] = 'Sujets';
$txt['maintain_sub_attachments'] = 'Pièces jointes';
$txt['maintain_done'] = 'La tâche de maintenance "%1$s" a été accomplie avec succès.';
$txt['maintain_fail'] = 'La tâche de maintenance "%1$s" a échoué.';
$txt['maintain_no_errors'] = 'Félicitations, aucune erreurs trouvées. Merci d\'avoir vérifié.';

$txt['maintain_tasks'] = 'Taches programmées';
$txt['maintain_tasks_desc'] = 'Gérer toutes les tâches programmées.';

$txt['scheduled_log'] = 'Journal des tâches';
$txt['scheduled_log_desc'] = 'Liste des journaux des tâches qui ont été exécutées.';
$txt['admin_log'] = 'Journal d\'administration';
$txt['admin_log_desc'] = 'Liste les tâches administration ayant été exécutées par les admins de votre forum.';
$txt['moderation_log'] = 'Journal de modération';
$txt['moderation_log_desc'] = 'Liste les activités de modération ayant été exécutées par les modérateurs de votre forum.';
$txt['badbehavior_log'] = 'Journal des mauvais comportements';
$txt['badbehavior_log_desc'] = 'Énumération des requêtes bloquées ou marquées comme suspectes pour cause de mauvais comportement. Si la verbosité du registre est activée, toutes les requêtes HTTP sont énumérées.';
$txt['spider_log_desc'] = 'Voir les entrées correspondant à l\'activité des moteurs de recherche sur votre forum.';
$txt['pruning_log_desc'] = 'Utiliser ces scripts pour supprimer les entrées les plus anciennes sur les divers journaux.';

$txt['mailqueue_title'] = 'Courriel';

$txt['db_error_send'] = 'Envoyer un courreil lors d\'une erreur de connexion à la base de données';
$txt['db_persist'] = 'Utiliser une connexion permanente';
$txt['ssi_db_user'] = 'Base de données des utilisateurs à utiliser en mode SSI';
$txt['ssi_db_passwd'] = 'Mot de passe de la base de données à utiliser en mode SSI';

$txt['default_language'] = 'Langue par défaut du forum';

$txt['maintenance_subject'] = 'Sujet à afficher';
$txt['maintenance_message'] = 'Message à afficher';

$txt['errlog_desc'] = 'Le Journal d\'erreurs suit toutes les erreurs rencontrées sur votre forum. Pour supprimer une erreur de la base de données, cochez le champ et cliquez sur le bouton %1$s au bas de la page.';
$txt['errlog_no_entries'] = 'Aucune erreur à signaler dans le journal.';

$txt['theme_settings'] = 'Réglages des thèmes';
$txt['theme_edit_settings'] = 'Modifier les paramètres de ce thèmes';
$txt['theme_current_settings'] = 'Thème actuel';

$txt['dvc_your'] = 'Votre version';
$txt['dvc_current'] = 'Dernière version';
$txt['dvc_sources'] = 'Sources';
$txt['dvc_admin'] = 'Admin';
$txt['dvc_controllers'] = 'Responsables';
$txt['dvc_database'] = 'Base de données';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Modèles par défaut';
$txt['dvc_templates'] = 'Modèles actuels';
$txt['dvc_languages'] = 'Fichiers de langue';

$txt['smileys_default_set_for_theme'] = 'Sélectionner le jeu d\'émoticônes pour ce thème : ';
$txt['smileys_no_default'] = 'Utiliser le jeu d\'émoticônes par défaut';

$txt['censor_test'] = 'Tester les mots censurés';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Ignorer la casse pour censurer.';
$txt['censor_whole_words'] = 'Vérifier uniquement les mots entiers.';
$txt['censor_allow'] = 'Permettre aux utilisateurs de désactiver la censure des mots.';

$txt['admin_confirm_password'] = '(confirmer le mot de passe)';
$txt['admin_incorrect_password'] = 'Mot de passe incorrect';

$txt['date_format'] = '(AAAA-MM-JJ)';
$txt['undefined_gender'] = 'Non défini';
$txt['age'] = 'Âge';
$txt['activation_status'] = 'Statut d\'activation';
$txt['activated'] = 'Activé';
$txt['not_activated'] = 'Non activé';
$txt['is_banned'] = 'Banni';
$txt['primary'] = 'Primaire';
$txt['additional'] = 'Additionnel';
$txt['wild_cards_allowed'] = 'les caractères joker * et ? sont permis';
$txt['member_part_of_these_membergroups'] = 'Le membre fait parti de ces groupes';
$txt['membergroups'] = 'Groupes';
$txt['confirm_delete_members'] = 'Êtes-vous sûr de vouloir supprimer les membres sélectionnés ?';

$txt['support_credits_title'] = 'Support et Crédits';
$txt['support_credits_info'] = 'Liens d\'aide vers les problèmes les plus courants, les informations sur la version du forum utilisée (à fournir lorsque vous demanderez de l\'aide) et la liste des collaborateurs au projet ElkArte.';
$txt['support_title'] = 'Informations de support';
$txt['support_versions_current'] = 'Dernière version';
$txt['support_versions_forum'] = 'Version installée ';
$txt['support_versions_db'] = 'Version %1$s';
$txt['support_versions_server'] = 'Version du serveur';
$txt['support_versions_gd'] = 'Version de GD';
$txt['support_versions_imagick'] = 'Version de Imagick';
$txt['support_versions'] = 'Infos sur la version';
$txt['support_resources'] = 'Ressources de support';
$txt['support_resources_p1'] = 'Le <a href="%1$s" target="_blank" class="new_win">wiki</a> d\'ElkArte constitue sa principale source de documentation. Le manuel en ligne d\'ElkArte comprend de nombreux documents permettant d\'aider à répondre à des demandes de soutien et fournissant de nombreuses explications à propos des <a href="%2$s" target="_blank" class="new_win">caractéristiques</a>, <a href="%3$s" target="_blank" class="new_win">paramètrages</a>, <a href="%4$s" target="_blank" class="new_win">thèmes</a>, <a href="%5$s" target="_blank" class="new_win">paquets</a>, etc. Le manuel en ligne documente chaque aspect d\'ElkArte de façon exhaustive et devrait répondre rapidement à la plupart des questions.';
$txt['support_resources_p2'] = 'Si vous ne trouvez pas réponse à vos questions dans le wiki de  documentation, vous pouvez lancer une recherche sur la <a href="%1$s" target="_blank" class="new_win">Communauté de soutien</a> ou demander de l\'aide dans une  de nos sections de soutien. La communauté de soutien d\'ElkArte propose de l\'aide pour le <a href="%2$s" target="_blank" class="new_win">soutien</a> ou la <a href="%3$s" target="_blank" class="new_win">personnalisation</a>, mais vous permet aussi de discuter d\'ElkArte , de trouver un hébergeur ou de parler de problèmes d\'administration avec d\'autres administrateurs de forums.';

$txt['latest_updates'] = 'Dernières mises à jour majeures';
$txt['new_in_1_0_2'] = 'Le changement le plus important dans ElkArte 1.0.2 est la gestion des permissions des avatars. Dans les versions antérieures chaque méthode utilisée pour définir un avatar est basé sur des permissions, ce qui requiert l\'activation ou la désactivation de chaque méthode pour chaque groupe. À compter de la version 1.0.2, les avatars sont simplement activés ou désactivés en considérant le groupe d\'utilisateurs, ce qui permet à tous les groupes habilités d\'ajouter un avatar (par toutes les méthodes disponibles).

La seule permission disponible est une permission générale, qui permet aux membres de changer ou pas leurs avatars. De plus, il n\'y a qu\'un seul réglage pour la largeur et la hauteur maximales des avatars. Ces valeurs s\'appliquent à toutes les méthodes relatives aux avatars.

Étant donné la nature des changements, il n\'est pas possible de migrer les réglages existants vers le nouveau format. C\'est pourquoi nous vous encourageons à visiter la page <a href="{admin_url};area=manageattachments;sa=avatars">Paramétrages des avatars</a> et à définir vos options préférées.';

$txt['edit_permissions_info'] = 'Utilisez les paramétrages des permissions pour gérer les caractéristiques globales et spécifiques des sections et quelles actions sont permises aux  invités, membres et modérateurs.';
$txt['membergroups_members'] = 'Membres inscrits';
$txt['membergroups_guests'] = 'Invités';
$txt['membergroups_add_group'] = 'Ajouter un groupe';
$txt['membergroups_permissions'] = 'Permissions';

$txt['permitgroups_restrict'] = 'Restreint';
$txt['permitgroups_standard'] = 'Standard';
$txt['permitgroups_moderator'] = 'Modérateur';
$txt['permitgroups_maintenance'] = 'Maintenance';

$txt['confirm_delete_attachments'] = 'Êtes-vous sûr de vouloir supprimer les pièces jointes sélectionnées ?';
$txt['attachment_manager_browse_files'] = 'Parcourir les fichiers';
$txt['attachment_manager_repair'] = 'Maintenance';
$txt['attachment_manager_avatars'] = 'Avatars';
$txt['attachment_manager_attachments'] = 'Pièces jointes';
$txt['attachment_manager_thumbs'] = 'Vignettes';
$txt['attachment_manager_last_active'] = 'Dernière connexion';
$txt['attachment_manager_member'] = 'Membre';
$txt['attachment_manager_avatars_older'] = 'Retirer les avatars des membres inactifs depuis plus de %1$s jours.';
$txt['attachment_manager_total_avatars'] = 'Total avatars';

$txt['attachment_manager_avatars_no_entries'] = 'Aucun avatar pour le moment.';
$txt['attachment_manager_attachments_no_entries'] = 'Aucune pièce jointe pour le moment.';
$txt['attachment_manager_thumbs_no_entries'] = 'Aucune vignette pour le moment.';

$txt['attachment_manager_settings'] = 'Paramètres des pièces jointes';
$txt['attachment_manager_avatar_settings'] = 'Paramètres des Avatars';
$txt['attachment_manager_browse'] = 'Parcourir les fichiers';
$txt['attachment_manager_maintenance'] = 'Maintenance des Fichiers';
$txt['attachmentEnable'] = 'Module des pièces jointes';
$txt['attachmentEnable_deactivate'] = 'Désactiver les piècess jointes';
$txt['attachmentEnable_enable_all'] = 'Activer toutes les pièces jointes';
$txt['attachmentEnable_disable_new'] = 'Désactiver les nouvelles pièces jointes';
$txt['attachmentCheckExtensions'] = 'Vérifier l\'extension des pièces jointes';
$txt['attachmentExtensions'] = 'Extensions autorisées';
$txt['attachmentRecodeLineEndings'] = 'Recoder les fins de ligne dans les fichiers joints au format texte';
$txt['attachmentShowImages'] = 'Afficher les images jointes sous les messages';
$txt['attachmentUploadDir'] = 'Répertoire des pièces jointes';
$txt['attachmentUploadDir_multiple_configure'] = 'Gérer les répertoires de pièces jointes';
$txt['attachmentDirSizeLimit'] = 'Espace maximal du répertoire des pièces jointes ';
$txt['attachmentPostLimit'] = 'Taille maximale de toutes les pièces jointes par message ';
$txt['attachmentSizeLimit'] = 'Taille maximale de chaque pièce jointe';
$txt['attachmentNumPerPostLimit'] = 'Nombre maximal de pièces jointes par message';
$txt['attachment_img_enc_warning'] = 'Aucun des modules, GD ou ImageMagick, n\'est installé. Réencoder des images n\'est pas possible.';
$txt['attachment_postsize_warning'] = 'Le paramètre  "post_max_size" actuel dans le fichier de configuration php.ini peut ne pas le permettre.';
$txt['attachment_filesize_warning'] = 'Le paramètre  "upload_max_filesize" actuel dans le fichier de configuration php.ini peut ne pas le permettre.';
$txt['attachment_image_reencode'] = 'Réencode les images potentiellement dangereuses envoyées en pièces jointes';
$txt['attachment_image_reencode_note'] = '(nécessite l\'extension GD ou ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Cette fonctionnalité peut donner lieu à des faux positifs (fichiers sains rejetés).';
$txt['attachment_image_paranoid'] = 'Effectuer un maximum de tests de sécurité sur les images envoyées en pièces jointes';
$txt['attachment_autorotate'] = 'Détecte et corrige les images mal tournées.';
$txt['attachment_autorotate_na'] = '(Non disponible sur ce système)';
$txt['attachmentThumbnails'] = 'Montrer les images jointes sous forme de vignettes sous les messages';
$txt['attachment_thumb_png'] = 'Sauvegarder les vignettes au format PNG';
$txt['attachment_thumb_memory'] = 'Mémoire adaptative des vignettes.';
$txt['attachment_thumb_memory_note2'] = 'Si le système ne peut pas obtenir de mémoire, aucune vignette ne sera créée.';
$txt['attachment_thumb_memory_note1'] = 'Laisser ceci décoché afin de toujours tenter de créer une vignette';
$txt['attachmentThumbWidth'] = 'Largeur maximale des vignettes';
$txt['attachmentThumbHeight'] = 'Hauteur maximale des vignettes';
$txt['attachment_thumbnail_settings'] = 'Paramètres des vignettes';
$txt['attachment_security_settings'] = 'Paramètres de sécurité des pièces jointes';

$txt['attachment_inline_title'] = 'Réglages pour les pièces jointes incorporées';
$txt['attachment_inline_enabled'] = 'Permettre l\'affichage de pièces jointes incorporées';
$txt['attachment_inline_basicmenu'] = 'Montrer seulement le menu de base';
$txt['attachment_inline_quotes'] = 'Cochez pour activer l\'affichage des pièces jointes en ligne entre guillemets';

$txt['attach_dir_does_not_exist'] = 'N\'existe pas';
$txt['attach_dir_not_writable'] = 'Non Inscriptible';
$txt['attach_dir_files_missing'] = 'Fichiers manquants (<a href="{repair_url}">Réparer</a>)';
$txt['attach_dir_unused'] = 'Inutilisé';
$txt['attach_dir_empty'] = 'Vide';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Répertoire de base';

$txt['attach_dir_desc'] = 'Créer de nouveaux répertoires ou modifier le dossier ci-dessous. Les dossiers peuvent être renommés tant qu\'ils ne contiennent pas un sous-dossier. Si le nouveau répertoire doit être créé dans l\'arborescence des dossiers du forum, vous avez juste à saisir le nom du répertoire. Pour supprimer un dossier, effacer le chemin dans le champ. Les dossiers ne peuvent être supprimés s\'ils contiennent des fichiers ou des sous-dossiers (affichés entre parenthèses à côté du nombre de fichiers).';
$txt['attach_dir_base_desc'] = 'Vous pouvez utiliser l\'espace ci-dessous pour modifier l\'actuel dossier de base ou en créer un nouveau. Les nouveaux dossiers de base sont également ajoutés à la liste des dossiers de pièces jointes. Vous pouvez également désigner un dossier existant pour être un répertoire de base.';
$txt['attach_dir_save_problem'] = 'Oh, on dirait qu\'il y a un problème.';
$txt['attachments_no_create'] = 'Ne peut créer un nouveau dossier de pièces jointes. Veuillez utiliser un client FTP ou le gestionnaire de fichiers de votre site.';
$txt['attachments_no_write'] = 'Le répertoire a été créé sans droit d\'écriture. Veuillez tenter à nouveau en utilisant un client FTP ou le gestionnaire de fichiers de votre site.';
$txt['attach_dir_reserved'] = 'Ne peut être ajouté. Ce dossier est un dossier système et il ne peut être utilisé pour les pièces jointes.';
$txt['attach_dir_duplicate_msg'] = 'Ajout impossible. Ce répertoire existe déjà.';
$txt['attach_dir_exists_msg'] = 'Déplacement impossible. Un répertoire existe déjà dans ce chemin.';
$txt['attach_dir_base_dupe_msg'] = 'Ajout impossible. Le répertoire de base a déjà été créé.';
$txt['attach_dir_base_no_create'] = 'Création impossible. Veuillez vérifier l\'entrée pour le chemin, ou créer ce répertoire au moyen d\'un client FTP ou du gestionnaire de fichiers du site, et réessayer.';
$txt['attach_dir_no_rename'] = 'Impossible de déplacer ou renommer. Veuillez vérifier que le chemin est exact ou que ce répertoire ne contient pas de sous-répertoires.';
$txt['attach_dir_no_delete'] = 'N\'est pas vide et ne peut être effacé. Pour ce faire, veuillez utiliser un client FTP ou le gestionnaire de fichiers du site.';
$txt['attach_dir_no_remove'] = 'Contient encore des fichiers, ou bien il s\'agit d\'un répertoire de base qui ne peut être effacé.';
$txt['attach_dir_is_current'] = 'On ne peut effacer le répertoire sélectionné tant qu\'il est le répertoire courant.';
$txt['attach_dir_is_current_bd'] = 'On ne peut effacer le répertoire sélectionné tant qu\'il est le répertoire de base actuel.';
$txt['attach_last_dir'] = 'Dernier répertoire de pièces jointes actif ';
$txt['attach_current_dir'] = 'Répertoire de pièces jointes actuel ';
$txt['attach_current'] = 'Actuel';
$txt['attach_path_manage'] = 'Gérer les Chemins des pièces jointes';
$txt['attach_directories'] = 'Répertoires des pièces jointes';
$txt['attach_paths'] = 'Chemins des dossiers des pièces jointes';
$txt['attach_path'] = 'Chemin';
$txt['attach_current_size'] = 'Taille (Ko)';
$txt['attach_num_files'] = 'Fichiers';
$txt['attach_dir_status'] = 'Statut';
$txt['attach_add_path'] = 'Ajouter un chemin';
$txt['attach_path_current_bad'] = 'Chemin actuel des pièces jointes invalides.';
$txt['attachmentDirFileLimit'] = 'Nombre maximum de fichiers par dossier';

$txt['attach_base_paths'] = 'Chemins des répertoires de base';
$txt['attach_num_dirs'] = 'Dossiers';
$txt['max_image_width'] = 'Largeur maximale pour l\'affichage des images incorporées ou jointes à un message.';
$txt['max_image_height'] = 'Hauteur maximale pour l\'affichage des images incorporées ou jointes à un message.';

$txt['automanage_attachments'] = 'Choisissez la façon de gérer les répertoires de pièces jointes.';
$txt['attachments_normal'] = '(Manuel) Comportement par défaut d\'ElkArte';
$txt['attachments_auto_years'] = '(Automatique) Subdiviser par années';
$txt['attachments_auto_months'] = '(Automatique) Subdiviser par années et par mois';
$txt['attachments_auto_days'] = '(Automatique) Subdiviser par années, mois et jours';
$txt['attachments_auto_16'] = '(Automatique) 16 répertoires au hasard.';
$txt['attachments_auto_16x16'] = '(Automatique) 16 répertoires et 16 sous-répertoires au hasard.';
$txt['attachments_auto_space'] = '(Automatique) Quand une des deux limites du répertoire est atteinte';

$txt['use_subdirectories_for_attachments'] = 'Créer de nouveaux répertoires dans un répertoire de base';
$txt['use_subdirectories_for_attachments_note'] = 'Sinon, tout nouveau répertoire sera créé dans le répertoire principal du forum.';
$txt['basedirectory_for_attachments'] = 'Définissez un répertoire de base pour les pièces jointes';
$txt['basedirectory_for_attachments_current'] = 'Répertoire de base actuel';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Veuillez noter que le répertoire est erroné. <br />(<a href="{attach_repair_url}">Tenter de le corriger</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">Ce répertoire semble présenter un problème. <br />(<a href="{attach_repair_url}">Tenter de le corriger</a>)</div>';

$txt['attachment_transfer'] = 'Transférer les pièces jointes.';
$txt['attachment_transfer_desc'] = 'Transférer les fichiers d\'un répertoire à l\'autre.';
$txt['attachment_transfer_select'] = 'Choisir un répertoire';
$txt['attachment_transfer_now'] = 'Transférer';
$txt['attachment_transfer_from'] = 'Transférer des fichiers de';
$txt['attachment_transfer_auto'] = 'Déplacer les automatiquement en fonction du nombre de fichiers ou de l\'espace libre.';
$txt['attachment_transfer_auto_select'] = 'Choisissez le répertoire de base';
$txt['attachment_transfer_to'] = 'Ou déplacez-les dans un répertoire précis.';
$txt['attachment_transfer_empty'] = 'Déplacer tous les fichiers du répertoire source.';
$txt['attachment_transfer_no_base'] = 'Aucun répertoires de base n\'est disponible.';
$txt['attachment_transfer_forum_root'] = 'Répertoire racine du forum.';
$txt['attachment_transfer_no_room'] = 'La taille maximale ou le nombre maximal de fichiers ont atteint leur limite.';
$txt['attachment_transfer_no_find'] = 'Le système n\'a trouvé aucun fichier à transférer.';
$txt['attachments_transfered'] = '%1$d fichiers ont été transférés vers %2$s';
$txt['attachments_not_transfered'] = '%1$d fichiers n\'ont pas été transférés.';
$txt['attachment_transfer_no_dir'] = 'Le répertoire cible ou l\'une des options cible n\'ont pas été sélectionnés.';
$txt['attachment_transfer_same_dir'] = 'Vous ne pouvez choisir le même répertoire comme source et comme cible.';
$txt['attachment_transfer_progress'] = 'Veuillez patienter. Le transfert est en cours.';

$txt['avatar_settings'] = 'Paramètres généraux pour les avatars';
$txt['avatar_default'] = 'Choisissez un avatar par défaut pour tous les utilisateurs sans avatar';
$txt['avatar_directory'] = 'Répertoire des avatars';
$txt['avatar_url'] = 'Adresse des avatars';
$txt['avatar_max_width'] = 'Largeur maximale des avatars en pixels (px)';
$txt['avatar_max_height'] = 'Hauteur maximale des avatars en pixels (px)';
$txt['avatar_action_too_large'] = 'Si un avatar est trop grand... ';
$txt['option_refuse'] = 'Refuser';
$txt['option_resize'] = 'Laisser le CSS le redimensionner';
$txt['option_download_and_resize'] = 'Le télécharger et le redimensionner (requiert le module GD ou ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Permettre l\'utilisation de gravatars';
$txt['gravatar_rating'] = 'Evaluation Gravatar';
$txt['avatar_download_png'] = 'Utiliser le format PNG pour les avatars redimensionnés';
$txt['avatar_img_enc_warning'] = 'Aucun des modules, GD ou ImageMagick, n\'est installé. Certaines options des avatars sont désactivées. ';
$txt['avatar_external'] = 'Avatars externes';
$txt['avatar_external_enabled'] = 'Permettre l\'utilisation d\'avatars externes (distants ou par adresse)';
$txt['avatar_upload'] = 'Avatars transférables';
$txt['avatar_resize_options'] = 'Options de stockage sur le serveur';
$txt['avatar_upload_enabled'] = 'Permettre le téléversement d\'avatars';
$txt['avatar_server_stored'] = 'Avatars stockés sur le serveur';
$txt['avatar_stored_enabled'] = 'Activer le choix du serveur d\'hébergement des avatars';
$txt['profile_set_avatar'] = 'Groupes autorisés à choisir un avatar';
$txt['avatar_select_permission'] = 'Sélectionner les permissions pour chaque groupe';
$txt['avatar_download_external'] = 'Télécharger l\'avatar à l\'adresse donnée';
$txt['custom_avatar_enabled'] = 'Transférer les avatars vers... ';
$txt['option_attachment_dir'] = 'Répertoire des pièces jointes';
$txt['option_specified_dir'] = 'Un répertoire spécifique... ';
$txt['custom_avatar_dir'] = 'Répertoire de téléversement';
$txt['custom_avatar_dir_desc'] = 'Cela devrait être un dossier existant et inscriptible, différent du dossier d\'hébergement sur le serveur';
$txt['custom_avatar_url'] = 'Adresse de téléversement';
$txt['custom_avatar_check_empty'] = 'Le répertoire de stockage des avatars transférés que vous avez spécifié semble être vide ou invalide. Merci de vérifier vos paramètres.';
$txt['avatar_reencode'] = 'Réencoder les avatars potentiellement dangereux';
$txt['avatar_reencode_note'] = '(Le module GD est requis)';
$txt['avatar_paranoid_warning'] = 'La vérification par la sécurité étendue peut générer un grand nombre d\'avatars rejetés.';
$txt['avatar_paranoid'] = 'Exécutez la sécurité étendue pour vérifier les avatars envoyés';

$txt['repair_attachments'] = 'Maintenance des pièces jointes';
$txt['repair_attachments_complete'] = 'Maintenance terminée';
$txt['repair_attachments_complete_desc'] = 'Toutes les erreurs sélectionnées ont maintenant été corrigées';
$txt['repair_attachments_no_errors'] = 'Aucune erreur n\'a été trouvée. ';
$txt['repair_attachments_error_desc'] = 'Les erreurs suivantes ont été rencontrées durant la maintenance. Cochez la boîte accompagnant les erreurs que vous souhaitez corriger et cliquez sur Continuer.';
$txt['repair_attachments_continue'] = 'Continuer';
$txt['repair_attachments_cancel'] = 'Annuler';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d vignettes n\'ont pas de fichier parent';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d fichiers parents sont notés comme ayant une vignette mais n\'en ont pas';
$txt['attach_repair_file_missing_on_disk'] = '%1$d fichiers/avatars ont une entrée mais n\'existent plus sur le disque';
$txt['attach_repair_file_wrong_size'] = '%1$d fichiers/avatars sont rapportés comme possédant une mauvaise taille de fichier';
$txt['attach_repair_file_size_of_zero'] = '%1$d fichiers/avatars ont une taille de zéro octet sur le disque. (Ils seront supprimés.)';
$txt['attach_repair_attachment_no_msg'] = '%1$d fichiers n\'ont plus de message auquel ils sont associés';
$txt['attach_repair_avatar_no_member'] = '%1$d avatars n\'ont plus de membre auquel ils sont associés';
$txt['attach_repair_wrong_folder'] = '%1$d pièces jointes sont dans le mauvais dossier ';
$txt['attach_repair_missing_extension'] = '%1$d pieces jointes n\'ayant pas l\'extension correcte et qui pourraient être dans le mauvais répertoire.';
$txt['attach_repair_files_without_attachment'] = '%1$d fichiers n\'ont pas d\'entrée correspondante dans la base de données. (Ces fichiers seront supprimés.)';

$txt['news_title'] = 'Nouvelles et infolettres';
$txt['news_settings_desc'] = 'Ici vous pouvez changer les réglages et permissions relatifs aux nouvelles et aux infolettres.';
$txt['news_mailing_desc'] = 'Depuis ce menu vous pouvez envoyer des messages à tous les utilisateurs inscrits qui ont spécifié leur adresse de courriel. Vous pouvez modifier la liste de diffusion, ou envoyer un message à tous. Utile pour informer des mises à jour et communiquer des nouvelles importantes.';
$txt['news_error_no_news'] = 'Il n\'y a rien à prévisualiser';
$txt['groups_edit_news'] = 'Groupes autorisés à modifier les nouvelles';
$txt['groups_send_mail'] = 'Groupes autorisés à envoyer les infolettres du forum';
$txt['xmlnews_enable'] = 'Activer les flux XML/RSS';
$txt['xmlnews_maxlen'] = 'Longueur maximale d\'un message';
$txt['xmlnews_limit'] = 'Limite XML/RSS';
$txt['xmlnews_limit_note'] = 'Nombre d\'éléments dans un flux de nouvelles';
$txt['xmlnews_maxlen_note'] = '(0 pour désactiver, mauvaise idée ! )';
$txt['editnews_clickadd'] = 'Ajouter un autre élément';
$txt['editnews_remove_selected'] = 'Supprimer la sélection';
$txt['editnews_remove_confirm'] = 'Voulez-vous vraiment supprimer les nouvelles sélectionnées ?';
$txt['censor_clickadd'] = 'Ajouter un autre mot';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Journaux';
$txt['generate_reports'] = 'Générer des rapports';

$txt['update_available'] = 'Une mise à jour est disponible ';
$txt['update_message'] = 'Vous utilisez une version ancienne d\'ElkArte qui contient quelques bogues qui ont été corrigés. 
Il est recommandé de <a href="#" id="update-link">mettre à jour votre forum</a> vers la dernière version le plus rapidement possible. Cela ne prend qu\'une minute !';

$txt['manageposts'] = 'Messages et sujets';
$txt['manageposts_title'] = 'Gérer les messages et les sujets';
$txt['manageposts_description'] = 'Ici vous pouvez gérer tous les réglages relatifs aux sujets et aux messages.';

$txt['manageposts_seconds'] = 'secondes';
$txt['manageposts_minutes'] = 'minutes';
$txt['manageposts_characters'] = 'caractères';
$txt['manageposts_days'] = 'jours';
$txt['manageposts_posts'] = 'messages';
$txt['manageposts_topics'] = 'sujets';

$txt['pollMode'] = 'Activer les sondages';

$txt['manageposts_settings'] = 'Paramètres des Messages';
$txt['manageposts_settings_description'] = 'Ici vous pouvez paramétrer tout ce qui est relatif aux messages et à leur envoi.';

$txt['manageposts_bbc_settings'] = 'Table des balises BBC';
$txt['manageposts_bbc_settings_description'] = 'Les <acronym title="Bulletin Board Code">BBCodes</acronym> peuvent être utilisés pour ajouter des mises en forme à vos messages. Par exemple, pour mettre de la force sur le mot \'maison\', vous pouvez taper [b]maison[/b]. Toutes les balises BBCodes sont entourées par des crochets (\'[\' et \']\').';
$txt['manageposts_bbc_settings_title'] = 'Paramètres des codes BBC ';

$txt['manageposts_topic_settings'] = 'Paramètres des sujets';
$txt['manageposts_topic_settings_description'] = 'Ici vous pouvez paramétrer toutes les options en rapport avec les sujets.';

$txt['managedrafts_settings'] = 'Paramètres des brouillons';
$txt['managedrafts_settings_description'] = 'Vous pouvez régler ici tous les paramètres relatifs aux brouillons ';
$txt['manage_drafts'] = 'Brouillons';

$txt['mail_center'] = 'Panneau des courriels';
$txt['mm_emailerror'] = 'Courriels échoués';
$txt['mm_emailfilters'] = 'Filtres';
$txt['mm_emailparsers'] = 'Analyseurs';
$txt['mm_emailtemplates'] = 'Modèles';
$txt['mm_emailsettings'] = 'Paramètres';

$txt['removeNestedQuotes'] = 'Supprimer les citations imbriquées en citant un message';
$txt['enableSpellChecking'] = 'Activer le correcteur orthographique';
$txt['enableSpellChecking_warning'] = 'ceci ne fonctionne pas sur tous les serveurs';
$txt['enableSpellChecking_error'] = 'ceci ne fonctionne pas sur votre serveur';
$txt['enableVideoEmbeding'] = 'Activer l\'incorporation de liens vidéo';
$txt['enableCodePrettify'] = 'Activer l\'embellissement des balises de code';
$txt['max_messageLength'] = 'Longueur maximale des messages';
$txt['max_messageLength_zero'] = '0 pour illimité';
$txt['convert_to_mediumtext'] = 'Votre base de données n\'est pas paramétrée pour accepter des messages de plus de 65535 caractères. Utiliser la page de <a href="%1$s">maintenance de la base de données</a> pour convertir la base de données puis revenir ici pour augmenter le nombre de caractères autorisé dans un message.';
$txt['topicSummaryPosts'] = 'Nombre de messages à afficher dans le résumé de la discussion';
$txt['spamWaitTime'] = 'Temps d\'attente requis entre deux envois en provenance d\'une même adresse IP';
$txt['edit_wait_time'] = 'Période de révision';
$txt['edit_disable_time'] = 'Temps maximum après l\'envoi pour modifier un message';
$txt['edit_disable_time_zero'] = '0 pour désactiver';
$txt['preview_characters'] = 'Longueur maximale du prévisionnement du premier ou du dernier courriel';
$txt['preview_characters_units'] = 'caractères';
$txt['preview_characters_zero'] = '0 pour montrer tout le message';
$txt['message_index_preview'] = 'Afficher la prévisualisation dans l\'accueil des messages';
$txt['message_index_preview_off'] = 'Ne pas montrer la prévisualisation';
$txt['message_index_preview_first'] = 'Montrer le texte du premier message';
$txt['message_index_preview_last'] = 'Montrer le texte du dernier message';

$txt['enableBBC'] = 'Activer les BBCodes';
$txt['enablePostHTML'] = 'Permettre l\'utilisation de balises HTML <em>basiques</em> dans les messages';
$txt['autoLinkUrls'] = 'Reconnaissance automatique des adresses';
$txt['disabledBBC'] = 'Balises BBCodes activées';
$txt['bbcTagsToUse'] = 'Balises BBCodes activées';
$txt['bbcTagsToUse_select'] = 'Sélectionnez toutes les balises pouvant être utilisées';
$txt['bbcTagsToUse_select_all'] = 'Sélectionner toutes les balises';

$txt['enableParticipation'] = 'Activer l\'icône de participation';
$txt['enableFollowup'] = 'Activer le suivi';
$txt['enable_unwatch'] = 'Activer la non-surveillance de sujets';
$txt['oldTopicDays'] = 'Temps avant qu\'un sujet ne soit mentionné comme ancien lors de l\'écriture d\'une réponse';
$txt['oldTopicDays_zero'] = '0 pour désactiver';
$txt['defaultMaxTopics'] = 'Nombre de sujets par page sur la page d\'accueil';
$txt['defaultMaxMessages'] = 'Nombre de messages à afficher sur la page d\'un sujet';
$txt['disable_print_topic'] = 'Désactiver la possibilité d\'imprimer une discussion';
$txt['hotTopicPosts'] = 'Nombre de messages pour considérer un sujet comme populaire';
$txt['hotTopicVeryPosts'] = 'Nombre de messages pour considérer un sujet comme très populaire';
$txt['useLikesNotViews'] = 'Utiliser le nombre de "J\'aime" à la place du nombre de messages pour considérer un sujet comme populaire';
$txt['enableAllMessages'] = 'Taille maximale d\'un sujet pour afficher TOUS les messages';
$txt['enableAllMessages_zero'] = '0 pour ne jamais afficher "Tous"';
$txt['disableCustomPerPage'] = 'Désactiver la personnalisation du nombre de sujets/messages par page';
$txt['enablePreviousNext'] = 'Activer les liens sujet précédent/suivant';

$txt['not_done_title'] = 'Une seconde, ce n\'est pas fini !';
$txt['not_done_reason'] = 'Afin d\'éviter la surcharge de votre serveur, le processus a été interrompu temporairement. Il devrait reprendre automatiquement dans quelques secondes. S\'il ne reprend pas, veuillez cliquer sur le lien "Continuer" ci-dessous.';
$txt['not_done_continue'] = 'Continuer';

$txt['general_settings'] = 'Général';
$txt['database_paths_settings'] = 'Base de données et chemins';
$txt['cookies_sessions_settings'] = 'Témoins/cookies et Sessions';
$txt['caching_settings'] = 'Configuration du Cache';
$txt['loadavg'] = 'Charge du serveur';
$txt['loadavg_settings'] = 'Gérer la charge';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Paramètres locaux';
$txt['phpinfo_defaultsettings'] = 'Mauvais comportement';
$txt['phpinfo_itemsettings'] = 'Paramètres';

$txt['language_configuration'] = 'Langues';
$txt['language_description'] = 'Cette section vous permet de modifier les langues installés sur votre forum ou d\'en télécharger de nouvelles à partir du site ElkArte. Vous pouvez aussi modifier ici les réglages relatifs à la langue.';
$txt['language_edit'] = 'Éditer les langues';
$txt['language_add'] = 'Ajouter une langue';
$txt['language_settings'] = 'Paramètres';

$txt['advanced'] = 'Avancé';
$txt['simple'] = 'Simple';

$txt['admin_news_select_recipients'] = 'Veuillez sélectionner qui doit recevoir une copie de l\'infolettre';
$txt['admin_news_select_group'] = 'Groupes';
$txt['admin_news_select_group_desc'] = 'Sélectionnez les groupes qui doivent recevoir cette infolettre.';
$txt['admin_news_select_members'] = 'Membres';
$txt['admin_news_select_members_desc'] = 'Membres supplémentaires qui doivent recevoir l\'infolettre.';
$txt['admin_news_select_excluded_members'] = 'Membres exclus';
$txt['admin_news_select_excluded_members_desc'] = 'Membres ne devant pas recevoir d\'infolettre.';
$txt['admin_news_select_excluded_groups'] = 'Groupes exclus';
$txt['admin_news_select_excluded_groups_desc'] = 'Sélectionnez les groupes ne devant absolument pas recevoir l\'infolettre.';
$txt['admin_news_select_email'] = 'Adresses de courriel';
$txt['admin_news_select_email_desc'] = 'Liste d\'adresses de courriel séparées par des points-virgules à laquelle sera envoyée l\'infolettre. (Par ex: adresse1; adresse2)';
$txt['admin_news_select_override_notify'] = 'Outrepasser les paramètres de notification existants';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Vous ne pouvez pas envoyer de message personnel à une adresse de courriel. Si vous continuez, toutes les adresses de courriel seront ignorées. Êtes-vous sûr de vouloir faire cela ?';

$txt['mailqueue_browse'] = 'Parcourir la file d\'attente';
$txt['mailqueue_settings'] = 'Paramètres';

$txt['admin_search'] = 'Recherche Rapide';
$txt['admin_search_type_internal'] = 'Tâche/Paramètres';
$txt['admin_search_type_member'] = 'Membre';
$txt['admin_search_type_online'] = 'Manuel en ligne';
$txt['admin_search_go'] = 'Aller';
$txt['admin_search_results'] = 'Résultats de la recherche';
$txt['admin_search_results_desc'] = 'Résultats de la recherche : %1$s';
$txt['admin_search_results_again'] = 'Rechercher à nouveau';
$txt['admin_search_results_none'] = 'Aucun résultat n\'a été trouvé ';

$txt['admin_search_section_sections'] = 'Section';
$txt['admin_search_section_settings'] = 'Paramètres';

$txt['core_settings_title'] = 'Options principales';
$txt['core_settings_desc'] = 'La présente page vous permet d\'activer ou de désactiver des caractéristiques optionnelles de votre forum.';
$txt['mods_cat_features'] = 'Général';
$txt['mods_cat_security_general'] = 'Réglages';
$txt['antispam_title'] = 'Anti-pourriel';
$txt['badbehavior_title'] = 'Mauvais comportements';
$txt['mods_cat_modifications_misc'] = 'Diverses';
$txt['mods_cat_layout'] = 'Apparence';
$txt['karma'] = 'Rayonnement';
$txt['moderation_settings_short'] = 'Modération';
$txt['signature_settings_short'] = 'Signatures';
$txt['custom_profile_shorttitle'] = 'Champs du profile';
$txt['pruning_title'] = 'Délestage de journal';

$txt['core_settings_activation_message'] = 'La caractéristique {core_feature} a été activée. Cliquer sur le titre pour la configurer.';
$txt['core_settings_deactivation_message'] = 'La caractéristique {core_feature} a été désactivée. ';
$txt['core_settings_generic_error'] = 'Une erreur s\'est produite. Veuillez recharger la page et réessayer.';

$txt['boardsEdit'] = 'Modifier les sections';
$txt['mboards_new_cat'] = 'Créer une nouvelle catégorie';
$txt['manage_holidays'] = 'Gérer les jours fériés';
$txt['calendar_settings'] = 'Réglages Calendrier';
$txt['search_weights'] = 'Pondérations';
$txt['search_method'] = 'Méthode de recherche';
$txt['search_sphinx'] = 'Configurer Sphinx';

$txt['smiley_sets'] = 'Jeux d\'émoticônes';
$txt['smileys_add'] = 'Ajouter une émoticône';
$txt['smileys_edit'] = 'Modifier les émoticônes';
$txt['smileys_set_order'] = 'Définir l\'ordre des émoticônes';
$txt['icons_edit_message_icons'] = 'Modifier les icônes des messages';

$txt['membergroups_new_group'] = 'Ajouter un groupe';
$txt['membergroups_edit_groups'] = 'Modifier les groupes';
$txt['permissions_groups'] = 'Permissions générales';
$txt['permissions_boards'] = 'Permissions par section';
$txt['permissions_profiles'] = 'Modifier les profils';
$txt['permissions_post_moderation'] = 'Modération des messages';

$txt['browse_packages'] = 'Parcourir les paquets';
$txt['download_packages'] = 'Télécharger des paquets';
$txt['upload_packages'] = 'Téléverser des paquets';
$txt['installed_packages'] = 'Paquets installés';
$txt['package_file_perms'] = 'Permissions des fichiers';
$txt['package_settings'] = 'Paramètres';
$txt['package_servers'] = 'Serveurs de paquets';
$txt['themeadmin_admin_title'] = 'Gérer et installer';
$txt['themeadmin_list_title'] = 'Réglages des thèmes';
$txt['themeadmin_reset_title'] = 'Options des membres';
$txt['themeadmin_edit_title'] = 'Modifier les thèmes';
$txt['admin_browse_register_new'] = 'Inscrire un nouveau membre';

$txt['search_engines'] = 'Moteurs de recherche';
$txt['spider_logs'] = 'Journal des robots';
$txt['spider_stats'] = 'Statistiques';

$txt['paid_subscriptions'] = 'Abonnements payants';
$txt['paid_subs_view'] = 'Voir les abonnements';

$txt['maintain_sub_hooks_list'] = 'Crochets d\'intégration';
$txt['hooks_field_hook_name'] = 'Nom du crochet';
$txt['hooks_field_function_name'] = 'Nom de la fonction';
$txt['hooks_field_function'] = 'Fonction';
$txt['hooks_field_included_file'] = 'Fichier inclus';
$txt['hooks_field_file_name'] = 'Nom du fichier';
$txt['hooks_field_hook_exists'] = 'Statut';
$txt['hooks_active'] = 'Existe';
$txt['hooks_disabled'] = 'Désactivé'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Non trouvé';
$txt['hooks_no_hooks'] = 'Il n\'y a aucun crochet dans le système en ce moment.';
$txt['hooks_disable_legend'] = 'Légende';
$txt['hooks_disable_legend_exists'] = 'Le crochet existe et est actif';
$txt['hooks_disable_legend_disabled'] = 'Le crochet existe, mais il a été désactivé';
$txt['hooks_disable_legend_missing'] = 'Le crochet n\'a pas été trouvé';
$txt['hooks_reset_filter'] = 'Réinitialiser le filtre';

$txt['board_perms_allow'] = 'Autoriser';
$txt['board_perms_ignore'] = 'Ignorer';
$txt['board_perms_deny'] = 'Interdire';
$txt['all_boards_in_cat'] = 'Toutes les sections dans cette catégorie';

$txt['url'] = 'Adresse ';
$txt['words_sep'] = 'Séparateur de mots';

$txt['admin_order_title'] = 'Erreur d\'ordonnancement';
$txt['admin_order_error'] = 'Une erreur inconnue s\'est produite en traitant votre requête';

// Known controllers that can work on the front page
$txt['default'] = 'Par défaut';
$txt['front_page'] = 'Choisissez l\'action à montrer sur la page d\'accueil';

$txt['BoardIndex_Controller'] = 'Accueil des sections';
$txt['MessageIndex_Controller'] = 'Contenu d\'une section';
$txt['message_index_frontpage'] = 'Choisissez la section à montrer sur la page d\'accueil';
$txt['Recent_Controller'] = 'Messages récents';
$txt['recent_frontpage'] = 'Nombre de messages à afficher : ';
