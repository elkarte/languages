<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Mes notifications';
$txt['my_unread_mentions'] = 'Mes notifications non lues';
$txt['my_mentions_pages'] = 'page %1$d';
$txt['no_mentions_yet'] = 'Pas de rappels';
$txt['no_new_mentions'] = 'Pas de nouveaux rappels';

$txt['mentions_from'] = 'Membre';
$txt['mentions_when'] = 'Quand';
$txt['mentions_what'] = 'Message';
$txt['mentions_all'] = 'Tout afficher';
$txt['mentions_unread'] = 'Afficher les non lues';
$txt['mentions_action'] = 'Actions';
$txt['mentions_delete_warning'] = 'Voulez-vous vraiment supprimer cet entrée ?';
$txt['mentions_markread'] = 'Marquer comme lue';
$txt['mentions_markunread'] = 'Marquer comme non lue';

$txt['mentions_settings'] = 'Paramètres des notifications';
$txt['mentions_settings_desc'] = 'Dans cette zone, vous pouvez configurer les méthodes que le membre pourra sélectionner pour recevoir des notifications. La méthode de notifications "dans le forum" ne peut être refusée, pour toute autre méthode, vous pouvez décider de l\'autoriser ou non.';
$txt['mentions_enabled'] = 'Activer les notifications du site';
$txt['mentions_buddy'] = 'Ajouter une notification lorsqu\'un membre est ajouté à la liste d\'amis d\'une personne ';
$txt['mentions_dont_notify_rlike'] = 'Ne pas informer le membre lorsqu\'un "J\'aime" est retiré à un message';

$txt['mention_mentionmem'] = 'Vous a mentionné dans le message {msg_link}';
$txt['mention_likemsg'] = 'A aimé votre message {msg_link}';
$txt['mention_rlikemsg'] = 'N\'a pas aimé votre message {msg_link}';
$txt['mention_buddy'] = 'Vous a ajouté à sa liste d\'amis.';
$txt['mention_quotedmem'] = 'A cité un de vos messages dans {msg_link}';
$txt['mention_mailfail'] = 'Notification par courriel désactivée en raison d\'un échec d\'envoi';

$txt['mentions_type_all'] = 'Toutes les notifications';
$txt['mentions_type_mentionmem'] = 'Mentionné';
$txt['mentions_type_likemsg'] = 'J\'aimes';
$txt['mentions_type_rlikemsg'] = 'J\'aimes pas';
$txt['mentions_type_buddy'] = 'Ami';
$txt['mentions_type_quotedmem'] = 'Cité';
$txt['mentions_type_mailfail'] = 'Échec d’envoi ';

$txt['mentions_mark_all_read'] = 'Marquer ces notifications comme lues';

$txt['setting_notify_enable_this'] = 'Activer les notifications pour cet élément';

$txt['setting_buddy'] = 'Amis';
$txt['setting_likemsg'] = 'J\'aimes';
$txt['setting_rlikemsg'] = 'J\'aimes pas';
$txt['setting_mentionmem'] = '@rappels';
$txt['setting_quotedmem'] = 'Cité';
$txt['setting_mailfail'] = 'Échec d’envoi ';