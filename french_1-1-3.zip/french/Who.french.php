<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... aucune idée, désolé</em>';
$txt['who_admin'] = 'Vue du portail de l\'administrateur';
$txt['who_moderate'] = 'Vue du portail du modérateur';
$txt['who_generic'] = 'Vue de %1$s';
$txt['who_unknown'] = '<em>Action inconnue</em>';
$txt['who_user'] = 'Membre';
$txt['who_time'] = 'Date';
$txt['who_action'] = 'Action';
$txt['who_show1'] = 'Afficher ';
$txt['who_show_members_only'] = 'Seulement les Membres';
$txt['who_show_guests_only'] = 'Seulement les Invités';
$txt['who_show_spiders_only'] = 'Seulement les Robots';
$txt['who_show_all'] = 'Tout le monde';
$txt['who_no_online_spiders'] = 'Il n\'y a aucun robot en ligne en ce moment.';
$txt['who_no_online_guests'] = 'Il n\'y a aucun invité en ligne en ce moment.';
$txt['who_no_online_members'] = 'Il n\'y a aucun membre en ligne en ce moment.';

$txt['whospider_login'] = 'Consulte la page de connexion.';
$txt['whospider_register'] = 'Consulte la page d\'inscription.';
$txt['whospider_reminder'] = 'Consulte la page de rappel du mot de passe.';

$txt['whoall_activate'] = 'Active son compte.';
$txt['whoall_buddy'] = 'Modifie sa liste d\'amis.';
$txt['whoall_coppa'] = 'Remplit le formulaire d\'accord parental.';
$txt['whoall_credits'] = 'Consulte la page des crédits.';
$txt['whoall_emailuser'] = 'Envoie un e-mail à un autre membre.';
$txt['whoall_groups'] = 'Consulte la page des groupes de membres.';
$txt['whoall_help'] = 'Consulte l\'<a href="{help_url}">Aide</a>.';
$txt['whoall_quickhelp'] = 'Consulte une fenêtre d\'aide.';
$txt['whoall_pm'] = 'Consulte ses messages personnels.';
$txt['whoall_auth'] = 'Se connecte au forum.';
$txt['whoall_login'] = 'Consulte la page de connexion.';
$txt['whoall_login2'] = 'Consulte la page de connexion.';
$txt['whoall_logout'] = 'Se déconnecte du forum.';
$txt['whoall_markasread'] = 'Marque des sujets lus ou non lus.';
$txt['whoall_mentions'] = 'Consulte leur liste de mentions.';
$txt['whoall_modifykarma_applaud'] = 'Applaudit un membre.';
$txt['whoall_modifykarma_smite'] = 'Hue un membre.';
$txt['whoall_news'] = 'Consulte les nouvelles.';
$txt['whoall_notify'] = 'Modifie ses paramètres de notification.';
$txt['whoall_notifyboard'] = 'Modifie ses paramètres de notification.';
$txt['whoall_openidreturn'] = 'Se connecte en utilisant le mode OpenID.';
$txt['whoall_quickmod'] = 'Modère une section.';
$txt['whoall_recent'] = 'Vue d\'une <a href="{recent_url}">liste de sujets récents</a>.';
$txt['whoall_register'] = 'S\'inscrit sur le forum.';
$txt['whoall_reminder'] = 'Demande un rappel de mot de passe.';
$txt['whoall_reporttm'] = 'Rapporte un sujet à un modérateur.';
$txt['whoall_spellcheck'] = 'Utilise le correcteur orthographique';
$txt['whoall_unread'] = 'Consulte la liste des sujets non lus depuis sa dernière visite.';
$txt['whoall_unreadreplies'] = 'Consulte la liste des réponses non lues depuis sa dernière visite.';
$txt['whoall_who'] = 'Consulte <a href="{who_url}">Qui est en ligne</a>.';

$txt['whoall_collapse_collapse'] = 'Rétracte une catégorie.';
$txt['whoall_collapse_expand'] = 'Développe une catégorie.';
$txt['whoall_pm_removeall'] = 'Supprime tous ses messages personnels.';
$txt['whoall_pm_send'] = 'Envoie un message personnel.';
$txt['whoall_pm_send2'] = 'Envoie un message personnel.';

$txt['whotopic_announce'] = 'Annonce le sujet "<a href="%1$s">%2$s</a>".';
$txt['whotopic_attachapprove'] = 'Approuve un fichier joint.';
$txt['whotopic_dlattach'] = 'Télécharge un fichier joint.';
$txt['whotopic_deletemsg'] = 'Efface un message.';
$txt['whotopic_editpoll'] = 'Édite le sondage dans "<a href="%1$s">%2$s</a>".';
$txt['whotopic_editpoll2'] = 'Édite le sondage dans "<a href="%1$s">%2$s</a>".';
$txt['whotopic_jsmodify'] = 'Modifie les message dans "<a href="%1$s">%2$s</a>".';
$txt['whotopic_likes'] = 'Aime un message du sujet "<a href="%1$s">%2$s</a>".';
$txt['whotopic_lock'] = 'Verrouille le sujet "<a href="%1$s">%2$s</a>".';
$txt['whotopic_lockvoting'] = 'Verrouille le sondage dans "<a href="%1$s">%2$s</a>".';
$txt['whotopic_mergetopics'] = 'Fusionne le sujet "<a href="%1$s">%2$s</a>" avec un autre sujet.';
$txt['whotopic_movetopic'] = 'Déplace le sujet "<a href="%1$s">%2$s</a>" vers une autre section.';
$txt['whotopic_movetopic2'] = 'Déplace le sujet "<a href="%1$s">%2$s</a>" vers une autre section.';
$txt['whotopic_post'] = 'Rédige dans <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Rédige dans <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Imprime le sujet "<a href="%1$s">%2$s</a>.';
$txt['whotopic_quickmod2'] = 'Modère le sujet <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Retire le sondage dans "<a href="%1$s">%2$s</a>".';
$txt['whotopic_removetopic2'] = 'Retire le sujet <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Envoie le sujet "<a href="%1$s">%2$s</a>" à un ami.';
$txt['whotopic_splittopics'] = 'Divise le sujet "<a href="%1$s">%2$s</a>" en deux sujets.';
$txt['whotopic_sticky'] = 'A épinglé le sujet "<a href="%1$s">%2$s</a>".';
$txt['whotopic_unwatch'] = 'A cessé de consulter un sujet.';
$txt['whotopic_vote'] = 'Vote dans <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'A commencé à consulter un sujet.';

$txt['whopost_quotefast'] = 'Cite un message de "<a href="%1$s">%2$s</a>".';

$txt['whoadmin_editagreement'] = 'Modifie l\'accord d\'inscription.';
$txt['whoadmin_featuresettings'] = 'Modifie les fonctionnalités et options du forum.';
$txt['whoadmin_modlog'] = 'Consulte le journal des actions de modération.';
$txt['whoadmin_serversettings'] = 'Modifie les paramètres du serveur.';
$txt['whoadmin_packageget'] = 'Récupère des paquets.';
$txt['whoadmin_packages'] = 'Consulte le gestionnaire de paquets.';
$txt['whoadmin_permissions'] = 'Modifie les permissions du forum.';
$txt['whoadmin_pgdownload'] = 'Télécharge un paquet.';
$txt['whoadmin_theme'] = 'Modifie les réglages du thème.';
$txt['whoadmin_trackip'] = 'Surveille une adresse IP.';

$txt['whoallow_manageboards'] = 'Modifie les paramètres des sections et des catégories.';
$txt['whoallow_admin'] = 'Consulte le <a href="{admin_url}">centre d\'administartion</a>.';
$txt['whoallow_ban'] = 'Modifie la liste des bannissements.';
$txt['whoallow_boardrecount'] = 'Recompte les totaux du forum.';
$txt['whoallow_calendar'] = 'Consulte le <a href="{calendar_url}">calendrier</a>.';
$txt['whoallow_editnews'] = 'Modifie les nouvelles.';
$txt['whoallow_mailing'] = 'Envoie une infolettre.';
$txt['whoallow_maintain'] = 'Exécute une tâche de maintenance du forum.';
$txt['whoallow_manageattachments'] = 'Gère les pièces jointes.';
$txt['whoallow_moderate'] = 'Consulte le <a href="{moderate_url}">centre de modération</a>.';
$txt['whoallow_memberlist'] = 'Consulte la <a href="{memberlist_url}">liste des membres</a>.';
$txt['whoallow_optimizetables'] = 'Optimise les tables de la base de données.';
$txt['whoallow_repairboards'] = 'Répare les tables de la base de données.';
$txt['whoallow_search'] = '<a href="{search_url}">Fait une recherche</a> dans le forum.';
$txt['whoallow_search_results'] = 'Consulte les résultats d\'une recherche.';
$txt['whoallow_setcensor'] = 'Modifie les mots à censurer.';
$txt['whoallow_setreserve'] = 'Modifie les noms réservés.';
$txt['whoallow_stats'] = 'Consulte les <a href="{stats_url}">statistiques du forum</a>.';
$txt['whoallow_viewErrorLog'] = 'Consulte le Journal des erreurs.';
$txt['whoallow_viewmembers'] = 'Consulte une liste de membres.';

$txt['who_topic'] = 'Consulte le sujet <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Consulte la section <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Consulte l\'index de la section <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Consulte le profil de <a href="%1$s">%2$s</a>.';
$txt['who_profile'] = 'Modifie le profil de <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Créé un nouveau sujet dans <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Créé un nouveau sondage dans <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Courriel ouvre un nouveau sujet dans <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Message par courriel dans <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Envoie un message personnel par courriel.';

// Credits text
$txt['credits'] = 'Crédits';
$txt['credits_intro'] = 'ElkArte est 100% gratuit et open-source. Nous encourageons et supportons une active communauté ouverte qui accepte les contributions du public. Nous voulons remercier chaque personne qui a supporté le projet en produisant du code, des retours, des rapports de bogues, des avis, et sans lesquelles cela n\'aurait pas été possible. Nous voulons aussi remercier spécialement <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, le projet à partir duquel ElkArte est né.';
$txt['credits_contributors'] = 'Contributeurs';
$txt['credits_and'] = 'et';
$txt['credits_copyright'] = 'Copyrights';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Modules';
$txt['credits_software_graphics'] = 'Logiciel/Visuels';
$txt['credits_software'] = 'Logiciel';
$txt['credits_graphics'] = 'Visuels';
$txt['credits_fonts'] = 'Polices';
$txt['credits_groups_contrib'] = 'Collaborateurs';
$txt['credits_contrib_list'] = 'Pour voir la liste complète de celles et ceux qui ont collaboré à la conception et à l\'implémentation d\'Elkarte, veuillez consulter le site github officiel à <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">liste des contributeurs</a>.';
$txt['credits_license'] = 'Licence';
$txt['credits_copyright'] = 'Copyrights';
$txt['credits_version'] = 'Version';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Traducteurs';
$txt['credits_translators_message'] = 'Merci de vos efforts, qui rendent possible l\'utilisation d\'ElkArte par des gens partout à travers le monde. Pour voir la liste complète des traducteurs, veuillez consulter le site Transifex officiel à <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">liste des contributeurs</a>.';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s ';
$txt['yesterday'] = '%1$s ';