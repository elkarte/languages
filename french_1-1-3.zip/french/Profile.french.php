<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Vous n\'êtes pas autorisé à modifier le profil de ce membre.';
$txt['website_title'] = 'Titre du site web';
$txt['website_url'] = 'Adresse du site web';
$txt['signature'] = 'Signature';
$txt['profile_posts'] = 'Messages';

$txt['profile_info'] = 'Détails supplémentaires';
$txt['profile_contact'] = 'Information de contact';
$txt['profile_moderation'] = 'Information de modération';
$txt['profile_more'] = 'Signature';
$txt['profile_attachments'] = 'Pièces jointes récentes';
$txt['profile_attachments_no'] = 'Aucune pièces jointes de la part de ce membre';
$txt['profile_recent_posts'] = 'Messages récents';
$txt['profile_posts_no'] = 'Il n\'y a aucun messages de la part de ce membre';
$txt['profile_topics'] = 'Sujets récents';
$txt['profile_topics_no'] = 'Il n\'y aucun sujets de la part de ce membre';
$txt['profile_buddies_no'] = 'Vous n\'avez pas inscrits d\'amis';
$txt['profile_user_info'] = 'Informations utilisateur';
$txt['profile_contact_no'] = 'Il n\'y a pas d\'information de contact pour ce membre';
$txt['profile_signature_no'] = 'Il n\'y a pas de signature pour ce membre';
$txt['profile_additonal_no'] = 'Il n\'y a pas d\'information complémentaire pour ce membre';
$txt['profile_user_summary'] = 'Profil';
$txt['profile_action'] = 'Actuellement';
$txt['profile_recent_activity'] = 'Activité récente';
$txt['profile_activity'] = 'Activité';
$txt['profile_loadavg'] = 'Réessayer à nouveau plus tard.  Cette information n\'est actuellement pas disponible à cause d\'une forte activité sur le site.';

$txt['change_profile'] = 'Modifier le profil';
$txt['preview_signature'] = 'Aperçu de la signature';
$txt['current_signature'] = 'Signature actuelle';
$txt['signature_preview'] = 'Prévisualisation de la signature';
$txt['personal_picture'] = 'Avatar personnalisé';
$txt['no_avatar'] = 'Pas d\'avatar';
$txt['choose_avatar_gallery'] = 'Choisir un avatar dans la galerie';
$txt['preferred_language'] = 'Langue préférée';
$txt['age'] = 'Âge';
$txt['no_pic'] = '(pas d\'image)';
$txt['avatar_by_url'] = 'Spécifier votre propre avatar par adresse. (ex : <em>http://www.mapage.com/monimage.gif</em>)';
$txt['my_own_pic'] = 'Spécifier un avatar par son adresse';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'La format indiqué sera utilisé pour afficher les dates sur le forum.';
$txt['time_format'] = 'Format de l\'heure';
$txt['display_name_desc'] = 'Ceci est le nom affiché sur toutes les pages du forum, celui que les visiteurs verront.';
$txt['personal_time_offset'] = 'Nombre d\'heures en +/- pour faire correspondre l\'heure affichée avec votre heure locale.';
$txt['dob'] = 'Date de naissance';
$txt['dob_month'] = 'Mois (MM)';
$txt['dob_day'] = 'Jour (JJ)';
$txt['dob_year'] = 'Année (AAAA)';
$txt['password_strength'] = 'Pour plus de sécurité, vous devriez choisir au moins huit (8) caractères avec une combinaison de lettres, chiffres et symboles.';
$txt['include_website_url'] = 'Indispensable si vous mettez une adresse ci-dessous.';
$txt['complete_url'] = 'Ceci doit être une adresse complète. (http://www...)';
$txt['sig_info'] = 'Les signatures sont affichées en bas de chaque message ou message personnel. Vous pouvez y inclure du BBCode et des émoticônes.';
$txt['max_sig_characters'] = '%1$d caractères sont autorisés au maximum. Il en reste : ';
$txt['send_member_pm'] = 'Envoyer un message personnel à ce membre';
$txt['hidden'] = 'caché';
$txt['current_time'] = 'Heure actuelle du forum';

$txt['language'] = 'Langue';
$txt['avatar_too_big'] = 'Cet Avatar est trop grand, merci de le redimensionner avant de réessayer (max';
$txt['invalid_registration'] = 'Date enregistrée invalide, exemple d\'une date valide : ';
$txt['current_password'] = 'Mot de passe actuel';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Pour des raisons évidentes de sécurité, votre mot de passe actuel est nécessaire pour modifier votre compte.';

$txt['timeoffset_autodetect'] = 'auto-détecter';

$txt['secret_question'] = 'Question secrète';
$txt['secret_desc'] = 'Pour vous aider à retrouver votre mot de passe, vous pouvez entrer ici une question et sa réponse que <strong>vous seul</strong> connaissez.';
$txt['secret_desc2'] = 'Choisissez-la prudemment et évitez que l\'on puisse deviner facilement la réponse ! ';
$txt['secret_answer'] = 'Réponse';
$txt['incorrect_answer'] = 'Désolé, mais vous n\'avez pas défini de question secrète/réponse valide dans votre profil.  Merci de cliquer le bouton Retour, et utilisez la méthode par défaut pour obtenir votre mot de passe.';
$txt['enter_new_password'] = 'Merci d\'entrer la réponse à votre question, et le mot de passe que vous souhaitez utiliser.  Votre mot de passe sera remplacé par celui fourni en répondant correctement à votre question.';
$txt['secret_why_blank'] = 'Pourquoi est-ce vide ? ';

$txt['authentication_reminder'] = 'Rappel d\'authentification';
$txt['password_reminder_desc'] = 'Si vous avez oublié vos détails de connexion, pas de souci, on peut vous aider. Pour commencer, veuillez entrer votre identifiant ou adresse de courriel ci-dessous.';
$txt['authentication_options'] = 'Veuillez choisir une des deux options ci-dessous';
$txt['authentication_openid_email'] = 'Envoyez-moi par courriel un rappel de mon identité OpenID';
$txt['authentication_openid_secret'] = 'Je veux répondre à ma "question secrète" pour afficher mon identité OpenID';
$txt['authentication_password_email'] = 'Envoyez-moi par courriel un nouveau mot de passe';
$txt['authentication_password_secret'] = 'Je veux répondre à ma "question secrète" pour changer de mot de passe';
$txt['openid_secret_reminder'] = 'Veuillez entrer votre réponse à la question ci-dessous. Si elle est correcte, votre identité OpenID sera affichée.';
$txt['reminder_openid_is'] = 'L\'identité OpenID associée à votre compte est : <br />    <strong>%1$s</strong><br /><br />Veuillez la noter pour ne plus l\'oublier.';
$txt['reminder_continue'] = 'Continuer';

$txt['accept_agreement_title'] = 'Accepter le réglement';
$txt['agreement_accepted_title'] = 'Continuer';

$txt['current_theme'] = 'Thème actuel';
$txt['change'] = 'Changer de thème';
$txt['theme_forum_default'] = 'Les paramètres par défaut du forum ou de la section';
$txt['theme_forum_default_desc'] = 'Ceci est le thème par défaut, ce qui signifie que votre thème changera suivant les réglages de l\'administrateur et la section que vous lisez.';

$txt['profileConfirm'] = 'Voulez-vous réellement effacer ce membre ?';

$txt['custom_title'] = 'Pseudonyme';

$txt['lastLoggedIn'] = 'Dernière connexion';

$txt['notify_settings'] = 'Paramètres de notification :';
$txt['notify_save'] = 'Sauvegarder les paramètres';
$txt['notify_important_email'] = 'Recevoir les lettres d\'information, les annonces du forum et les notifications importantes par courriel.';
$txt['notify_regularity'] = 'Pour les sujets et les sections pour lesquels j\'ai demandé la notification, notifiez-moi ';
$txt['notify_regularity_none'] = 'Jamais';
$txt['notify_regularity_instant'] = 'Instantanément';
$txt['notify_regularity_first_only'] = 'Instantanément - mais seulement pour la première réponse non lue';
$txt['notify_regularity_daily'] = 'Une fois par jour';
$txt['notify_regularity_weekly'] = 'Une fois par semaine';
$txt['auto_notify'] = 'Activer la notification du sujet quand je publie ou répond à un sujet.';
$txt['auto_notify_pbe_post'] = 'Cela <strong>N\'EST PAS</strong> recommandé si vous avez activé la notification de la section.';
$txt['notify_send_types'] = 'Pour les sujets et les sections pour lesquels j\'ai demandé la notification, notifiez-moi ';
$txt['notify_send_type_everything'] = 'Réponses et modération';
$txt['notify_send_type_everything_own'] = 'Actions de modération seulement si j\'ai démarré le sujet';
$txt['notify_send_type_only_replies'] = 'Seulement les réponses';
$txt['notify_send_type_only_replies_pbe'] = 'Tous les messages';
$txt['notify_send_type_nothing'] = 'Ne me notifiez pas';
$txt['notify_send_body'] = 'Lors de l\'envoi des notifications de réponse à un sujet, inclure le message complet dans le courriel envoyé (mais veuillez ne pas répondre à ces courriels !)';
$txt['notify_send_body_pbe'] = 'Quand un courriel de notification est envoyé, joindre le text complet au courriel';
$txt['notify_send_body_pbe_post'] = '<strong>NON</strong> disponible avec le résumé quotidien/hebdomadaire';

$txt['notify_method'] = 'Notification et : ';
$txt['notify_notification'] = 'pas de courriel (uniquement rappels/alertes)';
$txt['notify_email'] = 'Courriel immédiat';
$txt['notify_email_daily'] = 'Courriel quotidien';
$txt['notify_email_weekly'] = 'Courriel hebdomadaire';

$txt['notify_type_likemsg'] = 'Notifier lorsque l\'un de vos messages est approuvé';
$txt['notify_type_mentionmem'] = 'Notifier lorsque vous êtes nommé (@identifiant)';
$txt['notify_type_rlikemsg'] = 'Notifier lorsqu\'un "J\'aime" est retiré de l\'un de vos messages';
$txt['notify_type_buddy'] = 'Notifier lorsque quelqu\'un vous ajoute comme amis';
$txt['notify_type_quotedmem'] = 'Notifier lorsque quelqu\'un cite l\'un de vos messages';
$txt['notify_type_mailfail'] = 'Notifier lorsque les notifications par courriel sont désactivées (seuls les rappels/alertes sont possibles)';

$txt['notifications_topics'] = 'Notifications actuelles de sujets';
$txt['notifications_topics_none'] = 'Actuellement, vous ne recevez aucune notifications de sujet.';
$txt['notifications_topics_howto'] = 'Pour recevoir des notifications d\'un sujet, cliquez le bouton "Notifier" dans celui-ci.';

$txt['notifications_boards'] = 'Notifications actuelles de sections';
$txt['notifications_boards_none'] = 'Actuellement, vous ne recevez des notification d\'aucune sections.';
$txt['notifications_boards_howto'] = 'Pour demander des notifications pour une section, cliquez le bouton "Notifier" à l\'accueil de cette section <strong>ou</strong> utilisez les cases ci-dessous pour activer les notifications pour les sections cochées.';
$txt['notifications_boards_current'] = 'Vous recevez les notifications pour les sections affichées en <strong>GRAS</strong>. Utilisez les cases à cocher pour suprimer ou ajouter des sections à votre liste de notifications.';
$txt['notifications_boards_update'] = 'Mise à jour';
$txt['notifications_update'] = 'Dénotifier';

$txt['statPanel_showStats'] = 'Statistiques utilisateur pour : ';
$txt['statPanel_users_votes'] = 'Nombre de votes exprimés';
$txt['statPanel_users_polls'] = 'Nombre de sondages créés';
$txt['statPanel_total_time_online'] = 'Temps total passé en ligne';
$txt['statPanel_noPosts'] = 'Vous n\'avez posté aucun message !';
$txt['statPanel_generalStats'] = 'Statistiques générales';
$txt['statPanel_posts'] = 'messages';
$txt['statPanel_topics'] = 'sujets';
$txt['statPanel_total_posts'] = 'Total des messages';
$txt['statPanel_total_topics'] = 'Total des sujets initiés';
$txt['statPanel_votes'] = 'votes';
$txt['statPanel_polls'] = 'sondages';
$txt['statPanel_topBoards'] = 'Popularité des sections par messages';
$txt['statPanel_topBoards_posts'] = '%1$d messages sur les %2$d de cette section (%3$01.2f%%)';
$txt['statPanel_topBoards_memberposts'] = '%1$d messages sur les %2$d de ce membre (%3$01.2f%%)';
$txt['statPanel_topBoardsActivity'] = 'Popularité des sections par activité';
$txt['statPanel_activityTime'] = 'Activité de postage par heure';
$txt['statPanel_activityTime_posts'] = '%1$d messages (%2$d%%)';

$txt['deleteAccount_warning'] = 'Attention - Ces actions sont irréversibles !';
$txt['deleteAccount_desc'] = 'À partir de cette page vous pouvez supprimer le compte et les messages d\'un membre.';
$txt['deleteAccount_member'] = 'Supprimer le compte de ce membre';
$txt['deleteAccount_posts'] = 'Supprimer les messages publiés par ce membre';
$txt['deleteAccount_none'] = 'Aucun';
$txt['deleteAccount_all_posts'] = 'Réponses uniquement';
$txt['deleteAccount_topics'] = 'Sujets et Réponses';
$txt['deleteAccount_confirm'] = 'Êtes-vous absolument sûr de vouloir supprimer ce compte ?';
$txt['deleteAccount_approval'] = 'Veuillez noter que les modérateurs du forum devront approuver la suppression de ce compte avant qu\'elle soit effective.';

$txt['profile_of_username'] = 'Profil de %1$s';
$txt['profileInfo'] = 'Infos du Profil';
$txt['showPosts'] = 'Voir les messages';
$txt['showPosts_help'] = 'Cette section vous permet de consulter les contributions (messages, sujets et fichiers joints) d\'un utilisateur. Vous ne pourrez voir que les contributions des zones auxquelles vous avez accès.';
$txt['showMessages'] = 'Messages';
$txt['showGeneric_help'] = 'Cette espace vous permet de voir toutes les %1$s réalisées par ce membre. Vous ne pouvez voir que les %1$s réalisées dans les espaces auxquels vous avez accès.';
$txt['showTopics'] = 'Sujets';
$txt['showUnwatched'] = 'Sujets non vus';
$txt['showAttachments'] = 'Pièces jointes';
$txt['viewWarning_help'] = 'Cette espace vous permet de voir tous les avertissements reçus par ce membre.';
$txt['statPanel'] = 'Voir les statistiques';
$txt['editBuddyIgnoreLists'] = 'Liste d\'Amis/Ignorés';
$txt['editBuddies'] = 'Modifier la liste d\'Amis';
$txt['editIgnoreList'] = 'Modifier la liste d\'Ignorés';
$txt['trackUser'] = 'Suivre le membre';
$txt['trackActivity'] = 'Activité';
$txt['trackIP'] = 'Adresse IP';
$txt['trackLogins'] = 'Connexions';

$txt['likes_show'] = 'Afficher les "J\'aime"';
$txt['likes_given'] = 'Messages que vous avez appréciés';
$txt['likes_profile_received'] = 'reçus';
$txt['likes_profile_given'] = 'donnés';
$txt['likes_received'] = 'Vos messages appréciés par les autres';
$txt['likes_none_given'] = 'Vous n\'avez apprécié aucun messages';
$txt['likes_none_received'] = 'Personne n\'a apprécié aucun de vos messages :\'(';
$txt['likes_confirm_delete'] = 'Supprimer ce "J\'aime" ?';
$txt['likes_show_who'] = 'Montrer le membre qui a apprécié ce message';
$txt['likes_by'] = 'Apprécié par';
$txt['likes_delete'] = 'Supprimer';

$txt['authentication'] = 'Authentification';
$txt['change_authentication'] = 'D\'ici, vous pouvez modifier votre manière de vous connecter au forum. Vous pouvez soit choisir d\'utiliser un compte OpenID pour votre authentification, soit d\'utiliser un identifiant avec mot de passe.';

$txt['profileEdit'] = 'Modifier le Profil';
$txt['account_info'] = 'Ici sont vos préférences de compte. Cette page contient toutes les informations critiques qui peuvent vous identifier sur le forum. Pour des raisons de sécurité, vous devrez entrer votre mot de passe (actuel) pour modifier ces informations.';
$txt['forumProfile_info'] = 'Vous pouvez modifier vos informations personnelles sur cette page. Cette information sera affichée partout {forum_name_html_safe}. Si vous n\'êtes pas à l\'aise pour partager certaines informations passez à la suite - rien ici n\'est obligatoire.';
$txt['theme_info'] = 'Cette section vous permet de personnaliser l\'affichage et la disposition du forum.';
$txt['notification_info'] = 'Cela vous permet d\'être avisé des nouvelles réponses aux sujets, des nouveaux sujets et des nouvelles annonces du forum. Vous pouvez changer vos paramètres ici, ou voir les sujets et sections que vous suivez actuellement.';
$txt['groupmembership'] = 'Appartenance aux Groupes';
$txt['groupMembership_info'] = 'Dans cette section de votre profil, vous pouvez changer le ou les groupes auxquels vous appartenez.';
$txt['ignoreboards'] = 'Ignorer les options des sections';
$txt['ignoreboards_info'] = 'Cette page vous permet d\'ignorer certaines sections. Lorsqu\'une section est ignorée, l\'indicateur de nouveaux messages ne s\'affichera pas sur l\'accueil du forum. Les nouveaux messages ne seront pas affichés lors de l\'utilisation de la fonction "messages non lus" (la recherche des messages ignorera ces sections). Malgré tout, les sections ignorées apparaîtront toujours sur l\'accueil du forum et les sujets mis à jour y seront signalés si vous les visitez. Enfin, la fonction "réponses non lues" prend en compte toutes les sections, y compris celles qui sont ignorées.';
$txt['contactprefs'] = 'Messagerie';

$txt['profileAction'] = 'Actions';
$txt['deleteAccount'] = 'Effacer ce compte';
$txt['profileSendIm'] = 'Envoyer un message personnel';
$txt['profile_sendpm_short'] = 'Envoyer un MP';

$txt['profileBanUser'] = 'Bannir ce membre';

$txt['display_name'] = 'Pseudonyme';
$txt['enter_ip'] = 'Entrer une IP (plage)';
$txt['errors_by'] = 'Messages d\'erreur par';
$txt['errors_desc'] = 'Ci-dessous est affichée une liste des messages d\'erreur récents que cet utilisateur a généré/rencontrés.';
$txt['errors_from_ip'] = 'Messages d\'erreur depuis l\'IP (plage)';
$txt['errors_from_ip_desc'] = 'Ci-dessous est affichée une liste de toutes les erreurs générées par cette IP (plage).';
$txt['ip_address'] = 'Adresse IP';
$txt['ips_in_errors'] = 'Adresses IP utilisées dans les messages d\'erreur';
$txt['ips_in_messages'] = 'Adresses IP utilisées dans les derniers messages';
$txt['members_from_ip'] = 'Membres sur cette (plage d\') IP';
$txt['members_in_range'] = 'Membres possibles dans la même plage';
$txt['messages_from_ip'] = 'Messages envoyés depuis cette (plage d\') IP';
$txt['messages_from_ip_desc'] = 'Ci-dessous est affichée la liste de tous les messages postés depuis cette (plage d\') IP.';
$txt['trackLogins_desc'] = 'Ci-dessous une liste de tous les moments où ce compte était connecté.';
$txt['most_recent_ip'] = 'Adresse IP la plus récente';
$txt['why_two_ip_address'] = 'Pourquoi y-a-t\'il deux adresses IP listées ?';
$txt['no_errors_from_ip'] = 'Aucun message d\'erreur depuis cette adresse IP (plage)';
$txt['no_errors_from_user'] = 'Aucun message d\'erreur de ce membre';
$txt['no_members_from_ip'] = 'Aucun membre ayant l\'IP (plage) spécifiée n\'a été trouvé';
$txt['no_messages_from_ip'] = 'Aucun message depuis l\'IP (plage) spécifiée n\'a été trouvé';
$txt['trackLogins_none_found'] = 'Pas de connexions récentes trouvées';
$txt['none'] = 'Aucun';
$txt['own_profile_confirm'] = 'Voulez-vous réellement effacer votre compte ?';
$txt['view_ips_by'] = 'Voir les IPs utilisées par';

$txt['avatar_will_upload'] = 'Transférer un avatar';

$txt['activate_changed_email_title'] = 'Adresse de courriel modifiée';
$txt['activate_changed_email_desc'] = 'Vous avez changé votre adresse de courriel. Afin de valider cette adresse, vous allez recevoir un courriel dans la nouvelle boîte spécifiée. Cliquez sur le lien dans ce courriel pour réactiver votre compte.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Impossible d\'envoyer le courriel de rappel.';
$txt['send_email'] = 'Envoyer un courriel à';
$txt['to_ask_password'] = 'pour demander vos paramètres d\'authantification';

$txt['user_email'] = 'Identifiant/courriel';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'Un courriel a été envoyé à votre adresse de messagerie. Suivez le lien dans ce message pour obtenir un nouveau mot de passe.';
$txt['reminder_openid_sent'] = 'Votre identité OpenID actuelle a été envoyée à votre adresse de courriel.';
$txt['reminder_set_password'] = 'Définir le mot de passe';
$txt['reminder_password_set'] = 'Mot de passe défini avec succès';
$txt['reminder_error'] = '%1$s n\'a pas réussi à répondre correctement à sa question secrète en voulant retrouver un mot de passe perdu.';

$txt['registration_not_approved'] = 'Désolé, ce compte n\'a pas encore été approuvé. Si vous avez besoin de changer votre adresse de courriel, cliquez';
$txt['registration_not_activated'] = 'Désolé, ce compte n\'a pas encore été activé. Si vous voulez un nouveau courriel d\'activation, cliquez';

$txt['primary_membergroup'] = 'Groupe principal';
$txt['additional_membergroups'] = 'Groupes additionnels ';
$txt['additional_membergroups_show'] = 'Afficher les groupes additionnels';
$txt['no_primary_membergroup'] = '(pas de groupe principal)';
$txt['deadmin_confirm'] = 'Êtes-vous sûr de vouloir quitter irrévocablement votre statut d\'administrateur ?';

$txt['account_activate_method_2'] = 'Le compte requiert une réactivation après un changement d\'adresse de courriel';
$txt['account_activate_method_3'] = 'Le compte n\'est pas approuvé';
$txt['account_activate_method_4'] = 'Le compte est en attente d\'approbation de suppression';
$txt['account_activate_method_5'] = 'Le compte est un un compte "sous l\'âge minimum" en attente d\'approbation';
$txt['account_not_activated'] = 'Ce compte n\'est pas activé actuellement';
$txt['account_activate'] = 'activer';
$txt['account_approve'] = 'approuver';
$txt['user_is_banned'] = 'L\'utilisateur est actuellement banni';
$txt['view_ban'] = 'Voir';
$txt['user_banned_by_following'] = 'Cet utilisateur est actuellement affecté par les bannissements suivants';
$txt['user_cannot_due_to'] = 'L\'utilisateur ne peut pas %1$s, en raison de son bannissement : "%2$s"';
$txt['ban_type_post'] = 'publier';
$txt['ban_type_register'] = 's\'inscrire';
$txt['ban_type_login'] = 'se connecter';
$txt['ban_type_access'] = 'accéder au forum';

$txt['show_online'] = 'Autoriser l\'affichage de ma présence en ligne';

$txt['return_to_post'] = 'Par défaut, retourner dans les sujets après avoir publié.';
$txt['no_new_reply_warning'] = 'Ne pas aviser des nouvelles réponses publiées lors de la rédaction d\'un message.';
$txt['recent_pms_at_top'] = 'Voir les messages personnels récents en premier.';
$txt['wysiwyg_default'] = 'Par défaut afficher l\'éditeur WYSIWYG sur la page de rédaction.';

$txt['timeformat_default'] = '(Réglages par défaut du forum)';
$txt['timeformat_easy1'] = 'Mois Jour, Année, hh:mm:ss am/pm (sur 12 heures)';
$txt['timeformat_easy2'] = 'Mois Jour, Année, hh:mm:ss (sur 24 heures)';
$txt['timeformat_easy3'] = 'AAAA-MM-JJ, hh:mm:ss';
$txt['timeformat_easy4'] = 'JJ Mois AAAA, hh:mm:ss';
$txt['timeformat_easy5'] = 'JJ-MM-AAAA, hh:mm:ss';

$txt['poster'] = 'Auteur';

$txt['use_sidebar_menu'] = 'Utiliser les menus en barre verticale plutôt qu\'en menu déroulant.';
$txt['use_click_menu'] = 'Utiliser le clic pour ouvrir les menus au lieu de l\'ouverture au survole d\'un menu.';
$txt['show_no_avatars'] = 'Ne pas montrer les avatars des membres.';
$txt['show_no_signatures'] = 'Ne pas montrer les signatures des membres.';
$txt['show_no_censored'] = 'Ne pas censurer les mots.';
$txt['topics_per_page'] = 'Sujets affichés par page : ';
$txt['messages_per_page'] = 'Messages affichés par page : ';
$txt['hide_poster_area'] = 'Cacher l\'espace d\'information de l\'auteur.';
$txt['per_page_default'] = 'Options par défaut du forum';
$txt['calendar_start_day'] = 'Premier jour de la semaine pour le calendrier : ';
$txt['display_quick_reply'] = 'Utiliser la Réponse Rapide dans l\'affichage du sujet : ';
$txt['use_editor_quick_reply'] = 'Utiliser l\'éditeur complet  dans la Réponse rapide.';
$txt['display_quick_mod'] = 'Montrer la modération rapide sous forme : ';
$txt['display_quick_mod_none'] = 'ne pas afficher';
$txt['display_quick_mod_check'] = 'boîtes à cocher';
$txt['display_quick_mod_image'] = 'icônes';

$txt['whois_title'] = 'Chercher cette IP sur un serveur WHOIS régional';
$txt['whois_afrinic'] = 'AfriNIC (Afrique)';
$txt['whois_apnic'] = 'APNIC (Asie et Pacifique)';
$txt['whois_arin'] = 'ARIN (Amérique du Nord, une partie des Caraïbes et Afrique sub-saharienne)';
$txt['whois_lacnic'] = 'LACNIC (Amérique Latine et Caraïbes)';
$txt['whois_ripe'] = 'RIPE (Europe, le Moyen-Orient et des parties de l\'Afrique et Asie)';

$txt['moderator_why_missing'] = 'Pourquoi n\'y a-t-il aucun modérateur ici ?';
$txt['username_change'] = 'changer';
$txt['username_warning'] = 'Pour changer l\'identifiant de ce membre, le forum doit aussi réinitialiser son mot de passe, qui lui sera envoyé par courriel avec son nouvel identifiant.';

$txt['show_member_posts'] = 'Voir les Messages du membre';
$txt['show_member_topics'] = 'Voir les Sujets du membre';
$txt['show_member_attachments'] = 'Voir les pièces jointes du membre';
$txt['show_posts_none'] = 'Aucun message n\'a encore été publié.';
$txt['show_topics_none'] = 'Aucun sujet n\'a encore été publié.';
$txt['unwatched_topics_none'] = 'Vous n\'avez aucun sujet dans la liste des sujets non vus.';
$txt['show_attachments_none'] = 'Aucune pièces jointes n\'ont encore été envoyées.';
$txt['show_attach_filename'] = 'Nom de fichier';
$txt['show_attach_downloads'] = 'Téléchargements';
$txt['show_attach_posted'] = 'Publiés';

$txt['showPermissions'] = 'Montrer les permissions';
$txt['showPermissions_status'] = 'Statut de la permission';
$txt['showPermissions_help'] = 'Cette section vous permet de voir toutes les permissions de ce membre (les permissions refusées sont <del>barrées</del>).';
$txt['showPermissions_given'] = 'Attribué par';
$txt['showPermissions_denied'] = 'Interdit par';
$txt['showPermissions_permission'] = 'Permission (les permissions refusées sont <del>barrées</del>)';
$txt['showPermissions_none_general'] = 'Aucune permission générale n\'a été enregistrée pour ce membre.';
$txt['showPermissions_none_board'] = 'Aucune permission de section n\'a été enregistrée pour ce membre.';
$txt['showPermissions_all'] = 'En tant qu\'administrateur, ce membre a toutes les permissions possibles.';
$txt['showPermissions_select'] = 'Permissions de section pour';
$txt['showPermissions_general'] = 'Permissions générales';
$txt['showPermissions_global'] = 'Toutes les sections';
$txt['showPermissions_restricted_boards'] = 'Sections à accès restreint';
$txt['showPermissions_restricted_boards_desc'] = 'Les sections suivantes ne sont pas accessibles pour cet utilisateur';

$txt['local_time'] = 'Temps local';
$txt['posts_per_day'] = 'par jour';

$txt['buddy_ignore_desc'] = 'Cette section vous permet de tenir à jour vos listes d\'amis et d\'utilisateurs à ignorer sur ce forum. En ajoutant des membres à ces listes, vous pourrez entre autres contrôler votre trafic de courriels et de messages personnels selon vos préférences.';

$txt['buddy_add'] = 'Ajouter à la liste d\'amis';
$txt['buddy_remove'] = 'Retirer de la liste d\'amis';
$txt['buddy_add_button'] = 'Ajouter';
$txt['no_buddies'] = 'Votre liste d\'amis est actuellement vide';

$txt['ignore_add'] = 'Ajouter à la liste des membres à ignorer';
$txt['ignore_remove'] = 'Supprimer de la liste des membres ignorés';
$txt['ignore_add_button'] = 'Ajouter';
$txt['no_ignore'] = 'Votre liste d\'Ignorés est actuellement vide';

$txt['regular_members'] = 'Membres inscrits';
$txt['regular_members_desc'] = 'Tous les membres du forum font partie de ce groupe.';
$txt['group_membership_msg_free'] = 'Votre appartenance à un groupe a été mise à jour avec succès.';
$txt['group_membership_msg_request'] = 'Votre demande a été transmise, veuillez patienter le temps qu\'elle soit étudiée.';
$txt['group_membership_msg_primary'] = 'Votre groupe principal a été mis à jour';
$txt['current_membergroups'] = 'Groupes actuels';
$txt['available_groups'] = 'Groupes disponibles';
$txt['join_group'] = 'Rejoindre ce groupe';
$txt['leave_group'] = 'Quitter ce groupe';
$txt['request_group'] = 'Demander d\'adhésion';
$txt['approval_pending'] = 'Approbation en attente';
$txt['make_primary'] = 'Définir en tant que groupe principal';

$txt['request_group_membership'] = 'Demande d\'adhésion à un groupe';
$txt['request_group_membership_desc'] = 'Avant de pouvoir rejoindre ce groupe, votre adhésion doit être approuvée par le modérateur. Merci de donner la raison pour laquelle vous voulez le rejoindre';
$txt['submit_request'] = 'Envoyer la demande';

$txt['profile_updated_own'] = 'Votre profil a été mis à jour avec succès';
$txt['profile_updated_else'] = 'Le profil de <strong>%1$s</strong> a été mis à jour avec succès.';

$txt['profile_error_signature_max_length'] = 'Votre signature ne doit pas dépasser %1$d caractères';
$txt['profile_error_signature_max_lines'] = 'Votre signature ne doit pas dépasser %1$d lignes';
$txt['profile_error_signature_max_image_size'] = 'Les images de votre signature ne doivent pas être plus grandes que %1$dx%2$d pixels';
$txt['profile_error_signature_max_image_width'] = 'Les images de votre signature ne doivent pas avoir plus de %1$d pixels de largeur';
$txt['profile_error_signature_max_image_height'] = 'Les images de votre signature ne doivent pas avoir plus de %1$d pixels de hauteur';
$txt['profile_error_signature_max_image_count'] = 'Vous ne pouvez pas avoir plus de %1$d images dans votre signature';
$txt['profile_error_signature_max_font_size'] = 'La taille de la police du texte de votre signature ne doit pas dépasser %1$d';
$txt['profile_error_signature_allow_smileys'] = 'Vous n\'avez pas l\'autorisation d\'utiliser des émoticônes dans votre signature';
$txt['profile_error_signature_max_smileys'] = 'Vous n\'êtes pas autorisé à utiliser plus de %1$d émoticônes dans votre signature';
$txt['profile_error_signature_disabled_bbc'] = 'Le code BBC suivant n\'est pas autorisé dans votre signature : %1$s';

$txt['profile_view_warnings'] = 'Voir les Avertissements';
$txt['profile_issue_warning'] = 'Envoyer un Avertissement';
$txt['profile_warning_level'] = 'Niveau d\'avertissement';
$txt['profile_warning_desc'] = 'D\'ici, vous pouvez ajuster le niveau d\'avertissement d\'un utilisateur et émettre un avertissement si nécessaire. Vous pouvez aussi suivre son historique d\'avertissements et voir les effets de son niveau d\'avertissement actuel, tels que définis par l\'administrateur.';
$txt['profile_warning_name'] = 'Nom du Membre';
$txt['profile_warning_impact'] = 'Résultat';
$txt['profile_warning_reason'] = 'Motif de l\'Avertissement ';
$txt['profile_warning_reason_desc'] = 'Cela est obligatoire et sera archivé.';
$txt['profile_warning_effect_none'] = 'Aucun.';
$txt['profile_warning_effect_watch'] = 'L\'utilisateur sera ajouté à la liste de surveillance des modérateurs.';
$txt['profile_warning_effect_own_watched'] = 'Vous êtes sur la liste de surveillance des modérateurs.';
$txt['profile_warning_is_watch'] = 'sous surveillance';
$txt['profile_warning_effect_moderate'] = 'Tous les messages de l\'utilisateur seront modérés avant publication.';
$txt['profile_warning_effect_own_moderated'] = 'Tous vos messages seront modérés.';
$txt['profile_warning_is_moderation'] = 'messages qui sont modérés';
$txt['profile_warning_effect_mute'] = 'L\'utilisateur n\'aura plus la possibilité de publier.';
$txt['profile_warning_effect_own_muted'] = 'Vous ne pouvez plus publier.';
$txt['profile_warning_is_muted'] = 'ne peut pas publier';
$txt['profile_warning_effect_text'] = 'Niveau >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Envoyer une Notification';
$txt['profile_warning_notify_template'] = 'Sélectionner un modèle : ';
$txt['profile_warning_notify_subject'] = 'Titre de la Notification';
$txt['profile_warning_notify_body'] = 'Message de notification';
$txt['profile_warning_notify_template_subject'] = 'Vous avez reçu un avertissement';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},

Vous avez reçu un avertissement pour %1$s. Veuillez cesser ces activités et vous conformer aux règles du forum sinon nous devrons prendre d\'autres mesures.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},

Vous avez reçu un avertissement pour %1$s en rapport avec le message :
{MESSAGE}.

Veuillez cesser ces activités et vous conformer aux règles de forum sinon nous devrons prendre d\'autres mesures.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'pourriel';
$txt['profile_warning_notify_title_spamming'] = 'pourriel';
$txt['profile_warning_notify_for_offence'] = 'message au contenu inapproprié';
$txt['profile_warning_notify_title_offence'] = 'Message au contenu inapproprié';
$txt['profile_warning_notify_for_insulting'] = 'insultes envers d\'autres utilisateurs et/ou membres de l\'équipe';
$txt['profile_warning_notify_title_insulting'] = 'Insultes envers Utilisateurs/Equipe';
$txt['profile_warning_issue'] = 'Donner un Avertissement';
$txt['profile_warning_max'] = '(Max. 100)';
$txt['profile_warning_limit_attribute'] = 'Notez que vous ne pouvez pas ajuster ce niveau d\'utilisateur plus de %1$d%% fois par période de 24 heures.';
$txt['profile_warning_errors_occurred'] = 'L\'avertissement n\'a pas pu être envoyé à cause des erreurs suivantes';
$txt['profile_warning_success'] = 'Avertissement envoyé avec succès';
$txt['profile_warning_new_template'] = 'Nouveau modèle';

$txt['profile_warning_previous'] = 'Avertissements antérieurs';
$txt['profile_warning_previous_none'] = 'Cet utilisateur n\'a jamais reçu d\'avertissement à ce jour.';
$txt['profile_warning_previous_issued'] = 'Donné par';
$txt['profile_warning_previous_time'] = 'Date';
$txt['profile_warning_previous_level'] = 'Éléments';
$txt['profile_warning_previous_reason'] = 'Motif';
$txt['profile_warning_previous_notice'] = 'Voir les remarques envoyées au membre';

$txt['viewwarning'] = 'Voir les avertissements';
$txt['profile_viewwarning_for_user'] = 'Avertissements pour %1$s';
$txt['profile_viewwarning_no_warnings'] = 'Aucun avertissements n\'a été délivré.';
$txt['profile_viewwarning_desc'] = 'Vous trouverez ci-dessous la liste des avertissements qui ont été donnés par l\'équipe de modération du forum.';
$txt['profile_viewwarning_previous_warnings'] = 'Avertissements antérieurs';
$txt['profile_viewwarning_impact'] = 'Impact de l\'avertissement';

$txt['subscriptions'] = 'Abonnements payants';

$txt['pm_settings_desc'] = 'Ici vous pouvez modifier les options pour vos messages personnels, comme leur affichage et qui peut vous en envoyer.';
$txt['email_notify'] = 'Notifier par courriel à chaque fois que vous recevez un message personnel :';
$txt['email_notify_never'] = 'Jamais';
$txt['email_notify_buddies'] = 'Des amis uniquement';
$txt['email_notify_always'] = 'Toujours';

$txt['receive_from'] = 'Membres autorisés à me contacter : ';
$txt['receive_from_everyone'] = 'Tous les membres';
$txt['receive_from_ignore'] = 'Tous les membres, sauf ceux que j\'ignore';
$txt['receive_from_admins'] = 'Les administrateurs seulement';
$txt['receive_from_buddies'] = 'Mes amis et les administrateurs seulement';
$txt['receive_from_description'] = 'Ces paramètres s\'appliquent aux messages personnels et aux courriels (si l\'option permettant les courriels aux membres est activée)';

$txt['popup_messages'] = 'Afficher une fenêtre pop-up lorsque je reçois de nouveaux messages.';
$txt['pm_remove_inbox_label'] = 'Supprime le libellé  de la boîte Courriers entrants quand un nouveau libellé est appliqué.';
$txt['pm_display_mode'] = 'Afficher les messages personnels';
$txt['pm_display_mode_all'] = 'Tous à la fois';
$txt['pm_display_mode_one'] = 'Un à la fois';
$txt['pm_display_mode_linked'] = 'Triés par conversation';

$txt['history'] = 'Historique';
$txt['history_description'] = 'Cette section vous permet de vérifier certaines actions faites sur le profil de ce membre, mais aussi de suivre son adresse IP et son historique de connexion.';

$txt['trackEdits'] = 'Modifications du profil';
$txt['trackEdit_deleted_member'] = 'Membre supprimé';
$txt['trackEdit_no_edits'] = 'Aucune modification n\'a été enregistrée pour ce membre.';
$txt['trackEdit_action'] = 'Champ';
$txt['trackEdit_before'] = 'Valeur précédente';
$txt['trackEdit_after'] = 'Valeur suivante';
$txt['trackEdit_applicator'] = 'Modifié par';

$txt['trackEdit_action_real_name'] = 'Nom du Membre';
$txt['trackEdit_action_usertitle'] = 'Titre personnalisé';
$txt['trackEdit_action_member_name'] = 'Identifiant';
$txt['trackEdit_action_email_address'] = 'Adresse de courriel';
$txt['trackEdit_action_id_group'] = 'Groupe principal';
$txt['trackEdit_action_additional_groups'] = 'Groupes additionnels';

$txt['otp_enabled_help'] = 'Activer cela ajoutera une double authentification (mot de passe à usage unique).';
$txt['otp_token_help'] = 'Cela génère un jeton secret pour les applications basées sur des mots de passe à usage unique limités dans le temps comme Authy ou Google Authenticator.  Une fois que le code a été généré utilisez votre application d\'authentification favorite et scannez le qrcode. <ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator pour Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator pour IOS (Apple)</a></li></ul>';
