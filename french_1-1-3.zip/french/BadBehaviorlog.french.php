<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Date';
$txt['badbehaviorlog_protocol'] = 'Protocole';
$txt['badbehaviorlog_method'] = 'Méthode';
$txt['badbehaviorlog_request'] = 'Requête';
$txt['badbehaviorlog_uri'] = 'Adresse';
$txt['badbehaviorlog_id_member'] = 'Identifiant du membre';
$txt['badbehaviorlog_username'] = 'Identifiant';
$txt['badbehaviorlog_headers'] = 'En-têtes';
$txt['badbehaviorlog_agent'] = 'Navigateur';
$txt['badbehaviorlog_entity'] = 'Publier';
$txt['badbehaviorlog_key'] = 'Clé';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Total des actions';
$txt['badbehaviorlog_error_valid_code'] = 'Motif';
$txt['badbehaviorlog_error_valid_response'] = 'Statut HTTP';
$txt['badbehaviorlog_error_valid_explaination'] = 'Motif HTTP';
$txt['badbehaviorlog_error_valid_log'] = 'Détails';
$txt['badbehaviorlog_log'] = 'Journal des mauvais comportements';
$txt['badbehaviorlog_desc'] = 'Vous trouverez ci-dessous une liste de toutes les entrées enregistrées pour comportement incorrect';
$txt['badbehaviorlog_details'] = 'Détails supplémentaires';
$txt['badbehaviorlog_no_entries_found'] = 'Il n\'y a actuellement aucune entrée de journal pour comportement incorrect.';

$txt['badbehaviorlog_remove_selection'] = 'Effacer la sélection';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Êtes vous certain de vouloir effacer les journaux sélectionnés ?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Effacer tous les résultats filtrés';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Êtes-vous sûr de vouloir effacer les entrées filtrées ?';
$txt['badbehaviorlog_sure_remove'] = 'Voulez-vous vraiment entièrement effacer le journal des comportements incorrects ?';

$txt['badbehaviorlog_remove'] = 'Effacer la Sélection';
$txt['badbehaviorlog_removeall'] = 'Vider le journal';
$txt['badbehaviorlog_clear_filter'] = 'Vider le filtre';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Appliquer le filtre de type';
$txt['badbehaviorlog_apply_filter'] = 'Appliquer le filtre';
$txt['badbehaviorlog_applying_filter'] = 'Application du filtre';
$txt['badbehaviorlog_filter_only_member'] = 'Afficher uniquement les journaux de comportement incorrect de ce membre';
$txt['badbehaviorlog_filter_only_ip'] = 'Afficher uniquement les journaux de comportement incorrect provenant de cette adresse IP';
$txt['badbehaviorlog_filter_only_session'] = 'Afficher uniquement les comportements incorrects de cette session';
$txt['badbehaviorlog_filter_only_headers'] = 'Afficher uniquement les comportements incorrects de cette URL';
$txt['badbehaviorlog_filter_only_agent'] = 'Afficher uniquement les entrées avec le même agent utilisateur';

$txt['badbehaviorlog_session'] = 'Session';
$txt['badbehaviorlog_error_url'] = 'URL de la page qui a été enregistrée';

$txt['badbehaviorlog_reverse_direction'] = 'Inverser l\'ordre chronologique de la liste';
$txt['badbehaviorlog_filter_only_type'] = 'Afficher uniquement les journaux avec ce code';