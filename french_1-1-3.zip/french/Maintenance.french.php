<?php
// Version: 1.1; Maintenance

$txt['repair_zero_ids'] = 'Des sujets et/ou messages portant l\'ID 0 ont été trouvés.';
$txt['repair_missing_topics'] = 'Le message #%1$d est dans un sujet non existant (#%2$d).';
$txt['repair_missing_messages'] = 'Le sujet #%1$d ne contient aucun message réel.';
$txt['repair_stats_topics_1'] = 'Le sujet #%1$d débute par un message dont l\'ID (%2$d) est incorrect.';
$txt['repair_stats_topics_2'] = 'Le sujet #%1$d se termine par un message dont l\'ID (%2$d) est incorrect.';
$txt['repair_stats_topics_3'] = 'Le sujet #%1$d indique un nombre de réponses incorrect, %2$d.';
$txt['repair_stats_topics_4'] = 'Le sujet #%1$d indique un nombre de messages non approuvés incorrect, %2$d.';
$txt['repair_stats_topics_5'] = 'Le sujet #%1$d indique une valeur &quot;approuvé&quot; incorrecte.';
$txt['repair_missing_boards'] = 'Le sujet #%1$d est dans la section #%2$d, qui n\'existe pas.';
$txt['repair_missing_categories'] = 'La section #%1$d est dans la cétégoris #%2$d, qui n\'existe pas.';
$txt['repair_missing_posters'] = 'Le message #%1$d a été posté par le membre #%2$d, qui n\'existe pas ou plus.';
$txt['repair_missing_parents'] = 'La section #%1$d est fille de la section #%2$d, qui n\'existe pas.';
$txt['repair_missing_polls'] = 'Le sujet #%1$d est lié à un sondage #%2$d, qui n\'existe pas ou plus.';
$txt['repair_polls_missing_topics'] = 'Le sondage #%1$d est lié à un sujet inexistant #%2$d.';
$txt['repair_missing_calendar_topics'] = 'L\'événement #%1$d est lié à un sujet qui n\'existe pas ou plus, #%2$d.';
$txt['repair_missing_log_topics'] = 'Le sujet #%1$d est indiqué comme étant lu par une ou plusieurs personnes alors qu\'il n\'existe pas ou plus.';
$txt['repair_missing_log_topics_members'] = 'Le membre #%1$d est indiqué comme ayant lu un ou plusieurs sujets alors qu\'il n\'existe pas ou plus.';
$txt['repair_missing_log_boards'] = 'La section #%1$d est indiquée comme ayant été lue par une ou plusieurs personnes alors qu\'elle n\'existe pas ou plus.';
$txt['repair_missing_log_boards_members'] = 'Le membre #%1$d est indiqué comme ayant lu une ou plusieurs sections alors qu\'il n\'existe pas ou plus.';
$txt['repair_missing_log_mark_read'] = 'La section #%1$d est indiquée comme ayant été lue par une ou plusieurs personnes alors qu\'elle n\'existe pas ou plus.';
$txt['repair_missing_log_mark_read_members'] = 'Le membre #%1$d est indiqué comme ayant lu une ou plusieurs sections alors qu\'il n\'existe pas ou plus.';
$txt['repair_missing_pms'] = 'Le message personnel #%1$d a été envoyé à une ou plusieurs personnes, alors qu\'il n\'existe pas ou plus.';
$txt['repair_missing_recipients'] = 'Le membre #%1$d a reçu un ou plusieurs messages personnels alors qu\'il n\'existe pas ou plus.';
$txt['repair_missing_senders'] = 'Le message personnel #%1$d a été envoyé par le membre #%2$d, qui n\'existe pas ou plus.';
$txt['repair_missing_notify_members'] = 'Des notifications ont été demandées par le membre #%1$d, qui n\'existe pas ou plus.';
$txt['repair_missing_cached_subject'] = 'Le titre du sujet #%1$d n\'a pas été mis en cache.';
$txt['repair_missing_topic_for_cache'] = 'Le mot en cache \'%1$s\' est rattaché à un sujet inexistant.';
$txt['repair_missing_log_poll_member'] = 'Le sondage #%1$d a enregistré un vote par le membre #%2$d, qui n\'existe pas ou plus.';
$txt['repair_missing_log_poll_vote'] = 'Le membre #%1$d a participé au sondage #%2$d, qui n\'existe pas ou plus.';
$txt['repair_missing_thumbnail_parent'] = 'Une vignette existe, nommée %1$s, mais elle n\'a pas d\'image parente.';
$txt['repair_report_missing_comments'] = 'Le rapport #%1$d concernant le sujet &quot;%2$s&quot; n\'a pas de commentaire associé.';
$txt['repair_comments_missing_report'] = 'Le commentaire de rapport #%1$d soumis par %2$s n\'a pas de rapport associé.';
$txt['repair_group_request_missing_member'] = 'Une demande d\'adhésion à un groupe pour le membre supprimé #%1$d existe encore.';
$txt['repair_group_request_missing_group'] = 'Une demande d\'adhésion au groupe #%1$d qui n\'existe plus a été retrouvée.';

$txt['repair_currently_checking'] = 'Vérification de &quot;%1$s&quot;';
$txt['repair_currently_fixing'] = 'Réparation de &quot;%1$s&quot;';
$txt['repair_operation_zero_topics'] = 'Sujet dont la valeur id_topic est fixée à zéro par erreur';
$txt['repair_operation_zero_messages'] = 'Messages dont la valeur id_msg est fixée à zéro par erreur';
$txt['repair_operation_missing_topics'] = 'Messages sans sujet associé';
$txt['repair_operation_missing_messages'] = 'Sujets sans aucun messages';
$txt['repair_operation_stats_topics'] = 'Sujets où le premier ou dernier message n\'est pas le bon';
$txt['repair_operation_stats_topics2'] = 'Sujets où le nombre de réponses est erroné';
$txt['repair_operation_stats_topics3'] = 'Sujets où le nombre de réponses non approuvées est erroné';
$txt['repair_operation_missing_boards'] = 'Sujets dans une section inexistante';
$txt['repair_operation_missing_categories'] = 'Sections dans une catégorie inexistante';
$txt['repair_operation_missing_posters'] = 'Messages liés à des membres inexistants';
$txt['repair_operation_missing_parents'] = 'Sous-sections dont les sections parentes n\'existent pas';
$txt['repair_operation_missing_polls'] = 'Sujets liés à des sondages inexistants';
$txt['repair_operation_missing_calendar_topics'] = 'Événements liés à des sujets inexistants';
$txt['repair_operation_missing_log_topics'] = 'Journaux de sujets liés à des sujets inexistants';
$txt['repair_operation_missing_log_topics_members'] = 'Journaux de sujets liés à des membres inexistants';
$txt['repair_operation_missing_log_boards'] = 'Journaux de sections liés à des sections inexistantes';
$txt['repair_operation_missing_log_boards_members'] = 'Journaux de sections liés à des membres inexistants';
$txt['repair_operation_missing_log_mark_read'] = 'Informations sur les messages lus liées &agrave une section inexistante';
$txt['repair_operation_missing_log_mark_read_members'] = 'Informations sur les messages lus liées à un membre inexistant';
$txt['repair_operation_missing_pms'] = 'Messages privés manquants malgré l\'existence de destinataires';
$txt['repair_operation_missing_recipients'] = 'Destinataires de MP liés à un membre inexistant';
$txt['repair_operation_missing_senders'] = 'Messages personnels liés à un membre inexistant';
$txt['repair_operation_missing_notify_members'] = 'Journaux de notification liés à un membre inexistant';
$txt['repair_operation_missing_cached_subject'] = 'Sujets absents du cache de recherche';
$txt['repair_operation_missing_topic_for_cache'] = 'Cache de recherche lié à un sujet inexistant';
$txt['repair_operation_missing_member_vote'] = 'Votes de sondage liés à des membres inexistants';
$txt['repair_operation_missing_log_poll_vote'] = 'Votes de sondage liés à des sondages inexistants';
$txt['repair_operation_report_missing_comments'] = 'Rapports de sujet sans commentaire associé';
$txt['repair_operation_comments_missing_report'] = 'Commentaires de rapport sans rapport de sujet associé';
$txt['repair_operation_group_request_missing_member'] = 'Demandes d\'adhésion sans membre associé';
$txt['repair_operation_group_request_missing_group'] = 'Demandes d\'adhésion à un groupe inexistant';

$txt['salvaged_category_name'] = 'Zone de Récupération';
$txt['salvaged_category_error'] = 'Impossible de créer la catégorie Zone de Récupération !';
$txt['salvaged_board_name'] = 'Sujets récupérés';
$txt['salvaged_board_description'] = 'Sujets créés pour les messages sans sujet (fil de discussion)';
$txt['salvaged_board_error'] = 'Impossible de créer la section le Sujets récupérés !';
$txt['salvaged_poll_topic_name'] = 'Sondage récupéré';
$txt['salvaged_poll_message_body'] = 'Ce sondage a été trouvé son sujet associé.';

$txt['database_optimize'] = 'Optimiser la base de données';
$txt['database_numb_tables'] = 'Votre base de données contient %1$d tables.';
$txt['database_optimize_attempt'] = 'Tente d\'optimiser votre base de données...';
$txt['database_optimizing'] = 'Optimisation de %1$s... %2$01.2f KB optimisés.';
$txt['database_already_optimized'] = 'Toutes les tables étaient déjà optimisées.';
$txt['database_optimized'] = ' table(s) optimisée(s).';

$txt['apply_filter'] = 'Appliquer le filtre';
$txt['applying_filter'] = 'Application du filtre';
$txt['filter_only_member'] = 'Afficher uniquement les messages d\'erreurs pour ce membre';
$txt['filter_only_ip'] = 'Afficher uniquement les messages d\'erreurs pour cette adresse IP';
$txt['filter_only_session'] = 'Afficher uniquement les messages d\'erreurs pour cette session';
$txt['filter_only_url'] = 'Afficher uniquement les messages d\'erreurs pour cette adresse';
$txt['filter_only_message'] = 'Montrer uniquement les erreurs qui ont un message identique';
$txt['session'] = 'Session';
$txt['error_url'] = 'Adresse de la page causant l\'erreur';
$txt['error_message'] = 'Message d\'erreur';
$txt['clear_filter'] = 'Vider le filtre';
$txt['remove_selection'] = 'Effacer la sélection';
$txt['remove_filtered_results'] = 'Effacer tous les résultats filtrés';
$txt['sure_about_errorlog_remove'] = 'Êtes-vous sûr de vouloir complètement effacer le registre d\'erreurs ?';
$txt['remove_selection_confirm'] = 'Êtes-vous sûr de vouloir efface les entrées sélectionnées ?';
$txt['remove_filtered_results_confirm'] = 'Êtes-vous sûr de vouloir effacer les entrées filtrées ?';
$txt['reverse_direction'] = 'Inverser l\'ordre chronologique de la liste';
$txt['error_type'] = 'Type d\'erreur';
$txt['filter_only_type'] = 'Ne montrer que les erreurs de ce type';
$txt['filter_only_file'] = 'Ne montrer que les erreurs provenant de ce fichier';
$txt['apply_filter_of_type'] = 'Appliquer le filtre de type ';

$txt['errortype_all'] = 'Toutes les erreurs';
$txt['errortype_general'] = 'Générale ';
$txt['errortype_general_desc'] = 'Erreurs générales inclassables.';
$txt['errortype_critical'] = '<span class="error">Critique</span>';
$txt['errortype_critical_desc'] = 'Erreurs critiques. Elles nécessitent votre attention immédiate. Si vous ignorez ces erreurs, il se peut que votre forum tombe et ait des failles de sécurité.';
$txt['errortype_database'] = 'Base de données';
$txt['errortype_database_desc'] = 'Erreurs résultant de requêtes erronées. Elles devraient êtres bloquées et signalées à l\'équipe ElkArte.';
$txt['errortype_undefined_vars'] = 'Non défini';
$txt['errortype_undefined_vars_desc'] = 'Erreurs causées par l\'utilisation de variables, indexes ou décalages indéfinis.';
$txt['errortype_template'] = 'Modèles';
$txt['errortype_template_desc'] = 'Erreurs liées au chargement de modèles.';
$txt['errortype_user'] = 'Membre';
$txt['errortype_user_desc'] = 'Erreurs liées au comportement des utilisateurs. Par exemple, mots de passe erronés, tentative de connexion malgré un bannissement, et absence de permission pour une action spécifique.';

$txt['maintain_recount'] = 'Recompter tous les totaux et statistiques du forum';
$txt['maintain_recount_info'] = 'Si le nombre total de messages sur un sujet ou dans votre boîte de réception est incorrect, cette fonction peut corriger pour vous tous les décomptes et statistiques enregistrés.';
$txt['maintain_errors'] = 'Chercher et réparer les erreurs';
$txt['maintain_errors_info'] = 'Si, par exemple, des messages ou sujets ont disparu après un plantage serveur, cette fonction vous permettra peut-être de les récupérer.';
$txt['maintain_logs'] = 'Vider les journaux d\'importance mineure.';
$txt['maintain_logs_info'] = 'Cette fonction videra tous les journaux d\'importance mineure. À n\'utiliser qu\'en cas de problème, mais sans danger dans tous les cas.';
$txt['maintain_cache'] = 'Vider le cache';
$txt['maintain_cache_info'] = 'Cette fonction videra le cache, si vous avez besoin de le vider.';
$txt['maintain_optimize'] = 'Optimiser toutes les tables.';
$txt['maintain_optimize_info'] = 'Cette tâche vous permet d\'optimiser toutes les tables. Cela évitera les dépassements de mémoire, réduira la taille des tables et votre forum sera plus rapide.';
$txt['maintain_version'] = 'Comparer tous les fichiers avec la version la plus récente.';
$txt['maintain_version_info'] = 'Cette tâche de maintenance vous permet de faire une comparaison détaillée des versions des fichiers du forum par rapport aux derniers fichiers officiels.';
$txt['maintain_run_now'] = 'Lancer maintenant';
$txt['maintain_return'] = 'Retourner à la maintenance du forum';

$txt['maintain_backup'] = 'Sauvegarder la base de données';
$txt['maintain_backup_info'] = 'Télécharger une copie de sauvegarde de la base de données de votre forum en cas d\'urgence.';
$txt['maintain_backup_struct'] = 'Sauvegarder la structure des tables.';
$txt['maintain_backup_data'] = 'Sauver les données des tables (le contenu important).';
$txt['maintain_backup_gz'] = 'Compresser le fichier avec gzip.';
$txt['maintain_backup_save'] = 'Télécharger';

$txt['maintain_old'] = 'Effacer les anciens messages';
$txt['maintain_old_since_days'] = 'Effacer tous les sujets inactifs depuis %1$s jours, qui sont : ';
$txt['maintain_old_nothing_else'] = 'N\'importe quel type de sujet.';
$txt['maintain_old_are_moved'] = 'Des notifications de déplacement de sujet.';
$txt['maintain_old_are_locked'] = 'Bloqués';
$txt['maintain_old_are_not_stickied'] = 'Mais qui ne comprennent pas de sujets épinglés.';
$txt['maintain_old_all'] = 'Toutes les sections (cliquer pour sélectionner des sections spécifiques)';
$txt['maintain_old_choose'] = 'Des sections spécifiques (cliquer pour tout sélectionner)';
$txt['maintain_old_remove'] = 'Effacer maintenant';
$txt['maintain_old_confirm'] = 'Êtes-vous sûr de vouloir supprimer maintenant les anciens messages ?

Le processus ne peut être inversé !';

$txt['maintain_old_drafts'] = 'Effacer les anciens brouillons';
$txt['maintain_old_drafts_days'] = 'Effacer tous les brouillons datant de plus de %1$s jours';
$txt['maintain_old_drafts_confirm'] = 'Êtes-vous sûr de vouloir supprimer maintenant les anciens brouillons ?

Le processus ne peut être inversé !';
$txt['maintain_members'] = 'Effacer les membres inactifs';
$txt['maintain_members_since'] = 'Effacer tous les membres qui n\'ont pas {select_conditions} depuis {num_days} jours.';
$txt['maintain_members_activated'] = 'activé leur compte';
$txt['maintain_members_logged_in'] = 'cherché à se connecter';
$txt['maintain_members_all'] = 'Tous les groupes de membres';
$txt['maintain_members_choose'] = 'Groupes sélectionnés';
$txt['maintain_members_confirm'] = 'Êtes-vous sûr de vouloir supprimer ces comptes ?

Vous ne pourrez pas annuler cette opération !';

$txt['text_title'] = 'Convertir en TEXT';
$txt['mediumtext_title'] = 'Convertir en MEDIUMTEXT';
$txt['mediumtext_introduction'] = 'La table des messages par défaut accepte jusqu\'à 65535 caractères par message. Pour stocker des textes plus longs, les colonnes doivent être converties en "MEDIUMTEXT". Il est aussi possible de ramener la colonne à TEXT (cette opération reduira l\'espace occupé), mais <strong>seulement si</strong> aucun des messages de votre base de données ne dépasse 65535 caractères. Cette condition sera vérifiée avant la conversion.';
$txt['body_checking_introduction'] = 'Cette fonction convertira au format "TEXT" la colonne de votre base de données qui contient le texte des messages. (Elle est actuellement au format "MEDIUMTEXT"). Cette opération permettra de réduire un peu l\'espace occupé par chaque message (1 byte par message). Tout message de plus de 65535 caractères stocké dans la base de données sera tronqué, et une partie du texte sera perdu.';
$txt['exceeding_messages'] = 'Les messages suivants ont plus de 65535 caractères et seront tronqués par le processus : ';
$txt['exceeding_messages_morethan'] = 'Et autre %1$d';
$txt['convert_to_text'] = 'Aucun messages n\'a plus de 65535 caractères. Vous pouvez procéder à la conversion sans perdre de texte.';
$txt['convert_to_suggest_text'] = 'La colonne corps du message de votre base de données est actuellement fixée à MEDIUMTEXT. La taille maximale autorisée est inférieure à 65535 caractères par message. Vous gagneriez de l\'espace en convertissant la colonne au format TEXT.';
$txt['convert_proceed'] = 'Procéder';

// Move topics out.
$txt['move_topics_maintenance'] = 'Déplacer les sujets';
$txt['move_topics_from'] = 'Déplacer les sujets de';
$txt['move_topics_to'] = 'vers';
$txt['move_topics_now'] = 'Déplacer maintenant';
$txt['move_topics_confirm'] = 'Êtes-vous sûr de vouloir déplacer TOUS les sujets de &quot;%board_from%&quot; vers &quot;%board_to%&quot;&nbsp;?';

$txt['maintain_reattribute_posts'] = 'Réattribuer des messages aux utilisateurs';
$txt['reattribute_guest_posts'] = 'Attribuer les messages <em>invité</em> utilisant&nbsp;';
$txt['reattribute_email'] = 'Adresse de courriel de ';
$txt['reattribute_username'] = 'Identifiant de';
$txt['reattribute_current_member'] = 'Attribuer les messages à ce membre ';
$txt['reattribute_increase_posts'] = 'Ajouter les messages au total des messages du membre';
$txt['reattribute'] = 'Réattribuer';
// Don't use entities in the below string.
$txt['reattribute_confirm'] = 'Êtes-vous sûr de vouloir attribuer tous les messages d\'invités avec %type% "%find%" au membre "%member_to%" ?';
$txt['reattribute_confirm_username'] = 'un identifiant';
$txt['reattribute_confirm_email'] = 'pour adresse de courriel';
$txt['reattribute_cannot_find_member'] = 'Impossible de trouver le membre à qui réattribuer les messages.';

$txt['maintain_recountposts'] = 'Recompter les messages de l\'utilisateur';
$txt['maintain_recountposts_info'] = 'Lancez cette tâche de maintenance pour mettre à jour le total de messages de vos utilisateurs. Elle recomptera tous les messages qui peuvent l\'être, puis mettra à jour le total de messages dans leur profil.';

$txt['safe_mode_enabled'] = '<a href="http://php.net/manual/en/features.safe-mode.php">safe_mode</a> est activé sur votre serveur ! <br />La sauvegarde réalisée avec cette outil ne peut être considérée comme fiable !';
$txt['use_external_tool'] = 'Songez à utiliser un outil externe pour faire une sauvegarde de votre base de données. Les sauvegardes créées par le présent utilitaire ne sont pas fiables à 100 pour cent.';
$txt['zipped_file'] = 'Si vous le souhaitez vous pouvez créer une sauvegarde compressée (au format zip). ';
$txt['plain_text'] = 'La meilleure façon de faire une sauvegarde de votre base de données est de créer un fichier plain text. Une archive compactée pourrait ne pas être entièrement fiable.';
$txt['enable_maintenance1'] = 'Vu la taille de votre forum, nous vous recommandons de le mettre en « mode maintenance » avant de commencer une sauvegarde.';
$txt['enable_maintenance2'] = 'Avant de procéder, vu la taille de votre forum, veuillez le mettre en « mode maintenance ».';
$txt['security_database_download'] = 'Pour des raisons de sécurité, afin de procéder au téléchargement de la sauvegarde, vous devez fournir les paramètres FTP :';