<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Date';
$txt['modlog_member'] = 'Membre';
$txt['modlog_position'] = 'Rang';
$txt['modlog_action'] = 'Action';
$txt['modlog_ip'] = 'IP';
$txt['modlog_search_result'] = 'Résultats Recherche';
$txt['modlog_total_entries'] = 'Total des actions';
$txt['modlog_ac_approve_topic'] = 'Sujet "{topic}" approuvé par {member}';
$txt['modlog_ac_unapprove_topic'] = 'Sujet désapprouvé "{topic}" par "{member}"';
$txt['modlog_ac_approve'] = 'Message "{subject}" approuvé dans "{topic}" par "{member}"';
$txt['modlog_ac_unapprove'] = 'Message désapprouvé "{subject}" dans le sujet "{topic}" par "{member}"';
$txt['modlog_ac_lock'] = '"{topic}" verrouillé';
$txt['modlog_ac_warning'] = '{member} averti concernant "{message}"';
$txt['modlog_ac_unlock'] = '"{topic}" débloqué';
$txt['modlog_ac_sticky'] = '"{topic} épinglé';
$txt['modlog_ac_unsticky'] = '"{topic}" détaché';
$txt['modlog_ac_delete'] = '&quot;{subject}&quot; effacé de &quot;{topic}&quot; par &quot;{member}&quot;';
$txt['modlog_ac_delete_member'] = 'Membre &quot;{name}&quot; supprimé';
$txt['modlog_ac_remove'] = 'Sujet &quot;{topic}&quot; effacé de &quot;{board}&quot;';
$txt['modlog_ac_modify'] = '&quot;{message}&quot; modifié par &quot;{member}&quot;';
$txt['modlog_ac_merge'] = 'Sujets fusionnés pour créer &quot;{topic}&quot;';
$txt['modlog_ac_split'] = '&quot;{topic}&quot; séparé en deux pour créer &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = '&quot;{topic}&quot; déplacé de &quot;{board_from}&quot; à &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Profil de &quot;{member}&quot; modifié';
$txt['modlog_ac_pruned'] = 'Messages vieux de plus de {days} jours purgés';
$txt['modlog_ac_news'] = 'Nouvelles mises à jour';
$txt['modlog_enter_comment'] = 'Entrer un commentaire de modération';
$txt['modlog_moderation_log'] = 'Journal de Modération';
$txt['modlog_moderation_log_desc'] = 'Voici la liste des actions de modération faites par les modérateurs du forum.<br /><strong>Veuillez noter</strong> que les entrées ne peuvent être supprimées de ce journal avant un délai de 24h.';
$txt['modlog_no_entries_found'] = 'Aucune entrée pour le moment dans le journal de modération.';
$txt['modlog_remove'] = 'Effacer la Sélection';
$txt['modlog_removeall'] = 'Clear Log';
$txt['modlog_remove_selected_confirm'] = 'Êtes vous certain de vouloir effacer les journaux sélectionnés ?';
$txt['modlog_remove_all_confirm'] = 'Êtes vous certain de vouloir complètement vider les journaux ?';
$txt['modlog_go'] = 'Aller';
$txt['modlog_add'] = 'Ajouter';
$txt['modlog_search'] = 'Recherche Rapide';
$txt['modlog_by'] = 'Par';
$txt['modlog_id'] = '<em>Supprimé - (ID:%1$d)</em>';

$txt['modlog_ac_add_warn_template'] = 'Modèle d\'avertissement ajouté&nbsp;: &quot;{template}&quot;';
$txt['modlog_ac_modify_warn_template'] = 'Modèle d\'avertissement modifié&nbsp;: &quot;{template}&quot;';
$txt['modlog_ac_delete_warn_template'] = 'Modèle d\'avertissement supprimé&nbsp;: &quot;{template}&quot;';

$txt['modlog_ac_ban'] = 'Critères de bannissement ajoutés&nbsp;:';
$txt['modlog_ac_ban_update'] = 'Déclencheur de bannissement modifiés : ';
$txt['modlog_ac_ban_remove'] = 'Déclencheurs de bannissement retirés : ';
$txt['modlog_ac_ban_trigger_member'] = ' <em>Membre</em>&nbsp;: {member}';
$txt['modlog_ac_ban_trigger_email'] = ' <em>Courriel</em> : {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = ' <em>IP</em>&nbsp;: {ip_range}';
$txt['modlog_ac_ban_trigger_hostname'] = ' <em>Nom d\'hôte</em>&nbsp;: {hostname}';

$txt['modlog_admin_log'] = 'Journal d\'administration';
$txt['modlog_admin_log_desc'] = 'Voici la liste des actions d\'administration effectuées sur votre forum.<br /><strong>Veuillez noter</strong> que les entrées ne peuvent être supprimées de ce journal avant un délai de 24h.';
$txt['modlog_admin_log_no_entries_found'] = 'Aucune entrée pour le moment dans le journal d\'administration.';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Forum mis à jour en version {version}';
$txt['modlog_ac_install'] = 'Version {version} installée';
$txt['modlog_ac_add_board'] = 'Nouvelle section créée&nbsp;: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Section &quot;{board}&quot; modifiée';
$txt['modlog_ac_delete_board'] = 'Section &quot;{boardname}&quot; supprimée';
$txt['modlog_ac_add_cat'] = 'Nouvelle catégorie créée&nbsp;: &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Catégorie &quot;{catname}&quot; modifiée';
$txt['modlog_ac_delete_cat'] = 'Catégorie &quot;{catname}&quot; supprimée';

$txt['modlog_ac_delete_group'] = 'Groupe &quot;{group}&quot; supprimé';
$txt['modlog_ac_add_group'] = 'Groupe &quot;{group}&quot; créé';
$txt['modlog_ac_edited_group'] = 'Groupe &quot;{group}&quot; modifié';
$txt['modlog_ac_added_to_group'] = '&quot;{member}&quot; ajouté au groupe &quot;{group}&quot;';
$txt['modlog_ac_removed_from_group'] = '&quot;{member}&quot; retiré du groupe &quot;{group}&quot;';
$txt['modlog_ac_removed_all_groups'] = '&quot;{member}&quot; retiré de tous les groupes';

$txt['modlog_ac_remind_member'] = 'Rappel envoyé à &quot;{member}&quot; pour l\'activation de son compte';
$txt['modlog_ac_approve_member'] = 'Compte de &quot;{member}&quot; approuvé/activé';
$txt['modlog_ac_newsletter'] = 'Infolettre envoyée';

$txt['modlog_ac_install_package'] = 'Nouveau paquet installé&nbsp;: &quot;{package}&quot;, version {version} ';
$txt['modlog_ac_upgrade_package'] = 'Paquet mis à jour&nbsp;: &quot;{package}&quot; à la version {version} ';
$txt['modlog_ac_uninstall_package'] = 'Paquet désinstallé&nbsp;: &quot;{package}&quot;, version {version} ';

$txt['modlog_ac_database_backup'] = 'Sauvegarde de la base de données réalisée par {member}.';
$txt['modlog_ac_editing_theme'] = '{member} a édité un thème.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Sujet &quot;{topic}&quot; restauré à partir de &quot;{board}&quot; vers la section &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Messages restaurés à partir de &quot;{subject}&quot; vers le sujet &quot;{topic}&quot; dans la section &quot;{board}&quot;';

$txt['modlog_parameter_guest'] = '<em>Invité</em>';

$txt['modlog_ac_approve_attach'] = 'Fichier joint &quot;{filename}&quot; approuvé dans le message &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Le fichier joint &quot;{filename}&quot; a été rejeté dans le message &quot;{message}&quot;';