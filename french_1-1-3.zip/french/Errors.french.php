<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Désolé, vous ne pouvez pas accéder à cette section. Nous ne pouvons même pas vous dire si elle existe. Vous êtes invités à visiter la page principale et à choisir votre chemin à partir de là.';
$txt['not_guests'] = 'Désolé, cette action n\'est pas autorisée pour les Invités.';

$txt['mods_only'] = 'Seuls les modérateurs peuvent utiliser la fonction de suppression directe, veuillez supprimer ce message via la fonction de modification.';
$txt['no_name'] = 'Vous n\'avez pas rempli le champ du nom. Nous ne pouvons pas vous laisser continuer sans nom, désolé.';
$txt['no_email'] = 'Vous n\'avez pas rempli le champ Courriel. Nous ne pouvons pas vous laisser continuer sans courriel, désolé.';
$txt['topic_locked'] = 'Ce sujet est bloqué, vous n\'êtes pas autorisé à poster ou modifier un message ici...';
$txt['no_password'] = 'Champ MOT DE PASSE vide';
$txt['passwords_dont_match'] = 'Les mots de passe diffèrent.';
$txt['register_to_use'] = 'Désolé, vous devez vous inscrire avant d\'utiliser cette fonction.';
$txt['username_reserved'] = 'Le nom d\'utilisateur que vous avez essayé d\'utiliser contient le nom réservé «%1$s». Veuillez essayer un autre nom d\'utilisateur.';
$txt['numbers_one_to_nine'] = 'Ce champ n\'accepte que des chiffres de 0-9';
$txt['not_a_user'] = 'L\'utilisateur dont vous essayez de consulter le profil n\'existe pas.';
$txt['not_a_topic'] = 'Ce sujet n\'existe pas dans ce forum.';
$txt['not_approved_topic'] = 'Ce sujet n\'a pas encore été approuvé.';
$txt['email_in_use'] = 'Cette adresse de courriel (%1$s) est déjà utilisée par un membre inscrit. Si vous pensez que c\'est une erreur, allez sur la page de connexion et demandez le rappel de votre mot de passe en indiquant cette adresse.';

$txt['didnt_select_vote'] = 'Vous n\'avez pas choisi d\'option de vote.';
$txt['poll_error'] = 'Quelque chose ne fonctionne pas, désolé : soit ce sondage n\'existe pas, soit le sondage a été verrouillé, soit vous avez essayé de voter deux fois.';
$txt['locked_by_admin'] = 'Bloqué par un administrateur. Vous ne pouvez pas le débloquer.';
$txt['not_enough_posts_karma'] = 'Désolé, vous n\'avez pas assez de messages pour modifier un rayonnement - il vous en faut au moins %1$d.';
$txt['cant_change_own_karma'] = 'Désolé, vous ne pouvez pas modifier votre propre rayonnement.';
$txt['karma_wait_time'] = 'Désolé, vous ne pouvez répéter une action sur le rayonnement sans attendre %1$s %2$s.';
$txt['feature_disabled'] = 'Désolé, cette fonction est désactivée.';
$txt['feature_no_exists'] = 'Désolé, cette fonctionnalité n\'existe pas.';
$txt['couldnt_connect'] = 'Échec de la connexion au serveur, ou fichier non trouvé';
$txt['no_board'] = 'La section spécifiée est introuvable';
$txt['no_message'] = 'Le message n\'est plus disponible';
$txt['no_topic_id'] = 'ID de sujet invalide.';
$txt['split_first_post'] = 'Vous ne pouvez pas séparer un sujet sur le premier message.';
$txt['topic_one_post'] = 'Ce sujet ne contient qu\'un seul message et ne peut pas être séparé.';
$txt['no_posts_selected'] = 'Aucun message sélectionné';
$txt['selected_all_posts'] = 'Impossible de séparer. Vous avez sélectionné tous les messages.';
$txt['cant_find_messages'] = 'Messages introuvables';
$txt['cant_find_user_email'] = 'Impossible de trouver l\'adresse de courriel de l\'utilisateur.';
$txt['cant_insert_topic'] = 'Impossible d\'insérer le sujet';
$txt['session_timeout'] = 'Votre session a expiré lors de la publication. Veuillez revenir en arrière et réessayer.';
$txt['session_timeout_file_upload'] = 'Votre session a expiré lors du téléchargement du fichier. Veuillez réessayer.';
$txt['no_files_uploaded'] = 'Il n\'y a aucun fichier à télécharger.';
$txt['session_verify_fail'] = 'La vérification de session a échoué. Veuillez essayer de vous déconnecter, de revenir, puis réessayer de vous connecter.';
$txt['verify_url_fail'] = 'Impossible de vérifier l\'URL de référence : %1$s. Veuillez revenir en arrière et réessayer.';
$txt['token_verify_fail'] = 'La vérification du jeton a échoué. Veuillez revenir en arrière et réessayer.';
$txt['guest_vote_disabled'] = 'Les invités ne peuvent pas participer à ce sondage.';

$txt['cannot_access_mod_center'] = 'Vous n\'avez pas la permission d\'accéder au centre de modération.';
$txt['cannot_admin_forum'] = 'Vous n\'êtes pas autorisé à administrer ce forum.';
$txt['cannot_announce_topic'] = 'Vous n\'êtes pas autorisé à annoncer vos sujets dans cette section.';
$txt['cannot_approve_posts'] = 'Vous n\'avez pas la permission d\'approuver quoi que ce soit.';
$txt['cannot_post_unapproved_attachments'] = 'Vous n\'avez pas la permission de poster des fichiers joints non approuvés.';
$txt['cannot_post_unapproved_topics'] = 'Vous n\'avez pas la permission de poster des sujets non approuvés.';
$txt['cannot_post_unapproved_replies_own'] = 'Vous n\'avez pas la permission de poster des réponses non approuvées dans vos sujets.';
$txt['cannot_post_unapproved_replies_any'] = 'Vous n\'avez pas la permission de poster des réponses non approuvées dans les sujets des autres utilisateurs.';
$txt['cannot_calendar_edit_any'] = 'Vous ne pouvez pas modifier les événements du calendrier.';
$txt['cannot_calendar_edit_own'] = 'Vous n\'avez pas les privilèges requis pour modifier vos propres événements.';
$txt['cannot_calendar_post'] = 'Désolé, l\'ajout d\'événements n\'est pas autorisé.';
$txt['cannot_calendar_view'] = 'Désolé, mais vous n\'êtes pas autorisé à voir le calendrier.';
$txt['cannot_remove_any'] = 'Désolé, mais vous n\'avez pas les privilèges requis pour supprimer un sujet.';
$txt['cannot_remove_own'] = 'Vous ne pouvez pas effacer vos propres sujets dans ce forum.';
$txt['cannot_edit_news'] = 'Vous n\'êtes pas autorisé à modifier les nouvelles de ce forum.';
$txt['cannot_pm_read'] = 'Désolé, vous ne pouvez pas lire vos messages personnels.';
$txt['cannot_pm_send'] = 'Vous n\'êtes pas autorisé à envoyer des messages personnels';
$txt['cannot_karma_edit'] = 'Vous n\'êtes pas autorisé à modifier le karma des autres membres.';
$txt['cannot_like_posts'] = 'Vous n\'êtes pas autorisé à "Aimer" les messages de cette section.';
$txt['cannot_lock_any'] = 'Vous n\'êtes pas autorisé à verrouiller les sujets ici.';
$txt['cannot_lock_own'] = 'Désolé, mais vous ne pouvez pas bloquer vos propres sujets ici.';
$txt['cannot_make_sticky'] = 'Vous n\'êtes pas autorisé à épingler ce sujet.';
$txt['cannot_manage_attachments'] = 'Vous n\'avez pas les autorisations requises pour gérer les avatars et fichiers joints.';
$txt['cannot_manage_bans'] = 'Vous n\'avez pas les permissions nécessaires pour modifier la liste des bannissements.';
$txt['cannot_manage_boards'] = 'Vous n\'avez pas les autorisations requises pour gérer les sections et catégories.';
$txt['cannot_manage_membergroups'] = 'Vous n\'êtes pas autorisé à modifier ou à enregistrer des membres dans un groupe.';
$txt['cannot_manage_permissions'] = 'Vous n\'avez pas les autorisations requises pour gérer les permissions.';
$txt['cannot_manage_smileys'] = 'Vous n\'avez pas les autorisations requises pour gérer les smileys et les icônes de messages.';
$txt['cannot_mark_any_notify'] = 'Vous n\'avez pas les permissions nécessaires pour recevoir les notifications pour ce sujet.';
$txt['cannot_mark_notify'] = 'Désolé, vous n\'êtes pas autorisé à demander des notifications de ce forum.';
$txt['cannot_merge_any'] = 'Vous n\'êtes pas autorisé à fusionner des sujets sur une des sections sélectionnées.';
$txt['cannot_moderate_forum'] = 'Vous n\'êtes pas autorisé à modérer cette section.';
$txt['cannot_moderate_board'] = 'Vous n\'êtes pas autorisé à modérer cette section.';
$txt['cannot_modify_any'] = 'Vous n\'êtes autorisé à modifier des messages.';
$txt['cannot_modify_own'] = 'Désolé, mais vous n\'êtes pas autorisé à modifier vos propres messages.';
$txt['cannot_modify_replies'] = 'Bien que ce message soit une réponse à votre sujet, vous ne pouvez pas le modifier.';
$txt['cannot_move_own'] = 'Vous n\'êtes pas autorisé à déplacer vos propres sujets dans cette section.';
$txt['cannot_move_any'] = 'Vous n\'êtes pas autorisé à déplacer les sujets de cette section.';
$txt['cannot_poll_add_own'] = 'Désolé, vous n\'êtes pas autorisé à ajouter des sondages à vos propres sujets dans cette section.';
$txt['cannot_poll_add_any'] = 'Vous n\'avez pas les permissions pour ajouter un sondage dans ce sujet.';
$txt['cannot_poll_edit_own'] = 'Vous ne pouvez pas modifier ce sondage, bien que ce soit le votre.';
$txt['cannot_poll_edit_any'] = 'On vous a refusé l\'accès à la modification des sondages dans cette section.';
$txt['cannot_poll_lock_own'] = 'Vous n\'êtes pas autorisé à bloquer vos propres sondages dans cette section.';
$txt['cannot_poll_lock_any'] = 'Désolé, vous ne pouvez bloquer aucun sondage.';
$txt['cannot_poll_post'] = 'Vous n\'êtes pas autorisé à poster des sondages dans la section courante.';
$txt['cannot_poll_remove_own'] = 'Vous n\'êtes pas autorisé à supprimer ce sondage dans votre sujet.';
$txt['cannot_poll_remove_any'] = 'Vous ne pouvez retirer aucun sondage de cette section.';
$txt['cannot_poll_view'] = 'Vous n\'êtes pas autorisé à voir les sondages de cette section.';
$txt['cannot_poll_vote'] = 'Désolé, mais vous ne pouvez pas voter dans les sondages de cette section.';
$txt['cannot_post_attachment'] = 'Vous n\'avez pas la permission de poster des fichiers joints ici.';
$txt['cannot_post_new'] = 'Désolé, vous ne pouvez pas poster de nouveau sujet sur cette section.';
$txt['cannot_post_new_board'] = 'Désolé, vous ne pouvez pas publier de nouveaux sujets dans cette section %1$s.';
$txt['cannot_post_reply_any'] = 'Vous n\'êtes pas autorisé à poster des réponses aux sujets de cette section.';
$txt['cannot_post_reply_own'] = 'Vous n\'êtes pas autorisé à poster des réponses, même à vos propres sujets, dans cette section.';
$txt['cannot_profile_remove_own'] = 'Désolé, mais vous n\'avez pas l\'autorisation d\'effacer votre profil.';
$txt['cannot_profile_remove_any'] = 'Vous ne disposez pas des autorisations appropriées pour supprimer des comptes.';
$txt['cannot_profile_extra_any'] = 'Vous n\'êtes pas autorisé à modifier un paramètre du profil.';
$txt['cannot_profile_identity_any'] = 'Vous n\'êtes pas autorisé à modifier les paramètres relatifs au compte.';
$txt['cannot_profile_title_any'] = 'Vous ne pouvez pas modifier les pseudonymes des membres.';
$txt['cannot_profile_extra_own'] = 'Désolé, mais vous n\'avez pas les permissions nécessaires pour modifier votre profil.';
$txt['cannot_profile_identity_own'] = 'Vous ne pouvez pas changer votre identifiant pour l\'instant.';
$txt['cannot_profile_title_own'] = 'Vous n\'êtes pas autorisé à changer votre pseudonyme.';
$txt['cannot_profile_set_avatar'] = 'Vous n\'êtes pas autorisé à changer votre avatar.';
$txt['cannot_profile_view_own'] = 'Désolé, mais vous ne pouvez pas visualiser votre profil.';
$txt['cannot_profile_view_any'] = 'Désolé, mais vous ne pouvez visualiser aucun profil.';
$txt['cannot_delete_own'] = 'Désolé, vous ne pouvez pas supprimer vos messages dans cette section.';
$txt['cannot_delete_replies'] = 'Désolé, mais vous ne pouvez pas effacer ces messages, bien qu\'ils soient des réponses à votre sujet.';
$txt['cannot_delete_any'] = 'Désolé, vous ne pouvez pas supprimer de messages dans cette section.';
$txt['cannot_report_any'] = 'Vous n\'êtes pas autorisé à rapporter des messages de cette section.';
$txt['cannot_search_posts'] = 'Vous n\'êtes pas autorisé à rechercher des messages dans cette section.';
$txt['cannot_send_mail'] = 'Vous n\'avez pas l\'autorisation d\'envoyer des courriels à quiconque.';
$txt['cannot_issue_warning'] = 'Désolé, vous n\'avez pas la permission de donner des avertissements aux utilisateurs.';
$txt['cannot_send_topic'] = 'Désolé, mais l\'administrateur a interdit l\'envoi de sujets dans cette section.';
$txt['cannot_send_email_to_members'] = 'Désolé, mais l\'administrateur a interdit l\'envoi de courriels sur ce forum.';
$txt['cannot_split_any'] = 'Séparer un sujet n\'est pas autorisé dans cette section.';
$txt['cannot_view_attachments'] = 'Il semble que vous n\'êtes pas autorisé à télécharger ou voir les fichiers joints de cette section.';
$txt['cannot_view_mlist'] = 'Vous ne pouvez pas afficher la liste des membres car vous n\'y êtes pas autorisé.';
$txt['cannot_view_stats'] = 'Vous ne pouvez pas voir les statistiques du forum.';
$txt['cannot_who_view'] = 'Désolé - vous n\'avez pas les permissions nécessaires pour voir la liste des membres en ligne.';
$txt['cannot_like_posts_stats'] = 'Désolé, vous ne disposez pas des autorisations nécessaires pour afficher les statistiques des publications J\'aime.';

$txt['no_theme'] = 'Nous ne pouvons pas trouver ce thème.';
$txt['theme_dir_wrong'] = 'Le répertoire du thème par défaut est erroné, veuillez le corriger en cliquant sur ce texte.';
$txt['registration_disabled'] = 'Désolé, l\'inscription est actuellement désactivée.';
$txt['registration_agreement_missing'] = 'Le fichier du contrat d\'enregistrement, agreement.txt, est manquant ou vide. Les inscriptions seront désactivées jusqu\'à ce que cela soit corrigé';
$txt['registration_privacy_policy_missing'] = 'Le fichier de politique de confidentialité, privacypolicy.txt, est manquant ou vide. Les inscriptions seront désactivées jusqu\'à ce que cela soit corrigé';
$txt['registration_no_secret_question'] = 'Désolé, il n\'y a aucune question secrète programmée par ce membre.';
$txt['poll_range_error'] = 'Désolé, le sondage doit être validé pour plus de 0 jour.';
$txt['delFirstPost'] = 'Vous n\'êtes pas autorisé à supprimer le premier message d\'un sujet. <p>Si vous souhaitez supprimer ce sujet, cliquez sur le lien Supprimer ou demandez à un modérateur / administrateur de le faire pour vous.</p>';
$txt['login_cookie_error'] = 'Erreur de connexion.  Veuillez vérifier vos réglages pour l\'utilisation du témoin/cookie.';
$txt['incorrect_answer'] = 'Désolé, mais vous n\'avez pas répondu correctement à votre question.  Veuillez cliquer sur \'Retour\' et réessayer, ou cliquez Retour 2 fois afin d\'utiliser la méthode par défaut pour retrouver votre mot de passe.';
$txt['no_mods'] = 'Aucun modérateur trouvé&nbsp;!';
$txt['parent_not_found'] = 'La structure de la section est corrompue&nbsp;: impossible de trouver la section parente';
$txt['modify_post_time_passed'] = 'Vous ne pouvez pas modifier ce message puisque le temps limite pour les modifications est dépassé.';

$txt['calendar_off'] = 'Vous ne pouvez pas accéder au calendrier pour l\'instant car il est désactivé.';
$txt['calendar_export_off'] = 'Vous ne pouvez pas exporter les événements du calendrier car cette fonctionnalité est actuellement désactivée.';
$txt['invalid_month'] = 'Mois invalide.';
$txt['invalid_year'] = 'Année invalide.';
$txt['invalid_day'] = 'Jour invalide.';
$txt['event_month_missing'] = 'Mois de l\'événement manquant.';
$txt['event_year_missing'] = 'Année de l\'événement manquante.';
$txt['event_day_missing'] = 'Jour de l\'événement manquant.';
$txt['event_title_missing'] = 'Titre de l\'événement manquant.';
$txt['invalid_date'] = 'Date invalide.';
$txt['no_event_title'] = 'Titre d\'événement manquant.';
$txt['missing_board_id'] = 'ID de section manquant.';
$txt['missing_topic_id'] = 'ID de sujet manquant.';
$txt['topic_doesnt_exist'] = 'Le sujet n\'existe pas.';
$txt['not_your_topic'] = 'Ce sujet n\'est pas le vôtre.';
$txt['board_doesnt_exist'] = 'La section n\'existe pas.';
$txt['no_span'] = 'La fonction d\'intervalle est désactivée.';
$txt['invalid_days_numb'] = 'Nombre de jours d\'étalement invalide.';

$txt['moveto_noboards'] = 'Il n\'y a pas de forum où déplacer ce sujet';
$txt['topic_already_moved'] = 'Ce sujet %1$s a été déplacé vers la section %2$s, veuillez vérifier son nouvel emplacement avant de le déplacer à nouveau.';

$txt['already_activated'] = 'Nous serions ravis de traiter votre demande, mais votre compte a déjà été activé.';
$txt['still_awaiting_approval'] = 'Votre compte est encore en attente d\'approbation par un administrateur.';

$txt['invalid_email'] = 'Adresse de courriel invalide.<br />Exemple d\'une adresse e-mail valide : votreemail@votrefai.com.<br />Exemple d\'une plage d\'adresses de courriel valide : *@*.votrefai.com ';
$txt['invalid_expiration_date'] = 'Date d\'expiration non valide';
$txt['invalid_hostname'] = 'Nom/plage de domaine invalide.<br />Exemple de domaine valide : proxy4.grosmechantloup.com<br />Exemple de plage de domaine valide&nbsp;: *.grosmechantloup.com';
$txt['invalid_ip'] = 'IP ou plage d\'IP non valide.<br />Exemple d\'une adresse IP valide : 127.0.0.1<br />Exemple d\'une plage d\'adresses IP valide : 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Adresse IP ou bloc d\'adresses IP invalide.<br />Exemple d\'adresse IP valide&nbsp;: 127.0.0.1<br />Exemple de bloc valide&nbsp;: 127.0.0.*';
$txt['invalid_username'] = 'Identifiant du membre introuvable';
$txt['no_user_selected'] = 'Membre introuvable';
$txt['no_ban_admin'] = 'Hé ! Nous ne pouvons pas vous laisser bannir un administrateur. Si vous êtes certain de vouloir le faire, rétrogradez-le d\'abord !';
$txt['no_bantype_selected'] = 'Type de bannissement non sélectionné';
$txt['ban_not_found'] = 'Bannissement introuvable';
$txt['ban_unknown_restriction_type'] = 'Type de restriction inconnu';
$txt['ban_name_empty'] = 'Le nom du bannissement a été laissé vide';
$txt['ban_id_empty'] = 'Désolé, nous avons essayé de trouver cet ID d\'interdiction, mais il est introuvable.';
$txt['ban_group_id_empty'] = 'Un groupe d\'interdiction a besoin d\'un identifiant et ce groupe n\'en a pas.';
$txt['ban_no_triggers'] = 'Avez-vous oublié de sélectionner les facteurs déclenchants d\'interdiction ? Il en faut au moins et il n\'y en a pas !';
$txt['ban_ban_item_empty'] = 'Déclencheur d\'interdiction introuvable';
$txt['impossible_insert_new_bangroup'] = 'Une erreur s\'est produite lors de l\'insertion du nouveau bannissement';

$txt['like_heading_error'] = 'Erreur dans les "J\'aime"';
$txt['like_wait_time'] = 'Désolé, vous ne pouvez pas répéter une action similaire sans attendre %1$s %2$s.';
$txt['like_unlike_error'] = 'Il y a eu une erreur lors du J\'aime / J\'aime pas du message';
$txt['cant_like_yourself'] = 'Aimer vos propres messages ... c\'est comme rire de vos propres blagues quand il n\'y a personne d\'autre dans les parages ... lol ... Attendez, est-ce que je viens de me lol ?';

$txt['ban_name_exists'] = 'Le nom de ce bannissement (%1$s) existe déjà. Veuillez choisir un autre nom.';
$txt['ban_trigger_already_exists'] = 'Le déclencheur de bannissement %1$s existe déjà dans %2$s.';
$txt['attach_check_nag'] = 'Impossible de continuer en raison de données incomplètes (%1$s).';

$txt['recycle_no_valid_board'] = 'Aucune section valide n\'a été choisie pour stocker les sujets recyclés';
$txt['post_already_deleted'] = 'Le sujet ou le message a déjà été déplacé vers la section d\'archivage. Voulez-vous vraiment le supprimer complètement ? <br />Si tel est le cas suivez <a href="%1$s">ce lien</a>';

$txt['login_threshold_fail'] = 'Désolé, nombre de tentatives de connexion dépassé. Revenez essayer plus tard.';
$txt['login_threshold_brute_fail'] = 'Désolé, mais vous avez atteint votre seuil de tentatives de connexion. Veuillez patienter 30 secondes et réessayer.';

$txt['who_off'] = 'Nous serions ravis de vous donner un aperçu de Qui est en ligne, mais malheureusement, pour le moment, cette fonction est désactivée.';

$txt['merge_create_topic_failed'] = 'Désolé, la création d\'un nouveau sujet a échoué.';
$txt['merge_need_more_topics'] = 'La fusion des sujets nécessite au moins deux sujets, mais nous n\'en avons pas eu deux. Veuillez réessayer.';

$txt['post_WaitTime_broken'] = 'Le dernier message posté depuis votre adresse IP date d\'il y a moins de %1$d secondes. Veuillez réessayer plus tard.';
$txt['register_WaitTime_broken'] = 'Vous vous êtes déjà inscrit il y a %1$d secondes !';
$txt['login_WaitTime_broken'] = 'Vous devez attendre environ %1$d secondes avant de vous reconnecter, désolé.';
$txt['pm_WaitTime_broken'] = 'Le dernier message principal posté depuis votre adresse IP date d\'il y a moins de %1$d secondes. Veuillez réessayer plus tard.';
$txt['reporttm_WaitTime_broken'] = 'Le dernier sujet rapporté depuis votre adresse IP date d\'il y a moins de %1$d secondes. Veuillez réessayer plus tard.';
$txt['sendtopic_WaitTime_broken'] = 'Le dernier sujet envoyé depuis votre adresse IP date d\'il y a moins de %1$d secondes. Veuillez réessayer plus tard.';
$txt['sendmail_WaitTime_broken'] = 'Le dernier courriel envoyé depuis votre adresse IP date d\'il y a moins de %1$d secondes. Veuillez réessayer plus tard.';
$txt['search_WaitTime_broken'] = 'Votre dernière recherche date d\'il y a moins de %1$d secondes. Veuillez réessayer plus tard.';
$txt['remind_WaitTime_broken'] = 'Votre dernier rappel remonte à moins de %1$d secondes. Veuillez réessayer plus tard.';
$txt['contact_WaitTime_broken'] = 'La dernière fois que vous avez essayé d\'utiliser le formulaire de contact remonte à moins de %1$d secondes. Veuillez réessayer plus tard.';

$txt['topic_gone'] = 'Nous nous sommes efforcés de trouver le sujet ou la section que vous recherchez : il semble être manquant ou interdit pour vous.';
$txt['theme_edit_missing'] = 'Nous avons essayé de trouver le fichier que vous essayez de modifier, mais il est introuvable.';

$txt['no_dump_database'] = 'Désolé, nous ne pouvons pas vous permettre d\'effectuer des sauvegardes de base de données. Seuls les administrateurs peuvent.';
$txt['pm_not_yours'] = 'Le message personnel que vous tentez de citer n\'est pas de vous ou n\'existe pas, retournez en arrière et réessayez.';
$txt['mangled_post'] = 'Données du formulaire erronées - veuillez retourner à la page précédente et réessayer.';
$txt['too_many_groups'] = 'Désolé, vous avez sélectionné trop de groupes, veuillez en sélectionner moins.';
$txt['post_upload_error'] = 'Les données de publication sont manquantes. Cette erreur peut être provoquée en essayant de soumettre un fichier plus volumineux que celui autorisé par le serveur. Veuillez contacter votre administrateur si ce problème persiste.';
$txt['quoted_post_deleted'] = 'Le message que vous essayez de citer, soit n\'existe pas, soit à été supprimé, ou n\'est plus accessible pour vous.';
$txt['pm_too_many_per_hour'] = 'Vous avez dépassé la limite de %1$d messages personnels par heure.';
$txt['labels_too_many'] = 'Désolé, %1$s messages ont déjà le nombre maximal d\'étiquettes permis !';

$txt['register_only_once'] = 'Désolé, mais vous ne pouvez pas inscrire plus d\'un compte en même temps depuis le même ordinateur.';
$txt['admin_setting_coppa_require_contact'] = 'Si l\'approbation d\'un parent/tuteur est requise, vous devez entrer un moyen de contact soit postal, soit par fax.';

$txt['error_long_name'] = 'Le pseudonyme que vous avez tenté d\'utiliser est trop long.';
$txt['error_no_name'] = 'Aucun pseudonyme n\'a été fourni.';
$txt['error_bad_name'] = 'Ce pseudonyme ne peut être utilisé, car c\'est un mot réservé, ou il contient un mot réservé.';
$txt['error_no_email'] = 'Aucune adresse e-mail n\'a été indiquée.';
$txt['error_bad_email'] = 'Une adresse e-mail invalide a été indiquée.';
$txt['error_email'] = 'Adresse de courriel';
$txt['error_message'] = 'message';
$txt['error_no_event'] = 'Aucun nom d\'événement n\'a été donné.';
$txt['error_no_subject'] = 'Aucun titre de sujet n\'a été indiqué.';
$txt['error_no_question'] = 'Aucune question n\'a été posée pour ce sondage.';
$txt['error_no_message'] = 'Le corps du message est vide.';
$txt['error_long_message'] = 'Le message dépasse la limite de caractères autorisée (%1$d caractères permis).';
$txt['error_no_comment'] = 'Le champ de commentaire est vide.';
$txt['error_post_too_long'] = 'Votre message est trop long. Veuillez saisir un maximum de 255 caractères.';
$txt['error_session_timeout'] = 'Votre session s\'est terminée alors que vous postiez. Veuillez tenter de resoumettre votre message.';
$txt['error_no_to'] = 'Aucun destinataire spécifié.';
$txt['error_bad_to'] = 'Un ou plusieurs destinataires \'À\' n\'ont pu être trouvés.';
$txt['error_bad_bcc'] = 'Un ou plusieurs destinataires \'Bcc\' n\'ont pu être trouvés.';
$txt['error_form_already_submitted'] = 'Vous avez déjà envoyé ce message ! Vous avez peut-être accidentellement double-cliqué ou actualisé la page.';
$txt['error_poll_few'] = 'Vous devez avoir au moins deux (2) choix !';
$txt['error_poll_many'] = 'Vous ne devez pas avoir plus de 256 choix.';
$txt['error_need_qr_verification'] = 'Merci de remplir le formulaire de vérification ci-dessous avant d\'envoyer votre message.';
$txt['error_wrong_verification_code'] = 'Les lettres que vous avez tapées ne correspondent pas aux lettres montrées sur l\'image.';
$txt['error_wrong_verification_answer'] = 'Vous n\'avez pas répondu aux questions de vérification correctement.';
$txt['error_need_verification_code'] = 'Veuillez entrer le code de vérification ci-dessous pour passer aux résultats.';
$txt['error_bad_file'] = 'Désolé, mais le fichier spécifié n\'a pas pu être ouvert : %1$s';
$txt['error_bad_line'] = 'La ligne indiquée est invalide.';
$txt['error_draft_not_saved'] = 'Une erreur s\'est produite lors de l\'enregistrement du brouillon';
$txt['error_name_in_use'] = 'Le nom %1$s est déjà utilisé par un autre membre.';

$txt['smiley_not_found'] = 'Smiley introuvable.';
$txt['smiley_has_no_code'] = 'Aucun code pour ce smiley n\'a été donné.';
$txt['smiley_has_no_filename'] = 'Aucun nom de fichier pour ce smiley n\'a été donné.';
$txt['smiley_not_unique'] = 'Une émoticône ayant ce code existe déjà.';
$txt['smiley_set_already_exists'] = 'Un jeu d\'émoticônes ayant cette URL existe déjà.';
$txt['smiley_set_not_found'] = 'Jeu d\'émoticônes introuvable.';
$txt['smiley_set_dir_not_found'] = 'Le répertoire du jeu de smileys %1$s est soit invalide, soit inaccessible';
$txt['smiley_set_path_already_used'] = 'L\'adresse de ce jeu d\'émoticônes est déjà utilisée par un autre jeu.';
$txt['smiley_set_unable_to_import'] = 'Impossible d\'importer le jeu de smileys. Le répertoire est soit invalide, soit interdit d\'accès.';

$txt['smileys_upload_error'] = 'Échec lors du chargement du fichier.';
$txt['smileys_upload_error_blank'] = 'Tous les ensembles de smileys doivent avoir une image.';
$txt['smileys_upload_error_name'] = 'Tous les smileys doivent avoir le même nom de fichier.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Format d\'image interdit.';

$txt['search_invalid_weights'] = 'Les pondérations de recherche ne sont pas configurées correctement. Au moins un poids doit être configuré pour être différent de zéro. Veuillez signaler cette erreur à un administrateur.';

$txt['package_no_file'] = 'Impossible de trouver le fichier du paquet !';
$txt['packageget_unable'] = 'Impossible de se connecter au serveur. Veuillez réessayer en utilisant plutôt <a href="%1$s" target="_blank" class="new_win">cette URL</a>.';
$txt['not_valid_server'] = 'Désolé, les packages ne peuvent être téléchargés de cette manière qu\'à partir de serveurs que vous avez préalablement autorisés.';
$txt['package_cant_uninstall'] = 'Ce paquet n\'a jamais été installé ou a déjà été désinstallé - vous ne pouvez pas le désinstaller maintenant.';
$txt['package_cant_download'] = 'Vous ne pouvez pas télécharger ou installer de nouveaux packages car &quot;packages&quot; le répertoire ou l\'un des fichiers qu\'il contient ne sont pas accessibles en écriture !';
$txt['package_upload_error_nofile'] = 'Vous n\'avez pas choisi de paquet à envoyer.';
$txt['package_upload_error_failed'] = 'Échec d\'envoi du paquet. Veuillez vérifier les droits d\'accès du répertoire !';
$txt['package_upload_error_exists'] = 'Le fichier que vous téléchargez existe déjà sur le serveur. Veuillez d\'abord le supprimer, puis réessayer.';
$txt['package_upload_already_exists'] = 'Le package que vous essayez de télécharger existe déjà sur le serveur sous le nom de fichier : %1$s';
$txt['package_upload_error_supports'] = 'Le gestionnaire de paquets permet actuellement uniquement ces types de fichier : %1$s.';
$txt['package_upload_error_broken'] = 'Le paquet n\'a pas pu être téléchargé pour la raison suivante : <br />"%1$s"';

$txt['package_get_error_not_found'] = 'Le package que vous essayez d\'installer est introuvable. Vous souhaiterez peut-être le télécharger manuellement dans votre dossier &quot;packages&quot;.';
$txt['package_get_error_missing_xml'] = 'Le fichier package-info.xml est introuvable dans le paquet que vous essayez d\'installer. Il doit se trouver à la racine du répertoire du paquet.';
$txt['package_get_error_is_zero'] = 'Bien que le package ait été téléchargé sur le serveur, il semble être vide. Veuillez vérifier que le dossier &quot;packages&quot; et le sous-dossier &quot;temp&quot; sont tous les deux accessibles en écriture. Si vous continuez à rencontrer ce problème, vous devriez essayer d\'extraire le package sur votre PC et de télécharger les fichiers extraits dans un sous-répertoire de votre dossier &quot;packages&quot; et réessayez. Par exemple, si le package s\'appelait shout.tar.gz, vous devez : 1) Télécharger le package sur votre PC local et extraire ses fichiers 2) Créer un nouveau répertoire dans votre dossier &quot;packages&quot; en utilisant un client FTP, dans cet exemple, vous pouvez l\'appeler "shout" 3) Téléchargez tous les fichiers du package extrait dans ce répertoire 4) Revenez à la page de navigation du gestionnaire de packages. Le package sera automatiquement trouvé.';
$txt['package_get_error_packageinfo_corrupt'] = 'Impossible de trouver des informations valides dans le fichier package-info.xml inclus dans le package. Il peut y avoir une erreur dans le module ou le package est peut-être corrompu.';
$txt['package_get_error_is_theme'] = 'Vous ne pouvez pas installer un thème à partir de cette section, veuillez utiliser la page <a href="{MANAGETHEMEURL}">Gestion des thèmes</a> pour le télécharger';

$txt['no_membergroup_selected'] = 'Aucun groupe de membres sélectionné';
$txt['membergroup_does_not_exist'] = 'Le groupe de membres n\'existe pas ou n\'est pas valide.';

$txt['at_least_one_admin'] = 'Il doit y avoir au moins un administrateur sur ce forum !';

$txt['error_functionality_not_windows'] = 'Désolé, cette fonctionnalité n\'est actuellement pas disponible pour les serveurs tournant sous Windows.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Fichier joint introuvable';

$txt['error_no_boards_selected'] = 'Aucune section valide n\'a été sélectionnée.';
$txt['error_invalid_search_string'] = 'Avez-vous oublié de saisir quelque chose à rechercher ?';
$txt['error_invalid_search_string_blacklist'] = 'Votre requête de recherche contenait des mots triviaux. Veuillez réessayer avec une autre requête.';
$txt['error_search_string_small_words'] = 'Chaque mot doit faire au moins deux caractères de long.';
$txt['error_query_not_specific_enough'] = 'Votre requête n\'est pas assez précise. Essayez de nouveau avec des mots ou des phrases moins vagues.';
$txt['error_no_messages_in_time_frame'] = 'Aucun message trouvé dans cet intervalle de temps.';
$txt['error_no_labels_selected'] = 'Aucun libellé n\'a été sélectionné.';
$txt['error_no_search_daemon'] = 'Impossible d\'accéder au processus de recherche';

$txt['profile_errors_occurred'] = 'Les erreurs suivantes se sont produites lors de la tentative de mise à jour de votre profil';
$txt['profile_error_bad_offset'] = 'Le décalage horaire est hors normes';
$txt['profile_error_no_name'] = 'Le pseudonyme est resté vide';
$txt['profile_error_digits_only'] = 'La case "nombre de messages" ne peut contenir que des chiffres.';
$txt['profile_error_name_taken'] = 'Le nom d\'utilisateur / le nom d\'affichage sélectionné est déjà utilisé';
$txt['profile_error_name_too_long'] = 'Le nom sélectionné est trop long. Il ne doit pas faire plus de 60 caractères';
$txt['profile_error_no_email'] = 'Le champ d\'adresse de courriel est resté vide';
$txt['profile_error_bad_email'] = 'Vous n\'avez pas spécifié une adresse de courriel valide';
$txt['profile_error_email_taken'] = 'Un autre utilisateur s\'est déjà inscrit avec cette adresse de courriel';
$txt['profile_error_no_password'] = 'Vous n\'avez pas entré votre mot de passe';
$txt['profile_error_bad_new_password'] = 'Les nouveaux mots de passe que vous avez entrés ne correspondent pas';
$txt['profile_error_bad_password'] = 'Le mot de passe que vous avez entré est incorrect';
$txt['profile_error_bad_avatar'] = 'L\'avatar que vous avez choisi est trop grand ou n\'est pas un avatar';
$txt['profile_error_password_short'] = 'Votre mot de passe doit comporter au moins %1$s caractères.';
$txt['profile_error_password_restricted_words'] = 'Votre mot de passe ne doit pas contenir votre nom d\'utilisateur, votre adresse de courriel ou d\'autres mots couramment utilisés.';
$txt['profile_error_password_chars'] = 'Votre mot de passe doit contenir un mélange de lettres majuscules et minuscules, de même que des numéros.';
$txt['profile_error_already_requested_group'] = 'Vous avez déjà une demande en instance pour ce groupe !';
$txt['profile_error_openid_in_use'] = 'Un autre membre utilise déjà cette URL d\'authentification OpenID';
$txt['profile_error_signature_not_yet_saved'] = 'La signature n\'a pas été enregistrée.';
$txt['profile_error_personal_text_too_long'] = 'Le texte personnel est trop long.';
$txt['profile_error_user_title_too_long'] = 'Le titre personnalisé est trop long.';

$txt['mysql_error_space'] = ' - vérifiez la taille de votre base de données ou contactez un administrateur du serveur.';

$txt['icon_not_found'] = 'L\'icône de message n\'a pu être trouvée pour le thème par défaut - veuillez vous assurer que l\'image a bien été transférée et essayez de nouveau.';
$txt['icon_after_itself'] = 'L\'icône ne peut pas être positionnée après elle-même.';
$txt['icon_name_too_long'] = 'Les noms de fichiers d\'icônes ne peuvent pas comporter plus de 16 caractères';

$txt['name_censored'] = 'Désolé, le nom que vous tentez d\'utiliser, %1$s, contient des mots qui ont été censurés. Veuillez en choisir un autre.';

$txt['poll_already_exists'] = 'Un sujet ne peut être associé qu\'à un seul sondage.';
$txt['poll_not_found'] = 'Il n\'y a aucun sondage associé à ce sujet !';

$txt['error_while_adding_poll'] = 'L\'erreur ou les erreurs suivantes sont apparues lorsque vous ajoutiez ce sondage';
$txt['error_while_editing_poll'] = 'L\'erreur ou les erreurs suivantes sont apparues lorsque vous modifiez ce sondage';

$txt['loadavg_search_disabled'] = 'Dû à une charge élevée sur le serveur, la fonction de recherche a été automatiquement et temporairement désactivée. Réessayez un peu plus tard.';
$txt['loadavg_generic_disabled'] = 'Dû à une charge élevée sur le serveur, cette fonction est actuellement indisponible.';
$txt['loadavg_allunread_disabled'] = 'Les ressources du serveur sont temporairement trop sollicitées pour trouver tous les sujets que vous n\'avez pas lus.';
$txt['loadavg_unreadreplies_disabled'] = 'Le serveur est actuellement sous une charge élevée.  Veuillez essayer de nouveau dans quelques instants.';
$txt['loadavg_show_posts_disabled'] = 'Réessayer à nouveau plus tard.  Les messages de ce membre ce sont pas disponibles actuellement du fait d\'une surcharge du serveur.';
$txt['loadavg_unread_disabled'] = 'Les ressources du serveur sont temporairement trop sollicitées pour lister les sujets que vous n\'avez pas lus.';
$txt['loadavg_userstats_disabled'] = 'Veuillez réessayer plus tard. Les statistiques de ce membre ne sont actuellement pas disponibles en raison de la charge élevée sur le serveur.';

$txt['cannot_edit_permissions_inherited'] = 'Vous ne pouvez pas modifier directement les autorisations héritées, vous devez soit modifier le groupe parent, soit modifier l\'héritage du groupe de membres.';

$txt['mc_no_modreport_specified'] = 'Vous devez spécifier quel rapport vous voulez voir.';
$txt['mc_no_modreport_found'] = 'Le rapport spécifié n\'existe pas, ou il est hors de portée pour vous';

$txt['st_cannot_retrieve_file'] = 'Impossible de récupérer le fichier %1$s.';
$txt['admin_file_not_found'] = 'Impossible de charger le fichier demandé&nbsp;: %1$s.';

$txt['themes_none_selectable'] = 'Au moins un thème doit pouvoir être sélectionné.';
$txt['themes_default_selectable'] = 'Le thème par défaut global du forum doit être un thème sélectionnable.';
$txt['ignoreboards_disallowed'] = 'L\'option pour ignorer les sections n\'a pas été activée.';

$txt['mboards_delete_error'] = 'Aucune catégorie sélectionnée.';
$txt['mboards_delete_board_error'] = 'Aucune section sélectionnée.';
$txt['mboards_delete_board_has_posts'] = 'La section sélectionnée a toujours des messages et / ou des sujets.';

$txt['mboards_parent_own_child_error'] = 'Vous ne pouvez pas faire d\'un parent son propre enfant.';
$txt['mboards_board_own_child_error'] = 'Vous ne pouvez pas faire d\'une section son propre enfant.';

$txt['smileys_upload_error_notwritable'] = 'Les répertoires d\'émoticônes suivants ne sont pas inscriptibles : %1$s';
$txt['smileys_upload_error_types'] = 'Les fichiers des émoticônes sont limités à ces extensions : %1$s.';

$txt['change_email_success'] = 'Votre adresse de courriel a été changée, et un nouveau courriel d\'activation a été envoyé.';
$txt['resend_email_success'] = 'Le courriel d\'activation a été renvoyé avec succès.';

$txt['custom_option_need_name'] = 'L\'option de profil doit avoir un nom.';
$txt['custom_option_not_unique'] = 'Le nom du champ n\'est pas unique.';
$txt['custom_option_regex_error'] = 'L\'expression régulière que vous avez entrée n\'est pas valide';

$txt['warning_no_reason'] = 'Vous devez entrer une raison pour modifier l\'état d\'avertissement d\'un membre.';
$txt['warning_notify_blank'] = 'Vous avez choisi de notifier l\'utilisateur, mais vous n\'avez pas rempli les champs de titre/message.';

$txt['cannot_connect_doc_site'] = 'Impossible de se connecter au site de documentation. Veuillez vérifier que la configuration de votre serveur autorise les connexions Internet externes et réessayer plus tard.';

$txt['movetopic_no_reason'] = 'Vous devez préciser une raison pour le déplacement du sujet, ou désactiver l\'option \'Poster un message de redirection\'.';
$txt['movetopic_no_board'] = 'Vous devez choisir une section vers laquelle déplacer le sujet.';

$txt['splittopic_no_reason'] = 'Vous devez entrer un motif pour la division du sujet ou décocher l\'option «publier un message de redirection».';

// OpenID error strings
$txt['openid_server_bad_response'] = 'L\'identifiant demandé n\'a pas retourné l\'information attendue.';
$txt['openid_return_no_mode'] = 'Le fournisseur d\'identité n\'a pas répondu avec le mode OpenID.';
$txt['openid_not_resolved'] = 'Le fournisseur d\'identité n\'a pas appouvé votre demande.';
$txt['openid_no_assoc'] = 'Impossible de trouver l\'association demandée avec le fournisseur d\'identité.';
$txt['openid_sig_invalid'] = 'La signature du fournisseur d\'identité est invalide.';
$txt['openid_load_data'] = 'Impossible de charger les données à partir de votre requête de connexion. Veuillez réessayer.';
$txt['openid_not_verified'] = 'L\'OpenID fournie n\'a pas encore été vérifiée. Veuillez vous connecter pour vérifier.';

$txt['error_custom_field_too_long'] = 'Le champ &quot;%1$s&quot; ne peut faire plus de %2$d caractères.';
$txt['error_custom_field_invalid_email'] = 'Le champ "%1$s" doit être une adresse de courriel valide.';
$txt['error_custom_field_not_number'] = 'Le champ "%1$s" doit être un nombre.';
$txt['error_custom_field_inproper_format'] = 'Le format du champ "%1$s" est invalide.';
$txt['error_custom_field_empty'] = 'Le champ "%1$s" ne peut être laissé vide.';

$txt['email_no_template'] = 'Le modèle de courriel "%1$s" est introuvable.';

$txt['search_api_missing'] = 'L\'API de recherche est introuvable. Veuillez contacter l\'administrateur pour vérifier qu\'il a téléchargé les bons fichiers.';
$txt['search_api_not_compatible'] = 'L\'API de recherche sélectionnée utilisée par le forum est obsolète - revenant à la recherche standard. Veuillez vérifier le fichier %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Vous ne pouvez restaurer le premier message d\'un sujet.';
$txt['restored_disabled'] = 'La restauration de sujets a été désactivée.';
$txt['restore_not_found'] = 'Les messages suivants n\'ont pas pu être restaurés ; le sujet d\'origine a peut-être été supprimé : %1$s Vous devrez les déplacer manuellement.';

$txt['error_invalid_dir'] = 'Le répertoire que vous avez spécifié est invalide.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'La sous-action que vous avez demandée n\'est pas définie';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'Aucun élément triable n\'a été trouvé';

$txt['error_invalid_notification_id'] = 'Une extension tente d\'enregistrer une méthode de notification avec un ID existant. Les identifiants inférieurs à 5 sont protégés et ne peuvent pas être utilisés par des modules. Si l\'ID est plus élevé, deux modules utilisent peut-être le même ID.';
