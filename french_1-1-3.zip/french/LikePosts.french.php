<?php
// Version: 1.1; LikePosts

global $txt;

// Like posts stats strings
$txt['like_posts_stats_desc'] = 'Statistiques relatives aux articles et sujets Aimés';
$txt['like_post_tab_mlm'] = 'Messages les plus Aimés';
$txt['like_post_tab_mlt'] = 'Sujets les plus Aimés';
$txt['like_post_tab_mlb'] = 'Sections les plus Aimées';
$txt['like_post_tab_mlmember'] = 'Membres avec le plus de J\'aime';
$txt['like_post_tab_mlgmember'] = 'Membres donnant le plus de J\'aime';
$txt['like_post_generic_heading1'] = 'J\'aime(s)';
$txt['like_post_liked_by_others'] = 'J\'aime reçus';
$txt['like_post_show'] = 'Afficher';
$txt['like_post_hide'] = 'Cacher';

// For message
$txt['like_post_users_who_liked'] = '%1% utilisateurs ont Aimé ce message';

// For topic
$txt['like_post_most_popular_topic_heading1'] = 'a reçu un total de (%1%) J\'aime(s)';
$txt['like_post_most_popular_topic_sub_heading1'] = 'Le sujet contient (%1%) messages Aimés. Soit %2% des messages aimés du forum. ';

// For board
$txt['like_post_most_popular_board_heading1'] = 'a reçu ';
$txt['like_post_most_popular_board_sub_heading1'] = 'La section contient ';
$txt['like_post_most_popular_board_sub_heading2'] = 'sujets, dont ';
$txt['like_post_most_popular_board_sub_heading3'] = 'sujets sont Aimés.';
$txt['like_post_most_popular_board_sub_heading4'] = 'Les sujets contiennent ';
$txt['like_post_most_popular_board_sub_heading5'] = 'différents messages, dont ';
$txt['like_post_most_popular_board_sub_heading6'] = 'messages sont Aimés. ';

// Most liked user
$txt['like_post_total_likes_received'] = 'Total des mentions J\'aime reçues ';
$txt['like_post_most_popular_user_heading1'] = '%1% messages les plus appréciés de ces utilisateurs ';

// Most like giving user
$txt['like_post_total_likes_given'] = 'Total de mentions J\'aime données ';
$txt['like_post_most_like_given_user_heading1'] = '%1% messages récemment Aimés de cet utilisateur ';

// Like posts generic strings
$txt['like_post_topic'] = 'Sujet';
$txt['like_post_message'] = 'Message';
$txt['like_post_board'] = 'Section';
$txt['like_post_total_posts'] = 'Total des messages ';
$txt['like_post_posted_at'] = 'Publié à ';
$txt['like_post_read_more'] = 'Lire la suite... ';

// Error msgs
$txt['like_post_error_no_data'] = 'Désolé, il semble qu\'il n\'y ait encore rien à afficher ! ';
$txt['like_post_error_something_wrong'] = 'Désolé, il semble qu\'un problème soit survenu lors de la récupération des données... ';
