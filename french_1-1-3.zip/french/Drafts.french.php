<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Afficher les brouillons';
$txt['drafts_show_desc'] = 'Cet espace affiche tous les brouillons que vous avez actuellement enregistrés. Ici vous pouvez les modifier avant de les envoyer ou bien les supprimer.';

// misc
$txt['drafts'] = 'Brouillons';
$txt['draft_save'] = 'Enregistrer le brouillon';
$txt['draft_save_note'] = 'Cela va enregistrer le texte de votre message, mais pas les fichiers joints, le sondage ou les information d\'évènement.';
$txt['draft_none'] = 'Vous n\'avez pas de brouillons.';
$txt['draft_edit'] = 'Modifier le brouillon';
$txt['draft_load'] = 'Afficher les brouillons';
$txt['draft_hide'] = 'Cacher les brouillons';
$txt['draft_delete'] = 'Supprimer le brouillon';
$txt['draft_days_ago'] = 'Il y a %s jours';
$txt['draft_retain'] = 'cela sera conservé %s jours supplémentaires';
$txt['draft_remove'] = 'Supprimer ce brouillon';
$txt['draft_remove_selected'] = 'Supprimer tous les brouillons sélectionnés ?';
$txt['draft_saved'] = 'Les contenus ont été enregistrés en tant que brouillon et seront accessibles à partir de <a href="%1$s">Afficher l\'espace Brouillons</a> de votre profil.';
$txt['draft_pm_saved'] = 'Les contenus ont été enregistrés en tant que brouillon et seront accessibles à partir de <a href="%1$s">Afficher l\'espace Brouillons</a> de votre messagerie.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Activer l\'enregistrement automatique des brouillons';
$txt['drafts_autosave_enabled_subnote'] = 'Cela enregistrera automatiquement les brouillons de l\'utilisateur en arrière plan selon une fréquence déterminée. L\'utilisateur doit disposer des permissions adéquates';
$txt['drafts_keep_days'] = 'Nombre maximum de jours de conservation d\'un brouillon.';
$txt['drafts_keep_days_subnote'] = 'Saisir 0 pour conserver le brouillon indéfiniment';
$txt['drafts_autosave_frequency'] = 'Les brouillons doivent être enregistrés automatiquement tous les combien ?';
$txt['drafts_autosave_frequency_subnote'] = 'La valeur minimale autorisée est 30 secondes';
$txt['drafts_pm_enabled'] = 'Activer l\'enregistrement des brouillons des messages personels';
$txt['drafts_post_enabled'] = 'Activer l\'enregistrement des brouillons des messages';
$txt['drafts_none'] = 'Pas de titre';
$txt['drafts_saved'] = 'Le brouillon a été enregistré avec succès';