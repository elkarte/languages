<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Accueil des messages personnels';
$txt['pm_add'] = 'Ajouter';
$txt['make_bcc'] = 'Ajouter un BCC';
$txt['pm_to'] = 'à';
$txt['pm_bcc'] = 'Bcc';
$txt['inbox'] = 'Boîte de réception';
$txt['conversation'] = 'Conversation';
$txt['messages'] = 'Messages';
$txt['sent_items'] = 'Messages envoyés';
$txt['new_message'] = 'Nouveau message';
$txt['delete_message'] = 'Effacer des messages';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Effacer tous les messages dans votre boîte de réception';
$txt['delete_all_confirm'] = 'Êtes vous sûr de vouloir effacer tous les messages ?';

$txt['delete_selected_confirm'] = 'Êtes-vous sûr de vouloir effacer tous les messages personnels sélectionnés ?';

$txt['sent_to'] = 'Envoyé à';
$txt['reply_to_all'] = 'Répondre à tous';
$txt['delete_conversation'] = 'Supprimer Conversation';

$txt['pm_capacity'] = 'Capacité';
$txt['pm_currently_using'] = '%1$s messages, %2$s%% pleine.';
$txt['pm_sent'] = 'Votre message a été envoyé.';

$txt['pm_error_user_not_found'] = 'Impossible de trouver le membre "%1$s".';
$txt['pm_error_ignored_by_user'] = 'Le membre "%1$s" a bloqué votre message personnel.';
$txt['pm_error_data_limit_reached'] = 'Le message n\'a pas pu être envoyé à "%1$s" car sa boîte de réception est pleine !';
$txt['pm_error_user_cannot_read'] = 'L\'utilisateur "%1$s" ne peut pas recevoir de messages personnels.';
$txt['pm_successfully_sent'] = 'Le message a été envoyé à "%1$s".';
$txt['pm_send_report'] = 'Rapport d\'envoi';
$txt['pm_undisclosed_recipients'] = 'Destinataires non révélés';
$txt['pm_too_many_recipients'] = 'Vous ne pouvez pas envoyer de messages personnels à plus de %1$d destinataire(s) à la fois.';

$txt['pm_read'] = 'Lu';
$txt['pm_replied'] = 'Répondu à';
$txt['pm_mark_unread'] = 'Marquer comme non lu';

// Message Pruning.
$txt['pm_prune'] = 'Délester les messages';
$txt['pm_prune_desc'] = 'Supprimer tous les messages personnels datant de plus de %1$s jours.';
$txt['pm_prune_warning'] = 'Êtes-vous certain de vouloir purger votre boîte&nbsp;?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Actions supplémentaires';
$txt['pm_actions_delete_selected'] = 'Effacer la sélection';
$txt['pm_actions_filter_by_label'] = 'Filtrer par intitulé';
$txt['pm_actions_go'] = 'Aller';

// Manage Labels Screen.
$txt['pm_apply'] = 'Appliquer';
$txt['pm_manage_labels'] = 'Gérer les intitulés';
$txt['pm_labels_delete'] = 'Êtes-vous sûr de vouloir effacer les libellés sélectionnés ?';
$txt['pm_labels_desc'] = 'Ici vous pouvez ajouter, modifier et supprimer les labels utilisés dans votre centre de messagerie personnelle.';
$txt['pm_label_add_new'] = 'Ajouter un nouvel intitulé';
$txt['pm_label_name'] = 'Nom de l\'intitulé';
$txt['pm_labels_no_exist'] = 'Vous n\'avez actuellement aucun label paramétré !';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Libellé';
$txt['pm_msg_label_title'] = 'Message de l\'étiquette';
$txt['pm_msg_label_apply'] = 'Ajouter une étiquette';
$txt['pm_msg_label_remove'] = 'Supprimer une étiquette';
$txt['pm_msg_label_inbox'] = 'Boîte de réception';
$txt['pm_sel_label_title'] = 'Étiquettes sélectionnées';

// Sidebar Headings.
$txt['pm_labels'] = 'Libellés';
$txt['pm_messages'] = 'Messages';
$txt['pm_actions'] = 'Actions';
$txt['pm_preferences'] = 'Préférences';

$txt['pm_is_replied_to'] = 'Vous avez transféré ou répondu à ce message.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Signaler à un administrateur';
$txt['pm_report_title'] = 'Signaler un message personnel';
$txt['pm_report_desc'] = 'Depuis cette page vous pouvez rapporter le message personnel que vous avez reçu à l\'équipe d\'administration du forum. Veuillez vous assurer d\'inclure une description de la raison de ce rapport de message, puisque ça sera envoyé avec le contenu du message original.';
$txt['pm_report_admins'] = 'Administrateur à aviser';
$txt['pm_report_all_admins'] = 'Envoyer à tous les administrateurs';
$txt['pm_report_reason'] = 'Raison du signalement de ce message';
$txt['pm_report_message'] = 'Rapporter le message';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[SIGNALEMENT] ';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} a signalé le message personnel suivant, envoyé par {SENDER}, pour la raison suivante :';
$txt['pm_report_pm_other_recipients'] = 'Les autres destinataires de ce message sont :';
$txt['pm_report_pm_hidden'] = '%1$d destinataire(s) caché(s)';
$txt['pm_report_pm_unedited_below'] = 'Ci-dessous se trouve le contenu original du message personnel signalé :';
$txt['pm_report_pm_sent'] = 'Envoyé :';

$txt['pm_report_done'] = 'Merci d\'avoir soumis ce signalement. Vous devriez recevoir des nouvelles des administrateurs rapidement.';
$txt['pm_report_return'] = 'Retourner à la boîte de réception';

$txt['pm_search_title'] = 'Rechercher dans la boîte de messages personnels';
$txt['pm_search_bar_title'] = 'Rechercher des messages';
$txt['pm_search_text'] = 'Chercher pour';
$txt['pm_search_go'] = 'Recherche';
$txt['pm_search_advanced'] = 'Afficher les options avancées';
$txt['pm_search_simple'] = 'Cacher les options avancées';
$txt['pm_search_user'] = 'Par utilisateur';
$txt['pm_search_match_all'] = 'Correspondre tous les mots';
$txt['pm_search_match_any'] = 'Correspondre n\'importe quel mot';
$txt['pm_search_options'] = 'Options';
$txt['pm_search_post_age'] = 'Âge du message';
$txt['pm_search_show_complete'] = 'Montrer tout le message dans les résultats.';
$txt['pm_search_subject_only'] = 'Chercher par titre et auteur seulement.';
$txt['pm_search_sent_only'] = 'Chercher uniquement dans les messages envoyés';
$txt['pm_search_between'] = 'entre';
$txt['pm_search_between_and'] = 'et';
$txt['pm_search_between_days'] = 'jours';
$txt['pm_search_order'] = 'Ordre de recherche';
$txt['pm_search_choose_label'] = 'Choisir les intitulés à rechercher, ou rechercher partout';

$txt['pm_search_results'] = 'Résultats de la recherche';
$txt['pm_search_none_found'] = 'Aucun Message Trouvé';

$txt['pm_search_orderby_relevant_first'] = 'Plus significatif en premier';
$txt['pm_search_orderby_recent_first'] = 'Plus récent en premier';
$txt['pm_search_orderby_old_first'] = 'Plus ancien en premier';

$txt['pm_visual_verification_label'] = 'Vérification';
$txt['pm_visual_verification_desc'] = 'Veuillez saisir le code contenu dans l\'image ci-dessus pour envoyer ce message privé.';

$txt['pm_settings'] = 'Modifier les paramètres';
$txt['pm_change_view'] = 'Modifier l\'affichage';

$txt['pm_manage_rules'] = 'Gérer les règles';
$txt['pm_manage_rules_desc'] = 'Les règles de message vous permettent de traiter automatiquement les messages personnels inconnus selon des critères que vous aurez définis. Ci-dessous, la liste des règles que vous avez actuellement. Pour modifier une règle, cliquez simplement sur son nom.';
$txt['pm_rules_none'] = 'Vous n\'avez pas encore créé de règle de message.';
$txt['pm_rule_title'] = 'Règle';
$txt['pm_add_rule'] = 'Ajouter une nouvelle règle';
$txt['pm_apply_rules'] = 'Appliquer les règles maintenant';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Etes-vous sûr de vouloir appliquer les règles actuelles à tous les messages personnels&nbsp;?';
$txt['pm_edit_rule'] = 'Modifier la règle';
$txt['pm_rule_save'] = 'Sauvegarder la règle';
$txt['pm_delete_selected_rule'] = 'Effacer les règles sélectionnées';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Etes-vous sûr de vouloir effacer les règles sélectionnées&nbsp;?';
$txt['pm_rule_name'] = 'Nom';
$txt['pm_rule_name_desc'] = 'Le nom de la règle, pour s\'en souvenir plus facilement';
$txt['pm_rule_name_default'] = '[NOM]';
$txt['pm_rule_description'] = 'Description';
$txt['pm_rule_not_defined'] = 'Ajoutez un critère pour commencer à mettre en place la description de cette règle.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>Attention</strong>, il semblerait que Javascript soit désactivé. Nous vous recommandons fortement d\'activer Javascript pour utiliser cette fonctionnalité.</span>';
$txt['pm_rule_criteria'] = 'Critères';
$txt['pm_rule_criteria_add'] = 'Ajouter un critère';
$txt['pm_rule_criteria_pick'] = 'Choisissez un critère';
$txt['pm_rule_mid'] = 'Nom de l\'expéditeur';
$txt['pm_rule_gid'] = 'Groupe de l\'expéditeur';
$txt['pm_rule_sub'] = 'Le titre du message contient';
$txt['pm_rule_msg'] = 'Le corps du message contient';
$txt['pm_rule_bud'] = 'L\'expéditeur est un ami';
$txt['pm_rule_sel_group'] = 'Sélectionner un groupe';
$txt['pm_rule_logic'] = 'Lors de la vérification des critères';
$txt['pm_rule_logic_and'] = 'Tous les critères doivent être satisfaits';
$txt['pm_rule_logic_or'] = 'Au moins un critère doit être satisfait';
$txt['pm_rule_actions'] = 'Actions';
$txt['pm_rule_sel_action'] = 'Choisissez une action';
$txt['pm_rule_add_action'] = 'Ajouter une action';
$txt['pm_rule_label'] = 'Intitulé du message avec';
$txt['pm_rule_sel_label'] = 'Choisissez l\'intitulé';
$txt['pm_rule_delete'] = 'Effacer le Message';
$txt['pm_rule_no_name'] = 'Vous avez oublié d\'entrer un nom pour la règle.';
$txt['pm_rule_no_criteria'] = 'Une règle doit avoir au moins un critère et une action.';
$txt['pm_rule_too_complex'] = 'La règle que vous êtes en train de créer est trop longue à enregistrer. Essayez de la diviser en règles plus petites.';

$txt['pm_readable_and'] = '<em>et</em>';
$txt['pm_readable_or'] = '<em>ou</em>';
$txt['pm_readable_start'] = 'Si ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'message vient de "{MEMBER}"';
$txt['pm_readable_group'] = 'l\'expéditeur est du groupe "{GROUP}"';
$txt['pm_readable_subject'] = 'le titre du message est "{SUBJECT}"';
$txt['pm_readable_body'] = 'le corps du message est "{BODY}"';
$txt['pm_readable_buddy'] = 'l\'expéditeur est un ami';
$txt['pm_readable_label'] = 'appliquer l\'intitulé "{LABEL}"';
$txt['pm_readable_delete'] = 'effacer le message';
$txt['pm_readable_then'] = '<strong>puis</strong>';