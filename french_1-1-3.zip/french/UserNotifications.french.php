<?php
// Version: 1.1; UserNotifications

$txt['usernotif_title'] = 'Paramètres des notifications aux utilisateurs';
$txt['usernotif_desktop_enable'] = 'Activer les notifications sur le bureau';
$txt['usernotif_favicon_enable'] = 'Activer le nombre de notifications dans l\'icône favorite';

$txt['usernotif_favicon_position'] = 'Emplacement des notifications : ';
$txt['usernotif_favicon_up'] = 'En haut à droite';
$txt['usernotif_favicon_down'] = 'En bas à droite';
$txt['usernotif_favicon_left'] = 'En bas à gauche';
$txt['usernotif_favicon_upleft'] = 'En haut à gauche';

$txt['usernotif_favicon_bgColor'] = 'Couleur d\'arrière plan : ';
$txt['usernotif_favicon_textColor'] = 'Couleur du texte : ';

$txt['usernotif_favicon_fontStyle'] = 'Style de police : ';
$txt['usernotif_favicon_style_normal'] = 'Normale';
$txt['usernotif_favicon_style_italic'] = 'Italique';
$txt['usernotif_favicon_style_oblique'] = 'Oblique';
$txt['usernotif_favicon_style_bold'] = 'Gras';
$txt['usernotif_favicon_style_bolder'] = 'Plus gras';
$txt['usernotif_favicon_style_lighter'] = 'Plus léger';

$txt['usernotif_favicon_type'] = 'Figure : ';
$txt['usernotif_favicon_shape_circle'] = 'Cercle';
$txt['usernotif_favicon_shape_rectangle'] = 'Rectangle';