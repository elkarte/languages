<?php
// Version: 1.1; Validation

$txt['_validate_required'] = 'Le champ %1$s est requis.';
$txt['_validate_valid_email'] = 'Le champ %1$s doit comprendre une adresse de courriel valide.';
$txt['_validate_max_length'] = 'Le champ %1$s peut comprendre au plus %2$s caractères.';
$txt['_validate_min_length'] = 'Le champ %1$s doit avoir au moins %2$s caractères.';
$txt['_validate_length'] = 'Le champ %1$s doit comprendre exactement %2$s caractères.';
$txt['_validate_alpha'] = 'Le champ %1$s n\'accepte que des lettres.';
$txt['_validate_alpha_numeric'] = 'Le champ %1$s n\'accepte que des lettres et des nombres.';
$txt['_validate_alpha_dash'] = 'Le champ %1$s n\'accepte que des lettres et des tirets.';
$txt['_validate_numeric'] = 'Le champ %1$s devrait être numérique.';
$txt['_validate_integer'] = 'Le champ %1$s n\'accepte qu\'un nombre entier.';
$txt['_validate_boolean'] = 'Le champ %1$s n\'accepte qu\'un bouléen.';
$txt['_validate_float'] = 'Le champ %1$s n\'accepte qu\'un nombre à virgule flottante.';
$txt['_validate_valid_url'] = 'Le champ %1$s doit comprendre une adresse valide.';
$txt['_validate_url_exists'] = 'L\'adresse %1$s n\'existe pas.';
$txt['_validate_valid_ip'] = 'Le champ %1$s doit comprendre une adresse IPv4 valide.';
$txt['_validate_valid_ipv6'] = 'Le champ %1$s doit comprendre une adresse IPv6 valide.';
$txt['_validate_contains'] = 'Le champ %1$s doit comprendre une de ces valeurs %2$s.';
$txt['_validate_invalid_function'] = 'La fonction de validation spécifiée %1$s n\'existe pas.';
$txt['_validate_without'] = 'Le champ %1$s ne peut comprendre le caractère %2$s.';
$txt['_validate_notequal'] = 'Le champ %1$s ne comprend pas une valeur valide.';
$txt['_validate_isarray'] = 'Le champ %1$s ne comprend pas une chaine valide.';
$txt['_validate_php_syntax'] = 'Erreur de syntaxe PHP : %2$s.';
$txt['_validate_limits'] = 'Le champ %1$s comprend une valeur en dehors des limites autorisées %2$s.';
$txt['_validate_generic'] = 'Le champ %1$s contient une valeur invalide.';
$txt['validation_failure'] = 'La ou les erreurs suivante contenues dans le formulaire doivent être corrigées avant de poursuivre : ';