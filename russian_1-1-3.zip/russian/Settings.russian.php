<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Тема по умолчанию ElkArte.<br /><br /> Автор: ElkArte разработчики';