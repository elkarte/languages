<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Zaplanowane zadania';
$txt['scheduled_tasks_header'] = 'Wszystkie zaplanowane zadania';
$txt['scheduled_tasks_name'] = 'Nazwa zadania';
$txt['scheduled_tasks_next_time'] = 'Czas następnego uruchomienia';
$txt['scheduled_tasks_regularity'] = 'Harmonogram';
$txt['scheduled_tasks_enabled'] = 'Włączony';
$txt['scheduled_tasks_run_now'] = 'Uruchom teraz';
$txt['scheduled_tasks_save_changes'] = 'Zapisz zmiany';
$txt['scheduled_tasks_time_offset'] = '<strong>Uwaga:</strong> Wszystkie czasy widoczne poniżej są <em>czasami serwera</em> i nie uwzględniają przesunięć czasu na forum.';
$txt['scheduled_tasks_were_run'] = 'Wszystkie wybrane zadania zostały uzupełnione';
$txt['scheduled_tasks_were_run_errors'] = 'Podczas wykonywania zaplanowanych zadań wystąpiły następujące błędy:';

$txt['scheduled_tasks_na'] = 'brak';
$txt['scheduled_task_approval_notification'] = 'Powiadomienia zatwierdzeń';
$txt['scheduled_task_desc_approval_notification'] = 'Wyślij e-maile z zestawieniem wiadomości oczekujących zatwierdzenia do wszystkich moderatorów.';
$txt['scheduled_task_auto_optimize'] = 'Optymalizacja bazy danych';
$txt['scheduled_task_desc_auto_optimize'] = 'Optymalizuj bazę danych aby rozwiązać problemy z fragmentacją.';
$txt['scheduled_task_daily_maintenance'] = 'Codzienna konserwacja';
$txt['scheduled_task_desc_daily_maintenance'] = 'Uruchom niezbędną codzienną konserwację forum - nie powinno być wyłączone.';
$txt['scheduled_task_daily_digest'] = 'Dzienne podsumowanie powiadomień';
$txt['scheduled_task_desc_daily_digest'] = 'Wyślij e-maile z dziennym zestawieniem powiadomień dla subskrybentów.';
$txt['scheduled_task_weekly_digest'] = 'Tygodniowe podsumowanie powiadomień';
$txt['scheduled_task_desc_weekly_digest'] = 'Wyślij e-mail z tygodniowym zestawieniem powiadomień dla subskrybentów.';
$txt['scheduled_task_birthdayemails'] = 'Wyślij e-maile z życzeniami urodzinowymi';
$txt['scheduled_task_desc_birthdayemails'] = 'Wyślij e-maile życzące użytkownikom wszystkiego najlepszego z okazji urodzin.';
$txt['scheduled_task_weekly_maintenance'] = 'Cotygodniowa konserwacja';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Uruchom niezbędną cotygodniową konserwację forum - nie powinno być wyłączone.';
$txt['scheduled_task_paid_subscriptions'] = 'Sprawdź płatne subskrypcje';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Wyślij wszystkie przypomnienia o kończących się płatnych subskrypcjach i usuń użytkownikom wygasłe subskrypcje.';
$txt['scheduled_task_remove_topic_redirect'] = 'Usuń tematy przekierowujące';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Usuwa tematy z informacją o przeniesieniu "PRZENIESIONO:".';
$txt['scheduled_task_remove_temp_attachments'] = 'Usuń tymczasowe pliki załączników';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Usuwa tymczasowe pliki utworzone podczas dodawania plików do wiadomości, które z jakiegoś powodu nie zostały usunięte wcześniej.';
$txt['scheduled_task_remove_old_drafts'] = 'Usuń stare szkice';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Usuwa szkice starsze niż liczba dni podana w ustawieniach szkiców.';
$txt['scheduled_task_remove_old_followups'] = 'Usuń stare powiązania';
$txt['scheduled_task_desc_remove_old_followups'] = 'Usuwa stare wciąż obecne w bazie danych powiązania do nieistniejących tematów.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Pobierz wiadomości email z IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Pobiera wiadomości email dla funkcji listy mailingowej ze skrzynki IMAP.';
$txt['scheduled_task_user_access_mentions'] = 'Dostęp do oznaczania użytkowników';
$txt['scheduled_task_desc_user_access_mentions'] = 'Weryfikuje dostępność użytkowników do każdego działu i ustawia odpowiednio system oznaczeń.';

$txt['scheduled_task_reg_starting'] = 'Start o %1$s';
$txt['scheduled_task_reg_repeating'] = 'powtarzaj co %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minuta(y)';
$txt['scheduled_task_reg_unit_h'] = 'godzina(y)';
$txt['scheduled_task_reg_unit_d'] = 'dniu/dniach';
$txt['scheduled_task_reg_unit_w'] = 'tydzień(tygodnie)';

$txt['scheduled_task_edit'] = 'Edytuj zaplanowane zadania';
$txt['scheduled_task_edit_repeat'] = 'Powtarzaj zadanie co';
$txt['scheduled_task_edit_pick_unit'] = 'Wybierz jednostkę';
$txt['scheduled_task_edit_interval'] = 'Interwał';
$txt['scheduled_task_edit_start_time'] = 'Rozpocznij o';
$txt['scheduled_task_edit_start_time_desc'] = 'Godzina pierwszego uruchomienia zadania (godzina:minuty)';
$txt['scheduled_task_time_offset'] = 'Czas początku powinien być ustawiony w stosunku do aktualnego czasu serwera. Aktualny czas serwera to: %1$s';

$txt['scheduled_view_log'] = 'Pokaż logi';
$txt['scheduled_log_empty'] = 'Obecnie nie ma żadnych logów zadań.';
$txt['scheduled_log_time_run'] = 'Czas uruchomienia';
$txt['scheduled_log_time_taken'] = 'Czas wykonania';
$txt['scheduled_log_time_taken_seconds'] = '%1$d sekund';
$txt['scheduled_log_completed'] = 'Zadanie ukończone';
$txt['scheduled_log_empty_log'] = 'Wyczyść logi';
$txt['scheduled_log_empty_log_confirm'] = 'Na pewno chcesz usunąć wszystkie wpisy w logu?';