<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Zarządzaj działami i kategoriami';
$txt['order'] = 'Kolejność';
$txt['full_name'] = 'Pełna nazwa';
$txt['name_on_display'] = 'Ta nazwa będzie wyświetlana.';
$txt['boards_and_cats_desc'] = 'Tutaj możesz edytować kategorie i działy forum. Kilku moderatorów wymieniaj w ten sposób: <em>&quot;użytkownik1&quot;, &quot;użytkownik2&quot;</em>.(należy podać nazwy użytkowników, a nie nazwy wyświetlane)<br />Aby utworzyć nowy dział, kliknij przycisk Dodaj dział, dla utworzenia działu podrzędnego wybierz "Podrzędny..." z menu.<br />Aby przenieść dział możesz przeciągnąć go i upuścić w żądanym miejscu  (w dowolnym miejscu kategorii i działach podrzędnych)<br />Aby utworzyć nowy dział podrzędny, kliknij przycisk Dodaj dział, i wybierz opcję "Podrzędny..." z menu.';
$txt['parent_members_only'] = 'Zwykli użytkownicy';
$txt['parent_guests_only'] = 'Goście';
$txt['catConfirm'] = 'Na pewno chcesz usunąć tę kategorię?';
$txt['boardConfirm'] = 'Na pewno chcesz usunąć ten dział?';

$txt['catEdit'] = 'Edytuj kategorie';
$txt['collapse_enable'] = 'Zwijane';
$txt['collapse_desc'] = 'Pozwól użytkownikom zwinąć tę kategorię';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'Po ';
$txt['mboards_order_first'] = 'na pierwszym miejscu';
$txt['mboards_board_error'] = 'Wystąpił błąd podczas przenoszenia działu.';

$txt['mboards_new_board'] = 'Dodaj dział';
$txt['mboards_new_cat_name'] = 'Nowa kategoria';
$txt['mboards_add_cat_button'] = 'Dodaj kategorię';
$txt['mboards_new_board_name'] = 'Nowy dział';

$txt['mboards_modify'] = 'modyfikuj';
$txt['mboards_permissions'] = 'Zezwolenia';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Na pewno chcesz aby ten dział podlegał lokalnym pozwoleniom?';

$txt['mboards_delete_cat'] = 'Usuń kategorię';
$txt['mboards_delete_board'] = 'Usuń dział';

$txt['mboards_delete_cat_contains'] = 'Usunięcie tej kategorii spowoduje usunięcie działów jej podległych, włącznie ze wszystkimi tematami, wiadomościami i załącznikami przynależnymi każdemu z tych działów';
$txt['mboards_delete_option1'] = 'Usuń kategorię i wszystkie podległe jej działy.';
$txt['mboards_delete_option2'] = 'Usuń kategorię i przenieś wszystkie podległe jej działy do';
$txt['mboards_delete_board_contains'] = 'Usunięcie tego działu będzie także oznaczało przeniesienie wszystkich działów podrzędnych włącznie z ich tematami, wypowiedziami i załącznikami';
$txt['mboards_delete_board_option1'] = 'Usuń dział, a jego działy podrzędne przenieś do poziomu kategorii.';
$txt['mboards_delete_board_option2'] = 'Usuń dział i przenieś wszystkie jego działy podrzędne do';
$txt['mboards_delete_what_do'] = 'Zaznacz co chcesz zrobić z tymi działami';
$txt['mboards_delete_confirm'] = 'Potwierdź';
$txt['mboards_delete_cancel'] = 'Anuluj';

$txt['mboards_category'] = 'Kategoria';
$txt['mboards_description'] = 'Opis';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Dozwolone grupy';
$txt['mboards_groups_desc'] = 'Grupy mające dostęp do tego działu.<br /><em>Informacja: jeśli użytkownik jest w jakiejkolwiek zaznaczonej grupie, będzie miał dostęp do tego działu.</em>';
$txt['mboards_groups_regular_members'] = 'Grupa zawiera wszystkich użytkowników którzy nie mają przydzielonej podstawowej grupy.';
$txt['mboards_groups_post_group'] = 'Grupa oparta o liczbę wiadomości.';
$txt['mboards_moderators'] = 'Moderatorzy';
$txt['mboards_moderators_desc'] = 'Dodatkowi użytkownicy posiadający uprawnienia moderacyjne w tym dziale. Nie trzeba podawać tutaj administratorów.';
$txt['mboards_count_posts'] = 'Zliczaj wiadomości';
$txt['mboards_count_posts_desc'] = 'Odpowiedzi i nowe tematy podwyższają liczbę wiadomości u użytkowników.';
$txt['mboards_unchanged'] = 'Nie zmieniony';
$txt['mboards_theme'] = 'Styl działu';
$txt['mboards_theme_desc'] = 'Tutaj możesz zmienić wygląd forum tylko wewnątrz tego działu.';
$txt['mboards_theme_default'] = '(domyślny styl forum.)';
$txt['mboards_override_theme'] = 'Zignoruj styl wybrany przez użytkownika';
$txt['mboards_override_theme_desc'] = 'Używaj domyślnego stylu tego forum, nawet jeśli użytkownik wybrał inny.';

$txt['mboards_redirect'] = 'Przekieruj na adres w sieci';
$txt['mboards_redirect_desc'] = 'Włącz tą opcję aby przekierować każdego kto kliknie w to forum do innego adresu w sieci.';
$txt['mboards_redirect_url'] = 'Adres przekierowujący użytkowników do';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Zresetuj licznik przekierowań';
$txt['mboards_redirect_reset_desc'] = 'Wybranie tej opcji spowoduje zresetowanie do zera liczby przekierowań dla tego forum.';
$txt['mboards_current_redirects'] = 'Obecnie: %1$s';
$txt['mboards_redirect_disabled'] = 'Uwaga: Dział musi być pusty i nie może zawierać tematów aby opcja ta była aktywna.';
$txt['mboards_redirect_disabled_recycle'] = 'Uwaga: Nie możesz ustawić kosza forum jako przekierowania.';

$txt['mboards_order_before'] = 'Przed';
$txt['mboards_order_child_of'] = 'Podrzędny';
$txt['mboards_order_in_category'] = 'W kategorii';
$txt['mboards_current_position'] = 'Obecna pozycja';
$txt['no_valid_parent'] = 'Dział %1$s nie ma działu nadrzędnego. Użyj funkcji \'znajdź i usuń błędy\' aby to naprawić.';

$txt['mboards_recycle_disabled_delete'] = 'Musisz wybrać alternatywny dział jako kosz przed usunięciem obecnego.';

$txt['mboards_settings_desc'] = 'Edytuj ustawienia działów i kategorii.';
$txt['groups_manage_boards'] = 'Grupy użytkowników którym wolno zarządzać działami i kategoriami';
$txt['recycle_enable'] = 'Włącz zachowanie usuniętych tematów';
$txt['recycle_board'] = 'Dział dla usuniętych tematów';
$txt['recycle_board_unselected_notice'] = 'Włączyłeś opcję zachowania usuwanych tematów bez wybrania działu do którego mają być przenoszone. Opcja ta nie zostanie włączona dopóki nie wybierzesz działu oznaczonego jako kosz.';
$txt['countChildPosts'] = 'Uwzględniaj działy podrzędne przy zliczaniu wiadomości';
$txt['allow_ignore_boards'] = 'Zezwól na ignorowanie działów';
$txt['deny_boards_access'] = 'Włącz możliwość odmowy dostępu do działu bazując na grupie użytkownika';
$txt['boardsaccess_option_desc'] = 'Dla każdego zezwolenia możesz wybrać \'Zezwalaj\' (Z), \'Ignoruj\' (I) lub <span class="alert">\'Pozbaw\' (P)</span>.<br /><br />Pamiętaj, że jeśli pozbawisz grupę jakiegoś zezwolenia, każdy z członków - moderatorzy również nie będzie mógł wykonać danej czynności.<br />Dlatego też powinieneś używać zezwoleń bardzo ostrożnie, tylko kiedy jest to <strong>konieczne</strong>. Opcja \'Nie zezwalaj\' zabrania, chyba że użytkownik posiada dane zezwolenie w inny sposób (np. jest moderatorem).';

$txt['mboards_select_destination'] = 'Zaznacz cel dla działu \'<strong>%1$s</strong>\'';
$txt['mboards_cancel_moving'] = 'Anuluj przenoszenie';
$txt['mboards_move'] = 'przenieś';

$txt['mboards_no_cats'] = 'Nie ma obecnie żadnych skonfigurowanych kategorii lub działów.';
