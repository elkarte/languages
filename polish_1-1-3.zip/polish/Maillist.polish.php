<?php
// Version: 1.1; Maillist

// Email posting errors
$txt['error_locked'] = 'Ten temat został zamknięty i nie można w nim wysyłać odpowiedzi';
$txt['error_locked_short'] = 'Temat zamknięty';
$txt['error_cant_start'] = 'Nie możesz tworzyć nowych tematów w podanym dziale';
$txt['error_cant_start_short'] = 'Nie można rozpocząć nowego tematu';
$txt['error_cant_reply'] = 'Nie możesz odpowiedzieć';
$txt['error_cant_reply_short'] = 'Temat poza dostępem';
$txt['error_topic_gone'] = 'Temat nie może zostać odnaleziony - mógł zostać usunięty lub połączony z innym.';
$txt['error_topic_gone_short'] = 'Usunięty temat';
$txt['error_not_find_member'] = 'Nie znaleziono twojego adresu email w bazie użytkowników. Tylko użytkownicy mogą korzystać z tej funkcji.';
$txt['error_not_find_member_short'] = 'ID emaila nie znajduje się w bazie danych';
$txt['error_key_sender_match'] = 'Klucz wiadomości email jest poprawny, ale nie został wysłany na adres email odpowiedzi. Musisz wysłać odpowiedź z tego samego adresu email na który została wysłana wiadomość.';
$txt['error_key_sender_match_short'] = 'Niewłaściwy klucz';
$txt['error_not_find_entry'] = 'Wygląda na to, że już odpowiedziałeś na ten email. Jeśli chcesz edytować wiadomość użyj strony internetowej, jeśli chcesz wysłać kolejną odpowiedź wyślij ją w odpowiedzi na ostatnie powiadomienie.';
$txt['error_not_find_entry_short'] = 'Klucz wygasł';
$txt['error_pm_not_found'] = 'Prywatna wiadomość na którą próbowano odpowiedzieć nie została znaleziona.';
$txt['error_pm_not_found_short'] = 'Brakująca PW';
$txt['error_pm_not_allowed'] = 'Nie posiadasz uprawnień do wysyłania prywatnych wiadomości!';
$txt['error_pm_not_allowed_short'] = 'Brak dostępu do PW';
$txt['error_no_message'] = 'Nie odnaleziono wiadomości w treści email. Musisz podać ją w celu wysłania wiadomości na forum.';
$txt['error_no_message_short'] = 'Pusta wiadomość';
$txt['error_no_subject'] = 'Musisz podać nazwę tematu w celu jego rozpoczęcia';
$txt['error_no_subject_short'] = 'Brak tytułu';
$txt['error_board_gone'] = 'Dział w którym próbowałeś wysłać wiadomość nie istnieje lub nie masz do niego dostępu';
$txt['error_board_gone_short'] = 'Dział chroniony lub nieistniejący';
$txt['error_missing_key'] = 'W odpowiedzi nie odnaleziono klucza. W celu zaakceptowania wiadomości email musi ona być wysłana jako odpowiedź na powiadomienie oraz odpowiedź musi być wysłana z adresu email na który wysłano powiadomienie.';
$txt['error_missing_key_short'] = 'Brakujący klucz';
$txt['error_found_spam'] = 'Uwaga: Twoja wiadomość została uznana za potencjalny spam przez filtr twojej poczty i nie została wysłana.';
$txt['error_found_spam_short'] = 'Potencjalny spam';
$txt['error_pm_not_find_entry'] = 'Wygląda na to, że już odpowiedziałeś na tą prywatną wiadomość. Jeśli chcesz wysłać kolejną odpowiedź użyj strony internetowej lub poczekaj na kolejną odpowiedź innego użytkownika.';
$txt['error_pm_not_find_entry_short'] = 'Klucz PW wygasł';
$txt['error_not_find_board'] = 'Usiłowano utworzyć nowy temat w nieistniejącym dziale. Prawdopodobna próba włamania.';
$txt['error_not_find_board_short'] = 'Nie znaleziono działu';
$txt['error_no_pm_attach'] = '[załączniki w PW nie są obsługiwane]';
$txt['error_no_attach'] = '[załączniki w wiadomości email są wyłączone]';
$txt['error_in_maintenance_mode'] = 'Wiadomości nie można było wysłać, ponieważ email otrzymano, gdy forum znajdowało się w trybie obsługi';
$txt['error_in_maintenance_mode_short'] = 'W trybie obsługi';
$txt['error_email_notenabled_short'] = 'Wyłączone';
$txt['error_email_notenabled'] = 'Funkcja wysyłania wiadomości przez email nie jest włączona, email nie mógł zostać przetworzony';
$txt['error_permission'] = 'Autor wiadomości nie posiada uprawnień do wysyłania wiadomości przez email w tym dziale';
$txt['error_permission_short'] = 'No permissions';
$txt['error_bounced'] = 'The message was refused by the destination mail server';
$txt['error_bounced_short'] = 'The message could not be delivered';

// Maillist page items
$txt['ml_admin_configuration'] = 'Konfiguracja listy mailingowej';
$txt['ml_configuration_desc'] = 'Tutaj możesz zmienić ustawienia wysyłania wiadomości przez email';
$txt['ml_emailerror_none'] = 'Nie ma błędnych wpisów wymagających akcji moderatora';
$txt['ml_emailerror'] = 'Błędy wiadomości email';
$txt['ml_emailsettings'] = 'Ustawienia';

// Settings tab
$txt['maillist_enabled'] = 'Włącz listę mailingową (główne ustawienie)';
$txt['pbe_post_enabled'] = 'Pozwól na wysyłanie wiadomości na forum przez email';
$txt['pbe_pm_enabled'] = 'Pozwól na odpowiadanie na PW przez email';
$txt['pbe_no_mod_notices'] = 'Wyłącz powiadomienia moderacyjne';
$txt['pbe_no_mod_notices_desc'] = 'Nie wysyłaj powiadomień o tematach przeniesionych, zamkniętych, usuniętych, połączonych itd. Zużywają one niepotrzebnie miejsce na serwerze.';
$txt['pbe_bounce_detect'] = 'Turn on automatic bounce detection';
$txt['pbe_bounce_detect_desc'] = 'Attempt to identify mail bounces and disable further notifications';
$txt['pbe_bounce_record'] = 'Record bounce messages in failed mail after auto processing';
$txt['pbe_bounce_record_desc'] = 'Bounce messages will always be recorded if Bounce Detection is disabled';

$txt['saved'] = 'Zapisano informacje';

// General Sending Settings
$txt['maillist_outbound'] = 'Ogólne ustawienia wysyłania';
$txt['maillist_outbound_desc'] = 'Użyj tych ustawień, aby zmienić wygląd wychodzących wiadomości email oraz gdzie ma być wysyłana odpowiedź.';
$txt['maillist_group_mode'] = 'Włącz tryb listy mailingowej';
$txt['maillist_digest_enabled'] = 'Włącz rozszerzone codzienne powiadomienia (dodaje wyrywek z tematu w wiadomości)';
$txt['maillist_sitename'] = 'Nazwa strony do użycia w wiadomościach email';
$txt['maillist_sitename_desc'] = 'Jest to nazwa adresu email, coś znajomego dla użytkowników, pojawi się to w kilku miejscach wiadomości wychodzących, na przykład temat - [Nazwa strony] temat';
$txt['maillist_sitename_post'] = 'np. &lt;<strong>Nazwa strony</strong>&gt;emailpost@yourdomain.com';
$txt['maillist_sitename_address'] = 'Odpowiedź na i z adresu email';
$txt['maillist_sitename_address_desc'] = 'Adres na który wysyłane mają być odpowiedzi. Jeśli pozostawione jest puste zostanie użyty adres powiadomień (jeśli został podany) lub adres administratora.';
$txt['maillist_sitename_regards'] = 'Podpis wiadomości email';
$txt['maillist_sitename_regards_desc'] = 'Tekst na końcu wiadomości, np. "Pozdrowienia, załoga Nazwa Strony"';
$txt['maillist_sitename_address_post'] = 'np. emailpost@yourdomain.com';
$txt['maillist_sitename_help'] = 'Adres email pomocy';
$txt['maillist_sitename_help_desc'] = 'Używany dla nagłówka "List Owner" w celu zapobiegania oznaczania wiadomości jako spam.';
$txt['maillist_sitename_help_post'] = 'np. help@yourdomain.com';
$txt['maillist_mail_from'] = 'Adres email powiadomień';
$txt['maillist_mail_from_desc'] = 'Adres używany dla wysyłania powiadomień, przypomnień haseł itd. Jeśli pozostawione puste użyty zostanie adres administratora (domyślne)';
$txt['maillist_mail_from_post'] = 'np. noreply@yourdomain.com';

// Imap settings
$txt['maillist_imap'] = 'Ustawienia IMAP';
$txt['maillist_imap_host'] = 'Nazwa serwera poczty';
$txt['maillist_imap_host_desc'] = 'Podaj nazwę hosta serwera email oraz opcjonalny numer portu, np. imap.gmail.com lub imap.gmail.com:993';
$txt['maillist_imap_mailbox'] = 'Nazwa skrzynki';
$txt['maillist_imap_mailbox_desc'] = 'Podaj nazwę skrzynki poczty na serwerze, na przykład NOWE';
$txt['maillist_imap_uid'] = 'Nazwa użytkownika skrzynki';
$txt['maillist_imap_uid_desc'] = 'Nazwa użytkownika do zalogowania na skrzynkę';
$txt['maillist_imap_pass'] = 'Hasło do skrzynki pocztowej';
$txt['maillist_imap_pass_desc'] = 'Hasło do zalogowania się do poczty';
$txt['maillist_imap_connection'] = 'Połączenie ze skrzynką pocztową';
$txt['maillist_imap_connection_desc'] = 'Wybierz jaki typ połączenia ma być używany: IMAP lub POP3 (nieszyfrowany, TLS lub tryb SSL).';
$txt['maillist_imap_unsecure'] = 'IMAP';
$txt['maillist_pop3_unsecure'] = 'POP3';
$txt['maillist_imap_tls'] = 'IMAP/TLS';
$txt['maillist_imap_ssl'] = 'IMAP/SSL';
$txt['maillist_pop3_tls'] = 'POP3/TLS';
$txt['maillist_pop3_ssl'] = 'POP3/SSL';
$txt['maillist_imap_delete'] = 'Usuń wiadomości';
$txt['maillist_imap_delete_desc'] = 'Spróbuj usunąć wiadomości ze skrzynki pocztowej, które zostały pobrane i przetworzone.';
$txt['maillist_imap_reason'] = 'Powinno pozostać PUSTE jeśli zamierzasz przetwarzać wiadomość przez skrypt forum (zalecane)';
$txt['maillist_imap_missing'] = 'Funkcje IMAP nie są zainstalowane na używanym systemie, żadne ustawienia nie są dostępne';
$txt['maillist_imap_cron'] = 'Fake-Cron (zaplanowane zadanie)';
$txt['maillist_imap_cron_desc'] = 'Jeśli nie możesz uruchomić na swoim serwerze cron job zaznacz to pole, aby wykonać to za pomocą funkcji Zaplanowanych zadań';
$txt['scheduled_task_desc_pbeIMAP'] = 'Przetwarza wiadomości przez program IMAP w celu odczytania emaili ze skrzynki';

// General Receiving Settings
$txt['maillist_inbound'] = 'Ogólne ustawienia otrzymywania';
$txt['maillist_inbound_desc'] = 'Użyj tych ustawień, aby ustalić jakie akcje ma wykonać system po otrzymaniu nowego tematu przez email. Nie wpływa to na odpowiedzi na powiadomienia.';
$txt['maillist_newtopic_change'] = 'Pozwól na rozpoczęcie nowego tematu przez zmianę tytułu odpowiedzi';
$txt['maillist_newtopic_needsapproval'] = 'Wymagaj zatwierdzenia nowego tematu';
$txt['maillist_newtopic_needsapproval_desc'] = 'Wymagaj zatwierdzenia wszystkich nowych tematów wysyłanych przez email.';
$txt['recommended'] = 'Zalecane';
$txt['experimental'] = 'This functionality is experimental';
$txt['receiving_address'] = 'Odbierający adres email';
$txt['receiving_board'] = 'Dział w którym wysyłane sa nowe wiadomości';
$txt['reply_add_more'] = 'Dodaj kolejny adres';
$txt['receiving_address_desc'] = 'Podaj listę adresów email oraz odpowiadających im działów na forum, w których powinny być wysłane wiadomości z danego konta pocztowego. Jest to wymagane do rozpoczęcia nowego tematu, użytkownicy muszą wysłać email na wybrany adres, wtedy wiadomość zostanie dodana w wybranym dziale. Aby usunąć powiązanie wyczyść pola i zapisz ustawienia.';
$txt['email_not_valid'] = 'Adres email (%s) nie jest poprawny';
$txt['board_not_valid'] = 'Podany identyfikator działu (%d) nie jest poprawny';

// Other settings
$txt['misc'] = 'Inne ustawienia';
$txt['maillist_allow_attachments'] = 'Pozwól na wysyłanie załączników przez email (nie działa z PW)';
$txt['maillist_key_active'] = 'Ilość dni przez które klucz jest aktywny';
$txt['maillist_key_active_desc'] = 'np. jak długo po wysłaniu powiadomienia można otrzymać odpowiedź';
$txt['maillist_sig_keys'] = 'Słowa oznaczające początek podpisu';
$txt['maillist_sig_keys_desc'] = 'Rozdziel słowa znakiem |, użyj na przykład "Pozdrawiam|Dziękuję". Linie rozpoczynające się od nich będą oznaczały początek podpisu';
$txt['maillist_leftover_remove'] = 'Linie pomijane';
$txt['maillist_leftover_remove_desc'] = 'Rozdziel słowa znakiem |, sugerowane słowa do użycia:"Do: |Odp: |Wysłano: |Tytuł: |Data: |Od: ". Większość z rzeczy usuwana jest przez parsery, ale niektóre kończą w cytatach. Nie dodawaj nic do tej listy, chyba że wiesz co robisz.';
$txt['maillist_short_line'] = 'Długość krótkiej linii wiadomości używana do formatowania wierszy ';
$txt['maillist_short_line_desc'] = 'Zmiana wartości domyślnej może spowodować nieoczekiwane rezultaty, bądź ostrożny';

// Failed log actions
$txt['approved'] = 'Email został zatwierdzony i wysłany';
$txt['error_approved'] = 'Wystąpił błąd podczas zatwierdzania wiadomości email';
$txt['id'] = '#';
$txt['error'] = 'Błąd';
$txt['key'] = 'Klucz';
$txt['message_id'] = 'Wiadomość';
$txt['message_type'] = 'Typ';
$txt['message_action'] = 'Czynności';
$txt['emailerror_title'] = 'Log błędów emaili';
$txt['show_notice'] = 'Szczegóły wiadomości email';
$txt['private'] = 'Prywatny';
$txt['show_notice_text'] = 'Treść wiadomości';
$txt['noaccess'] = 'Prywatne wiadomości nie mogą być przejrzane';
$txt['badid'] = 'Błędny lub brakujący ID wiadomości email';
$txt['delete_warning'] = 'Na pewno chcesz usunąć ten wpis?';
$txt['pm_approve_warning'] = 'UWAGA!
Prywatna wiadomość na którą odpowiadasz została usunięta.
System spróbuje odnaleźć osoby, które uczestniczyły w dyskusji, jednak wyniki nie są w 100% dokładne.
Jeśli masz jakiekolwiek wątpliwości najlepiej odrzuć wiadomość!';
$txt['filter_delete_warning'] = 'Na pewno chcesz usunąć ten filtr?';
$txt['parser_delete_warning'] = 'Na pewno chcesz usunąć ten parser?';
$txt['bounce'] = 'Zwróć';
$txt['heading'] = 'Lista nieudanych operacji wysłania wiadomości przez email na forum, możesz je przeglądać, zatwierdzać (jeśli jest to możliwe), usuwać lub zwracać do nadawcy.';
$txt['cant_approve'] = 'Błędy nie pozwalają na zatwierdzenie pozycji (nie można automatycznie naprawić)';
$txt['email_attachments'] = '[W wiadomości znajdują się %d załączniki]';
$txt['email_failure'] = 'Powód porażki';

// Filters
$txt['filters'] = 'Filtry email';
$txt['add_filter'] = 'Dodaj filtr';
$txt['sort_filter'] = 'Kolejność filtrów';
$txt['edit_filter'] = 'Edytuj istniejący filtr';
$txt['no_filters'] = 'Nie ustawiono żadnych filtrów';
$txt['error_no_filter'] = 'Nie udało się znaleźć/załadować wybranego filtra';
$txt['regex_invalid'] = 'Wyrażenie Regex nie jest poprawne';
$txt['filter_to'] = 'Zamień na';
$txt['filter_to_desc'] = 'Zamień znaleziony tekst na';
$txt['filter_from'] = 'Znajdź';
$txt['filter_from_desc'] = 'Wpisz tekst, który ma być wyszukiwany';
$txt['filter_type'] = 'Typ';
$txt['filter_type_desc'] = 'Standardowe znajdzie dokładny tekst i zamieni go na tekst znajdujący się w polu Zamień na. Wyrażenie regularne jest opcjonalne i musi być podane w formacie PCRE.';
$txt['filter_name'] = 'Nazwa';
$txt['filter_name_desc'] = 'Opcjonalnie podaj nazwę w celu ułatwienia zapamiętania do czego służy ten filtr';
$txt['filters_title'] = 'Tutaj możesz dodawać, edytować i usuwać filtry wiadomości email. Filtry szukają tekstu w wiadomości i zamieniają go na wybrany inny tekst.';
$txt['filter_invalid'] = 'Definicja nie jest poprawna i nie może być zapisana';
$txt['error_no_id_filter'] = 'ID filtra nie jest poprawny';
$txt['saved_filter'] = 'Filtr został zapisany';
$txt['filter_sort_description'] = 'Filtry są wykonywane w widocznej kolejności, wyrażenia regularne na początku, a później standardowe. Aby to zmienić przeciągnij pozycję do nowej lokacji na liście (ale nie możesz wymusić wykonania standardowego filtra przed filtrem z wyrażeniem regularnym).';

// Parsers
$txt['saved_parser'] = 'Parser został zapisany';
$txt['parser_reordered'] = 'Kolejność pól została zmieniona';
$txt['error_no_id_parser'] = 'ID parsera nie jest poprawny';
$txt['add_parser'] = 'Dodaj parser';
$txt['sort_parser'] = 'Sortuj parsery';
$txt['edit_parser'] = 'Edytuj istniejący parser';
$txt['parsers'] = 'Parsery email';
$txt['parser_from'] = 'Znajdź wyrażenie w oryginalnej wiadomości email';
$txt['parser_from_desc'] = 'Podaj słowo rozpoczynające oryginalną wiadomość email, system przytnie w tym miejscu wiadomość pozostawiając jedynie nową wiadomość (jeśli jest to możliwe). Podczas używania wyrażeń regularnych musi być to poprawnie ograniczone';
$txt['parser_type'] = 'Typ';
$txt['parser_type_desc'] = 'Standardowe znajdzie dokładny tekst i przytnie w tym miejscu wiadomość. Wyrażenie regularne jest opcją standardowego i musi być podane w formacie PCRE.';
$txt['parser_name'] = 'Nazwa';
$txt['parser_name_desc'] = 'Opcjonalnie podaj nazwę w celu ułatwienia zapamiętania do czego służy ten parser';
$txt['no_parsers'] = 'Nie zdefiniowano żadnego parsera';
$txt['parsers_title'] = 'Tutaj możesz dodawać, edytować lub usuwać parsery email. Parser szuka specyficznej linii i ucina wiadomość w tym punkcie w celu usunięcia części wiadomości na którą wysyłana jest odpowiedź. Jeśli parser nie odnajdzie tekstu (np. odpowiedź jest poniżej lub pomiędzy oryginalna wiadomością) zostanie pominięty.';
$txt['option_standard'] = 'Standardowe';
$txt['option_regex'] = 'Wyrażenie regularne';
$txt['parser_sort_description'] = 'Parsery są wykonywane w kolejności podanej poniżej. Aby to zmienić przeciągnij pozycję na liście.';

// Bounce
$txt['bounce_subject'] = 'Porażka';
$txt['bounce_error'] = 'Błąd';
$txt['bounce_title'] = 'Kreator zwróconej poczty';
$txt['bounce_notify_subject'] = 'Tytuł zwróconej wiadomości';
$txt['bounce_notify'] = 'Wyślij powiadomienie o zwróceniu';
$txt['bounce_notify_template'] = 'Wybierz szablon';
$txt['bounce_notify_body'] = 'Treść powiadomienia zwróconej wiadomości';
$txt['bounce_issue'] = 'Wyślij zwrot';
$txt['bad_bounce'] = 'Nie można wysłać, ponieważ treść lub/i tytuł zwróconej wiadomości jest puste.';

// Subject tags
$txt['RE:'] = 'ODP:';
$txt['FW:'] = 'FW:';
$txt['FWD:'] = 'FWD:';
$txt['SUBJECT:'] = 'TYTUŁ:';

// Quote strings
$txt['email_wrote'] = 'Napisał';
$txt['email_quoting'] = 'Cytat';
$txt['email_quotefrom'] = 'Cytat';
$txt['email_on'] = 'W';
$txt['email_at'] = 'w';

// Our digest strings for the digest "template"
$txt['digest_preview'] = "\n     <*> Topic Summary:\n     ";
$txt['digest_see_full'] = "\n\n <*> Zobacz pełen temat:\n <*> ";
$txt['digest_reply_preview'] = "\n     <*> Latest Reply:\n     ";
$txt['digest_unread_reply_link'] = "\n\n     <*> See all your unread replies to this topic at the following link:\n     <*> ";
$txt['message_attachments'] = '<*> Ta wiadomość ma powiązane ze sobą %d grafik/plików.
<*> Aby je zobaczyć kliknij na ten link: %s';

// Help
$txt['maillist_help'] = 'W celu uzyskania pomocy w konfiguracji listy mailingowej odwiedź jej sekcję na <a href="https://github.com/elkarte/Elkarte/wiki/Posting-by-Email-Feature" target="_blank" class="new_win">wiki ElkArte</a>';

// Email bounce templates
$txt['ml_bounce_templates_title'] = 'Własne szablony zwróconych wiadomości email';
$txt['ml_bounce_templates_none'] = 'Nie utworzono jeszcze żadnych szablonów zwróconych wiadomości email';
$txt['ml_bounce_templates_time'] = 'Czas utworzenia';
$txt['ml_bounce_templates_name'] = 'Szablon';
$txt['ml_bounce_templates_creator'] = 'Utworzony przez';
$txt['ml_bounce_template_add'] = 'Dodaj szablon';
$txt['ml_bounce_template_modify'] = 'Edytuj szablon';
$txt['ml_bounce_template_delete'] = 'Usuń zaznaczone';
$txt['ml_bounce_template_delete_confirm'] = 'Na pewno chcesz usunąć wybrane szablony?';
$txt['ml_bounce_body'] = 'Treść wiadomości';
$txt['ml_bounce_template_subject_default'] = 'Tytuł powiadomienia';
$txt['ml_bounce_template_desc'] = 'Użyj tej strony do uzupełnienia szczegółów szablonu. Tytuł wiadomości email nie jest częścią szablonu.';
$txt['ml_bounce_template_title'] = 'Tytuł szablonu';
$txt['ml_bounce_template_title_desc'] = 'Nazwa do użycia na liście szablonów';
$txt['ml_bounce_template_body'] = 'Zawartość szablonu';
$txt['ml_bounce_template_body_desc'] = 'The content of the bounced message. Note that you can use the following shortcuts in this template:<ul><li>{MEMBER} - Member Name.</li><li>{FORUMNAME} - Forum Name.</li><li>{FORUMNAMESHORT} - Short name for the site.</li><li>{ERROR} - The error that the email generated.</li><li>{SUBJECT} - The subject of the email that failed.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{EMAILREGARDS} - Maillist email sign-off.</li><li>{REGARDS} - Standard forum sign-off.</li></ul>';
$txt['ml_bounce_template_personal'] = 'Szablon osobisty';
$txt['ml_bounce_template_personal_desc'] = 'Jeśli wybierzesz tą opcję tylko ty będziesz mógł widzieć, edytować i używać ten szablon, w przeciwnym razie wszyscy moderatorzy będą mogli go używać.';
$txt['ml_bounce_template_error_no_title'] = 'Musisz podać tytuł';
$txt['ml_bounce_template_error_no_body'] = 'Musisz podać treść szablonu';

$txt['ml_bounce'] = 'Szablony email';
$txt['ml_bounce_description'] = 'Tutaj możesz dodawać i edytować szablony zwróconych wiadomości email.';
$txt['ml_bounce_title'] = 'Zwróć';
$txt['ml_bounce_subject'] = 'Wiadomość email nie mogła zostać wysłana na forum';
$txt['ml_bounce_body'] = 'Treść wiadomości';
$txt['ml_inform_title'] = 'Powiadamiaj';
$txt['ml_inform_subject'] = 'Wystąpił problem z wiadomością email';
$txt['ml_inform_body'] = '{MEMBER},

Twoja wiadomość email wysłana do {FORUMNAMESHORT} wygenerowała błąd, który spowodował opóźnienie w wysłaniu wiadomości na forum. Treść błędu: {ERROR}

Aby zapobiec przyszłym opóźnieniom powinieneś naprawić ten błąd.

{EMAILREGARDS}';
$txt['ml_bounce_template_body_default'] = 'Witaj. Tutaj program mailingu z {FORUMNAMESHORT}

Obawiam się, że nie było możliwe dostarczenie lub wysłanie twojej wiadomości na forum: {SUBJECT}.

Błąd otrzymany podczas pobierania wiadomości: {ERROR}

Jest to trwały błąd; poddałem się. Przepraszam, że nie udało się.

{EMAILREGARDS}'; // redundant?