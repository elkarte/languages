<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Najwięcej online';

$txt['stats_center'] = 'Centrum statystyk';
$txt['general_stats'] = 'Statystyki ogólne';
$txt['top_posters'] = '10 najaktywniejszych użytkowników';
$txt['top_boards'] = '10 najaktywniejszych działów';
$txt['forum_history'] = 'Historia forum (domyślne ustawienia czasu)';
$txt['stats_new_topics'] = 'Nowe tematy';
$txt['stats_new_posts'] = 'Nowe wiadomości';
$txt['stats_new_members'] = 'Nowi użytkownicy';
$txt['page_views'] = 'Wejścia';
$txt['top_topics_replies'] = '10 najlepszych tematów (wg odpowiedzi)';
$txt['top_topics_views'] = '10 najlepszych tematów (wg wyświetleń)';
$txt['yearly_summary'] = 'Podsumowanie miesięcy';
$txt['top_starters'] = 'Najwięcej wysłanych tematów';
$txt['most_time_online'] = 'Najwięcej czasu online';

$txt['average_members'] = 'Średnio rejestracji na dzień';
$txt['average_posts'] = 'Średnio wiadomości na dzień';
$txt['average_topics'] = 'Średnio tematów na dzień';
$txt['average_online'] = 'Średnio online na dzień';
$txt['users_online'] = 'Zalogowani użytkownicy';
$txt['emails_sent'] = 'Średnio emaili na dzień';
$txt['users_online_today'] = 'Online dzisiaj';
$txt['num_hits'] = 'Wszystkich wyświetleń strony';
$txt['average_hits'] = 'Średnio wyświetleń na dzień';

$txt['ssi_comment'] = 'komentarz';
$txt['ssi_comments'] = 'komentarze';
$txt['ssi_write_comment'] = 'Napisz komentarz';
$txt['ssi_no_guests'] = 'Nie możesz wybrać działu, do którego nie mają dostępu goście. Sprawdź ID działu przed ponowną próbą.';
$txt['xml_rss_desc'] = 'Aktualności z {forum_name}';