<?php
// Version: 1.1; ManageThemes

$txt['themeadmin_explain'] = 'Style dają różny wygląd stronom. Globalne ustawienia stylów pozwalają administratorowi na wybranie domyślnego stylu strony. Administratorzy mogą również umożliwić użytkownikom wybranie własnego stylu spośród zainstalowanych na forum stylów. W sekcji Zainstaluj nowy styl administrator może instalować nowe style.';
$txt['themeadmin_manage'] = 'Zarządzaj i instaluj';
$txt['theme_forum_theme'] = 'Globalne ustawienia stylów';
$txt['theme_allow'] = 'Zezwól użytkownikom na wybór stylu.';
$txt['theme_guests'] = 'Domyślny styl forum:';
$txt['theme_select'] = 'wybierz...';
$txt['theme_reset'] = 'Ustaw wszystkim użytkownikom styl:';
$txt['theme_nochange'] = 'Bez zmian';
$txt['theme_forum_default'] = 'Domyślny dla forum';

$txt['theme_remove'] = 'Odinstaluj';
$txt['theme_remove_confirm'] = 'Na pewno chcesz usunąć ten styl?';

$txt['theme_install'] = 'Zainstaluj nowy styl';
$txt['theme_install_file'] = 'Z lokalnego archiwum (np. .zip lub .tar.gz)';
$txt['theme_install_dir'] = 'Z katalogu na serwerze:';
$txt['theme_install_error'] = 'Katalog nie istnieje lub nie zawiera stylu.';
$txt['theme_install_write_error'] = 'W celu kontynuowania katalog stylów musi być zapisywalny.';
$txt['theme_install_go'] = 'Zainstaluj';
$txt['theme_install_new'] = 'Utwórz kopię domyślnego stylu ElkArte pod nazwą:';
$txt['theme_install_new_confirm'] = 'Na pewno chcesz zainstalować nowy styl?';
$txt['theme_install_writable'] = 'Uwaga - nie możesz tworzyć lub instalować nowych stylów, ponieważ katalog stylów nie jest zapisywalny.';
$txt['theme_install_general'] = 'Styl nie znajduje się tam, gdzie powinien. Sprawdź podane informacje.';
$txt['theme_installed'] = 'Zainstalowano pomyślnie';
$txt['theme_installed_message'] = 'został poprawnie zainstalowany.';

$txt['theme_pick'] = 'Wybierz styl...';
$txt['theme_preview'] = 'Podgląd stylu';
$txt['theme_set'] = 'Użyj tego stylu';
$txt['theme_user'] = 'użytkownik używa tego stylu.';
$txt['theme_users'] = 'użytkowników używa tego stylu.';
$txt['theme_pick_variant'] = 'Wybierz wariant:';

$txt['theme_edit'] = 'Edytuj styl';
$txt['theme_edit_style'] = 'Modyfikuj plik stylów. (kolory, czcionki, itp.)';
$txt['theme_edit_index'] = 'Modyfikuj plik index.template.php (główny szablon)';
$txt['theme_edit_no_save'] = 'Plik nie może być zapisany, ponieważ nie jest zapisywalny. Upewnij się, że następujący plik ma atrybuty 777 lub odpowiednie zezwolenia';
$txt['theme_edit_save'] = 'Zapisz zmiany';
$txt['theme_edit_not_writable'] = 'Niezapisywalny';

$txt['theme_global_description'] = 'To jest styl domyślny, twój styl będzie zmieniał się razem z ustawieniami administratora i działem, który będziesz przeglądał.';

$txt['theme_url_config'] = 'Adres stylu i konfiguracja';
$txt['theme_variants'] = 'Warianty stylu';
$txt['theme_options'] = 'Opcje i preferencje stylu';
$txt['actual_theme_name'] = 'Nazwa tego stylu: ';
$txt['actual_theme_dir'] = 'Katalog tego stylu: ';
$txt['actual_theme_url'] = 'URL tego stylu: ';
$txt['actual_images_url'] = 'URL obrazków tego stylu: ';

$txt['theme_variants_default'] = 'Wariant stylu domyślnego:';
$txt['theme_variants_user_disable'] = 'Wyłącz użytkownikom możliwość wyboru wariantu stylu.';

$txt['site_slogan'] = 'Slogan strony:';
$txt['site_slogan_desc'] = '(Add your own text for a slogan here.)';
$txt['header_layout'] = 'Styl nagłówka:';
$txt['header_layout_desc'] = '(Tutaj możesz wybrać jeden z trzech dostępnych stylów nagłówka.)';
$txt['header_layout_default_name'] = 'Domyślny:';
$txt['header_layout_default_desc'] = 'Logo jest wyświetlane po prawej stronie, nazwa froum po lewej.';
$txt['header_layout_logo_only_name'] = 'Tylko logo:';
$txt['header_layout_logo_only_desc'] = 'Wyświetlane jest tylko wyśrodkowane logo.';
$txt['header_layout_inverted_name'] = 'Logo po lewej stronie:';
$txt['header_layout_inverted_desc'] = 'Podobne do domyślnego, ale logo i nazwa są zamienione miejscami (logo jest po lewej stronie, a nazwa po prawej).';
$txt['header_layout_default'] = 'Domyślny';
$txt['header_layout_logo_only'] = 'Tylko logo';
$txt['header_layout_inverted'] = 'Logo po lewej stronie';
$txt['forum_width'] = 'Szerokość forum:';
$txt['forum_width_desc'] = '(Ustawia szerokość forum. Przykłady: 950px, 80%, 1240px.)';

$txt['enable_news'] = 'Linia aktualności w nagłówku forum:';
$txt['enable_news_off'] = 'Wyłącz';
$txt['enable_news_random'] = 'Losowa';
$txt['enable_news_fader'] = 'Animowana';
$txt['enable_news_off_name'] = 'Wyłączone:';
$txt['enable_news_off_desc'] = 'Aktualności nie są wyświetlane.';
$txt['enable_news_random_name'] = 'Losowa:';
$txt['enable_news_random_desc'] = 'Wyświetli jedną losową wiadomość.';
$txt['enable_news_fader_name'] = 'Animowana:';
$txt['enable_news_fader_desc'] = 'Wszystkie aktualności będą wyświetlane po kolei z efektem animacji.';

$txt['show_group_key'] = 'Pokaż grupy w indeksie działów.';
$txt['additional_options_collapsible'] = 'Włącz zwijane dodatkowe opcje wysyłania wiadomości.';
$txt['who_display_viewing'] = 'Pokaż kto ogląda indeks działów oraz wiadomości:';
$txt['who_display_viewing_off'] = 'Nie pokazuj';
$txt['who_display_viewing_numbers'] = 'Pokazuj tylko liczby';
$txt['who_display_viewing_names'] = 'Pokazuj nazwy użytkowników';
$txt['show_stats_index'] = 'Pokaż statystyki w indeksie działów.';
$txt['latest_members'] = 'Pokaż najnowszego użytkownika w indeksie działów.';
$txt['last_modification'] = 'Pokaż datę modyfikacji wiadomości.';
$txt['user_avatars'] = 'Pokaż awatary użytkowników w widoku wiadomości.';
$txt['member_list_bar'] = 'Pokaż pasek listy użytkowników w indeksie działów';
$txt['current_pos_text_img'] = 'Pokaż obecną pozycję na forum jako link zamiast tekstu.';
$txt['show_view_profile_button'] = 'Pokaż przycisk zobacz profil pod wiadomością.';
$txt['enable_mark_as_read'] = 'Włącz i pokaż przyciski \'Oznacz jako przeczytane\'.';
$txt['header_logo_url'] = 'Adres grafiki loga forum:';
$txt['header_logo_url_desc'] = '(Pozostaw puste w celu pokazania nazwy forum lub domyślnego loga.)';

$txt['recent_post_topics'] = 'Show recent posts or recent topics on board index.';
$txt['show_recent_topics'] = 'Show recent topics';
$txt['show_recent_posts'] = 'Show recent posts';
$txt['number_recent_posts'] = 'Number of recent posts or topics to display on board index:';
$txt['number_recent_posts_desc'] = '(To disable the recent posts/topics bar set this value to zero.)';
$txt['hide_post_group'] = 'Ukryj nazwy grup opartych o liczbę wiadomości.';
$txt['hide_post_group_desc'] = '(Po włączeniu tej opcji w tematach nie będzie widoczna grupa oparta o liczbę wiadomości jeśli użytkownik należy do zwykłej grupy.)';

$txt['theme_options_defaults'] = 'To są domyślne wartości niektórych opcji specyficznych dla użytkowników. Zmiana tych ustawień będzie dotyczyć jedynie nowych użytkowników i gości.';
$txt['theme_options_title'] = 'Zmień lub resetuj domyślne opcje';

$txt['themeadmin_title'] = 'Zarządzanie stylami i opcje';
$txt['themeadmin_description'] = 'Tutaj możesz zmodyfikować ustawienia swoich stylów, uaktualniać je, resetować opcje użytkowników i tym podobne.';
$txt['themeadmin_admin_desc'] = 'Style umożliwiają zmianę wyglądu forum. Zarządzanie stylami i opcje pozwala instalować nowe style, zmieniać domyślny styl, wymuszać styl używany na forum oraz zmieniać ustawienia dotyczące wyboru stylów. Pamiętaj, aby przejrzeć ustawienia każdego zainstalowanego stylu, niektóre mogą mieć własne ustawienia.';
$txt['themeadmin_list_desc'] = 'W sekcji Ustawienia stylów możesz przeglądać listę zainstalowanych stylów, zmieniać ścieżki katalogów, ustawienia oraz usuwać je.';
$txt['themeadmin_reset_desc'] = 'W sekcji Opcje użytkowników możesz zmienić ustawienia stylów dla wszystkich użytkowników. Zobaczysz tylko te style, które mają własny zestaw ustawień.';
$txt['themeadmin_edit_desc'] = 'W sekcji Modyfikuj style możesz edytować arkusze stylów oraz kod szablonów. Aby nie uszkodzić stylu przyda się tutaj podstawowa wiedza na temat PHP i CSS.';
$txt['themeadmin_modify_styles'] = 'Changing a themes style is risky so be certain of what you are doing. Always have a backup copy of the theme directory that you are working in to use to recover from an error with. For help with this before you start, visit the <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">ElkArte Community</a>.';

$txt['themeadmin_list_heading'] = 'Ustawienia stylów';
$txt['themeadmin_list_tip'] = 'Ustawienia wyglądu mogą być inne dla każdego zainstalowanego stylu. Edytuj zainstalowane style w celu zastosowania indywidualnych ustawień, zmiany katalogu, adresu URL lub innych opcji.';
$txt['themeadmin_list_theme_dir'] = 'Katalog stylów: (szablony)';
$txt['themeadmin_list_invalid'] = '(Uwaga! Podana ścieżka nie jest prawidłowa!)';
$txt['themeadmin_list_theme_url'] = 'Adres do powyższego katalogu:';
$txt['themeadmin_list_images_url'] = 'Adres do katalogu grafik:';
$txt['themeadmin_list_reset'] = 'Przywróć domyślny adres URL i ścieżkę katalogu';
$txt['themeadmin_list_reset_dir'] = 'Główna ścieżka do katalogu stylów:';
$txt['themeadmin_list_reset_url'] = 'Adres do tego samego katalogu:';
$txt['themeadmin_list_reset_go'] = 'Spróbuj zresetować wszystkie style';

$txt['themeadmin_reset_tip'] = 'Każdy styl może mieć własne opcje dostępne dla użytkowników. W tych opcjach znajdują się np. &quot;szybka odpowiedź&quot;, awatary, podpisy, ustawienia wyglądu. Tutaj możesz zmienić domyślne ustawienia stylów lub zresetować je dla wszystkich użytkowników.<br /><br />Zapamiętaj: styl może zawierać niektóre domyślne opcje, dla których nie będzie ustawień.';
$txt['themeadmin_reset_defaults'] = 'Ustaw domyślne opcje stylu dla gości i nowych użytkowników';
$txt['themeadmin_reset_defaults_current'] = 'opcje obecnie ustawione.';
$txt['themeadmin_reset_members'] = 'Zmień opcje użytkowników tego stylu';
$txt['themeadmin_reset_remove'] = 'Usuń wszystkie ustawienia użytkowników i ustaw wartości domyślne';
$txt['themeadmin_reset_remove_current'] = 'użytkowników używa własnych opcji.';
// Don't use entities in the below string.
$txt['themeadmin_reset_remove_confirm'] = 'Na pewno chcesz usunąć wszystkie ustawienia stylu?\nMoże to zresetować niektóre dodatkowe pola profilu.';
$txt['themeadmin_reset_options_info'] = 'Opcje znajdujące się poniżej zresetują ustawienia <em>wszystkich użytkowników</em>. Aby zmienić opcję wybierz &quot;Zmień&quot; w polu obok i wybierz żądaną wartość. W celu użycia domyślnych ustawień wybierz &quot;domyślne&quot;. W przeciwnym razie użyj &quot;Nie zmieniaj&quot;, aby zachować obecny stan opcji.';
$txt['themeadmin_reset_options_change'] = 'Zmień';
$txt['themeadmin_reset_options_none'] = 'Nie zmieniaj';
$txt['themeadmin_reset_options_default'] = 'Domyślny';

$txt['themeadmin_edit_browse'] = 'Przeglądaj szablony i pliki w tym stylu.';
$txt['themeadmin_edit_style'] = 'Edytuj arkusz stylów tego stylu.';
$txt['themeadmin_edit_copy_template'] = 'Kopiuj szablon ze stylu bazowego.';
$txt['themeadmin_edit_exists'] = 'już istnieje';
$txt['themeadmin_edit_do_copy'] = 'kopiuj';
$txt['themeadmin_edit_copy_warning'] = 'Kiedy system potrzebuje plik języka lub szablon który nie jest dostępny w używanym stylu zostaje użyty plik ze stylu domyślnego.<br />Jeśli nie będziesz edytował szablonów lepiej nie kopiować ich.';
$txt['themeadmin_edit_copy_confirm'] = 'Na pewno chcesz skopiować ten szablon?';
$txt['themeadmin_edit_overwrite_confirm'] = 'Na pewno chcesz skopiować ten szablon i nadpisać istniejący plik?\nWszystkie wprowadzone zmiany zostaną utracone';
$txt['themeadmin_edit_no_copy'] = '<em>(nie można skopiować)</em>';
$txt['themeadmin_edit_filename'] = 'Nazwa pliku';
$txt['themeadmin_edit_modified'] = 'Ostatnio modyfikowano';
$txt['themeadmin_edit_size'] = 'Rozmiar';
$txt['themeadmin_edit_error'] = 'Plik, który próbowałeś zapisać wygenerował następujący błąd:';
$txt['themeadmin_edit_on_line'] = 'Początek w linii:';
$txt['themeadmin_edit_preview'] = 'Podgląd';
$txt['themeadmin_selectable'] = 'Style dostępne dla użytkowników:';
$txt['themeadmin_themelist_link'] = 'Pokaż listę zainstalowanych stylów';

// Strings for the variants
$txt['variant_light'] = 'ElkArte Light';
$txt['variant_besocial'] = 'ElkArte Be Social!';
