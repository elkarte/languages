<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Ustaw parametry wyszukiwania';
$txt['choose_board'] = 'Wybierz dział do przeszukania lub przeszukaj wszystkie';
$txt['all_words'] = 'Dopasuj wszystkie słowa';
$txt['any_words'] = 'Dopasuj jakiekolwiek ze słów';
$txt['by_user'] = 'wysłane przez';

$txt['search_post_age'] = 'Wiek wiadomości';
$txt['search_between'] = 'pomiędzy';
$txt['search_and'] = 'i';
$txt['search_options'] = 'Opcje';
$txt['search_show_complete_messages'] = 'Pokaż wyniki jako wiadomości';
$txt['search_subject_only'] = 'Szukaj tylko w tytułach tematów';
$txt['search_relevance'] = 'Trafności';
$txt['search_date_posted'] = 'Data wysłania';
$txt['search_order'] = 'Sortowanie wyszukiwania';
$txt['search_orderby_relevant_first'] = 'Najpierw najbardziej trafne';
$txt['search_orderby_large_first'] = 'Najpierw najdłuższe tematy';
$txt['search_orderby_small_first'] = 'Najpierw najkrótsze tematy';
$txt['search_orderby_recent_first'] = 'Najpierw najnowsze tematy';
$txt['search_orderby_old_first'] = 'Najpierw najstarsze tematy';
$txt['search_visual_verification_label'] = 'Weryfikacja';
$txt['search_visual_verification_desc'] = 'Aby użyć wyszukiwarki przepisz kod z obrazka.';

$txt['search_specific_topic'] = 'Przeszukaj wiadomości tylko w tym temacie';

$txt['groups_search_posts'] = 'Grupy użytkowników mające dostęp do funkcji szukania';
$txt['search_dropdown'] = 'Włącz menu szybkiego wyszukiwania';
$txt['search_results_per_page'] = 'Ilość wyników na stronę';
$txt['search_weight_frequency'] = 'Relatywna waga wyszukania dla liczby pasujących wiadomości w temacie';
$txt['search_weight_age'] = 'Relatywna waga wyszukania dla wieku ostatniej zgodnej wiadomości';
$txt['search_weight_length'] = 'Relatywna waga wyszukania dla długości tematu';
$txt['search_weight_subject'] = 'Relatywna waga wyszukania dla zgodnego tytułu';
$txt['search_weight_first_message'] = 'Relatywna waga wyszukania dla zgodności z pierwszą wiadomością';
$txt['search_weight_sticky'] = 'Relatywna waga wyszukania dla przyklejonych tematów';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Tutaj możesz zmienić podstawowe ustawienia wyszukiwania.';
$txt['search_settings_title'] = 'Ustawienia wyszukiwania';

$txt['search_weights_desc'] = 'Tutaj możesz zmienić pojedyncze komponenty wskaźnika trafności.';
$txt['search_weights_sphinx'] = 'Aby zaktualizować czynniki wag dla Sphinx musisz wygenerować i zainstalować nowy plik sphinx.conf.';
$txt['search_weights_title'] = 'Wyszukiwanie - wagi';
$txt['search_weights_total'] = 'W sumie';
$txt['search_weights_save'] = 'Zapisz';

$txt['search_method_desc'] = 'Tutaj możesz zmienić ustawienia wyszukiwarki.';
$txt['search_method_title'] = 'Metoda szukania';
$txt['search_method_save'] = 'Zapisz';
$txt['search_method_messages_table_space'] = 'Miejsce zajmowane w bazie danych przez wiadomości';
$txt['search_method_messages_index_space'] = 'Miejsce zajmowane w bazie danych przez indeks wiadomości';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Indeks pełnotekstowy';
$txt['search_method_no_index_exists'] = 'obecnie nie istnieje';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'nie można utworzyć, ponieważ maksymalna długość wiadomości przekracza 65,535 znaków lub tabela nie jest typu MyISAM';
$txt['search_method_index_already_exists'] = 'już stworzone';
$txt['search_method_fulltext_remove'] = 'usuń indeks pełnotekstowy';
$txt['search_method_index_partial'] = 'częściowo utworzony';
$txt['search_index_custom_resume'] = 'wznów';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'Aby korzystać z pełnotekstowego wyszukiwania, musisz najpierw stworzyć pełnotekstowy indeks.';
$txt['search_index_custom_warning'] = 'Aby móc korzystać z wyszukiwania według własnego indeksu, musisz go najpierw utworzyć!';

$txt['search_index'] = 'Indeks wyszukiwania';
$txt['search_index_none'] = 'Brak indeksu';
$txt['search_index_custom'] = 'Własny indeks';
$txt['search_index_label'] = 'Indeks';
$txt['search_index_size'] = 'Rozmiar';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Wymuszaj korzystanie z indeksu wyszukiwania';
$txt['search_match_words'] = 'Uwzględniaj tylko całe słowa';
$txt['search_max_results'] = 'Maksymalna ilość wyświetlanych wyników';
$txt['search_max_results_disable'] = '(0: brak limitu)';
$txt['search_floodcontrol_time'] = 'Minimalny czas pomiędzy wyszukiwaniem dla tego samego użytkownika';
$txt['search_floodcontrol_time_desc'] = '(0 = brak limitu, w sekundach)';

$txt['additional_search_engines'] = 'Dodatkowe silniki wyszukiwarek';
$txt['setup_search_engine_add_more'] = 'Dodaj kolejny silnik wyszukiwarki';

$txt['search_create_index'] = 'Stwórz indeks';
$txt['search_create_index_why'] = 'Dlaczego tworzyć indeks wyszukiwania?';
$txt['search_create_index_start'] = 'Stwórz';
$txt['search_predefined'] = 'Predefiniowany profil';
$txt['search_predefined_small'] = 'Mały indeks';
$txt['search_predefined_moderate'] = 'Średni indeks';
$txt['search_predefined_large'] = 'Duży indeks';
$txt['search_create_index_continue'] = 'Kontynuuj';
$txt['search_create_index_not_ready'] = 'ElkArte tworzy właśnie indeks wyszukiwania twoich wiadomości. W celu uniknięcia przeciążenia serwera, proces został chwilowo wstrzymany. Powinien wznowić działanie za kilka sekund. Jeśli tak się nie stanie, kliknij kontynuuj.';
$txt['search_create_index_progress'] = 'Postęp';
$txt['search_create_index_done'] = 'Własny indeks wyszukiwania został utworzony.';
$txt['search_create_index_done_link'] = 'Kontynuuj';
$txt['search_double_index'] = 'Masz aktualnie utworzone dwa indeksy na tabeli wiadomości. Dla osiągnięcia lepszej wydajności, zalecane jest usunięcie jednego z nich.';

$txt['search_error_indexed_chars'] = 'Nieprawidłowa liczba zindeksowanych znaków. Wymagane są co najmniej 3 znaki do stworzenia użytecznego indeksu.';
$txt['search_error_max_percentage'] = 'Nieprawidłowy procent słów do pominięcia. Użyj co najmniej wartości 5%.';
$txt['error_string_too_long'] = 'Wyszukiwane słowo musi być krótsze niż %1$d znaków.';

$txt['search_warning_ignored_word'] = 'Następujące słowo zostało zignorowane podczas wyszukiwania';
$txt['search_warning_ignored_words'] = 'Następujące słowa zostały zignorowane podczas wyszukiwania';

$txt['search_adjust_query'] = 'Dostosuj parametry wyszukiwania';
$txt['search_adjust_submit'] = 'Ponów wyszukiwanie';
$txt['search_did_you_mean'] = 'Może szukałeś tego';

$txt['search_example'] = '<em>np.</em> Orwell "Folwark Zwierzęcy" -film';

$txt['search_engines_description'] = 'W tej części możesz zdecydować, w jakim stopniu chcesz śledzić silniki wyszukiwarek gdy indeksują twoje forum oraz przeglądać logi robotów.';
$txt['spider_mode'] = 'Poziom śledzenia silników wyszukiwarek';
$txt['spider_mode_note'] = 'Wyższy poziom śledzenia zużywa więcej zasobów serwera.';
$txt['spider_mode_off'] = 'Wyłączony';
$txt['spider_mode_standard'] = 'Standardowe';
$txt['spider_mode_high'] = 'Moderuj';
$txt['spider_mode_vhigh'] = 'Agresywny';
$txt['spider_settings_desc'] = 'Możesz zmienić ustawienia śledzenia robotów. Jeśli chcesz  włączyć automatyczne czyszczenie logów możesz to zrobić <a href="%1$s">tutaj</a>';

$txt['spider_group'] = 'Zastosuj restrykcyjne zezwolenia z grupy';
$txt['spider_group_note'] = 'Aby uniemożliwić indeksowanie niektórych stron.';
$txt['spider_group_none'] = 'Wyłączony';

$txt['show_spider_online'] = 'Pokaż roboty na liście zalogowanych użytkowników';
$txt['show_spider_online_no'] = 'Nie pokazuj';
$txt['show_spider_online_summary'] = 'Pokaż liczbę robotów';
$txt['show_spider_online_detail'] = 'Pokaż nazwy robotów';
$txt['show_spider_online_detail_admin'] = 'Pokaż nazwy robotów - tylko administracja';

$txt['spider_name'] = 'Nazwa robota';
$txt['spider_last_seen'] = 'Ostatnio widziany';
$txt['spider_last_never'] = 'Nigdy';
$txt['spider_agent'] = 'User Agent robota';
$txt['spider_ip_info'] = 'Adresy IP';
$txt['spiders_add'] = 'Dodaj robota';
$txt['spiders_edit'] = 'Edytuj robota';
$txt['spiders_remove_selected'] = 'Usuń zaznaczone';
$txt['spider_remove_selected_confirm'] = 'Na pewno chcesz usunąć wybrane roboty?\\n\\nWszystkie powiązane z nimi statystyki zostaną usunięte!';
$txt['spiders_no_entries'] = 'Brak skonfigurowanych robotów.';

$txt['add_spider_desc'] = 'Z tej strony możesz edytować parametry, według których roboty są klasyfikowane. Jeśli User Agent/adres IP użytkownika pasuje do tych wpisanych poniżej, zostanie wykryty jako robot i zacznie być śledzony.';
$txt['spider_name_desc'] = 'Nazwa pod którą będzie wyświetlany robot.';
$txt['spider_agent_desc'] = 'User Agent powiązany z tym robotem.';
$txt['spider_ip_info_desc'] = 'Rozdzielona przecinkiem lista adresów IP powiązanych z robotem.';

$txt['spider_time'] = 'Czas';
$txt['spider_viewing'] = 'Przegląda';
$txt['spider_logs_empty'] = 'Brak logów.';
$txt['spider_logs_info'] = 'Każda akcja robota jest logowana gdy poziom śledzenia jest ustawiony na &quot;Wysoki&quot; lub &quot;Bardzo Wysoki&quot;. Dokładne akcje robotów są logowane gdy śledzenie jest ustawione na &quot;Bardzo wysokie&quot;.';
$txt['spider_disabled'] = 'Wyłączony';
$txt['spider_log_empty_log'] = 'Wyczyść logi';
$txt['spider_log_empty_log_confirm'] = 'Na pewno chcesz usunąć wszystkie wpisy w logu?';

$txt['spider_logs_delete'] = 'Usuń wpisy';
$txt['spider_logs_delete_older'] = 'Usuń wszystkie wpisy starsze niż %1$s dni.';
$txt['spider_logs_delete_submit'] = 'Usuń';

$txt['spider_stats_delete_older'] = 'Usuń statystyki robotów, które nie odwiedziły strony w ciągu ostatnich %1$s dni.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Na pewno chcesz usunąć wszystkie wpisy w logu?';

$txt['spider_stats_select_month'] = 'Skocz do miesiąca';
$txt['spider_stats_page_hits'] = 'Odsłon strony';
$txt['spider_stats_no_entries'] = 'Nie ma dostępnych statystyk robotów.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'Jeszcze nie wybrałeś której metody wyszukiwania używać, Sphinx lub SphinxQL';
$txt['sphinx_test_passed'] = 'Wszystkie testy przebiegły pomyślnie, system połączył się z kreatorem wyszukiwania sphinx używając API Sphinx.';
$txt['sphinxql_test_passed'] = 'Wszystkie testy przebiegły pomyślnie, system połączył się z kreatorem wyszukiwania sphinx używając komend SphinxQL.';
$txt['sphinx_test_connect_failed'] = 'Nie udało się połączyć z kreatorem Sphinx. Upewnij się, że jest on uruchomiony i prawidłowo skonfigurowany. Wyszukiwanie Sphinx nie będzie działało dopóki nie naprawisz problemu.';
$txt['sphinxql_test_connect_failed'] = 'Brak dostępu do SphinxQL. Upewnij się, że sphinx.conf osobną dyrektywę nasłuchu dla portu SphinxQL. Wyszukiwanie SphinxQL nie będzie działało dopóki nie naprawisz problemu.';
$txt['sphinx_test_api_missing'] = 'Nie znaleziono pliku sphinxapi.php w katalogu &quot;sources&quot; . Musisz skopiować ten plik z dystrybucji  Sphinx. Wyszukiwanie Sphinx nie będzie działało dopóki nie naprawisz problemu.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Prefiks tabel';
$txt['sphinx_index_prefix_desc'] = 'To jest prefiks indeksów podstawowych i delta.<br />Domyślnie wykorzystuje elkarte, dwa indeksy będą miały postać: elkarte_base_index i elkarte_delta_index. Sphinx podłączy się do elkarte_index (prefix_index). Jeśli zmienisz to ustawienie, upewnij się, że używać prawidłowego profilu w zadaniu cron.';
$txt['sphinx_index_data_path'] = 'Ścieżka danych indeksu:';
$txt['sphinx_index_data_path_desc'] = 'Jest to ścieżka zawierająca pliki indeksów wyszukiwania używane przez Sphinx.<br />Ścieżka ta <strong>musi</strong> istnieć oraz musi być zapisywalna przez kreatora wyszukiwania sphinx oraz funkcję indeksowania.';
$txt['sphinx_log_file_path'] = 'Ścieżka pliku logów:';
$txt['sphinx_log_file_path_desc'] = 'Ścieżka na serwerze do pliku logów utworzonych przez Sphinx.<br />Ten katalog musi istnieć na serwerze i musi być zapisywalny przez kreatora wyszukiwania sphinx oraz funkcję indeksowania.';
$txt['sphinx_stop_word_path'] = 'Ścieżka stopword:';
$txt['sphinx_stop_word_path_desc'] = 'Ścieżka na serwerze do listy stopword (pozostaw puste, jeśli jej nie posiadasz).';
$txt['sphinx_memory_limit'] = 'Limit pamięci indeksowania Sphinx:';
$txt['sphinx_memory_limit_desc'] = 'Maksymalna ilość pamięci (RAM) którą może wykorzystać funkcja indeksowania.';
$txt['sphinx_searchd_server'] = 'Serwer kreatora wyszukiwania:';
$txt['sphinx_searchd_server_desc'] = 'Adres serwera z uruchomionym kreatorem wyszukiwania. Musi to być prawidłowy adres IP lub domena.<br />Jeśli nic nie ustawisz zostanie użyty localhost.';
$txt['sphinx_searchd_port'] = 'Port kreatora wyszukiwania:';
$txt['sphinx_searchd_port_desc'] = 'Port nasłuchiwania kreatora wyszukiwania.';
$txt['sphinx_searchd_qlport'] = 'Port kreatora Sphinx QL:';
$txt['sphinx_searchd_qlport_desc'] = 'Port na którym kreator wyszukiwania będzie nasłuchiwał zapytań SphinxQL.';
$txt['sphinx_max_matches'] = 'Maksymalna ilość dopasowań:';
$txt['sphinx_max_matches_desc'] = 'Maksymalna ilość zwróconych wyników.';
$txt['sphinx_create_config'] = 'Utwórz konfigurację Sphinx';
$txt['sphinx_test_connection'] = 'Przetestuj połączenie z kreatorem Sphinx';