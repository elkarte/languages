<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Działy';
$txt['admin_back_to'] = 'Wróć do panelu administracyjnego';
$txt['admin_users'] = 'Użytkownicy';
$txt['admin_newsletters'] = 'Newslettery';
$txt['include_these'] = 'Dołącz użytkowników';
$txt['exclude_these'] = 'Wyklucz użytkowników';
$txt['admin_newsletters_select_groups'] = 'Dołącz grupy';
$txt['admin_newsletters_exclude_groups'] = 'Wyklucz grupy';
$txt['admin_edit_news'] = 'Aktualności';
$txt['admin_groups'] = 'Grupy użytkowników';
$txt['admin_members'] = 'Zarządzaj użytkownikami';
$txt['admin_members_list'] = 'Poniżej znajduje się lista wszystkich zarejestrowanych na forum użytkowników.';
$txt['admin_next'] = 'Następna';
$txt['admin_censored_words'] = 'Cenzurowane słowa';
$txt['admin_censored_where'] = 'Po lewej stronie wpisz słowo które ma zostać ocenzurowane, a po prawej stronie słowo które ma zostać wyświetlone. Później ustaw czy wielkość znaków jest brana pod uwagę i czy sprawdzać całe wyrazy. Po zakończeniu zapisz ustawienia. Można zapisać kilka wpisów jednocześnie używając przycisku Dodaj następne słowo.';
$txt['admin_censored_desc'] = 'Z powodu publicznej natury forum możesz chcieć zabronić użytkownikom wysyłanie niektórych słów. Poniżej możesz podać słowa, które mają zostać ocenzurowane.<br />Wyczyść pole, aby usunąć słowo z listy cenzury.';
$txt['admin_reserved_names'] = 'Zarezerwowane nazwy użytkowników';
$txt['admin_template_edit'] = 'Edytuj szablon forum';
$txt['admin_modifications'] = 'Ustawienia dodatków';
$txt['admin_security_moderation'] = 'Bezpieczeństwo i moderacja';
$txt['admin_server_settings'] = 'Ustawienia serwera';
$txt['admin_reserved_set'] = 'Zarezerwowane nazwy';
$txt['admin_reserved_line'] = 'Jedno zarezerwowane słowo na linię.';
$txt['admin_basic_settings'] = 'Na tej stronie możesz zmienić podstawowe ustawienia forum. Bądź ostrożny, nieprawidłowe ustawienia mogą negatywnie wpłynąć na działanie forum.';
$txt['admin_maintain'] = 'Włącz tryb obsługi forum';
$txt['admin_title'] = 'Nazwa forum';
$txt['admin_url'] = 'Adres forum';
$txt['cookie_name'] = 'Nazwa ciasteczka';
$txt['admin_webmaster_email'] = 'Adres email administratora';
$txt['boarddir'] = 'Katalog ElkArte';
$txt['sourcesdir'] = 'Katalog źródeł';
$txt['cachedir'] = 'Katalog pamięci podręcznej';
$txt['admin_news'] = 'Włącz aktualności';
$txt['admin_guest_post'] = 'Włącz wysyłanie wiadomości przez gości';
$txt['admin_manage_members'] = 'Użytkownicy';
$txt['admin_main'] = 'Główne';
$txt['admin_config'] = 'Konfiguracja';
$txt['admin_version_check'] = 'Szczegółowe sprawdzenie wersji';
$txt['admin_elkfile'] = 'Plik ElkArte';
$txt['admin_elkpackage'] = 'Pakiet ElkArte';
$txt['admin_logoff'] = 'Zakończ sesję administracyjną';
$txt['admin_maintenance'] = 'Konserwacja';
$txt['admin_image_text'] = 'Pokaż przyciski jako obrazki zamiast tekstu';
$txt['admin_credits'] = 'Twórcy';
$txt['admin_agreement'] = 'Pokaż umowę rejestracyjną podczas rejestracji';
$txt['admin_checkbox_agreement'] = 'Pokaż pole umowy rejestracyjnej do zaznaczenia podczas rejestracji zamiast pełnej strony';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Domyślny';
$txt['admin_agreement_select_language'] = 'Język do edycji';
$txt['admin_agreement_select_language_change'] = 'Zmień';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Usuń wybranych użytkowników';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Napraw wszystkie działy i tematy';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Umieść jedną wiadomość w okienku. Możesz używać BBC takie jak <span>[b]</span>, <span>[i]</span> i <span>[u]</span> oraz emotikony. Wyczyść pole wiadomości aby ja usunąć.';
$txt['administrators'] = 'Administratorzy forum';
$txt['admin_reserved_desc'] = 'Zarezerwowane nazwy nie pozwolą użyć tych nazw podczas rejestracji oraz w nawach wyświetlanych. Wybierz opcje które chcesz użyć poniżej.';
$txt['admin_activation_email'] = 'Wyślij użytkownikom email aktywacyjny po rejestracji';
$txt['admin_match_whole'] = 'Bierz pod uwagę tylko całe nazwy. Niezaznaczone wyszuka w nazwie.';
$txt['admin_match_case'] = 'Bierz pod uwagę wielkość liter. Niezaznaczone nie będzie zwracało uwagi na wielkość liter.';
$txt['admin_check_user'] = 'Sprawdź nazwę użytkownika.';
$txt['admin_check_display'] = 'Sprawdź nazwę wyświetlaną.';
$txt['admin_newsletter_send'] = 'Z tej strony możesz wysłać email do kogo chcesz. Adresy email wybranych grup powinny pojawić się poniżej, ale możesz usunąć lub dodać dowolne adresy email. Upewnij się, że adresy email są rozdzielone jak w przykładzie: \'adres1; adres2\'.';
$txt['admin_fader_delay'] = 'Czas wyświetlenia wiadomości na pasku aktualności';
$txt['zero_for_no_limit'] = '(0 dla bez limitu)';
$txt['zero_to_disable'] = '(0 aby wyłączyć)';

$txt['admin_backup_fail'] = 'Nie można wykonać kopii zapasowej pliku Settings.php - upewnij się, że plik Settings_bak.php istnieje i można go zapisywać.';
$txt['modSettings_info'] = 'Ustawienia funkcji takich jak Reputacja, Podpisy, Lubię to oraz  ustawienia dotyczące działania forum.';
$txt['database_server'] = 'Serwer bazy danych';
$txt['database_user'] = 'Użytkownik bazy danych';
$txt['database_password'] = 'Hasło bazy danych';
$txt['database_name'] = 'Nazwa bazy danych';
$txt['registration_agreement'] = 'Umowa rejestracyjna';
$txt['registration_agreement_desc'] = 'Ta umowa jest wyświetlana podczas rejestracji nowego konta na forum i musi zostać zaakceptowana przed kontynuowaniem procesu rejestracji.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Prefiks tabel bazy danych';
$txt['errors_list'] = 'Lista błędów na forum';
$txt['errors_found'] = 'Na forum wykryto następujące błędy';
$txt['errors_fix'] = 'Spróbować naprawić te błędy?';
$txt['errors_do_recount'] = 'Wszystkie błędy zostały naprawione i został utworzony dział odzysku. Kliknij na przycisk poniżej, aby przeliczyć statystyki.';
$txt['errors_recount_now'] = 'Przelicz statystyki';
$txt['errors_fixing'] = 'Naprawianie błędów';
$txt['errors_fixed'] = 'Wszystkie błędy zostały naprawione. Sprawdź utworzone kategorie, działy i tematy i zdecyduj co z nimi zrobić.';
$txt['attachments_avatars'] = 'Załączniki i awatary';
$txt['attachments_desc'] = 'Tutaj możesz zarządzać załącznikami na forum. Możesz usuwać załączniki według rozmiaru i daty. Wyświetlane są tu również statystyki załączników.';
$txt['attachment_stats'] = 'Statystyki załączników';
$txt['attachment_integrity_check'] = 'Sprawdzenie spójności załączników';
$txt['attachment_integrity_check_desc'] = 'Ta funkcja sprawdzi oraz jeśli będzie to konieczne naprawi błędy związane ze spójnością i rozmiarem załączników, a także listę ich nazw w bazie danych.';
$txt['attachment_check_now'] = 'Uruchom sprawdzanie';
$txt['attachment_pruning'] = 'Usuwanie załączników';
$txt['attachment_pruning_message'] = 'Informacja dodana do wiadomości';
$txt['attachment_pruning_warning'] = 'Na pewno usunąć te załączniki?\\nTej operacji nie można cofnąć!';

$txt['attachment_total'] = 'Ilość załączników';
$txt['attachmentdir_size'] = 'Rozmiar katalogów załączników';
$txt['attachmentdir_size_current'] = 'Rozmiar obecnego katalogu załączników';
$txt['attachmentdir_files_current'] = 'Ilość plików w obecnym katalogu załączników';
$txt['attachment_space'] = 'Dostępna przestrzeń';
$txt['attachment_files'] = 'Pozostało plików';

$txt['attachment_options'] = 'Opcje załączników';
$txt['attachment_log'] = 'Logi załączników';
$txt['attachment_remove_old'] = 'Usuń załączniki starsze niż %1$s dni';
$txt['attachment_remove_size'] = 'Usuń załączniki większe niż %1$s KB';
$txt['attachment_name'] = 'Nazwa załącznika';
$txt['attachment_file_size'] = 'Rozmiar pliku';
$txt['attachmentdir_size_not_set'] = 'Nie ustawiono maksymalnego rozmiaru katalogu';
$txt['attachmentdir_files_not_set'] = 'Nie ustawiono limitu plików w katalogu';
$txt['attachment_delete_admin'] = '[załącznik usunięty przez administratora]';
$txt['live'] = 'Najnowsze aktualizacje';
$txt['remove_all'] = 'Wyczyść logi';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(więcej szczegółów)';

$txt['lfyi'] = 'Nie można połączyć się z plikiem aktualności ElkArte.';

$txt['manage_calendar'] = 'Kalendarz';
$txt['manage_search'] = 'Szukaj';
$txt['viewmembers_online'] = 'Ostatnio zalogowany';

$txt['smileys_manage'] = 'Emotikony i ikony wiadomości';
$txt['smileys_manage_info'] = 'Zainstaluj nowe zestawy emotikon, dodawaj nowe emotikony do istniejących zestawów oraz zarządzaj ikonami wiadomości.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Instaluj, pobieraj i wysyłaj pakiety modyfikacji, sprawdź uprawnienia plików oraz ustawienia FTP.';
$txt['theme_admin'] = 'Zarządzanie stylami';
$txt['theme_admin_info'] = 'Zainstaluj nowe style, wybierz style dostępne dla użytkowników oraz zmieniaj ich opcje.';
$txt['registration_center'] = 'Rejestracja';
$txt['member_center_info'] = 'Przeglądaj listę użytkowników, szukaj użytkowników i zarządzaj aktywacjami oraz zatwierdzaniem kont.';
$txt['viewmembers_online'] = 'Ostatnio zalogowany';

$txt['display_name'] = 'Nazwa wyświetlana';
$txt['email_address'] = 'Adres email';
$txt['ip_address'] = 'Adres IP';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'nieznany';
$txt['security_wrong'] = 'Próba logowania do administracji!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Wyślij w formacie HTML (możesz wtedy dodać kod HTML do treści wiadomości email).';
$txt['email_parsed_html'] = 'Dodaj &lt;br /&gt;s i &amp;nbsp;s do tej wiadomości.';
$txt['email_variables'] = 'W tej wiadomości możesz użyć kilka &quot;zmiennych&quot;.<a href="{help_emailmembers}" class="help"> Tutaj uzyskasz więcej informacji</a>.';
$txt['email_force'] = 'Wyślij do użytkowników, którzy nie zgodzili się na wysyłanie im ogłoszeń.';
$txt['email_as_pms'] = 'Wyślij to do tych grup za pomocą prywatnych wiadomości.';
$txt['email_continue'] = 'Kontynuuj';
$txt['email_done'] = 'ukończono.';
$txt['email_members_succeeded'] = 'Wysłano newsletter!';

$txt['ban_title'] = 'Lista banów';
$txt['ban_ip'] = 'Banowanie IP: (np. 192.168.12.213 lub 128.0.*.*) - jeden wpis na linię';
$txt['ban_email'] = 'Banowanie adresów email: (np. badguy@somewhere.com) - jeden wpis na linię';
$txt['ban_username'] = 'Banowanie nazw użytkowników: (np. h4k3r) - jeden wpis na linię';

$txt['ban_errors_detected'] = 'Podczas zapisywania bana wystąpiły następujące błędy';
$txt['ban_description'] = 'Tutaj możesz zbanować użytkowników przez adres IP, nazwę hosta, nazwę użytkownika lub email.';
$txt['ban_add_new'] = 'Dodaj nowy ban';
$txt['ban_banned_entity'] = 'Banuj według';
$txt['ban_on_ip'] = 'Zbanuj  adres IP (np. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Zbanuj nazwę hosta (np. *.mil)';
$txt['ban_on_email'] = 'Zbanuj adres email (np. *@zlastrona.com)';
$txt['ban_on_username'] = 'Zbanuj nazwę użytkownika';
$txt['ban_notes'] = 'Uwagi';
$txt['ban_restriction'] = 'Ograniczenia';
$txt['ban_full_ban'] = 'Pełna blokada';
$txt['ban_partial_ban'] = 'Częściowa blokada';
$txt['ban_cannot_post'] = 'Nie może wysyłać wiadomości';
$txt['ban_cannot_register'] = 'Nie może się zarejestrować';
$txt['ban_cannot_login'] = 'Nie może się logować';
$txt['ban_add'] = 'Dodaj';
$txt['ban_edit_list'] = 'Lista banów';
$txt['ban_type'] = 'Typ bana';
$txt['ban_days'] = 'dniu/dniach';
$txt['ban_will_expire_within'] = 'Ban wygaśnie po';
$txt['ban_added'] = 'Dodane';
$txt['ban_expires'] = 'Wygasa';
$txt['ban_hits'] = 'Trafienia';
$txt['ban_actions'] = 'Czynności';
$txt['ban_expiration'] = 'Wygaśnięcie';
$txt['ban_reason_desc'] = 'Powód bana wyświetlany zbanowanemu użytkownikowi.';
$txt['ban_notes_desc'] = 'Uwagi mogące służyć reszcie załogi forum.';
$txt['ban_remove_selected'] = 'Usuń zaznaczone';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Na pewno chcesz usunąć zaznaczone bany?';
$txt['ban_modify'] = 'Modyfikuj';
$txt['ban_name'] = 'Nazwa bana';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Edytuj ban';
$txt['ban_add_notes'] = '<strong>Uwaga</strong>: po dodaniu powyższego bana, możesz dodać dodatkowe blokady, np. - adresy IP, nazwy hostów i adresy email.';
$txt['ban_expired'] = 'Wygasły / wyłączony';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Nie wybrano żadnych ograniczeń';

$txt['ban_triggers'] = 'Blokada';
$txt['ban_add_trigger'] = 'Dodaj ban';
$txt['ban_add_trigger_submit'] = 'Dodaj';
$txt['ban_edit_trigger'] = 'Modyfikuj';
$txt['ban_edit_trigger_title'] = 'Edytuj ban';
$txt['ban_edit_trigger_submit'] = 'Modyfikuj';
$txt['ban_remove_selected_triggers'] = 'Usuń zaznaczone bany';
$txt['ban_no_entries'] = 'W tym momencie nie ma żadnych aktywnych banów.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Na pewno chcesz usunąć zaznaczone bany?';
$txt['ban_trigger_browse'] = 'Przeglądaj bany';
$txt['ban_trigger_browse_description'] = 'Widoczne są tutaj wszystkie bany grupowane według IP, nazwy hosta, nazwy użytkownika i adresu email.';

$txt['ban_log'] = 'Logi banów';
$txt['ban_log_description'] = 'Logi banów pokazują wszystkie próby wejścia na forum dokonane przez zbanowanych użytkowników (dotyczy tylko: \'pełnego bana\' i \'zakazu rejestracji\').';
$txt['ban_log_no_entries'] = 'Aktualnie nie ma wpisów w logu banów.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'Adres email';
$txt['ban_log_member'] = 'Użytkownik';
$txt['ban_log_date'] = 'Data';
$txt['ban_log_remove_all'] = 'Wyczyść logi';
$txt['ban_log_remove_all_confirm'] = 'Na pewno chcesz usunąć wszystkie wpisy w logu?';
$txt['ban_log_remove_selected'] = 'Usuń zaznaczone';
$txt['ban_log_remove_selected_confirm'] = 'Na pewno chcesz usunąć wszystkie zaznaczone wpisy?';
$txt['ban_no_triggers'] = 'Brak banów.';

$txt['settings_not_writable'] = 'Opcje nie mogą zostać zmienione ponieważ plik Settings.php jest tylko do odczytu.';

$txt['maintain_title'] = 'Obsługa forum';
$txt['maintain_info'] = 'Podstawowe kopie zapasowe forum, sprawdzanie błędów w bazie danych, czyszczenie cache, haki integracyjne i więcej.';
$txt['maintain_sub_database'] = 'Baza danych';
$txt['maintain_sub_routine'] = 'Zadania';
$txt['maintain_sub_members'] = 'Użytkownicy';
$txt['maintain_sub_topics'] = 'Tematy';
$txt['maintain_sub_attachments'] = 'Załączniki';
$txt['maintain_done'] = 'Zadanie \'%1$s\' zakończone powodzeniem.';
$txt['maintain_fail'] = 'Zadanie obsługi \'%1$s\' nie powiodło się.';
$txt['maintain_no_errors'] = 'Gratulacje, nie znaleziono żadnych błędów. Dzięki za sprawdzenie.';

$txt['maintain_tasks'] = 'Zaplanowane zadania';
$txt['maintain_tasks_desc'] = 'Zarządzaj zaplanowanymi zadaniami';

$txt['scheduled_log'] = 'Logi zadań';
$txt['scheduled_log_desc'] = 'Lista logów wykonanych zadań';
$txt['admin_log'] = 'Logi administracji';
$txt['admin_log_desc'] = 'Lista zadań administracyjnych, które zostały wykonane przez administratorów forum.';
$txt['moderation_log'] = 'Logi moderacji';
$txt['moderation_log_desc'] = 'Lista czynności wykonanych przez moderatorów forum.';
$txt['badbehavior_log'] = 'Log Bad Behavior';
$txt['badbehavior_log_desc'] = 'Lista wszystkich żądań zablokowanych lub oznaczonych przez Bad Behavior. Jeśli włączono rozszerzone logi wszystkie żądania HTTP są zapisywane.';
$txt['spider_log_desc'] = 'Przejrzyj wpisy związane z aktywnością robotów wyszukiwarek internetowych na forum.';
$txt['pruning_log_desc'] = 'Użyj tych narzędzi do usunięcia starszych wpisów w logach.';

$txt['mailqueue_title'] = 'Mail';

$txt['db_error_send'] = 'Wyślij wiadomość email po wystąpieniu błędu połączenia z bazą danych';
$txt['db_persist'] = 'Używaj ciągłego połączenia';
$txt['ssi_db_user'] = 'Nazwa użytkownika bazy danych w trybie SSI';
$txt['ssi_db_passwd'] = 'Hasło użytkownika w bazie danych do użycia w trybie SSI';

$txt['default_language'] = 'Domyślny język forum';

$txt['maintenance_subject'] = 'Wyświetlany tytuł';
$txt['maintenance_message'] = 'Wyświetlana wiadomość';

$txt['errlog_desc'] = 'Log błędów śledzi każdy błąd napotkany przez twoje forum. Aby usunąć błąd z listy, zaznacz odpowiednie okienko i kliknij przycisk %1$s na dole strony.';
$txt['errlog_no_entries'] = 'Obecnie nie ma wpisów w logu błędów.';

$txt['theme_settings'] = 'Ustawienia stylów';
$txt['theme_edit_settings'] = 'Edytuj ustawienia tego stylu';
$txt['theme_current_settings'] = 'Ustawienia obecnego stylu';

$txt['dvc_your'] = 'Twoja wersja';
$txt['dvc_current'] = 'Obecna wersja';
$txt['dvc_sources'] = 'Źródła';
$txt['dvc_admin'] = 'Administracja';
$txt['dvc_controllers'] = 'Kontrolery';
$txt['dvc_database'] = 'Bazy danych';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Domyślne szablony';
$txt['dvc_templates'] = 'Obecne szablony';
$txt['dvc_languages'] = 'Pliki języków';

$txt['smileys_default_set_for_theme'] = 'Wybierz domyślny zestaw emotikon dla tego stylu:';
$txt['smileys_no_default'] = 'Użyj domyślny zestaw emotikon';

$txt['censor_test'] = 'Testuj ocenzurowane słowa';
$txt['censor_test_save'] = 'Testuj';
$txt['censor_case'] = 'Ignoruj wielkość liter podczas cenzurowania';
$txt['censor_whole_words'] = 'Sprawdź tylko całe słowa';
$txt['censor_allow'] = 'Pozwól na wyłączenie cenzurowania słów';

$txt['admin_confirm_password'] = '(potwierdź hasło)';
$txt['admin_incorrect_password'] = 'Błędne hasło';

$txt['date_format'] = '(RRRR-MM-DD)';
$txt['undefined_gender'] = 'Nie określono';
$txt['age'] = 'Wiek użytkownika';
$txt['activation_status'] = 'Status aktywacji';
$txt['activated'] = 'Aktywne';
$txt['not_activated'] = 'Nieaktywne';
$txt['is_banned'] = 'Zbanowany';
$txt['primary'] = 'Podstawowe';
$txt['additional'] = 'Dodatkowe';
$txt['wild_cards_allowed'] = 'Możesz używać znaków * i ?';
$txt['member_part_of_these_membergroups'] = 'Użytkownik należy do następujących grup';
$txt['membergroups'] = 'Grupy użytkowników';
$txt['confirm_delete_members'] = 'Na pewno chcesz usunąć wybranych użytkowników?';

$txt['support_credits_title'] = 'Wsparcie i twórcy';
$txt['support_credits_info'] = 'Linki przydatne w rozwiązywaniu częstych problemów, ważne informacje o wersji forum o które będziesz zapytany gdy będzie potrzebna pomoc oraz lista osób, które wsparły projekt ElkArte.';
$txt['support_title'] = 'Informacja techniczna';
$txt['support_versions_current'] = 'Obecna wersja';
$txt['support_versions_forum'] = 'Ta wersja';
$txt['support_versions_db'] = '%1$s wersja';
$txt['support_versions_server'] = 'Wersja serwera';
$txt['support_versions_gd'] = 'Wersja GD';
$txt['support_versions_imagick'] = 'Wersja Imagick';
$txt['support_versions'] = 'Informacja o wersjach';
$txt['support_resources'] = 'Zasoby wsparcia';
$txt['support_resources_p1'] = 'Nasza główna <a href="%1$s" target="_blank" class="new_win">dokumentacja ElkArte</a>. W dokumentacji znajduje się wiele wyjaśnień w celu pomocy w odpowiedzi na niektóre pytania dotyczące <a href="%2$s" target="_blank" class="new_win">funkcji</a>, <a href="%3$s" target="_blank" class="new_win">ustawień</a>, <a href="%4$s" target="_blank" class="new_win">stylów</a>, <a href="%5$s" target="_blank" class="new_win">pakietów</a>, itd. Dokumentacja zawiera informacje na temat każdego miejsca w ElkArte i powinna być w stanie odpowiedzieć szybko na większość pytań.';
$txt['support_resources_p2'] = 'Jeśli nie możesz znaleźć odpowiedzi na swoje pytanie w dokumentacji, spróbuj przeszukać <a href="%1$s" target="_blank" class="new_win">forum wsparcia</a> lub poproś o pomoc w dziale pomocy. Forum pomocy ElkArte może być użyte w celu <a href="%2$s" target="_blank" class="new_win">uzyskania pomocy</a>, <a href="%3$s" target="_blank" class="new_win">modyfikacji</a> oraz wielu innych rzeczy takich jak np. rozmowy o ElkArte, szukanie serwera i dyskutowanie na temat problemów administracyjnych z innymi administratorami stron.';

$txt['latest_updates'] = 'Najnowsze zmiany';
$txt['new_in_1_0_2'] = 'Najważniejszą zmianą wprowadzoną w ElkArte 1.0.2 jest nowy panel zarządzania uprawnieniami awatarów. Obecnie każdy rodzaj awatara posiada własne uprawnienie, które należy nadać grupie. W 1.0.2 zostało to dosyć mocno uproszczone do włączenia/wyłączenia awatarów na poziomie zezwoleń (dla każdego rodzaju awatara).<br />
Pozostało więc jedno ogólne uprawnienie pozwalające użytkownikom na zmianę awatara. Dodatkowo jest tylko jedno ustawienie dotyczące wymiarów grafiki - szerokość i wysokość - które ma zastosowanie we wszystkich rodzajach awatarów.
Z powodu bardzo dużych zmian nie było możliwe zachowanie istniejących uprawnień i ustawień awatarów, dlatego zalecane jest odwiedzenie strony <a href="{admin_url};area=manageattachments;sa=avatars">Ustawienia awatarów</a> i ustawienie opcji według własnych preferencji.';

$txt['edit_permissions_info'] = 'Użyj zezwoleń w celu zarządzania funkcjami działów oraz czynnościami które mogą wykonać goście, zalogowani użytkownicy oraz moderatorzy.';
$txt['membergroups_members'] = 'Zwykli użytkownicy';
$txt['membergroups_guests'] = 'Goście';
$txt['membergroups_add_group'] = 'Dodaj grupę';
$txt['membergroups_permissions'] = 'Zezwolenia';

$txt['permitgroups_restrict'] = 'Restrykcyjne';
$txt['permitgroups_standard'] = 'Standardowe';
$txt['permitgroups_moderator'] = 'Moderatorskie';
$txt['permitgroups_maintenance'] = 'Konserwacja';

$txt['confirm_delete_attachments'] = 'Na pewno chcesz usunąć wybrane załączniki?';
$txt['attachment_manager_browse_files'] = 'Przeglądaj pliki';
$txt['attachment_manager_repair'] = 'Napraw';
$txt['attachment_manager_avatars'] = 'Awatary';
$txt['attachment_manager_attachments'] = 'Załączniki';
$txt['attachment_manager_thumbs'] = 'Miniaturki';
$txt['attachment_manager_last_active'] = 'Ostatni aktywny';
$txt['attachment_manager_member'] = 'Użytkownik';
$txt['attachment_manager_avatars_older'] = 'Usuń awatary użytkowników nielogujących się więcej niż %1$s dni';
$txt['attachment_manager_total_avatars'] = 'Ilość awatarów';

$txt['attachment_manager_avatars_no_entries'] = 'Nie ma obecnie żadnych awatarów';
$txt['attachment_manager_attachments_no_entries'] = 'Nie ma obecnie żadnych załączników';
$txt['attachment_manager_thumbs_no_entries'] = 'Nie ma obecnie żadnych miniatur';

$txt['attachment_manager_settings'] = 'Ustawienia załączników';
$txt['attachment_manager_avatar_settings'] = 'Ustawienia awatarów';
$txt['attachment_manager_browse'] = 'Przeglądaj pliki';
$txt['attachment_manager_maintenance'] = 'Zarządzanie plikami';
$txt['attachmentEnable'] = 'Tryb załączników';
$txt['attachmentEnable_deactivate'] = 'Wyłącz załączniki';
$txt['attachmentEnable_enable_all'] = 'Włącz wszystkie załączniki';
$txt['attachmentEnable_disable_new'] = 'Wyłącz nowe załączniki';
$txt['attachmentCheckExtensions'] = 'Sprawdzaj rozszerzenie załącznika';
$txt['attachmentExtensions'] = 'Dozwolone rozszerzenia załączników';
$txt['attachmentRecodeLineEndings'] = 'Przekoduj zakończenia linii w załącznikach tekstowych';
$txt['attachmentShowImages'] = 'Wyświetlaj załączniki graficzne jako obrazki pod wiadomością';
$txt['attachmentUploadDir'] = 'Katalog załączników';
$txt['attachmentUploadDir_multiple_configure'] = 'Zarządzaj katalogami załączników';
$txt['attachmentDirSizeLimit'] = 'Maksymalny rozmiar katalogu załączników';
$txt['attachmentPostLimit'] = 'Maksymalna ilość załączników w jednej wiadomości';
$txt['attachmentSizeLimit'] = 'Maksymalny rozmiar załącznika';
$txt['attachmentNumPerPostLimit'] = 'Maksymalna ilość załączników w wiadomości';
$txt['attachment_img_enc_warning'] = 'Nie wykryto modułu GD  ani ImageMagick. Ponowne kodowanie grafiki jest niemożliwe.';
$txt['attachment_postsize_warning'] = 'Obecne ustawienie \'post_max_size\' w php.ini może tego nie wspierać.';
$txt['attachment_filesize_warning'] = 'Obecne ustawienie \'upload_max_filesize\' w php.ini może tego nie wspierać.';
$txt['attachment_image_reencode'] = 'Ponowne kodowanie potencjalnie niebezpiecznych obrazów w załącznikach';
$txt['attachment_image_reencode_note'] = '(wymaga modułu GD lub ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Przeprowadzenie kontroli bezpieczeństwa może doprowadzić do odrzucenia dużej liczby załączników.';
$txt['attachment_image_paranoid'] = 'Przeprowadzenie kontroli bezpieczeństwa wysłanych obrazków';
$txt['attachment_autorotate'] = 'Wykryj i automatycznie popraw niepoprawnie obrócone obrazy';
$txt['attachment_autorotate_na'] = '(Funkcja nie jest dostępna na tym systemie)';
$txt['attachmentThumbnails'] = 'Zmień rozmiar obrazka podczas wyświetlania pod wiadomością';
$txt['attachment_thumb_png'] = 'Zapisz miniatury jako pliki PNG';
$txt['attachment_thumb_memory'] = 'Adaptacyjna pamięć miniatur';
$txt['attachment_thumb_memory_note2'] = 'Jeśli system nie będzie miał pamięci miniatura nie zostanie utworzona.';
$txt['attachment_thumb_memory_note1'] = 'Aby zawsze próbować tworzyć miniaturę pozostaw to pole niezaznaczone';
$txt['attachmentThumbWidth'] = 'Maksymalna szerokość miniaturki';
$txt['attachmentThumbHeight'] = 'Maksymalna wysokość miniaturki';
$txt['attachment_thumbnail_settings'] = 'Ustawienia miniaturek';
$txt['attachment_security_settings'] = 'Ustawienia bezpieczeństwa załączników';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Nie istnieje';
$txt['attach_dir_not_writable'] = 'Niezapisywalny';
$txt['attach_dir_files_missing'] = 'Brakujące pliki (<a href="{repair_url}">napraw</a>)';
$txt['attach_dir_unused'] = 'Nieużywany';
$txt['attach_dir_empty'] = 'Puste';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Katalog bazowy';

$txt['attach_dir_desc'] = 'Poniżej możesz tworzyć nowe katalogi lub zmienić obecny katalog. Katalogi mają możliwość zmiany nazwy, jeśli nie zawierają katalogu podrzędnego. Jeśli chcesz utworzyć nowy katalog w należy podać nazwę katalogu. Aby usunąć katalog wyczyść pole ścieżki. Katalogi nie mogą być usunięte, jeśli zawierają pliki lub katalogi podrzędne (pokazane w nawiasie obok liczby plików).';
$txt['attach_dir_base_desc'] = 'Tutaj możesz zmienić obecny katalog bazowy lub utworzyć nowy. Nowe katalogi bazowe zostają dodane do listy katalogów załączników. Możesz także wybrać istniejący katalog jako bazowy.';
$txt['attach_dir_save_problem'] = 'Ups, wydaje się, że wystąpił problem.';
$txt['attachments_no_create'] = 'Nie można utworzyć nowego katalogu załączników. Zrób to używając klienta FTP lub menadżera plików strony.';
$txt['attachments_no_write'] = 'Katalog został utworzony, ale nie można w nim zapisywać. Spróbuj naprawić to używając klienta FTP lub menadżera plików strony.';
$txt['attach_dir_reserved'] = 'Nie można dodać. Katalog jest katalogiem systemowym i nie może być użyty dla załączników.';
$txt['attach_dir_duplicate_msg'] = 'Nie można dodać. Katalog już istnieje.';
$txt['attach_dir_exists_msg'] = 'Nie można przenieść. Katalog już istnieje w miejscu docelowym.';
$txt['attach_dir_base_dupe_msg'] = 'Nie można dodać. Katalog bazowy został już utworzony.';
$txt['attach_dir_base_no_create'] = 'Nie można utworzyć. Zweryfikuj podaną ścieżkę lub utwórz katalog przez klienta FTP lub menadżera plików strony.';
$txt['attach_dir_no_rename'] = 'Nie można przenieść lub zmienić nazwy. Zweryfikuj poprawność ścieżki oraz że katalog nie zawiera żadnych katalogów podrzędnych.';
$txt['attach_dir_no_delete'] = 'Nie jest pusty i nie może zostać usunięty. Użyj klienta FTP lub menadżera plików strony.';
$txt['attach_dir_no_remove'] = 'Wciąż zawiera pliki lub jest katalogiem bazowym i nie może zostać usunięty.';
$txt['attach_dir_is_current'] = 'Nie można usunąć, gdy jest wybrany jako obecny katalog.';
$txt['attach_dir_is_current_bd'] = 'Nie można usunąć, gdy jest wybrany jako główny katalog bazowy.';
$txt['attach_last_dir'] = 'Ostatni aktywny katalog załączników';
$txt['attach_current_dir'] = 'Obecny katalog załączników';
$txt['attach_current'] = 'Obecny';
$txt['attach_path_manage'] = 'Zarządzaj ścieżkami załączników';
$txt['attach_directories'] = 'Katalogi załączników';
$txt['attach_paths'] = 'Ścieżki katalogów załączników';
$txt['attach_path'] = 'Ścieżka';
$txt['attach_current_size'] = 'Rozmiar (KiB)';
$txt['attach_num_files'] = 'Pliki';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Dodaj ścieżkę';
$txt['attach_path_current_bad'] = 'Nieprawidłowa ścieżka załączników';
$txt['attachmentDirFileLimit'] = 'Maksymalna ilość plików w katalogu';

$txt['attach_base_paths'] = 'Ścieżka katalogu bazowego';
$txt['attach_num_dirs'] = 'Katalogi';
$txt['max_image_width'] = 'Maksymalna szerokość wysłanych w wiadomości lub załączonych obrazów';
$txt['max_image_height'] = 'Maksymalna wysokość wysłanych w wiadomości lub załączonych obrazów';

$txt['automanage_attachments'] = 'Wybierz metodę zarządzania katalogami załączników';
$txt['attachments_normal'] = '(Ręczna) Domyślne zachowanie ElkArte';
$txt['attachments_auto_years'] = '(Automatyczne) Podziel na lata';
$txt['attachments_auto_months'] = '(Automatyczne) Podziel na lata i miesiące';
$txt['attachments_auto_days'] = '(Automatyczne) Podziel na lata, miesiące i dni';
$txt['attachments_auto_16'] = '(Automatyczne) 16 losowych katalogów';
$txt['attachments_auto_16x16'] = '(Automatyczne) 16 losowych katalogów z 16 katalogami podrzędnymi';
$txt['attachments_auto_space'] = '(Automatyczne) Gdy katalog osiągnie maksymalny rozmiar';

$txt['use_subdirectories_for_attachments'] = 'Utwórz nowe katalogi w katalogu bazowym';
$txt['use_subdirectories_for_attachments_note'] = 'W przeciwnym wypadku nowe katalogi będą utworzone w głównym katalogu forum.';
$txt['basedirectory_for_attachments'] = 'Ustaw katalog bazowy załączników';
$txt['basedirectory_for_attachments_current'] = 'Obecny katalog bazowy';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Ten katalog nie jest poprawny. <br />(<a href="{attach_repair_url}">Spróbuj naprawić</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">Wystąpił problem z katalogiem. <br />(<a href="{attach_repair_url}">Spróbuj naprawić</a>)</div>';

$txt['attachment_transfer'] = 'Transferuj załączniki';
$txt['attachment_transfer_desc'] = 'Transferuj pliki pomiędzy katalogami.';
$txt['attachment_transfer_select'] = 'Wybierz katalog';
$txt['attachment_transfer_now'] = 'Transferuj';
$txt['attachment_transfer_from'] = 'Transferuj pliki z';
$txt['attachment_transfer_auto'] = 'Przenieś je automatycznie, według rozmiaru lub ilości plików';
$txt['attachment_transfer_auto_select'] = 'Wybierz katalog bazowy';
$txt['attachment_transfer_to'] = 'lub przenieś do konkretnego katalogu.';
$txt['attachment_transfer_empty'] = 'Przenieś wszystkie pliki z katalogu źródłowego.';
$txt['attachment_transfer_no_base'] = 'Nie ma dostępnych katalogów bazowych.';
$txt['attachment_transfer_forum_root'] = 'Główny katalog forum.';
$txt['attachment_transfer_no_room'] = 'Osiągnięto maksymalny rozmiar katalogu lub limit ilości plików.';
$txt['attachment_transfer_no_find'] = 'Nie znaleziono plików do przeniesienia.';
$txt['attachments_transfered'] = '%1$d plików zostało przeniesionych do %2$s';
$txt['attachments_not_transfered'] = '%1$d plików nie zostało przeniesionych.';
$txt['attachment_transfer_no_dir'] = 'Nie wybrano katalogu źródłowego lub katalogu docelowego.';
$txt['attachment_transfer_same_dir'] = 'Nie możesz wybrać tego samego katalogu jako źródłowego i docelowego.';
$txt['attachment_transfer_progress'] = 'Proszę czekać. Trwa transfer.';

$txt['avatar_settings'] = 'Ogólne ustawienia awatarów';
$txt['avatar_default'] = 'Włącz domyślny awatar dla użytkowników, którzy nie wybrali własnego';
$txt['avatar_directory'] = 'Katalog awatarów';
$txt['avatar_url'] = 'URL awatarów';
$txt['avatar_max_width'] = 'Maksymalna szerokość awatarów w pikselach (px)';
$txt['avatar_max_height'] = 'Maksymalna wysokość awatarów w pikselach (px)';
$txt['avatar_action_too_large'] = 'Jeśli awatar jest za duży...';
$txt['option_refuse'] = 'Odrzuć go';
$txt['option_resize'] = 'Pozwól CSS na zmianę rozmiaru';
$txt['option_download_and_resize'] = 'Pobierz go i zmień rozmiar (wymaga modułu GD lub ImageMagick)';
$txt['gravatar'] = 'Gravatary';
$txt['avatar_gravatar_enabled'] = 'Włącz użycie gravatar';
$txt['gravatar_rating'] = 'Ocena Gravatara';
$txt['avatar_download_png'] = 'Użyj formatu PNG dla zmniejszonych awatarów';
$txt['avatar_img_enc_warning'] = 'Nie wykryto modułu GD i ImageMagick. Niektóre opcje związane z awatarami nie będą dostępne.';
$txt['avatar_external'] = 'Zewnętrzne awatary';
$txt['avatar_external_enabled'] = 'Włącz możliwość używania zewnętrznych awaratów';
$txt['avatar_upload'] = 'Wysłane awatary';
$txt['avatar_resize_options'] = 'Ustawienia pobranych awatarów';
$txt['avatar_upload_enabled'] = 'Włącz wysyłanie awatarów';
$txt['avatar_server_stored'] = 'Awatary przechowywane na serwerze';
$txt['avatar_stored_enabled'] = 'Włącz wybieranie awatarów, które są przechowywane na serwerze.';
$txt['profile_set_avatar'] = 'Grupy użytkowników mogące wybrać awatar.';
$txt['avatar_select_permission'] = 'Ustaw zezwolenia dla każdej grupy';
$txt['avatar_download_external'] = 'Pobieraj awatary z podanego adresu';
$txt['custom_avatar_enabled'] = 'Pobieraj awatary do...';
$txt['option_attachment_dir'] = 'Katalogu załączników';
$txt['option_specified_dir'] = 'Określonego katalogu...';
$txt['custom_avatar_dir'] = 'Katalog wysyłania';
$txt['custom_avatar_dir_desc'] = 'Powinien to być poprawny katalog z możliwością zapisu, inny niż katalog główny serwera.';
$txt['custom_avatar_url'] = 'URL wysyłania';
$txt['custom_avatar_check_empty'] = 'Wybrany katalog awatarów może być pusty albo niepoprawny. Upewnij się, że te ustawienia są poprawne.';
$txt['avatar_reencode'] = 'Ponowne kodowanie potencjalnie niebezpiecznych awatarów';
$txt['avatar_reencode_note'] = '(wymagany moduł GD)';
$txt['avatar_paranoid_warning'] = 'Przeprowadzenie kontroli bezpieczeństwa może doprowadzić do odrzucenia dużej liczby awatarów.';
$txt['avatar_paranoid'] = 'Przeprowadzenie kontroli bezpieczeństwa przesłanych awatarów';

$txt['repair_attachments'] = 'Napraw załączniki';
$txt['repair_attachments_complete'] = 'Naprawa zakończona';
$txt['repair_attachments_complete_desc'] = 'Wszystkie zaznaczone błędy zostały usunięte';
$txt['repair_attachments_no_errors'] = 'Nie znaleziono błędów';
$txt['repair_attachments_error_desc'] = 'Podczas konserwacji wykryto następujące błędy. Zaznacz te które chcesz naprawić i kliknij kontynuuj.';
$txt['repair_attachments_continue'] = 'Kontynuuj';
$txt['repair_attachments_cancel'] = 'Anuluj';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d miniatury nie posiadają oryginalnego załącznika';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d załączonych obrazków nie ma miniaturek';
$txt['attach_repair_file_missing_on_disk'] = '%1$d załączników/awatarów istnieje w bazie, ale nie ma ich na serwerze';
$txt['attach_repair_file_wrong_size'] = '%1$d załączników/awatarów ma źle opisany rozmiar pliku';
$txt['attach_repair_file_size_of_zero'] = '%1$d załączników/awatarów ma zerowy rozmiar na dysku (zostaną usunięte)';
$txt['attach_repair_attachment_no_msg'] = '%1$d załączników nie jest powiązanych z żadnymi wiadomościami';
$txt['attach_repair_avatar_no_member'] = '%1$d awatarów nie jest powiązanych z żadnym użytkownikiem';
$txt['attach_repair_wrong_folder'] = '%1$d załączników jest w złym katalogu';
$txt['attach_repair_missing_extension'] = '%1$d załączników ma niepoprawne rozszerzenie i może znajdować się w złym katalogu';
$txt['attach_repair_files_without_attachment'] = '%1$d plików nie posiada wpisu w bazie danych (zostaną one usunięte).';

$txt['news_title'] = 'Aktualności i newslettery';
$txt['news_settings_desc'] = 'Tutaj możesz zmieniać ustawienia i uprawnienia związane z aktualnościami oraz newsletterami.';
$txt['news_mailing_desc'] = 'Z tego menu można wysyłać wiadomości do wszystkich zarejestrowanych na forum użytkowników, którzy podali adres email. Użyteczne podczas wysyłania ogłoszeń.';
$txt['news_error_no_news'] = 'Nie ma nic do podejrzenia';
$txt['groups_edit_news'] = 'Grupy uprawnione do edycji aktualności';
$txt['groups_send_mail'] = 'Grupy uprawnione do rozsyłania newsletterów';
$txt['xmlnews_enable'] = 'Włącz aktualności XML/RSS';
$txt['xmlnews_maxlen'] = 'Maksymalna długość wiadomości';
$txt['xmlnews_limit'] = 'Limit XML/RSS';
$txt['xmlnews_limit_note'] = 'Ilość wiadomości w kanale RSS';
$txt['xmlnews_maxlen_note'] = '(0 aby wyłączyć, zły pomysł.)';
$txt['editnews_clickadd'] = 'Dodaj kolejny';
$txt['editnews_remove_selected'] = 'Usuń zaznaczone';
$txt['editnews_remove_confirm'] = 'Na pewno chcesz usunąć zaznaczone aktualności?';
$txt['censor_clickadd'] = 'Dodaj kolejne słowo';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Logi';
$txt['generate_reports'] = 'Raporty';

$txt['update_available'] = 'Aktualizuj dostępne';
$txt['update_message'] = 'Używasz nieaktualnej wersji ElkArte, która zawiera błędy poprawione w najnowszej wersji.  
	Zalecamy wykonanie <a href="#" id="update-link">aktualizacji forum</a> do najnowszej wersji najszybciej jak to tylko jest możliwe. Zajmie to tylko minutę!';

$txt['manageposts'] = 'Wiadomości i tematy';
$txt['manageposts_title'] = 'Zarządzanie wiadomościami i tematami';
$txt['manageposts_description'] = 'Tu możesz zarządzać wszystkimi ustawieniami odnoszącymi się do tematów i wiadomości.';

$txt['manageposts_seconds'] = 'sekund';
$txt['manageposts_minutes'] = 'minut';
$txt['manageposts_characters'] = 'znaków';
$txt['manageposts_days'] = 'dni';
$txt['manageposts_posts'] = 'wiadomości';
$txt['manageposts_topics'] = 'tematy';

$txt['pollMode'] = 'Włącz ankiety';

$txt['manageposts_settings'] = 'Ustawienia wiadomości';
$txt['manageposts_settings_description'] = 'Tutaj możesz zarządzać wszystkimi ustawieniami, które dotyczą tworzenia wiadomości i ich wysyłania.';

$txt['manageposts_bbc_settings'] = 'Bulletin Board Code';
$txt['manageposts_bbc_settings_description'] = 'Znaczniki Bulletin Board Code mogą być używane do formatowania tekstu wiadomości. Na przykład, aby pogrubić słowo \'dom\' wpisz [b]dom[/b]. Wszystkie znaczniki BBC są umieszczane wewnątrz nawiasów kwadratowych (\'[\' i \']\').';
$txt['manageposts_bbc_settings_title'] = 'Ustawienia Bulletin Board Code';

$txt['manageposts_topic_settings'] = 'Ustawienia tematów';
$txt['manageposts_topic_settings_description'] = 'Tu możesz zmienić opcje związane z tematami.';

$txt['managedrafts_settings'] = 'Ustawienia szkiców';
$txt['managedrafts_settings_description'] = 'Tutaj możesz zmieniać ustawienia dotyczące szkiców.';
$txt['manage_drafts'] = 'Szkice';

$txt['mail_center'] = 'Centrum listy mailingowej';
$txt['mm_emailerror'] = 'Błędy wiadomości email';
$txt['mm_emailfilters'] = 'Filtry';
$txt['mm_emailparsers'] = 'Parsery';
$txt['mm_emailtemplates'] = 'Szablony';
$txt['mm_emailsettings'] = 'Ustawienia';

$txt['removeNestedQuotes'] = 'Usuń zagnieżdżone cytaty podczas cytowania';
$txt['enableSpellChecking'] = 'Włącz sprawdzanie pisowni';
$txt['enableSpellChecking_warning'] = 'Nie działa na niektórych serwerach.';
$txt['enableSpellChecking_error'] = 'Nie działa na twoim serwerze.';
$txt['enableVideoEmbeding'] = 'Włącz automatyczne wstawianie filmów z linków.';
$txt['enableCodePrettify'] = 'Włącz upiększanie tagu code';
$txt['max_messageLength'] = 'Maksymalny rozmiar wiadomości';
$txt['max_messageLength_zero'] = '0 dla braku ograniczeń';
$txt['convert_to_mediumtext'] = 'Twoja baza danych nie jest w stanie zaakceptować wiadomości dłuższych niż 65535 znaków. Użyj funkcji dostępnej w <a href="%1$s">menu konserwacji bazy danych</a> w celu konwersji tabeli, a następnie wróć, aby zwiększyć maksymalny rozmiar wiadomości.';
$txt['topicSummaryPosts'] = 'Ilość wiadomości w podsumowaniu tematu';
$txt['spamWaitTime'] = 'Czas wymagany pomiędzy wiadomościami z tego samego adresu IP';
$txt['edit_wait_time'] = 'Czas utajonej edycji';
$txt['edit_disable_time'] = 'Przez jaki czas od wysłania wiadomości możliwa jest jej edycja';
$txt['edit_disable_time_zero'] = '0 aby wyłączyć';
$txt['preview_characters'] = 'Maksymalna długość podglądu ostatniej/pierwszej wiadomości';
$txt['preview_characters_units'] = 'znaków';
$txt['preview_characters_zero'] = '0 aby pokazać całą wiadomość';
$txt['message_index_preview'] = 'Pokaż podgląd wiadomości w indeksie tematów';
$txt['message_index_preview_off'] = 'Nie pokazuj podglądów';
$txt['message_index_preview_first'] = 'Pokaż treść pierwszej wiadomości';
$txt['message_index_preview_last'] = 'Pokaż treść ostatniej wiadomości';

$txt['enableBBC'] = 'Włącz bulletin board code (BBC)';
$txt['enablePostHTML'] = 'Włącz <em>prosty</em> HTML w wiadomościach';
$txt['autoLinkUrls'] = 'Automatycznie linkuj wysłane w wiadomości adresy';
$txt['disabledBBC'] = 'Włącz tagi BBC';
$txt['bbcTagsToUse'] = 'Włącz tagi BBC';
$txt['bbcTagsToUse_select'] = 'Wybierz tagi dozwolone do użycia';
$txt['bbcTagsToUse_select_all'] = 'Zaznacz wszystkie znaczniki';

$txt['enableParticipation'] = 'Włącz ikony uczestnictwa';
$txt['enableFollowup'] = 'Włącz powiązania';
$txt['enable_unwatch'] = 'Włącz ignorowanie tematów';
$txt['oldTopicDays'] = 'Czas po którym temat zostanie oznaczony jako stary przy odpowiedzi';
$txt['oldTopicDays_zero'] = '0 aby wyłączyć';
$txt['defaultMaxTopics'] = 'Maksymalna ilość tematów na stronę';
$txt['defaultMaxMessages'] = 'Maksymalna ilość wiadomości na stronę';
$txt['disable_print_topic'] = 'Wyłącz funkcję drukowania tematu';
$txt['hotTopicPosts'] = 'Ilość wiadomości w popularnym temacie';
$txt['hotTopicVeryPosts'] = 'Ilość wiadomości w bardzo popularnym temacie';
$txt['useLikesNotViews'] = 'Użyj ilość polubień zamiast ilości wiadomości dla oceny gorącego tematu';
$txt['enableAllMessages'] = 'Maksymalna ilość odpowiedzi w temacie pozwalająca na włączenie funkcji "Pokaż wszystkie"';
$txt['enableAllMessages_zero'] = '0 aby wyłączyć';
$txt['disableCustomPerPage'] = 'Wyłącz użytkownikom możliwość dostosowania ilości tematów/wiadomości na stronę';
$txt['enablePreviousNext'] = 'Włącz odnośniki do poprzedniego/następnego tematu';

$txt['not_done_title'] = 'Jeszcze nie skończono';
$txt['not_done_reason'] = 'Aby uniknąć przeciążenia serwera proces został chwilowo wstrzymany. Powinien zostać automatycznie wznowiony za kilka sekund. Jeśli tak się nie stanie proszę kliknąć kontynuuj.';
$txt['not_done_continue'] = 'Kontynuuj';

$txt['general_settings'] = 'Główne';
$txt['database_paths_settings'] = 'Baza danych i ścieżki';
$txt['cookies_sessions_settings'] = 'Ciasteczka i sesje';
$txt['caching_settings'] = 'Cache';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'Informacje o PHP';
$txt['phpinfo_localsettings'] = 'Ustawienia lokalne';
$txt['phpinfo_defaultsettings'] = 'Ustawienia domyślne';
$txt['phpinfo_itemsettings'] = 'Ustawienia';

$txt['language_configuration'] = 'Języki';
$txt['language_description'] = 'Ta sekcja pozwala na edytowanie zainstalowanych plików językowych i pobieranie nowych ze strony ElkArte. Możesz także zmienić ustawienia dotyczące języków.';
$txt['language_edit'] = 'Edytuj język';
$txt['language_add'] = 'Dodaj język';
$txt['language_settings'] = 'Ustawienia';

$txt['advanced'] = 'Zaawansowane';
$txt['simple'] = 'Proste';

$txt['admin_news_select_recipients'] = 'Wybierz kto ma otrzymywać kopię newslettera';
$txt['admin_news_select_group'] = 'Grupy użytkowników';
$txt['admin_news_select_group_desc'] = 'Wybierz grupy które mają otrzymać newsletter.';
$txt['admin_news_select_members'] = 'Użytkownicy';
$txt['admin_news_select_members_desc'] = 'Dodatkowi użytkownicy do których wysłać newsletter.';
$txt['admin_news_select_excluded_members'] = 'Użytkownicy wykluczeni';
$txt['admin_news_select_excluded_members_desc'] = 'Użytkownicy którzy nie powinni otrzymać newslettera.';
$txt['admin_news_select_excluded_groups'] = 'Wykluczone grupy';
$txt['admin_news_select_excluded_groups_desc'] = 'Wybierz grupy które definitywnie nie powinny otrzymać newslettera.';
$txt['admin_news_select_email'] = 'Adresy email';
$txt['admin_news_select_email_desc'] = 'Rozdzielona średnikami lista adresów email na które powinien zostać wysłany newsletter  (np. adres1; adres2).';
$txt['admin_news_select_override_notify'] = 'Ignoruj ustawienia powiadomień';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Nie możesz wysłać prywatnej wiadomości na adres email. Jeśli kontynuujesz wszystkie wprowadzone adresy email zostaną zignorowane.\\n\\nNa pewno chcesz to zrobić?';

$txt['mailqueue_browse'] = 'Przeglądaj kolejkę';
$txt['mailqueue_settings'] = 'Ustawienia';

$txt['admin_search'] = 'Szybkie wyszukiwanie';
$txt['admin_search_type_internal'] = 'Zadania/opcje';
$txt['admin_search_type_member'] = 'Użytkownik';
$txt['admin_search_type_online'] = 'Podręcznik online';
$txt['admin_search_go'] = 'Idź';
$txt['admin_search_results'] = 'Wyniki wyszukiwania';
$txt['admin_search_results_desc'] = 'Wyniki wyszukiwania: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Szukaj ponownie';
$txt['admin_search_results_none'] = 'Nie znaleziono wyników.';

$txt['admin_search_section_sections'] = 'Sekcja';
$txt['admin_search_section_settings'] = 'Opcja';

$txt['core_settings_title'] = 'Cechy podstawowe';
$txt['core_settings_desc'] = 'Ta strona pozwala na włączenie lub wyłączenie opcjonalnych funkcji forum.';
$txt['mods_cat_features'] = 'Główne';
$txt['mods_cat_security_general'] = 'Główne';
$txt['antispam_title'] = 'Anty-spam';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Różne';
$txt['mods_cat_layout'] = 'Układ';
$txt['karma'] = 'Reputacja';
$txt['moderation_settings_short'] = 'Moderacja';
$txt['signature_settings_short'] = 'Podpisy';
$txt['custom_profile_shorttitle'] = 'Pola profilów';
$txt['pruning_title'] = 'Czyszczenie logów';

$txt['core_settings_activation_message'] = 'Funkcja {core_feature} została aktywowana, aby ją skonfigurować kliknij na jej tytuł.';
$txt['core_settings_deactivation_message'] = 'Funkcja {core_feature} została wyłączona.';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Modyfikuj działy';
$txt['mboards_new_cat'] = 'Utwórz nową kategorię';
$txt['manage_holidays'] = 'Zarządzaj wydarzeniami';
$txt['calendar_settings'] = 'Opcje kalendarza';
$txt['search_weights'] = 'Wagi';
$txt['search_method'] = 'Metoda wyszukiwania';
$txt['search_sphinx'] = 'Konfiguracja Sphinx';

$txt['smiley_sets'] = 'Zestawy emotikon';
$txt['smileys_add'] = 'Dodaj emotikony';
$txt['smileys_edit'] = 'Edytuj emotikony';
$txt['smileys_set_order'] = 'Ustaw kolejność emotikon';
$txt['icons_edit_message_icons'] = 'Edytuj ikony wiadomości';

$txt['membergroups_new_group'] = 'Dodaj grupę użytkowników';
$txt['membergroups_edit_groups'] = 'Edytuj grupę użytkowników';
$txt['permissions_groups'] = 'Ogólne zezwolenia';
$txt['permissions_boards'] = 'Zezwolenia działów';
$txt['permissions_profiles'] = 'Edytuj profile';
$txt['permissions_post_moderation'] = 'Moderacja wiadomości';

$txt['browse_packages'] = 'Przeglądaj pakiety';
$txt['download_packages'] = 'Pobierz pakiety';
$txt['upload_packages'] = 'Wyślij pakiet';
$txt['installed_packages'] = 'Zainstalowane pakiety';
$txt['package_file_perms'] = 'Zezwolenia plików';
$txt['package_settings'] = 'Ustawienia';
$txt['package_servers'] = 'Serwery pakietów';
$txt['themeadmin_admin_title'] = 'Zarządzaj i instaluj';
$txt['themeadmin_list_title'] = 'Ustawienia stylów';
$txt['themeadmin_reset_title'] = 'Opcje użytkowników';
$txt['themeadmin_edit_title'] = 'Modyfikuj style';
$txt['admin_browse_register_new'] = 'Zarejestruj nowego użytkownika';

$txt['search_engines'] = 'Silniki wyszukiwarek';
$txt['spider_logs'] = 'Logi robotów';
$txt['spider_stats'] = 'Statystyki';

$txt['paid_subscriptions'] = 'Płatna subskrypcja';
$txt['paid_subs_view'] = 'Pokaż subskrypcje';

$txt['maintain_sub_hooks_list'] = 'Haki integracyjne';
$txt['hooks_field_hook_name'] = 'Nazwa haka';
$txt['hooks_field_function_name'] = 'Nazwa funkcji';
$txt['hooks_field_function'] = 'Funkcja';
$txt['hooks_field_included_file'] = 'Załączony plik';
$txt['hooks_field_file_name'] = 'Nazwa pliku';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Istnieje';
$txt['hooks_disabled'] = 'Wyłączony'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Nie znaleziono';
$txt['hooks_no_hooks'] = 'Obecnie nie ma żadnych haków w systemie.';
$txt['hooks_disable_legend'] = 'Legenda';
$txt['hooks_disable_legend_exists'] = 'hak istnieje i jest aktywny';
$txt['hooks_disable_legend_disabled'] = 'hak istnieje, ale został wyłączony';
$txt['hooks_disable_legend_missing'] = 'nie znaleziono haka';
$txt['hooks_reset_filter'] = 'Resetuj filtr';

$txt['board_perms_allow'] = 'Zezwól';
$txt['board_perms_ignore'] = 'Ignoruj';
$txt['board_perms_deny'] = 'Nie zezwalaj';
$txt['all_boards_in_cat'] = 'Wszystkie działy w kategorii';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Separator słów';

$txt['admin_order_title'] = 'Błąd sortowania';
$txt['admin_order_error'] = 'Podczas przetwarzania żądania wystąpił nieznany błąd';

// Known controllers that can work on the front page
$txt['default'] = 'Domyślny';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
