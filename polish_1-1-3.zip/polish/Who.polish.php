<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... nie mam pojęcia</em>';
$txt['who_admin'] = 'Przegląda centrum administracji';
$txt['who_moderate'] = 'Przegląda centrum moderacji';
$txt['who_generic'] = 'Przegląda %1$s';
$txt['who_unknown'] = '<em>Nieznana czynność</em>';
$txt['who_user'] = 'Użytkownik';
$txt['who_time'] = 'Czas';
$txt['who_action'] = 'Akcja';
$txt['who_show1'] = 'Pokaż ';
$txt['who_show_members_only'] = 'Tylko użytkownicy';
$txt['who_show_guests_only'] = 'Tylko goście';
$txt['who_show_spiders_only'] = 'Tylko roboty';
$txt['who_show_all'] = 'Wszyscy';
$txt['who_no_online_spiders'] = 'Obecnie na forum nie ma żadnych robotów.';
$txt['who_no_online_guests'] = 'Obecnie na forum nie ma żadnych gości.';
$txt['who_no_online_members'] = 'Obecnie na forum nie ma żadnych użytkowników.';

$txt['whospider_login'] = 'Przegląda stronę logowania.';
$txt['whospider_register'] = 'Przegląda stronę rejestracyjną.';
$txt['whospider_reminder'] = 'Przegląda stronę przypomnień.';

$txt['whoall_activate'] = 'Aktywuje swoje konto.';
$txt['whoall_buddy'] = 'Modyfikuje listę znajomych.';
$txt['whoall_coppa'] = 'Wypełnia formularz zgody rodzica/opiekuna.';
$txt['whoall_credits'] = 'Przegląda stronę z podziękowaniami.';
$txt['whoall_emailuser'] = 'Wyślij email do innego użytkownika.';
$txt['whoall_groups'] = 'Przegląda stronę grup użytkownika.';
$txt['whoall_help'] = 'Przegląda <a href="{help_url}">stronę pomocy</a>.';
$txt['whoall_quickhelp'] = 'Przegląda okienko pomocy.';
$txt['whoall_pm'] = 'Przegląda prywatne wiadomości.';
$txt['whoall_auth'] = 'Loguje się na forum.';
$txt['whoall_login'] = 'Przegląda stronę logowania.';
$txt['whoall_login2'] = 'Przegląda stronę logowania.';
$txt['whoall_logout'] = 'Wylogowuje się z forum.';
$txt['whoall_markasread'] = 'Zaznacza tematy jako przeczytane lub nieprzeczytane.';
$txt['whoall_mentions'] = 'Przegląda listę oznaczeń.';
$txt['whoall_modifykarma_applaud'] = 'Dodaje pozytywną reputację użytkownikowi.';
$txt['whoall_modifykarma_smite'] = 'Dodaje negatywną reputację użytkownikowi.';
$txt['whoall_news'] = 'Przegląda aktualności.';
$txt['whoall_notify'] = 'Zmienia ustawienia powiadamiania.';
$txt['whoall_notifyboard'] = 'Zmienia ustawienia powiadamiania.';
$txt['whoall_openidreturn'] = 'Loguje się używając OpenID.';
$txt['whoall_quickmod'] = 'Moderuje dział.';
$txt['whoall_recent'] = 'Przegląda <a href="{recent_url}">listę najnowszych tematów</a>.';
$txt['whoall_register'] = 'Rejestruje konto na forum.';
$txt['whoall_reminder'] = 'Prosi o przypomnienie hasła.';
$txt['whoall_reporttm'] = 'Zgłasza wiadomość do moderatora.';
$txt['whoall_spellcheck'] = 'Używa sprawdzania pisowni';
$txt['whoall_unread'] = 'Przegląda tematy nieprzeczytane od ostatniej wizyty.';
$txt['whoall_unreadreplies'] = 'Przegląda odpowiedzi nieprzeczytane od ostatniej wizyty.';
$txt['whoall_who'] = 'Przegląda <a href="{who_url}">listę zalogowanych użytkowników</a>.';

$txt['whoall_collapse_collapse'] = 'Zwija kategorię.';
$txt['whoall_collapse_expand'] = 'Rozwija kategorię.';
$txt['whoall_pm_removeall'] = 'Usuwa wszystkie prywatne wiadomości.';
$txt['whoall_pm_send'] = 'Wysyła prywatną wiadomość.';
$txt['whoall_pm_send2'] = 'Wysyła prywatną wiadomość.';

$txt['whotopic_announce'] = 'Ogłasza temat &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Zatwierdza załącznik.';
$txt['whotopic_dlattach'] = 'Ogląda załącznik.';
$txt['whotopic_deletemsg'] = 'Usuwa wiadomość.';
$txt['whotopic_editpoll'] = 'Edytuje ankietę w &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Edytuje ankietę w &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Edytuje wiadomość w &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Dodaje "Lubię to" w wiadomości w temacie &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Zamyka temat &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Zamyka ankietę w &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Łączy temat &quot;<a href="%1$s">%2$s</a>&quot; z innym tematem.';
$txt['whotopic_movetopic'] = 'Przenosi temat &quot;<a href="%1$s">%2$s</a>&quot; do innego działu.';
$txt['whotopic_movetopic2'] = 'Przenosi temat &quot;<a href="%1$s">%2$s</a>&quot; do innego działu.';
$txt['whotopic_post'] = 'Wysyła wiadomość w <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Wysyła wiadomość w <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Drukuje temat &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderuje temat <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Usuwa ankietę w &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Usuwa temat <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Wysyła temat &quot;<a href="%1$s">%2$s</a>&quot; do przyjaciela.';
$txt['whotopic_splittopics'] = 'Rozdziela temat &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_sticky'] = 'Przykleja temat &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Przestał obserwować temat.';
$txt['whotopic_vote'] = 'Głosuje w ankiecie w <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Rozpoczął obserwowanie tematu.';

$txt['whopost_quotefast'] = 'Cytuje wiadomość z &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Modyfikuję umowę rejestracyjną.';
$txt['whoadmin_featuresettings'] = 'Modyfikuje funkcje i opcje forum.';
$txt['whoadmin_modlog'] = 'Przegląda raport moderacji.';
$txt['whoadmin_serversettings'] = 'Modyfikuje ustawienia forum.';
$txt['whoadmin_packageget'] = 'Pobiera listę pakietów.';
$txt['whoadmin_packages'] = 'Przegląda manager pakietów.';
$txt['whoadmin_permissions'] = 'Modyfikuje zezwolenia forum.';
$txt['whoadmin_pgdownload'] = 'Pobiera pakiet.';
$txt['whoadmin_theme'] = 'Modyfikuje ustawienia stylu.';
$txt['whoadmin_trackip'] = 'Śledzi adres IP.';

$txt['whoallow_manageboards'] = 'Modyfikuje ustawienia działów i kategorii.';
$txt['whoallow_admin'] = 'Przegląda <a href="{admin_url}">centrum administracji</a>.';
$txt['whoallow_ban'] = 'Modyfikuje listę banów.';
$txt['whoallow_boardrecount'] = 'Przelicza statystyki forum.';
$txt['whoallow_calendar'] = 'Przegląda <a href="{calendar_url}">kalendarz</a>.';
$txt['whoallow_editnews'] = 'Modyfikuje aktualności.';
$txt['whoallow_mailing'] = 'Wysyła email przez forum.';
$txt['whoallow_maintain'] = 'Przeprowadza rutynowe czynności administracyjne.';
$txt['whoallow_manageattachments'] = 'Zarządza załącznikami.';
$txt['whoallow_moderate'] = 'Przegląda <a href="{moderate_url}">centrum moderacji</a>.';
$txt['whoallow_memberlist'] = 'Przegląda <a href="{memberlist_url}">listę użytkowników</a>.';
$txt['whoallow_optimizetables'] = 'Optymalizuje tabele bazy danych.';
$txt['whoallow_repairboards'] = 'Naprawia tabele bazy danych.';
$txt['whoallow_search'] = 'Używa <a href="{search_url}">wyszukiwarki</a> na forum.';
$txt['whoallow_search_results'] = 'Przegląda wyniki wyszukiwania.';
$txt['whoallow_setcensor'] = 'Modyfikuje ustawienia cenzury.';
$txt['whoallow_setreserve'] = 'Modyfikuje zarezerwowane nazwy.';
$txt['whoallow_stats'] = 'Przegląda <a href="{stats_url}">statystyki forum</a>.';
$txt['whoallow_viewErrorLog'] = 'Przegląda raport błędów.';
$txt['whoallow_viewmembers'] = 'Przegląda listę użytkowników.';

$txt['who_topic'] = 'Przegląda temat <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Przegląda dział <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Przegląda stronę główną <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Przegląda profil użytkownika <a href="%1$s">%2$s</a>.';
$txt['who_profile'] = 'Edytuje profil użytkownika <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Wysyła nowy temat w <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Wysyła nową ankietę w <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Wysyła nowy temat przez email w <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Wysyła wiadomość przez email w <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Wysyła prywatną wiadomość przez email.';

// Credits text
$txt['credits'] = 'Twórcy';
$txt['credits_intro'] = 'ElkArte jest w 100% darmowym i otwartym oprogramowaniem. Aktywnie wspieramy oraz akceptujemy wkład społeczności. Chcemy podziękować wszystkim którzy wspierali projekt w postaci pisania kodu, opinii, raportowali błędy, ponieważ to wszystko nie byłoby możliwe bez was. Podziękowania należą się również <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a> - projektowi z którego narodziło się ElkArte.';
$txt['credits_contributors'] = 'Twórcy';
$txt['credits_and'] = 'i';
$txt['credits_copyright'] = 'Prawa autorskie';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Dodatki';
$txt['credits_software_graphics'] = 'Oprogramowanie i grafiki';
$txt['credits_software'] = 'Oprogramowanie';
$txt['credits_graphics'] = 'Grafiki';
$txt['credits_fonts'] = 'Czcionki';
$txt['credits_groups_contrib'] = 'Twórcy';
$txt['credits_contrib_list'] = 'Pełną listę osób, które przyczyniły się do stworzenia ElkArte znajdziesz na <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">oficjalnej liście twórców</a> w serwisie GitHub.';
$txt['credits_license'] = 'Licencja';
$txt['credits_copyright'] = 'Prawa autorskie';
$txt['credits_version'] = 'Wersja';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Tłumacze językowi';
$txt['credits_translators_message'] = 'Dziękujemy za wasze wysiłki, które umożliwiają ludziom na całym świecie używanie ElkArte.  Pełną listę tłumaczy znajdziesz na <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">oficjalnej stronie projektu</a> w serwisie Transifex.';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';