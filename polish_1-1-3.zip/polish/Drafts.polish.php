<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Pokaż szkice';
$txt['drafts_show_desc'] = 'Tutaj widoczne są wszystkie obecnie zapisane szkice. Możesz je edytować przed wysłaniem lub usunąć je.';

// misc
$txt['drafts'] = 'Szkice';
$txt['draft_save'] = 'Zapisz szkic';
$txt['draft_save_note'] = 'Ta opcja zapisze jedynie treść wiadomości. Załączniki oraz ankiety nie będą zapisane.';
$txt['draft_none'] = 'Nie posiadasz żadnych szkiców.';
$txt['draft_edit'] = 'Edytuj szkic';
$txt['draft_load'] = 'Załaduj szkice';
$txt['draft_hide'] = 'Ukryj szkice';
$txt['draft_delete'] = 'Usuń szkic';
$txt['draft_days_ago'] = '%s dni temu';
$txt['draft_retain'] = 'będzie zachowane przez %s dni';
$txt['draft_remove'] = 'Usuń ten szkic';
$txt['draft_remove_selected'] = 'Usunąć zaznaczone szkice?';
$txt['draft_saved'] = 'Treść została zapisana jako szkic i będzie dostępna w menu <a href="%1$s">Pokaż szkice</a> w profilu.';
$txt['draft_pm_saved'] = 'Treść została zapisana jako szkic i będzie dostępna w menu <a href="%1$s">Pokaż szkice</a> w centrum wiadomości.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Włącz automatyczne zapisywanie szkiców';
$txt['drafts_autosave_enabled_subnote'] = 'Ta funkcja automatycznie zapisze szkice w tle w określonych odstępach czasu. Użytkownik musi posiadać odpowiednie uprawnienie.';
$txt['drafts_keep_days'] = 'Ilość dni do przechowywania szkiców';
$txt['drafts_keep_days_subnote'] = 'Aby nie usuwać starych szkiców wpisz 0';
$txt['drafts_autosave_frequency'] = 'Częstotliwość automatycznego zapisywania szkiców';
$txt['drafts_autosave_frequency_subnote'] = 'Minimalna wartość: 30 sekund';
$txt['drafts_pm_enabled'] = 'Włącz zapisywanie szkiców PW';
$txt['drafts_post_enabled'] = 'Włącz zapisywanie szkiców wiadomości';
$txt['drafts_none'] = 'Brak tytułu';
$txt['drafts_saved'] = 'Szkic został zapisany';