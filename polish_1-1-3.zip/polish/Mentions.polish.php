<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Powiadomienia';
$txt['my_unread_mentions'] = 'Nowe powiadomienia';
$txt['my_mentions_pages'] = 'strona %1$d';
$txt['no_mentions_yet'] = 'Brak oznaczeń';
$txt['no_new_mentions'] = ' Brak nowych oznaczeń';

$txt['mentions_from'] = 'Użytkownik';
$txt['mentions_when'] = 'Kiedy';
$txt['mentions_what'] = 'Wiadomość';
$txt['mentions_all'] = 'Pokaż wszystkie';
$txt['mentions_unread'] = 'Pokaż nieprzeczytane';
$txt['mentions_action'] = 'Czynności';
$txt['mentions_delete_warning'] = 'Na pewno chcesz usunąć ten wpis?';
$txt['mentions_markread'] = 'Oznacz jako przeczytane';
$txt['mentions_markunread'] = 'Oznacz jako nieprzeczytane';

$txt['mentions_settings'] = 'Notifications Settings';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = 'Enable site notifications';
$txt['mentions_buddy'] = 'Wyślij powiadomienie gdy użytkownik został dodany do listy znajomych';
$txt['mentions_dont_notify_rlike'] = 'Nie informuj użytkownika, gdy zostaje usunięty znacznik polubienia';

$txt['mention_mentionmem'] = 'oznaczył Ciebie w wiadomości {msg_link}';
$txt['mention_likemsg'] = 'lubi Twoją wiadomość {msg_link}';
$txt['mention_rlikemsg'] = 'nie lubi Twojej wiadomości {msg_link}';
$txt['mention_buddy'] = 'dodał Ciebie do listy znajomych.';
$txt['mention_quotedmem'] = 'Quoted a message of yours in {msg_link}';
$txt['mention_mailfail'] = 'Disabled email notification due to delivery failure';

$txt['mentions_type_all'] = 'Wszystkie oznaczenia';
$txt['mentions_type_mentionmem'] = 'Oznaczony';
$txt['mentions_type_likemsg'] = 'Polubienia';
$txt['mentions_type_rlikemsg'] = 'Nie lubię';
$txt['mentions_type_buddy'] = 'Znajomy';
$txt['mentions_type_quotedmem'] = 'Quoted';
$txt['mentions_type_mailfail'] = 'Delivery Failure';

$txt['mentions_mark_all_read'] = 'Oznacz powiadomienia jako przeczytane';

$txt['setting_notify_enable_this'] = 'Enable user notifications of this event.';

$txt['setting_buddy'] = 'Znajomi';
$txt['setting_likemsg'] = 'Polubienia';
$txt['setting_rlikemsg'] = 'Removed likes';
$txt['setting_mentionmem'] = '@mentions';
$txt['setting_quotedmem'] = 'Cytat';
$txt['setting_mailfail'] = 'Delivery Failures';