<?php
// Version: 1.1; ManageCalendar

$txt['calendar_desc'] = 'Tutaj możesz modyfikować wszystkie opcje kalendarza.';

// Calendar Settings
$txt['calendar_settings_desc'] = 'Tutaj możesz włączyć kalendarz i wybrać ustawienia z których będzie korzystał.';
$txt['groups_calendar_view'] = 'Grupy użytkowników mogące przeglądać kalendarz';
$txt['groups_calendar_post'] = 'Grupy użytkowników mogące tworzyć własne wydarzenia';
$txt['groups_calendar_edit_own'] = 'Grupy użytkowników mogące edytować własne wydarzenia';
$txt['groups_calendar_edit_any'] = 'Grupy użytkowników mogące edytować dowolne wydarzenie';
$txt['setting_cal_enabled'] = 'Włącz kalendarz';
$txt['setting_cal_daysaslink'] = 'Pokazuj dni jako odnośniki do \'Dodaj wydarzenie\'';
$txt['setting_cal_days_for_index'] = 'Maksymalna liczba dni na przód w indeksie działów';
$txt['setting_cal_showholidays'] = 'Pokaż święta';
$txt['setting_cal_showbdays'] = 'Pokaż urodziny';
$txt['setting_cal_showevents'] = 'Pokaż wydarzenia';
$txt['setting_cal_export'] = 'Pozwól eksportować wydarzenia w formacie iCal';
$txt['setting_cal_show_never'] = 'Nigdy';
$txt['setting_cal_show_cal'] = 'Tylko w kalendarzu';
$txt['setting_cal_show_index'] = 'Tylko w indeksie działów';
$txt['setting_cal_show_all'] = 'Pokazuj w indeksie działów i kalendarzu';
$txt['setting_cal_defaultboard'] = 'Domyślny dział do dodawania wydarzeń';
$txt['setting_cal_allow_unlinked'] = 'Zezwól na wydarzenia nie powiązane z wiadomościami na forum';
$txt['setting_cal_minyear'] = 'Rok początkowy';
$txt['setting_cal_maxyear'] = 'Rok końcowy';
$txt['setting_cal_allowspan'] = 'Zezwól na kilkudniowe wydarzenia';
$txt['setting_cal_maxspan'] = 'Maksymalna ilość dni trwania wydarzenia';
$txt['setting_cal_showInTopic'] = 'Pokaż powiązane wydarzenia w widoku tematu';

// Adding/Editing/Viewing Holidays
$txt['manage_holidays_desc'] = 'Tutaj możesz dodawać i usuwać święta w Twoim kalendarzu.';
$txt['current_holidays'] = 'Obecne święta';
$txt['holidays_title'] = 'Święto';
$txt['holidays_title_label'] = 'Tytuł';
$txt['holidays_delete_confirm'] = 'Na pewno chcesz usunąć te święta?';
$txt['holidays_add'] = 'Dodaj nowe święto';
$txt['holidays_edit'] = 'Edytuj istniejące święto';
$txt['holidays_button_add'] = 'Dodaj';
$txt['holidays_button_edit'] = 'Edytuj';
$txt['holidays_button_remove'] = 'Usuń';
$txt['holidays_no_entries'] = 'Nie ma obecnie skonfigurowanych żadnych świąt.';
$txt['every_year'] = 'Co roku';