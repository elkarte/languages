<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Data';
$txt['badbehaviorlog_protocol'] = 'Protokół';
$txt['badbehaviorlog_method'] = 'Metoda';
$txt['badbehaviorlog_request'] = 'Żądanie';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'ID użytkownika';
$txt['badbehaviorlog_username'] = 'Nazwa użytkownika';
$txt['badbehaviorlog_headers'] = 'Nagłówki';
$txt['badbehaviorlog_agent'] = 'Przeglądarka';
$txt['badbehaviorlog_entity'] = 'Wyślij';
$txt['badbehaviorlog_key'] = 'Klucz';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Ilość wejść';
$txt['badbehaviorlog_error_valid_code'] = 'Kod powodu';
$txt['badbehaviorlog_error_valid_response'] = 'Status HTTP';
$txt['badbehaviorlog_error_valid_explaination'] = 'Powód HTTP';
$txt['badbehaviorlog_error_valid_log'] = 'Szczegóły';
$txt['badbehaviorlog_log'] = 'Log Bad Behavior';
$txt['badbehaviorlog_desc'] = 'Poniżej znajduje się lista wszystkich wejść zalogowanych przez Bad Behavior';
$txt['badbehaviorlog_details'] = 'Dodatkowe informacje';
$txt['badbehaviorlog_no_entries_found'] = 'Obecnie nie ma wpisów w logu Bad Behavior.';

$txt['badbehaviorlog_remove_selection'] = 'Usuń zaznaczone';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Na pewno chcesz usunąć wszystkie zaznaczone wpisy?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Usuń wszystkie przefiltrowane wyniki';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Na pewno chcesz usunąć wybrane wpisy?';
$txt['badbehaviorlog_sure_remove'] = 'Na pewno chcesz usunąć wszystkie logi Bad Behavior?';

$txt['badbehaviorlog_remove'] = 'Usuń zaznaczone';
$txt['badbehaviorlog_removeall'] = 'Wyczyść logi';
$txt['badbehaviorlog_clear_filter'] = 'Wyczyść filtr';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Zastosuj filtr typu';
$txt['badbehaviorlog_apply_filter'] = 'Filtruj wyniki';
$txt['badbehaviorlog_applying_filter'] = 'Zastosowany filtr';
$txt['badbehaviorlog_filter_only_member'] = 'Pokaż logi Bad Behavior tylko dla tego użytkownika';
$txt['badbehaviorlog_filter_only_ip'] = 'Pokaż logi Bad Behavior tylko dla tego adresu IP';
$txt['badbehaviorlog_filter_only_session'] = 'Pokaż logi Bad Behavior tylko dla tej sesji';
$txt['badbehaviorlog_filter_only_headers'] = 'Pokaż logi Bad Behavior tylko dla tego adresu URL';
$txt['badbehaviorlog_filter_only_agent'] = 'Pokaż logi Bad Behavior z tym samym agentem przeglądarki';

$txt['badbehaviorlog_session'] = 'Sesja';
$txt['badbehaviorlog_error_url'] = 'Zapisany adres strony';

$txt['badbehaviorlog_reverse_direction'] = 'Wyświetl listę w odwrotnym porządku chronologicznym';
$txt['badbehaviorlog_filter_only_type'] = 'Pokaż logi Bad Behavior z tym kodem';