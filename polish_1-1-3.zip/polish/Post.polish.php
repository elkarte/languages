<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Wyślij odpowiedź';
$txt['post_in_board'] = 'Wyślij w dziale';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Wstaw cytat';
$txt['disable_smileys'] = 'Wyłącz emotikony';
$txt['dont_use_smileys'] = 'Nie używaj emotikon.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Wysłane';
$txt['standard'] = 'Standardowe';
$txt['thumbs_up'] = 'Dobrze';
$txt['thumbs_down'] = 'Źle';
$txt['exclamation_point'] = 'Wykrzyknik';
$txt['question_mark'] = 'Znak zapytania';
$txt['icon_poll'] = 'Ankieta';
$txt['lamp'] = 'Żarówka';
$txt['add_smileys'] = 'Dodaj emotikony';
$txt['topic_notify_no'] = 'Nie ma tematów z powiadomieniem.';

$txt['rich_edit_wont_work'] = 'Twoja przeglądarka nie obsługuje zaawansowanego edytora tekstu.';
$txt['rich_edit_function_disabled'] = 'Twoja przeglądarka nie współpracuje z tą funkcją.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Przestań śledzić ten temat klikając tutaj';

$txt['lock_after_post'] = 'Zamknij po wysłaniu wiadomości';
$txt['notify_replies'] = 'Powiadamiaj mnie o odpowiedziach.';
$txt['lock_topic'] = 'Zamknij ten temat.';
$txt['shortcuts'] = 'skróty: shift+alt+s aby wysłać wiadomość, shift+alt+p aby ją podejrzeć';
$txt['shortcuts_drafts'] = 'skróty: shift+alt+s aby wysłać wiadomość, shift+alt+p aby ją podejrzeć, shift+alt+d aby zapisać szkic';
$txt['option'] = 'Opcja';
$txt['reset_votes'] = 'Resetuj liczbę głosów';
$txt['reset_votes_check'] = 'Zaznacz to, jeśli chcesz resetować liczbę wszystkich głosów do zera.';
$txt['votes'] = 'głosów';
$txt['attach'] = 'Załącz';
$txt['clean_attach'] = 'Usuń załącznik';
$txt['attached'] = 'Załączone'; // @deprecated since 1.1
$txt['allowed_types'] = 'Dozwolone typy plików';
$txt['cant_upload_type'] = 'Nie możesz wysłać pliku tego typu. jedynymi dozwolonymi rozszerzeniami są %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Odznacz te pliki, które nie mają już być załączone'; // @deprecated since 1.1
$txt['restricted_filename'] = 'To jest zastrzeżona nazwa pliku. Spróbuj innej.';
$txt['topic_locked_no_reply'] = 'Uwaga: temat jest lub będzie zamknięty!<br />Tylko administratorzy i moderatorzy mogą wysyłać odpowiedzi.';
$txt['attachment_requires_approval'] = 'Wszystkie załączone pliki nie zostaną wyświetlone do czasu zatwierdzenia ich przez moderatora.';
$txt['error_temp_attachments'] = 'Znaleziono załączniki, które wysłałeś lecz ich nie zaznaczyłeś. Załączniki te nie będą widoczne w tej wiadomości. Jeśli nie chcesz aby były dodane do tej wiadomości możesz je usunąć klikając <a href="#postAttachment">tutaj</a>. ';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Uwaga: Wiadomość nie zostanie wyświetlona do czasu zatwierdzenia przez moderatora.';

$txt['enter_comment'] = 'Wpisz komentarz';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Wiadomość zgłoszona';
$txt['reported_to_mod_by'] = 'przez';
$txt['rtm10'] = 'Wyślij';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Wiadomość "%1$s" napisana przez';
$txt['reported_by'] = 'została zgłoszona przez';
$txt['board_moderate'] = 'w dziale, który moderujesz';
$txt['report_comment'] = 'Osoba zgłaszająca dodała następujący komentarz';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maksymalny całkowity rozmiar %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maksymalny rozmiar jednego pliku %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d załączniki na wiadomość';
$txt['attach_restrictions'] = 'Ograniczenia:';

$txt['post_additionalopt_attach'] = 'Załączniki i opcje dodatkowe';
$txt['post_additionalopt'] = 'Inne opcje';
$txt['sticky_after'] = 'Przyklej ten temat';
$txt['move_after2'] = 'Przenieś temat.';
$txt['back_to_topic'] = 'Powróć do tematu.';
$txt['approve_this_post'] = 'Zatwierdź wiadomość';

$txt['retrieving_quote'] = 'Pobieranie cytatu...';

$txt['post_visual_verification_label'] = 'Weryfikacja';
$txt['post_visual_verification_desc'] = 'Wpisz kod z obrazka aby dodać wiadomość.';

$txt['poll_options'] = 'Opcje ankiety';
$txt['poll_run'] = 'Ankieta czynna przez';
$txt['poll_run_limit'] = '(Zostaw puste jeśli brak limitu.)';
$txt['poll_results_visibility'] = 'Widzialność wyników';
$txt['poll_results_anyone'] = 'Pokaż wyniki wszystkim.';
$txt['poll_results_voted'] = 'Pokaż wyniki tylko głosującym.';
$txt['poll_results_after'] = 'Pokazuj wyniki tylko po wygaśnięciu ankiety.';
$txt['poll_max_votes'] = 'Maksimum głosów na użytkownika';
$txt['poll_do_change_vote'] = 'Zezwól użytkownikom zmieniać głos';
$txt['poll_too_many_votes'] = 'Zaznaczyłeś za dużo opcji. Dla tej ankiety możesz wybrać tylko %1$s opcji.';
$txt['poll_add_option'] = 'Dodaj opcję';
$txt['poll_guest_vote'] = 'Pozwól gościom głosować';

$txt['spellcheck_done'] = 'Sprawdzanie ortografii zakończone.';
$txt['spellcheck_change_to'] = 'Zmień na:';
$txt['spellcheck_suggest'] = 'Sugestie:';
$txt['spellcheck_change'] = 'Zmień';
$txt['spellcheck_change_all'] = 'Zmień wszystko';
$txt['spellcheck_ignore'] = 'Ignoruj';
$txt['spellcheck_ignore_all'] = 'Ignoruj wszystko';

$txt['more_attachments'] = 'więcej załączników';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Nie możesz dodać więcej plików.';

$txt['more_smileys'] = 'więcej';
$txt['more_smileys_title'] = 'Dodatkowe emotikony';
$txt['more_smileys_pick'] = 'Wybierz emotikonę';
$txt['more_smileys_close_window'] = 'Zamknij okno';

$txt['error_new_reply'] = 'Podczas pisania wiadomości została wysłana nowa odpowiedź. Zobacz ją przed wysłaniem swojej wiadomości.';
$txt['error_new_replies'] = 'Podczas pisania wiadomości %1$d nowe odpowiedzi zostały wysłane. Zobacz je przed wysłaniem swojej wiadomości.';
$txt['error_new_reply_reading'] = 'Podczas czytania została wysłana nowa odpowiedź. Zobacz ją przed wysłaniem swojej wiadomości.';
$txt['error_new_replies_reading'] = 'Podczas czytania została wysłano %1$d nowych odpowiedzi. Zobacz je przed wysłaniem swojej wiadomości.';

$txt['announce_this_topic'] = 'Wyślij użytkownikom ogłoszenie o tym temacie:';
$txt['announce_title'] = 'Wyślij ogłoszenie';
$txt['announce_desc'] = 'Ten formularz pozwala na wysłanie do wybranych grup użytkowników ogłoszenia o tym temacie.';
$txt['announce_sending'] = 'Wysyłanie ogłoszenia o temacie';
$txt['announce_done'] = 'zrobione';
$txt['announce_continue'] = 'Kontynuuj';
$txt['announce_topic'] = 'Ogłoś temat.';
$txt['announce_regular_members'] = 'Zwykli użytkownicy';

$txt['digest_subject_daily'] = 'Skrót dnia';
$txt['digest_subject_weekly'] = 'Skrót tygodnia';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'Następujące tematy zostały rozpoczęte';
$txt['digest_new_topics_line'] = '"%1$s" w dziale %2$s';
$txt['digest_new_replies'] = 'Odpowiedzi dokonane w następujących tematach';
$txt['digest_new_replies_one'] = '1 odpowiedź w "%1$s"';
$txt['digest_new_replies_many'] = '%1$d odpowiedzi w "%2$s"';
$txt['digest_mod_actions'] = 'Moderatorzy wykonali następujące czynności';
$txt['digest_mod_act_sticky'] = '"%1$s" został przyklejony';
$txt['digest_mod_act_lock'] = '"%1$s" został zamknięty';
$txt['digest_mod_act_unlock'] = '"%1$s" został otwarty';
$txt['digest_mod_act_remove'] = '"%1$s" został usunięty';
$txt['digest_mod_act_move'] = '"%1$s" został przeniesiony';
$txt['digest_mod_act_merge'] = '"%1$s" został połączony';
$txt['digest_mod_act_split'] = '"%1$s" został podzielony';

$txt['attach_error_title'] = 'Podczas wysyłania załączników wystąpił błąd.';
$txt['attach_warning'] = 'Wystąpił błąd podczas wysyłania <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Wyczerpałeś limit wielkości załączników. Całkowity ich rozmiar  w jednej wiadomości to %1$s KB. Pozostało %2$s KB.';
$txt['attach_folder_warning'] = 'Katalog załączników nie został znaleziony. Powiadom administratora o tym problemie.';
$txt['attach_folder_admin_warning'] = 'Ścieżka do katalogu załączników (%1$s) nie jest poprawna. Popraw ją w ustawieniach załączników.';
$txt['attach_limit_nag'] = 'Wyczerpano limit ilości załączników w wiadomości.';
$txt['attach_no_upload'] = 'Wystąpił błąd. Załączniki nie mogły zostać wysłane.';
$txt['attach_remaining'] = 'Pozostało %1$d';
$txt['attach_available'] = 'Dostępne %1$s KB';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'Plik wydaje się być pusty. Jeśli błąd się powtórzy skontaktuj się z administratorem forum.';
$txt['attached_files_in_session'] = '<em>Podkreślone pliki zostały wysłane, ale nie będą załączone do wiadomości dopóki jej nie wyślesz.</em>';

$txt['attach_php_error'] = 'W wyniku błędu załącznik nie mógł zostać wysłany. Jeśli problem się powtórzy skontaktuj się z administratorem forum.';
$txt['php_upload_error_1'] = 'Wysłany plik przekracza maksymalny dozwolony rozmiar ustawiony w opcji upload_max_filesize w php.ini. Skontaktuj się z administratorem hostingu jeśli nie masz możliwości zmiany tego ustawienia.';
$txt['php_upload_error_3'] = 'Pliki zostały wysłane częściowo. Błąd związany z PHP. Skontaktuj się z administratorem hostingu jeśli błąd będzie się powtarzał.';
$txt['php_upload_error_4'] = 'Plik nie został wysłany. Błąd związany z PHP. Skontaktuj się z administratorem hostingu jeśli błąd będzie się powtarzał.';
$txt['php_upload_error_6'] = 'Nie można zapisać. Katalog tymczasowy nie istnieje. Skontaktuj się z administratorem hostingu jeśli nie możesz rozwiazac problemu.';
$txt['php_upload_error_7'] = 'Nie można zapisywać na dysku. Błąd związany z PHP. Skontaktuj się z administratorem hostingu jeśli błąd będzie się powtarzał.';
$txt['php_upload_error_8'] = 'Rozszerzenie PHP przerwało wysyłanie pliku. Błąd związany z PHP. Skontaktuj się z administratorem hostingu jeśli błąd będzie się powtarzał.';
$txt['error_temp_attachments_new'] = 'Znaleziono załączniki, które wysłano, ale nie załączono ich do wiadomości. Załączniki są wciąż powiązane z wiadomością. Wiadomość musi zostać wysłana przed ich zapisaniem lub usunięciem. Możesz to zrobić <a href="#postAttachment">tutaj</a>';
$txt['error_temp_attachments_found'] = 'Znaleziono następujące pliki, które zostały załączone do  innej wiadomości, ale nie zostały wysłane. Zalecamy, abyś usunął te pliki lub wysłał wiadomość do której mają one być dodane.<br />Aby usunąć te pliki <a href="%1$s">kliknij tutaj </a>. Aby wysłać tą wiadomość <a href="%2$s">kliknij tutaj</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'Znaleziono następujące pliki, które zostały załączone do innej wiadomości, ale nie zostały wysłane. Zalecamy, abyś usunął te pliki lub wysłał wiadomość do której mają one być dodane.<br />Aby usunąć te pliki <a href="%1$s">kliknij tutaj </a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Te załączniki zostały usunięte, zostałeś przekierowany do poprzedniej strony';
$txt['error_temp_attachments_flushed'] = 'Wszystkie pliki, które zostały załączone, ale nie wysłane zostały usunięte.';
$txt['error_topic_already_announced'] = 'Ten temat został już ogłoszony.';

$txt['cant_access_upload_path'] = 'Nie można uzyskać dostępu do ścieżki wysyłania załączników!';
$txt['file_too_big'] = 'Wysyłany plik jest za duży. Maksymalny rozmiar załącznika to %1$s KB.';
$txt['attach_timeout'] = 'Twój załącznik nie mógł zostać zapisany. Może to być spowodowane zbyt długim czasem wysyłania lub plik jest za duży.<br /><br />W celu uzyskania większej ilości informacji skontaktuj się z administratorem serwera.';
$txt['bad_attachment'] = 'Twój załącznik nie przeszedł testów bezpieczeństwa i nie może zostać wysłany. Skonsultuj się z administratorem forum.';
$txt['ran_out_of_space'] = 'Katalog załączników jest pełny. Skontaktuj się a administratorem.';
$txt['attachments_no_write'] = 'Nie można zapisywać w katalogu załączników. Twój załącznik lub awatar nie może być zapisany.';
$txt['attachments_no_create'] = 'Nie można utworzyć nowego katalogu załączników. Twój załącznik lub awatar nie może zostać zapisany.';
$txt['attachments_limit_per_post'] = 'Maksymalna liczba załączników na jedną wiadomość to: %1$d';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Wstaw';
$txt['ila_opt_size'] = 'Rozmiar';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Brak';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Wyśrodkuj';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/