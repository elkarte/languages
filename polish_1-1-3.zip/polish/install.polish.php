<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Witamy';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Test CHMOD';
$txt['install_step_forum'] = 'Ustawienia forum';
$txt['install_step_databaseset'] = 'Ustawienia bazy danych';
$txt['install_step_databasechange'] = 'Uzupełnianie bazy danych';
$txt['install_step_admin'] = 'Konto administratora';
$txt['install_step_delete'] = 'Kończenie instalacji';

$txt['installer'] = 'Instalator ElkArte';
$txt['installer_language'] = 'Język';
$txt['installer_language_set'] = 'Ustaw';
$txt['congratulations'] = 'Gratulacje, proces instalacji został zakończony!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Zapisywanie w katalogu instalacyjnym jest włączone. Z powodów bezpieczeństwa powinieneś zmienić ustawienia CHMOD, tak aby zapisywanie w tym katalogu nie było możliwe.';
$txt['delete_installer'] = 'Usuń plik install.php';
$txt['delete_installer_maybe'] = '<em>(nie działa na niektórych serwerach)</em>';
$txt['go_to_your_forum'] = 'Teraz możesz odwiedzić <a href="%1$s">swoje nowo zainstalowane forum</a> i zacząć go używać. Aby móc skorzystać z funkcji administracyjnych, powinieneś najpierw się zalogować.';
$txt['good_luck'] = 'Dziękujemy za zainstalowanie ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Witamy';
$txt['install_welcome_desc'] = 'Witaj w ElkArte. Ten skrypt przeprowadzi Cię przez proces instalacji %1$s. W następnych krokach zbierzemy kilka informacji o Twoim forum i po kilku minutach forum będzie gotowe do użycia.';
$txt['install_all_lovely'] = 'Przeprowadziliśmy pomyślnie kilka ważnych testów Twojego serwera i wszystko wygląda w porządku. Kliknij przycisk &quot;Kontynuuj&quot; aby zacząć.';

$txt['user_refresh_install'] = 'Forum odświeżone';
$txt['user_refresh_install_desc'] = 'Podczas instalacji, instalator stwierdził (wykorzystując informacje podane przez Ciebie), że jedna lub więcej tabel, które instalator powinien utworzyć już istnieje.<br />Jakiekolwiek brakujące tabele w twojej instalacji zostały odtworzone z domyślnymi danymi, a z istniejących tabel niczego nie skasowano.';

$txt['default_topic_subject'] = 'Witamy w ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Dyskusja ogólna';
$txt['default_board_description'] = 'W tym dziale możesz rozmawiać o wszystkim.';
$txt['default_category_name'] = 'Kategoria ogólna';
$txt['default_time_format'] = '%d %B %Y, %H:%M:%S';
$txt['default_news'] = 'Forum ElkArte zostało uruchomione!';
$txt['default_karmaLabel'] = 'Reputacja:';
$txt['default_karmaSmiteLabel'] = '[potępiam]';
$txt['default_karmaApplaudLabel'] = '[popieram]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGuest\\nroot\\nGość\\nAdministrator';
$txt['default_smileyset_name'] = 'Zestaw Fugue';
$txt['default_theme_name'] = 'Domyślny styl ElkArte';

$txt['default_administrator_group'] = 'Administrator';
$txt['default_global_moderator_group'] = 'Moderator Globalny';
$txt['default_moderator_group'] = 'Moderator';
$txt['default_newbie_group'] = 'Nowy użytkownik';
$txt['default_junior_group'] = 'Użytkownik';
$txt['default_full_group'] = 'Aktywny użytkownik';
$txt['default_senior_group'] = 'Zaawansowany użytkownik';
$txt['default_hero_group'] = 'Ekspert';

$txt['default_smiley_smiley'] = 'Uśmiech';
$txt['default_wink_smiley'] = 'Mrugnięcie';
$txt['default_cheesy_smiley'] = 'Chichot';
$txt['default_grin_smiley'] = 'Duży uśmiech';
$txt['default_angry_smiley'] = 'Zły';
$txt['default_sad_smiley'] = 'Smutny';
$txt['default_shocked_smiley'] = 'Szok';
$txt['default_cool_smiley'] = 'Spoko';
$txt['default_huh_smiley'] = 'Co?';
$txt['default_roll_eyes_smiley'] = 'Z politowaniem';
$txt['default_tongue_smiley'] = 'Język';
$txt['default_embarrassed_smiley'] = 'Zawstydzony';
$txt['default_lips_sealed_smiley'] = 'Buzia na kłódkę';
$txt['default_undecided_smiley'] = 'Niezdecydowany';
$txt['default_kiss_smiley'] = 'Buziak';
$txt['default_cry_smiley'] = 'Płacz';
$txt['default_evil_smiley'] = 'Zły';
$txt['default_azn_smiley'] = 'Uśmiech 2';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Śmiech';
$txt['default_police_smiley'] = 'Policja';
$txt['default_angel_smiley'] = 'Anioł';

$txt['error_message_click'] = 'Kliknij tutaj';
$txt['error_message_try_again'] = 'aby wykonać ten krok ponownie.';
$txt['error_message_bad_try_again'] = 'aby spróbować instalacji mimo wszystko. Miej jednak na uwadze, że jest to <em>mocno</em> odradzane.';

$txt['install_settings'] = 'Ustawienia forum';
$txt['install_settings_info'] = 'Na tej stronie musisz uzupełnić kilka ustawień dla forum. ElkArte wykryło automatycznie najważniejsze ustawienia.';
$txt['install_settings_name'] = 'Nazwa forum';
$txt['install_settings_name_info'] = 'To jest nazwa twojego forum, np. &quot;Forum testowe&quot;.';
$txt['install_settings_name_default'] = 'Moje forum';
$txt['install_settings_url'] = 'Adres forum';
$txt['install_settings_url_info'] = 'To jest adres internetowy do twojego forum <strong>(nie może być zakończony symbolem \'/\'!)</strong>.<br />W większości przypadków możesz pozostawić w tym polu wartość domyślną.';
$txt['install_settings_compress'] = 'Kompresja Gzip';
$txt['install_settings_compress_title'] = 'Kompresuje dane w celu oszczędzania transferu';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Ta funkcja nie działa poprawnie na wszystkich serwerach, ale może pomóc w zachowaniu transferu.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Kliknij tutaj, aby sprawdzić działanie tej funkcji</a>. (powinno pojawić się okienko z komunikatem "PASS")';
$txt['install_settings_dbsession'] = 'Sesje w bazie danych';
$txt['install_settings_dbsession_title'] = 'Użyj bazy danych zamiast plików do przechowania informacji o sesjach.';
$txt['install_settings_dbsession_info1'] = 'Najczęściej warto włączyć tę funkcję, ponieważ dzięki niej dane o sesjach są bardziej godne zaufania.';
$txt['install_settings_dbsession_info2'] = 'Ta funkcja jest zazwyczaj przydatna, ale może nie działać poprawnie na twoim serwerze.';
$txt['install_settings_proceed'] = 'Wykonaj';

$txt['db_settings'] = 'Ustawienia bazy danych';
$txt['db_settings_info'] = 'Poniższe opcje służą do ustawienia bazy danych serwera. Jeśli ich nie znasz skontaktuj się z administratorem swojego hostingu.';
$txt['db_settings_type'] = 'Typ bazy danych';
$txt['db_settings_type_info'] = 'Wykryto kilka wspieranych baz danych - którą chcesz użyć?';
$txt['db_settings_server'] = 'Nazwa serwera';
$txt['db_settings_server_info'] = 'Zazwyczaj jest to localhost - jeśli nie jesteś pewien spróbuj localhost.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Jeśli serwer nasłuchuje na domyślnym porcie lub jeśli nie jesteś tego pewien to pozostaw pole  puste.';
$txt['db_settings_username'] = 'Nazwa użytkownika';
$txt['db_settings_username_info'] = 'Podaj nazwę użytkownika bazy danych.<br />Jeśli jej nie znasz spróbuj użyć nazwy użytkownika FTP, zazwyczaj są one takie same.';
$txt['db_settings_password'] = 'Hasło';
$txt['db_settings_password_info'] = 'Podaj hasło wymagane do połączenia się z bazą danych.<br />Jeśli nie znasz go spróbuj użyć hasła konta FTP.';
$txt['db_settings_database'] = 'Nazwa bazy danych';
$txt['db_settings_database_info'] = 'Podaj nazwę bazy danych w której chcesz zainstalować ElkArte.';
$txt['db_settings_database_info_note'] = 'Jeśli baza danych nie istnieje, instalator spróbuje ją utworzyć.';
$txt['db_settings_database_file'] = 'Nazwa pliku bazy danych';
$txt['db_settings_database_file_info'] = 'Jest to nazwa pliku, który przechowuje wszystkie dane ElkArte. Zalecane jest użycie pliku z losowo wygenerowaną nazwą oraz umieszczenie go w niedostępnym z sieci miejscu.';
$txt['db_settings_prefix'] = 'Prefiks tabel';
$txt['db_settings_prefix_info'] = 'Prefiks każdej tabeli w bazie danych. <strong>Nie instaluj dwóch for z takimi samymi prefiksami!</strong><br />Wartość pozwala na multi instalację w jednej bazie.';
$txt['db_populate'] = 'Uzupełnianie bazy danych';
$txt['db_populate_info'] = 'Twoje ustawienia zostały zapisane oraz baza danych została wypełniona wszystkimi wymaganymi danymi do poprawnego działania Twojego forum. Podsumowanie:';
$txt['db_populate_info2'] = 'Kliknij &quot;Kontynuuj&quot; aby przejść do strony z tworzeniem konta administratora.';
$txt['db_populate_inserts'] = 'Wstawiono %1$d rzędów.';
$txt['db_populate_tables'] = 'Utworzono %1$d tabel. ';
$txt['db_populate_insert_dups'] = 'Zignorowano %1$d zduplikowanych wpisów.';
$txt['db_populate_table_dups'] = 'Zignorowano %1$d zduplikowanych tabel.';

$txt['user_settings'] = 'Utwórz swoje konto';
$txt['user_settings_info'] = 'Instalator utworzy teraz konto administratora.';
$txt['user_settings_username'] = 'Twoja nazwa użytkownika';
$txt['user_settings_username_info'] = 'Wybierz nazwę użytkownika z którą chcesz się logować. ';
$txt['user_settings_password'] = 'Hasło';
$txt['user_settings_password_info'] = 'Tu wprowadź hasło i dobrze je zapamiętaj!';
$txt['user_settings_again'] = 'Hasło';
$txt['user_settings_again_info'] = '(dla weryfikacji)';
$txt['user_settings_email'] = 'Adres email';
$txt['user_settings_email_info'] = 'Podaj również swój adres email. <strong>Adres musi być prawidłowy.</strong>';
$txt['user_settings_database'] = 'Hasło bazy danych';
$txt['user_settings_database_info'] = 'Z powodów bezpieczeństwa instalator wymaga podania hasła do bazy danych.';
$txt['user_settings_skip'] = 'Pomiń';
$txt['user_settings_skip_sure'] = 'Na pewno chcesz pominąć krok tworzenia konta administratora?';
$txt['user_settings_proceed'] = 'Zakończ';

$txt['ftp_checking_writable'] = 'Sprawdzanie czy pliki są zapisywalne';
$txt['ftp_setup'] = 'Informacje o połączeniu FTP';
$txt['ftp_setup_info'] = 'Instalator może połączyć się poprzez FTP aby zmienić atrybuty plików, które muszą być zapisywalne, a nie są. Jeśli ta funkcja nie zadziała u ciebie, musisz własnoręcznie dokonać potrzebnych zmian. Opcja ta nie działa obecnie z SSL.';
$txt['ftp_server'] = 'Serwer';
$txt['ftp_server_info'] = 'To powinien być adres i port twojego serwera FTP.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'Nazwa użytkownika';
$txt['ftp_username_info'] = 'Nazwa używana w celu logowania się. <em>Nie będzie ona nigdzie zapisana.</em>';
$txt['ftp_password'] = 'Hasło';
$txt['ftp_password_info'] = 'Hasło używane w celu logowania się. <em>Nie będzie ono nigdzie zapisane.</em>';
$txt['ftp_path'] = 'Ścieżka instalacji';
$txt['ftp_path_info'] = 'To jest ścieżka pokazująca <em>prawdziwą</em> lokalizację plików na serwerze FTP.';
$txt['ftp_path_found_info'] = 'Ścieżka w polu powyżej została wykryta automatycznie.';
$txt['ftp_connect'] = 'Połącz';
$txt['ftp_setup_why'] = 'Po co jest ten krok?';
$txt['ftp_setup_why_info'] = 'W celu poprawnego działania, ElkArte musi mieć możliwość zapisywania w niektórych plikach. Ten etap pozwala na dokonanie odpowiednich zmian przez instalator w plikach. Jeśli z jakiegoś powodu się to nie uda należy zmienić CHMOD następujących plików na 777 (lub na niektórych serwerach na 755):';
$txt['ftp_setup_again'] = 'aby ponownie przetestować, czy można zapisywać w tych plikach.';

$txt['error_php_too_low'] = 'Uwaga! Nie wykryto na serwerze <strong>minimalnej wymaganej wersji PHP</strong>.<br />Jeśli nie jesteś właścicielem serwera, będziesz musiał poprosić administratora o aktualizację lub zmienić serwer, w przeciwnym razie zaktualizuj PHP do najnowszej wersji.<br /><br />Jeśli jesteś pewien, że zainstalowana wersja PHP jest zgodna z wymaganiami ElkArte możesz kontynuować, jednak nie jest to zalecane.';
$txt['error_missing_files'] = 'Nie znaleziono niezbędnych plików w katalogu instalacji!<br /><br />Upewnij się, że wysłałeś na serwer cały pakiet instalacyjny, razem z plikiem sql i spróbuj ponownie.';
$txt['error_session_save_path'] = 'Poinformuj właściciela serwera, że <strong>wpis session.save_path w php.ini</strong> jest niewłaściwy! Musi on być zmieniony na katalog, który <strong>istnieje</strong> i ma możliwość <strong>zapisu</strong> przez użytkownika,  u którego jest uruchomione PHP.<br />';
$txt['error_windows_chmod'] = 'Używasz serwera działającego pod kontrolą systemu Windows i niektóre kluczowe pliki nie mają możliwości zapisu. Poproś administratora hostingu, aby <strong>nadał uprawnienia zapisu</strong> dla użytkownika PHP dla plików instalacji ElkArte. Następujące pliki lub katalogi muszą mieć możliwość zapisywania:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Nie można połączyć się z serwerem FTP za pomocą podanych danych.';
$txt['error_db_file'] = 'Nie można znaleźć skryptu bazy danych! Sprawdź czy plik %1$s znajduje się w plikach źródłowych twojego forum.';
$txt['error_db_connect'] = 'Nie można połączyć się z serwerem bazy danych używając podanych danych.<br /><br />Jeśli nie jesteś pewien co wpisać, skontaktuj się ze swoim hostem.';
$txt['error_db_too_low'] = 'Wersja bazy danych jest bardzo stara i nie jest wspierana przez ElkArte.<br /><br />Skontaktuj się z administratorem serwera w celu aktualizacji lub założenia nowej bazy. Jeśli nie będzie to możliwe - poszukaj nowy hosting.';
$txt['error_db_database'] = 'Instalator nie był w stanie połączyć się z bazą danych &quot;<em>%1$s</em>&quot;. Na niektórych serwerach konieczne jest utworzenie bazy danych w panelu administracyjnym przed rozpoczęciem instalacji ElkArte. Niektóre także dodają prefiksy - np. nazwa użytkownika - do nazwy bazy danych.';
$txt['error_db_queries'] = 'Niektóre zapytania zostały niepoprawnie wykonane.  Może być to spowodowane nieobsługiwaną (rozwojową lub przestarzałą) wersją oprogramowania bazy danych.<br /><br />Informacje techniczne o zapytaniach:';
$txt['error_db_queries_line'] = 'Linia #';
$txt['error_db_missing'] = 'Instalator nie mógł wykryć w PHP wsparcia dla bazy danych, którą ElkArte może użyć. Spytaj się administratora serwera, aby upewnić się, że PHP zostało skompilowane z żądaną bazą danych lub czy ładowane jest poprawne rozszerzenie PHP. Obecnie ElkArte wspiera rozszerzenia &quot;%1$s&quot;';
$txt['error_db_script_missing'] = 'Instalator nie mógł znaleźć żadnego skryptu instalacyjnego dla wykrytej bazy danych. Prosimy sprawdź czy wysłałeś na serwer wszystkie wymagane pliki skryptów instalacji do głównego katalogu forum, na przykład &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Instalator nie był w stanie wykryć na serwerze wsparcia dla sesji w PHP. Zapytaj się właściciela serwera czy PHP było skompilowane ze wsparciem dla sesji (a raczej czy specjalnie zostało skompilowane bez).'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Wpisałeś dwa różne hasła!';
$txt['error_user_settings_no_password'] = 'Twoje hasło musi zawierać przynajmniej cztery znaki.';
$txt['error_user_settings_taken'] = 'Przepraszamy, jeden z użytkowników już używa tej nazwy użytkownika i/lub adresu email.<br /><br />Nie utworzono nowego konta.';
$txt['error_user_settings_query'] = 'Wystąpił błąd bazy danych podczas próby utworzenia konta administratora. Treść błędu:';
$txt['error_subs_missing'] = 'Nie można odnaleźć pliku sources/Subs.php. Upewnij się, że został prawidłowo wysłany na serwer i spróbuj ponownie.';
$txt['error_db_alter_priv'] = 'Podane konto bazy danych nie posiada uprawnień do wykonania operacji ALTER, CREATE i/lub DROP, są one wymagane do poprawnego działania ElkArte.';
$txt['error_versions_do_not_match'] = 'Instalator wykrył, że aktualnie zainstalowana jest inna wersja ElkArte z tymi samymi informacjami. Jeśli próbujesz dokonać aktualizacji powinieneś skorzystać z aktualizatora, a nie instalatora.<br />W przeciwnym razie użyj innych informacji lub utwórz kopię bazy danych i usuń obecnie znajdujące się w bazie dane.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'Obecna wersja bazy danych nie obsługuje kodowania UTF-8. ElkArte nie może zostać zainstalowane.';
$txt['error_valid_email_needed'] = 'Wpisałeś niepoprawny adres email.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Uwaga!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Musisz wpisać nazwę bazy danych dla SQLite.';
$txt['error_db_prefix_numeric'] = 'Zaznaczony typ bazy danych nie obsługuje numerycznych prefiksów.';
$txt['error_invalid_characters_username'] = 'Użyto niedozwolonego znaku w nazwie użytkownika.';
$txt['error_username_too_long'] = 'Nazwa użytkownika musi być krótsza niż 25 znaków.';
$txt['error_username_left_empty'] = 'Pole nazwy użytkownika pozostało puste.';
$txt['error_db_filename_exists'] = 'Baza danych która próbujesz stworzyć już istnieje. Prosimy skasuj obecną bazę danych lub użyj innej nazwy.';
$txt['error_db_prefix_reserved'] = 'Prefiks który wpisałeś jest już zarezerwowany. Prosimy wpisz inny prefiks.';

$txt['upgrade_upgrade_utility'] = 'Narzędzie aktualizacji ElkArte';
$txt['upgrade_warning'] = 'Uwaga!';
$txt['upgrade_critical_error'] = 'Błąd krytyczny!';
$txt['upgrade_continue'] = 'Kontynuuj';
$txt['upgrade_retry'] = 'Spróbuj ponownie';
$txt['upgrade_skip'] = 'Pomiń';
$txt['upgrade_note'] = 'Uwaga!';
$txt['upgrade_step'] = 'Krok';
$txt['upgrade_steps'] = 'Kroki';
$txt['upgrade_progress'] = 'Postęp';
$txt['upgrade_overall_progress'] = 'Postęp całkowity';
$txt['upgrade_step_progress'] = 'Postęp kroku';
$txt['upgrade_time_elapsed'] = 'Czas trwania';
$txt['upgrade_time_mins'] = 'minut';
$txt['upgrade_time_secs'] = 'sekund';

$txt['upgrade_incomplete'] = 'Niekompletne';
$txt['upgrade_not_quite_done'] = 'Jeszcze nie ukończone!';
$txt['upgrade_paused_overload'] = 'Aktualizacja została zatrzymana aby nie spowodować przeciążenia serwera. Bez obaw wszystko działa jak należy - kliknij na przycisk <label for="contbutt">kontynuuj</label> aby przejść dalej.';

$txt['upgrade_ready_proceed'] = 'Dziękujemy za wybranie aktualizacji ElkArte do wersji %1$s. Wszystkie pliki są na swoim miejscu i jesteśmy gotowi do kontynuacji.';

$txt['upgrade_error_script_js'] = 'Skrypt aktualizacji nie mógł znaleźć pliku script.js lub nie jest on aktualny. Upewnij się, że ścieżka stylów jest poprawna. Możesz pobrać narzędzie do sprawdzania i naprawy ustawień ze strony <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">narzędzi ElkArte</a>.';

$txt['upgrade_warning_lots_data'] = 'Skrypt aktualizacji wykrył, że twoje forum zawiera bardzo dużo danych które muszą zostać zaktualizowane. Proces ten może potrwać trochę czasu w zależności od twojego serwera oraz wielkości forum, dla przykładu dla dużych for (~300,000 wiadomości) może potrwać kilka godzin.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';