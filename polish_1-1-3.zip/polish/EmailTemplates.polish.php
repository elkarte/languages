<?php
// Version: 1.1; EmailTemplates

// Since all of these strings are being used in emails, numeric entities should be used.

// Do not translate anything that is between {}, they are used as replacement variables and MUST remain exactly how they are.
//   Additionally do not translate the @additional_params: line or the variable names in the lines that follow it.  You may
//   translate the description of the variable.  Do not translate @description:, however you may translate the rest of that line.

// Do not use block comments in this file, they will have special meaning.

global $txtBirthdayEmails;

$txt['scheduled_approval_email_topic'] = 'Następujące tematy oczekują na zatwierdzenie:';
$txt['scheduled_approval_email_msg'] = 'Następujące wiadomości oczekują na zatwierdzenie:';
$txt['scheduled_approval_email_attach'] = 'Następujące załączniki oczekują na zatwierdzenie:';
$txt['scheduled_approval_email_event'] = 'Następujące wydarzenia oczekują na zatwierdzenie:';

/**
	@additional_params: resend_activate_message
		REALNAME: The display name for the member receiving the email.
		USERNAME:  The user name for the member receiving the email.
		ACTIVATIONLINK:  The url link to activate the member's account.
		ACTIVATIONCODE:  The code needed to activate the member's account.
		ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
		FORGOTPASSWORDLINK: The url to the "forgot password" page.
	@description:
*/
$txt['resend_activate_message_subject'] = 'Witamy na {FORUMNAME}';
$txt['resend_activate_message_body'] = 'Thank you for registering at {FORUMNAME}. Your username is {USERNAME}. If you forget your password, you can reset it by visiting {FORGOTPASSWORDLINK}

Before you can login, you must first activate your account by selecting the following link:

{ACTIVATIONLINK}

Should you have any problems with the activation, please visit {ACTIVATIONLINKWITHOUTCODE} and enter the code "{ACTIVATIONCODE}".

{REGARDS}';

/**
	@additional_params: resend_pending_message
		REALNAME: The display name for the member receiving the email.
		USERNAME:  The user name for the member receiving the email.
	@description:
*/
$txt['resend_pending_message_subject'] = 'Witamy na {FORUMNAME}';
$txt['resend_pending_message_body'] = 'Witaj {REALNAME}, Twoja prośba o rejestrację na {FORUMNAME} została otrzymana.

Nazwa użytkownika użyta podczas rejestracji to  {USERNAME}.

Przed rozpoczęciem korzystania z forum, Twoja prośba musi zostać zatwierdzona. Kiedy to się stanie zostaniesz poinformowany o tym w kolejnej wiadomości.

{REGARDS}';

/**
	@additional_params: mc_group_approve
		USERNAME: The user name for the member receiving the email.
		GROUPNAME: The name of the membergroup that the user was accepted into.
	@description: The request to join a particular membergroup has been accepted.
*/
$txt['mc_group_approve_subject'] = 'Akceptacja dołączenia do grupy uzytkowników';
$txt['mc_group_approve_body'] = '{USERNAME},

Jest nam miło poinformować, że Twoja prośba o dołączenie do grupy "{GROUPNAME}" na {FORUMNAME} została zatwierdzona, a konto zostało zaktualizowane.

{REGARDS}';

/**
	@additional_params: mc_group_reject
		USERNAME: The user name for the member receiving the email.
		GROUPNAME: The name of the membergroup that the user was rejected from.
	@description: The request to join a particular membergroup has been rejected.
*/
$txt['mc_group_reject_subject'] = 'Odrzucenie prośby o dołączenie do grupy użytkowników';
$txt['mc_group_reject_body'] = '{USERNAME},

Przykro nam, ale Twoja prośba o dołączenie do grupy "{GROUPNAME}" na {FORUMNAME} została odrzucona.

{REGARDS}';

/**
	@additional_params: mc_group_reject_reason
		USERNAME: The user name for the member receiving the email.
		GROUPNAME: The name of the membergroup that the user was rejected from.
		REASON: Reason for the rejection.
	@description: The request to join a particular membergroup has been rejected with a reason given.
*/
$txt['mc_group_reject_reason_subject'] = 'Odrzucenie prośby o dołączenie do grupy użytkowników';
$txt['mc_group_reject_reason_body'] = '{USERNAME},

Przykro nam, ale Twoja prośba o dołączenie do grupy "{GROUPNAME}" na {FORUMNAME} została odrzucona z podanego poniżej powodu:

{REASON}

{REGARDS}';

/**
	@additional_params: admin_approve_accept
		NAME: The display name of the member.
		USERNAME: The user name for the member receiving the email.
		PROFILELINK: The URL of the profile page.
		FORGOTPASSWORDLINK: The URL of the "forgot password" page.
	@description:
*/
$txt['admin_approve_accept_subject'] = 'Witamy na {FORUMNAME}';
$txt['admin_approve_accept_body'] = 'Welcome, {NAME}

Your account has been activated manually by the admin and you can now login and post. Your username is: {USERNAME}. If you forget your password, you can change it at {FORGOTPASSWORDLINK}

{REGARDS}';

/**
	@additional_params: admin_approve_activation
		USERNAME: The user name for the member receiving the email.
		ACTIVATIONLINK:  The url link to activate the member's account.
		ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
		ACTIVATIONCODE: The activation code.
	@description:
*/
$txt['admin_approve_activation_subject'] = 'Witamy na {FORUMNAME}';
$txt['admin_approve_activation_body'] = 'Witaj, {USERNAME}!

Twoje konto na {FORUMNAME} zostało zatwierdzone przez administratora. Przed rozpoczęciem korzystania z konta musisz je aktywować, w tym celu wystarczy odwiedzić tą stronę:

{ACTIVATIONLINK}

Jeśli występują problemy z aktywacją przejdź do strony {ACTIVATIONLINKWITHOUTCODE} i podaj kod aktywacyjny "{ACTIVATIONCODE}".

{REGARDS}';

/**
	@additional_params: admin_approve_reject
		USERNAME: The user name for the member receiving the email.
	@description:
*/
$txt['admin_approve_reject_subject'] = 'Rejestracja odrzucona';
$txt['admin_approve_reject_body'] = '{USERNAME},

Przykro nam, ale Twoja prośba o rejestrację na {FORUMNAME} została odrzucona.

{REGARDS}';

/**
	@additional_params: admin_approve_delete
		USERNAME: The user name for the member receiving the email.
	@description:
*/
$txt['admin_approve_delete_subject'] = 'Konto usunięte';
$txt['admin_approve_delete_body'] = '{USERNAME},

Twoje konto na {FORUMNAME} zostało usunięte. Może być to spowodowane brakiem aktywacji konta, w tym wypadku możesz ponownie się zarejestrować.

{REGARDS}';

/**
	@additional_params: admin_approve_remind
		USERNAME: The user name for the member receiving the email.
		ACTIVATIONLINK:  The url link to activate the member's account.
		ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
		ACTIVATIONCODE: The activation code.
	@description:
*/
$txt['admin_approve_remind_subject'] = 'Przypomnienie o rejestracji';
$txt['admin_approve_remind_body'] = '{USERNAME},
Wciąż nie aktywowałeś swojego konta na {FORUMNAME}.

W celu aktywacji konta odwiedź tą stronę:
{ACTIVATIONLINK}

Jeśli występują problemy z aktywacją przejdź do strony {ACTIVATIONLINKWITHOUTCODE} i podaj kod aktywacyjny "{ACTIVATIONCODE}".

{REGARDS}';

/**
	@additional_params:
		USERNAME: The user name for the member receiving the email.
		ACTIVATIONLINK:  The url link to activate the member's account.
		ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
		ACTIVATIONCODE: The activation code.
	@description:
*/
$txt['admin_register_activate_subject'] = 'Witamy na {FORUMNAME}';
$txt['admin_register_activate_body'] = 'Dziękujemy za zarejestrowanie się na {FORUMNAME}. Twoja nazwa użytkownika to {USERNAME}, a hasło to {PASSWORD}.

Przed rozpoczęciem korzystania z konta musisz je aktywować, w tym celu wystarczy odwiedzić tą stronę:

{ACTIVATIONLINK}

Jeśli występują problemy z aktywacją przejdź do strony {ACTIVATIONLINKWITHOUTCODE} i podaj kod aktywacyjny "{ACTIVATIONCODE}".

{REGARDS}';

$txt['admin_register_immediate_subject'] = 'Witamy na {FORUMNAME}';
$txt['admin_register_immediate_body'] = 'Dziękujemy za zarejestrowanie się na {FORUMNAME}. Twoja nazwa użytkownika to {USERNAME}, a hasło to {PASSWORD}.

{REGARDS}';

/**
	@additional_params: new_announcement
		TOPICSUBJECT: The subject of the topic being announced.
		MESSAGE: The message body of the first post of the announced topic.
		TOPICLINK: A link to the topic being announced.
	@description:
*/
$txt['new_announcement_subject'] = 'Nowe ogłoszenie: {TOPICSUBJECT}';
$txt['new_announcement_body'] = '{MESSAGE}

Aby zrezygnować z otrzymywania powiadomień zaloguj się na forum i odznacz "Otrzymuj powiadomienia i ważne informacje przez email." w ustawieniach profilu.

Pełną treść ogłoszenia możesz zobaczyć pod adresem:
{TOPICLINK}

{REGARDS}';

/**
	@additional_params: notify_boards_once_body
		TOPICSUBJECT: The subject of the topic causing the notification
		TOPICLINK: A link to the topic.
		MESSAGE: This is the body of the message.
		UNSUBSCRIBELINK: Link to unsubscribe from notifications.
	@description:
*/
$txt['notify_boards_once_body_subject'] = 'Nowy temat: {TOPICSUBJECT}';
$txt['notify_boards_once_body_body'] = 'W dziale który obserwujesz został wysłany nowy temat:  \'{TOPICSUBJECT}\'.

Możesz zobaczyć go pod tym adresem:
{TOPICLINK}

Mogło zostać wysłane więcej tematów, ale nie otrzymasz nowych powiadomień dopóki nie przeczytasz kliku tematów w dziale.

Treść wysłanej wiadomości:
{MESSAGE}

Możesz usunąć dział z listy obserwowanych pod tym adresem:
{UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notify_boards_once
		TOPICSUBJECT: The subject of the topic causing the notification
		TOPICLINK: A link to the topic.
		UNSUBSCRIBELINK: Link to unsubscribe from notifications.
	@description:
*/
$txt['notify_boards_once_subject'] = 'Nowy temat: {TOPICSUBJECT}';
$txt['notify_boards_once_body'] = 'W dziale który obserwujesz został wysłany nowy temat:  \'{TOPICSUBJECT}\'.

Możesz zobaczyć go pod tym adresem:
{TOPICLINK}

Mogło zostać wysłane więcej tematów, ale nie otrzymasz nowych powiadomień dopóki nie przeczytasz kliku tematów w dziale.

Możesz usunąć dział z listy obserwowanych pod tym adresem:
{UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notify_boards_body
		TOPICSUBJECT: The subject of the topic causing the notification
		TOPICLINK: A link to the topic.
		MESSAGE: This is the body of the message.
		UNSUBSCRIBELINK: Link to unsubscribe from notifications.
	@description:
*/
$txt['notify_boards_body_subject'] = 'Nowy temat: {TOPICSUBJECT}';
$txt['notify_boards_body_body'] = 'W dziale który obserwujesz został wysłany nowy temat:  \'{TOPICSUBJECT}\'.

Możesz zobaczyć go pod tym adresem:
{TOPICLINK}

Treść wysłanej wiadomości:
{MESSAGE}

Możesz usunąć dział z listy obserwowanych pod tym adresem:
{UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notify_boards
		TOPICSUBJECT: The subject of the topic causing the notification
		TOPICLINK: A link to the topic.
		UNSUBSCRIBELINK: Link to unsubscribe from notifications.
	@description:
*/
$txt['notify_boards_subject'] = 'Nowy temat: {TOPICSUBJECT}';
$txt['notify_boards_body'] = 'W dziale który obserwujesz został wysłany nowy temat:  \'{TOPICSUBJECT}\'.

Możesz zobaczyć go pod tym adresem:
{TOPICLINK}

Możesz usunąć dział z listy obserwowanych pod tym adresem:
{UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: request_membership
		RECPNAME: The name of the person receiving the email
		APPYNAME: The name of the person applying for group membership
		GROUPNAME: The name of the group being applied to.
		REASON: The reason given by the applicant for wanting to join the group.
		MODLINK: Link to the group moderation page.
	@description:
*/
$txt['request_membership_subject'] = 'Nowe zgłoszenie do grupy';
$txt['request_membership_body'] = '{RECPNAME},

{APPYNAME} prosi o dołączenie do grupy "{GROUPNAME}". Użytkownik podał następujący powód:

{REASON}

Możesz zatwierdzić lub odrzucić prośbę klikając na poniższy link:

{MODLINK}

{REGARDS}';

/**
	@additional_params: scheduled_approval
		REALNAME: The real (display) name of the person receiving the email.
		PROFILE_LINK: Link to profile of member receiving email where can renew.
		SUBSCRIPTION: Name of the subscription.
		END_DATE: Date it expires.
	@description:
*/
$txt['paid_subscription_reminder_subject'] = 'Wkrótce wygaśnie subskrypcja na {FORUMNAME}';
$txt['paid_subscription_reminder_body'] = '{REALNAME},

Twoja subskrypcja na forum {FORUMNAME} wkrótce wygaśnie. Jeśli podczas zamawiania subskrypcji wybrano opcję automatycznego odnawiania nie trzeba podejmować żadnej akcji  - w przeciwnym razie rozważ ponowne wykupienie subskrypcji. Poniżej znajdują się szczegóły:

Nazwa subskrypcji: {SUBSCRIPTION}
Wygasa: {END_DATE}

W celu edycji swoich subskrypcji odwiedź poniższy link:
{PROFILE_LINK}

{REGARDS}';

/**
	@additional_params: activate_reactivate
		ACTIVATIONLINK:  The url link to reactivate the member's account.
		ACTIVATIONCODE:  The code needed to reactivate the member's account.
		ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
	@description:
*/
$txt['activate_reactivate_subject'] = 'Witamy z powrotem na {FORUMNAME}';
$txt['activate_reactivate_body'] = 'W celu weryfikacji podanego adresu email twoje konto zostało dezaktywowane. Aby ponownie je aktywować kliknij na poniższy link:
{ACTIVATIONLINK}

Jeśli występują problemy z aktywacją przejdź do strony {ACTIVATIONLINKWITHOUTCODE} i podaj kod aktywacyjny "{ACTIVATIONCODE}".

{REGARDS}';

/**
	@additional_params: forgot_password
		REALNAME: The real (display) name of the person receiving the reminder.
		REMINDLINK: The link to reset the password.
		IP: The IP address of the requester.
		MEMBERNAME:
	@description:
*/
$txt['forgot_password_subject'] = 'Nowe hasło na {FORUMNAME}';
$txt['forgot_password_body'] = 'Dear {REALNAME},

This mail was sent because the \'forgot password\' function has been applied to your account. To set a new password, click the following link:
{REMINDLINK}

IP: {IP}
Username: {MEMBERNAME}

If you\'ve received this password-assistance email and you didn\'t request one, it\'s likely that another user entered your email address by mistake.  If you didn\'t initiate the request, don\'t worry - your account is secure, and there\'s no need for you to take any further action.
Your privacy and security aren\'t compromised by this email.

{REGARDS}';

/**
	@additional_params: forgot_password
		REALNAME: The real (display) name of the person receiving the reminder.
		IP: The IP address of the requester.
		OPENID: The members OpenID identity.
	@description:
*/
$txt['forgot_openid_subject'] = 'Przypomnienie identyfikatora OpenID na {FORUMNAME}';
$txt['forgot_openid_body'] = '{REALNAME},
Ta wiadomość została wysłana, ponieważ na twoim koncie użyto funkcji przypominania identyfikatora Open ID. Poniżej znajduje się powiązany z kontem identyfikator Open ID:
{OPENID}

IP: {IP}
Nazwa użytkownika: {MEMBERNAME}

{REGARDS}';

/**
	@additional_params: scheduled_approval
		REALNAME: The real (display) name of the person receiving the email.
		BODY: The generated body of the mail.
	@description:
*/
$txt['scheduled_approval_subject'] = 'Podsumowanie wiadomości oczekujących na zatwierdzenie na {FORUMNAME}';
$txt['scheduled_approval_body'] = '{REALNAME},

Ta wiadomość zawiera podsumowanie pozycji oczekujących na zatwierdzenie na {FORUMNAME}.

{BODY}

Zaloguj się na forum i przejrzyj kolejkę pozycji.
{SCRIPTURL}

{REGARDS}';

/**
	@additional_params: send_topic
		TOPICSUBJECT: The subject of the topic being sent.
		SENDERNAME: The name of the member sending the topic.
		RECPNAME: The name of the person receiving the email.
		TOPICLINK: A link to the topic being sent.
	@description:
*/
$txt['send_topic_subject'] = 'Temat: {TOPICSUBJECT} (Od: {SENDERNAME})';
$txt['send_topic_body'] = '{RECPNAME},
Sprawdź temat "{TOPICSUBJECT}" na {FORUMNAME}. Aby do niego przejść kliknij na poniższy link:

{TOPICLINK}

Dzięki,

{SENDERNAME}';

/**
	@additional_params: send_topic_comment
		TOPICSUBJECT: The subject of the topic being sent.
		SENDERNAME: The name of the member sending the topic.
		RECPNAME: The name of the person receiving the email.
		TOPICLINK: A link to the topic being sent.
		COMMENT: A comment left by the sender.
	@description:
*/
$txt['send_topic_comment_subject'] = 'Temat: {TOPICSUBJECT} (Od: {SENDERNAME})';
$txt['send_topic_comment_body'] = '{RECPNAME},
Sprawdź temat "{TOPICSUBJECT}" na {FORUMNAME}. Aby do niego przejść kliknij na poniższy link:

{TOPICLINK}

Dodano komentarz dotyczący tego tematu:
{COMMENT}

Dzięki,

{SENDERNAME}';

/**
	@additional_params: send_email
		EMAILSUBJECT: The subject the user wants to email.
		EMAILBODY: The body the user wants to email.
		SENDERNAME: The name of the member sending the email.
		RECPNAME: The name of the person receiving the email.
	@description:
*/
$txt['send_email_subject'] = '{EMAILSUBJECT}';
$txt['send_email_body'] = '{EMAILBODY}';

/**
	@additional_params: report_to_moderator
		TOPICSUBJECT: The subject of the reported post.
		POSTERNAME: The report post's author's name.
		REPORTERNAME: The name of the person reporting the post.
		TOPICLINK: The url of the post that is being reported.
		REPORTLINK: The url of the moderation center report.
		COMMENT: The comment left by the reporter, hopefully to explain why they are reporting the post.
	@description: When a user reports a post this email is sent out to moderators and admins of that board.
*/
$txt['report_to_moderator_subject'] = 'Raportowana wiadomość: {TOPICSUBJECT} przez {POSTERNAME}';
$txt['report_to_moderator_body'] = 'Wiadomość "{TOPICSUBJECT}" napisana przez {POSTERNAME} została raportowana przez {REPORTERNAME} w dziale który moderujesz:

Temat: {TOPICLINK}
Centrum moderacji: {REPORTLINK}

Użytkownik raportujący pozostawił komentarz:
{COMMENT}

{REGARDS}';

/**
	@additional_params: change_password
		USERNAME: The user name for the member receiving the email.
		PASSWORD: The password for the member.
	@description:
*/
$txt['change_password_subject'] = 'Nowe hasło';
$txt['change_password_body'] = '{USERNAME},

Dane logowania na forum {FORUMNAME} zostały zmienione, a hasło zresetowane. Poniżej znajdują się nowe dane logowania.

Twoja nazwa użytkownika to "{USERNAME}", a hasło to "{PASSWORD}".

Możesz je zmienić w profilu po zalogowaniu się lub przez kliknięcie na poniższy link:
{SCRIPTURL}?action=profile

{REGARDS}';

/**
	@additional_params: register_activate
		REALNAME: The display name for the member receiving the email.
		USERNAME: The user name for the member receiving the email.
		PASSWORD: The password for the member.
		ACTIVATIONLINK:  The url link to reactivate the member's account.
		ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
		ACTIVATIONCODE:  The code needed to reactivate the member's account.
		FORGOTPASSWORDLINK: The url to the "forgot password" page.
	@description:
*/
$txt['register_activate_subject'] = 'Witamy na {FORUMNAME}';
$txt['register_activate_body'] = 'Thank you for registering at {FORUMNAME}. Your username is {USERNAME}. If you forget your password, you can reset it by visiting {FORGOTPASSWORDLINK}

Before you can login, you first need to activate your account. To do so, please follow this link:

{ACTIVATIONLINK}

Should you have any problems with activation, please visit {ACTIVATIONLINKWITHOUTCODE} use the code "{ACTIVATIONCODE}".

{REGARDS}';

/**
	@additional_params: register_activate
		REALNAME: The display name for the member receiving the email.
		USERNAME: The user name for the member receiving the email.
		OPENID: The openID identity for the member.
		ACTIVATIONLINK:  The url link to reactivate the member's account.
		ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
		ACTIVATIONCODE:  The code needed to reactivate the member's account.
	@description:
*/
$txt['register_openid_activate_subject'] = 'Witamy na {FORUMNAME}';
$txt['register_openid_activate_body'] = 'Dziękujemy za zarejestrowanie się na {FORUMNAME}. Twoja nazwa użytkownika to {USERNAME}. Wybrałeś opcję logowania przez następujący identyfikator Open ID:
{OPENID}

Przed rozpoczęciem korzystania z konta musisz je aktywować, możesz to zrobić klikając na poniższy link:

{ACTIVATIONLINK}

Jeśli występują problemy z aktywacją przejdź do strony {ACTIVATIONLINKWITHOUTCODE} i podaj kod aktywacyjny "{ACTIVATIONCODE}".

{REGARDS}';

/**
	@additional_params: register_coppa
		REALNAME: The display name for the member receiving the email.
		USERNAME: The user name for the member receiving the email.
		PASSWORD: The password for the member.
		COPPALINK:  The url link to the coppa form.
		FORGOTPASSWORDLINK: The url to the "forgot password" page.
	@description:
*/
$txt['register_coppa_subject'] = 'Witamy na {FORUMNAME}';
$txt['register_coppa_body'] = 'Dziękujemy za zarejestrowanie się na {FORUMNAME}. Twoja nazwa użytkownika to {USERNAME}. Jeśli zapomnisz swoje hasło, możesz zresetować je pod tym adresem {FORGOTPASSWORDLINK}.

Zanim będziesz mógł się zalogować, administrator wymaga zgody rodzica/opiekuna na twoje uczestnictwo w społeczności forum. Więcej informacji uzyskasz pod tym adresem:

{COPPALINK}

{REGARDS}';

/**
	@additional_params: register_coppa
		REALNAME: The display name for the member receiving the email.
		USERNAME: The user name for the member receiving the email.
		OPENID: The openID identity for the member.
		COPPALINK:  The url link to the coppa form.
	@description:
*/
$txt['register_openid_coppa_subject'] = 'Witamy na {FORUMNAME}';
$txt['register_openid_coppa_body'] = 'Dziękujemy za zarejestrowanie się na {FORUMNAME}. Twoja nazwa użytkownika to {USERNAME}.

Wybrałeś opcję logowania przez następujący identyfikator Open ID:
{OPENID}

Zanim będziesz mógł się zalogować, administrator wymaga zgody rodzica/opiekuna na twoje uczestnictwo w społeczności forum. Więcej informacji uzyskasz pod tym adresem:

{COPPALINK}

{REGARDS}';

/**
	@additional_params: register_immediate
		REALNAME: The display name for the member receiving the email.
		USERNAME: The user name for the member receiving the email.
		PASSWORD: The password for the member.
		FORGOTPASSWORDLINK: The url to the "forgot password" page.
	@description:
*/
$txt['register_immediate_subject'] = 'Witamy na {FORUMNAME}';
$txt['register_immediate_body'] = 'Thank you for registering at {FORUMNAME}. Your username is {USERNAME}. If you forget your password, you may change it at {FORGOTPASSWORDLINK}

{REGARDS}';

/**
	@additional_params: register_immediate
		REALNAME: The display name for the member receiving the email.
		USERNAME: The user name for the member receiving the email.
		OPENID: The openID identity for the member.
	@description:
*/
$txt['register_openid_immediate_subject'] = 'Witamy na {FORUMNAME}';
$txt['register_openid_immediate_body'] = 'Dziękujemy, za zarejestrowanie się na {FORUMNAME}. Twoja nazwa użytkownika to {USERNAME}.

Wybrałeś opcję logowania przez następujący identyfikator Open ID:
{OPENID}

Możesz zaktualizować swój profil na poniższej stronie po zalogowaniu się:

{SCRIPTURL}?action=profile

{REGARDS}';

/**
	@additional_params: register_pending
		REALNAME: The display name for the member receiving the email.
		USERNAME: The user name for the member receiving the email.
		PASSWORD: The password for the member.
		FORGOTPASSWORDLINK: The url to the "forgot password" page.
	@description:
*/
$txt['register_pending_subject'] = 'Witamy na {FORUMNAME}';
$txt['register_pending_body'] = 'Hello {REALNAME}, your registration request at {FORUMNAME} has been received.

The username you registered with was {USERNAME}. If you forget your password, you can change it at {FORGOTPASSWORDLINK}

Before you can login and start using the forum, your request will be reviewed and approved.  When this happens, you will receive another email from this address.

{REGARDS}';

/**
	@additional_params: register_pending
		REALNAME: The display name for the member receiving the email.
		USERNAME: The user name for the member receiving the email.
		OPENID: The openID identity for the member.
	@description:
*/
$txt['register_openid_pending_subject'] = 'Witamy na {FORUMNAME}';
$txt['register_openid_pending_body'] = 'Witaj {REALNAME}, twoja prośba rejestracji na {FORUMNAME} została otrzymana.

Nazwa użytkownika użyta podczas rejestracji to {USERNAME}.

Wybrałeś opcję logowania przez następujący identyfikator Open ID:
{OPENID}

Przed rozpoczęciem korzystania z konta administrator musi je zweryfikować. Gdy to się stanie otrzymasz kolejną wiadomość z tego adresu.

{REGARDS}';

/**
	@additional_params: notification_reply
		TOPICSUBJECT:
		POSTERNAME:
		TOPICLINK:
		UNSUBSCRIBELINK:
	@description:
*/
$txt['notification_reply_subject'] = 'Odpowiedź w temacie: {TOPICSUBJECT}';
$txt['notification_reply_body'] = 'W temacie który obserwujesz użytkownik {POSTERNAME} wysłał nową odpowiedź.

Zobacz ją tutaj: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notification_reply_body
		TOPICSUBJECT:
		POSTERNAME:
		TOPICLINK:
		UNSUBSCRIBELINK:
		MESSAGE:
	@description:
*/
$txt['notification_reply_body_subject'] = 'Odpowiedź w temacie: {TOPICSUBJECT}';
$txt['notification_reply_body_body'] = 'W temacie który obserwujesz użytkownik {POSTERNAME} wysłał nową odpowiedź.

Zobacz ją tutaj: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

Treść odpowiedzi:
{MESSAGE}

{REGARDS}';

/**
	@additional_params: notification_reply_once
		TOPICSUBJECT:
		POSTERNAME:
		TOPICLINK:
		UNSUBSCRIBELINK:
	@description:
*/
$txt['notification_reply_once_subject'] = 'Odpowiedź w temacie: {TOPICSUBJECT}';
$txt['notification_reply_once_body'] = 'W temacie który obserwujesz użytkownik {POSTERNAME} wysłał nową odpowiedź.

Zobacz ją tutaj: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

Mogło zostać wysłane więcej odpowiedzi, ale nie dostaniesz nowych powiadomień dopóki nie przeczytasz tematu.

{REGARDS}';

/**
	@additional_params: notification_reply_body_once
		TOPICSUBJECT:
		POSTERNAME:
		TOPICLINK:
		UNSUBSCRIBELINK:
		MESSAGE:
	@description:
*/
$txt['notification_reply_body_once_subject'] = 'Odpowiedź w temacie: {TOPICSUBJECT}';
$txt['notification_reply_body_once_body'] = 'W temacie który obserwujesz użytkownik {POSTERNAME} wysłał nową odpowiedź.

Zobacz ją tutaj: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

Treść odpowiedzi:
{MESSAGE}

Mogło zostać wysłane więcej odpowiedzi, ale nie dostaniesz nowych powiadomień dopóki nie przeczytasz tematu.

{REGARDS}';

/**
	@additional_params: notification_sticky
	@description:
*/
$txt['notification_sticky_subject'] = 'Temat został przyklejony: {TOPICSUBJECT}';
$txt['notification_sticky_body'] = 'Temat, który obserwujesz, został przyklejony przez {POSTERNAME}.

Zobacz temat: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notification_lock
	@description:
*/
$txt['notification_lock_subject'] = 'Temat został zamknięty: {TOPICSUBJECT}';
$txt['notification_lock_body'] = 'Temat, który obserwujesz, został zamknięty przez {POSTERNAME}.

Zobacz temat: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notification_unlock
	@description:
*/
$txt['notification_unlock_subject'] = 'Temat został otworzony: {TOPICSUBJECT}';
$txt['notification_unlock_body'] = 'Temat, który obserwujesz, został otworzony przez {POSTERNAME}.

Zobacz temat: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notification_remove
	@description:
*/
$txt['notification_remove_subject'] = 'Temat został usunięty: {TOPICSUBJECT}';
$txt['notification_remove_body'] = 'Temat, który obserwujesz, został usunięty przez {POSTERNAME}.

{REGARDS}';

/**
	@additional_params: notification_move
	@description:
*/
$txt['notification_move_subject'] = 'Temat został przeniesiony: {TOPICSUBJECT}';
$txt['notification_move_body'] = 'Temat, który obserwujesz, został przeniesiony do innegio działu przez {POSTERNAME}.

Zobacz temat: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notification_merged
	@description:
*/
$txt['notification_merge_subject'] = 'Temat został połączony: {TOPICSUBJECT}';
$txt['notification_merge_body'] = 'Temat, który obserwujesz, został połączony z innym tematem przez {POSTERNAME}.

Zobacz nowy połączony temat: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: notification_split
	@description:
*/
$txt['notification_split_subject'] = 'Temat został podzielony: {TOPICSUBJECT}';
$txt['notification_split_body'] = 'Temat, który obserwujesz, został podzielony przez {POSTERNAME}.

Zobacz temat: {TOPICLINK}

Aby zrezygnować z powiadomień dotyczących tego tematu kliknij na ten link: {UNSUBSCRIBELINK}

{REGARDS}';

/**
	@additional_params: admin_notify
		USERNAME:
		PROFILELINK:
	@description:
*/
$txt['admin_notify_subject'] = 'Dołączył nowy użytkownik';
$txt['admin_notify_body'] = '{USERNAME} zarejestrował na forum nowe konto. Kliknij na poniższy link, aby przejść do profilu użytkownika.
{PROFILELINK}

{REGARDS}';

/**
	@additional_params: admin_notify_approval
		USERNAME:
		PROFILELINK:
		APPROVALLINK:
	@description:
*/
$txt['admin_notify_approval_subject'] = 'Dołączył nowy użytkownik';
$txt['admin_notify_approval_body'] = '{USERNAME} zarejestrował na forum nowe konto. Kliknij na poniższy link, aby przejść do profilu użytkownika.
{PROFILELINK}

Przed rozpoczęciem korzystania z konta musi ono zostać zatwierdzone. Kliknij na poniższy link, aby przejść do menu zatwierdzania.
{APPROVALLINK}

{REGARDS}';

/**
	@additional_params: admin_attachments_full
		REALNAME:
	@description:
*/
$txt['admin_attachments_full_subject'] = 'Pilne! Katalog załączników jest prawie pełen';
$txt['admin_attachments_full_body'] = '{REALNAME},

Katalog załączników na {FORUMNAME} jest prawie pełen. Odwiedź forum w celu rozwiązania problemu.

Gdy katalog załączników osiągnie maksymalny rozmiar użytkownicy nie będą mogli dodawać nowych załączników oraz awatarów (jeśli są włączone).

{REGARDS}';

/**
	@additional_params: admin_backup_database
		BAK_REALNAME: the name of the user doing the backup
	@description:
*/
$txt['admin_backup_database_subject'] = 'Została zrobiona kopia bazy danych.';
$txt['admin_backup_database_body'] = '{REALNAME},

This email is to inform you that {BAK_REALNAME} has just downloaded a backup of the database at {FORUMNAME}.

{REGARDS}';

/**
	@additional_params: editing_theme
		EDIT_REALNAME: the name of the user doing the backup
		FILE_EDITED: the name of the file being modified
		THEME_NAME: the name of the theme
	@description:
*/
$txt['editing_theme_subject'] = 'Edytowanie stylu';
$txt['editing_theme_body'] = '{REALNAME},

ten email został wysłany jako informacją, że {EDIT_REALNAME} wprowadza zmiany w plikach stylu:
{FILE_EDITED}
w stylu {THEME_NAME} na {FORUMNAME}.

Jeżeli jest to błąd, to prosimy o przyjrzeniu się sprawie.

{REGARDS}';

/**
	@additional_params: paid_subscription_refund
		NAME: Subscription title.
		REALNAME: Recipients name
		REFUNDUSER: Username who took out the subscription.
		REFUNDNAME: User's display name who took out the subscription.
		DATE: Today's date.
		PROFILELINK: Link to members profile.
	@description:
*/
$txt['paid_subscription_refund_subject'] = 'Zwrot kosztów płatnej subskrypcji';
$txt['paid_subscription_refund_body'] = '{REALNAME},

Użytkownik otrzymał zwrot kosztów płatnej subskrypcji. Poniżej znajdują się szczegóły subskrypcji:

	Subskrypcja: {NAME}
	Nazwa użytkownika: {REFUNDNAME} ({REFUNDUSER})
	Data: {DATE}

Możesz przejść do profilu użytkownika korzystając z linka:
{PROFILELINK}

{REGARDS}';

/**
	@additional_params: paid_subscription_new
		NAME: Subscription title.
		REALNAME: Recipients name
		SUBEMAIL: Email address of the user who took out the subscription
		SUBUSER: Username who took out the subscription.
		SUBNAME: User's display name who took out the subscription.
		DATE: Today's date.
		PROFILELINK: Link to members profile.
	@description:
*/
$txt['paid_subscription_new_subject'] = 'Nowa płatna subskrypcja';
$txt['paid_subscription_new_body'] = '{REALNAME},

Użytkownik aktywował nową subskrypcję. Poniżej znajdują się jej szczegóły:

	Subskrypcja: {NAME}
	Nazwa użytkownika: {SUBNAME} ({SUBUSER})
	Adres email użytkownika: {SUBEMAIL}
	Cena: {PRICE}
	Data: {DATE}

Możesz przejść do profilu użytkownika korzystając z linka:
{PROFILELINK}

{REGARDS}';

/**
	@additional_params: paid_subscription_error
		ERROR: Error message.
		REALNAME: Recipients name
	@description:
*/
$txt['paid_subscription_error_subject'] = 'Wystąpił błąd w płatnej subskrypcji';
$txt['paid_subscription_error_body'] = '{REALNAME},

Podczas przetwarzania płatnej subskrypcji wystąpił następujący błąd
---------------------------------------------------------------
{ERROR}

{REGARDS}';

/**
	@additional_params: new_pm
		SUBJECT: The personal message subject.
		SENDER:  The user name for the member sending the personal message.
		READLINK:  The link to directly access the read page.
		REPLYLINK:  The link to directly access the reply page.
	@description: A notification email sent to the receivers of a personal message
*/
$txt['new_pm_subject'] = 'Nowa prywatna wiadomość: {SUBJECT}';
$txt['new_pm_body'] = 'Użytkownik {SENDER} wysłał tobie nową prywatną wiadomość na {FORUMNAME}

WAŻNE: Pamiętaj, że jest to tylko powiadomienie. Nie wysyłaj odpowiedzi na ten email.

Przeczytaj prywatną wiadomość tutaj: {READLINK}

Wyślij odpowiedź na prywatną wiadomość tutaj: {REPLYLINK}';

/**
	@additional_params: new_pm_body
		SUBJECT: The personal message subject.
		SENDER:  The user name for the member sending the personal message.
		MESSAGE:  The text of the personal message.
		REPLYLINK:  The link to directly access the reply page.
	@description: A notification email sent to the receivers of a personal message
*/
$txt['new_pm_body_subject'] = 'Nowa prywatna wiadomość: {SUBJECT}';
$txt['new_pm_body_body'] = 'Użytkownik {SENDER} wysłał tobie nową prywatną wiadomość na {FORUMNAME}

WAŻNE: Pamiętaj, że jest to tylko powiadomienie. Nie wysyłaj odpowiedzi na ten email.

Treść wiadomości:

{MESSAGE}

Wyślij odpowiedź na prywatną wiadomość tutaj: {REPLYLINK}';

/**
	@additional_params: new_pm_tolist
		SUBJECT: The personal message subject.
		SENDER:  The user name for the member sending the personal message.
		READLINK:  The link to directly access the read page.
		REPLYLINK:  The link to directly access the reply page.
		TOLIST:  The list of users that will receive the personal message.
	@description: A notification email sent to the receivers of a personal message
*/
$txt['new_pm_tolist_subject'] = 'Nowa prywatna wiadomość: {SUBJECT}';
$txt['new_pm_tolist_body'] = '{SENDER} wysłał prywatną wiadomość do {TOLIST} na forum {FORUMNAME}

WAŻNE: Pamiętaj, jest to tylko powiadomienie. Nie wysyłaj odpowiedzi na ten email.

Przeczytaj prywatną wiadomość tutaj: {READLINK}

Odpowiedz na tą prywatną wiadomość tutaj (tylko do nadawcy): {REPLYLINK}';

/**
	@additional_params: new_pm_body_tolist
		SUBJECT: The personal message subject.
		SENDER:  The user name for the member sending the personal message.
		MESSAGE:  The text of the personal message.
		REPLYLINK:  The link to directly access the reply page.
		TOLIST:  The list of users that will receive the personal message.
	@description: A notification email sent to the receivers of a personal message
*/
$txt['new_pm_body_tolist_subject'] = 'Nowa prywatna wiadomość: {SUBJECT}';
$txt['new_pm_body_tolist_body'] = '{SENDER} wysłał prywatną wiadomość do {TOLIST} na forum {FORUMNAME}

WAŻNE: Pamiętaj, jest to tylko powiadomienie. Nie wysyłaj odpowiedzi na ten email.

Treść wysłanej wiadomości:

{MESSAGE}

Odpowiedz na tą prywatną wiadomość tutaj (tylko do nadawcy): {REPLYLINK}';

/**
	@additional_params: notify_new_buddy
		ACTIONNAME:  The user name of the member adding as buddy.
	@description: A notification email sent to the members that are set as buddy by someone
*/
$txt['notify_new_buddy_subject'] = '{ACTIONNAME} added you as buddy';
$txt['notify_new_buddy_body'] = '{REALNAME},

We wanted to let you know that {ACTIONNAME} has just added you as a buddy 
at {FORUMNAME}.  

{REGARDS}


You can unsubscribe to further "new buddy" notifications by using this link:
{UNSUBSCRIBELINK}
';
$txt['notify_new_buddy_digest'] = 'You have been added as buddy by:';
$txt['notify_new_buddy_snippet'] = '{ACTIONNAME}';

/**
	@additional_params: notify_new_likemsg
		ACTIONNAME:  The user name of the member that liked the message.
		MSGLINK:  The url to the message liked.
		SUBJECT: The subject of the message
	@description: A notification email sent to the members whose message has been liked
*/
$txt['notify_new_likemsg_subject'] = 'A message received a like';
$txt['notify_new_likemsg_body'] = '{REALNAME},

We wanted to let you know that {ACTIONNAME} has just liked your message 
in the "{SUBJECT}" topic at {FORUMNAME}.  
You can view that message by following this link:
{MSGLINK}

{REGARDS}


You can unsubscribe to further "liked by" notifications by using this link:
{UNSUBSCRIBELINK}
';
$txt['notify_new_likemsg_digest'] = 'The following messages has been liked:';
$txt['notify_new_likemsg_snippet'] = '{MSGLINK}';

/**
	@additional_params: notify_mentionmem
		ACTIONNAME:  The user name of the member that mentioned someone.
		MSGLINK:  The url to the message where someone has been mentioned.
        SUBJECT: The subject of the message
	@description: A notification email sent to the members mentioned by someone else in a message
*/
$txt['notify_mentionmem_subject'] = 'You have been mentioned';
$txt['notify_mentionmem_body'] = '{REALNAME},

We wanted to let you know that {ACTIONNAME} has just mentioned you in a message 
in the "{SUBJECT}" topic at {FORUMNAME}.  
You can view that message by following this link:
{MSGLINK}

{REGARDS}


You can unsubscribe to further "mentioned" notifications by using this link:
{UNSUBSCRIBELINK}
';
$txt['notify_mentionmem_digest'] = 'You have been mentioned in the following messages:';
$txt['notify_mentionmem_snippet'] = '{MSGLINK}';

/**
	@additional_params: notify_quotedmem
		ACTIONNAME:  The user name of the member that quoted someone's message.
		MSGLINK:  The url to the message where someone has been quoted.
        SUBJECT: The subject of the message
	@description: A notification email sent to the members quoted in someone else message
*/
$txt['notify_quotedmem_subject'] = 'Your message has been quoted';
$txt['notify_quotedmem_body'] = '{REALNAME},

We wanted to let you know that {ACTIONNAME} at {FORUMNAME} has just quoted
your messages in the "{SUBJECT}" topic.  You can view that message by 
following this link:
{MSGLINK}

{REGARDS}


You can unsubscribe to further "quoted message" notifications by using this link:
{UNSUBSCRIBELINK}
';
$txt['notify_quotedmem_digest'] = 'Your messages have been quoted in:';
$txt['notify_quotedmem_snippet'] = '{MSGLINK}';

/**
	@additional_params: happy_birthday
		REALNAME: The real (display) name of the person receiving the birthday message.
	@description: A message sent to members on their birthday.
*/

$txtBirthdayEmails['happy_birthday_subject'] = 'Wszystkiego najlepszego z okazji urodzin - {FORUMNAME}.';
$txtBirthdayEmails['happy_birthday_body'] = '{REALNAME},

Społeczność {FORUMNAME} pragnie złożyć Ci najlepsze życzenia urodzinowe! Niech ten dzień i kolejny rok będą pełne radości i sukcesów.

{REGARDS}';
$txtBirthdayEmails['happy_birthday_author'] = '<a href="http://www.simplemachines.org/community/?action=profile;u=2676">Thantos</a>';

$txtBirthdayEmails['karlbenson1_subject'] = 'W dniu Twoich urodzin...';
$txtBirthdayEmails['karlbenson1_body'] = 'Mogliśmy wysłać Ci kartkę urodzinową. Mogliśmy wysłać Ci bukiet kwiatów lub tort.

Ale tego nie zrobiliśmy.

Mogliśmy nawet wysłać Ci jedną z tych automatycznie generowanych wiadomości z życzeniami urodzinowymi, gdzie nawet nie trzeba umieszczać Twojego imienia.

Ale tego nie zrobiliśmy.

Napisaliśmy te Serdeczne Życzenia Urodzinowe dokładnie dla Ciebie!

Chcielibyśmy życzyć Ci naprawdę wyjątkowych urodzin!

{REGARDS}

//:: Ta wiadomość została wygenerowana automatycznie :://';
$txtBirthdayEmails['karlbenson1_author'] = '<a href="http://www.simplemachines.org/community/?action=profile;u=63186">karlbenson</a>';

$txtBirthdayEmails['nite0859_subject'] = 'Wszystkiego najlepszego!';
$txtBirthdayEmails['nite0859_body'] = '{REALNAME}, twoi znajomi na {FORUMNAME} chcieliby zabrać Ci chwilę Twojego czasu i złożyć Tobie Życzenia Urodzinowe! Jeśli nie robiłeś tego ostatnio, odwiedź forum, aby inni użytkownicy również mieli okazję złożyć Ci Życzenia!

Nawet w dniu Twoich urodzin, {REALNAME}, chcielibyśmy abyś pamiętał, że Twoje uczestnictwo w naszej społeczności, jest najlepszą rzeczą jaka nas dotąd spotkała.

Najlepsze życzenia,
Załoga {FORUMNAME}';
$txtBirthdayEmails['nite0859_author'] = '<a href="http://www.simplemachines.org/community/?action=profile;u=46625">nite0859</a>';

$txtBirthdayEmails['zwaldowski_subject'] = 'Życzenia urodzinowe dla {REALNAME}';
$txtBirthdayEmails['zwaldowski_body'] = '{REALNAME},

Minął kolejny rok w Twoim życiu! My, na {FORUMNAME} mamy nadzieję, że był on przepełniony szczęściem i życzymy Ci powodzenia na kolejny!

{REGARDS}';
$txtBirthdayEmails['zwaldowski_author'] = '<a href="http://www.simplemachines.org/community/?action=profile;u=72038">zwaldowski</a>';

$txtBirthdayEmails['geezmo_subject'] = 'Wszystkiego najlepszego, {REALNAME}!';
$txtBirthdayEmails['geezmo_body'] = '{REALNAME}, czy wiesz, kto dziś obchodzi urodziny? 

My wiemy... TY! 

Wszystkiego Najlepszego!

Jesteś teraz o rok starszy, ale mamy nadzieję, że jesteś bardziej szczęśliwy niż w rok temu! 

{REALNAME}, ciesz się dzisiejszym dniem!

- Od Twojej rodziny z {FORUMNAME}';
$txtBirthdayEmails['geezmo_author'] = '<a href="http://www.simplemachines.org/community/?action=profile;u=48671">geezmo</a>';

$txtBirthdayEmails['karlbenson2_subject'] = 'Twoje życzenia urodzinowe';
$txtBirthdayEmails['karlbenson2_body'] = 'Czy będzie pochmurnie, czy deszczowo, czy jakakolwiek inna aura, życzymy Ci, aby Twoje urodziny były The Best! 
Dużo tortów urodzinowych, zabawy, aha... i opowiedz nam co wyprawiałeś/aś! 

Mamy nadzieję, że ta wiadomość doda Ci otuchy aż do następnego roku, w tym samym miejscu i czasie! 

{REGARDS}';
$txtBirthdayEmails['karlbenson2_author'] = '<a href="http://www.simplemachines.org/community/?action=profile;u=63186">karlbenson</a>';
