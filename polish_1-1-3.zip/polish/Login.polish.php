<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Umowa rejestracyjna';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'Akceptuję';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Akceptuję i mam powyżej %1$d lat.';
$txt['agreement_agree_coppa_below'] = 'Akceptuję i mam mniej niż %1$d lat.';
$txt['agree_coppa_above'] = 'Mam powyżej %1$d lat.';
$txt['agree_coppa_below'] = 'Mam mniej niż %1$d lat.';

// Registration form.
$txt['registration_form'] = 'Formularz rejestracji';
$txt['error_too_quickly'] = 'Proces rejestracji przebiegł szybciej, niż jest to zazwyczaj możliwe. Poczekaj chwilę i spróbuj ponownie.';
$txt['error_token_verification'] = 'Weryfikacja nie powiodła się. Spróbuj ponownie.';
$txt['need_username'] = 'Musisz podać nazwę użytkownika.';
$txt['no_password'] = 'Nie podano hasła.';
$txt['improper_password'] = 'Podane hasło jest za długie.';
$txt['incorrect_password'] = 'Hasło niewłaściwe';
$txt['openid_not_found'] = 'Nie znaleziono podanego identyfikatora OpenID.';
$txt['maintain_mode'] = 'Forum chwilowo niedostępne';
$txt['registration_successful'] = 'Rejestracja zakończona pomyślnie';
$txt['valid_email_needed'] = 'Wpisz prawidłowy adres email, %1$s.';
$txt['required_info'] = 'Informacje wymagane';
$txt['additional_information'] = 'Informacje dodatkowe';
$txt['warning'] = 'Uwaga!';
$txt['only_members_can_access'] = 'Tylko zarejestrowani użytkownicy mają dostęp do tej sekcji.';
$txt['login_below'] = 'Zaloguj się poniżej.';
$txt['login_below_or_register'] = 'Zaloguj się poniżej lub <a href="%1$s">zarejestruj się</a> na %2$s';
$txt['checkbox_agreement'] = 'Akceptuję umowę rejestracyjną';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Ustawienia bezpieczeństwa zostały podniesione.<br />Proszę ponownie wpisać hasło.';

$txt['ban_register_prohibited'] = 'Przykro nam, nie możesz zarejestrować się na tym forum.';
$txt['under_age_registration_prohibited'] = 'Przykro nam, ale użytkownicy poniżej %1$d lat nie mają pozwolenia na rejestrację na tym forum.';

$txt['activate_account'] = 'Aktywacja konta';
$txt['activate_success'] = 'Twoje konto zostało aktywowane. Teraz możesz się zalogować.';
$txt['activate_not_completed1'] = 'Twój adres email musi zostać zweryfikowany, zanim będziesz mógł się zalogować.';
$txt['activate_not_completed2'] = 'Potrzebujesz następnego emaila aktywacyjnego?';
$txt['activate_after_registration'] = 'Dziękujemy za rejestrację. Wkrótce otrzymasz email z odnośnikiem potrzebnym do aktywacji konta. Jeśli nie otrzymałeś wiadomości aktywacyjnej sprawdź folder spamu.';
$txt['invalid_userid'] = 'Użytkownik nie istnieje';
$txt['invalid_activation_code'] = 'Nieprawidłowy kod aktywacyjny';
$txt['invalid_activation_username'] = 'Nazwa użytkownika lub email';
$txt['invalid_activation_new'] = 'Jeśli zarejestrowałeś się ze złym adresem wpisz właściwy adres i swoje hasło tutaj.';
$txt['invalid_activation_new_email'] = 'Nowy adres email';
$txt['invalid_activation_password'] = 'Stare hasło';
$txt['invalid_activation_resend'] = 'Wyślij kod aktywacyjny ponownie';
$txt['invalid_activation_known'] = 'Jeśli już znasz twój kod aktywacyjny, wpisz go tutaj.';
$txt['invalid_activation_retry'] = 'Kod aktywacyjny';
$txt['invalid_activation_submit'] = 'Aktywuj';

$txt['coppa_no_concent'] = 'Administrator wciąż nie otrzymał zgody twojego rodzica bądź opiekuna.';
$txt['coppa_need_more_details'] = 'Potrzebujesz więcej szczegółów?';

$txt['awaiting_delete_account'] = 'Twoje konto zostało zaznaczone jako do usunięcia!<br />Jeśli chcesz je odzyskać, proszę zaznaczyć "Reaktywuj moje konto" i zaloguj się ponownie.';
$txt['undelete_account'] = 'Reaktywuj moje konto';

$txt['in_maintain_mode'] = 'To forum jest w trybie obsługi.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Proszę przeczytaj i zaakceptuj warunki przed rejestracją.';
$txt['register_passwords_differ_js'] = 'Wpisane hasła nie są takie same !';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Dziękujemy za rejestrację. Administrator musi zatwierdzić Twoją rejestrację zanim będziesz mógł używać swojego konta. Wkrótce otrzymasz email z decyzją administratora.';

$txt['admin_settings_desc'] = 'Możesz tutaj zmienić rozmaite ustawienia dotyczące rejestracji nowych użytkowników.';

$txt['setting_enableOpenID'] = 'Zezwól użytkownikom na rejestrację używając OpenID';

$txt['setting_registration_method'] = 'Metoda rejestracji dla nowych użytkowników';
$txt['setting_registration_disabled'] = 'Rejestracja wyłączona';
$txt['setting_registration_standard'] = 'Natychmiastowa rejestracja';
$txt['setting_registration_activate'] = 'Aktywacja email';
$txt['setting_registration_approval'] = 'Zatwierdzenie użytkownika';
$txt['setting_notify_new_registration'] = 'Powiadom administrację gdy nowy użytkownik się dołącza';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Wysyłaj emaile powitalne nowym użytkownikom';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Wiek poniżej którego należy dać ograniczenia związane z rejestracją';
$txt['setting_coppaAge_desc'] = '(Aby wyłączyć wpisz 0)';
$txt['setting_coppaType'] = 'Co należy zrobić z użytkownikami próbującymi się zarejestrować poniżej wymaganego wieku';
$txt['setting_coppaType_reject'] = 'Odrzuć próbę rejestracji';
$txt['setting_coppaType_approval'] = 'Wymaga zatwierdzenia przez rodzica/opiekuna';
$txt['setting_coppaPost'] = 'Adres pocztowy na który należy wysyłać formularze zatwierdzające';
$txt['setting_coppaPost_desc'] = 'Tylko gdy rejestracja jest ograniczona wiekowo';
$txt['setting_coppaFax'] = 'Numer faksu na jaki mają być przesłane formularze zatwierdzające';
$txt['setting_coppaPhone'] = 'Numer kontaktowy dla rodziców w sprawie ograniczeń wiekowych';

$txt['admin_register'] = 'Rejestracja nowego użytkownika';
$txt['admin_register_desc'] = 'Tutaj możesz zarejestrować nowych użytkowników i jeśli chcesz wysłać im szczegóły emailem.';
$txt['admin_register_username'] = 'Nowa nazwa użytkownika';
$txt['admin_register_email'] = 'Adres email';
$txt['admin_register_password'] = 'Hasło';
$txt['admin_register_username_desc'] = 'Nazwa użytkownika dla nowego użytkownika';
$txt['admin_register_email_desc'] = 'Adres email użytkownika';
$txt['admin_register_password_desc'] = 'Nowe hasło dla użytkownika';
$txt['admin_register_email_detail'] = 'Wyślij hasło użytkownikowi';
$txt['admin_register_email_detail_desc'] = 'Adres email wymagany jest nawet, gdy nie zaznaczono tej opcji';
$txt['admin_register_email_activate'] = 'Użytkownik musi aktywować konto';
$txt['admin_register_group'] = 'Podstawowa grupa użytkowników';
$txt['admin_register_group_desc'] = 'Podstawowa grupa, do której będzie należał nowy użytkownik';
$txt['admin_register_group_none'] = '(brak podstawowej grupy użytkowników)';
$txt['admin_register_done'] = 'Użytkownik %1$s został zarejestrowany!';

$txt['coppa_title'] = 'Forum ograniczone wiekowo';
$txt['coppa_after_registration'] = 'Dziękujemy za rejestrację na {forum_name_html_safe}.<br /><br />Z powodu wieku poniżej {MINIMUM_AGE} lat, wymagane jest uzyskanie pozwolenia rodzica lub prawnego opiekuna przed rozpoczęciem korzystania z konta. W celu aktywowania konta wydrukuj poniższy formularz:';
$txt['coppa_form_link_popup'] = 'Pokaż formularz w nowym oknie';
$txt['coppa_form_link_download'] = 'Ściągnij formularz jako plik tekstowy';
$txt['coppa_send_to_one_option'] = 'Potem poproś swojego rodzica/opiekuna aby wysłał wypełniony formularz na adres:';
$txt['coppa_send_to_two_options'] = 'Potem poproś swojego rodzica/opiekuna aby wysłał wypełniony formularz:';
$txt['coppa_send_by_post'] = 'Wyślij na następujący adres:';
$txt['coppa_send_by_fax'] = 'Prześlij fax na następujący numer:';
$txt['coppa_send_by_phone'] = 'Alternatywnie możesz skontaktować się z administratorem poprzez numer telefonu {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Formularz pozwolenia na rejestrację na {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Adres';
$txt['coppa_form_date'] = 'Data';
$txt['coppa_form_body'] = 'Ja {PARENT_NAME},<br /><br />udzielam pozwolenia {CHILD_NAME} (nazwa dziecka) na założenie konta na: {forum_name_html_safe}, z nazwą użytkownika: {USER_NAME}.<br /><br />Rozumiem, że niektóre prywatne informacje podane przez {USER_NAME} mogą być widoczne dla innych użytkowników forum.<br /><br />Podpis:<br />{PARENT_NAME} (Rodzic/Opiekun).';

$txt['visual_verification_sound_again'] = 'Odtwórz';
$txt['visual_verification_sound_close'] = 'Zamknij okno';
$txt['visual_verification_sound_direct'] = 'Masz problem z odsłuchaniem? Spróbuj pobrać plik bezpośrednio.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Nazwa użytkownika jest dostępna';
$txt['registration_username_unavailable'] = 'Nazwa użytkownika jest niedostępna';
$txt['registration_username_check'] = 'Sprawdź czy nazwa użytkownika jest dostępna';
$txt['registration_password_short'] = 'Hasło jest za krótkie';
$txt['registration_password_reserved'] = 'Hasło zawiera twoją nazwę użytkownika/email';
$txt['registration_password_numbercase'] = 'Hasło musi zawierać wielkie i małe litery oraz cyfry';
$txt['registration_password_no_match'] = 'Hasła nie są takie same';
$txt['registration_password_valid'] = 'Hasło jest poprawne';

$txt['registration_errors_occurred'] = 'Następujące błędy zostały wykryte podczas rejestracji. Popraw je aby kontynuować:';

$txt['authenticate_label'] = 'Metoda uwierzytelnienia';
$txt['authenticate_password'] = 'Hasło';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'URL uwierzytelnienia OpenID';
$txt['otp_required'] = 'W celu zalogowania się musisz podać jednorazowe hasło!';
$txt['disable_otp'] = 'Wyłącz  uwierzytelnianie wielopoziomowe.';

// Contact form
$txt['admin_contact_form'] = 'Skontaktuj się z administratorem';
$txt['contact_your_message'] = 'Twoja wiadomość';
$txt['errors_contact_form'] = 'Następujące błędy zostały wykryte podczas wysyłania wiadomości';
$txt['contact_subject'] = 'Gość wysłał tobie wiadomość';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
