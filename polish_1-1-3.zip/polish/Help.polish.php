<?php
// Version: 1.1; Help

global $helptxt;

$txt['close_window'] = 'Zamknij okno';

$helptxt['manage_boards'] = '
<strong>Edytuj działy</strong><br />
	W tym menu możesz stworzyć/usunąć/zmienić kolejność działów i kategorii. Przykładowo, miałeś stronę o szerokiej tematyce takiej jak &quot;Sport&quot;, &quot;Motoryzacja&quot; i &quot;Muzyka&quot;. To byłyby kategorie najwyższego poziomu. Pod każdą z nich chciałbyś prawdopodobnie stworzyć hierarchiczne &quot;podkategorie&quot; lub &quot;działy&quot; dla tematów. To będzie prosta hierarchia ze strukturą: <br />
<br />
	<ul class="normallist">
		<li>
			<strong>Sport</strong>
			&nbsp;- A &quot;kategoria&quot;
			<ul class="normallist">
				<li>
					<strong>Bejzbol</strong>
					&nbsp;- Dział w kategorii &quot;Sport&quot;
					<ul class="normallist">
						<li>
							<strong>Statystyki</strong>
							&nbsp;- Poddział w &quot;Bejsbol&quot;
						</li>
					</ul>
				</li>
				<li><strong>Piłka nożna</strong>
				&nbsp;- Dział w kategorii&quot;Sport&quot;</li>
			</ul>
		</li>
	</ul>
	Kategorie pozwolą Ci na rozdzielenie forum z szerszych tematów (&quot;Motoryzacja, Sporty&quot;), a &quot;Fora&quot; pod nimi są tematy w których użytkownik może pisać.
	Użytkownik zainteresowany Pinto, napisałby wiadomość pod &quot;Motoryzacja->Pinto&quot;. Kategorie pozwolą ludziom szybko znaleźć konkretnie to, co ich interesuje: zamiast &quot;Sklep&quot; możesz mieć &quot;Sprzęt&quot; oraz &quot;Ubiór&quot;, sklepy do których możesz wejść. Zdecydowanie upraszcza wyszukiwanie &quot;płyta główna&quot;, ponieważ możesz przejść do &quot;kategorii&quot; sklepu - Sprzęt zamiast szukać w sklepie z ubiorem (gdzie raczej ciężko o płytę główną).<br /> Tak jak podano wyżej, 
	Dział jest konkretnym tematem w szerszej kategorii. Jeśli chcesz rozmawiać o &quot;Pinto&quot;, przejdziesz do kategorii &quot;Auto&quot;, a następnie wybierzesz dział Pinto i napiszesz to co masz namyśli.<br /> Funkcje zarządzania dla tego menu pozwalają na tworzenie działów dla każdej kategorii oraz zmiana ich kolejności (np. przesuń &quot;Pinto&quot; przed &quot;Chevy&quot;) 
	lub całkowite usunięcie działów.';

$helptxt['edit_news'] = '<ul class="normallist">  <li>  <strong>Aktualności</strong><br /> Ta sekcja pozwala wprowadzić tekst informacji o nowościach, wyświetlany na stronie głównej forum. Dodaj co tylko chcesz (np. &quot;Nie zapomnijcie o konferencji w najbliższy wtorek&quot;). Informacje te są wyświetlane losowo, każda w osobnej ramce. </li> <li> <strong>Newsletters</strong><br /> Ta sekcja pozwoli Ci na wysłanie masowej korespondencji do użytkowników forum. Najpierw musisz zaznaczyć nazwy grup użytkowników, do których chcesz wysłać newsletter. Jeśli sobie życzysz możesz dodatkowo dodać użytkowników lub adresy email którzy otrzymają newsletter. Ostatecznie możesz zdecydować w jakiej formie korespondencja ma być wysłana do użytkownika, za pomocą wiadomości prywatnej lub też wiadomości email. </li> <li> <strong>Ustawienia</strong><br /> Ta sekcja zawiera kilka ustawień dotyczących aktualności oraz korespondencji takich jak: dodawanie grup które mogą edytować aktualności i wysyłać korespondencję. Istnieje także opcja konfiguracji aktualności za pomocą której możesz je włączyć lub wyłączyć, ustawić długość znaków w wyświetlanej wiadomości. </li> </ul>';

$helptxt['view_members'] = '
	<ul class="normallist">
		<li>
			<strong>Przeglądanie użytkowników</strong><br />
			Przeglądaj wszystkich użytkowników forum. Zostanie wyświetlona lista użytkowników, z których każdy jest odnośnikiem do jego profilu. Jako administrator, możesz modyfikować profile użytkowników. Masz całkowitą kontrolę nad użytkownikami, włącznie z ich usunięciem z forum bez żadnego powiadamiania.<br /><br />
		</li>
		<li>
			<strong>Oczekujący na zatwierdzenie</strong><br />
			Ta sekcja pokazuje się tylko jeśli włączona jest opcja zatwierdzania wszystkich nowych użytkowników. Każdy rejestrujący się na forum staje się pełnym użytkownikiem dopiero po zatwierdzeniu przez admina. Ta sekcja wyświetla wszystkich tych użytkowników, którzy oczekują na zatwierdzenie. Pokazują się również ich emaile i adres IP. Możesz wybrać czy zatwierdzić, czy odrzucić (skasować) każdego użytkownika z listy, poprzez zaznaczenie użytkowników i wybranie odpowiedniej czynności z rozwijanej listy. Podczas odrzucania użytkownika możesz wybrać czy po usunięciu poinformować go emailem o swojej decyzji.<br /><br />
		</li>
		<li>
			<strong>Oczekujący na aktywację</strong><br />
			Ta sekcja pokazuje się tylko jeśli włączona jest opcja aktywacji kont użytkownika. Ta lista wyświetla wszystkich użytkowników, którzy jeszcze nie aktywowali swojego konta. Możesz wybrać czy aktywować te konta za nich, odrzucić, czy też przypomnieć o konieczności aktywacji konta. Tak jak powyżej, możesz poinformować lub nie użytkowników o swojej decyzji.<br /><br />
		</li>
	</ul>';

$helptxt['ban_members'] = '<strong>Ban użytkowników</strong><br />
	To pozwala na &quot;ban&quot; użytkowników którzy zakłócają działanie forum
	poprzez spamowanie, floodowanie, itp. Jako admin widzisz podczas przeglądania wiadomości adres IP każdego z użytkowników z którego wysłana została wiadomość.
	Możesz dodać dane IP do listy banów co zablokuje możliwość pisania wiadomości z tej lokacji. 	Możesz również banować użytkowników podając ich adres email.';

$helptxt['featuresettings'] = '<strong>Właściwości i opcje</strong><br />
	Jest tu kilka ustawień, które możesz zmienić według swoich preferencji.';

$helptxt['securitysettings'] = '<strong>Bezpieczeństwo i moderacja</strong><br />
	Ta sekcja zawiera ustawienia związane z bezpieczeństwem i moderacją forum.';

$helptxt['addonsettings'] = '<strong>Ustawienia dodatków</strong><br />
	Ta sekcja zawiera ustawienia dodane przez zainstalowane na forum modyfikacje.';

$helptxt['time_format'] = '<strong>Format czasu</strong><br />
	Masz możliwość zmiany wyglądu daty. Na początku może wydawać się to skomplikowane, ale takie nie jest.
	The conventions follow PHP\'s strftime function and are described as below (więcej szczegółów znajdziesz na <a href="http://www.php.net/manual/function.strftime.php" target="_blank" class="new_win">php.net</a>).<br />
	<br />
	Można wykorzystać następujące znaki:<br />
	<span class="smalltext">
	&nbsp;&nbsp;%a - skrócona nazwa dnia tygodnia<br />
	&nbsp;&nbsp;%A - pełna nazwa dnia tygodnia<br />
	&nbsp;&nbsp;%b - skrócona nazwa miesiąca<br />
	&nbsp;&nbsp;%B - pełna nazwa miesiąca<br />
	&nbsp;&nbsp;%d - dzień miesiąca (od 01 do 31) <br />
	&nbsp;&nbsp;%D<strong>*</strong> - to samo co %m/%d/%y <br />
	&nbsp;&nbsp;%e<strong>*</strong> - dzień miesiąca (od 1 do 31) <br />
	&nbsp;&nbsp;%H - godzina w formacie 24-godzinnym (od 00 do 23) <br />
	&nbsp;&nbsp;%I - godzina w formacie 12-godzinnym (od 01 do 12) <br />
	&nbsp;&nbsp;%m - numer miesiąca (od 01 do 12) <br />
	&nbsp;&nbsp;%M - minuty <br />
	&nbsp;&nbsp;%p - dodanie &quot;am&quot; lub &quot;pm&quot; w zależności od godziny<br />
	&nbsp;&nbsp;%R<strong>*</strong> - czas w formacie 24-godzinnym<br />
	&nbsp;&nbsp;%S - sekundy <br />
	&nbsp;&nbsp;%T<strong>*</strong> - obecny czas, to samo co %H:%M:%S <br />
	&nbsp;&nbsp;%y - dwucyfrowe oznaczenie roku (od 00 do 99) <br />
	&nbsp;&nbsp;%Y - czterocyfrowe oznaczenie roku<br />
	&nbsp;&nbsp;%% - znak \'%\'<br />
	<br />
	<em>* Nie działa na serwerach działających pod kontrolą systemu WIndows.</em></span>';

$helptxt['deleteAccount_posts'] = 'Tylko wiadomości: Ta opcja usunie tylko wiadomości, które zostały wysłane przez tego użytkownika jako odpowiedzi w tematach.<br />

	Wiadomości i tematy: Robi to samo co powyższa opcja, ale usuwa także wszystkie tematy rozpoczęte przez tego użytkownika.';

$helptxt['live_news'] = '<strong>Live announcements</strong><br />
	This box shows recently updated announcements from <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.
	You should check here every now and then for updates, new releases, and important information from ElkArte.';

$helptxt['registrations'] = '<strong>Zarządzanie rejestracją</strong><br />
	Ta sekcja zawiera wszystkie funkcje związane z zarządzaniem nowymi rejestracjami na forum. Jest podzielona na maksymalnie cztery działy, które są widoczne zależnie od ustawień Twojego forum:<br /><br />
	<ul class="normallist">
		<li>
<strong>Zarejestruj nowego użytkownika</strong><br />
			Tu możesz zarejestrować użytkownika na jego prośbę. Jest to przydatne na zamkniętych forach, lub gdy admin chce stworzyć konto testowe. Jeśli jest włączona opcja aktywacji konta, to do użytkownika zostanie wysłany emailem link aktywacyjny, który będzie musiał być kliknięty, by zacząć korzystać z konta. Ewentualnie można wybrać opcję, by przesłać użytkownikowi hasło na email.<br /><br />
		</li>
		<li>
			<strong>Edytuj umowę rejestracyjną</strong><br />
			W tym miejscu możesz zmienić umowę rejestracyjną, wyświetlaną podczas tworzenia nowego konta na forum.
			Możesz dodać, usunąć i zmienić wszystko co zostało standardowo zaproponowane przez ElkArte.<br /><br />
		</li>
		<li>
			<strong>Ustal zarezerwowane nazwy</strong><br />
			Tu ustalisz jakie wyrazy nie będą mogły być użyte przez użytkowników do stworzenia ich nazwy użytkownika.<br /><br />
		</li>
		<li>
			<strong>Ustawienia</strong><br />
			Ta sekcja będzie widoczna jedynie, jeśli masz zezwolenie na administrację forum. Tu możesz ustawić sposób rejestracji jaki będzie używany na forum, a także inne opcje, które są związane z rejestracją.
		</li>
	</ul>';

$helptxt['modlog'] = '<strong>Logi moderacji</strong><br />
	Ta sekcja pozwala użytkownikom z grupy moderacyjnej śledzić wszystkie czynności wykonane przez moderatorów na forum. Aby 
	moderatorzy nie mogli usunąć odwołań do akcji, które wykonali, wpisy nie mogą zostać usunięte przed upływem 24 godzin od ich wystąpienia.';
$helptxt['adminlog'] = '<strong>Logi administracji</strong><br /> Ta sekcja pozwala administratorom na śledzenie czynności administracyjnych wykonanych na forum. Aby się upewnić, że administratorzy nie usuną odnośników do czynności jakie wykonali, wejścia nie mogą zostać usunięte przez 24 godziny po dokonaniu czynności.';
$helptxt['badbehaviorlog'] = '<strong>Logi Bad Behavior</strong><br />
	Ta sekcja pozwala użytkownikom grupy administracyjnej na przeglądanie akcji związanych z działaniem Bad Behavior. Log jest automatycznie czyszczony i zawiera jedynie historię z ostatnich 7 dni.';
$helptxt['warning_enable'] = '<strong>System ostrzeżeń użytkowników</strong><br />
	Ta funkcja umożliwia administratorom i moderatorom na przyznawanie użytkownikom ostrzeżeń oraz ograniczanie uprawnienień w zależności od poziomu ostrzeżeń.
	Po aktywowaniu tej funkcji pojawi się nowe uprawnienie umożliwiające wybranie grup które mogą przyznawać ostrzeżenia.
	Ostrzeżenia mogą być zmienione z poziomu profilu użytkownika. Również są dostępne dodatkowe opcje:';
$helptxt['watch_enable'] = '<strong>Poziom ostrzeżeń do obserwacji użytkownika</strong><br />Ustawia poziom ostrzeżeń w procentach potrzebnych, aby użytkownik został automatycznie przydzielony do &quot;obserwacji&quot;. Każdy użytkownik, który jest pod &quot;obserwacją&quot; będzie widniał w odpowiedniej sekcji w centrum moderacji.';
$helptxt['moderate_enable'] = '<strong>Poziom ostrzeżeń dla moderacji wiadomości</strong><br /> Każdy użytkownik, który przekracza wartość tych ustawień, będzie musiał czekać aż moderator zaakceptuje jego wiadomość zanim będzie dostępna na forum. Nadpisze to ustawienia działów, które są powiązane z moderacją wiadomości.';
$helptxt['mute_enable'] = '<strong>Poziom ostrzeżeń do wyciszenia</strong><br />Jeżeli przekroczono tą wartość, to użytkownik dostanie ban na pisanie wiadomości. Użytkownik ten straci wszystkie prawa do pisania wiadomości.';
$helptxt['perday_limit'] = '<strong>Maksymalna ilość ostrzeżeń przyznanych przez okres jednego dnia</strong><br />To ustawienie ogranicza liczbę przydzielonych ostrzeżeń przez moderatora, tyczy się to do dodawania lub usuwania ostrzeżeń użytkownikom w ciągu 24 godzin. Może to być użyte, żeby ograniczyć to co moderator może zrobić w krótkim czasie. Ta opcja może być wyłączona poprzez ustawienie wartości równej zero. Pamiętaj, że te zezwolenia nie tyczą się do użytkowników którzy mają zezwolenia administratora.';
$helptxt['error_log'] = '<strong>Raport błędów forum</strong><br />
	Każdy błąd, który wystąpił podczas korzystania z forum zostaje zapisany. Domyślnie są sortowane po dacie.
	Za pomocą strzałek, można zmienić sortowanie, a dodatkowo można włączyć filtr, np. według użytkownika. 
	Podczas filtrowania, wyświetlą się jedynie te wpisy, które pasują do filtra.';
$helptxt['theme_settings'] = '<strong>Ustawienia stylu</strong><br />
	Tutaj można zmienić ustawienia dotyczące obecnego stylu, włączając w to opcje takie jak 
	katalog oraz adres URL stylu czy ustawienia layoutu forum. Większość stylów posiada rozmaite opcje 
	pozwalające na dostosowanie ustawień do indywidualnych potrzeb forum.';
$helptxt['smileys'] = '<strong>Centrum emotikon</strong><br />
	Tutaj możesz dodawać,  usuwać emotikony. Zauważ, że jeśli emotikona znajduje się w jednym zestawie, to istnieje również w pozostałych zestawach - w przeciwnym wypadku 	mogłoby by to dezorientować użytkowników forum używających różnych zestawów.<br /><br /> 

	Możesz tutaj również edytować ikony wiadomości, o ile włączyłeś je na stronie ustawień.';

$helptxt['calendar'] = '<strong>Zarządzanie kalendarzem</strong><br />
	Tutaj możesz edytować ustawienia kalendarza oraz dodawać i usuwać święta w nim występujące.';
$helptxt['calendar_settings'] = 'Kalendarz może być użyty w celu wyświetlania urodzin lub żeby pokazać ważne wydarzenia dotyczące forum.<br /><br />Pamiętaj, że korzystanie z kalendarza (dodawanie, przeglądanie  wydarzeń) jest kontrolowane przez specjalne uprawnienia.';
$helptxt['cal_days_for_index'] = 'Maksymalna ilość kolejnych dni wyświetlana w indeksie działów.<br />Jeśli jest ustawione na 7 zostaną wyświetlone wydarzenia z przyszłego tygodnia.';
$helptxt['cal_showevents'] = 'Włącza wyróżnianie wydarzeń w mini kalendarzu, głównym kalendarzu, w obydwu miejscach lub wyłącza wyróżnianie.';
$helptxt['cal_showholidays'] = 'To ustawienie pozwala na wyróżnianie świąt w mini kalendarzu, głównym kalendarzu, w obydwu miejscach lub wyłącza wyróżnianie.';
$helptxt['cal_showbdays'] = 'To ustawienie pozwala na wyróżnianie urodzin w mini kalendarzu, głównym kalendarzu, w obydwu miejscach lub wyłącza wyróżnianie.';
$helptxt['cal_export'] = 'Eksportuje plik tekstowy w formacie iCal w celu importowania go w innej aplikacji kalendarza.';
$helptxt['cal_daysaslink'] = 'Wyświetla dni jako linki do strony dodawania wydarzeń.<br />Pozwoli to użytkownikom na wysłanie wydarzenia dla danego dnia po kliknięciu na datę.';
$helptxt['cal_allow_unlinked'] = 'Pozwól na wydarzenia nie powiązane z wiadomością:<br />Umożliwia użytkownikom dodawanie wydarzeń bez wymogu powiązania z wiadomością na forum.';
$helptxt['cal_defaultboard'] = 'Domyślny dział do dodawania wydarzeń:<br />Podaj domyślny dział do wysłania wydarzenia.';
$helptxt['cal_showInTopic'] = 'Pokaż powiązane wydarzenia w widoku tematu:<br />Zaznacz w celu pokazania odnośnika do wydarzenia na górze tematu.';
$helptxt['cal_allowspan'] = 'Zezwól na kilkudniowe wydarzenia:<br />Zaznacz, aby było możliwe dodanie wydarzenia trwającego kilka dni.';
$helptxt['cal_maxspan'] = 'Maksymalna ilość dni trwania wydarzenia:<br />Podaj maksymalną ilość dni dla pojedynczego wydarzenia.';
$helptxt['cal_minyear'] = 'Rok początkowy:<br />Wybierz &quot;pierwszy&quot; rok znajdujący się w kalendarzu na forum.';
$helptxt['cal_maxyear'] = 'Rok końcowy:<br />Wybierz &quot;ostatni&quot; rok znajdujący się w kalendarzu na forum.';

$helptxt['serversettings'] = '<strong>Ustawienia serwera</strong><br />
	Tu możesz zmienić główne ustawienia forum. W tej sekcji znajdziesz ustawienia bazy danych, ścieżek URL,
	a także tych związanych z pocztą i pamięcią podręczną. Zastanów się przed zmianami w tym miejscu, 	gdyż błędy mogą spowodować brak dostępu do forum.';
$helptxt['manage_files'] = '
	<ul class="normallist">
		<li>
			<strong>Przeglądaj pliki</strong><br />
			Przeglądanie wszystkich załączników, awatarów i miniaturek zgromadzonych przez system.<br /><br />
		</li><li>
			<strong>Ustawienia załączników</strong><br />
			Skonfiguruj miejsce przechowywania załączników i ustaw ograniczenia na typy załączników.<br /><br />
		</li><li>
			<strong>Ustawienia awatarów</strong><br />
			Skonfiguruj miejsce przechowywania awatarów i ustaw zmianę wielkości awatarów.<br /><br />
		</li><li>
			<strong>Zarządzanie plikami</strong><br />
			Sprawdź i napraw jakiekolwiek błędy w katalogu załączników i usuń wybrane załączniki.<br /><br />
		</li>
	</ul>';

$helptxt['topicSummaryPosts'] = 'Ta opcja pozwala ustawić liczbę poprzednich wiadomości widocznych w podsumowaniu tematu podczas odpowiedzi.';
$helptxt['enableAllMessages'] = 'Ustawia <em>maksymalną</em> ilość wiadomości w temacie, dla którego zostanie wyświetlony link do wyświetlenia wszystkich wiadomości. Ustawienie tej ilości na mniej niż &quot;Maksymalna ilość wiadomości do wyświetlenia na stronie tematu&quot; spowoduje, że link nigdy się nie pojawi, a zbyt duża wartość może spowolnić forum.';
$helptxt['allow_guestAccess'] = 'Odznaczenie tej opcji wyłączy gościom wykonywanie większości czynności poza tymi najprostszymi - logowanie, rejestracja, przypomnienie hasła, itp. - na Twoim forum. Nie jest to to samo co uniemożliwienie gościom dostępu do działów.';
$helptxt['userLanguage'] = 'Włączenie tej opcji pozwoli użytkownikom na wybranie używanego na forum języka. Nie zmieni to domyślnego ustawienia.';
$helptxt['trackStats'] = 'Statystyki:<br />Pozwoli to użytkownikom na wyświetlanie najnowszych wiadomości oraz najpopularniejszych tematów na forum.
		Pokaże to również kilka innych statystyk takich jak największą ilość zalogowanych użytkowników, najnowszego użytkownika oraz nowe tematy.<hr />
		Wyświetlenia strony:<br />Dodaje kolejną kolumnę na stronie statystyk z ilością wyświetleń forum.';
$helptxt['enable_unwatch'] = 'Włączenie tej opcji umożliwi użytkownikom forum na wyłączenie powiadomień o nowych odpowiedziach w tematach w których wysłali oni odpowiedź.';
$helptxt['titlesEnable'] = 'Włączenie własnych tytułów pozwoli użytkownikom z odpowiednim uprawnieniem na dodanie sobie specjalnego tytułu.
		Zostanie on wyświetlony pod nazwą użytkownika.<br /><em>Przykład:</em><br />Jeff<br />Cool Guy';
$helptxt['onlineEnable'] = 'Pokazuje obrazek wskazujący czy użytkownik jest zalogowany lub wylogowany';
$helptxt['todayMod'] = 'To sformatuje &quot;Dzisiaj&quot; lub &quot;Wczoraj&quot; w różnych formatach zamiast pełnej daty.<br /><br />
		<strong>Przykłady:</strong><br /><br />
		<dl class="settings">
			<dt>Wyłączone</dt>
			<dd>Październik 3, 2009 at 12:59:18 am</dd>
			<dt>Relatywnie</dt>
			<dd>2 godziny temu</dd>
			<dt>Tylko dziś</dt>
			<dd>Dziś at 12:59:18 am</dd>
			<dt>Dziś i wczoraj</dt>
			<dd>Wczoraj at 09:36:55 pm</dd>
		</dl>';
$helptxt['disableCustomPerPage'] = 'Zaznacz tę opcję, aby uniemożliwić użytkownikom zmianę ilości wiadomości i tematów pokazywanych w indeksie tematów oraz w widoku tematu.';
$helptxt['enablePreviousNext'] = 'Ta opcja spowoduje wyświetlanie odnośnika do następnego i poprzedniego tematu.';
$helptxt['pollMode'] = 'Ta opcja włącza lub wyłącza ankiety. Jeżeli ankiety są wyłączone, to zwykłe tematy bez ankiet są pokazane.
<br /><br />Żeby wybrać kto może wysyłać ankiety, oglądać je i wykonywać podobne czynności możesz włączyć i wyłączyć te zezwolenia. Pamiętaj to jeżeli będzie wyglądało na to, że ankiety nie działają.';
$helptxt['enableVBStyleLogin'] = 'Włączenie tej opcji spowoduje wyświetlanie małego pola logowania na każdej stronie forum, tylko dla gości.';
$helptxt['enableCompressedOutput'] = 'Ta opcja skompresuje wysyłane dane w celu oszczędzania transferu, wymaga zainstalowanego modułu zlib.';
$helptxt['databaseSession_enable'] = 'Ta opcja wykorzystuje bazę danych do przechowywania informacji o sesjach - jest to najlepsze rozwiązanie dla serwerów wykorzystujących ładowanie zbalansowane, ale pomaga również przy wszelkich problemach z timeoutem i może przyspieszyć działanie forum.';
$helptxt['databaseSession_loose'] = 'Włączenie tej opcji spowoduje zmniejszenie transferu generowanego przez forum, oraz sprawi, że powrót do poprzedniej strony nie będzie skutkować jej przeładowaniem. Minusem jest między innymi to, że ikony nowych wiadomości nie odświeżą się (dopóki nie przejdziesz do niej kliknięciem zamiast przyciskiem powrotu).';
$helptxt['databaseSession_lifetime'] = 'To jest czas bezczynności w sekundach, po którym sesja wygaśnie. Jeśli czas bezczynności użytkownika przekroczy tą wartość kolejna akcja spowoduje wyświetlenie komunikatu &quot;sesja wygasła&quot;. Wartości powyżej 2400 sekund nie są zalecane.';
$helptxt['cache_enable'] = 'ElkArte korzysta z pamięci podręcznej w różnych poziomach. Wyższy poziom cache oznacza większe użycie procesora. Zalecane jest korzystanie z cache na poziomie 1.';
$helptxt['cache_memcached'] = 'If you are using memcached you need to provide the server details. This should be entered as a comma separated list as shown in the example below:<br /><br/>&quot;server1,server2,server3:port,server4&quot;<br /><br />Note that if no port is specified the software will use port 11211, set this to 0 when using UNIX domain sockets.';
$helptxt['cache_cachedir'] = 'To ustawienie dotyczy jedynie cache bazującego na plikach. Wyznacza ono ścieżkę do katalogu cache. Jeśli zamierzasz używać tej opcji zalecane jest umieszczenie go w katalogu /tmp/ ale będzie działało to w każdym innym katalogu.';
$helptxt['cache_uid'] = 'Niektóre systemy cache, np. Xcache, wymagają ID użytkownika oraz hasło w celu umożliwienia ElkArte na wyczyszczenie pamięci podręcznej.';
$helptxt['cache_password'] = 'Niektóre systemy cache, np. Xcache, wymagają ID użytkownika oraz hasło w celu umożliwienia ElkArte na wyczyszczenie pamięci podręcznej.';
$helptxt['enableErrorLogging'] = 'Ta opcja powoduje logowanie błędów, takich jak np. błędne logowania, aby można było zobaczyć, co poszło źle.';
$helptxt['enableErrorQueryLogging'] = 'Uwzględnia pełne zapytanie wysłane do bazy danych z jakimkolwiek błędem bazy. Wymaga włączenia rejestracji błędów.<br /><br /><strong>Uwaga:  Wpłynie to na możliwość filtrowania logu błędów po komunikacie błędu.</strong>';
$helptxt['allow_disableAnnounce'] = 'Ta opcja umożliwi użytkownikom wyłączenie powiadamiania o tematach, które administrator zaznaczył jako tematy do powiadamiania.';
$helptxt['disallow_sendBody'] = 'Ta opcja usuwa opcję otrzymywania treści odpowiedzi i wiadomości w powiadomieniach wysyłanych na email.<br /><br />Często użytkownicy odpowiadają na takie powiadomienia, a to w większości przypadków oznacza, że odpowiedź otrzymuje webmaster.';
$helptxt['enable_contactform'] = 'Ta opcja dodaje przycisk kontaktowy na stronie rejestracji';
$helptxt['jquery_source'] = 'Określa źródło ładowania biblioteki jQuery. Automatyczne użyje najpierw serwera CDN, a jeśli nie będzie on dostępny załadowana zostanie biblioteka z lokalnego źródła. Lokalne spowoduje użycie tylko lokalnego źródła, CDN załaduje ją tylko z serwerów CDN Google.';
$helptxt['jquery_default'] = 'Jeżeli chcesz używać inną wersję jQueryUI, niż ta która jest dostarczona razem z ElkArte, to zaznacz to pole i wpisz numer wersji X.XX.X Plik lokalny musi mieć taki sam format jak X.XX.X.min.js żeby można go było załadować.';
$helptxt['jqueryui_default'] = 'Jeżeli chcesz używać inną wersję jQueryUI, niż ta która jest dostarczona razem z ElkArte, to zaznacz to pole i wpisz numer wersji X.XX.X Plik lokalny musi mieć taki sam format jak X.XX.X.min.js żeby można go było załadować.';
$helptxt['minify_css_js'] = 'Połączy to pliki CSS oraz JS według potrzeb strony. Usunie także niepotrzebne białe znaki oraz komentarze z plików w celu zmniejszenia ich rozmiaru. Połączone i skompresowane pliki są zapisane, aby przyszłe żądania mogły z nich skorzystać, bez ponownego generowania.<br />Podczas pierwszego generowania plików może pojawić się małe opóźnienie w załadowaniu strony (tak samo będzie po wyczyszczeniu pamięci cache).';
$helptxt['compactTopicPagesEnable'] = 'Pokaże to podaną ilość poprzednich lub kolejnych stron.<br /><em>Przykład:</em>
		&quot;3&quot; wyświetli: 1 ... 4 [5] 6 ... 9 <br />
		&quot;5&quot; wyświetli: 1 ... 3 4 [5] 6 7 ... 9';
$helptxt['timeLoadPageEnable'] = 'Pokaże na dole strony ile czasu zajęło wygenerowanie strony.';
$helptxt['removeNestedQuotes'] = 'Ta opcja wyłączy wklejanie zagnieżdżonych cytatów, podczas cytowania wiadomości.';
$helptxt['search_dropdown'] = 'To pokaże rozwijane menu wyszukiwania, które jest obok okna szybkiego wyszukiwania. Z tego możesz wybrać, aby szukać aktualną stronę, aktualny dział (jeżeli w jakimś dziale), aktualnym temacie (jeżeli w jakimś temacie) albo szukać użytkowników.';
$helptxt['max_image_width'] = 'Ta opcja pozwala na ustawienie maksymalnego rozmiaru wysyłanych obrazków. Nie będzie to miało wpływu na obrazki mniejsze niż maksymalna ustawiona wartość. Także determinuje jak załączone obrazki będą się wyświetlać po kliknięciu na nie.';
$helptxt['mail_type'] = 'To ustawienie pozwala Ci wybrać pomiędzy domyślnymi ustawieniami PHP a zastąpieniem tych ustawień przez SMTP. PHP nie obsługuje autoryzacji SMTP (której wiele serwerów aktualnie wymaga), tak więc jeśli jest ona dla Ciebie konieczna, powinieneś wybrać SMTP. Miej na uwadze, że SMTP może działać wolniej, a niektóre serwery mogą nie przyjmować nazwy użytkownika i hasła.<br /><br />Nie musisz wypełniać ustawień SMTP jeśli zdecydowałeś się na domyślne ustawienia PHP.';
$helptxt['mail_batch_size'] = 'Tu ustawienie określa ile wiadomości email jest wysyłane przy każdym załadowaniu strony i nie może być wyższe niż maksymalna dozwolona ilość wysyłanych na minutę.<br />Pozostawienie ustawienia na 0 spowoduje automatyczne rozdzielenie ilości wysyłanych wiadomości.<br />Jeśli chcesz podać własne ustawienia dobrym rozwiązaniem jest podanie maksymalnych dozwolonych wartości lub 1/6 limitów.';
$helptxt['smtp_client'] = 'Used to identify this client to the SMTP server.<br />The field should contain the fully-qualified domain name (FQDN) of the SMTP client. In situations in which the client system does not have a meaningful domain name you can instead use an address literal formatted as [ipv4] or [IPv6:ipv6 address].<br />If left blank the system will attempt to detect this value for you.';

$helptxt['attachmentEnable'] = 'Włącz lub wyłącz system załączników, lub wyłącz możliwość dodawania nowych załączników.';
$helptxt['attachmentRecodeLineEndings'] = 'Włączenie tej opcji spowoduje ponowne kodowanie zakończeń linii w plikach tekstowych (txt, css, html, php, xml) znajdujących się na serwerze (Windows, Mac or Unix).';
$helptxt['automanage_attachments'] = 'Funkcja ta utworzy strukturę katalogów według wybranej opcji. Może być ona utworzona według daty wysłania (rozdzieli załączniki według roku, roku i miesiąca lub według roku, miesiąca i dnia) lub dopiero po osiągnięciu maksymalnego rozmiaru katalogu. Każdy utworzony katalog będzie miał takie same limity rozmiaru i ilości plików.';
$helptxt['use_sub-directories_for_attachments'] = 'To stworzy nowe foldery jako podfoldery głównej lokalizacji załączników.';
$helptxt['attachmentDirSizeLimit'] = 'Ustaw maksymalny rozmiar katalogu załączników.';
$helptxt['attachmentDirFileLimit'] = 'Ustaw maksymalną ilość plików w katalogu załączników';
$helptxt['attachmentPostLimit'] = 'Wybierz jak duże mogą być załączniki w jednej wiadomości (w KiB), to jest rozmiar wszystkich załączników wysłanych w wiadomości.';
$helptxt['attachmentSizeLimit'] = 'Ustaw maksymalny rozmiar jednego wysyłanego w wiadomości załącznika.';
$helptxt['attachmentNumPerPostLimit'] = 'Ustaw maksymalną ilość wysyłanych w wiadomości załączników.';
$helptxt['attachmentCheckExtensions'] = 'Zaznacz to pole, aby włączyć filtrowanie załączników. Oznacza to, że będzie się dało jedynie wysłać pliki w formatach które zostały przez Ciebie wcześniej ustalone.';
$helptxt['attachmentExtensions'] = 'Ustal jakie typy załączników będą dozwolone, na przykład: jpg,png,gif Pamiętaj, aby być ostrożnym jakie rozszerzenia wybierasz, ponieważ niektóre mogą narazić Twoją stronę na niebezpieczeństwo.';
$helptxt['attachment_image_paranoid'] = 'Zaznaczenie tej opcji umożliwi bardzo rygorystyczne sprawdzanie załączonych obrazków. Ostrzeżenie! Ta szczegółowa kontrola może nie przepuścić nawet prawidłowych obrazków. Zdecydowanie zalecamy używanie tej opcji wraz z przekodowywaniem obrazków w celu próbkowania przez ElkArte tych, które nie zdadzą testu bezpieczeństwa - jeśli to się powiedzie, zostaną wyczyszczone oraz załadowane. W przeciwnym wypadku, jeśli przekodowywanie jest wyłączone, każdy obrazek, który nie przejdzie testu bezpieczeństwa, zostanie odrzucony.';
$helptxt['attachment_autorotate'] = 'Selecting this option will allow the system to detect rotated images, typical of phone cameras, and automatically adjust the orientation such that the image top is oriented up. Requires either ImageMagick or both GD and Exif modules to be available.';
$helptxt['attachmentShowImages'] = 'Jeśli wysyłany załącznik jest obrazem zostanie wyświetlony on pod wiadomością.';
$helptxt['attachmentThumbnails'] = 'Włącz to jeżeli chcesz, aby obrazki w wiadomościach były pomniejszane do miniaturek, które po naciśnięciu powiększą się do oryginalnych rozmiarów.';
$helptxt['attachment_thumb_png'] = 'Miniaturki które wyświetlają się pod wiadomością, będą utworzone tylko jako pliki png.';
$helptxt['attachmentThumbWidth'] = 'Używane z opcją &quot;Zmień rozmiar obrazka podczas wyświetlania pod wiadomością&quot;, maksymalna szerokość grafiki po zmniejszeniu. Proporcje zostaną zachowane.';
$helptxt['attachmentThumbHeight'] = 'Używane z opcją &quot;Zmień rozmiar obrazka podczas wyświetlania pod wiadomością&quot;, maksymalna wysokość grafiki po zmniejszeniu. Proporcje zostaną zachowane.';
$helptxt['attachment_image_reencode'] = 'Zaznaczenie tej opcji umożliwi przekodowywanie załączonych obrazków. Przekodowywanie oferuje większe bezpieczeństwo. Uwaga, przekodowywanie powoduje wyświetlanie wszystkich animowanych obrazków jako statyczne. <br /> Ta funkcja jest dostępna tylko wtedy, gdy moduł GD jest zainstalowany na serwerze.';
$helptxt['attachment_thumb_memory'] = 'Im większy plik źródłowy (waga & szerokość x wysokość), tym większe wymagania pamięci, żeby system pomyślnie stworzył miniaturki.<br /> Jeżeli zaznaczono tą opcję, system oszacuje wymaganą pamięć i dopiero potem zarząda tą ilość. Jeżeli pomyślnie, to tylko wtedy spróbuje stworzyć miniaturkę/<br />W rezultacie będzie mniej błędów z białą stroną, ale może też być mniej utworzonych miniatur. Jeżeli zostawisz tą opcję niezaznaczoną, system zawsze będzie starał się stworzyć miniaturkę (ze stałą ilością pamięci). W rezultacie może być więcej błędów z białą stroną.';
$helptxt['max_image_height'] = 'Maksymalna wysokość wyświetlanego załącznika graficznego.';
$helptxt['max_image_width'] = 'Ta opcja pozwala na ustawienie maksymalnego rozmiaru wysyłanych obrazków. Nie będzie to miało wpływu na obrazki mniejsze niż maksymalna ustawiona wartość. Także determinuje jak załączone obrazki będą się wyświetlać po kliknięciu na nie.';
$helptxt['attachmentUploadDir'] = 'Wybierz gdzie chcesz zapisywać wysłane załączniki na twoim serwerze. Może się znajdować na zewnątrz folderu public html dla dodatkowego bezpieczeństwa.';
$helptxt['attachment_transfer_empty'] = 'Włączenie tego przeniesie wszystkie pliki z źródłowego katalogu do nowej lokacji, w przeciwnym razie maksymalna liczba dozwolonych plików ustalona na katalog zostanie przeniesiona.';
$helptxt['avatar_paranoid'] = 'Zaznaczenie tej opcji umożliwi bardzo rygorystyczne sprawdzanie awatarów. Ostrzeżenie! Ta szczegółowa kontrola może nie przepuścić nawet prawidłowych awatarów. Zdecydowanie zalecamy używanie tej opcji wraz z przekodowywaniem obrazków w celu próbkowania przez ElkArte tych, które nie zdadzą testu bezpieczeństwa - jeśli to się powiedzie, zostaną wyczyszczone oraz załadowane. W przeciwnym wypadku, jeśli przekodowywanie jest wyłączone, każdy awatar, który nie przejdzie testu bezpieczeństwa, zostanie odrzucony.';
$helptxt['avatar_reencode'] = 'Zaznaczenie tej opcji umożliwi przekodowywanie załadowanych awatarów. Przekodowywanie oferuje większe bezpieczeństwo. Uwaga, przekodowywanie powoduje wyświetlanie wszystkich animowanych awatarów jako statyczne. <br />Funkcja jest dostępna tylko wtedy, gdy moduł GD jest zainstalowany na serwerze.';
$helptxt['karmaMode'] = 'Reputacja to możliwość pokazania popularności użytkownika na forum. Użytkownicy, jeśli mają udzielone zezwolenie, mogą zagłosować na innych użytkowników klikając 
		\'popieram\' lub \'potępiam\'. Administrator może zmienić minimalną ilość wiadomości napisanych przez użytkownika, powyżej której użytkownik ma prawo zdobywania reputacji, czas pomiędzy 
		głosowaniem na tego samego użytkownika, oraz czy admini również muszą czekać.<br /><br />Zezwolenie na głosowanie jest ustawiane dla grupy, lub użytkownika poprzez zezwolenia. 
		Jeśli ktoś na forum ma problemy, sprawdź jeszcze raz zezwolenia.';
$helptxt['localCookies'] = 'ElkArte używa ciasteczek (cookies) do przechowywania informacji na komputerze użytkownika. Ciasteczka mogą być przechowywane globalnie (mojserwer.com) lub lokalnie (mojserwer.com/sciezka/do/forum).<br />
Zaznacz tą opcję jeśli występują problemy polegające na automatycznym wylogowywaniu użytkowników.<hr />
Ciasteczka przechowywane globalnie są mniej bezpieczne jeśli są używane na współdzielonym serwerze (np. Tripod).<hr />
Ciasteczka lokalne nie działają poza katalogiem forum, tak więc jeśli Twoje forum jest zainstalowane w www.mojserwer.com/forum, strony w stylu www.mojserwer.com/index.php nie będą w stanie uzyskać dostępu do informacji o koncie użytkownika.
Globalne ciasteczka są szczególnie polecane gdy używasz SSI.php.';
$helptxt['enableBBC'] = 'Zaznaczenie tej opcji pozwoli użytkownikom na korzystanie w wiadomościach z kodów BBC, dzięki czemu będą mogli umieszczać obrazki, formatować tekst, itp.';
$helptxt['time_offset'] = 'Nie wszyscy administratorzy chcą aby forum używało tej samej strefy czasowej co serwer. Użyj tej opcji aby ustawić różnicę (w godzinach) między czasem na serwerze a godziną na forum. Dozwolone są wartości ujemne oraz ułamkowe.';
$helptxt['default_timezone'] = 'Strefa czasowa serwera informuje PHP o tym, gdzie znajduje się twój serwer. Powinieneś upewnić się czy to ustawienie jest poprawne, najlepiej według kraju/miasta w którym znajduje się serwer. Więcej informacji znajdziesz na <a href="http://www.php.net/manual/en/timezones.php" target="_blank">stronie PHP</a>.';
$helptxt['spamWaitTime'] = 'Tutaj możesz ustawić czas po upływie którego można napisać kolejną wiadomość. Ta opcja chroni przed "spamowaniem" ustalając jak często użytkownicy mogą wysyłać wiadomość.';

$helptxt['enablePostHTML'] = 'Włączenie tej opcji umożliwi korzystanie w wiadomościach z podstawowych znaczników HTML:
	<ul class="normallist enablePostHTML">
		<li>&lt;b&gt;, &lt;u&gt;, &lt;i&gt;, &lt;s&gt;, &lt;em&gt;, &lt;ins&gt;, &lt;del&gt;</li>
		<li>&lt;a href=&quot;&quot;&gt;</li>
		<li>&lt;img src=&quot;&quot; alt=&quot;&quot; /&gt;</li>
		<li>&lt;br /&gt;, &lt;hr /&gt;</li>
		<li>&lt;pre&gt;, &lt;blockquote&gt;</li>
	</ul>';

// Initial theme settings - Manage and Install
$helptxt['themes'] = 'W tej sekcji możesz zadecydować czy użytkownik może wybrać styl domyślny, jaki styl widzą goście i inne opcje związane ze stylami. Kliknij na stylu po prawej stronie, by zmienić jego ustawienia.';
$helptxt['theme_install'] = 'This section permits you to install new themes. You do this by uploading an archived file for the theme from your personal computer, installing from a theme directory on the host server or by copying the default theme and renaming that copied file.<br /><br />Please remember this: the archived file or directory must have a <span class="alert">theme_info.xml</span> definition file as a part of the archive or the directory.';
$helptxt['theme_forum_theme'] = 'Zmiana domyślnego stylu forum nie wpływa na użytkowników, którzy wybrani jeden z dostępnych stylów. Musisz wybrać również "Ustaw wszystkim użytkownikom styl", żeby zmusić ich do nowego domyślnego stylu. Możesz również zmienić domyślny styl forum, jaki jest widziany przez Gości i zresetować użytkowników do używania innego stylu. <br /><br />Pamiętaj, że jeżeli użytkownicy mają zezwolenia na zmianę stylów, to mogą nadpisać styl który został wybrany przez Ciebie.';

// Theme Management and Options - Theme settings
$helptxt['themeadmin_list_reset'] = 'W rzadkich przypadkach ścieżka Twojego stylu zostanie zagubiona i forum nie będzie się wyświetlać poprawnie. Może to być spowodowane pomyłką administratora, błędem bazy danych, niepoprawną aktualizacją oprogramowania, instalacją modów lub innych zdarzeń. Zresetowanie linków URL do stylu prawdopodobnie naprawi ten problem.';
$helptxt['themeadmin_delete_help'] = 'Domyślny styl nie może być usunięty, ponieważ popsuło by to forum, a także inne style.  Jednak możesz usunąć każdy styl który posiada czerwony "X", wystarczy że go naciśniesz.<br /><br /> Pamiętaj: Usuwając styl, nie usuwasz go z serwera, a tylko jego dostępność do użycia na forum. Musisz wejść na swój serwer FTP, lub użyć panelu ze swojego hostingu żeby całkowicie usunąć styl z serwera. Nigdy nie usuwaj stylu "default".';

$helptxt['enableVideoEmbeding'] = 'Ta opcja pozwala na automatyczną konwersję standardowych linków w osadzone pliki wideo, kiedy wiadomość jest przeglądana. Aktualnie wspierane są tylko YouTube, Vimeo i Dailymotion.';
$helptxt['enableCodePrettify'] = 'Załaduje to skrypt Prettify, który będzie podświetlał kod znajdujący się w tagu code. Dodaje on styl do kodu, dzięki czemu jest on bardziej czytelny.';
// @todo Add more information about how to use them here.
$helptxt['xmlnews_enable'] = 'Zezwól na łączenie się z <a href="%1$s?action=.xml;sa=news" target="_blank" class="new_win">Ostatnimi aktualnościami</a>
	itp. Polecamy ograniczyć rozmiar liczby ostatnich wiadomości/aktualności ze względu na to,
	że niektóre czytniki RSS, jak np. Trillian, je obetną..';
$helptxt['hotTopicPosts'] = 'Zmienia liczbę wiadomości, która jest wymagana do oznaczenia tematu jako &quot;gorący&quot; lub
	&quot;bardzo gorący&quot; temat. Wybierz opcję polubień, aby bazować to na podstawie liczby polubień zamiast liczby wiadomości.';
$helptxt['globalCookies'] = 'Pozwala na używanie ciasteczek do logowania na subdomenach. Na przykład, jeżeli...<br />
	twoja strona to http://www.myserver.com/,<br />
	a twoje forum jest pod adresem http://forum.myserver.com/,<br />
	Ta opcja pozwoli Ci na dostęp ciasteczek forum. Nie włączaj tego jeżeli są inne subdomeny (takie jak hacker.elkarte.net), które nie są kontrolowane przez Ciebie.<br />
	Ta opcja nie działa jeżeli są włączone lokalne ciasteczka.';
$helptxt['globalCookiesDomain'] = 'Określ główną domenę, która będzie użyta do ciasteczek logowania (login cookies) dostępnych poprzez subdomeny';
$helptxt['httponlyCookies'] = 'Jeżeli to ustawienie jest włączone, ciasteczka nie będą dostępne przez inne języki programowania takie jak JavaScript. Pozwala to ograniczyć kradzieże tożsamości i ataki XSS. Może to spowodować problemy ze skryptami osób trzecich, ale jego włączenie jest rekomendowane jeżeli możliwe.';
$helptxt['secureCookies'] = 'Włączenie tej opcji spowoduje wymuszenie oznaczenia cookies stworzonych dla użytkowników Twojego forum jako bezpieczne. Włącz tę opcję tylko wtedy, gdy używasz bezpiecznego protokołu HTTPS, w przeciwnym wypadku uszkodzi to obsługę cookies!';
$helptxt['admin_session_lifetime'] = 'To kontroluje czas aktywnej sesji administratora. Sesja zostanie zakończona kiedy ten czas wygaśnie, wymagając wpisanie ponownego uwierzytelnienia żeby kontynuować. Minimalna wartość to 5 minut, a maksymalna to 14400 minut (jeden dzień). Silnie zalecamy ustawienie niższych wartości niż 60 minut, ze względów bezpieczeństwa.';
$helptxt['auto_admin_session'] = 'Kontroluje czy administracyjna sesja jest aktywowana podczas logowania.';
$helptxt['securityDisable'] = 'Opcja <em>wyłącza</em> dodatkowe sprawdzanie hasła przy wchodzeniu do sekcji administracyjnej. Nie jest to zalecane!';
$helptxt['securityDisable_why'] = 'Jest to Twoje obecne hasło. (to samo którego używasz do logowania.)<br /><br />Wymuszając ponowne wpisanie hasła, system sprawdza czy na pewno <strong>Ty</strong> chcesz wykonać jakiekolwiek czynności administracyjne.';
$helptxt['securityDisable_moderate'] = 'Ta opcja <em>wyłączy</em> dodatkowe sprawdzanie hasła w centrum moderacji. Nie jest to zalecane!';
$helptxt['securityDisable_moderate_why'] = 'Jest to Twoje bieżące hasło. (to samo którego używasz do logowania.)<br /><br />Wymuszając ponowne wpisanie hasła, system sprawdza czy na pewno <strong>Ty</strong> chcesz wykonać jakiekolwiek czynności moderacyjne.';
$helptxt['enableOTP'] = 'Enabling this feature allows another layer of security for a member\'s account. Two-factor authentication, or 2FA, is a way of logging into websites that requires more than just a password. Using a password to log into a website is susceptible to security threats, because it represents a single piece of information a malicious person needs to acquire. The added security that 2FA provides is requiring additional information to sign in.<br /><br />A Time-based One-Time Password (TOTP) application such as Google Authenticator or Authy automatically generates an authentication code that changes after a certain period of time.';
$helptxt['emailmembers'] = 'W tej wiadomości możesz użyć kilku &quot;zmiennych&quot;. Są to:<br /> 
	{$board_url} - Adres URL Twojego forum.<br />
	{$current_time} - Aktualny czas.<br />
	{$member.email} - Adres e-mail aktualnego użytkownika.<br />
	{$member.link} - Link do profilu aktualnego użytkownika.<br />
	{$member.id} - ID aktualnego użytkownika..<br />
	{$member.name} - Nazwa aktualnego użytkownika. (do personalizacji).<br />
	{$latest_member.link} - Link do profilu ostatnio zarejestrowanego użytkownika.<br />
	{$latest_member.id} - ID ostatnio zarejestrowanego użytkownika.<br />
	{$latest_member.name} - Nazwa ostatnio zarejestrowanego użytkownika.';
$helptxt['attachmentEncryptFilenames'] = 'Kodowanie nazwy załącznika umożliwia posiadanie więcej niż jednego załącznika o tej samej nazwie i wzmocnienia ochrony. Jednakże może to utrudnić odbudowę bazy danych w pewnych drastycznych przypadkach.';

$helptxt['failed_login_threshold'] = 'Ustawia liczbę nieudanych prób logowania zanim użytkownik zostanie przekierowany do strony z przypomnieniem hasła.';
$helptxt['loginHistoryDays'] = 'Ilość dni do przechowywania historii logowania w profilu użytkownika. Domyślnie jest to 30 dni.';
$helptxt['oldTopicDays'] = 'Jeśli ta opcja jest włączona, użytkownik zobaczy ostrzeżenie podczas próby napisania wiadomości w temacie, w którym nikt nic nie napisał w podanej tutaj ilości dni. Ustawienie ilości dni na 0 spowoduje wyłączenie pokazywania ostrzeżeń.';
$helptxt['edit_wait_time'] = 'Liczba sekund, w których można jeszcze edytować wiadomość zanim zastanie zapisana informacja o dacie ostatniej modyfikacji.';
$helptxt['edit_disable_time'] = 'Liczba minut po upływie których użytkownik nie będzie mógł edytować napisanej przez siebie wiadomości. Ustaw 0 by wyłączyć.<br /><br /><em>Pamiętaj: Opcja ta nie wpłynie na użytkowników mających pozwolenie na edycję wiadomości pozostałych użytkowników.</em>';
$helptxt['preview_characters'] = 'Ta opcja ustawia liczbę dostępnych znaków dla pierwszych i ostatnich wiadomości pokazanych w podglądzie. <strong>Pamiętaj</strong>, że to tylko pokazuje informacje dostępne w stylu, dany styl musi wspierać ustawienie &quot;Show post previews on the message index&quot;';
$helptxt['posts_require_captcha'] = 'To ustawienie zmusza użytkowników do przejścia weryfikacji anty-spam, za każdym razem, kiedy chcą napisać wiadomość na forum. Tylko użytkownicy o ilości napisanych wiadomości, mniejszej niż ustawiona liczba, będą zmuszeni przejść tę procedurę. To powinno pomóc zwalczać spamowanie przez automatyczne skrypty.';
$helptxt['enableSpellChecking'] = 'Enable spell checking. You MUST have the pspell library installed on your server and your PHP configuration set up to use the pspell library. Your server ' . (function_exists('pspell_new') ? 'DOES' : 'DOES NOT') . ' appear to have this set up.';
$helptxt['lastActive'] = 'Ustawia liczbę minut przez które użytkownicy będą widoczni na głównej stronie forum jako aktywni. Domyślnie 15 minut.';

$helptxt['customoptions'] = 'Ta sekcja definiuje opcje dostępne dla użytkownika z listy rozwijalnej. Jest klika kluczowych punktów do zauważenia w tej sekcji:
	<ul class="normallist">
		<li><b>Opcje Domyślne:</b> Zależnie, które opcje mają &quot;przycisk radio&quot; zaznaczony, będą one domyślnym wyborem użytkownika gdy otworzy swój profil.</li>
		<li><b>Usuwanie Opcji:</b> Aby usunąć opcję po prostu odznacz ją - wszyscy użytkownicy z zaznaczoną daną opcją, będą mieli ją odznaczoną.</li>
		<li><b>Zmiana kolejności Opcji:</b> Możesz zmienić kolejność opcji poprzez przeniesienie tekstu pomiędzy boksami. Jednakże - ważna uwaga - musisz upewnić się, że <b>nie</b> przenosisz tekstu, podczas zmiany kolejności opcji, w innym wypadku dane użytkownika zostaną utracone.</li>
	</ul>';

$helptxt['autoOptDatabase'] = 'Ta opcja zoptymalizuje bazę danych co zadaną ilość dni. Ustaw 1, aby optymalizować bazę danych codziennie. Możesz również określić maksymalną ilość zalogowanych użytkowników będących na forum. Dzięki temu nie przeciążysz serwera i nie sprawisz, że użytkownicy będą niezadowoleni z powolnego działania forum.';
$helptxt['autoFixDatabase'] = 'Automatycznie naprawia uszkodzone tabele i przywraca działanie forum tak, jakby nic się nie stało. Może być to użyteczne, ponieważ jedynym sposobem na naprawę jest naprawa tabeli, a dzięki temu forum nie będzie wyłączone dopóki nie dowiesz się o awarii. Zostaniesz powiadomiony emailem jeśli coś takiego się stanie.';

$helptxt['enableParticipation'] = 'Ta opcja pokazuje małą ikonkę przy tematach, w których użytkownik napisał.';
$helptxt['enableFollowup'] = 'Pozwoli to użytkownikom na rozpoczęcie nowego tematu cytując dowolną wiadomość.';

$helptxt['db_persist'] = 'Ustal stałe połączenie z bazą danych aby zwiększyć wydajność. Jeśli nie korzystasz z serwera dedykowanego, może to powodować problemy z Twoim hostem.';
$helptxt['ssi_db_user'] = 'Opcjonalne ustawienie, które zezwoli na użycie innej nazwy użytkownika oraz hasła do bazy danych, jeśli używasz SSI.php.';

$helptxt['queryless_urls'] = 'Zamienia format linków URL, aby wyszukiwarki je bardziej lubiły. Będą wyglądać podobnie do index.php/topic,1.0.html.';
$helptxt['countChildPosts'] = 'Po włączeniu tej opcji, przy działach zawierających poddziały pojawi się liczba wiadomości będąca sumą poddziałów. <br /><br />Może to znacząco spowolnić forum, ale dzięki temu działy z poddziałami niezawierające wiadomości nie będą pokazywać 0 wiadomości.';
$helptxt['allow_ignore_boards'] = 'Zaznaczenie tej opcji umożliwi użytkownikom wybranie działów, które chcieliby ignorować.';
$helptxt['deny_boards_access'] = 'Zaznaczenie tej opcji pozwoli na zablokowanie dostępu do wyznaczonych działów, na podstawie zezwoleń grup';

$helptxt['who_enabled'] = 'Ta opcja pozwala Tobie włączyć lub wyłączyć możliwość sprawdzania użytkownikom kto przegląda forum i co kto robi.';

$helptxt['recycle_enable'] = '&quot;Przywraca&quot; usunięte tematy i wiadomości w określonym dziale.';

$helptxt['enableReportPM'] = 'Ta opcja pozwala twoim użytkownikom na zgłaszanie prywatnych wiadomości, które otrzymali, do ekipy administracyjnej. Może być to pomocne przy tropieniu nadużyć systemu prywatnych wiadomości.';
$helptxt['max_pm_recipients'] = 'Ta opcja pozwala na ustawienie maksymalnej ilości odbiorców wiadomości prywatnych, wysyłanych przez użytkownika forum. Może być to użyteczne do powstrzymania spamu wysyłanego przy użyciu systemu PW. Pamiętaj, że użytkownicy z uprawnieniami do wysyłania newsletterów nie są objęci tym ograniczeniem. Wpisanie wartości zerowej spowoduje wyłączenie limitu.';
$helptxt['pm_posts_verification'] = 'To ustawienie wymusi na użytkownikach wprowadzenie kodu z obrazka przy każdym wysyłaniu prywatnej wiadomości. Tylko użytkownicy o liczbie wiadomości poniżej wybranej liczby będą musieli wpisywać kod. Ta funkcja powinna pomóc w walce z automatycznym spamem.';
$helptxt['pm_posts_per_hour'] = 'Ogranicza liczbę prywatnych wiadomości jaką użytkownik może wysłać w ciągu godziny. Nie wpływa to na administratorów i moderatorów.';

$helptxt['default_personal_text'] = 'Ustawia domyślny tekst, który nowy użytkownik będzie posiadać jako &quot;tekst osobisty.&quot; Ta opcja jest niedostępna jeżeli teksty osobiste są wyłączone, lub kiedy użytkownicy własnoręcznie wybierają tekst osobisty przy rejestracji.';

$helptxt['modlog_enabled'] = 'Loguj wszystkie czynności moderacyjne.';

$helptxt['registration_method'] = 'Ta opcja umożliwia wybór metody rejestracji, przez osoby chcące dołączyć do użytkowników forum. Masz wybór pomiędzy:<br /><br />
	<ul class="normallist">
		<li>
			<strong>Rejestracja wyłączona</strong><br />
				Wyłącza proces rejestracji, co oznacza że nowi użytkownicy nie będą mogli się zarejestrować..<br />
		</li><li>
			<strong>Rejestracja natychmiastowa</strong><br />
				Nowi użytkownicy mogą zalogować się i pisać wiadomości bezpośrednio po rejestracji.<br />
		</li><li>
			<strong>Aktywacja użytkownika</strong><br />
				Nowi użytkownicy po rejestracji otrzymają email z odnośnikiem do aktywacji konta. Dopiero po kliknięciu staną się pełnoprawnymi użytkownikami forum.<br />
		</li><li>
			<strong>Zatwierdzenie użytkownika</strong><br />
				Nowi użytkownicy po rejestracji muszą zaczekać, aż ich rejestrację zatwierdzi administrator.
		</li>
	</ul>';
$helptxt['register_openid'] = '<strong>Identyfikacja z OpenID</strong><br />
	OpenID pozwala na używanie jednej nazwy użytkownika pomiędzy różnymi stronami, w celu ulepszenia doznań z przeglądania sieci. Aby użyć OpenID musisz najpierw stworzyć konto OpenID - listę dostawców znajdziesz na <a href="http://openid.net/" target="_blank">Oficjalnej stronie OpenID</a><br /><br />
	Kiedy już będziesz miał konto OpenID po prostu wpisz swój unikatowy adres identyfikacyjny do pola wprowadzania i wyślij. Zostaniesz przeniesiony na witrynę dostawcy w celu sprawdzenia tożsamości, przed przyznaniem dostępu do strony.<br /><br />
	Podczas pierwszej wizyty na stronie zostaniesz poproszony o potwierdzenia paru detali zanim zostaniesz rozpoznany, po czym będziesz mógł się zalogować na stronę i zmienić swoją konfigurację profilu używając swojego OpenID.<br /><br />
	Po więcej informacji odwiedź <a href="http://openid.net/" target="_blank">Oficjalną stronę OpenID</a>';

$helptxt['send_validation_onChange'] = 'Gdy ta opcja jest zaznaczona wszyscy użytkownicy którzy zmienią swój adres email w profilu będą musieli reaktywować swoje konto poprzez email wysłany na nowy adres.';
$helptxt['send_welcomeEmail'] = 'Gdy ta opcja jest włączona nowi użytkownicy otrzymają emaila witającego ich na Twoim forum.';
$helptxt['password_strength'] = 'To ustawienie określa wymaganą siłę haseł użytkowników Twojego forum. Im silniejsze jest hasło, tym trudniej je odgadnąć lub złamać.
	Dostępne są następujące ustawienia dla siły haseł. 
	<ul class="normallist">
		<li><strong>Niska:</strong> Hasło musi mieć długość co najmniej czterech znaków.</li>
		<li><strong>Średnia:</strong> Hasło musi mieć długość co najmniej ośmiu znaków i nie może być częścią nazwy użytkownika lub jego adresu email.</li>
		<li><strong>Wysoka:</strong> To samo, co w Średnim, poza tym, że hasło musi składać się z dużych i małych liter oraz co najmniej jednej cyfry.</li>
	</ul>';
$helptxt['enable_password_conversion'] = 'To ustawienie pozwoli ElkArte na próbę wykrycia haseł przechowywanych w innych formatach i przekonwertuje na rozpoznawane przez system. Głównie używane na forach po konwersji, ale może mieć też inne zastosowania. Wyłączenie tego, powoduje że użytkownicy logujący się na forum po konwersji muszą zresetować hasła.';

$helptxt['coppaAge'] = 'Wartość podana w tym polu określa minimalny wiek użytkownika pozwalający na natychmiastową rejestrację na forum.
	Podczas rejestracji użytkownik będzie musiał potwierdzić, czy przekroczył określony wiek. Jeżeli odpowiedź będzie negatywna rejestracja zostanie odrzucona lub zawieszona do momentu potwierdzenia przez dorosłego opiekuna - w zależności od wybranego trybu.
	Jeżeli zostanie wpisane 0 wszelkie restrykcje związane z wiekiem będą ignorowane.';
$helptxt['coppaType'] = 'Jeśli ograniczenia wieku są włączone, to w tym miejscu można wybrać w jaki sposób traktować osoby poniżej wymaganego wieku. Do wyboru są dwa tryby:
	<ul class="normallist">
		<li>
			<strong>Odrzucenie próby rejestracji:</strong><br />
				Każdy próba rejestracji nowego użytkownika poniżej wymaganego wieku zostanie odrzucona.<br />
		</li><li>
			<strong>Wymóg zatwierdzenia przez rodzica bądź opiekuna</strong><br />
				Każdy nowy użytkownik poniżej wymaganego wieku, musi przesłać zgodę rodziców bądź opiekunów, zanim jego konto zostanie aktywowane. 
				Zostanie też przesłany im standardowy formularz do wypełnienia przez rodziców lub opiekunów, oraz dane kontaktowe, na jaki ma on być wysłany.
		</li>
	</ul>';
$helptxt['coppaPost'] = 'Miejsce na wpisanie danych kontaktowych jest wymagane, tak by rodzice lub opiekunowie małoletnich mogli przesłać formularz ze zgodą. Musi być wypełnione przynajmniej pole adresowe lub numer faksu.';

$helptxt['allow_hideOnline'] = 'Zaznaczając tę opcje pozwolisz użytkownikom na ukrycie swojej obecności na forum przed innymi użytkownikami (oprócz administratorów). Jeżeli opcja pozostanie wyłączona jedynie osoby moderujące forum będą mogły ukryć swoją obecność. Wyłączenie tej opcji nie zmieni istniejącego statusu użytkownika - powstrzyma ich przed ukrywaniem statusu w przyszłości.';

$helptxt['latest_support'] = 'Ten panel pokazuje niektóre z najczęstszych problemów i pytań dotyczących konfiguracji Twojego serwera. Nie martw się, te informacje nie są nigdzie zapisywane.<br /><br />Jeśli cały czas pojawia komunikat &quot;Retrieving support information...&quot;, Twój komputer prawdopodobnie nie może połączyć się ze stroną internetową.';
$helptxt['latest_packages'] = 'Here you can see some of the most popular and some random packages, with quick and easy installations.<br /><br />If this section doesn\'t show up, your computer probably cannot connect to <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.';
$helptxt['latest_themes'] = 'This area shows a few of the latest and most popular themes from <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.  It may not show up properly if your computer can\'t find <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>, though.';

$helptxt['secret_why_blank'] = 'Dla Twojego bezpieczeństwa, odpowiedź na Twoje pytanie jak i Twoje hasło jest zakodowana w taki sposób, że ElkArte nie będzie w stanie powiedzieć Tobie, ani nikomu innemu gdzie się znajdują.';
$helptxt['moderator_why_missing'] = 'Moderatorzy ustalani są poprzez <a href="%1$s?action=admin;area=manageboards" target="_blank" class="new_win">zarządzanie działami</a>, dla każdego działu osobno.';

$helptxt['permissions'] = 'Zezwolenia pozwalają administratorom decydować o dostępie grup użytkowników do różnych czynności na forum.<br /><br />Można zarządzać zezwoleniami poprzez działy lub grupy użytkowników klikając w \'Modyfikuj.\'';
$helptxt['permissions_board'] = 'Jeśli dział ma ustawienie \'globalne\', oznacza to, że nie posiada żadnych dodatkowych pozwoleń. Ustawienie \'lokalne\' oznacza, że dział posiada swoje odrębne zezwolenia. Pozwala to na ograniczenie lub zwiększenie dostępu do któregoś z działów, bez konieczności zmian w całym forum.';
$helptxt['permissions_quickgroups'] = 'Ta opcja pozwala na szybkie przyznanie domyślnych zezwoleń dla grup. Standardowe to zwyczajne prawa użytkownika. Restrykcyjne to takie jakie ma gość. Moderatorskie to prawa jakie posiadają moderatorzy. Przynależność do obsługi forum daje prawa bardzo bliskie administratorskim.';
$helptxt['permission_enable_deny'] = 'Zabronienie jakiejś czynności jest przydatne, jeśli chcesz zmienić pozwolenia konkretnemu użytkownikowi. Możesz też stworzyć grupę użytkowników z odebranymi prawami i dodać tam tych użytkowników.<br /><br />Zalecamy ostrożne stosowanie. Po zabronieniu użytkownikowi wybranych czynności na forum, nie będzie on miał do nich dostępu, niezależnie od grupy, do której przynależy.';
$helptxt['permission_enable_postgroups'] = 'Zezwolenia dla grup opartych na ilości wiadomości pozwalają na dodanie dodatkowych praw użytkownikom, którzy napisali określoną liczbę wiadomości. Tak by np. nagrodzić wiernych użytkowników forum. Te zezwolenia <em>dodają się</em> do zezwoleń z innych grup, do których należą użytkownicy.';
$helptxt['membergroup_guests'] = 'Grupa Goście to wszyscy użytkownicy, którzy nie są zalogowani.';
$helptxt['membergroup_regular_members'] = 'Użytkownikami bez grupy są wszyscy użytkownicy którzy są zarejestrowani, ale nie mają przydzielonej żadnej grupy.';
$helptxt['membergroup_administrator'] = 'Administrator może z definicji robić wszystko i widzieć wszystkie fora. Nie istnieją ustawienia uprawnień dla administratora.';
$helptxt['membergroup_moderator'] = 'Moderatorzy to specjalna grupa. Pozwolenia i ustawienia dotyczące tej grupy dotyczą się moderatorów, ale <em>tylko w działach, w których moderują</em>. Poza tymi działami, ich prawa nie różnią się od praw zwykłych użytkowników.';
$helptxt['membergroups'] = 'Są dwa rodzaje grup użytkowników: 
	<ul class="normallist">
		<li><strong>Zwykłe grupy:</strong> To takie grupy, do których użytkownicy nie są przydzielani automatycznie. By przypisać użytkownika do grupy, administrator musi wejść do jego profilu i kliknąć na &quot;ustawienia konta&quot;. Z tego miejsca można przydzielić go do dowolnej liczby istniejących grup.</li>
		<li><strong>Grupy oparte na ilości wiadomości:</strong> W odróżnieniu od zwykłych grup, do grup opartych na ilości wiadomości napisanych przez użytkownika, nie można przydzielić użytkowników. Użytkownicy są przydzielani do nich automatycznie po osiągnięciu określonej liczby wiadomości.</li>
	</ul>';

$helptxt['calendar_how_edit'] = 'Możesz edytować te zdarzenia poprzez kliknięcie na czerwonej gwiazdce (*) zaraz obok ich nazw.';

$helptxt['maintenance_backup'] = 'Tutaj możesz zapisać kopię wszystkich wiadomości, ustawień, użytkowników i innych informacji dotyczących Twojego forum w bardzo dużym pliku.<br /><br />Zaleca się, aby dla bezpieczeństwa robić to dość często (np. raz w tygodniu).';
$helptxt['maintenance_rot'] = 'Pozwala <strong>całkowicie</strong> i <strong>nieodwracalnie</strong> usunąć stare tematy. Zaleca się zrobić najpierw kopię na wypadek, gdyby zostało usunięte coś, czego nie chciałeś skasować.<br /><br />Używaj tej opcji z należytą ostrożnością.';
$helptxt['maintenance_members'] = 'Pozwala <strong>całkowicie</strong> i <strong>nieodwracalnie</strong> usunąć konta użytkowników z Twojego forum. Zaleca się zrobić najpierw kopię na wypadek, gdyby zostało usunięte coś, czego nie chciałeś skasować.<br /><br />Używaj tej opcji z należytą ostrożnością.';

$helptxt['avatar_default'] = 'Jeżeli ta opcja jest włączona to domyślny awatar będzie pokazany dla każdego użytkownika, który jeszcze nie posiada swojego awatara. Plik \'default_avatar.png\' znajduje się w folderze images w plikach stylów.';
$helptxt['avatar_server_stored'] = 'Ta opcja umożliwia użytkownikom forum na użycie awatarów znajdujących się już na twoim serwerze. Znajdują się one przeważnie w folderze awatarów.<br />Jako podpowiedź dodamy, że jeśli stworzysz oddzielne katalogi w folderze awatarów, powstaną &quot;kategorie&quot; awatarów.';
$helptxt['avatar_external'] = 'Kiedy ta funkcja jest włączona, użytkownicy mogą podać własny URL do awatara. Minusem tego jest to, że w niektórych przypadkach, mogą oni użyć awatara zbyt dużego, albo przedstawiać obrazki, których sobie nie życzysz na swoim forum.';
$helptxt['avatar_download_external'] = 'Jeżeli włączysz tę opcję, będzie możliwe pobranie awatarów z zewnętrznego adresu URL podanego przez użytkownika. Awatar będzie traktowany jak wgrany na serwer.';
$helptxt['avatar_upload'] = 'Ta opcja jest podobna do &quot;Zezwól użytkownikom na posiadanie awatarów z innego serwera&quot;, ale masz lepszą kontrolę nad awatarami, możesz zmieniać ich rozmiar a twoi użytkownicy nie muszą posiadać własnego serwera, na którym trzymaliby swoje awatary.<br /><br />Jednakże  są pewne minusy tej opcji. Musisz posiadać sporo miejsca na serwerze na awatary swoich forumowiczów.';
$helptxt['avatar_resize_options'] = 'Te opcje dotyczą każdego awataru, który został wysłany na serwer poprzez wysłanie go jako plik lub załadowanie z adresu URL.';
$helptxt['avatar_download_png'] = 'Pliki PNG są większe, ale oferują lepszą jakość. Jeśli ta opcja jest odznaczona, zostaną użyte pliki JPEG - które są zwykle mniejsze, ale zwykle o niższej jakości.';
$helptxt['gravatar'] = 'Gravatar (globally recognized avatar) to usługa, która pozwala na wybranie unikalnych awatarów. Po więcej informacji odwiedź <a href="http://www.gravatar.com" target="_blank"><strong>stronę</strong></a> Gravatar.';
$helptxt['gravatar_rating'] = 'Gravatar pozwala użytkownikom na ocenianie swoich obrazków, przez co mogą zaznaczyć jeżeli obrazek jest stosowny dla jakiejś grupy wiekowej, lub specyficznej społeczności. Domyślnie, tylko obrazki oznaczone literą \'G\' są pokazane dopóki nie zaznaczysz, że chcesz inaczej ocenić obrazek <br /><br /><ul><li><strong>g:</strong> jest odpowiednie dla każdej społeczności.</li><li><strong>pg:</strong> może zawierać niegrzeczne gesty, osoby mające wyzywające ubrania, "lekkie" przekleństwa, lub przemoc.</li><li><strong>r:</strong> może zawierać takie rzeczy jak ostre wulgaryzmy, intensywną przemoc, nagość, lub użycie narkotyków.</li><li><strong>x:</strong> może zawierać ciężkie akty seksualne lub ekstremalnie niepokojącą przemoc.</li></ul>';
$helptxt['custom_avatar_enabled'] = 'Rekomendujemy żeby włączyć tę opcję dla najlepszej wydajności, ponieważ redukuje obciążenie procesora i obciążenie bazy danych kiedy przegląda się stronę z awatarami.<br />Musisz wpisać publiczny katalog w którym zapisuje się awatary i publiczny adres URL dla tego katalogu. Na przykład katalog to /home/yourforumname/public_html/NewAvatarDirectory i adres URL http://www.yourforumname.com/NewAvatarDirectory';
$helptxt['disableHostnameLookup'] = 'Ta opcja wyłącza sprawdzanie nazwy DNS hosta, które na niektórych serwerach jest bardzo wolne. Pamiętaj, że spowoduje to obniżenie efektywności banowania.';

$helptxt['search_weight_commonheader'] = 'Weight factors are used to determine the relevancy of a search result. Change these weight factors to match the things that are specifically important for your forum. For instance, a forum of a news site might want a relatively high value for \'age of last matching message\'. All values are relative in relation to each other and should be positive integers.';
$helptxt['search_weight_frequency'] = 'Ten współczynnik zlicza ilość podobnych wiadomości i rozdziela je poprzez liczbę wiadomości w temacie.';
$helptxt['search_weight_age'] = 'Ten współczynnik ocenia wiek ostatniej wiadomości w temacie. Im bardziej aktualna wiadomość, tym wyższy wynik.';
$helptxt['search_weight_length'] = 'Ten współczynnik bazuje na rozmiarze tematu. Im więcej wiadomości w temacie, tym większy wynik.';
$helptxt['search_weight_subject'] = 'Ten współczynnik sprawdza czy warunki wyszukiwania mogą być znalezione w nazwie tematu.';
$helptxt['search_weight_first_message'] = 'Ten współczynnik sprawdza czy można znaleźć daną frazę w pierwszej wiadomości tematu.';
$helptxt['search_weight_sticky'] = 'Ten współczynnik sprawdza czy temat jest przypięty i zwiększa jego wartość, jeżeli tak jest.';
$helptxt['search_weight_likes'] = 'This factor looks whether a topic has likes and increases the relevancy score based on the number.';
$helptxt['search'] = 'Tutaj możesz dostosować wszystkie ustawienia funkcji wyszukiwania.';
$helptxt['search_why_use_index'] = 'Indeks wyszukiwania może w znaczny sposób przyspieszyć wyszukiwanie na Twoim forum. Szczególnie gdy liczba wiadomości na forum jest bardzo duża, wyszukiwanie bez indeksu może zająć dużo czasu i znacznie obciążać bazę danych. Jeśli ilość wiadomości na Twoim forum jest powyżej 50,000, weź pod uwagę stworzenie indeksu, by zwiększyć wydajność Twojego forum.<br /><br />Weź jednak pod uwagę, że indeks wyszukiwania może zająć sporo miejsca. Indeks pełnotekstowy jest wbudowany w indeks MySQL. Jest stosunkowo niewielki (podobnych rozmiarów co tabela wiadomości), lecz nie wszystkie słowa są indeksowane, a niektóre wyszukiwania i tak okazują się wolne. Indeks wybiórczy jest często większy (zależnie od konfiguracji do 3 razy większy niż tabela wiadomości), lecz jego wydajność jest większa od indeksu pełnotekstowego i indeksuje większość słów.';

$helptxt['see_admin_ip'] = 'Adresy IP są pokazywane administratorom i moderatorom w celu ułatwienia moderacji i umożliwienia śledzenia osób, które robią złe rzeczy na forum. Pamiętaj, że adresy IP nie zawsze mogą być identyfikowane, a wiele osób zmienia swój adres IP co jakiś czas.<br /><br />Użytkownicy widzą swoje własne adresy IP.';
$helptxt['see_member_ip'] = 'Twój adres IP jest pokazywany jedynie Tobie i moderatorom. Pamiętaj że ta informacja nie identyfikuje jednoznacznie ludzi, ponieważ adresy IP zwykle się zmieniają okresowo<br /><br />Nie możesz sprawdzić adresów IP innych członków, a oni twojego.';
$helptxt['whytwoip'] = 'Różnorodne metody są używane do detekcji adresu IP użytkownika. Zwykle metody te, dają ten sam rezultat, czyli jeden adres IP, ale w niektórych sytuacjach, może zostać wykryty więcej niż jeden adres IP. W tym przypadku będą pokazane oba adresy i użyje się ich do sprawdzenia listy zbanowanych adresów. Możesz kliknąć w którykolwiek adres aby go śledzić lub zbanować, jeśli to konieczne.';

$helptxt['ban_cannot_post'] = 'Ban \'Nie może wysyłać wiadomości\' włącza forum w tryb tylko-do-odczytu dla banowanego użytkownika. Użytkownik nie może tworzyć nowych tematów, odpowiadać na istniejące, wysyłać prywatnych wiadomości oraz oddawać głosów w ankietach. Zbanowany użytkownik może nadal odczytywać prywatne wiadomości oraz tematy.<br /><br />Wiadomość ostrzegawcza jest wyświetlana użytkownikowi jeśli został zbanowany w ten sposób.';

$helptxt['posts_and_topics'] = '
	<ul class="normallist">
		<li>
			<strong>Ustawienia wiadomości</strong><br />
			Tu możesz zmienić ustawienia związane z pisaniem wiadomości i sposobem ich wyświetlania, a także włączyć sprawdzanie ortografii.
		</li><li>
			<strong>Bulletin Board Code</strong><br />
			Tu włączysz możliwość formatowania wiadomości, oraz możesz wybrać które z kodów mają być dostępne dla użytkowników.
		</li><li>
			<strong>Słowa cenzurowane</strong> By utrzymać słownictwo forum pod kontrolą, możesz ustawić które słowa zostaną wymienione na ich \'poprawne\' odpowiedniki.
		</li><li>
			<strong>Ustawienia tematów</strong>
			Tu możesz zmieniać ustawienia dotyczące tematów: ilość na stronę, ilość potrzebna by oznaczyć temat jako gorący, opcje przyklejonych tematów itp.
		</li>
	</ul>';
$helptxt['allow_no_censored'] = 'Jeżeli zaznaczone, to globalne ustawienie pozwala użytkownikom wyłączyć cenzurę słów w ich profilu pod zakładką Opcje wyglądu. Ta opcja na wyłączenie cenzurę słów jest jednak ograniczana przez ich ustawienia w profilu.';
$helptxt['spider_mode'] = 'Ustawia poziom logów.<br />
Standardowe - Zapisuje minimalną aktywność botów
Umiarkowany - Dostarcza bardziej dokładne statystyki
Agresywne - Tak jak &quot;Umiarkowany&quot;, ale zapisuje dane które zawierają każdą odwiedzoną stronę.';

$helptxt['spider_group'] = 'Ustawiając uprawnienia według grupy, spowodujesz, że kiedy gość zostanie rozpoznany jako robot, jego uprawnienia zmienią się ze standardowych gościa, na uprawnienia grupy, którą tu ustawisz. Możesz użyć tej opcji do ograniczenia dostępu silnikom wyszukiwarek. Przykładowo: Stwórz grupę o nazwie &quot;Roboty&quot; i ustaw ją tutaj. Możesz teraz zabrać tej grupie możliwość oglądania profili użytkowników, co jednocześnie uniemożliwi robotom indeksowanie profili użytkowników Twojego forum. <br />Uwaga: Detekcja robotów nie jest idealna i może być symulowana przez użytkowników, dlatego nie ma gwarancji, że ograniczenia będą zastosowane tylko do silników wyszukiwarek, które dodałeś.';
$helptxt['show_spider_online'] = 'Te ustawienia pozwolą Ci wybrać, czy roboty powinny być wymienione na liście zalogowanych użytkowników w indeksie działów i stronie &quot;Kto jest na forum&quot;. Dostępne opcje to:
	<ul class="normallist">
		<li>
			<strong>Wcale</strong><br />
			Roboty będą po prostu wyświetlane jako goście dla wszystkich użytkowników.
		</li><li>
			<strong>Pokaż ilość robotów</strong><br />
			Indeks działu wyświetli liczbę robotów aktualnie odwiedzających forum.
		</li><li>
			<strong>Pokaż Nazwy Robotów</strong><br />
			Każda nazwa robota będzie wyświetlana, więc użytkownicy mogą zobaczyć ile robotów aktualnie odwiedza forum - efekt odnosi się do Indeksu działu jak i strony Kto jest online.
		</li><li>
			<strong>Pokaż Nazwy Robotów - Tylko dla Administratora</strong><br />
			Jak wyżej z wyjątkiem tego, że tylko Administratorzy mogą zobaczyć status robotów - dla pozostałych użytkowników roboty ukazują się jako goście.
		</li>
	</ul>';

$helptxt['birthday_email'] = 'Wybierz schemat mailowych życzeń urodzinowych. Podgląd będzie widoczny w polach Tytuł Maila i w Treść Maila.<br /><strong>Zauważ:</strong> Ustawienie tej opcji nie aktywuje automatycznie mailów urodzinowych. Aby aktywować maile urodzinowe użyj <a href="%1$s?action=admin;area=scheduledtasks;%3$s=%2$s" target="_blank" class="new_win">Menadżera Zadań</a> i aktywuj zadanie rozsyłania maili urodzinowych.';
$helptxt['pm_bcc'] = 'Kiedy wysyłasz Prywatną Wiadomość, możesz wybrać odbiorców jako UDW czyli &quot;Ukryte Do Wiadomości&quot;. Odbiorcy oznaczeni UDW, nie będą widoczni dla pozostałych adresatów wiadomości.';

$helptxt['move_topics_maintenance'] = 'Ta opcja pozwala na przeniesienie wszystkich wiadomości z wybranego działu do innego.';
$helptxt['maintain_reattribute_posts'] = 'Możesz użyć tej funkcji, jeśli chcesz przypisać wiadomości napisane przez gości do zarejestrowanego użytkownika. Jest to przydatne np. w sytuacji, gdy użytkownik usunął swoje konto, później zmienił zdanie i chce, aby jego stare wiadomości, były skojarzone z nowym kontem użytkownika.';
$helptxt['chmod_flags'] = 'Możesz ręcznie ustawić zezwolenia plikom, które zaznaczyłeś. Aby to zrobić, wpisz CHMOD jako wartość numeryczną. Pamiętaj - te zmiany nie odniosą skutku w systemach operacyjnych Microsoft Windows.';

$helptxt['postmod'] = 'Ta sekcja pozwala członkom zespołu moderatorskiego (muszą mieć odpowiednie zezwolenia) akceptować wiadomości i tematy zanim zostaną one pokazane.';

$helptxt['field_show_enclosed'] = 'Encloses the user input between some text or HTML code.  This will allow you to add more instant message providers, images or an embed, etc. For example:<br /><br />
		&lt;a href="http://website.com/{INPUT}"&gt;&lt;img src="{DEFAULT_IMAGES_URL}/icon.png" alt="{INPUT}" /&gt;&lt;/a&gt;<br /><br />
		You can use the following variables:<br />
		<ul class="normallist">
			<li>{INPUT} - The input specified by the user.</li>
			<li>{KEY} - The key specified for a certain value of select box or radio buttons in the admin panel. Usually to use in case of localization or use in CSS of Javascript elements (e.g. as class name).</li>
			<li>{SCRIPTURL} - Web address of forum.</li>
			<li>{IMAGES_URL} - URI of the images directory of the user\'s current theme.</li>
			<li>{DEFAULT_IMAGES_URL} - URI of the images directory of the default theme.</li>
		</ul>';

$helptxt['custom_mask'] = 'Maska wprowadzania jest ważna dla bezpieczeństwa forum. Sprawdzanie wprowadzanych przez użytkownika danych pozwala upewnić się, że dane te nie są wykorzystywane w nieprzewidziany sposób. Poniżej podane jest kilka przykładowych wyrażeń regularnych oraz wskazówek.<br /><br />
	<div class="smalltext custom_mask">
		&quot;~[A-Za-z]+~&quot; - dopasuj wszystkie litery WIELKIE i małe.<br />
		&quot;~[0-9]+~&quot; - dopasuj tylko cyfry.<br />
		&quot;~[A-Za-z0-9]{7}~&quot; - dopasuj litery WIELKIE i małe oraz cyfry siedem razy.<br />
		&quot;~[^0-9]?~&quot; - nie pozwól na dopasowanie cyfr.<br />
		&quot;~^([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$~&quot; - pozwól tylko na 3 lub 6 znakowy kod hex.<br />
	</div><br /><br />
	Dodatkowo można zdefiniować meta-znaki ?+*^$ oraz {xx}.
	<div class="smalltext custom_mask">
		? - brak lub jedno dopasowanie w poprzednim wyrażeniu.<br />
		+ - jedno lub więcej dopasowań w poprzednim wyrażeniu.<br />
		* - brak lub więcej w poprzednim wyrażeniu.<br />
		{xx} - dokładna cyfra poprzedniego wyrażenia.<br />
		{xx,} - dokładna liczba lub więcej w poprzednim wyrażeniu.<br />
		{,xx} - dokładna liczba lub mniej w poprzednim wyrażeniu.<br />
		{xx,yy} - dokładne dopasowanie pomiędzy dwoma liczbami z poprzedniego wyrazenia.<br />
		^ - początek łańcucha.<br />
		$ - koniec łańcucha.<br />
		\ - unik.<br />
	</div><br /><br />
	Więcej informacji oraz zaawansowane opcje znajdziesz w sieci.';

$helptxt['badbehavior_reverse_proxy_addresses'] = 'Niektóre konfiguracje serwerów mogą uniemożliwić Bad Behavior ustalenie pochodzenia zdalnego żądania. W tym przypadku powinieneś dodać wszystkie wewnętrzne adresy IP twojego serwera reverse proxy/ładowania zbalansowanego. Zazwyczaj można to pominąć, ale jeśli posiadasz konfigurację, w której niektóre żądania mogą obejść reverse proxy lub ładowania zbalansowane i połączyć się z serwerem bezpośrednio należy skorzystać z tej opcji. Powinno się skorzystać z tej opcji gdy przychodzące żądania przechodzą przez dwa lub więcej serwerów reverse proxy przed dotarciem do strony.<br /><br />Podaj adresy IP lub bloki adresów CIDR rozdzielone przez | (1.2.3.4|5.4.3.2/27)';
$helptxt['badbehavior_reverse_proxy_header'] = 'Podczas korzystania z reverse proxy Bad Behavior sprawdza ten nagłówek HTTP w celu ustalenia właściwego źródła adresu IP dla każdego żądania. Serwer reverse proxy lub ładowania balansowanego musi dodać nagłówek zawierający zdalny adres IP z którego zostało zapoczątkowane połączenie. Zazwyczaj jest to robione domyślnie, sprawdź ustawienia reverse proxy lub ładowania balansowanego w celu upewnienia się, że nagłówek jest wysyłany.<br /><br />Jeśli używasz usługi CloudFlare musisz zmienić tą opcję na CF-Connecting-IP.';
$helptxt['badbehavior_reverse_proxy'] = 'Po włączeniu tej opcji Bad Behavior będzie zakładał, że przyjmuje połączenie z reverse proxy po otrzymaniu specyficznego nagłówka HTTP.';
$helptxt['badbehavior_httpbl_maxage'] = 'Jest to ilość dni która minęła od ostatniego zaobserwowania podejrzanej aktywności z tego adresu IP przez Project Honey Pot. Bad Behavior zablokuje żądania z maksymalnym wiekiem równym lub mniejszym niż podano w tej opcji.';
$helptxt['badbehavior_httpbl_threat'] = 'Jest to ocena adresu IP, bazująca na aktywności zaobserwowanej na Project Honey Pot. Bad Behavior zablokuje żądania z oceną równą lub wyższą niż podana w opcji. Więcej informacji na temat tego parametru można znaleźć na stronie <a href="http://www.projecthoneypot.org/threat_info.php" target="_blank">Project Honey Pot</a>.';
$helptxt['badbehavior_httpbl_key'] = 'Bad Behavior może wykorzystać do monitorowania dane z usługi <a href="http://www.projecthoneypot.org/faq.php#g" target="_blank">http:BL</a> dostarczanej przez <a href="http://www.projecthoneypot.org/" target="_blank">Project Honey Pot</a>.<br /><br />Jest to opcjonalne, ale jeśli chcesz z tej funkcji korzystać należy <a href="http://www.projecthoneypot.org/httpbl_configure.php" target="_blank">zarejestrować się w usłudze</a> i uzyskać klucz API. Aby wyłączyć http:BL, usuń klucz API z ustawień.';
$helptxt['badbehavior_verbose'] = 'Włączenie rozszerzonych logów spowoduje zapisanie wszystkich żądań HTTP. Gdy tryb rozszerzony jest wyłączony tylko zablokowane oraz podejrzane żądania zostają zapisane.<br /><br />Tryb rozszerzony jest domyślnie wyłączony. Używanie trybu rozszerzonego nie jest zalecane, ponieważ może znacząco spowolnić działanie strony, istnieje to w celu wychwycenia danych od "żywych" spamerów, którzy nie są blokowani.';
$helptxt['badbehavior_logging'] = 'Włącza zachowywanie logów Bad Behavior. Domyślnie włączone, nie jest zalecane wyłączenie logowania, ponieważ może to spowodować zwiększenie ilości spamu na stronie.';
$helptxt['badbehavior_strict'] = 'Bad Behavior działa w dwóch trybach: normalnym oraz dokładnym.<br />Dokładny tryb sprawdza (stare) oprogramowanie, które było źródłem spamu, ale może zdarzyć się sytuacja, że zostanie także zablokowany prawdziwy użytkownik.';
$helptxt['badbehavior_offsite_forms'] = 'Bad Behavior zazwyczaj nie pozwala na otrzymywanie danych, które zostały wysłane z formularza znajdującego się na innej stronie. Uniemożliwia to spamerom na używanie wersji strony zapisanej w pamięci cache Google do wysyłania spamu. Niektóre aplikacje wymagają, aby strona mogła otrzymywać dane z zewnętrznych formularzy, na przykład OpenID, dlatego jeśli używasz takiej funkcji włącz tą opcję.';
$helptxt['badbehavior_postcount_wl'] = 'Pozwala to na wyłączenie sprawdzania przez Bad Behavior użytkowników posiadających określoną liczbę wiadomości.<br />-1 nie będzie sprawdzało wszystkich zalogowanych użytkowników, włączając tych bez wiadomości na koncie<br />0 spowoduje włączenie sprawdzanie wszystkich użytkowników, bez względu na liczbę wiadomości<br />Jakakolwiek liczba większa od 0 oznacza liczbę wiadomości poniżej której użytkownicy są sprawdzani.';
$helptxt['badbehavior_ip_wl'] = 'Zakresy adresów IP w formacie CIDR. Aby usunąć adres pozostaw pole puste i zapisz';
$helptxt['badbehavior_useragent_wl'] = 'Agent użytkownika musi być dokładnie dopasowany.';
$helptxt['badbehavior_url_wl'] = 'Adresy są dopasowywane od pierwszego / po nazwie serwera do, ale nie włączając, znaku ? (jeśli występuje). Adres dodawany do białej listy jest adresem na TWOJEJ stronie. Częściowe dopasowanie adresu jest dozwolone, więc wpisy na białej liście mogą być tak rozbudowane jak to jest tylko możliwe, ale nie muszą być bardziej rozbudowane niż jest to wymagane.<br />Na przykład, /przykład byłoby dopasowane do /przykład.php oraz /przykład/adres';

$helptxt['filter_to'] = 'Zamień znaleziony tekst na ten wybrany, pozostaw puste żeby zamienić znaleziony tekst na nic (tzn. usunąć go)';
$helptxt['filter_from'] = 'Wpisz tekst który chcesz znaleźć/zamienić. Jeśli jako typ ustawiono wyrażenie regularne musi to być poprawne wyrażenie regularne. W przeciwnym razie wyszukany i zamieniony zostanie zwykły tekst.';
$helptxt['filter_type'] = 'Standardowe znajdzie dokładny tekst i zamieni go na tekst znajdujący się w polu Zamień na. Wyrażenie regularne jest opcjonalne i musi być podane w poprawnym formacie regex.';
$helptxt['pbe_post_enabled'] = 'Włącz to, żeby pozwolić użytkownikom odpowiadać na powiadomienia email i wysyłać je jako odpowiedzi w tematach. Użytkownicy nadal muszą mieć uprawnienia, które zezwalają na wysyłanie wiadomości.';
$helptxt['pbe_pm_enabled'] = 'Włącz to, żeby użytkownicy mogli odpowiadać na emaile do powiadomień prywatnych wiadomości i wysyłać je jako odpowiedzi w tematach. Użytkownicy nadal muszą mieć uprawnienia, które zezwalają na wysyłanie wiadomości.';
$helptxt['maillist_group_mode'] = 'Jeżeli włączone, to wychodzące emaile z wiadomościami/tematami przyjdą z nazwą użytkownika, inaczej email przyjdzie z nazwą forum. Jest to po prostu koperta, która jedynie wpływa na "Od: nazwa" czyli to co się wyświetla przy odbieraniu wiadomości ze skrzynki pocztowej. Adres email jest niezmieniony.';
$helptxt['maillist_newtopic_change'] = 'Ta opcja pozwoli użytkownikom na zmianę tytułu powiadomienia email i wyśle wiadomość jako nowy temat. Nowy temat będzie założony w tym samym dziale, w jakim została wysłana odpowiedź.';
$helptxt['maillist_sitename_address'] = 'Musi to być adres lub skrzynka IMAP który/a ma być przetwarzany przez emailpost.php';
$helptxt['maillist_help_short'] = 'Ta funkcja pozwala użytkownikom na odpowiadanie na powiadomienia email i wysyłanie ich jako wiadomości na forum. Proszę odwiedzić Wiki, żeby zobaczyć dokładny opis tej funkcji.';

$helptxt['frame_security'] = 'Nagłówek X-Frame-Options może być użyty do zezwolenia lub zablokowania przeglądarce możliwości renderowania strony w ramce. Można używać tego jako dodatkowego zabezpieczenia przed atakami typu clickjacking, upewniając się, że zawartość strony nie jest załadowana w innych stronach.
	<br />
	Więcej informacji na ten temat można znaleźć w sieci.';

$helptxt['attachment_inline_title'] = '<b>Add an inline attachment</b><br />
		Example:
		<br /><b>[attach align=left width=400]123[/attach]</b>
		<br />This will show a left-aligned image resized to 400 pixels wide with the post text flowing around it. Except for the attachment tag and the attachment id all other parameters are optional
		<br /><b>[attach]123[/attach]</b>
		<br />This will show the attachment as a thumbnail if available, if no thumbnail is available it will use a full sized image. The image will be in line with the text of your post.
		<br /><br />
		<br /><b>Options:</b>
		<br />where x is the attachment id
		<br />align=left, center, right
		<br />width=### (where # is number in pixels)
		<br />height=### (where # is number in pixels)
		<br />
		<h3>Modes available</h3>
		<p>
			You can choose the inline mode you want for your attachment:
			<ul>
				<li>Thumbnail [attach]x[/attach] : Your image will be shown as a thumbnail</li>
				<li>Text Link [attachurl]x[/attachurl] : Only a link is show with size and view details. By clicking on it, the image is displayed.</li>
			</ul>
		</p><br />
		<p>
			You can choose how to align the inline image:
			<ul>
				<li>align=left : The image is aligned to the left and the text will flow around it</li>
				<li>align=right : The image is aligned to the right and the text will flow around it</li>
				<li>align=center : The image is centered and the text will be below it</li>
			</ul>
		</p><br />
		<p>
			You can choose how wide to show the image:
			<ul>
				<li>width=123 : The image is displayed 123 pixels wide</li>
				<li>If the width specified is larger than the image or larger than the forum allows the largest allowable width will be used</li>
				<li>Can be used to shrink a thumbnail as well [attach width=50]x[/attach] will display a 50px wide thumbnail</li>
			</ul>
		</p><br />
		<p>
			You can choose how tall to show the image:
			<ul>
				<li>height=123 : The image is displayed 123 pixels tall</li>
				<li>If the height specified is bigger than the image or bigger than the forum allows the biggest allowable width will be used</li>
				<li>Can be used to shrink a thumbnail as well [attach height=50]x[/attach] will display a 50px tall thumbnail</li>
			</ul>
		</p>';