<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'Pomoc użytkownika ElkArte';

$txt['manual_welcome'] = 'Witaj na %s, forum działającym na silniku ElkArte!';
$txt['manual_introduction'] = 'ElkArte jest potężnym i darmowym oprogramowaniem forum. Pozwala użytkownikom dyskutować na dane tematy w sposób rozsądny i zorganizowany. Posiada ono więcej interesujących funkcji niż użytkownicy są w stanie wykorzystać. Wiele funkcji ElkArte posiada informacje pomocy, które są dostępne po kliknięciu w ikonę znaku zapytania znajdującą się obok opcji lub w odnośniki znajdujące się na tej stronie. Linki te przekierują ciebie do dokumentacji na oficjalnej stronie ElkArte.';
$txt['manual_docs_and_credits'] = 'Aby uzyskać więcej informacji jak używać ElkArte odwiedź <a href="%1$s" target="_blank" class="new_win">dokumentację</a>, a także zajrzyj na stronę <a href="%2$s">podziękowań</a> aby dowiedzieć się kto brał udział w tworzeniu ElkArte.';

$txt['manual_section_registering_title'] = 'Rejestracja';
$txt['manual_section_logging_in_title'] = 'Logowanie';
$txt['manual_section_profile_title'] = 'Profil';
$txt['manual_section_search_title'] = 'Szukaj';
$txt['manual_section_posting_title'] = 'Tworzenie wiadomości';
$txt['manual_section_bbc_title'] = 'Kod Bulletin Board (BBC)';
$txt['manual_section_personal_messages_title'] = 'Prywatne wiadomości';
$txt['manual_section_memberlist_title'] = 'Lista użytkowników';
$txt['manual_section_calendar_title'] = 'Kalendarz';
$txt['manual_section_features_title'] = 'Cechy';

$txt['manual_section_registering_desc'] = 'Do pełnego dostępu do forum wiele z nich wymaga zarejestrowania się.';
$txt['manual_section_logging_in_desc'] = 'Gdy użytkownik jest zarejestrowany, musi zalogować się aby mógł mieć dostęp do swojego profilu.';
$txt['manual_section_profile_desc'] = 'Każdy użytkownik posiada własny profil na forum.';
$txt['manual_section_search_desc'] = 'Przeszukiwanie forum jest bardzo pomocnym narzędziem, które pozwala znaleźć informacje na forum zawarte w tematach oraz wiadomościach.';
$txt['manual_section_posting_desc'] = 'Istotą forum jest to, że każdy użytkownik ma możliwość wysyłania wiadomości za pomocą których reprezentuje się całej społeczności.';
$txt['manual_section_bbc_desc'] = 'Do wysyłanych wiadomości można dodawać kody BBC.';
$txt['manual_section_personal_messages_desc'] = 'Użytkownicy mogą także komunikować się między sobą za pomocą prywatnych wiadomości.';
$txt['manual_section_memberlist_desc'] = 'Lista użytkowników pokazuje wszystkich użytkowników danego forum.';
$txt['manual_section_calendar_desc'] = 'Użytkownicy mogą śledzić wydarzenia, święta, a także urodziny za pomocą kalendarza.';
$txt['manual_section_features_desc'] = 'Najpopularniejsze funkcje ElkArte.';