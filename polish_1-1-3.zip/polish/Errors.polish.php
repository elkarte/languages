<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Przepraszamy, ale nie możesz przejść do tej sekcji. Nie możemy nawet potwierdzić jej istnienia. Możesz odwiedzić stronę główną i z niej spróbować dostać się w to miejsce.';
$txt['not_guests'] = 'Przepraszamy, ta akcja nie jest dostępna dla gości.';

$txt['mods_only'] = 'Tylko moderatorzy mogą usuwać wiadomości, wykasuj swoją wiadomość używając funkcji edycji.';
$txt['no_name'] = 'Nie wpisałeś nazwy użytkownika. Musisz ją podać w celu kontynuowania.';
$txt['no_email'] = 'Nie wpisałeś adresu email. Musisz go podać w celu kontynuowania.';
$txt['topic_locked'] = 'Ten temat jest zamknięty, nie masz uprawnień na wysyłanie lub modyfikację wiadomości...';
$txt['no_password'] = 'Pole hasła jest puste';
$txt['passwords_dont_match'] = 'Hasła nie są identyczne.';
$txt['register_to_use'] = 'Zanim będziesz mógł korzystać z tej opcji musisz się zarejestrować.';
$txt['username_reserved'] = 'Nazwa użytkownika, której próbowałeś zawiera zarezerwowaną nazwę \'%1$s\'. Spróbuj jeszcze raz.';
$txt['numbers_one_to_nine'] = 'W to pole można wpisywać tylko cyfry od 0 do 9';
$txt['not_a_user'] = 'Profil użytkownika, który próbujesz przeglądać nie istnieje.';
$txt['not_a_topic'] = 'Temat nie istnieje w tym dziale.';
$txt['not_approved_topic'] = 'Ten temat nie został jeszcze zatwierdzony.';
$txt['email_in_use'] = 'Podany adres email (%1$s) jest używany przez innego zarejestrowanego użytkownika. Jeśli to pomyłka, przejdź do strony z logowaniem i postaraj się przywrócić hasło na ten adres email.';

$txt['didnt_select_vote'] = 'Nie wybrałeś żadnej z opcji ankiety.';
$txt['poll_error'] = 'Ankieta nie istnieje, została zamknięta lub próbowałeś zagłosować dwa razy.';
$txt['locked_by_admin'] = 'Ten temat został zamknięty przez administratora. Nie możesz go otworzyć.';
$txt['not_enough_posts_karma'] = 'Nie masz wystarczającej ilości wiadomości by móc modyfikować reputację - musisz mieć co najmniej %1$d.';
$txt['cant_change_own_karma'] = 'Nie masz uprawnień do modyfikacji własnej reputacji.';
$txt['karma_wait_time'] = 'Przepraszamy, nie możesz zmienić reputacji, poczekaj %1$s %2$s.';
$txt['feature_disabled'] = 'Przepraszamy, ta funkcja jest wyłączona.';
$txt['feature_no_exists'] = 'Przepraszamy, funkcja nie istnieje.';
$txt['couldnt_connect'] = 'Nie można połączyć się z serwerem lub nie można znaleźć pliku';
$txt['no_board'] = 'Wybrany dział nie istnieje';
$txt['no_message'] = 'Wiadomość nie jest dostępna.';
$txt['no_topic_id'] = 'Podano niewłaściwy ID tematu.';
$txt['split_first_post'] = 'Nie możesz rozdzielić tematu na pierwszej wiadomości.';
$txt['topic_one_post'] = 'Ten temat zawiera tylko jedną wiadomość i nie może być rozdzielony.';
$txt['no_posts_selected'] = 'Nie wybrano żadnej wiadomości';
$txt['selected_all_posts'] = 'Nie można podzielić. Wybrano wszystkie wiadomości.';
$txt['cant_find_messages'] = 'Nie można znaleźć wiadomości';
$txt['cant_find_user_email'] = 'Nie można znaleźć adresu email użytkownika.';
$txt['cant_insert_topic'] = 'Nie można zamieścić tematu';
$txt['session_timeout'] = 'Twoja sesja dobiegła końca podczas pisania. Spróbuj ponownie wysłać wiadomość.';
$txt['session_timeout_file_upload'] = 'Podczas wysyłania pliku wygasła twoja sesja. Spróbuj ponownie.';
$txt['no_files_uploaded'] = 'Nie ma plików do wysłania.';
$txt['session_verify_fail'] = 'Weryfikacja sesji nie powiodła się. Wyloguj i zaloguj się ponownie, a potem spróbuj jeszcze raz.';
$txt['verify_url_fail'] = 'Nie można zweryfikować URL odnoszącego: %1$s. Powróć i spróbuj jeszcze raz.';
$txt['token_verify_fail'] = 'Weryfikacja tokena nie powiodła się. Spróbuj ponownie.';
$txt['guest_vote_disabled'] = 'Goście nie mogą głosować w tej ankiecie.';

$txt['cannot_access_mod_center'] = 'Nie posiadasz do dostępu do centrum moderacji.';
$txt['cannot_admin_forum'] = 'Nie masz zezwolenia na administrowanie tym forum.';
$txt['cannot_announce_topic'] = 'Nie masz zezwolenia na ogłaszanie tematów w tym dziele.';
$txt['cannot_approve_posts'] = 'Nie masz zezwoleń na zatwierdzanie.';
$txt['cannot_post_unapproved_attachments'] = 'Nie masz zezwoleń na dodawanie niezatwierdzonych załączników.';
$txt['cannot_post_unapproved_topics'] = 'Nie masz zezwoleń na dodawanie niezatwierdzonych tematów.';
$txt['cannot_post_unapproved_replies_own'] = 'Nie masz zezwoleń na dodawanie niezatwierdzonych odpowiedzi na własne tematy.';
$txt['cannot_post_unapproved_replies_any'] = 'Nie masz zezwoleń na dodawanie niezatwierdzonych odpowiedzi na tematy innych użytkowników.';
$txt['cannot_calendar_edit_any'] = 'Nie możesz edytować wydarzeń w kalendarzu.';
$txt['cannot_calendar_edit_own'] = 'Nie masz zezwoleń potrzebnych, aby dodawać własne wydarzenia w kalendarzu.';
$txt['cannot_calendar_post'] = 'Dodawanie wydarzeń jest zabronione.';
$txt['cannot_calendar_view'] = 'Nie masz uprawnień na przeglądanie kalendarza.';
$txt['cannot_remove_any'] = 'Nie masz uprawnień do usuwania dowolnego tematu. Upewnij się, że temat nie został właśnie przeniesiony do innego działu.';
$txt['cannot_remove_own'] = 'Nie możesz usuwać własnych tematów w tym dziale. Upewnij się, że temat nie został właśnie przeniesiony do innego działu.';
$txt['cannot_edit_news'] = 'Nie posiadasz uprawnień do edytowania aktualności.';
$txt['cannot_pm_read'] = 'Przepraszamy, nie możesz czytać własnych prywatnych wiadomości.';
$txt['cannot_pm_send'] = 'Nie możesz wysyłać prywatnych wiadomości.';
$txt['cannot_karma_edit'] = 'Nie posiadasz uprawnień do zmiany reputacji innych użytkowników.';
$txt['cannot_like_posts'] = 'Nie możesz polubić wiadomości w tym dziale.';
$txt['cannot_lock_any'] = 'Nie posiadasz uprawnień do zamykania wszystkich tematów.';
$txt['cannot_lock_own'] = 'Nie posiadasz uprawnień do zamykania swoich tematów.';
$txt['cannot_make_sticky'] = 'Nie posiadasz uprawnień do przyklejenia tego tematu.';
$txt['cannot_manage_attachments'] = 'Nie posiadasz uprawnień do zarządzania załącznikami i awatarami.';
$txt['cannot_manage_bans'] = 'Nie posiadasz uprawnień do zmiany listy banów.';
$txt['cannot_manage_boards'] = 'Nie posiadasz uprawnień do zarządzania działami i kategoriami.';
$txt['cannot_manage_membergroups'] = 'Nie posiadasz uprawnień do modyfikacji lub przyznawania grup użytkownikom.';
$txt['cannot_manage_permissions'] = 'Nie posiadasz uprawnień do zarządzania uprawnieniami.';
$txt['cannot_manage_smileys'] = 'Nie posiadasz uprawnień do zarządzania emotikonami oraz ikonami w wiadomościach.';
$txt['cannot_mark_any_notify'] = 'Nie posiadasz uprawnień do otrzymywania powiadomień z tego tematu.';
$txt['cannot_mark_notify'] = 'Nie posiadasz uprawnień do otrzymywania powiadomień z tego działu.';
$txt['cannot_merge_any'] = 'Nie posiadasz uprawnień do scalania tematów w jednym z zaznaczonych działów.';
$txt['cannot_moderate_forum'] = 'Nie posiadasz uprawnień do moderowania tego forum.';
$txt['cannot_moderate_board'] = 'Nie posiadasz uprawnień do moderowania tego działu.';
$txt['cannot_modify_any'] = 'Nie możesz edytować każdej wiadomości.';
$txt['cannot_modify_own'] = 'Przepraszamy, ale nie możesz edytować swoich wiadomości.';
$txt['cannot_modify_replies'] = 'Pomimo tego, że ta wiadomość jest odpowiedzią na twój temat, nie możesz jej modyfikować.';
$txt['cannot_move_own'] = 'Nie posiadasz uprawnień do przenoszenia własnych tematów w tym dziale.';
$txt['cannot_move_any'] = 'Nie posiadasz uprawnień do przenoszenia tematów w tym dziale.';
$txt['cannot_poll_add_own'] = 'Nie posiadasz uprawnień na dodawanie ankiet do swoich tematów w tym dziale.';
$txt['cannot_poll_add_any'] = 'Nie posiadasz uprawnień na dodanie ankiety do tego tematu.';
$txt['cannot_poll_edit_own'] = 'Pomimo tego, że ta ankieta należy do twojego tematu, nie możesz jej edytować.';
$txt['cannot_poll_edit_any'] = 'Nie masz zezwolenia na modyfikowanie ankiet w tym dziale.';
$txt['cannot_poll_lock_own'] = 'Nie masz zezwolenia na zamykanie swoich ankiet w tym dziale.';
$txt['cannot_poll_lock_any'] = 'Nie masz zezwolenia na zamykanie dowolnej ankiety.';
$txt['cannot_poll_post'] = 'Nie masz zezwolenia na wysyłanie ankiet w tym dziale.';
$txt['cannot_poll_remove_own'] = 'Nie masz zezwolenia na usunięcie ankiety ze swojego tematu.';
$txt['cannot_poll_remove_any'] = 'Nie masz zezwolenia na usuwanie każdej ankiety w tym dziale.';
$txt['cannot_poll_view'] = 'Nie masz zezwolenia na przeglądanie ankiet w tym dziale.';
$txt['cannot_poll_vote'] = 'Nie masz zezwolenia na głosowanie w tym dziale.';
$txt['cannot_post_attachment'] = 'Nie masz zezwolenia na wysyłanie załączników.';
$txt['cannot_post_new'] = 'Nie masz zezwolenia na wysyłanie tematów w tym dziale.';
$txt['cannot_post_new_board'] = 'Przepraszamy, nie możesz wysyłać nowych tematów w dziale %1$s.';
$txt['cannot_post_reply_any'] = 'Nie masz zezwolenia na odpowiadanie w tym dziale.';
$txt['cannot_post_reply_own'] = 'Nie masz zezwolenia na odpowiadanie nawet na swoje tematy w tym dziale.';
$txt['cannot_profile_remove_own'] = 'Nie posiadasz uprawnień do usunięcia swojego konta.';
$txt['cannot_profile_remove_any'] = 'Nie posiadasz uprawnień do usuwania kont użytkowników.';
$txt['cannot_profile_extra_any'] = 'Nie posiadasz uprawnień do modyfikowania ustawień profilu.';
$txt['cannot_profile_identity_any'] = 'Nie masz zezwolenia na modyfikowanie ustawień konta.';
$txt['cannot_profile_title_any'] = 'Nie możesz edytować własnych tytułów innych użytkowników.';
$txt['cannot_profile_extra_own'] = 'Nie posiadasz uprawnień do modyfikowania włąsnego profilu.';
$txt['cannot_profile_identity_own'] = 'Nie możesz teraz zmienić swojej tożsamości.';
$txt['cannot_profile_title_own'] = 'Nie posiadasz uprawnień do zmiany własnego tytułu.';
$txt['cannot_profile_set_avatar'] = 'Nie masz zezwoleń do zmiany awatara.';
$txt['cannot_profile_view_own'] = 'Przepraszamy, ale nie możesz przeglądać swojego profilu.';
$txt['cannot_profile_view_any'] = 'Przepraszamy, ale nie możesz przeglądać każdego profilu.';
$txt['cannot_delete_own'] = 'Przepraszamy, nie możesz usuwać swoich wiadomości w tym dziale.';
$txt['cannot_delete_replies'] = 'Przepraszamy, ale nie możesz usuwać tych wiadomości, pomimo że są odpowiedzią na twój temat.';
$txt['cannot_delete_any'] = 'Przepraszamy, nie możesz usuwać wiadomości w tym dziale.';
$txt['cannot_report_any'] = 'Nie posiadasz uprawnień do zgłaszania wiadomości w tym dziale.';
$txt['cannot_search_posts'] = 'Nie posiadasz uprawnień do wyszukiwania wiadomości.';
$txt['cannot_send_mail'] = 'Nie posiadasz uprawnień do wysyłania wiadomości email.';
$txt['cannot_issue_warning'] = 'Przepraszamy, nie masz zezwoleń na wysyłanie ostrzeżeń do użytkowników.';
$txt['cannot_send_topic'] = 'Administrator wyłączył możliwość wysyłania nowych tematów w tym dziale.';
$txt['cannot_send_email_to_members'] = 'Przepraszamy, administrator wyłączył możliwość wysyłania wiadomości email w tym dziale.';
$txt['cannot_split_any'] = 'Nie posiadasz uprawnień do dzielenia dowolnych tematów w tym dziale.';
$txt['cannot_view_attachments'] = 'Nie posiadasz uprawnień do pobierania i oglądania załączników w tym dziale.';
$txt['cannot_view_mlist'] = 'Nie posiadasz uprawnień do przeglądania listy użytkowników.';
$txt['cannot_view_stats'] = 'Nie masz zezwolenia na przeglądanie statystyk forum.';
$txt['cannot_who_view'] = 'Nie masz zezwolenia na przeglądanie listy zalogowanych użytkowników.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = 'Nie można odnaleźć tego stylu.';
$txt['theme_dir_wrong'] = 'Katalog domyślnego stylu nie jest prawidłowy. Popraw to klikając tutaj.';
$txt['registration_disabled'] = 'Przepraszamy, rejestracja jest obecnie wyłączona.';
$txt['registration_agreement_missing'] = 'Plik umowy rejestracyjnej - agreement.txt - nie istnieje lub jest pusty. Rejestracja będzie wyłączona dopóki błąd nie zostanie poprawiony.';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Ten użytkownik nie ustawił sobie sekretnego pytania.';
$txt['poll_range_error'] = 'Ankieta musi być otwarta przez więcej niż 0 dni.';
$txt['delFirstPost'] = 'Nie możesz usunąć pierwszej wiadomości w temacie.<p>Jeśli chcesz usunąć temat kliknij na &quot;Usuń temat&quot; albo poproś o to moderatora lub administratora.</p>';
$txt['login_cookie_error'] = 'Nie możesz się zalogować. Sprawdź ustawienia plików cookie.';
$txt['incorrect_answer'] = 'Udzielono nieprawidłowej odpowiedzi. Przejdź jeden poziom do tyłu, aby spróbować jeszcze raz lub dwa poziomy, aby użyć domyślnej metody uzyskiwania hasła.';
$txt['no_mods'] = 'Nie znaleziono żadnych moderatorów!';
$txt['parent_not_found'] = 'Struktura działów uszkodzona: nie można znaleźć działu nadrzędnego';
$txt['modify_post_time_passed'] = 'Nie możesz edytować tej wiadomość, ponieważ upłynął czas w którym można było to zrobić.';

$txt['calendar_off'] = 'Obecnie nie masz dostępu do kalendarza, ponieważ jest on wyłączony.';
$txt['calendar_export_off'] = 'Nie możesz eksportować wydarzeń z kalendarza, ponieważ funkcja ta jest obecnie wyłączona.';
$txt['invalid_month'] = 'Nieprawidłowy numer miesiąca.';
$txt['invalid_year'] = 'Nieprawidłowy numer roku.';
$txt['invalid_day'] = 'Nieprawidłowa wartość dnia.';
$txt['event_month_missing'] = 'Brakuje miesiąca wydarzenia.';
$txt['event_year_missing'] = 'Brakuje roku wydarzenia.';
$txt['event_day_missing'] = 'Brakuje dnia wydarzenia.';
$txt['event_title_missing'] = 'Brakuje nazwy wydarzenia.';
$txt['invalid_date'] = 'Nieprawidłowa data.';
$txt['no_event_title'] = 'Nie wprowadzono nazwy wydarzenia.';
$txt['missing_board_id'] = 'Brakuje ID działu.';
$txt['missing_topic_id'] = 'Brakuje ID tematu.';
$txt['topic_doesnt_exist'] = 'Temat nie istnieje.';
$txt['not_your_topic'] = 'Nie jesteś autorem tego tematu.';
$txt['board_doesnt_exist'] = 'Dział nie istnieje.';
$txt['no_span'] = 'Funkcja kilkudniowych wydarzeń jest wyłączona.';
$txt['invalid_days_numb'] = 'Nieprawidłowa ilość dni trwania wydarzenia.';

$txt['moveto_noboards'] = 'Nie ma działu do którego można przenieść ten temat!';
$txt['topic_already_moved'] = 'Temat %1$s został przeniesiony do działu %2$s, sprawdź jego nową lokalizację przed kolejnym przeniesieniem.';

$txt['already_activated'] = 'Twoje konto zostało już aktywowane.';
$txt['still_awaiting_approval'] = 'Twoje konto nadal oczekuje na zatwierdzenie przez administratora.';

$txt['invalid_email'] = 'Nieprawidłowy adres email lub zakres adresów.<br />Przykład prawidłowego adresu: zly.uzytkownik@zla.pl.<br />Przykład prawidłowego zakresu adresów: *@*.zla.pl';
$txt['invalid_expiration_date'] = 'Nieprawidłowa data wygaśnięcia';
$txt['invalid_hostname'] = 'Nieprawidłowa nazwa hosta lub zakres.<br />Przykład prawidłowej nazwy: proxy4.zlyhost.com<br />Przykład prawidłowego zakresu nazw: *.zlyhost.com';
$txt['invalid_ip'] = 'Nieprawidłowy adres IP lub zakres adresów.<br />Przykład prawidłowego adresu: 127.0.0.1<br />Przykład prawidłowego zakresu: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Nieprawidłowy adres IP lub zakres adresów.<br />Przykład prawidłowego adresu IP: 127.0.0.1<br />Przykład prawidłowego zakresu IP: 127.0.0.*';
$txt['invalid_username'] = 'Nie znaleziono nazwy użytkownika';
$txt['no_user_selected'] = 'Nie znaleziono użytkownika';
$txt['no_ban_admin'] = 'Nie możesz zbanować administratora. Jeśli jednak chcesz to zrobić musisz najpierw usunąć go z grupy administratorów.';
$txt['no_bantype_selected'] = 'Nie wybrano typu bana';
$txt['ban_not_found'] = 'Nie znaleziono bana';
$txt['ban_unknown_restriction_type'] = 'Nieznany typ ograniczenia';
$txt['ban_name_empty'] = 'Nazwa bana jest pusta';
$txt['ban_id_empty'] = 'Przepraszamy, nie można odnaleźć ID bana.';
$txt['ban_group_id_empty'] = 'Wybrana grupa nie posiada ID, grupa banów wymaga ID grupy.';
$txt['ban_no_triggers'] = 'Nie zapomniałeś wybrać typu blokady? Musisz wybrać przynajmniej jedną opcję.';
$txt['ban_ban_item_empty'] = 'Nie znaleziono aktywatora bana';
$txt['impossible_insert_new_bangroup'] = 'Podczas dodawania nowego bana wystąpił błąd';

$txt['like_heading_error'] = 'Błąd w systemie polubień';
$txt['like_wait_time'] = 'Przepraszamy, nie możesz powtórzyć akcji Polubienia bez odczekania %1$s %2$s.';
$txt['like_unlike_error'] = 'Wystąpił błąd podczas używania funkcji Lubię to w wiadomości';
$txt['cant_like_yourself'] = 'Nie możesz polubić własnych wiadomości...';

$txt['ban_name_exists'] = 'Podana nazwa bana (%1$s) już istnieje, wybierz inną.';
$txt['ban_trigger_already_exists'] = 'Ten ban (%1$s) już istnieje w %2$s. ';
$txt['attach_check_nag'] = 'Nie można kontynuować z powodu niekompletnych informacji (%1$s).';

$txt['recycle_no_valid_board'] = 'Nie wybrano działu do zachowywania usuniętych tematów';
$txt['post_already_deleted'] = 'Temat lub wiadomość znajduje się już w koszu.<br />Jeśli chcesz całkowicie usunąć wiadomość <a href="%1$s">kliknij tutaj</a>.';

$txt['login_threshold_fail'] = 'Wyczerpałeś ilość prób zalogowania. Spróbuj jeszcze raz później.';
$txt['login_threshold_brute_fail'] = 'Przepraszamy, wyczerpałeś ilość prób zalogowania. Poczekaj 30 sekund i spróbuj ponownie.';

$txt['who_off'] = 'Niestety w chwili obecnej lista zalogowanych użytkowników jest wyłączona.';

$txt['merge_create_topic_failed'] = 'Nie udało się utworzyć nowego tematu.';
$txt['merge_need_more_topics'] = 'Aby połączyć tematy musisz wybrać przynajmniej dwa tematy. Spróbuj ponownie.';

$txt['post_WaitTime_broken'] = 'Ostatnia odpowiedź z twojego adresu IP była wysłana mniej niż %1$d sekund temu. Spróbuj ponownie później.';
$txt['register_WaitTime_broken'] = 'Zarejestrowałeś się już %1$d sekund temu!';
$txt['login_WaitTime_broken'] = 'Musisz poczekać około %1$d sekund aby ponownie się zalogować.';
$txt['pm_WaitTime_broken'] = 'Ostatnia prywatna wiadomość z twojego adresu IP była wysłana mniej niż %1$d sekund temu. Spróbuj ponownie później.';
$txt['reporttm_WaitTime_broken'] = 'Ostatni temat z twojego adresu IP wysłany był mniej niż %1$d sekund temu. Spróbuj ponownie później.';
$txt['sendtopic_WaitTime_broken'] = 'Ostatni temat z twojego adresu IP wysłany był mniej niż %1$d sekund temu. Spróbuj ponownie później.';
$txt['sendmail_WaitTime_broken'] = 'Ostatni email z twojego adresu IP wysłany był mniej niż%1$d sekund temu. Spróbuj ponownie później.';
$txt['search_WaitTime_broken'] = 'Od twojego ostatniego wyszukiwania upłynęło mniej niż %1$d sekund. Spróbuj ponownie później.';
$txt['remind_WaitTime_broken'] = 'Ostatnie przypomnienie wysłano mniej niż %1$d sekund temu. Spróbuj ponownie później.';
$txt['contact_WaitTime_broken'] = 'Ostatni raz użyłeś formularza kontaktowego mniej niż %1$d sekund temu. Spróbuj ponownie później.';

$txt['topic_gone'] = 'Próbowaliśmy znaleźć temat lub dział którego szukasz, ale nie ma po nim śladu. Został on usunięty lub nie masz do niego dostępu.';
$txt['theme_edit_missing'] = 'Próbowaliśmy znaleźć plik, który chcesz edytować, ale nie można go nigdzie znaleźć.';

$txt['no_dump_database'] = 'Przepraszamy, nie możesz zrobić kopii bazy danych. Mogą ją wykonać jedynie administratorzy.';
$txt['pm_not_yours'] = 'Prywatna wiadomość, którą próbujesz cytować nie jest twoja lub nie istnieje, wróć i spróbuj jeszcze raz.';
$txt['mangled_post'] = 'Uszkodzony formularz danych - wróć i spróbuj jeszcze raz.';
$txt['too_many_groups'] = 'Przepraszamy, wybrano za dużo grup, usuń niektóre.';
$txt['post_upload_error'] = 'Brakuje treści wiadomości. Błąd mógł powstać w wyniku próby wysłania za dużego pliku. Skontaktuj się z administratorem jeśli błąd będzie się powtarzał.';
$txt['quoted_post_deleted'] = 'Wiadomość, którą próbujesz zacytować, nie istnieje, została skasowana lub nie masz uprawnień do czytania jej.';
$txt['pm_too_many_per_hour'] = 'Przekroczyłeś limit %1$d prywatnych wiadomości na godzinę.';
$txt['labels_too_many'] = 'Przepraszamy, %1$s wiadomość posiada maksymalną liczbę etykiet!';

$txt['register_only_once'] = 'Przepraszamy, ale nie można rejestrować kilku kont w tym samym czasie z tego samego komputera.';
$txt['admin_setting_coppa_require_contact'] = 'Musisz wpisać kod pocztowy lub nr faxu jeśli wymagana jest zgoda rodzica/opiekuna.';

$txt['error_long_name'] = 'Nazwa użytkownika jest za długa.';
$txt['error_no_name'] = 'Nie podano nazwy użytkownika.';
$txt['error_bad_name'] = 'Podana przez Ciebie nazwa użytkownika nie może zostać użyta, ponieważ zawiera nazwę zarezerwowaną.';
$txt['error_no_email'] = 'Nie podano adresu email.';
$txt['error_bad_email'] = 'Podano nieprawidłowy adres email.';
$txt['error_email'] = 'adres email';
$txt['error_message'] = 'wiadomość';
$txt['error_no_event'] = 'Nie podano nazwy wydarzenia.';
$txt['error_no_subject'] = 'Nie wpisano tytułu.';
$txt['error_no_question'] = 'Nie wpisano pytania do ankiety.';
$txt['error_no_message'] = 'Nie wpisano treści wiadomości.';
$txt['error_long_message'] = 'Wiadomość przekracza dozwoloną długość (%s znaków).';
$txt['error_no_comment'] = 'Pole komentarza nie zostało uzupełnione.';
$txt['error_post_too_long'] = 'Twoja wiadomość jest za długa. Wpisz maksymalnie 255 znaków.';
$txt['error_session_timeout'] = 'Twoja sesja dobiegła końca podczas pisania. Spróbuj ponownie wysłać wiadomość.';
$txt['error_no_to'] = 'Nie podano odbiorców.';
$txt['error_bad_to'] = 'Nie znaleziono jednego lub więcej odbiorców.';
$txt['error_bad_bcc'] = 'Nie znaleziono jednego lub więcej odbiorców \'BCC\'.';
$txt['error_form_already_submitted'] = 'Już wysłałeś tą wiadomość! Być może przez przypadek kliknąłeś dwukrotnie lub odświeżyłeś stronę.';
$txt['error_poll_few'] = 'Musisz dać przynajmniej dwie możliwości do wyboru!';
$txt['error_poll_many'] = 'Nie możesz mieć więcej niż 256 opcji.';
$txt['error_need_qr_verification'] = 'Uzupełnij poniższą sekcję weryfikacji, aby wysłać wiadomość.';
$txt['error_wrong_verification_code'] = 'Wpisane litery nie pasują do liter pokazanych na obrazku.';
$txt['error_wrong_verification_answer'] = 'Odpowiedziałeś błędnie na pytanie weryfikacyjne.';
$txt['error_need_verification_code'] = 'Wprowadź niżej kod weryfikacyjny aby kontynuować.';
$txt['error_bad_file'] = 'Przepraszamy, ale wybrany plik nie mógł zostać otworzony: %1$s';
$txt['error_bad_line'] = 'Podana linia nie jest poprawna.';
$txt['error_draft_not_saved'] = 'Wystąpił błąd podczas zapisywania szkicu';
$txt['error_name_in_use'] = 'Nazwa %1$s jest już zajęta przez innego użytkownika.';

$txt['smiley_not_found'] = 'Nie znaleziono emotikony.';
$txt['smiley_has_no_code'] = 'Do tej emotikony nie przypisano kodu.';
$txt['smiley_has_no_filename'] = 'Nie podano nazwy pliku emotikony.';
$txt['smiley_not_unique'] = 'Emotikona z tym kodem już istnieje.';
$txt['smiley_set_already_exists'] = 'Pod tym adresem URL już istnieje zestaw emotikon.';
$txt['smiley_set_not_found'] = 'Nie znaleziono zestawu emotikon';
$txt['smiley_set_dir_not_found'] = 'Katalog zestawu emotikon %1$s jest błędny lub nie ma do niego dostępu';
$txt['smiley_set_path_already_used'] = 'Adres URL tego zestawu emotikon jest już zajęty przez inny zestaw.';
$txt['smiley_set_unable_to_import'] = 'Nie można importować zestawu emotikon. Katalog jest niewłaściwy lub nie można uzyskać do niego dostępu.';

$txt['smileys_upload_error'] = 'Nie udało się wysłać pliku.';
$txt['smileys_upload_error_blank'] = 'Każdy zestaw emotikon musi mieć grafikę.';
$txt['smileys_upload_error_name'] = 'Wszystkie emotikony muszą mieć tą samą nazwę pliku.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Niewłaściwy typ pliku.';

$txt['search_invalid_weights'] = 'Wagi wyszukiwania nie są ustawione poprawnie. Przynajmniej jedna waga musi być wyższa niż zero. Skontaktuj się z administratorem.';

$txt['package_no_file'] = 'Nie można znaleźć pliku pakietu!';
$txt['packageget_unable'] = 'Nie można połączyć się z serwerem. Spróbuj używając <a href="%1$s" target="_blank" class="new_win">tego adresu</a>.';
$txt['not_valid_server'] = 'Przepraszamy, pakiety mogą być pobierane jedynie z wcześniej autoryzowanych serwerów.';
$txt['package_cant_uninstall'] = 'Ten pakiet nie był nigdy zainstalowany lub był już odinstalowany - nie możesz go teraz odinstalować.';
$txt['package_cant_download'] = 'Nie możesz pobierać lub instalować nowych pakietów, ponieważ katalog &quot;packages&quot; lub jeden ze znajdujących się w nim plików nie jest zapisywalny.';
$txt['package_upload_error_nofile'] = 'Nie zaznaczyłeś pakietu do wysłania.';
$txt['package_upload_error_failed'] = 'Nie można wysłać pakietu, sprawdź zezwolenie zapisu w katalogu.';
$txt['package_upload_error_exists'] = 'Plik, który wysyłasz istnieje już na serwerze. Usuń go i spróbuj ponownie.';
$txt['package_upload_already_exists'] = 'Pakiet, który próbujesz wysłać już istnieje na serwerze pod nazwą: %1$s';
$txt['package_upload_error_supports'] = 'Menadżer pakietów aktualnie pozawala tylko na takie typy plików: %1$s.';
$txt['package_upload_error_broken'] = 'Nie udało się wysłać pakietu z powodu następującego błędu:<br />&quot;%1$s&quot;';

$txt['package_get_error_not_found'] = 'Pakiet, który próbujesz zainstalować nie może zostać odnaleziony. Spróbuj ręcznie wysłać pakiet do katalogu &quot;packages&quot;.';
$txt['package_get_error_missing_xml'] = 'Próbujesz zainstalować pakiet nie posiadający pliku package-info.xml, który musi być w głównym katalogu pakietu.';
$txt['package_get_error_is_zero'] = 'Pomimo tego, że pakiet został pobrany na serwer wydaje się, że jest pusty. Sprawdź czy katalogi &quot;packages&quot; oraz w nim znajdujący się katalog &quot;temp&quot; mają możliwość zapisu. Jeśli problem będzie się powtarzał powinieneś spróbować wypakować pakiet na komputerze, wysłać pliki do katalogu znajdującego się w &quot;packages&quot; i spróbować ponownie. Na przykład: jeśli pakiet nazywa się shout.tar.gz powinieneś:<br />1) Pobrać pakiet na swój komputer i wypakować pliki.<br />2) Utworzyć nowy katalog w katalogu &quot;packages&quot; używając klienta FTP, w tym przypadku możesz anzwać go "shout".<br />3) Wyślij wypakowane pliki do tego katalogu.<br />4) Wróć do menadżera pakietów. Pakiet powinien zostać automatycznie wykryty.';
$txt['package_get_error_packageinfo_corrupt'] = 'Nie można odnaleźć poprawnych informacji w pliku package-info.xml dołączonym do pakietu. Paczka jest uszkodzona lub zawiera błąd.';
$txt['package_get_error_is_theme'] = 'Nie możesz tutaj instalować stylów, do wysłania stylu użyj strony <a href="{MANAGETHEMEURL}">Zarządzanie stylami</a>';

$txt['no_membergroup_selected'] = 'Nie wybrano grupy użytkowników';
$txt['membergroup_does_not_exist'] = 'Grupa użytkowników nie istnieje lub jest nieprawidłowa.';

$txt['at_least_one_admin'] = 'Musi istnieć przynajmniej jeden administrator forum!';

$txt['error_functionality_not_windows'] = 'Przepraszamy, ta opcja obecnie nie jest dostępna dla serwerów pracujących na systemie Windows.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Załącznik nie został znaleziony';

$txt['error_no_boards_selected'] = 'Nie wybrano poprawnych działów.';
$txt['error_invalid_search_string'] = 'Nie zapomniałeś podać czego szukasz?';
$txt['error_invalid_search_string_blacklist'] = 'Próbowano wyszukać zbyt proste słowa. Spróbuj ponownie z innym zapytaniem.';
$txt['error_search_string_small_words'] = 'Każde słowo musi składać się przynajmniej z dwóch znaków.';
$txt['error_query_not_specific_enough'] = 'Twoje wyszukiwanie nie zwróciło żadnych wyników.';
$txt['error_no_messages_in_time_frame'] = 'Nie znaleziono wiadomości w wybranym przedziale czasowym.';
$txt['error_no_labels_selected'] = 'Nie wybrano etykiet.';
$txt['error_no_search_daemon'] = 'Brak dostępu do narzędzia wyszukiwania';

$txt['profile_errors_occurred'] = 'Podczas aktualizacji profilu wystąpiły następujące błędy';
$txt['profile_error_bad_offset'] = 'Niepoprawna strefa czasowa';
$txt['profile_error_no_name'] = 'Pole z nazwą użytkownika jest puste';
$txt['profile_error_digits_only'] = 'Pole \'liczba wiadomości\' może zawierać tylko cyfry.';
$txt['profile_error_name_taken'] = 'Wybrana nazwa użytkownika/wyświetlana jest już zajęta';
$txt['profile_error_name_too_long'] = 'Wybrana nazwa użytkownika jest za długa. Nie powinna przekraczać 60 znaków';
$txt['profile_error_no_email'] = 'Pole email jest puste';
$txt['profile_error_bad_email'] = 'Nie wprowadziłeś poprawnego adresu email';
$txt['profile_error_email_taken'] = 'Inny użytkownik jest już zarejestrowany z tym adresem email';
$txt['profile_error_no_password'] = 'Hasło nie zostało wpisane';
$txt['profile_error_bad_new_password'] = 'Podane hasła nie są zgodne';
$txt['profile_error_bad_password'] = 'Podane hasło nie jest prawidłowe';
$txt['profile_error_bad_avatar'] = 'Wybrany awatar jest za duży lub nie jest to awatar';
$txt['profile_error_password_short'] = 'Twoje hasło musi mieć przynajmniej %1$s znaków.';
$txt['profile_error_password_restricted_words'] = 'Hasło nie może zawierać nazwy użytkownika, adresu email lub innych popularnych słów.';
$txt['profile_error_password_chars'] = 'Twoje hasło musi zawierać mieszankę dużych i małych liter oraz cyfr.';
$txt['profile_error_already_requested_group'] = 'Już wysłałeś prośbę o dodanie do tej grupy!';
$txt['profile_error_openid_in_use'] = 'Podany URL weryfikacyjny OpenID jest używany przez innego użytkownika.';
$txt['profile_error_signature_not_yet_saved'] = 'Podpis nie został zapisany.';
$txt['profile_error_personal_text_too_long'] = 'Tekst osobisty jest za długi.';
$txt['profile_error_user_title_too_long'] = 'Własny tytuł jest za długi.';

$txt['mysql_error_space'] = '- sprawdź miejsce zapisu bazy danych lub skontaktuj się z administratorem serwera.';

$txt['icon_not_found'] = 'Plik ikony nie został znaleziona w domyślnym stylu - upewnij się że obrazek został wysłany i spróbuj ponownie.';
$txt['icon_after_itself'] = 'Ikona nie może być umieszczona za sobą.';
$txt['icon_name_too_long'] = 'Nazwa pliku ikony nie może mieć więcej niż 16 znaków';

$txt['name_censored'] = 'Przepraszamy, nazwa której próbujesz użyć, %1$s, zawiera słowa które zostały ocenzurowane. Użyj innej nazwy.';

$txt['poll_already_exists'] = 'Temat może mieć tylko jedną powiązaną z nim ankietę.';
$txt['poll_not_found'] = 'Nie ma ankiet powiązanych z tym tematem!';

$txt['error_while_adding_poll'] = 'Następujący błąd lub błędy wystąpiły przy dodawaniu ankiety';
$txt['error_while_editing_poll'] = 'Następujący błąd lub błędy wystąpiły przy edycji tej ankiety';

$txt['loadavg_search_disabled'] = 'Z powodu dużego obciążenia serwera, funkcja wyszukiwania jest tymczasowo wyłączona. Spróbuj ponownie później.';
$txt['loadavg_generic_disabled'] = 'Przepraszamy, z powodu dużego obciążenia serwera ta opcja jest obecnie niedostępna.';
$txt['loadavg_allunread_disabled'] = 'Serwer znajduje się pod dużym obciążeniem. Nie można wyświetlić wszystkich nieprzeczytanych tematów.';
$txt['loadavg_unreadreplies_disabled'] = 'W tej chwili serwer jest przeciążony. Spróbuj ponownie później.';
$txt['loadavg_show_posts_disabled'] = 'Spróbuj jeszcze raz później. Z powodu dużego obciążenia serwera wiadomości tego użytkownika nie są w tej chwili dostępne.';
$txt['loadavg_unread_disabled'] = 'Serwer znajduje się pod dużym obciążeniem. Nie można wyświetlić listy nieprzeczytanych tematów.';
$txt['loadavg_userstats_disabled'] = 'Serwer znajduje się pod dużym obciążeniem. Nie można wyświetlić statystyk użytkownika. Spróbuj ponownie później.';

$txt['cannot_edit_permissions_inherited'] = 'Nie możesz edytować dziedziczonych uprawnień, musisz edytować grupę  z której uprawnienia są dziedziczone lub grupę użytkownika.';

$txt['mc_no_modreport_specified'] = 'Musisz sprecyzować który raport chcesz wyświetlić.';
$txt['mc_no_modreport_found'] = 'Podany raport nie istnieje lub jest poza twoim zasięgiem';

$txt['st_cannot_retrieve_file'] = 'Nie można odzyskać pliku %1$s.';
$txt['admin_file_not_found'] = 'Nie można załadować wybranego pliku: %1$s.';

$txt['themes_none_selectable'] = 'Przynajmniej jeden styl musi być wybieralny.';
$txt['themes_default_selectable'] = 'Domyślny styl forum musi być stylem wybieralnym.';
$txt['ignoreboards_disallowed'] = 'Opcja ignorowania działów nie jest włączona.';

$txt['mboards_delete_error'] = 'Nie wybrano kategorii.';
$txt['mboards_delete_board_error'] = 'Nie wybrano działu.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'Nie możesz ustawić działu nadrzędnego jako podrzędny.';
$txt['mboards_board_own_child_error'] = 'Nie możesz ustawić działu nadrzędnego jako podrzędny.';

$txt['smileys_upload_error_notwritable'] = 'Podana ścieżka emotikon nie jest zapisywalna: %1$s';
$txt['smileys_upload_error_types'] = 'Emotikona może mieć następujące rozszerzenia: %1$s.';

$txt['change_email_success'] = 'Twój adres email został zmieniony, nowy email aktywacyjny został wysłany na podany adres.';
$txt['resend_email_success'] = 'Nowy email aktywacyjny został wysłany pomyślnie.';

$txt['custom_option_need_name'] = 'Opcja profilu musi mieć nazwę.';
$txt['custom_option_not_unique'] = 'Nazwa pola musi być unikalna.';
$txt['custom_option_regex_error'] = 'Podane wyrażenie regularne nie jest poprawne';

$txt['warning_no_reason'] = 'Musisz wpisać powód zamiany poziomu ostrzeżenia użytkownika';
$txt['warning_notify_blank'] = 'Zaznaczyłeś powiadamianie użytkownika lecz nie wypełniłeś pola tytułu lub wiadomości';

$txt['cannot_connect_doc_site'] = 'Nie można połączyć się ze stroną dokumentacji. Sprawdź czy konfiguracja twojego serwera pozwala na przychodzące połączenia i spróbuj ponownie.';

$txt['movetopic_no_reason'] = 'Musisz wprowadzić powód przeniesienia tematu albo odznaczyć opcję \'Wyślij temat przekierowujący\'.';
$txt['movetopic_no_board'] = 'Musisz wybrać dział do którego chcesz przenieść temat.';

$txt['splittopic_no_reason'] = 'Musisz wpisać powód podzielenia tematu lub odznacz opcję \'Wyślij temat przekierowujący\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Podany identyfikator nie zwrócił poprawnych informacji.';
$txt['openid_return_no_mode'] = 'Dostawca identyfikacji nie odpowiada z opcją Open ID.';
$txt['openid_not_resolved'] = 'Dostawca identyfikacji nie zatwierdził twojej prośby.';
$txt['openid_no_assoc'] = 'Nie znaleziono żądanego powiązania z dostawcą identyfikacji.';
$txt['openid_sig_invalid'] = 'Sygnatura dostawcy identyfikacji jest nieprawidłowa.';
$txt['openid_load_data'] = 'Nie można załadować danych z twojego żądania o logowanie. Spróbuj ponownie.';
$txt['openid_not_verified'] = 'Podany identyfikator OpenID nie został jeszcze zweryfikowany. W celu weryfikacji zaloguj się.';

$txt['error_custom_field_too_long'] = 'Pole &quot;%1$s&quot; nie może być większe niż %2$d znaków.';
$txt['error_custom_field_invalid_email'] = 'Pole &quot;%1$s&quot; musi zawierać prawidłowy adres email.';
$txt['error_custom_field_not_number'] = 'Pole &quot;%1$s&quot; musi być numeryczne.';
$txt['error_custom_field_inproper_format'] = 'Pole &quot;%1$s&quot; posiada błędny format.';
$txt['error_custom_field_empty'] = 'Pole &quot;%1$s&quot; nie może być puste.';

$txt['email_no_template'] = 'Szablon wiadomości email &quot;%1$s&quot; nie może zostać znaleziony.';

$txt['search_api_missing'] = 'API wyszukiwarki nie zostało znalezione. Skontaktuj się z administratorem.';
$txt['search_api_not_compatible'] = 'Wybrane API wyszukiwarki nie jest aktualne - przekierowywanie do standardowego wyszukiwania. Sprawdź plik %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Nie możesz przywrócić pierwszej wiadomości w temacie.';
$txt['restored_disabled'] = 'Przywracanie tematów zostało wyłączone.';
$txt['restore_not_found'] = 'Wymienione wiadomości nie mogły zostać przywrócone; oryginalny temat mógł zostać usunięty: %1$s Musisz przenieść je ręcznie.';

$txt['error_invalid_dir'] = 'Podany katalog nie jest prawidłowy.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'Żądana akcja nie jest zdefiniowana.';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'Nie znaleziono pozycji które można uporządkować';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
