<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Wykonaj';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Lista plików w pakiecie';
$txt['files_archive'] = 'Pliki w archiwum';
$txt['package_browse'] = 'Przeglądaj';
$txt['add_server'] = 'Dodaj serwer';
$txt['server_name'] = 'Nazwa serwera';
$txt['serverurl'] = 'URL';
$txt['no_packages'] = 'Nie ma jeszcze pakietów.';
$txt['download'] = 'Pobierz';
$txt['download_success'] = 'Pakiet został pobrany';
$txt['package_downloaded_successfully'] = 'Pakiet został pobrany';
$txt['package_manager'] = 'Pakiety';
$txt['install_mod'] = 'Zainstaluj';
$txt['uninstall_mod'] = 'Odinstaluj';
$txt['no_adds_installed'] = 'Nie ma zainstalowanych dodatków';
$txt['uninstall'] = 'Odinstaluj';
$txt['delete_list'] = 'Usuń listę dodatków';
$txt['package_delete_list_warning'] = 'Na pewno chcesz usunąć listę zainstalowanych dodatków?';

$txt['package_manager_desc'] = 'Tutaj możesz pobrać i instalować dodatki na forum.';
$txt['installed_packages_desc'] = 'Użyj poniższego interfejsu aby przeglądać obecnie zainstalowane pakiety i usuwać te, których już nie potrzebujesz.';
$txt['download_packages_desc'] = 'Tutaj możesz dodawać lub usuwać serwery pakietów, szukać pakietów lub pobierać nowe pakiety z serwerów.';
$txt['package_servers_desc'] = 'Tutaj możesz zarządzać serwerami pakietów oraz pobierać dodatki do swojego forum.';
$txt['upload_packages_desc'] = 'Tutaj możesz wysłać nowy pakiet ze swojego komputera bezpośrednio na forum.';

$txt['upload_new_package'] = 'Wyślij nowy pakiet';
$txt['view_and_remove'] = 'Pokaż i usuń zainstalowane pakiety';
$txt['modification_package'] = 'Pakiety dodatków';
$txt['avatar_package'] = 'Pakiety awatarów';
$txt['language_package'] = 'Paczki językowe';
$txt['unknown_package'] = 'Inne pakiety';
$txt['smiley_package'] = 'Pakiety emotikon';
$txt['use_avatars'] = 'Użyj awatarów';
$txt['add_languages'] = 'Dodaj język';
$txt['list_files'] = 'Lista plików';
$txt['package_type'] = 'Typ pakietu';
$txt['extracting'] = 'Wypakowywanie';
$txt['avatars_extracted'] = 'Awatary zostały zainstalowane, będą one dostępne do wyboru dla użytkowników.';
$txt['language_extracted'] = 'Pakiet językowy został zainstalowany, teraz możesz włączyć go w ustawieniach języka.';

$txt['mod_name'] = 'Nazwa dodatku';
$txt['mod_version'] = 'Wersja';
$txt['mod_author'] = 'Autor';
$txt['author_website'] = 'Strona domowa autora';
$txt['package_no_description'] = 'Nie podano opisu';
$txt['package_description'] = 'Opis';
$txt['file_location'] = 'Pobierz';
$txt['bug_location'] = 'Zgłoszone błędy';
$txt['support_location'] = 'Wsparcie';
$txt['mod_hooks'] = 'Brak edycji plików źródłowych';
$txt['mod_date'] = 'Ostatnia aktualizacja';
$txt['mod_section_count'] = 'Przeglądaj (%1d) modyfikacji w tej kategorii';

// Package Server strings
$txt['package_current'] = '(%s <em>Posiadasz najnowszą wersję %s</em>)';
$txt['package_update'] = '(%s <em>Aktualizacja %s jest dostępna</em>)';
$txt['package_installed'] = 'zainstalowano';
$txt['package_downloaded'] = 'pobrano';

$txt['package_installed_key'] = 'Zainstalowane dodatki:';
$txt['package_installed_current'] = 'obecna wersja';
$txt['package_installed_old'] = 'starsza wersja';
$txt['package_installed_warning1'] = 'Ten pakiet jest już zainstalowany i nie znaleziono aktualizacji.';
$txt['package_installed_warning2'] = 'Aby uniknąć problemów powinieneś najpierw odinstalować starą wersję, możesz też poprosić autora o zrobienie aktualizacji z twojej do najnowszej wersji.';
$txt['package_installed_warning3'] = 'Pamiętaj o regularnym robieniu kopii zapasowych twoich plików i bazy danych przed instalacją modyfikacji, szczególnie w wersji beta.';
$txt['package_installed_extract'] = 'Wypakowywanie pakietu';
$txt['package_installed_done'] = 'Pakiet został zainstalowany. Powinieneś teraz móc używać funkcji, które zostały dodane, zmienione albo usunięte.';
$txt['package_installed_redirecting'] = 'Przekierowywanie...';
$txt['package_installed_redirect_go_now'] = 'Przekieruj teraz';
$txt['package_installed_redirect_cancel'] = 'Wróć do Menadżera pakietów';

$txt['package_upgrade'] = 'Aktualizacja';
$txt['package_uninstall_readme'] = 'Plik informacji odinstalowywania';
$txt['package_install_readme'] = 'Plik informacji instalowania';
$txt['package_install_license'] = 'Licencja';
$txt['package_install_type'] = 'Typ';
$txt['package_install_action'] = 'Akcja';
$txt['package_install_desc'] = 'Opis';
$txt['install_actions'] = 'Czynności instalacji';
$txt['perform_actions'] = 'Zostaną wykonane następujące czynności:';
$txt['corrupt_compatible'] = 'Pakiet, który próbujesz pobrać lub zainstalować jest uszkodzony lub nie jest kompatybilny z używaną wersją ElkArte.';
$txt['package_create'] = 'Stwórz';
$txt['package_move'] = 'Przenieś';
$txt['package_delete'] = 'Usuń';
$txt['package_extract'] = 'Wypakuj';
$txt['package_file'] = 'Plik';
$txt['package_tree'] = 'Katalog';
$txt['execute_modification'] = 'Wykonaj modyfikację';
$txt['execute_code'] = 'Wykonaj kod';
$txt['execute_database_changes'] = 'Wykonaj plik';
$txt['execute_hook_add'] = 'Dodaj hak';
$txt['execute_hook_remove'] = 'Usuń hak';
$txt['execute_hook_action'] = 'Dostosowanie haka %1$s';
$txt['package_requires'] = 'Wymaga modyfikacji';
$txt['package_check_for'] = 'Sprawdź instalację dla:';
$txt['execute_credits_add'] = 'Dodaj podziękowania';
$txt['execute_credits_action'] = 'Podziękowania: %1$s';

$txt['package_install_actions'] = 'Możliwe tryby instalacji dla';
$txt['package_will_fail_title'] = 'Błąd w pakiecie %1$s';
$txt['package_will_fail_warning'] = 'Podczas testowania %1$s pakietu wystąpił co najmniej jeden błąd.<br /><strong>Nie jest zalecane</strong> kontynuowanie procesu %1$s, chyba, że wiesz co robisz oraz posiadasz niedawno utworzone kopie zapasowe.<br /><br />Ten błąd może być spowodowany przez konflikt z inną zainstalowaną modyfikacją, błąd w pakiecie instalacyjnym, brak innej wymaganej modyfikacji lub niekompatybilność pakietu z używaną wersją forum.';
$txt['package_will_fail_unknown_action'] = 'Pakiet próbuje wykonać nieznaną akcję: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Na pewno chcesz kontynuować instalację dodatku, nawet jeśli nie przebiegnie ona prawidłowo?';
$txt['package_will_fail_popup_uninstall'] = 'Na pewno chcesz kontynuować odinstalowywanie dodatku, nawet jeśli nie przebiegnie ono prawidłowo?';
$txt['package_install'] = 'instalacji';
$txt['package_uninstall'] = 'usuwania';
$txt['package_install_now'] = 'Zainstaluj';
$txt['package_uninstall_now'] = 'Odinstaluj';
$txt['package_other_themes'] = 'Zainstaluj w innych stylach';
$txt['package_other_themes_uninstall'] = 'Odinstaluj w innych stylach';
$txt['package_other_themes_desc'] = 'W celu używania tego dodatku na stylu innym niż domyślny menadżer pakietów musi wykonać dodatkowe edycje w tych stylach. Jeśli chcesz zainstalować dodatek w innym stylu zaznacz go poniżej.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Co najmniej jeden błąd wystąpił podczas próby instalacji na tym stylu. Czy na pewno chcesz ponowić próbę instalacji?';

$txt['package_bytes'] = 'bajtów';

$txt['package_action_missing'] = '<strong class="error">Plik nie znaleziony</strong>';
$txt['package_action_error'] = '<strong class="error">Błąd parsowania modyfikacji</strong>';
$txt['package_action_failure'] = '<strong class="error">Wystąpił błąd</strong>';
$txt['package_action_success'] = '<strong>Sukces</strong>';
$txt['package_action_skipping'] = '<strong>Plik pominięty</strong>';

$txt['package_uninstall_actions'] = 'Czynności odinstalowania';
$txt['package_uninstall_done'] = 'Pakiet został pomyślnie odinstalowany.';
$txt['package_uninstall_cannot'] = 'Pakiet nie może zostać odinstalowany, ponieważ nie posiada on deinstalatora.<br /><br />Skontaktuj się z autorem dodatku w celu uzyskania większej ilości informacji.';

$txt['package_install_options'] = 'Opcje instalacji';
$txt['package_install_options_desc'] = 'Tutaj możesz zmienić ustawienia instalacji dodatków, np. dostęp do serwera FTP lub tworzenie kopii zapasowych';
$txt['package_install_options_ftp_why'] = 'Dla poprawnego działania menedżera pakietów oraz ominięcia manualnej zmiany CHMOD na wszystkich plikach, najprostszym sposobem jest wykorzystanie tego menedżera FTP.<br />Możesz tutaj wstawić domyślne wartości dla poszczególnych pól.';
$txt['package_install_options_ftp_server'] = 'Serwer FTP';
$txt['package_install_options_ftp_port'] = 'Port';
$txt['package_install_options_ftp_user'] = 'Nazwa użytkownika';
$txt['package_install_options_make_backups'] = 'Utwórz kopie zapasowe podmienionych plików z tyldą (~) na końcu nazwy.';
$txt['package_install_options_make_full_backups'] = 'Utwórz pełną kopię zapasową ElkArte (z wyłączeniem emotikon, awatarów oraz załączników).';

$txt['package_ftp_necessary'] = 'Wymagane informacje FTP';
$txt['package_ftp_why'] = 'Menadżer pakietów wykrył, że niektóre pliki nie są zapisywalne. Trzeba to zmienić logując się na serwerze FTP i zmienić CHMOD tych plików lub utworzyć te pliki i katalogi. Dane logowania do serwera FTP zostaną tymczasowo przechowane na czas czynności menadżera pakietów. Możesz zrobić to także ręcznie używając swojego klienta FTP - <a href="#" onclick="%1$s">kliknij tutaj aby zobaczyć listę plików</a>.';
$txt['package_ftp_why_file_list'] = 'W celu kontynuowania instalacji następujące pliki muszą być zapisywalne:';
$txt['package_ftp_why_download'] = 'W celu pobrania pakietów katalog w którym są one przechowywane oraz wszystkie znajdujące się w nim pliki muszą być zapisywalne. Obecnie system nie posiada odpowiednich uprawnień na zapisywanie w katalogu pakietów. Menadżer pakietów może spróbować naprawić ten problem po podaniu danych logowania na serwer FTP.';
$txt['package_ftp_server'] = 'Serwer FTP';
$txt['package_ftp_port'] = 'Port';
$txt['package_ftp_username'] = 'Nazwa użytkownika';
$txt['package_ftp_password'] = 'Hasło';
$txt['package_ftp_path'] = 'Lokalna ścieżka do ElkArte';
$txt['package_ftp_test'] = 'Testuj';
$txt['package_ftp_test_connection'] = 'Test połączenia';
$txt['package_ftp_test_success'] = 'Nawiązano połączenie z FTP.';
$txt['package_ftp_test_failed'] = 'Nie można połączyć się z serwerem.';
$txt['package_ftp_bad_server'] = 'Nie można połączyć się z serwerem.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Pakiet, który chcesz usunąć jest obecnie zainstalowany! Jeśli go usuniesz, możesz nie być w stanie go później odinstalować.\\n\\nJesteś pewien?';

$txt['package_examine_file'] = 'Zobacz plik w pakiecie';
$txt['package_file_contents'] = 'Zawartość pliku';

$txt['package_upload_title'] = 'Wyślij pakiet';
$txt['package_upload_select'] = 'Pakiet do wysłania';
$txt['package_upload'] = 'Wyślij';
$txt['package_uploaded_success'] = 'Pakiet wysłany';
$txt['package_uploaded_successfully'] = 'Pakiet został wysłany';

$txt['package_modification_malformed'] = 'Błędny lub niewłaściwy plik dodatku.';
$txt['package_modification_missing'] = 'Plik nie znaleziony.';
$txt['package_no_zlib'] = 'Twoja konfiguracja PHP nie wspiera <strong>zlib</strong>. Bez tego menadżer pakietów nie będzie działał. Skontaktuj się z administratorem serwera w celu uzyskania dalszych informacji.';

$txt['package_cleanperms_title'] = 'Wyczyść uprawnienia';
$txt['package_cleanperms_desc'] = 'Ten ekran umożliwia Ci zresetowanie uprawnień wszystkich plików ElkArte w celu zwiększenia poziomu bezpieczeństwa lub rozwiązania problemów związanych z instalacją nowych pakietów.';
$txt['package_cleanperms_type'] = 'Ustaw wszystkie uprawnienia plików tak, aby';
$txt['package_cleanperms_standard'] = 'standardowe pliki miały możliwość zapisu.';
$txt['package_cleanperms_free'] = 'wszystkie pliki miały możliwość zapisu.';
$txt['package_cleanperms_restrictive'] = 'zapis był możliwy jedynie w wymaganych plikach.';
$txt['package_cleanperms_go'] = 'Zmień uprawnienia plików';

$txt['package_download_by_url'] = 'Pobierz pakiet z adresu';
$txt['package_download_filename'] = 'Nazwa pliku';
$txt['package_download_filename_info'] = 'Opcjonalne. Powinno być stosowane gdy adres URL nie kończy się na nazwie pliku. Na przykład: index.php?mod=5';

$txt['package_db_uninstall'] = 'Usuń wszystkie dane powiązane z tym dodatkiem.';
$txt['package_db_uninstall_details'] = 'Szczegóły';
$txt['package_db_uninstall_actions'] = 'Zaznaczenie tej opcji spowoduje wykonanie następujących czynności';
$txt['package_db_remove_table'] = 'Usuń tabelę &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Usuń kolumnę &quot;%2$s&quot; z &quot;%1$s&quot;';
$txt['package_db_remove_index'] = 'Usuń index &quot;%1$s&quot; z &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Zainstaluj emulując:';
$txt['package_emulate_uninstall'] = 'Odinstaluj emulując:';

// Operations.
$txt['operation_find'] = 'Znajdź';
$txt['operation_replace'] = 'Zamień na';
$txt['operation_after'] = 'Dodaj po';
$txt['operation_before'] = 'Dodaj przed';
$txt['operation_title'] = 'Operacje';
$txt['operation_ignore'] = 'Ignoruj błędy';
$txt['operation_invalid'] = 'Operacja którą wybrałeś jest niepoprawna.';

$txt['package_file_perms_desc'] = 'Możesz użyć tej sekcji do przeglądania statusu CHMOD ważnych folderów i plików w katalogu forum. Zauważ, że poniżej zostały uwzględnione tylko kluczowe foldery i pliki forum, użyj klienta FTP aby nadać uprawnienia innym plikom lub folderom.';
$txt['package_file_perms_name'] = 'Nazwa pliku/katalogu';
$txt['package_file_perms_status'] = 'Obecny status';
$txt['package_file_perms_new_status'] = 'Zmień atrybuty';
$txt['package_file_perms_status_read'] = 'Przeczytany';
$txt['package_file_perms_status_write'] = 'Zapis';
$txt['package_file_perms_status_execute'] = 'Wykonanie';
$txt['package_file_perms_status_custom'] = 'Własne';
$txt['package_file_perms_status_no_change'] = 'Bez zmian';
$txt['package_file_perms_writable'] = 'Zapisywalny';
$txt['package_file_perms_not_writable'] = 'Niezapisywalny';
$txt['package_file_perms_chmod'] = 'CHMOD';
$txt['package_file_perms_more_files'] = 'Więcej plików';

$txt['package_file_perms_change'] = 'Zmień zezwolenia plików';
$txt['package_file_perms_predefined'] = 'Użyj zdefiniowanego zestawu zezwoleń';
$txt['package_file_perms_predefined_note'] = 'Pamiętaj, że dotyczy to tylko predefiniowanych kluczowych katalogów i plików.';
$txt['package_file_perms_apply'] = 'Zastosuj indywidualne ustawienia uprawnień dla zaznaczonych plików.';
$txt['package_file_perms_custom'] = 'Jeśli zaznaczono opcję &quot;Własne&quot; użyj podanej wartości CHMOD';
$txt['package_file_perms_pre_restricted'] = 'Ograniczony - minimalna ilość plików jest zapisywalna';
$txt['package_file_perms_pre_standard'] = 'Standardowy - kluczowe pliki są zapisywalne';
$txt['package_file_perms_pre_free'] = 'Wolny - wszystkie pliki są zapisywalne';
$txt['package_file_perms_ftp_details'] = 'Na większości serwerów, zmiana zezwoleń plików jest możliwa tylko za pomocą konta FTP. Wpisz poniżej dane swojego konta FTP';
$txt['package_file_perms_ftp_retain'] = 'System przechowa hasło tymczasowo, w celu poprawnego działania menadżera pakietów.';
$txt['package_file_perms_go'] = 'Zastosuj zmiany';

$txt['package_file_perms_applying'] = 'Zastosowywanie zmian zmiany';
$txt['package_file_perms_items_done'] = 'Zakończono %1$d z %2$d';
$txt['package_file_perms_skipping_ftp'] = '<strong>Ostrzeżenie:</strong> Nie udało się połączyć z serwerem FTP, próbowanie zmiany uprawnień bez połączenia. To <em>prawdopodobnie</em> się nie uda - sprawdź rezultat po zakończeniu i jeśli będzie to konieczne spróbuj ponownie z poprawnymi danymi serwera FTP.';

$txt['package_file_perms_dirs_done'] = 'Ukończono %1$d z %2$d katalogów';
$txt['package_file_perms_files_done'] = 'Ukończono %1$d z %2$d plików w obecnym katalogu';

$txt['chmod_value_invalid'] = 'Próbowano wprowadzić niepoprawną wartość CHMOD. Prawidłowa wartość powinna znajdować się w przedziale od 0444 do 0777';

$txt['package_restore_permissions'] = 'Przywróć uprawnienia pliku';
$txt['package_restore_permissions_desc'] = 'W celu instalacji wybranych pakietów zostały zmienione następujące uprawnienia plików. Możesz przywrócić plikom oryginalne uprawnienia klikając poniżej na przycisk &quot;Przywróć&quot;.';
$txt['package_restore_permissions_restore'] = 'Przywróć';
$txt['package_restore_permissions_filename'] = 'Nazwa pliku';
$txt['package_restore_permissions_orig_status'] = 'Oryginalny status';
$txt['package_restore_permissions_cur_status'] = 'Obecny status';
$txt['package_restore_permissions_result'] = 'Wynik';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - było %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Pominięty</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Sukces</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Porażka</span> ';
$txt['package_restore_permissions_action_done'] = 'Przywrócono oryginalne uprawnienia plików, poniżej znajduje się więcej informacji. Jeśli nie udało się przywrócić uprawnień odwiedź sekcję <a href="%1$s">Uprawnienia plików</a>.';

$txt['package_file_perms_warning'] = 'Pamiętaj';
$txt['package_file_perms_warning_desc'] = '
	Bądź ostrożny podczas zmiany uprawnień plików w tej sekcji - nieprawidłowe uprawnienia mogą odwrócić negatywnie wpłynąć na działanie forum!<br />
	Niektóre konfiguracje serwerów mogą zablokować forum po wybraniu niepoprawnych uprawnień plików.<br />
	W wybranych katalogach takich jak np. <em>attachments</em> musi być możliwość zapisu.<br />
	Te funkcje dotyczą głównie serwerów nie działających na systemie Windows - zmiana uprawnień plików nie będzie działała na serwerze działającym pod kontrolą systemu Windows.<br />
	Przed kontynuowaniem upewnij się, że posiadasz zainstalowany klient FTP - w przypadku błędu będziesz mógł użyć go do poprawienia uprawnień plików.';

$txt['package_confirm_view_package_content'] = 'Jesteś pewny, że chcesz zobaczyć zawartość paczki z tej lokalizacji:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Wykonaj';
$txt['package_confirm_go_back'] = 'Wróć';

$txt['package_readme_default'] = 'Domyślny';
$txt['package_available_readme_language'] = 'Dostępne języki pliku informacji:';
$txt['package_license_default'] = 'Domyślny';
$txt['package_available_license_language'] = 'Dostępne języki licencji:';