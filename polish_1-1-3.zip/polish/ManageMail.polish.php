<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Na tej stronie możesz skonfigurować opcje maili, a także przeglądać i administrować obecną kolejką maili jeśli opcja ta jest włączona.';
$txt['mail_settings'] = 'Ustawienia wiadomości email';

$txt['mail_type'] = 'Typ emailu';
$txt['mail_type_default'] = '(PHP domyślnie)';
$txt['smtp_host'] = 'Serwer SMTP';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'Port SMTP';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'Użytkownik SMTP';
$txt['smtp_password'] = 'Hasło SMTP';

$txt['mail_queue'] = 'Włącz kolejkę maili';
$txt['mail_period_limit'] = 'Maksymalna ilość wiadomości wysłanych na minutę';
$txt['mail_period_limit_desc'] = '(Aby wyłączyć wpisz 0)';
$txt['mail_batch_size'] = 'Maksymalna ilość wiadomości wysłanych przy załadowaniu strony';

$txt['mailqueue_stats'] = 'Statystyki kolejki maili';
$txt['mailqueue_oldest'] = 'Najstarszy mail';
$txt['mailqueue_oldest_not_available'] = 'brak';
$txt['mailqueue_size'] = 'Długość kolejki';

$txt['mailqueue_age'] = 'Wiek';
$txt['mailqueue_priority'] = 'Priorytet';
$txt['mailqueue_recipient'] = 'Odbiorca';
$txt['mailqueue_subject'] = 'Tytuł';
$txt['mailqueue_clear_list'] = 'Wyślij teraz maile w kolejce';
$txt['mailqueue_no_items'] = 'Kolejka maili jest aktualnie pusta';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Jesteś pewien, że chcesz wysłać teraz całą kolejkę maili? Przekroczy to wszystkie ustawione limity.';

$txt['mq_day'] = '%1.1f Dzień';
$txt['mq_days'] = '%1.1f Dni';
$txt['mq_hour'] = '%1.1f Godzina';
$txt['mq_hours'] = '%1.1f Godzin';
$txt['mq_minute'] = '%1$d Minuta';
$txt['mq_minutes'] = '%1$d Minut';
$txt['mq_second'] = '%1$d Sekunda';
$txt['mq_seconds'] = '%1$d Sekund';

$txt['mq_mpriority_5'] = 'Bardzo niski';
$txt['mq_mpriority_4'] = 'Niski';
$txt['mq_mpriority_3'] = 'Normalny';
$txt['mq_mpriority_2'] = 'Wysoki';
$txt['mq_mpriority_1'] = 'Bardzo wysoki';

$txt['birthday_email'] = 'Wiadomość urodzinowa';
$txt['birthday_body'] = 'Treść wiadomości email';
$txt['birthday_subject'] = 'Tytuł wiadomości email';