<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'el_GR.utf8';
$txt['lang_dictionary'] = 'el';
$txt['lang_spelling'] = 'Ελληνικά';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'Κυριακή';
$txt['monday'] = 'Δευτέρα';
$txt['tuesday'] = 'Τρίτη';
$txt['wednesday'] = 'Τετάρτη';
$txt['thursday'] = 'Πέμπτη';
$txt['friday'] = 'Παρασκευή';
$txt['saturday'] = 'Σάββατο';

$txt['sunday_short'] = 'Κυρ';
$txt['monday_short'] = 'Δεύ';
$txt['tuesday_short'] = 'Τρί';
$txt['wednesday_short'] = 'Τέτ';
$txt['thursday_short'] = 'Πέμ';
$txt['friday_short'] = 'Παρ';
$txt['saturday_short'] = 'Σαββ';

$txt['january'] = 'Ιανουάριος';
$txt['february'] = 'Φεβρουάριος';
$txt['march'] = 'Μάρτιος';
$txt['april'] = 'Απρίλιος';
$txt['may'] = 'Μάιος ';
$txt['june'] = 'Ιούνιος';
$txt['july'] = 'Ιούλιος';
$txt['august'] = 'Αύγουστος';
$txt['september'] = 'Σεπτέμβριος ';
$txt['october'] = 'Οκτώβριος ';
$txt['november'] = 'Νοέμβριος';
$txt['december'] = 'Δεκέμβριος';

$txt['january_titles'] = 'Ιανουάριος';
$txt['february_titles'] = 'Φεβρουάριος';
$txt['march_titles'] = 'Μάρτιος';
$txt['april_titles'] = 'Απρίλιος';
$txt['may_titles'] = 'Μάιος ';
$txt['june_titles'] = 'Ιούνιος';
$txt['july_titles'] = 'Ιούλιος';
$txt['august_titles'] = 'Αύγουστος';
$txt['september_titles'] = 'Σεπτέμβριος ';
$txt['october_titles'] = 'Οκτώβριος ';
$txt['november_titles'] = 'Νοέμβριος';
$txt['december_titles'] = 'Δεκέμβριος';

$txt['january_short'] = 'Ιάν';
$txt['february_short'] = 'Φέβ';
$txt['march_short'] = 'Μάρ';
$txt['april_short'] = 'Απρ';
$txt['may_short'] = 'Μάιος ';
$txt['june_short'] = 'Ιούν';
$txt['july_short'] = 'Ιούλ';
$txt['august_short'] = 'Αύγ';
$txt['september_short'] = 'Σεπ';
$txt['october_short'] = 'Οκτ';
$txt['november_short'] = 'Νοέ';
$txt['december_short'] = 'Δεκ';

$txt['time_am'] = 'πμ';
$txt['time_pm'] = 'μμ';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Αρχική';
$txt['community'] = 'Φόρουμ';
// Sub menu labels
$txt['help'] = 'Βοήθεια';
$txt['search'] = 'Αναζήτηση';
$txt['calendar'] = 'Ημερολόγιο';
$txt['members'] = 'Μέλη';
$txt['recent_posts'] = 'Τελευταία μηνύματα';

$txt['admin'] = 'Διαχείριση';
// Sub menu labels
$txt['errlog'] = 'Αρχείο καταγραφής σφαλμάτων';
$txt['package'] = 'Διαχείριση πακέτων';
$txt['edit_permissions'] = 'Δικαιώματα';
$txt['modSettings_title'] = 'Χαρακτηριστικά και επιλογές';

$txt['moderate'] = 'Συντονισμός';
// Sub menu labels
$txt['modlog_view'] = 'Αρχείο καταγραφής συντονισμού';
$txt['mc_emailerror'] = 'Χωρίς έγκριση Emails';
$txt['mc_reported_posts'] = 'Αναφερόμενα μηνύματα';
$txt['mc_reported_pms'] = 'Αναφερόμενα Προσωπικά Μηνύματα';
$txt['mc_unapproved_attachments'] = 'Μη εγκεκριμένα συνημμένα';
$txt['mc_unapproved_poststopics'] = 'Μη εγκεκριμένα μηνύματα και θέματα';

$txt['pm_short'] = 'Τα μηνύματά μου';
// Sub menu labels
$txt['pm_menu_read'] = 'Ανάγνωση μηνυμάτων';
$txt['pm_menu_send'] = 'Αποστολή μηνύματος';

$txt['account_short'] = 'Ο λογαριασμός μου';
// Sub menu labels
$txt['profile'] = 'Προφίλ';
$txt['mydrafts'] = 'Τα πρόχειρα μου';
$txt['summary'] = 'Περίληψη';
$txt['theme'] = 'Ρυθμίσεις εμφάνισης';
$txt['account'] = 'Ρυθμίσεις λογαριασμού';
$txt['forumprofile'] = 'Προφίλ φόρουμ';

$txt['view_unread_category'] = 'Νέα μηνύματα';
$txt['view_replies_category'] = 'Νέες απαντήσεις';

$txt['login'] = 'Σύνδεση';
$txt['register'] = 'Εγγραφή';
$txt['logout'] = 'Αποσύνδεση';
// End main menu strings.

$txt['save'] = 'Αποθήκευση';

$txt['modify'] = 'Τροποποίηση';
$txt['forum_index'] = '%1$s- Index';
$txt['board_name'] = 'Όνομα φόρουμ';
$txt['posts'] = 'μηνύματα';

$txt['member_postcount'] = 'μηνύματα';
$txt['no_subject'] = '(Χωρίς τίτλο)';
$txt['view_profile'] = 'Προφίλ';
$txt['guest_title'] = 'Επισκέπτης';
$txt['author'] = 'Αποστολέας';
$txt['on'] = 'στις';
$txt['remove'] = 'Διαγραφή';
$txt['start_new_topic'] = 'Νέο θέμα';

// Use numeric entities in the below string.
$txt['username'] = 'Όνομα χρήστη';
$txt['password'] = 'Κωδικός';

$txt['username_no_exist'] = 'Αυτό το όνομα χρήστη δεν υπάρχει.';
$txt['no_user_with_email'] = 'Δεν υπάρχουν όνομα χρήστη συνδεδεμένο με αυτό το email.';

$txt['board_moderator'] = 'Συντονιστής πίνακα';
$txt['remove_topic'] = 'Διαγραφή';
$txt['topics'] = 'Θέματα';
$txt['modify_msg'] = 'Αλλαγή';
$txt['name'] = 'Όνομα';
$txt['email'] = 'E-mail';
$txt['user_email_address'] = 'Διεύθυνση e-mail';
$txt['subject'] = 'Τίτλος';
$txt['message'] = 'Μήνυμα';
$txt['redirects'] = 'Ανακατευθύνσεις';

$txt['choose_pass'] = 'Επιλογή κωδικού πρόσβασης';
$txt['verify_pass'] = 'Επαλήθευση κωδικού';
$txt['position'] = 'Αξίωμα';
$txt['notify_announcements'] = 'Εγγραφείτε για να λαμβάνετε σημαντικές ειδήσεις από το φόρουμ μέσω ηλεκτρονικού ταχυδρομείου';

$txt['profile_of'] = 'Εμφάνιση προφίλ του μέλους';
$txt['total'] = 'Σύνολο';
$txt['posts_made'] = 'μηνύματα';
$txt['topics_made'] = 'Θέματα';
$txt['website'] = 'Ιστότοπος';
$txt['contact'] = 'Επικοινωνία';
$txt['warning_status'] = 'Κατάσταση προειδοποίησης';
$txt['user_warn_watch'] = 'Ο χρήστης είναι στη λίστα παρακολούθησης των συντονιστών';
$txt['user_warn_moderate'] = 'Τα μηνύματα του χρήστη μπαίνουν στη λίστα για έγκριση';
$txt['user_warn_mute'] = 'Ο χρήστης έχει αποκλειστεί από την δημοσίευση μηνυμάτων';
$txt['warn_watch'] = 'Υπό παρακολούθηση';
$txt['warn_moderate'] = 'Υπό έγκριση';
$txt['warn_mute'] = 'Φιμωμένος';
$txt['warning_issue'] = 'Προειδοποίηση ';

$txt['message_index'] = 'Πίνακας μηνυμάτων';
$txt['news'] = 'Ειδήσεις';
$txt['page'] = 'Σελίδα';
$txt['prev'] = 'Προηγούμενο';
$txt['next'] = 'Επόμενο';

$txt['post'] = 'Δημοσίευση';
$txt['error_occurred'] = 'Παρουσιάστηκε σφάλμα';
$txt['send_error_occurred'] = 'Παρουσιάστηκε σφάλμα,<a href="{href}">κάντε κλίκ εδώ για να δοκιμάσετε ξανά</a>.';
$txt['require_field'] = 'Αυτό είναι υποχρεωτικό πεδίο.';
$txt['started_by'] = 'Ξεκίνησε από το μέλος';
$txt['topic_started_by'] = 'Ξεκίνησε από %1$s';
$txt['topic_started_by_in'] = 'Ξεκίνησε από %1$sστις %2$s';
$txt['replies'] = 'Απαντήσεις';
$txt['last_post'] = 'Τελευταίο μήνυμα';
$txt['first_post'] = 'Πρώτη δημοσίευση';
$txt['last_poster'] = 'Δημιουργός τελευταίας δημοσίευσης';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s</span><span class="board_lastposter">από%1$s</span><span class="board_lasttime"><strong>Τελευταία δημοσίευση:</strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$sΔημοσιεύσεις σε%2$sΘέματα από %3$sΜέλη';
$txt['show'] = 'Εμφάνιση';
$txt['hide'] = 'Απόκρυψη';
$txt['sort_by'] = 'Ταξινόμηση με';
$txt['sort_asc'] = 'Αύξουσα τιμή';
$txt['sort_desc'] = 'Φθίνουσα τιμή';

$txt['admin_login'] = 'Σύνδεση Διαχείρισης ';
// Use numeric entities in the below string.
$txt['topic'] = 'Θέμα';
$txt['help'] = 'Βοήθεια';
$txt['notify'] = 'Ειδοποίηση';
$txt['unnotify'] = 'Μη ειδοποίηση';
$txt['notify_request'] = 'Θέλετε ειδοποίηση με e-mail όταν κάποιος απαντήσει σε αυτό το θέμα;';
// Use numeric entities in the below string.
$txt['regards_team'] = "Χαιρετισμούς,\ Η {forum_name_html_unsafe} Ομάδα.";
$txt['notify_replies'] = 'Ειδοποίηση για απαντήσεις';
$txt['move_topic'] = 'Μετακίνηση';
$txt['move_to'] = 'Μετακίνηση σε';
$txt['pages'] = 'Σελίδες';
$txt['users_active'] = 'Ενεργός πριν από%1$dλεπτό/α';
$txt['personal_messages'] = 'Προσωπικά μηνύματα';
$txt['reply_quote'] = 'Απάντηση με παράθεση';
$txt['reply'] = 'Απάντηση';
$txt['reply_number'] = 'Απάντηση #%1$s';
$txt['approve'] = 'Έγκριση';
$txt['unapprove'] = 'Χωρίς έγκριση';
$txt['approve_all'] = 'έγκριση όλων';
$txt['awaiting_approval'] = 'Περιμένουν έγκριση';
$txt['attach_awaiting_approve'] = 'Συνημμένα που περιμένουν έγκριση';
$txt['post_awaiting_approval'] = 'Σημείωση: Αυτό το μήνυμα περιμένει έγκριση από κάποιον συντονιστή.';
$txt['there_are_unapproved_topics'] = 'Υπάρχουν %1$sθέματα και %2$sδημοσιεύσεις που περιμένουν έγκριση για αυτόν τον πίνακα.<a href="%3$s">Κάντε κλικ εδώ για τα δείτε.';
$txt['send_message'] = 'Αποστολή μηνύματος';

$txt['msg_alert_no_messages'] = 'Δεν έχετε κανένα μήνυμα';
$txt['msg_alert_one_message'] = 'έχετε <a href="%1$s">1μήνυμα</a>';
$txt['msg_alert_many_message'] = 'έχετε <a href="%1$s">%2$dμηνύματα</a>';
$txt['msg_alert_one_new'] = '1 είναι νέο';
$txt['msg_alert_many_new'] = '%1$dείναι νέο/α';
$txt['remove_message'] = 'Διαγραφή';

$txt['topic_alert_none'] = 'Κανένα μήνυμα...';
$txt['pm_alert_none'] = 'Κανένα μήνυμα...';

$txt['online_users'] = 'Συνδεδεμένοι χρήστες'; //Deprecated
$txt['online_now'] = 'Σε σύνδεση';
$txt['personal_message'] = 'Προσωπικό μήνυμα';
$txt['jump_to'] = 'Μεταπήδηση σε';
$txt['go'] = 'Ψάξε';
$txt['are_sure_remove_topic'] = 'Θέλετε σίγουρα να διαγράψετε αυτό το θέμα;';
$txt['yes'] = 'Ναι';
$txt['no'] = 'Όχι';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'στις';

$txt['search'] = 'Αναζήτηση';
$txt['all'] = 'Όλοι';
$txt['search_entireforum'] = 'Ολόκληρο το φόρουμ';
$txt['search_thisbrd'] = 'Αυτός ο πίνακας';
$txt['search_thistopic'] = 'Αυτό το θέμα';
$txt['search_members'] = 'Μέλη';

$txt['back'] = 'Πίσω';
$txt['continue'] = 'Συνέχεια';
$txt['password_reminder'] = 'Υπενθύμιση κωδικού';
$txt['topic_started'] = 'Μήνυμα ξεκίνησε από';
$txt['title'] = 'Τίτλος';
$txt['post_by'] = 'Αποστολή από';
$txt['welcome_newest_member'] = 'Παρακαλώ καλωσορίστε%1$s, το νέο μας μέλος';
$txt['admin_center'] = 'Κέντρο διαχείρισης';
$txt['admin_session_active'] = 'Έχετε ενεργή μία συνεδρία διαχειριστή. Συνιστούμε τον <strong><a class="strong" href="%1$s">τερματισμό της συνεδρίας</a></strong>μόλις ολοκληρώσετε τις εργασίες διαχείρισης.';
$txt['admin_maintenance_active'] = 'Το φόρουμ είναι σε κατάσταση συντήρησης, μόνο οι διαχειριστές μπορούν να συνδεθούν. Σας υπενθυμίζουμε την <strong><a class="strong" href="%1$s">διακοπή της συντήρησης </strong>μόλις ολοκληρώσετε εργασίες διαχείρισης.';
$txt['query_command_denied'] = 'Προέκυψαν τα ακόλουθα MySQL σφάλματα, παρακαλώ επαληθεύσετε τις ρυθμίσεις:';
$txt['query_command_denied_guests'] = 'Φαίνεται ότι ξαφνικά κάτι πήγε στραβά με τη βάση δεδομένων του φόρουμ.Αυτό το πρόβλημα πρέπει να είναι προσωρινό,παρακαλούμε επιστρέψτε αργότερα και προσπαθήστε ξανά. Αν συνεχίσετε να βλέπετε αυτό το μήνυμα, αναφέρετε το ακόλουθο μήνυμα στον διαχειριστή:';
$txt['query_command_denied_guests_msg'] = 'η εντολή %1$sαπορρίπτεται στην βάση δεδομένων';
$txt['last_edit_by'] = '<span class="lastedit">Τελευταία Επεξεργασία</span>: %1$sαπό%2$s';
$txt['notify_deactivate'] = 'Απενεργοποίηση ειδοποίησης σε αυτό το θέμα;';

$txt['date_registered'] = 'Ημερομηνία εγγραφής';
$txt['date_joined'] = 'Εντάχθηκε';
$txt['date_joined_format'] = '%b%d, %Y';

$txt['recent_view'] = 'Δείτε όλες τις πρόσφατες δημοσιεύσεις.';
$txt['is_recent_updated'] = '%1$sείναι το πιο πρόσφατα ενημερωμένο θέμα';

$txt['male'] = 'Άντρας';
$txt['female'] = 'Γυναίκα';

$txt['error_invalid_characters_username'] = 'Μη έγκυρος χαρακτήρας στο όνομα χρήστη.';

$txt['welcome_guest'] = 'Καλωσήρθες,<strong>Επισκέπτη</strong>.Παρακαλώ<a href="{login_url}" rel="nofollow">συνδέσου</a>.';
$txt['welcome_guest_register'] = 'Καλωσήρθες στο <strong>{forum_name}</strong>.Παρακαλώ<a href="{login_url}" rel="nofollow">συνδέσου</a>ή <a href="{register_url}" rel="nofollow">εγγράψου</a>.';
$txt['welcome_guest_activate'] = '<br />Έχασες το <a href="{activate_url}" rel="nofollow">email ενεργοποίησης</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Γεια χαρά,';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Καλώς ορίσατε,';
$txt['select_destination'] = 'Επιλέξτε προορισμό';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Στάλθηκε από';

$txt['icon_smiley'] = 'Χαμόγελο';
$txt['icon_angry'] = 'Θυμός';
$txt['icon_cheesy'] = 'Μεγάλο χαμόγελο';
$txt['icon_laugh'] = 'Γέλιο';
$txt['icon_sad'] = 'Λύπη';
$txt['icon_wink'] = 'Κλείσιμο ματιού';
$txt['icon_grin'] = 'Σαρκασμός';
$txt['icon_shocked'] = 'Έκπληξη';
$txt['icon_cool'] = 'Άνεση';
$txt['icon_huh'] = 'Απορία';
$txt['icon_rolleyes'] = 'Στριφογύρισμα ματιών';
$txt['icon_tongue'] = 'Γλώσσα';
$txt['icon_embarrassed'] = 'Ντροπή';
$txt['icon_lips'] = 'Σφραγισμένα χείλη';
$txt['icon_undecided'] = 'Αναποφασιστικότητα';
$txt['icon_kiss'] = 'Φιλί';
$txt['icon_cry'] = 'Κλάμα';
$txt['icon_angel'] = 'Αθωότητα';

$txt['moderator'] = 'Συντονιστή';
$txt['moderators'] = 'Συντονιστές';

$txt['views'] = 'Εμφανίσεις';
$txt['new'] = 'Νέα';
$txt['no_redir'] = 'Ανακατεύθυνση από %1$s';

$txt['view_all_members'] = 'Όλα τα μέλη';
$txt['view'] = 'Εμφάνιση';

$txt['viewing_members'] = 'Εμφάνιση μελών %1$s έως %2$s';
$txt['of_total_members'] = 'από %1$s συνολικά μέλη';

$txt['forgot_your_password'] = 'Ξεχάσατε τον κωδικό σας;';

$txt['date'] = 'Ημερομηνία';
// Use numeric entities in the below string.
$txt['from'] = 'Από';
$txt['to'] = 'Προς';

$txt['board_topics'] = 'Θέματα';
$txt['members_title'] = 'Μέλη';
$txt['members_list'] = 'Λίστα μελών';
$txt['new_posts'] = 'Νέα μηνύματα';
$txt['old_posts'] = 'Κανένα νέο μήνυμα';
$txt['redirect_board'] = 'Πίνακας ανακατεύθυνσης';
$txt['redirect_board_to'] = 'Ανακατεύθυνση σε%1$s ';

$txt['sendtopic_send'] = 'Αποστολή';
$txt['report_sent'] = 'Η αναφορά σας στάλθηκε επιτυχώς.';
$txt['topic_sent'] = 'Το email σας έχει σταλεί με επιτυχία.';

$txt['time_offset'] = 'Διαφορά ώρας';
$txt['or'] = 'ή';

$txt['mention'] = 'Ειδοποιήσεις';
$txt['notifications'] = 'Ειδοποιήσεις';
$txt['unread_notifications'] = 'Έχετε %1$sμη αναγνωσμένες κοινοποίησεις από την τελευταία σας επίσκεψη.';
$txt['new_from_last_notifications'] = 'Έχετε %1$sνέες κοινοποιήσεις. ';
$txt['forum_notification'] = 'Κοινοποιήσεις από%1$s.';

$txt['your_ban'] = 'Λυπούμαστε %1$s, έχετε αποκλειστεί από αυτό το φόρουμ!';
$txt['your_ban_expires'] = 'Αυτός ο αποκλεισμός θα λήξει %1$s';
$txt['your_ban_expires_never'] = 'Αυτός ο αποκλεισμός δεν έχει ημερομηνία λήξης.';
$txt['ban_continue_browse'] = 'Μπορείτε να περιηγηθείτε στο φόρουμ ως επισκέπτης.';

$txt['mark_as_read'] = 'Σήμανση ΟΛΩΝ των μηνυμάτων ως αναγνωσμένα';
$txt['mark_as_read_confirm'] = 'Είστε βέβαιοι ότι θέλετε να επισημάνετε ΟΛΑ τα μηνύματα ως αναγνωσμένα;';
$txt['mark_these_as_read'] = 'Σημειώστε ΑΥΤΑ τα μηνύματα ως αναγνωσμένα';
$txt['mark_these_as_read_confirm'] = 'Είστε βέβαιοι ότι θέλετε να επισημάνετε ΑΥΤΑ τα μηνύματα ως αναγνωσμένα;';

$txt['locked_topic'] = 'Κλειδωμένο θέμα';
$txt['normal_topic'] = 'Κανονικό θέμα';
$txt['participation_caption'] = 'Θέμα όπου έχετε συμμετάσχει';

$txt['print'] = 'Εκτύπωση';
$txt['topic_summary'] = 'Περίληψη θέματος';
$txt['not_applicable'] = '(-)';
$txt['name_in_use'] = 'Το όνομα %1$s χρησιμοποιείται από άλλο μέλος.';

$txt['total_members'] = 'Σύνολο μελών';
$txt['total_posts'] = 'Σύνολο μηνυμάτων';
$txt['total_topics'] = 'Σύνολο θεμάτων';

$txt['mins_logged_in'] = 'Λεπτά παραμονής σε σύνδεση';

$txt['preview'] = 'Προεπισκόπηση';
$txt['always_logged_in'] = 'Αυτόματη επανασύνδεση';

$txt['logged'] = 'Καταγράφηκε';
// Use numeric entities in the below string.
$txt['ip'] = 'IP';

$txt['www'] = 'WWW';
$txt['link'] = 'Σύνδεσμος';

$txt['by'] = 'από'; //Deprecated

$txt['hours'] = 'ώρες';
$txt['minutes'] = 'λεπτά';
$txt['seconds'] = 'δευτερόλεπτα';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'Ώρα';
$txt['days_word'] = 'ημέρες';

$txt['newest_member'] = ', το νεότερο μέλος μας.'; //Deprecated

$txt['search_for'] = 'Αναζήτηση για';
$txt['search_match'] = 'Ταίριασμα';

$txt['maintain_mode_on'] = 'Προσοχή, το φόρουμ είναι σε κατάσταση συντήρησης.';

$txt['read'] = 'Αναγνώστηκε'; //Deprecated
$txt['times'] = 'φορές'; //Deprecated
$txt['read_one_time'] = 'Αναγνωσμένο 1 φορά';
$txt['read_many_times'] = 'Αναγνωσμένο %1$d φορές';

$txt['forum_stats'] = 'Στατιστικά';
$txt['latest_member'] = 'Τελευταίο μέλος';
$txt['total_cats'] = 'Σύνολο κατηγοριών';
$txt['latest_post'] = 'Τελευταίο μήνυμα';

$txt['here'] = 'εδώ';
$txt['you_have_no_msg'] = 'Δεν έχετε κανένα μήνυμα...';
$txt['you_have_one_msg'] = 'Έχετε 1 μήνυμα...<a href="%1$s">Κάντε κλικ για να το διαβάσετε</a>';
$txt['you_have_many_msgs'] = 'Έχετε %2$dμηνύματα...<a href="%1$s">Κάντε κλικ για να τα δείτε</a>';

$txt['total_boards'] = 'Σύνολο πινάκων';

$txt['print_page'] = 'Εκτύπωση σελίδας';
$txt['print_page_text'] = 'Μόνο κείμενο';
$txt['print_page_images'] = 'Κείμενο με εικόνες';

$txt['valid_email'] = 'Εισαγάγετε μία έγκυρη διεύθυνση e-mail.';

$txt['info_center_title'] = '%1$s - Κέντρο Πληροφοριών';

$txt['send_topic'] = 'Κοινοποίηση';
$txt['unwatch'] = 'Χωρίς προβολή';
$txt['watch'] = 'Έχουν προβληθεί';

$txt['sendtopic_title'] = 'Αποστολή θέματος &quot;%1$s&quot; σε ένα φίλο.';
$txt['sendtopic_sender_name'] = 'Το όνομά σας';
$txt['sendtopic_sender_email'] = 'Το e-mail σας';
$txt['sendtopic_receiver_name'] = 'Όνομα παραλήπτη';
$txt['sendtopic_receiver_email'] = 'E-mail παραλήπτη';
$txt['sendtopic_comment'] = 'Προσθήκη σχολίου';

$txt['allow_user_email'] = 'Να επιτρέπεται στους χρήστες να μου στέλνουν email';

$txt['check_all'] = 'Επιλογή όλων';

// Use numeric entities in the below string.
$txt['database_error'] = 'Σφάλμα βάσης δεδομένων';
$txt['try_again'] = 'Παρακαλούμε ξαναπροσπαθήστε. Αν το σφάλμα ξαναεμφανιστεί, αναφέρετέ το σε έναν διαχειριστή.';
$txt['file'] = 'Αρχείο';
$txt['line'] = 'Γραμμή';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'Το ElkArte βρήκε και προσπάθησε αυτόματα να διορθώσει ένα λάθος στη βάση δεδομένων.Εάν εξακολουθείτε να αντιμετωπίζετε προβλήματα ή συνεχίζετε να λαμβάνετε αυτά τα μηνύματα ηλεκτρονικού ταχυδρομείου, επικοινωνήστε με την σελίδα φιλοξενίας (host) σας.';
$txt['database_error_versions'] = '<strong>Σημείωση:</strong>Η έκδοση της βάσης δεδομένων είναι%1$s.';
$txt['template_parse_error'] = 'Σφάλμα στο Template!';
$txt['template_parse_error_message'] = 'Φαίνεται ότι κάτι πήγε στραβά με το σύστημα των προτύπων.  Αυτό το πρόβλημα συνήθως είναι προσωρινό, ξαναδοκιμάστε λίγο αργότερα.  Αν συνεχίζετε να βλέπετε αυτό το μήνυμα, παρακαλούμε επικοινωνήστε με τον διαχειριστή.<br /><br />Μπορείτε επίσης να δοκιμάσετε να <a href="javascript:location.reload();"> κάνετε ανανέωση αυτής της σελίδας</a>.';
$txt['template_parse_error_details'] = 'Παρουσιάστηκε πρόβλημα κατά τη φόρτωση του<span class="tt"><strong>%1$s</strong></span> προτύπου ή του αρχείου γλώσσας.Παρακαλώ ελέγξτε την σύνταξη και δοκιμάστε ξανά - υπενθύμιση, τα μονά εισαγωγικά (<span class="tt">\'</span>) συχνά πρέπει να συνοδεύονται  με αντίστροφη κάθετο (<span class="tt">\\</span>). Για να δείτε συγκεκριμένες πληροφορίες σχετικά με το σφάλμα από PHP, προσπαθήστε <a href="%2$s%1$s">την άμεση πρόσβαση</a>.<br /><br />Μπορείτε να προσπαθήσετε την<a href="javascript:location.reload();">ανανέωση της σελίδας</a>ή την<a href="%3$s">χρήση του προ-επιλεγμένου θέματος</a>. ';
$txt['template_parse_undefined'] = 'Κατά τη διάρκεια της ανάλυσης αυτού του προτύπου προέκυψε ένα άγνωστο σφάλμα';

$txt['today'] = 'Σήμερα στις %1$s';
$txt['yesterday'] = 'Εχθές στις %1$s';

// Relative times
$txt['rt_now'] = 'μόλις τώρα';
$txt['rt_minute'] = 'Πριν ένα λεπτό';
$txt['rt_minutes'] = '%sλεπτά πριν';
$txt['rt_hour'] = 'Μία ώρα πριν';
$txt['rt_hours'] = '%sώρες πριν';
$txt['rt_day'] = 'Εχθές';
$txt['rt_days'] = '%sημέρες πριν';
$txt['rt_week'] = 'Μία εβδομάδα πριν';
$txt['rt_weeks'] = '%sεβδομάδες πριν';
$txt['rt_month'] = 'Ένα μήνα πριν';
$txt['rt_months'] = '%sμήνες πριν';
$txt['rt_year'] = 'Ένα χρόνο πριν';
$txt['rt_years'] = '%sχρόνια πριν';

$txt['new_poll'] = 'Νέα ψηφοφορία';
$txt['poll_question'] = 'Ερώτηση';
$txt['poll_question_options'] = 'Ερωτήσεις και Επιλογές';
$txt['poll_vote'] = 'Αποστολή ψήφου';
$txt['poll_total_voters'] = 'Σύνολο ψηφοφόρων';
$txt['draft_saved_on'] = 'Τελευταίο αποθηκευμένο πρόχειρο';
$txt['poll_results'] = 'Εμφάνιση αποτελεσμάτων';
$txt['poll_lock'] = 'Κλείδωμα ψηφοφορίας';
$txt['poll_unlock'] = 'Ξεκλείδωμα ψηφοφορίας';
$txt['poll_edit'] = 'Αλλαγή ψηφοφορίας';
$txt['poll'] = 'Ψηφοφορία';
$txt['one_day'] = '1 μέρα';
$txt['one_week'] = '1 εβδομάδα';
$txt['two_weeks'] = '2 Εβδομάδες';
$txt['one_month'] = '1 μήνας';
$txt['two_months'] = '2 Μήνες';
$txt['forever'] = 'Χωρίς όριο';
$txt['quick_login_dec'] = 'Σύνδεση με όνομα, κωδικό και διάρκεια σύνδεσης';
$txt['one_hour'] = '1 ώρα';
$txt['moved'] = 'ΜΕΤΑΚΙΝΗΘΗΚΕ';
$txt['moved_why'] = 'Δώστε μια σύντομη επεξήγηση γιατί<br>μετακινήθηκε αυτό το θέμα.';
$txt['board'] = 'Πίνακας';
$txt['in'] = 'σε';
$txt['sticky_topic'] = 'Καρφιτσωμένο Θέμα ';
$txt['split'] = 'Διαχωρισμός';

$txt['delete'] = 'Διαγραφή';

$txt['byte'] = 'B';
$txt['kilobyte'] = 'KB';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[Περισσότερα στατιστικά]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Κώδικας';
$txt['code_select'] = '[Επιλογή]';
$txt['quote_from'] = 'Παράθεση από';
$txt['quote'] = 'Παράθεση';
$txt['quote_new'] = 'Νέο θέμα';
$txt['follow_ups'] = 'Υπό παρακολούθηση ';
$txt['topic_derived_from'] = 'Το θέμα προέρχεται από %1$s';
$txt['edit'] = 'Τροποποίηση';
$txt['quick_edit'] = 'Γρήγορη επεξεργασία';
$txt['post_options'] = 'Περισσότερα...';

$txt['set_sticky'] = 'Καρφίτσωμα';
$txt['set_nonsticky'] = 'Αφαίρεση καρφιτσώματος';
$txt['set_lock'] = 'Κλείδωμα';
$txt['set_unlock'] = 'Ξεκλείδωμα';

$txt['search_advanced'] = 'Εμφάνιση επιλογών για προχωρημένους';
$txt['search_simple'] = 'Απόκρυψη επιλογών για προχωρημένους';

$txt['security_risk'] = 'ΚΙΝΔΥΝΟΣ ΑΣΦΑΛΕΙΑΣ:';
$txt['not_removed'] = ' Δεν έχετε καταργήσει %1$s';
$txt['not_removed_extra'] = '%1$sείναι αντίγραφο ασφαλείας από %2$sπου δεν δημιουργήθηκε από το ElkArte. Μπορεί να προσεγγιστεί άμεσα και να χρησιμοποιηθεί για την απόκτηση μη εξουσιοδοτημένης πρόσβασης στο φόρουμ σας. Θα πρέπει να το διαγράψετε αμέσως.';
$txt['generic_warning'] = 'Προειδοποίηση';
$txt['agreement_missing'] = 'Απαιτείτε από τους νέους χρήστες να αποδεχθούν μια συμφωνία εγγραφής, ωστόσο το αρχείο (agreement.txt) δεν υπάρχει.';
$txt['agreement_accepted'] = 'Μόλις δεχτήκατε τη συμφωνία.';
$txt['privacypolicy_accepted'] = 'Μόλις αποδεχθήκατε την πολιτική απορρήτου του φόρουμ.';

$txt['new_version_updates'] = 'Μόλις κάνατε ενημέρωση!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Κάντε κλικ εδώ για να δείτε τα νέα σχετικά με αυτή την έκδοση ElkArte!</a>!';

$txt['cache_writable'] = 'Ο φάκελος προσωρινής μνήμης (cache) δεν είναι εγγράψιμος - αυτό θα επηρρεάσει δυσμενώς την απόδοση του φόρουμ.';

$txt['page_created_full'] = 'Η σελίδα δημιουργήθηκε πριν από %1$.3fδευτερόλεπτα με %2$d ερωτήματα.';

$txt['report_to_mod_func'] = 'Χρησιμοποιήστε αυτή την λειτουργία για να πληροφορήσετε τους συντονιστές και διαχειριστές για ένα καταχρηστικό ή εσφαλμένα σταλμένο μήνυμα.<br /><em>Σημείωση: Η διεύθυνσή email σας θα εμφανιστεί στους συντονιστές αν χρησιμοποιήσετε την λειτουργία.</em>  ';

$txt['online'] = 'Συνδεδεμένος';
$txt['member_is_online'] = '%1$s είναι συνδεδεμένος';
$txt['offline'] = 'Αποσυνδεδεμένος';
$txt['member_is_offline'] = '%1$sεκτός σύνδεσης';
$txt['pm_online'] = 'Προσωπικό μήνυμα (Σε σύνδεση)';
$txt['pm_offline'] = 'Προσωπικό μήνυμα (Εκτός σύνδεσης)';
$txt['status'] = 'Κατάσταση';

$txt['skip_nav'] = 'Μετάβαση στο κύριο περιεχόμενο';
$txt['go_up'] = 'Πάνω';
$txt['go_down'] = 'Κάτω';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Γενέθλια:';
$txt['events'] = 'Εκδηλώσεις:';
$txt['birthdays_upcoming'] = 'Προσεχή γενέθλια:';
$txt['events_upcoming'] = 'Προσεχείς εκδηλώσεις:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Διακοπές:';
$txt['calendar_month'] = 'Μήνας';
$txt['calendar_year'] = 'Έτος:';
$txt['calendar_day'] = 'Ημέρα:';
$txt['calendar_event_title'] = 'Τίτλος εκδήλωσης';
$txt['calendar_event_options'] = 'Επιλογές Εκδηλώσεων';
$txt['calendar_post_in'] = 'Δημιουργία στο:';
$txt['calendar_edit'] = 'Τροποποίηση εκδήλωσης';
$txt['event_delete_confirm'] = 'Διαγραφή αυτής της εκδήλωσης;';
$txt['event_delete'] = 'Διαγραφή εκδήλωσης';
$txt['calendar_post_event'] = 'Δημιουργία εκδήλωσης';
$txt['calendar'] = 'Ημερολόγιο';
$txt['calendar_link'] = 'Σύνδεση με το ημερολόγιο';
$txt['calendar_upcoming'] = 'Ημερολόγιο Προσεχώς';
$txt['calendar_today'] = 'Ημερολόγιο ημέρας';
$txt['calendar_week'] = 'Εβδομάδα';
$txt['calendar_week_title'] = 'Εβδομάδα %1$d από %2$d';
$txt['calendar_numb_days'] = 'Αριθμός ημερών:';
$txt['calendar_how_edit'] = 'πώς τροποποιείτε αυτές τις εκδηλώσεις;';
$txt['calendar_link_event'] = 'Σύνδεση εκδήλωσης';
$txt['calendar_confirm_delete'] = 'Σίγουρα θέλετε να διαγράψετε αυτή την εκδήλωση;';
$txt['calendar_linked_events'] = 'Συνδεδεμένες εκδηλώσεις';
$txt['calendar_click_all'] = 'Πατήστε για να δείτε όλες %1$s';

$txt['moveTopic1'] = 'Δημιουργία θέματος παραπομπής';
$txt['moveTopic2'] = 'Αλλαγή τίτλου θέματος';
$txt['moveTopic3'] = 'Νέος τίτλος';
$txt['moveTopic4'] = 'Αλλαγή τίτλου όλων των μηνυμάτων';
$txt['move_topic_unapproved_js'] = 'Προσοχή! Αυτό το θέμα δεν έχει ήδη εγκριθεί.\\n\\nΔεν προτείνεται να δημιουργήσετε ένα θέμα ανακατεύθυνσης εκτός αν πρόκειται να εγκρίνετε το μήνυμα αμέσως μετά από αυτήν την κίνηση.';
$txt['movetopic_auto_board'] = '[BOARD]';
$txt['movetopic_auto_topic'] = '[TOPIC LINK]';
$txt['movetopic_default'] = 'Αυτό το θέμα μεταφέρθηκε στον πίνακα [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Ανακατεύθυνση στο θέμα ';
$txt['movetopic_expires'] = 'Καταργήστε αυτόματα το θέμα ανακατεύθυνσης';

$txt['merge_to_topic_id'] = 'Αναγνωριστικό (ID) του θέματος προορισμού';
$txt['split_topic'] = 'Διαχωρισμός';
$txt['merge'] = 'Συγχώνευση';
$txt['subject_new_topic'] = 'Τίτλος του νέου θέματος';
$txt['split_this_post'] = 'Διαχωρισμός μόνο αυτού του μηνύματος.';
$txt['split_after_and_this_post'] = 'Διαχωρισμός του θέματος από αυτό το μήνυμα (συμπεριλαμβανομένου) και κάτω.';
$txt['select_split_posts'] = 'Επιλέξτε μηνύματα για διαχωρισμό.';

$txt['splittopic_notification'] = 'Δημοσίευση μηνύματος όταν το θέμα είναι χωρισμένο';
$txt['splittopic_default'] = 'Μία ή περισσότερες δημοσιεύσεις από αυτό το θέμα έχουν μετακινηθεί σε [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Μετακίνηση του νέου θέματος σε άλλο πίνακα';

$txt['new_topic'] = 'Νέο θέμα';
$txt['split_successful'] = 'Το θέμα διαχωρίστηκε σε δύο θέματα.';
$txt['origin_topic'] = 'Αρχικό θέμα';
$txt['please_select_split'] = 'Επιλέξτε τα μηνύματα που θέλετε να διαχωρίσετε.';
$txt['merge_successful'] = 'Τα θέματα συγχωνεύθηκαν.';
$txt['new_merged_topic'] = 'Συγχωνευμένο θέμα';
$txt['topic_to_merge'] = 'Θέματα προς συγχώνευση';
$txt['target_board'] = 'Τελικός πίνακας';
$txt['target_topic'] = 'Τελικό θέμα';
$txt['merge_confirm'] = 'Θέλετε σίγουρα να κάνετε συγχώνευση;';
$txt['with'] = 'με';
$txt['merge_desc'] = 'Αυτή η επιλογή θα συγχωνεύσει τα μηνύματα δύο θεμάτων σε ένα. Τα μηνύματα θα εμφανίζονται ανάλογα με τον χρόνο αποστολής. Το πιο παλιό μήνυμα θα εμφανίζεται πρώτο στο τελικό θέμα.';

$txt['theme_template_error'] = 'Δεν ήταν δυνατόν να φορτωθεί το πρότυπο \'%1$s\'.';
$txt['theme_language_error'] = 'Δεν ήταν δυνατόν να φορτωθεί το αρχείο γλώσσας \'%1$s\'.';

$txt['parent_boards'] = 'Υπό-κατηγορίες';

$txt['smtp_no_connect'] = 'Δεν ήταν δυνατόν να γίνει σύνδεση με τον διακομιστή SMTP';
$txt['smtp_port_ssl'] = 'Η ρύθμιση θύρας SMTP είναι εσφαλμένη, θα έπρεπε να είναι 465 για διακομιστές SSL.';
$txt['smtp_bad_response'] = 'Δεν ήταν δυνατόν να ληφθούν οι κωδικοί απόκρισης διακομιστή αλληλογραφίας';
$txt['smtp_error'] = 'Υπήρξαν προβλήματα στην αποστολή αλληλογραφίας. Σφάλμα: ';
$txt['mail_send_unable'] = 'Δεν ήταν δυνατόν να σταλεί e-mail στη διεύθυνση \'%1$s\'';

$txt['mlist_search'] = 'Αναζήτηση μελών';
$txt['mlist_search_again'] = 'Αναζήτηση ξανά'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Αναζήτηση ανά διεύθυνση e-mail';
$txt['mlist_search_group'] = 'Αναζήτηση ανά θέση';
$txt['mlist_search_name'] = 'Αναζήτηση κανά όνομα';
$txt['mlist_search_website'] = 'Αναζήτηση ανά ιστοσελίδα';
$txt['mlist_search_results'] = 'Αναζήτηση αποτελεσμάτων για';
$txt['mlist_search_by'] = 'Αναζήτηση με %1$s';

$txt['attach_downloaded'] = 'Έγινε λήψη %1$dφορές';
$txt['attach_viewed'] = 'Αναγνώστηκε %1$d φορές';

$txt['settings'] = 'Επιλογές';
$txt['never'] = 'Ποτέ';
$txt['more'] = 'περισσότερα';

$txt['hostname'] = 'Όνομα κεντρικού υπολογιστή';
$txt['you_are_post_banned'] = 'Λυπούμαστε %1$s, αλλά σας έχει απαγορευθεί η αποστολή δημοσίων και προσωπικών μηνυμάτων σε αυτό το φόρουμ.';
$txt['ban_reason'] = 'Αιτιολογία';

$txt['add_poll'] = 'Προσθήκη ψηφοφορίας';
$txt['poll_options6'] = 'Μπορείτε να ενεργοποιήσετε μέχρι %1$s επιλογές.';
$txt['poll_remove'] = 'Διαγραφή ψηφοφορίας';
$txt['poll_remove_warn'] = 'Θέλετε σίγουρα να διαγράψετε αυτήν την ψηφοφορία από το θέμα;';
$txt['poll_results_expire'] = 'Τα αποτελέσματα θα εμφανιστούν όταν κλείσει η ψηφοφορία';
$txt['poll_expires_on'] = 'Η ψηφοφορία λήγει';
$txt['poll_expired_on'] = 'Η ψηφοφορία έληξε';
$txt['poll_change_vote'] = 'Αφαίρεση ψήφου';
$txt['poll_return_vote'] = 'Επιλογές ψηφοφορίας';
$txt['poll_cannot_see'] = 'Δεν μπορείτε να δείτε τα αποτελέσματα αυτής της ψηφοφορίας αυτή τη στιγμή.';

$txt['quick_mod_approve'] = 'Έγκριση επιλεγμένων';
$txt['quick_mod_remove'] = 'Διαγραφή επιλεγμένων';
$txt['quick_mod_lock'] = '(Ξε)Κλείδωμα επιλεγμένων';
$txt['quick_mod_sticky'] = 'Καρφίτσωμα/Καρφίτσωμα επιλεγμένων ';
$txt['quick_mod_move'] = 'Μετακίνηση επιλεγμένων σε';
$txt['quick_mod_merge'] = 'Συγχώνευση επιλεγμένων';
$txt['quick_mod_markread'] = 'Σήμανση επιλεγμένων ως αναγνωσμένα';
$txt['quick_mod_go'] = 'Ψάξε';
$txt['quickmod_confirm'] = 'Είστε βέβαιος ότι θέλετε να το κάνετε αυτό;';

$txt['spell_check'] = 'Ορθογραφικός έλεγχος';

$txt['quick_reply'] = 'Γρήγορη απάντηση';
$txt['quick_reply_warning'] = 'Προειδοποίηση! Αυτό το θέμα είναι κλειδωμένο, μόνο οι διαχειριστές και οι συντονιστές μπορούν να απαντήσουν.';
$txt['quick_reply_verification'] = 'Μετά από την αποστολή του μηνύματός σας θα ανακατευθυνθείτε στην κοινή φόρμα αποστολής για να επαληθεύσετε το μήνυμά σας %1$s.';
$txt['quick_reply_verification_guests'] = '(απαιτούμενο για όλους τους επισκέπτες)';
$txt['quick_reply_verification_posts'] = '(απαιτούμενο για όλους τους χρήστες με λιγότερα από %1$d μηνύματα)';
$txt['wait_for_approval'] = 'Σημείωση: αυτό το μήνυμα δεν θα εμφανιστεί μέχρι να εγκριθεί από κάποιον συντονιστή.';

$txt['notification_enable_board'] = 'Είστε βέβαιος ότι θέλετε να ενεργοποιήσετε τις ειδοποιήσεις νέων θεμάτων για αυτόν τον πίνακα;';
$txt['notification_disable_board'] = 'Είστε βέβαιος ότι θέλετε να απενεργοποιήσετε τις ειδοποιήσεις νέων θεμάτων για αυτόν τον πίνακα;';
$txt['notification_enable_topic'] = 'Είστε βέβαιος ότι θέλετε να ενεργοποιήσετε τις ειδοποιήσεις νέων απαντήσεων για αυτό το θέμα;';
$txt['notification_disable_topic'] = 'Είστε βέβαιος ότι θέλετε να απενεργοποιήσετε τις ειδοποιήσεις νέων απαντήσεων για αυτό το θέμα;';

$txt['report_to_mod'] = 'Αναφορά δημοσίευσης';
$txt['issue_warning_post'] = 'Απευθύνετε προειδοποίηση με αφορμή αυτό το μήνυμα';

$txt['like_post'] = 'Like';
$txt['unlike_post'] = 'Like';
$txt['likes'] = 'Likes';
$txt['liked_by'] = 'Αρέσει σε:';
$txt['liked_you'] = 'Εσένα';
$txt['liked_more'] = 'περισσότερα';
$txt['likemsg_are_you_sure'] = 'Έχετε ήδη κάνει like στην δημοσίευση, σίγουρα θέλετε να αφαιρέσετε το like?';

$txt['unread_topics_visit'] = 'Πρόσφατα μη αναγνωσμένα θέματα';
$txt['unread_topics_visit_none'] = 'Δεν βρέθηκαν μη αναγνωσμένα θέματα από την τελευταία σας επίσκεψη.<a href="{unread_all_url}" class="linkbutton">Κάντε κλικ εδώ για να δοκιμάσετε όλα τα μη αναγνωσμένα θέματα</a>';
$txt['unread_topics_all'] = 'Όλα τα μη αναγνωσμένα θέματα';
$txt['unread_replies'] = 'Ενημερωμένα θέματα';

$txt['who_title'] = 'Ποιοι είναι συνδεδεμένοι';
$txt['who_and'] = ' και ';
$txt['who_viewing_topic'] = ' διαβάζουν αυτό το θέμα.';
$txt['who_viewing_board'] = ' διαβάζουν αυτόν τον πίνακα.';
$txt['who_member'] = 'Μέλος';

// Current footer strings
$txt['valid_html'] = 'Εγκυροποίηση HTML 5';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'Επισκέπτης';
$txt['guests'] = 'Επισκέπτες';
$txt['user'] = 'χρήστης';
$txt['users'] = 'χρήστες';
$txt['hidden'] = 'κρυφοί';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'κρυφοί';
$txt['buddy'] = 'φίλος';
$txt['buddies'] = 'φίλοι';
$txt['most_online_ever'] = 'Περισσότεροι συνδεδεμένοι έως τώρα';
$txt['most_online_today'] = 'Περισσότεροι συνδεδεμένοι σήμερα';

$txt['merge_select_target_board'] = 'Επιλέξτε τον τελικό πίνακα του συγχωνευμένου θέματος';
$txt['merge_select_poll'] = 'Επιλέξτε ποια ψηφοφορία θα έχει το συγχωνευμένο θέμα';
$txt['merge_topic_list'] = 'Επιλέξτε θέματα που θα συγχωνευτούν';
$txt['merge_select_subject'] = 'Επιλέξτε τίτλο του συγχωνευμένου θέματος';
$txt['merge_custom_subject'] = 'Νέος τίτλος';
$txt['merge_enforce_subject'] = 'Αλλαγή τίτλου όλων των μηνυμάτων;';
$txt['merge_include_notifications'] = 'Να συμπεριληφθούν οι ειδοποιήσεις;';
$txt['merge_check'] = 'Συγχώνευση;';
$txt['merge_no_poll'] = 'Χωρίς ψηφοφορία';

$txt['response_prefix'] = 'Απ: ';
$txt['current_icon'] = 'Τρέχον εικονίδιο';
$txt['message_icon'] = 'Εικονίδιο';

$txt['smileys_current'] = 'Σετ από φατσούλες';
$txt['smileys_none'] = 'Χωρίς φατσούλες';
$txt['smileys_forum_board_default'] = 'Προεπιλογή Φόρουμ/Πίνακα';

$txt['search_results'] = 'Αποτελέσματα αναζήτησης';
$txt['search_no_results'] = 'Δυστυχώς δεν βρέθηκε τίποτα';

$txt['totalTimeLogged2'] = ' ημέρες, ';
$txt['totalTimeLogged3'] = ' ώρες και ';
$txt['totalTimeLogged4'] = ' λεπτά.';
$txt['totalTimeLogged5'] = 'ημ. ';
$txt['totalTimeLogged6'] = 'ωρ. ';
$txt['totalTimeLogged7'] = 'λεπ.';

$txt['approve_thereis'] = 'Υπάρχει'; //Deprecated
$txt['approve_thereare'] = 'Υπάρχουν'; //Deprecated
$txt['approve_member'] = 'ένα μέλος'; //Deprecated
$txt['approve_members'] = 'μέλη'; //Deprecated
$txt['approve_members_waiting'] = 'που περιμένουν έγκριση.'; //Deprecated
$txt['approve_one_member_waiting'] = 'Υπάρχει <a href="%1$s">ένα μέλος</a>που περιμένει έγκριση.';
$txt['approve_many_members_waiting'] = 'Υπάρχουν <a href="%1$s">%2$dμέλη</a>που περιμένουν έγκριση.';

$txt['notifyboard_turnon'] = 'Θέλετε ειδοποίηση με e-mail όταν κάποιος δημοσιεύει ένα νέο θέμα σε αυτόν τον πίνακα;';
$txt['notifyboard_turnoff'] = 'Θέλετε σίγουρα να μη λαμβάνετε ειδοποιήσεις νέων θεμάτων για αυτόν τον πίνακα;';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Αναζήτηση μελών';
$txt['find_username'] = 'Όνομα, όνομα χρήστη ή διεύθυνση e-mail';
$txt['find_buddies'] = 'Προβολή φίλων μόνο;';
$txt['find_wildcards'] = 'Επιτρεπόμενοι χαρακτήρες μπαλαντέρ: *, ?';
$txt['find_no_results'] = 'Δε βρέθηκαν αποτελέσματα';
$txt['find_results'] = 'Αποτελέσματα';
$txt['find_close'] = 'Κλείσιμο';

$txt['quickmod_delete_selected'] = 'Διαγραφή επιλεγμένων';
$txt['quickmod_split_selected'] = 'Διαχωρισμός επιλεγμένων';

$txt['show_personal_messages_heading'] = 'Νέα μηνύματα';
$txt['show_personal_messages'] = 'Έχετε <strong>%1$s</strong> προσωπικά μηνύματα μη αναγνωσμένα .<br /><br /><a href="%2$s">Πηγαίνετε στα εισερχόμενα</a>  ';

$txt['help_popup'] = 'Λίγο μπερδεμένος? Άσε με να σου εξηγήσω:';

$txt['previous_next_back'] = 'προηγούμενο θέμα';
$txt['previous_next_forward'] = 'επόμενο θέμα';

$txt['upshrink_description'] = 'Σύμπτυξη ή ανάπτυξη της επικεφαλίδας.';

$txt['mark_unread'] = 'Σήμανση ως αναγνωσμένο';

$txt['ssi_not_direct'] = 'Μην καλείτε απευθείας το SSI.php. Ίσως θα θέλατε να χρησιμοποιήσετε τη διαδρομή (%1$s) ή να προσθέσετε ?ssi_function=something.';
$txt['ssi_session_broken'] = ' Το SSI.php δεν μπόρεσε να φορτώσει μια περίοδο λειτουργίας (session)! Κάτι τέτοιο μπορεί να προκαλέσει προβλήματα στην αποσύνδεση και σε άλλες λειτουργίες - παρακαλώ βεβαιωθείτε ότι το SSI.php συμπεριλαμβάνεται πριν *οτιδήποτε* άλλο στα αρχεία σας!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Προεπισκόπηση μηνύματος';
$txt['preview_fetch'] = 'Δημιουργία προεπισκόπησης...';
$txt['pm_error_while_submitting'] = 'Παρουσιάστηκε το ακόλουθο σφάλμα ή λάθη κατά την αποστολή αυτού του προσωπικού μηνύματος:';
$txt['warning_while_submitting'] = 'Κάτι συνέβη, αναθεωρήστε το εδώ:';
$txt['error_while_submitting'] = 'Το μήνυμα έχει το ακόλουθο σφάλμα ή σφάλματα που πρέπει να διορθωθούν πριν συνεχίσετε:';
$txt['error_old_topic'] = 'Προσοχή: αυτό το θέμα δεν έχει λάβει απαντήσεις για τουλάχιστον %1$d ημέρες.<br />Αν δεν είστε σίγουροι ότι θέλετε να απαντήσετε, παρακαλούμε σκεφτείτε την περίπτωση να ξεκινήσετε ένα νέο θέμα.';

$txt['split_selected_posts'] = 'Επιλεγμένα μηνύματα';
$txt['split_selected_posts_desc'] = 'Τα παρακάτω μηνύματα θα δημιουργήσουν ένα νέο θέμα μετά τον διαχωρισμό.';
$txt['split_reset_selection'] = 'ακύρωση επιλογής';

$txt['modify_cancel'] = 'Άκυρο';
$txt['mark_read_short'] = 'Σήμανση ως αναγνωσμένο';

$txt['hello_member_ndt'] = 'Γεια χαρά';

$txt['unapproved_posts'] = 'Μη εγκεκριμένα μηνύματα (Θέματα: %1$d, Μηνύματα: %2$d)';

$txt['ajax_in_progress'] = 'Φόρτωση...';
$txt['ajax_bad_response'] = 'Μη έγκυρη απάντηση.';

$txt['mod_reports_waiting'] = 'Υπάρχουν %1$d ανοικτές αναφορές συντονιστών.';
$txt['pm_reports_waiting'] = 'Επί του παρόντος υπάρχουν%1$dπροσωπικά μηνύματα με ανοικτή αναφορά καταγγελίας.';

$txt['new_posts_in_category'] = 'Κάντε κλικ για να δείτε τις νέες δημοσιεύσεις σε %1$s';
$txt['verification'] = 'Επαλήθευση';
$txt['visual_verification_hidden'] = 'Παρακαλώ αφήστε αυτό το πλαίσιο κενό';
$txt['visual_verification_description'] = 'Γράψτε τα γράμματα που εμφανίζονται στην εικόνα';
$txt['visual_verification_sound'] = 'Ακούστε τα γράμματα';
$txt['visual_verification_request_new'] = 'Ζητήστε άλλη εικόνα';

// @todo Send email strings - should move?
$txt['send_email'] = 'Αποστολή email';
$txt['send_email_disclosed'] = 'Σημείωση: αυτό θα είναι εμφανές στον παραλήπτη.';
$txt['send_email_subject'] = 'Τίτλος email';

$txt['ignoring_user'] = 'Αγνοείτε αυτόν τον χρήστη.';
$txt['show_ignore_user_post'] = '<em>[Δείξε μου την δημοσίευση.]</em>';

$txt['spider'] = 'Αράχνη';
$txt['spiders'] = 'Αράχνες';
$txt['openid'] = 'OpenID';

$txt['downloads'] = 'Downloads';
$txt['filesize'] = 'Μέγεθος αρχείου';
$txt['subscribe_webslice'] = 'Γίνετε συνδρομητής στο Webslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Επαναφορά θέματος';
$txt['restore_message'] = 'Επαναφορά';
$txt['quick_mod_restore'] = 'Επαναφορά επιλεγμένων';

// Editor prompt.
$txt['prompt_text_email'] = 'Εισαγάγετε τη διεύθυνση email.';
$txt['prompt_text_ftp'] = 'Παρακαλώ εισάγετε την διεύθυνση του FTP';
$txt['prompt_text_url'] = 'Εισαγάγετε τη διεύθυνση URL.';
$txt['prompt_text_img'] = 'Εισαγάγετε την τοποθεσία της εικόνας';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Διαγραφή αντικειμένου';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Μη αποδεκτή συμπεριφορά</a>έχει αποκλειστεί%1$sπροσπάθειες πρόσβασης τις τελευταίες 7 ημέρες.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Πρότυπα:';
$txt['debug_subtemplates'] = 'Υπο-πρότυπα:'; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Υπο-πρότυπα:';
$txt['debug_language_files'] = 'Αρχεία γλώσσας:';
$txt['debug_sheets'] = 'Φύλλα στυλ:';
$txt['debug_javascript'] = 'Σενάρια:';
$txt['debug_files_included'] = 'Συμπεριλαμβανόμενα αρχεία:';
$txt['debug_kb'] = 'KB.';
$txt['debug_show'] = 'εμφάνιση';
$txt['debug_cache_hits'] = 'Cache hits:';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s bytes ';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss για %2$s bytes ';
$txt['debug_queries_used'] = 'Επερωτήματα που χρησιμοποιήθηκαν: %1$d. ';
$txt['debug_queries_used_and_warnings'] = 'Επερωτήματα που χρησιμοποιήθηκαν: %1$d, %2$d προειδοποιήσεις. ';
$txt['debug_query_in_line'] = 'στο <em>%1$s</em> γραμμή <em>%2$s</em>,';
$txt['debug_query_which_took'] = 'που διήρκησαν %1$s δευτερόλεπτα.';
$txt['debug_query_which_took_at'] = 'το οποίο διήρκησε %1$s δευτερόλεπτα at %2$s into request.';
$txt['debug_show_queries'] = '[Εμφάνιση επερωτημάτων]';
$txt['debug_hide_queries'] = '[Απόκρυψη επερωτημάτων]';
$txt['debug_tokens'] = 'Σημεία:';
$txt['debug_browser'] = 'ID περιηγητή: ';
$txt['debug_hooks'] = 'Κάλεσμα Hooks:';
$txt['debug_system_type'] = 'Σύστημα:';
$txt['debug_server_load'] = 'Φόρτωση διακομιστή:';
$txt['debug_script_mem_load'] = 'Σενάριο Χρήσης Μνήμης:';
$txt['debug_script_cpu_load'] = 'Σενάριο χρόνου CPU (χρήστη/σύστημα) :';

// Video embedding
$txt['preview_image'] = 'Προ επισκόπηση Εικόνας Βίντεο ';
$txt['ctp_video'] = 'Κλικ για αναπαραγωγή βίντεο, διπλό κλικ για φόρτωση βίντεο';
$txt['hide_video'] = 'Απόκρυψη/Εμφάνιση Βίντεο';
$txt['youtube'] = 'Βίντεο YouTube';
$txt['vimeo'] = 'Βίντεο Vimeo';
$txt['dailymotion'] = 'Βίντεο Dailymotion';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (κλίκ για εμφάνιση/απόκρυψη)';

$txt['ok_uppercase'] = 'OK';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Προειδοποίηση';

$txt['via'] = 'μέσω';

$txt['like_post_stats'] = 'Στατιστικά Like';

$txt['otp_token'] = 'Απαιτείται κωδικός πρόσβασης μίας χρήσης';
$txt['otp_enabled'] = 'Ενεργοποίηση έλεγχου ταυτότητας δύο παραγόντων';
$txt['invalid_otptoken'] = 'Λανθασμένος κωδικός πρόσβασης μίας χρήσης';
$txt['otp_used'] = 'Ο κωδικός πρόσβασης μίας χρήσης ήδη χρησιμοποιείται.<br />Παρακαλώ περιμένετε και χρησιμοποιήστε τον επόμενο κωδικό. ';
$txt['otp_generate'] = 'Παραγωγή';
$txt['otp_show_qr'] = 'Εμφάνιση κωδικού QR';
