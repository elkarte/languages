<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'ElkArte User Help';

$txt['manual_welcome'] = 'Welcome to %s, powered by ElkArte Forum software!';
$txt['manual_introduction'] = 'ElkArte is the elegant, effective, powerful and free forum software solution that this site is running. It allows users to communicate in discussion topics on a given subject in a clever and organized manner. Furthermore, it has a number of powerful features which end users can take advantage of. Help for many of ElkArte\'s features can be found by either clicking the question mark icon next to the relevant section or by selecting one of the links on this page. These links will take you to ElkArte\'s centrally-located documentation on the ElkArte official site.';
$txt['manual_docs_and_credits'] = 'For more information about how to use ElkArte, please see the <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> and check out the <a href="%2$s">credits</a> to find out who has made ElkArte what it is today.';

$txt['manual_section_registering_title'] = 'Εγγραφή';
$txt['manual_section_logging_in_title'] = 'Σύνδεση';
$txt['manual_section_profile_title'] = 'Προφίλ';
$txt['manual_section_search_title'] = 'Αναζήτηση';
$txt['manual_section_posting_title'] = 'Δημοσίευση';
$txt['manual_section_bbc_title'] = 'Κώδικας BBC (Bulletin Board Code)';
$txt['manual_section_personal_messages_title'] = 'Προσωπικά μηνύματα';
$txt['manual_section_memberlist_title'] = 'Λίστα μελών';
$txt['manual_section_calendar_title'] = 'Ημερολόγιο';
$txt['manual_section_features_title'] = 'Χαρακτηριστικά';

$txt['manual_section_registering_desc'] = 'Πολλά φόρουμ απαιτούν από τους χρήστες να εγγραφούν για να αποκτήσουν πλήρη πρόσβαση.';
$txt['manual_section_logging_in_desc'] = 'Μετά την εγγραφή, οι χρήστες πρέπει να συνδεθούν για να έχουν πρόσβαση στο λογαριασμό τους.';
$txt['manual_section_profile_desc'] = 'Κάθε μέλος έχει το δικό του προσωπικό προφίλ.';
$txt['manual_section_search_desc'] = 'Η Αναζήτηση είναι ένα εξαιρετικά χρήσιμο εργαλείο για την εύρεση πληροφοριών σε μηνύματα και συζητήσεις.';
$txt['manual_section_posting_desc'] = 'Το νόημα ύπαρξης ενός φόρουμ, η δημοσίευση μηνυμάτων επιτρέπει στους χρήστες να εκφραστούν.';
$txt['manual_section_bbc_desc'] = 'Τα μηνύματα μπορεί να είναι πιο ευπαρουσίαστα με λίγο BBC.';
$txt['manual_section_personal_messages_desc'] = 'Οι χρήστες μπορούν να στέλνουν προσωπικά μηνύματα ο ένας στον άλλο.';
$txt['manual_section_memberlist_desc'] = 'Η Λίστα Μελών εμφανίζει όλα τα μέλη του φόρουμ. ';
$txt['manual_section_calendar_desc'] = 'Οι χρήστες μπορούν να ενημερώνονται για τις εκδηλώσεις, τις εορτές και τα γενέθλια, στο ημερολόγιο';
$txt['manual_section_features_desc'] = 'Here is a list of the most popular features in ElkArte.';