<?php
// Version: 1.1; ManageMembers

$txt['groups'] = 'Ομάδες';
$txt['viewing_groups'] = 'Εμφάνιση ομάδων μελών';

$txt['membergroups_title'] = 'Διαχείριση ομάδων μελών';
$txt['membergroups_description'] = 'Οι ομάδες μελών είναι ομάδες που έχουν όμοιες ρυθμίσεις δικαιωμάτων, εμφάνιση, ή δικαιώματα πρόσβασης. Μερικές ομάδες μελών βασίζονται στο πλήθος των μηνυμάτων που έχει στείλει ένα Μέλος. Μπορείτε να εντάξετε κάποιον σε μια ομάδα μελών, επιλέγοντας το Προφίλ του και αλλάζοντας τις Ρυθμίσεις του Λογαριασμού του.';
$txt['membergroups_modify'] = 'Τροποποίηση';
$txt['membergroups_modify_parent'] = 'Modify parent group';

$txt['membergroups_add_group'] = 'Προσθήκη ομάδας';
$txt['membergroups_regular'] = 'Κανονικές ομάδες';
$txt['membergroups_post'] = 'Ομάδες βασισμένες στον αριθμό μηνυμάτων';
$txt['membergroups_guests_na'] = 'μη διαθέσιμο';

$txt['membergroups_group_name'] = 'Όνομα ομάδας';
$txt['membergroups_new_board'] = 'Ορατοί πίνακες';
$txt['membergroups_new_board_desc'] = 'Πίνακες που μπορεί να δει η ομάδα';
$txt['membergroups_new_board_post_groups'] = '<em>Σημείωση: Κανονικά, οι ομάδες με βάση το αριθμό μηνυμάτων δεν χρειάζονται πρόσβαση γιατί θα τους την δώσει η ομάδα μελών στην οποία ανήκουν.</em>';
$txt['membergroups_new_as_inherit'] = 'κληρονόμηση από';
$txt['membergroups_new_as_type'] = 'με είδος';
$txt['membergroups_new_as_copy'] = 'ή βασιζόμενη στη';
$txt['membergroups_new_copy_none'] = '(καμία)';
$txt['membergroups_can_edit_later'] = '(Μπορείτε να τα τροποποιήσετε αργότερα.)';

$txt['membergroups_edit_group'] = 'Τροποποίηση ομάδας μελών';
$txt['membergroups_edit_name'] = 'Όνομα ομάδας μελών';
$txt['membergroups_edit_inherit_permissions'] = 'Κληρονόμηση δικαιωμάτων';
$txt['membergroups_edit_inherit_permissions_desc'] = 'Επιλέξτε &quot;Όχι&quot; για να έχει η κάθε ομάδα τις δικές της ρυθμίσεις δικαιωμάτων.';
$txt['membergroups_edit_inherit_permissions_no'] = 'Όχι - Χρήση ανεξάρτητων δικαιωμάτων';
$txt['membergroups_edit_inherit_permissions_from'] = 'Κληρονόμηση από';
$txt['membergroups_edit_hidden'] = 'Ορατότητα';
$txt['membergroups_edit_hidden_no'] = 'Ορατό';
$txt['membergroups_edit_hidden_boardindex'] = 'Visible - Apart from in group key';
$txt['membergroups_edit_hidden_all'] = 'Αόρατο';
// Do not use numeric entities in the below string.
$txt['membergroups_edit_hidden_warning'] = 'Σίγουρα θέλετε να απαγορεύσετε την εκχώρηση αυτής της ομάδας ως κύριας ομάδας χρηστών;\\n\\nΑν το κάνετε θα περιοριστεί η εκχώρηση μόνο σε πρόσθετες ομάδες και θα ενημερωθούν όλα τα &quot;κύρια&quot; μέλη έτσι ώστε να την έχουν μόνο ως πρόσθετη ομάδα.';
$txt['membergroups_edit_desc'] = 'Περιγραφή ομάδας';
$txt['membergroups_edit_group_type'] = 'Group type';
$txt['membergroups_edit_select_group_type'] = 'Select Group type';
$txt['membergroups_group_type_private'] = 'Ιδιωτική <span class="smalltext">(Η ένταξη στην ομάδα πρέπει να προσδιοριστεί)</span>';
$txt['membergroups_group_type_protected'] = 'Προστατευμένο  <span class="smalltext">(Μόνο διαχειριστές μπορούν να διαχειριστούν και να εκχωρήσουν)</span>';
$txt['membergroups_group_type_request'] = 'Κατόπιν αίτησης <span class="smalltext">(Ο χρήστης μπορεί να αιτηθεί την ένταξη στην ομάδα)</span>';
$txt['membergroups_group_type_free'] = 'Ελεύθερη <span class="smalltext">(Ο χρήστης μπορεί να ενταχθεί ή να απενταχθεί από την ομάδα κατά βούληση)</span>';
$txt['membergroups_group_type_post'] = 'Βάσει μηνυμάτων <span class="smalltext">(Η ομάδα μελών βασίζεται στο πλήθος μηνυμάτων)</span>';
$txt['membergroups_min_posts'] = 'Απαιτούμενα μηνύματα';
$txt['membergroups_online_color'] = 'Χρώμα στη λίστα των συνδεδεμένων χρηστών';
$txt['membergroups_icon_count'] = 'Number of icon images';
$txt['membergroups_icon_image'] = 'Icon image filename';
$txt['membergroups_icon_image_note'] = 'Upload icon images in to the default theme directory to enable selection.<br />Select the icon to change it.';
$txt['membergroups_max_messages'] = 'Μέγιστο πλήθος προσωπικών μηνυμάτων';
$txt['membergroups_max_messages_note'] = '0 = απεριόριστα';
$txt['membergroups_max_messages_desc'] = 'Here you can set the limit of personal messages a user can keep on the server.<br />
To allow store an unlimited number of personal messages, you can set the value to 0';
$txt['membergroups_edit_save'] = 'Αποθήκευση';
$txt['membergroups_delete'] = 'Διαγραφή';
$txt['membergroups_confirm_delete'] = 'Are you sure you want to delete this group?';

$txt['membergroups_members_title'] = 'Εμφάνιση όλων των μελών από την ομάδα';
$txt['membergroups_members_group_members'] = 'Μέλη ομάδας';
$txt['membergroups_members_no_members'] = 'Αυτή η ομάδα είναι άδεια προς το παρόν';
$txt['membergroups_members_add_title'] = 'Προσθήκη μέλους σε αυτή την ομάδα';
$txt['membergroups_members_add_desc'] = 'Λίστα μελών για προσθήκη';
$txt['membergroups_members_add'] = 'Προσθήκη μελών';
$txt['membergroups_members_remove'] = 'Διαγραφή από την ομάδα';
$txt['membergroups_members_last_active'] = 'Τελευταίο ενεργό';
$txt['membergroups_members_additional_only'] = 'Προσθήκη ως πρόσθετη ομάδα μόνο.';
$txt['membergroups_members_group_moderators'] = 'Συντονιστές ομάδας';
$txt['membergroups_members_description'] = 'Περιγραφή';
// Use javascript escaping in the below.
$txt['membergroups_members_deadmin_confirm'] = 'Είστε σίγουρος ότι θέλετε να αφαιρέσετε τον εαυτό σας από την ομάδα διαχειριστών;';

$txt['membergroups_postgroups'] = 'Ομάδες πλήθους μηνυμάτων';
$txt['membergroups_settings'] = 'Ρυθμίσεις ομάδων μελών';
$txt['groups_manage_membergroups'] = 'Ομάδες που επιτρέπεται να αλλάζουν ομάδες μελών';
$txt['membergroups_select_permission_type'] = 'Επιλογή προφίλ δικαιωμάτων';
$txt['membergroups_images_url'] = '{theme URL}/images/group_icons/';
$txt['membergroups_select_visible_boards'] = 'Προβολή πινάκων';
$txt['membergroups_members_top'] = 'Μέλη';
$txt['membergroups_name'] = 'Όνομα';
$txt['membergroups_icons'] = 'Icons';

$txt['admin_browse_approve'] = 'Μέλη των οποίων οι λογαριασμοί περιμένουν έγκριση';
$txt['admin_browse_approve_desc'] = 'Εδώ μπορείτε να διαχειριστείτε όλα τα μέλη που περιμένουν να εγκριθούν οι λογαριασμοί τους.';
$txt['admin_browse_activate'] = 'Μέλη των οποίων οι λογαριασμοί περιμένουν ενεργοποίηση';
$txt['admin_browse_activate_desc'] = 'Αυτή η οθόνη εμφανίζει όλα τα μέλη που δεν έχουν ενεργοποιήσει ακόμα τους λογαριασμούς τους στο φόρουμ.';
$txt['admin_browse_awaiting_approval'] = 'Awaiting Approval [%1$d]';
$txt['admin_browse_awaiting_activate'] = 'Awaiting Activation [%1$d]';

$txt['admin_browse_username'] = 'Όνομα χρήστη';
$txt['admin_browse_email'] = 'Διεύθυνση e-mail';
$txt['admin_browse_ip'] = 'Διεύθυνση IP';
$txt['admin_browse_registered'] = 'Εγγεγραμμένα';
$txt['admin_browse_id'] = 'Αναγνωριστικό (ID)';
$txt['admin_browse_with_selected'] = 'με τα επιλεγμένα';
$txt['admin_browse_no_members_approval'] = 'Δεν υπάρχουν μέλη που περιμένουν έγκριση.';
$txt['admin_browse_no_members_activate'] = 'Δεν υπάρχουν μέλη που περιμένουν ενεργοποίηση των λογαριασμών τους.';

// Don't use entities in the below strings, except the main ones. (lt, gt, quot.)
$txt['admin_browse_warn'] = 'όλα τα επιλεγμένα μέλη;';
$txt['admin_browse_outstanding_warn'] = 'όλα τα επηρεαζόμενα μέλη;';
$txt['admin_browse_w_approve'] = 'Έγκριση';
$txt['admin_browse_w_activate'] = 'Ενεργοποίηση';
$txt['admin_browse_w_delete'] = 'Διαγραφή';
$txt['admin_browse_w_reject'] = 'Reject (Delete)';
$txt['admin_browse_w_remind'] = 'Υπενθύμιση';
$txt['admin_browse_w_approve_deletion'] = 'Έγκριση (Διαγραφή λογαριασμών)';
$txt['admin_browse_w_email'] = 'και αποστολή email';
$txt['admin_browse_w_approve_require_activate'] = 'Approve and require activation';

$txt['admin_browse_filter_by'] = 'Φίλτρο με βάση';
$txt['admin_browse_filter_show'] = 'Εμφάνιση';
$txt['admin_browse_filter_type_0'] = 'Unactivated new accounts';
$txt['admin_browse_filter_type_2'] = 'Unactivated email changes';
$txt['admin_browse_filter_type_3'] = 'Unapproved new accounts';
$txt['admin_browse_filter_type_4'] = 'Unapproved account deletions';
$txt['admin_browse_filter_type_5'] = 'Λογαριασμοί "με όριο ηλικίας" χωρίς έγκριση';

$txt['admin_browse_outstanding'] = 'Διακεκριμένα μέλη';
$txt['admin_browse_outstanding_days_1'] = 'Με όλα τα μέλη που εγγράφηκαν πριν από';
$txt['admin_browse_outstanding_days_2'] = 'ημέρες';
$txt['admin_browse_outstanding_perform'] = 'Εκτέλεση της ακόλουθης ενέργειας';
$txt['admin_browse_outstanding_go'] = 'Εκτέλεση ενέργειας';

$txt['check_for_duplicate'] = 'Check for duplicates';
$txt['dont_check_for_duplicate'] = 'Don\'t check for duplicates';
$txt['duplicates'] = 'Αντίγραφα';

$txt['not_activated'] = 'Ανενεργό';