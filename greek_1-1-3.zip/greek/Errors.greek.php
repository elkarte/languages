<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Συγγνώμη, δεν σας επιτρέπουμε την είσοδο σε αυτή την ενότητα. Δεν μπορούμε να σας πούμε αν υπάρχει. Μπορείτε να επισκεφτείτε την κύρια σελίδα και να διαλέξετε από εκεί.';
$txt['not_guests'] = 'Συγγνώμη, αυτή η ενέργεια δεν επιτρέπετε σε επισκέπτες.';

$txt['mods_only'] = 'Μόνο οι συντονιστές μπορούν να χρησιμοποιήσουν τη λειτουργία άμεσης αφαίρεσης, καταργήστε αυτό το μήνυμα μέσω της δυνατότητας τροποποίησης.';
$txt['no_name'] = 'Δεν συμπληρώσατε το πεδίο ονόματος. Δεν μπορούμε να σας αφήσουμε να συνεχίσετε χωρίς όνομα, συγγνώμη.';
$txt['no_email'] = 'Δεν συμπληρώσατε το πεδίο ηλεκτρονικού ταχυδρομείου. Δεν μπορούμε να σας αφήσουμε να συνεχίσετε χωρίς ένα μήνυμα ηλεκτρονικού ταχυδρομείου, συγγνώμη.';
$txt['topic_locked'] = 'Αυτό το θέμα είναι κλειδωμένο. Δεν επιτρέπεται δημοσίευση ή τροποποίηση μηνυμάτων...';
$txt['no_password'] = 'Το πεδίο του κωδικού είναι κενό';
$txt['passwords_dont_match'] = 'Οι κωδικοί δεν είναι ίδιοι.';
$txt['register_to_use'] = 'Πρέπει να εγγραφείτε για να χρησιμοποιήσετε αυτήν την λειτουργία.';
$txt['username_reserved'] = 'The user name you tried to use contains the reserved name \'%1$s\'. Please try another user name.';
$txt['numbers_one_to_nine'] = 'Αυτό το πεδίο δέχεται μόνο αριθμούς από 0 έως 9';
$txt['not_a_user'] = 'Ο χρήστης του οποίου το προφίλ θέλετε να δείτε, δεν υπάρχει.';
$txt['not_a_topic'] = 'Αυτό το θέμα δεν υπάρχει στον πίνακα.';
$txt['not_approved_topic'] = 'Αυτό το θέμα δεν έχει εγκριθεί ακόμη.';
$txt['email_in_use'] = 'Αυτή η διεύθυνση email(%1$s) χρησιμοποιείται ήδη από κάποιο εγγεγραμμένο μέλος. Αν πιστεύετε ότι αυτό είναι λάθος, πηγαίνετε στη σελίδα σύνδεσης και χρησιμοποιήστε την υπενθύμιση κωδικού με αυτή τη διεύθυνση.';

$txt['didnt_select_vote'] = 'Δεν επιλέξατε επιλογή ψήφου.';
$txt['poll_error'] = 'Something isn\'t working, sorry: either that poll doesn\'t exist, the poll has been locked, or you tried to vote twice.';
$txt['locked_by_admin'] = 'Κλειδωμένο από διαχειριστή.  Δεν μπορείτε να το ξεκλειδώσετε.';
$txt['not_enough_posts_karma'] = 'Λυπούμαστε, δεν έχετε αρκετά μηνύματα για να αλλάξετε το κάρμα - χρειάζεστε τουλάχιστον %1$d.';
$txt['cant_change_own_karma'] = 'Δεν επιτρέπεται να τροποποιήσετε το δικό σας κάρμα.';
$txt['karma_wait_time'] = 'Λυπούμαστε, δεν μπορείτε να επαναλάβετε μια ενέργεια κάρμα πριν περιμένετε %1$s %2$s.';
$txt['feature_disabled'] = 'Αυτή η λειτουργία έχει απενεργοποιηθεί.';
$txt['feature_no_exists'] = 'Λυπούμαστε, αυτή η λειτουργία δεν υπάρχει.';
$txt['couldnt_connect'] = 'Δεν είναι εφικτή η σύνδεση στον διακομιστή ή το αρχείο δεν βρέθηκε.';
$txt['no_board'] = 'O πίνακας που επιλέξατε δεν υπάρχει.';
$txt['no_message'] = 'Το μήνυμα δεν είναι πλέον διαθέσιμο';
$txt['no_topic_id'] = 'Δώσατε μη έγκυρο αναγνωριστικό (ID) θέματος.';
$txt['split_first_post'] = 'Δεν μπορείτε να διαχωρίσετε ένα θέμα στο πρώτο μήνυμα.';
$txt['topic_one_post'] = 'Αυτό το θέμα έχει μόνο ένα μήνυμα και δεν μπορεί να διαχωριστεί.';
$txt['no_posts_selected'] = 'Δεν επιλέχθηκαν μηνύματα';
$txt['selected_all_posts'] = 'Ο διαχωρισμός δεν ήταν εφικτός. Επιλέξατε όλα τα μηνύματα.';
$txt['cant_find_messages'] = 'Δεν ήταν εφικτή η εύρεση μηνυμάτων';
$txt['cant_find_user_email'] = 'Δεν βρέθηκε η διεύθυνση email του χρήστη.';
$txt['cant_insert_topic'] = 'Δεν ήταν εφικτή η εισαγωγή θέματος';
$txt['session_timeout'] = 'Η συνεδρία σας έκλεισε κατά την ανάρτηση. Επιστρέψτε και δοκιμάστε ξανά.';
$txt['session_timeout_file_upload'] = 'Η συνεδρία σας έκλεισε κατά τη μεταφόρτωση του αρχείου.Παρακαλώ προσπάθησε ξανά.';
$txt['no_files_uploaded'] = 'Δεν υπάρχουν αρχεία για μεταφόρτωση.';
$txt['session_verify_fail'] = 'Η επαλήθευση περιόδου σύνδεσης απέτυχε. Δοκιμάστε να αποσυνδεθείτε και στη συνέχεια, δοκιμάστε ξανά.';
$txt['verify_url_fail'] = 'Δεν είναι δυνατή η επαλήθευση της παραπομπής URL:%1$s. Επιστρέψτε και δοκιμάστε ξανά.';
$txt['token_verify_fail'] = 'Token verification failed. Please go back and try again.';
$txt['guest_vote_disabled'] = 'Οι επισκέπτες δεν μπορούν να ψηφίσουν σε αυτή τη ψηφοφορία.';

$txt['cannot_access_mod_center'] = 'Δεν έχετε δικαίωμα να προσπελάσετε το κέντρο συντονισμού.';
$txt['cannot_admin_forum'] = 'Δεν έχετε δικαίωμα διαχείρισης αυτού του φόρουμ.';
$txt['cannot_announce_topic'] = 'Δεν έχετε δικαίωμα να αναγγείλετε θέματα σε αυτόν το πίνακα.';
$txt['cannot_approve_posts'] = 'Δεν έχετε δικαίωμα να εγκρίνετε δημοσιεύσεις.';
$txt['cannot_post_unapproved_attachments'] = 'Δεν έχετε δικαίωμα να δημοσιεύσετε μη εγκεκριμένα συνημμένα.';
$txt['cannot_post_unapproved_topics'] = 'Δεν έχετε δικαίωμα να δημοσιεύσετε μη εγκεκριμένα θέματα.';
$txt['cannot_post_unapproved_replies_own'] = 'Δεν έχετε δικαίωμα να δημοσιεύσετε μη εγκεκριμένες απαντήσεις στα θέματά σας.';
$txt['cannot_post_unapproved_replies_any'] = 'Δεν έχετε δικαίωμα να δημοσιεύσετε μη εγκεκριμένες απαντήσεις σε θέματα άλλων.';
$txt['cannot_calendar_edit_any'] = 'Δεν μπορείτε να τροποποιήσετε εκδηλώσεις ημερολογίου.';
$txt['cannot_calendar_edit_own'] = 'Δεν έχετε αρκετά δικαιώματα για να τροποποιήσετε τις δικές σας εκδηλώσεις.';
$txt['cannot_calendar_post'] = 'Δεν επιτρέπεται η δημοσίευση εκδήλωσης.';
$txt['cannot_calendar_view'] = 'Δεν έχετε δικαίωμα εμφάνισης του ημερολογίου.';
$txt['cannot_remove_any'] = 'Η διαγραφή οποιουδήποτε μηνύματος σε αυτόν τον πίνακα δεν επιτρέπεται.';
$txt['cannot_remove_own'] = 'Σε αυτόν τον πίνακα δεν σας επιτρέπεται να διαγράψετε τις δικές σας δημοσιεύσεις.';
$txt['cannot_edit_news'] = 'Δεν επιτρέπεται να τροποποιήσετε ειδήσεις σε αυτό το φόρουμ.';
$txt['cannot_pm_read'] = 'Δεν μπορείτε να διαβάσετε τα προσωπικά σας μηνύματα.';
$txt['cannot_pm_send'] = 'Δεν μπορείτε να στείλετε προσωπικά μηνύματα.';
$txt['cannot_karma_edit'] = 'Δεν μπορείτε να τροποποιήσετε το κάρμα άλλων μελών.';
$txt['cannot_like_posts'] = 'Δεν επιτρέπονται τα Likes σε αυτό το πίνακα.';
$txt['cannot_lock_any'] = 'Δεν επιτρέπεται να κλειδώσετε οποιοδήποτε θέμα εδώ.';
$txt['cannot_lock_own'] = 'Δεν μπορείτε να κλειδώσετε τα δικά σας θέματα εδώ.';
$txt['cannot_make_sticky'] = 'Δεν έχετε δικαίωμα να καρφιτσώσετε αυτό το θέμα.';
$txt['cannot_manage_attachments'] = 'Δεν σας επιτρέπεται να διαχειριστείτε συνημμένα ή πορτραίτα.';
$txt['cannot_manage_bans'] = 'Δεν σας επιτρέπεται να αλλάξετε τη λίστα των αποκλεισμών.';
$txt['cannot_manage_boards'] = 'Δεν σας επιτρέπεται να διαχειριστείτε πίνακες και κατηγορίες.';
$txt['cannot_manage_membergroups'] = 'Δεν έχετε άδεια να τροποποιήσετε ή να ορίσετε ομάδες μελών.';
$txt['cannot_manage_permissions'] = 'Δεν έχετε δικαίωμα να διαχειριστείτε τα δικαιώματα.';
$txt['cannot_manage_smileys'] = 'Δεν σας επιτρέπεται να διαχειριστείτε τις φατσούλες.';
$txt['cannot_mark_any_notify'] = 'Δεν έχετε αρκετά δικαιώματα για να λαμβάνετε ειδοποιήσεις για αυτό το θέμα.';
$txt['cannot_mark_notify'] = 'Δεν μπορείτε να ζητήσετε ειδοποιήσεις σε αυτόν τον πίνακα.';
$txt['cannot_merge_any'] = 'Δεν έχετε δικαίωμα να συγχωνεύσετε θέματα σε ένα από τους επιλεγμένους πίνακες.';
$txt['cannot_moderate_forum'] = 'Δεν έχετε δικαίωμα συντονισμού αυτού του φόρουμ.';
$txt['cannot_moderate_board'] = 'Δεν σας επιτρέπεται ο συντονισμός του παρόντος πίνακα.';
$txt['cannot_modify_any'] = 'Δεν έχετε δικαίωμα τροποποίησης οποιασδήποτε δημοσίευσης.';
$txt['cannot_modify_own'] = 'Δεν έχετε δικαίωμα τροποποίησης των δικών σας δημοσιεύσεων.';
$txt['cannot_modify_replies'] = 'Αν και αυτό το μήνυμα είναι απάντηση σε δικό σας θέμα, δεν μπορείτε να το τροποποιήσετε.';
$txt['cannot_move_own'] = 'Δεν έχετε δικαίωμα μετακίνησης δικών σας θεμάτων σε αυτόν τον πίνακα.';
$txt['cannot_move_any'] = 'Δεν έχετε δικαίωμα μετακίνησης θεμάτων σε αυτόν τον πίνακα.';
$txt['cannot_poll_add_own'] = 'Δεν έχετε δικαίωμα προσθήκης ψηφοφοριών στα δικά σας θέματα σε αυτόν τον πίνακα.';
$txt['cannot_poll_add_any'] = 'Δεν έχετε δικαίωμα προσθήκης ψηφοφοριών σε αυτό το θέμα.';
$txt['cannot_poll_edit_own'] = 'Δεν μπορείτε να τροποποιήσετε αυτήν την ψηφοφορία, έστω κι αν είναι δικό σας.';
$txt['cannot_poll_edit_any'] = 'Δεν έχετε δικαίωμα τροποποίησης ψηφοφορίας σε αυτόν τον πίνακα.';
$txt['cannot_poll_lock_own'] = 'Δεν έχετε δικαίωμα κλειδώματος των δικών σας ψηφοφοριών σε αυτόν τον πίνακα.';
$txt['cannot_poll_lock_any'] = 'Δεν έχετε δικαίωμα κλειδώματος οποιασδήποτε ψηφοφορίας.';
$txt['cannot_poll_post'] = 'Δεν έχετε δικαίωμα να δημοσιεύσετε ψηφοφορίες σε αυτόν τον πίνακα.';
$txt['cannot_poll_remove_own'] = 'Δεν μπορείτε να καταργήσετε αυτήν την ψηφοφορία από το θέμα σας.';
$txt['cannot_poll_remove_any'] = 'Δεν μπορείτε να αφαιρέσετε οποιανδήποτε ψηφοφορία από αυτόν τον πίνακα.';
$txt['cannot_poll_view'] = 'Δεν έχετε δικαίωμα εμφάνισης των ψηφοφοριών σε αυτόν τον πίνακα.';
$txt['cannot_poll_vote'] = 'Δεν μπορείτε να ψηφίσετε στις ψηφοφορίες σε αυτόν τον πίνακα.';
$txt['cannot_post_attachment'] = 'Δεν έχετε δικαίωμα αποστολής συνημμένων εδώ.';
$txt['cannot_post_new'] = 'Δεν μπορείτε να δημοσιεύσετε νέα θέματα σε αυτόν τον πίνακα.';
$txt['cannot_post_new_board'] = 'Λυπούμαστε, δεν μπορείτε να δημοσιεύσετε νέα θέματα σε αυτόν τον πίνακα %1$s.';
$txt['cannot_post_reply_any'] = 'Δεν μπορείτε να δημοσιεύσετε απαντήσεις σε θέματα αυτού του πίνακα.';
$txt['cannot_post_reply_own'] = 'Δεν μπορείτε να δημοσιεύσετε απαντήσεις ακόμα και στα δικά σας θέματα σε αυτόν τον πίνακα.';
$txt['cannot_profile_remove_own'] = 'Δεν μπορείτε να διαγράψετε τον λογαριασμό σας.';
$txt['cannot_profile_remove_any'] = 'Δεν έχετε τα κατάλληλα δικαιώματα για την κατάργηση λογαριασμών.';
$txt['cannot_profile_extra_any'] = 'Δεν έχετε δικαίωμα τροποποίησης των ρυθμίσεων του προφίλ.';
$txt['cannot_profile_identity_any'] = 'Δεν έχετε δικαίωμα τροποποίησης ρυθμίσεων λογαριασμού.';
$txt['cannot_profile_title_any'] = 'Δεν μπορείτε να τροποποιήσετε τους πρόσθετους τίτλους άλλων μελών.';
$txt['cannot_profile_extra_own'] = 'Δεν έχετε επαρκή δικαιώματα να τροποποιήσετε τα δεδομένα του προφίλ σας.';
$txt['cannot_profile_identity_own'] = 'Δεν μπορείτε να αλλάξετε ταυτότητα την παρούσα στιγμή.';
$txt['cannot_profile_title_own'] = 'Δεν έχετε δικαίωμα αλλαγής του πρόσθετου τίτλου σας.';
$txt['cannot_profile_set_avatar'] = 'Δεν επιτρέπεται να αλλάξετε το avatar σας.';
$txt['cannot_profile_view_own'] = 'Λυπούμαστε αλλά δεν μπορείτε να δείτε το προφίλ σας.';
$txt['cannot_profile_view_any'] = 'Λυπούμαστε αλλά δεν μπορείτε να δείτε οποιοδήποτε προφίλ.';
$txt['cannot_delete_own'] = 'Ouch, sorry, you cannot delete your posts on this board.';
$txt['cannot_delete_replies'] = 'Λυπούμαστε αλλά δεν μπορείτε να διαγράψετε αυτά τα μηνύματα, ακόμα κι αν είναι απαντήσεις στο δικό σας θέμα.';
$txt['cannot_delete_any'] = 'Ouch, sorry, you cannot delete posts in this board.';
$txt['cannot_report_any'] = 'Δεν επιτρέπεται η αναφορά δημοσιεύσεων σε αυτόν τον πίνακα.';
$txt['cannot_search_posts'] = 'Δεν έχετε το δικαίωμα αναζήτησης για δημοσιεύσεις σε αυτό το φόρουμ.';
$txt['cannot_send_mail'] = 'Δεν έχετε δικαίωμα αποστολής e-mail σε όλους.';
$txt['cannot_issue_warning'] = 'Λυπούμαστε, Δεν έχετε δικαίωμα να κάνετε προειδοποιήσεις σε μέλη.';
$txt['cannot_send_topic'] = 'Λυπούμαστε αλλά ο διαχειριστής έχει απαγορέψει την αποστολή θεμάτων σε αυτόν τον πίνακα.';
$txt['cannot_send_email_to_members'] = 'Sorry, but the administrator has disallowed sending emails on this board.';
$txt['cannot_split_any'] = 'Ο διαχωρισμός οποιουδήποτε θέματος δεν επιτρέπεται σε αυτόν τον πίνακα.';
$txt['cannot_view_attachments'] = 'Δεν έχετε δικαίωμα εμφάνισης ή να κάνετε λήψη συνημμένων σε αυτόν τον πίνακα.';
$txt['cannot_view_mlist'] = 'You can\'t view the member list because you don\'t have permission to.';
$txt['cannot_view_stats'] = 'Δεν σας επιτρέπεται η εμφάνιση των στατιστικών του φόρουμ.';
$txt['cannot_who_view'] = 'Δεν έχετε τα κατάλληλα δικαιώματα για να δείτε την λίστα με τους συνδεδεμένους χρήστες.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = ' We can\'t find that theme.';
$txt['theme_dir_wrong'] = 'Ο φάκελος Εμφανίσεων είναι εσφαλμένος, διορθώστε τον πατώντας εδώ.';
$txt['registration_disabled'] = 'Λυπούμαστε αλλά η εγγραφή είναι προς το παρόν απενεργοποιημένη.';
$txt['registration_agreement_missing'] = 'The registration agreement file, agreement.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Δεν υπάρχει τεθεί μυστική ερώτηση για αυτό το μέλος.';
$txt['poll_range_error'] = 'Η ψηφοφορία πρέπει να είναι ενεργή για περισσότερες από 0 ημέρες.';
$txt['delFirstPost'] = 'You are not allowed to delete the first post in a topic.<p>If you want to delete this topic, click on the Remove link, or ask a moderator/administrator to do it for you.</p>';
$txt['login_cookie_error'] = 'Η σύνδεσή σας δεν ήταν εφικτή. Παρακαλούμε ελέγξτε τις ρυθμίσεις σας για τα cookies.';
$txt['incorrect_answer'] = 'Δεν απαντήσατε σωστά στη μυστική σας ερώτησή. Παρακαλούμε πατήστε Πίσω για να ξαναδοκιμάσετε, ή πατήστε Πίσω δύο φορές για να χρησιμοποιήσετε την τυπική μέθοδο ανάκτησης του κωδικού σας.';
$txt['no_mods'] = 'Δεν βρέθηκαν συντονιστές!';
$txt['parent_not_found'] = 'Η δομή του πίνακα είναι κατεστραμμένη: δεν είναι δυνατόν να βρεθεί ο γονικός πίνακας';
$txt['modify_post_time_passed'] = 'Δεν μπορείτε να τροποποιήσετε αυτό το μήνυμα γιατί πέρασε το χρονικό όριο για τροποποιήσεις.';

$txt['calendar_off'] = 'Δεν έχετε πρόσβαση στο ημερολόγιο γιατί είναι απενεργοποιημένο.';
$txt['calendar_export_off'] = 'You cannot export calendar events because that feature is currently disabled.';
$txt['invalid_month'] = 'Μη έγκυρη τιμή μήνα.';
$txt['invalid_year'] = 'Μη έγκυρη τιμή έτους.';
$txt['invalid_day'] = 'Μη έγκυρη τιμή ημέρας.';
$txt['event_month_missing'] = 'Λείπει ο μήνας της εκδήλωσης.';
$txt['event_year_missing'] = 'Λείπει το έτος της εκδήλωσης.';
$txt['event_day_missing'] = 'Λείπει η ημέρα της εκδήλωσης.';
$txt['event_title_missing'] = 'Λείπει ο τίτλος της εκδήλωσης.';
$txt['invalid_date'] = 'Μη έγκυρη ημερομηνία.';
$txt['no_event_title'] = 'Δεν δόθηκε τίτλος της εκδήλωσης.';
$txt['missing_board_id'] = 'Λείπει το αναγνωριστικό (ID) του πίνακα.';
$txt['missing_topic_id'] = 'Λείπει το αναγνωριστικό (ID) του θέματος.';
$txt['topic_doesnt_exist'] = 'Το θέμα δεν υπάρχει.';
$txt['not_your_topic'] = 'Δεν είστε ο συντάκτης αυτού του θέματος.';
$txt['board_doesnt_exist'] = 'Ο πίνακας δεν υπάρχει.';
$txt['no_span'] = 'Η λειτουργία της διάρκειας πολλών ημερών είναι προς το παρόν μη διαθέσιμη.';
$txt['invalid_days_numb'] = 'Μη έγκυρος αριθμός ημερών διάρκειας.';

$txt['moveto_noboards'] = 'Δεν υπάρχουν πίνακες για μετακίνηση αυτού του θέματος!';
$txt['topic_already_moved'] = 'This topic %1$s has been moved to the board %2$s, please check its new location before moving it again.';

$txt['already_activated'] = 'We\'d love to process your request, but your account has already been activated.';
$txt['still_awaiting_approval'] = 'Ο λογαριασμός σας αναμένει έγκριση από διαχειριστή.';

$txt['invalid_email'] = 'Μη έγκυρη διεύθυνση / εύρος διευθύνσεων e-mail<br />Παράδειγμα έγκυρης διεύθυνσης email: bill.gates@microsoft.com.<br />Παράδειγμα έγκυρου εύρους διευθύνσεων email: *@*.microsoft.com';
$txt['invalid_expiration_date'] = 'Η ημερομηνία λήξης δεν είναι έγκυρη';
$txt['invalid_hostname'] = 'Μη έγκυρο όνομα / εύρος ονομάτων κεντρικού υπολογιστή.<br />Παράδειγμα έγκυρου ονόματος host: proxy4.microsoft.com<br />Παράδειγμα έγκυρου εύρους ονομάτων hosts: *.microsoft.com';
$txt['invalid_ip'] = 'Μη έγκυρη IP / εύρος IP.<br />Παράδειγμα έγκυρης ΙΡ: 127.0.0.1<br />Παράδειγμα έγκυρου εύρους IP: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Μη έγκυρη IP / εύρος IP.<br />Παράδειγμα έγκυρης διεύθυνσης IP: 127.0.0.1<br />Παράδειγμα έγκυρου εύρους IP: 127.0.0.*';
$txt['invalid_username'] = 'Δεν βρέθηκε το όνομα μέλους';
$txt['no_user_selected'] = 'Member not found';
$txt['no_ban_admin'] = 'Hey! We can\'t let you ban an admin. If you are certain about this, demote them first!';
$txt['no_bantype_selected'] = 'Δεν επιλέχθηκε τύπος αποκλεισμού';
$txt['ban_not_found'] = 'Η απαγόρευση δεν βρέθηκε';
$txt['ban_unknown_restriction_type'] = 'Αγνωστος τύπος αποκλεισμού';
$txt['ban_name_empty'] = 'Το όνομα του αποκλεισμού είναι κενό';
$txt['ban_id_empty'] = 'Dang, sorry. We tried to find this ban ID, but it can\'t be found.';
$txt['ban_group_id_empty'] = 'A ban group needs a group ID, and this group didn\'t have any.';
$txt['ban_no_triggers'] = 'Did you forget to select ban triggers? We need at least one, and we haven\'t got any.';
$txt['ban_ban_item_empty'] = 'Ban trigger not found';
$txt['impossible_insert_new_bangroup'] = 'An error occurred while inserting the new ban';

$txt['like_heading_error'] = 'Σφάλμα στα Likes';
$txt['like_wait_time'] = 'Sorry, you can\'t repeat a like action without waiting %1$s %2$s.';
$txt['like_unlike_error'] = 'Oops, there was an error while liking/unliking the post';
$txt['cant_like_yourself'] = 'Liking your own posts ... it\'s like laughing at your own jokes when there is no one else around  ... lol ... Wait did I just lol myself?';

$txt['ban_name_exists'] = 'Το όνομα αυτού του αποκλεισμού (%1$s) υπάρχει ήδη. Διαλέξτε ένα άλλο όνομα.';
$txt['ban_trigger_already_exists'] = 'Αυτό το έναυσμα αποκλεισμού (%1$s) υπάρχει ήδη στο %2$s. ';
$txt['attach_check_nag'] = 'Unable to continue due to incomplete data (%1$s).';

$txt['recycle_no_valid_board'] = 'Δεν επιλέχθηκε έγκυρος πίνακας για ανακύκλωση θεμάτων';
$txt['post_already_deleted'] = 'The topic or message has already been moved to the recycle board. Are you sure you want to delete it completely?<br />If so follow <a href="%1$s">this link</a>';

$txt['login_threshold_fail'] = 'Λυπούμαστε, τελείωσαν οι ευκαιρίες σύνδεσής σας. Παρακαλούμε δοκιμάστε αργότερα.';
$txt['login_threshold_brute_fail'] = 'Sorry, but you\'ve reached your login attempts threshold.  Please wait 30 seconds and try again.';

$txt['who_off'] = 'We would love to let you peek at Who\'s Online, but unfortunately right now it\'s disabled.';

$txt['merge_create_topic_failed'] = 'Dang, sorry. We tried, we really did, but creating a new topic failed.';
$txt['merge_need_more_topics'] = 'Merge topics requires at least two topics to merge, but we didn\'t get two. Please try again.';

$txt['post_WaitTime_broken'] = 'Η τελευταία δημοσίευσή σας από αυτή τη διεύθυνση IP ήταν λιγότερο από %1$d δευτερόλεπτα πριν. Παρακαλούμε προσπαθήστε αργότερα.';
$txt['register_WaitTime_broken'] = 'Ήδη εγγραφήκατε πριν από μόλις %1$d δευτερόλεπτα!';
$txt['login_WaitTime_broken'] = 'Θα χρειαστεί να περιμένετε περίπου %1$d δευτερόλεπτα για να συνδεθείτε ξανά.';
$txt['pm_WaitTime_broken'] = 'Το τελευταίο προσωπικό μήνυμα από τη διεύθυνση IP σας ήταν λιγότερο από %1$d δευτερόλεπτα πριν. Παρακαλούμε προσπαθήστε αργότερα.';
$txt['reporttm_WaitTime_broken'] = 'Η τελευταία αναφορά θεμάτων από τη διεύθυνση IP σας ήταν λιγότερο από %1$d δευτερόλεπτα πριν. Παρακαλούμε προσπαθήστε αργότερα.';
$txt['sendtopic_WaitTime_broken'] = 'Το τελευταίο θέμα σταλμένο από τη διεύθυνση IP σας ήταν λιγότερο από %1$d δευτερόλεπτα πριν. Παρακαλούμε προσπαθήστε αργότερα.';
$txt['sendmail_WaitTime_broken'] = 'Το τελευταίο email που στάλθηκε από τη διεύθυνση IP σας ήταν λιγότερο από %1$d δευτερόλεπτα πριν. Παρακαλούμε προσπαθήστε αργότερα.';
$txt['search_WaitTime_broken'] = 'Η τελευταία αναζήτηση σας ήταν λιγότερο από %1$d δευτερόλεπτα πριν. Παρακαλούμε προσπαθήστε αργότερα.';
$txt['remind_WaitTime_broken'] = 'Your last reminder was less than %1$d seconds ago. Please try again later.';
$txt['contact_WaitTime_broken'] = 'The last time you tried to use the contact form was less than %1$d seconds ago. Please try again later.';

$txt['topic_gone'] = 'We tried very hard to find the topic or board you are looking for, but it\'s nowhere to be found. It appears to be either missing or off limits to you.';
$txt['theme_edit_missing'] = 'We tried very hard to find the file you are trying to edit, but it can\'t be found.';

$txt['no_dump_database'] = 'Sorry, we can\'t let you make database backups. Only administrators can.';
$txt['pm_not_yours'] = 'Το προσωπικό μήνυμα που προσπαθείτε να παραθέσετε, δεν είναι δικό σας ή δεν υπάρχει, παρακαλώ πηγαίνετε πίσω και δοκιμάστε ξανά.';
$txt['mangled_post'] = 'Παραποιημένα δεδομένα φόρμας - παρακαλώ πηγαίνετε πίσω και δοκιμάστε ξανά.';
$txt['too_many_groups'] = 'Sorry, you selected too many groups, please remove some.';
$txt['post_upload_error'] = 'The post data is missing. This error could be caused by trying to submit a file larger than allowed by the server.  Please contact your administrator if this problem continues.';
$txt['quoted_post_deleted'] = 'Το μήνυμα που προσπαθείτε να παραθέσετε είτε δεν υπάρχει, διαγράφηκε, είτε δεν είναι πλέον προσπελάσιμο για εσάς.';
$txt['pm_too_many_per_hour'] = 'Έχετε υπερβεί το όριο των %1$d προσωπικών μηνυμάτων ανά ώρα.';
$txt['labels_too_many'] = 'Λυπούμαστε, %1$s μηνύματα ήδη συμπλήρωσαν τον μέγιστο αριθμό επιτρεπόμενων ετικετών!';

$txt['register_only_once'] = 'Δεν μπορείτε να δημιουργήσετε πολλαπλούς λογαριασμούς την ίδια στιγμή από τον ίδιο υπολογιστή.';
$txt['admin_setting_coppa_require_contact'] = 'Πρέπει να εισαγάγετε είτε ταχυδρομική διεύθυνση είτε φαξ αν απαιτείται έγκριση γονέα/κηδεμόνα.';

$txt['error_long_name'] = 'Το όνομα που χρησιμοποιήσατε ήταν πολύ μεγάλο.';
$txt['error_no_name'] = 'Δεν δόθηκε όνομα.';
$txt['error_bad_name'] = 'Το όνομα που δώσατε δεν μπορεί να χρησιμοποιηθεί, επειδή είναι ή περιέχει δεσμευμένο όνομα.';
$txt['error_no_email'] = 'Δεν δόθηκε e-mail.';
$txt['error_bad_email'] = 'Δόθηκε μη έγκυρη διεύθυνση e-mail.';
$txt['error_email'] = 'email address';
$txt['error_message'] = 'μήνυμα';
$txt['error_no_event'] = 'Δεν δόθηκε όνομα συμβάντος.';
$txt['error_no_subject'] = 'Δεν δόθηκε τίτλος.';
$txt['error_no_question'] = 'Δεν δόθηκε ερώτηση για αυτήν την ψηφοφορία.';
$txt['error_no_message'] = 'Δεν δόθηκε κείμενο για το μήνυμα.';
$txt['error_long_message'] = 'Το μήνυμα υπερβαίνει το μέγιστο επιτρεπόμενο μέγεθος (%s χαρακτήρες).';
$txt['error_no_comment'] = 'Το πεδίο σχολίου είναι άδειο.';
$txt['error_post_too_long'] = 'Your message is too long. Please enter a maximum of 255 characters.';
$txt['error_session_timeout'] = 'Υπερβήκατε τον μέγιστο χρόνο σύνδεσης κατά την αποστολή. Παρακαλούμε προσπαθήστε να αποστείλετε ξανά το μήνυμά σας.';
$txt['error_no_to'] = 'Δεν δόθηκαν παραλήπτες.';
$txt['error_bad_to'] = 'Ένας ή περισσότεροι παραλήπτες δεν βρέθηκαν.';
$txt['error_bad_bcc'] = 'Ένας ή περισσότεροι κρυφοί παραλήπτες δεν βρέθηκαν.';
$txt['error_form_already_submitted'] = 'You already submitted this post!  You might have accidentally double clicked or refreshed the page.';
$txt['error_poll_few'] = 'Πρέπει να έχετε τουλάχιστον δύο επιλογές!';
$txt['error_poll_many'] = 'You must have no more than 256 choices.';
$txt['error_need_qr_verification'] = 'Παρακαλούμε συμπληρώστε το τμήμα επαλήθευσης παρακάτω για να αποστείλετε το μήνυμά σας.';
$txt['error_wrong_verification_code'] = 'Τα γράμματα που γράψατε δεν ταιριάζουν με τα γράμματα που εμφανίζονται στην εικόνα.';
$txt['error_wrong_verification_answer'] = 'Δεν απαντήσατε σωστά στις ερωτήσεις επαλήθευσης.';
$txt['error_need_verification_code'] = 'Παρακαλώ εισαγάγετε τον κωδικό επαλήθευσης για να συνεχίσετε με τα αποτελέσματα.';
$txt['error_bad_file'] = 'Sorry, but the file specified could not be opened: %1$s';
$txt['error_bad_line'] = 'Η γραμμή που δηλώσατε δεν είναι έγκυρη.';
$txt['error_draft_not_saved'] = 'There was an error saving the draft';
$txt['error_name_in_use'] = 'Το όνομα %1$s χρησιμοποιείται από άλλο μέλος.';

$txt['smiley_not_found'] = 'Η φατσούλα δεν βρέθηκε.';
$txt['smiley_has_no_code'] = 'Δεν δόθηκε κώδικας για αυτή τη φατσούλα.';
$txt['smiley_has_no_filename'] = 'No file name for this smiley was given.';
$txt['smiley_not_unique'] = 'Υπάρχει ήδη φατσούλα με αυτόν τον κώδικα.';
$txt['smiley_set_already_exists'] = 'Υπάρχει ήδη φατσούλα με αυτό το URL';
$txt['smiley_set_not_found'] = 'Η ομάδα φατσούλων δεν βρέθηκε';
$txt['smiley_set_dir_not_found'] = 'The directory of the smiley set %1$s is either invalid or cannot be accessed';
$txt['smiley_set_path_already_used'] = 'Το URL για αυτήν την ομάδα φατσούλων χρησιμοποιείται ήδη από άλλη ομάδα φατσούλων.';
$txt['smiley_set_unable_to_import'] = 'Αποτυχία στην εισαγωγή ομάδας φατσούλων. Είτε ο φάκελος δεν είναι έγκυρος, είτε δεν μπορεί να προσπελαστεί.';

$txt['smileys_upload_error'] = 'Αποτυχία στην αποστολή του αρχείου.';
$txt['smileys_upload_error_blank'] = 'All smiley sets must have an image.';
$txt['smileys_upload_error_name'] = 'All smileys must have the same file name.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Μη έγκυρος τύπος αρχείου.';

$txt['search_invalid_weights'] = 'Search weights are not configured properly. At least one weight should be configured to be non-zero. Please report this error to an administrator.';

$txt['package_no_file'] = 'Το αρχείο πακέτου δεν βρέθηκε!';
$txt['packageget_unable'] = 'Η σύνδεση στον διακομιστή δεν ήταν δυνατή.  Παρακαλούμε δοκιμάστε <a href="%1$s" target="_blank" class="new_win">αυτό το URL</a> ως εναλλακτικό.';
$txt['not_valid_server'] = 'Sorry, packages can only be downloaded like this from servers you have first authorized.';
$txt['package_cant_uninstall'] = 'Αυτό το πακέτο είτε δεν είχε εγκατασταθεί ποτέ, είτε έχει ήδη απεγκατασταθεί. Δεν μπορείτε να το απεγκαταστήσετε τώρα.';
$txt['package_cant_download'] = 'You cannot download or install new packages because the &quot;packages&quot; directory or one of the files in it are not writable!';
$txt['package_upload_error_nofile'] = 'Δεν επιλέξατε πακέτο για ανέβασμα.';
$txt['package_upload_error_failed'] = 'Δεν μπόρεσε να ανέβει το πακέτο, παρακαλώ ελέγξτε τα δικαιώματα του φακέλου!';
$txt['package_upload_error_exists'] = 'The file you are uploading already exists on the server. Please delete it first, then try again.';
$txt['package_upload_already_exists'] = 'The package you are trying to upload already exists on the server under file name: %1$s';
$txt['package_upload_error_supports'] = 'Ο διαχειριστής πακέτων προς το παρόν επιτρέπει μόνο αυτούς τους τύπους αρχείων: %1$s.';
$txt['package_upload_error_broken'] = 'Η αποστολή πακέτου απέτυχε λόγω του παρακάτω σφάλματος: <br />&quot;%1$s&quot;';

$txt['package_get_error_not_found'] = 'The package you are trying to install cannot be located. You may want to manually upload the package to your &quot;packages&quot; directory.';
$txt['package_get_error_missing_xml'] = 'Από το πακέτο που προσπαθείτε να εγκαταστήσετε λείπει το package-info.xml, το οποίο πρέπει να βρίσκεται στον κύριο κατάλογο του πακέτου.';
$txt['package_get_error_is_zero'] = 'Although the package was downloaded to the server it appears to be empty. Please check the &quot;packages&quot; directory, and the &quot;temp&quot; sub-directory are both writable. If you continue to experience this problem you should try extracting the package on your PC and uploading the extracted files into a subdirectory in your &quot;packages&quot; directory and try again. For example, if the package was called shout.tar.gz you should:<br />1) Download the package to your local PC and extract its files.<br />2) Create a new directory in your &quot;packages&quot; folder using an FTP client, in this example you may call it "shout".<br />3) Upload all the files from the extracted package to this directory.<br />4) Go back to the package manager browse page. The package will be automatically found.';
$txt['package_get_error_packageinfo_corrupt'] = 'Unable to find any valid information within the package-info.xml file included within the package. There may be an error in the add-on, or the package may be corrupt.';
$txt['package_get_error_is_theme'] = 'You can\'t install a theme from this section, please use the <a href="{MANAGETHEMEURL}">Theme Management</a> page to upload it';

$txt['no_membergroup_selected'] = 'Δεν επιλέχθηκε ομάδα μελών';
$txt['membergroup_does_not_exist'] = 'The member group doesn\'t exist or is invalid.';

$txt['at_least_one_admin'] = 'Πρέπει να υπάρχει τουλάχιστον ένας διαχειριστής σε ένα φόρουμ!';

$txt['error_functionality_not_windows'] = 'Λυπούμαστε, αυτή η δυνατότητα προς το παρόν δεν είναι διαθέσιμη για εξυπηρετητές που χρησιμοποιούν Windows.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Το συνημμένο δεν βρέθηκε';

$txt['error_no_boards_selected'] = 'No valid boards were selected.';
$txt['error_invalid_search_string'] = 'Μήπως ξεχάσατε να εισάγετε κάτι για αναζήτηση?';
$txt['error_invalid_search_string_blacklist'] = 'Your search query contained trivial words. Please try again with a different query.';
$txt['error_search_string_small_words'] = 'Κάθε λέξη πρέπει να έχει μήκος τουλάχιστον δύο χαρακτήρες.';
$txt['error_query_not_specific_enough'] = 'Η αναζήτησή σας δεν ήταν αρκετά συγκεκριμένη. Προσπαθήστε να χρησιμοποιήσετε περισσότερες/μεγαλύτερες λέξεις, ή λιγότερο συχνές φράσεις.';
$txt['error_no_messages_in_time_frame'] = 'Δεν βρέθηκαν μηνύματα στην επιλεγμένη χρονική περίοδο.';
$txt['error_no_labels_selected'] = 'No labels were selected.';
$txt['error_no_search_daemon'] = 'Unable to access the search daemon';

$txt['profile_errors_occurred'] = 'The following errors occurred when trying to update your profile';
$txt['profile_error_bad_offset'] = 'Η διαφορά ώρας είναι εκτός ορίων';
$txt['profile_error_no_name'] = 'Το πεδίο ονόματος είναι κενό';
$txt['profile_error_digits_only'] = 'Το πεδίο \'αριθμός μηνυμάτων\' μπορεί να περιέχει μόνο ψηφία.';
$txt['profile_error_name_taken'] = 'Το επιλεγμένο εμφανιζόμενο όνομα/όνομα χρήστη χρησιμοποιείται από άλλον χρήστη';
$txt['profile_error_name_too_long'] = 'Το επιλεγμένο όνομα είναι πολύ μεγάλο. Δεν πρέπει να είναι μεγαλύτερο από 60 χαρακτήρες';
$txt['profile_error_no_email'] = 'Το πεδίο διεύθυνσης e-mail είναι κενό';
$txt['profile_error_bad_email'] = 'Δεν έχετε εισάγει μια έγκυρη διεύθυνση email';
$txt['profile_error_email_taken'] = 'Κάποιος άλλος χρήστης είναι ήδη εγγεγραμμένος με αυτή τη διεύθυνση email';
$txt['profile_error_no_password'] = 'Δεν έχετε εισάγει τον κωδικό σας';
$txt['profile_error_bad_new_password'] = 'Οι νέοι κωδικοί που εισάγατε δεν συμπίπτουν';
$txt['profile_error_bad_password'] = 'Ο κωδικός που εισάγατε δεν ήταν σωστός';
$txt['profile_error_bad_avatar'] = 'Το πορτραίτο που επιλέξατε είναι πολύ μεγάλο ή δεν είναι πορτραίτο';
$txt['profile_error_password_short'] = 'Your password must be at least %1$s characters long.';
$txt['profile_error_password_restricted_words'] = 'Your password must not contain your user name, email address or other commonly used words.';
$txt['profile_error_password_chars'] = 'Ο κωδικός σας πρέπει να περιέχει πεζούς και κεφαλαίους χαρακτήρες, καθώς και αριθμούς.';
$txt['profile_error_already_requested_group'] = 'You already have an outstanding request for this group!';
$txt['profile_error_openid_in_use'] = 'Ένας άλλος χρήστης χρησιμοποιεί ήδη αυτή τη διεύθυνση URL του OpenID';
$txt['profile_error_signature_not_yet_saved'] = 'Η υπογραφή δεν έχει αποθυκευθεί.';
$txt['profile_error_personal_text_too_long'] = 'Το προσωπικό κείμενο είναι μεγάλο.';
$txt['profile_error_user_title_too_long'] = 'Ο προσαρμοσμένος τίτλος είναι μεγάλος.';

$txt['mysql_error_space'] = ' - ελέγξτε τον χώρο αποθήκευσης της βάσης δεδομένων ή επικοινωνήστε με τον διαχειριστή του διακομιστή.';

$txt['icon_not_found'] = 'Το εικονίδιο δεν ήταν δυνατό να βρεθεί στην προεπιλεγμένη εμφάνιση - παρακαλώ σιγουρευτείτε ότι έχει φορτωθεί και προσπαθήστε πάλι.';
$txt['icon_after_itself'] = 'The icon cannot be positioned after itself.';
$txt['icon_name_too_long'] = 'Icon file names cannot be more than 16 characters long';

$txt['name_censored'] = 'Λυπούμαστε, το όνομα που προσπαθήσατε να χρησιμοποιήσετε, %1$s, περιέχει λέξεις που έχουν απαγορευθεί. Παρακαλώ δοκιμάστε άλλο όνομα.';

$txt['poll_already_exists'] = 'A topic can only have one poll associated with it.';
$txt['poll_not_found'] = 'Δεν υπάρχει ψηφοφορία για αυτό το θέμα!';

$txt['error_while_adding_poll'] = 'Τα ακόλουθα σφάλματα παρουσιάστηκαν κατά την προσθήκη αυτής της ψηφοφορίας';
$txt['error_while_editing_poll'] = 'Τα ακόλουθα σφάλματα παρουσιάστηκαν κατά την τροποποίηση αυτής της ψηφοφορίας';

$txt['loadavg_search_disabled'] = 'Λόγω μεγάλου φόρτου στον διακομιστή, η λειτουργία της αναζήτησης είναι αυτόματα και προσωρινά απενεργοποιημένη. Παρακαλούμε προσπαθήστε αργότερα.';
$txt['loadavg_generic_disabled'] = 'Λόγω μεγάλου φόρτου στον διακομιστή, αυτή η λειτουργία είναι προσωρινά μη διαθέσιμη.';
$txt['loadavg_allunread_disabled'] = 'The server\'s resources are temporarily under a too high demand to find all the topics you have not read.';
$txt['loadavg_unreadreplies_disabled'] = 'Ο διακομιστής αυτή τη στιγμή έχει μεγάλο φόρτο. Παρακαλώ προσπαθήστε αργότερα.';
$txt['loadavg_show_posts_disabled'] = 'Παρακαλούμε προσπαθήστε αργότερα.  Τα μηνύματα αυτού του μέλους είναι προσωρινά μη διαθέσιμα λόγω υψηλού φόρτου στον διακομιστή.';
$txt['loadavg_unread_disabled'] = 'The server\'s resources are temporarily under a too high demand to list out the topics you have not read.';
$txt['loadavg_userstats_disabled'] = 'Please try again later.  This member\'s statistics are not currently available due to high load on the server.';

$txt['cannot_edit_permissions_inherited'] = 'You cannot edit inherited permissions directly, you must either edit the parent group or edit the member group inheritance.';

$txt['mc_no_modreport_specified'] = 'Πρέπει να δηλώσετε ποια αναφορά θέλετε να δείτε.';
$txt['mc_no_modreport_found'] = 'Η συγκεκριμένη αναφορά είτε δεν υπάρχει είτε είναι απροσπέλαστη από εσάς';

$txt['st_cannot_retrieve_file'] = 'Αποτυχία στην ανάκτηση του αρχείου %1$s.';
$txt['admin_file_not_found'] = 'Αποτυχία στην φόρτωση του ζητούμενου αρχείου: %1$s.';

$txt['themes_none_selectable'] = 'Τουλάχιστον μία εμφάνιση πρέπει να είναι επιλέξιμη.';
$txt['themes_default_selectable'] = 'Η γενική προκαθορισμένη εμφάνιση του φόρουμ πρέπει να είναι μία επιλέξιμη εμφάνιση.';
$txt['ignoreboards_disallowed'] = 'Η επιλογή για αγνόηση πινάκων δεν έχει ενεργοποιηθεί.';

$txt['mboards_delete_error'] = 'No category selected.';
$txt['mboards_delete_board_error'] = 'No board selected.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'You can not make a parent its own child.';
$txt['mboards_board_own_child_error'] = 'You can not make a board its own child.';

$txt['smileys_upload_error_notwritable'] = 'Οι παρακάτω φάκελοι φατσούλων δεν είναι εγγράψιμοι: %1$s';
$txt['smileys_upload_error_types'] = 'Η εικόνα μπορεί να έχει μόνο τις ακόλουθες καταλήξεις: %1$s.';

$txt['change_email_success'] = 'Η διεύθυνση email σας έχει αλλάξει, και ένα νέο email ενεργοποίησης έχει σταλθεί σε αυτή.';
$txt['resend_email_success'] = 'Ένα νέο email ενεργοποίησης έχει σταλθεί επιτυχώς.';

$txt['custom_option_need_name'] = 'The profile option must have a name.';
$txt['custom_option_not_unique'] = 'Field name is not unique.';
$txt['custom_option_regex_error'] = 'The regex you entered is not valid';

$txt['warning_no_reason'] = 'Πρέπει να εισάγετε έναν λόγο για να μεταβάλετε την κατάσταση προειδοποίησης ενός μέλους.';
$txt['warning_notify_blank'] = 'Επιλέξατε να ειδοποιήσετε τον χρήστη αλλά δεν συμπληρώσατε τα πεδία τίτλος/μήνυμα.';

$txt['cannot_connect_doc_site'] = 'Could not connect to the documentation site. Please check that your server configuration allows external internet connections and try again later.';

$txt['movetopic_no_reason'] = 'Πρέπει να δώσετε έναν λόγο για την μετακίνηση του θέματος, ή να αποεπιλέξετε την επιλογή "δημιουργία θέματος παραπομπής".';
$txt['movetopic_no_board'] = 'You must choose a board to move the topic to.';

$txt['splittopic_no_reason'] = 'You must enter a reason for splitting the topic, or uncheck the option to \'post a redirection message\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'The requested identifier did not return the proper information.';
$txt['openid_return_no_mode'] = 'The identity provider did not respond with the Open ID mode.';
$txt['openid_not_resolved'] = 'The identity provider did not approve your request.';
$txt['openid_no_assoc'] = 'Could not find the requested association with the identity provider.';
$txt['openid_sig_invalid'] = 'The signature from the identity provider is invalid.';
$txt['openid_load_data'] = 'Could not load the data from your login request.  Please try again.';
$txt['openid_not_verified'] = 'The supplied OpenID has not been verified yet.  Please log in to verify.';

$txt['error_custom_field_too_long'] = 'Το πεδίο &quot;%1$s&quot; δεν μπορεί να έχει μήκος μεγαλύτερο από %2$d χαρακτήρες.';
$txt['error_custom_field_invalid_email'] = 'Το πεδίο &quot;%1$s&quot; πρέπει να είναι μια έγκυρη διεύθυνση email.';
$txt['error_custom_field_not_number'] = 'Το πεδίο &quot;%1$s&quot; πρέπει να είναι αριθμητικό.';
$txt['error_custom_field_inproper_format'] = 'Το πεδίο &quot;%1$s&quot; είναι μη έγκυρου τύπου.';
$txt['error_custom_field_empty'] = 'Το πεδίο &quot;%1$s&quot; δεν μπορεί να είναι κενό.';

$txt['email_no_template'] = 'Το πρότυπο email &quot;%1$s&quot; δεν βρέθηκε.';

$txt['search_api_missing'] = 'The search API could not be found. Please contact the admin to check they have uploaded the correct files.';
$txt['search_api_not_compatible'] = 'The selected search API the forum is using is out of date - falling back to standard search. Please check the file %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Δεν μπορείτε να επαναφέρετε το αρχικό μήνυμα ενός θέματος.';
$txt['restored_disabled'] = 'Η επαναφορά θεμάτων έχει απανεργοποιηθεί.';
$txt['restore_not_found'] = 'The following messages could not be restored; the original topic may have been removed: %1$s You will need to move these manually.';

$txt['error_invalid_dir'] = 'Ο φάκελος που δηλώσατε δεν είναι έγκυρος.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'The Sub-action you requested is not defined';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'No sortable items were found';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
