<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Καλώς ήρθατε';
$txt['install_step_exist'] = 'Έλεγχος υπαρχόντων ';
$txt['install_step_writable'] = 'Έλεγχος εγγραψιμότητας';
$txt['install_step_forum'] = 'Βασικές Ρυθμίσεις';
$txt['install_step_databaseset'] = 'Ρυθμίσεις βάσης δεδομένων';
$txt['install_step_databasechange'] = 'Καταχώρηση στη βάση δεδομένων';
$txt['install_step_admin'] = 'Λογαριασμός διαχειριστή';
$txt['install_step_delete'] = 'Ολοκλήρωση εγκατάστασης';

$txt['installer'] = 'Εγκατάσταση ElkArte';
$txt['installer_language'] = 'Γλώσσα';
$txt['installer_language_set'] = 'Ορισμός';
$txt['congratulations'] = 'Συγχαρητήρια, η εγκατάσταση ολοκληρώθηκε!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Ο κατάλογος εγκατάστασης είναι ακόμη εγγράψιμος.  Είναι καλή ιδέα να το αλλάξετε (με chmod) σε μη εγγράψιμο για λόγους ασφαλείας.';
$txt['delete_installer'] = 'Κάντε κλικ εδώ για να προσπαθήσετε τον φάκελο εγκατάστασης.';
$txt['delete_installer_maybe'] = '<em>(δεν δουλεύει σε όλους τους διακομιστές.)</em>';
$txt['go_to_your_forum'] = 'Τώρα μπορείτε να δείτε το <a href="%1$s">νέο σας φόρουμ</a> και να το αρχίσετε να το χρησιμοποιείτε.  Σιγουρευτείτε πρώτα ότι είστε συνδεδεμένος, μετά από αυτό θα έχετε πρόσβαση στο κέντρο διαχείρισης.';
$txt['good_luck'] = 'Ευχαριστούμε που εγκαταστήσατε το  ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Καλώς ήρθατε';
$txt['install_welcome_desc'] = 'Καλωσορίσατε στο ElkArte.  Ακολουθώντας τον οδηγό θα καταφέρετε να ολοκληρώσετε την εγκατάσταση.%1$s.Θα χρειαστούμε μερικές λεπτομέρειες στα επόμενα βήματα και μετά από μερικά λεπτά το φόρουμ σας θα είναι έτοιμο προς χρήση.';
$txt['install_all_lovely'] = 'Ολοκληρώθηκαν κάποιες αρχικές δοκιμές στον διακομιστή σας και όλα φαίνονται να είναι εντάξει. Απλά πατήστε το κουμπί &quot;Συνέχεια&quot; για να ξεκινήσετε.';

$txt['user_refresh_install'] = 'Το φόρουμ αναβαθμίστηκε';
$txt['user_refresh_install_desc'] = 'Κατά την εγκατάσταση, το πρόγραμμα εγκατάστασης βρήκε οτι (με τις πληροφορίες που δώσατε) ένας ή περισσότερoι πίνακες που θα δημιουργούσε το πρόγραμμα εγκατάστασης, υπήρχαν ήδη.<br />Τυχόν πίνακες που λείπουν στην εγκατάσταση σας έχουν δημιουργηθεί εκ νέου με αρχικά δεδομένα, αλλά δεν διαγράφηκαν δεδομένα από υπάρχοντες πίνακες.';

$txt['default_topic_subject'] = 'Καλωσήρθατε στο ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Γενική Συζήτηση';
$txt['default_board_description'] = 'Μιλήστε ελεύθερα για οτιδήποτε σε αυτόν τον πίνακα.';
$txt['default_category_name'] = 'Γενική Κατηγορία';
$txt['default_time_format'] = '%B %d, %Y, %I:%M:%S %p';
$txt['default_news'] = 'ElkArte - Μόλις εγκαταστάθηκε!';
$txt['default_karmaLabel'] = 'Κάρμα:';
$txt['default_karmaSmiteLabel'] = '[απoδοκιμασία]';
$txt['default_karmaApplaudLabel'] = '[επιδοκιμασία]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGuest\\nroot';
$txt['default_smileyset_name'] = 'Χαρούμενη σειρά';
$txt['default_theme_name'] = 'ElkArte προεπιλεγμένη θέμα εμφάνισης';

$txt['default_administrator_group'] = 'Διαχειριστής';
$txt['default_global_moderator_group'] = 'Γενικός συντονιστής';
$txt['default_moderator_group'] = 'Συντονιστή';
$txt['default_newbie_group'] = 'Αρχάριο μέλος';
$txt['default_junior_group'] = 'Απλό μέλος';
$txt['default_full_group'] = 'Πλήρες μέλος';
$txt['default_senior_group'] = 'Ανώτερο μέλος';
$txt['default_hero_group'] = 'Ανώτατο μέλος';

$txt['default_smiley_smiley'] = 'Χαμόγελο';
$txt['default_wink_smiley'] = 'Κλείσιμο ματιού';
$txt['default_cheesy_smiley'] = 'Μεγάλο χαμόγελο';
$txt['default_grin_smiley'] = 'Σαρκασμός';
$txt['default_angry_smiley'] = 'Θυμός';
$txt['default_sad_smiley'] = 'Λύπη';
$txt['default_shocked_smiley'] = 'Έκπληξη';
$txt['default_cool_smiley'] = 'Άνεση';
$txt['default_huh_smiley'] = 'Απορία';
$txt['default_roll_eyes_smiley'] = 'Στριφογύρισμα ματιών';
$txt['default_tongue_smiley'] = 'Γλώσσα';
$txt['default_embarrassed_smiley'] = 'Ντροπή';
$txt['default_lips_sealed_smiley'] = 'Σφραγισμένα χείλη';
$txt['default_undecided_smiley'] = 'Αναποφασιστικότητα';
$txt['default_kiss_smiley'] = 'Φιλί';
$txt['default_cry_smiley'] = 'Κλάμα';
$txt['default_evil_smiley'] = 'Κακία';
$txt['default_azn_smiley'] = 'Azn';
$txt['default_afro_smiley'] = 'Άφρο';
$txt['default_laugh_smiley'] = 'Γέλιο';
$txt['default_police_smiley'] = 'Αστυνομία';
$txt['default_angel_smiley'] = 'Άγγελος';

$txt['error_message_click'] = 'Πατήστε εδώ';
$txt['error_message_try_again'] = 'για να δοκιμάσετε αυτό το βήμα ξανά.';
$txt['error_message_bad_try_again'] = 'για να δοκιμάσετε να εγκαταστήσετε έτσι κι αλλιώς, αλλά σημειώστε ότι αυτό <em>δεν</em> συνιστάται.';

$txt['install_settings'] = 'Βασικές Ρυθμίσεις';
$txt['install_settings_info'] = 'Αυτή η σελίδα απαιτεί να ορίσετε μερικές βασικές ρυθμίσεις για το φόρουμ σας. Το ElkArte ανίχνευσε αυτόματα τις βασικές ρυθμίσεις.';
$txt['install_settings_name'] = 'Όνομα φόρουμ';
$txt['install_settings_name_info'] = 'Αυτό είναι το όνομα του φόρουμ, π.χ. &quot;Δοκιμαστικό Φόρουμ&quot;.';
$txt['install_settings_name_default'] = 'Η κοινότητά μου';
$txt['install_settings_url'] = 'URL φόρουμ';
$txt['install_settings_url_info'] = 'Αυτή είναι η διεύθυνση URL του φόρουμ σας <strong>χωρίς το τελικό \'/\'!</strong>.<br />Στις περισσότερες περιπτώσεις, μπορείτε να αφήσετε την προεπιλεγμένη τιμή σε αυτό το πεδίο - είναι συνήθως σωστή.';
$txt['install_settings_compress'] = 'Έξοδος Gzip';
$txt['install_settings_compress_title'] = 'Συμπίεση εξόδου για εξοικονόμηση bandwidth.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Αυτή η λειτουργία δεν δουλεύει σωστά σε όλους τους διακομιστές, αλλά μπορεί να κάνει εξοικονόμηση σε μεγάλο εύρος.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Κλικ εδώ για ελέγχο</a>.(πρέπει να λέει "ΕΠΙΤΥΧΗΣ".)';
$txt['install_settings_dbsession'] = 'Συνδέσεις της βάσης δεδομένων';
$txt['install_settings_dbsession_title'] = 'Χρήση της βάσης δεδομένων για τις συνδέσεις αντί για τη χρήση αρχείων.';
$txt['install_settings_dbsession_info1'] = 'Αυτή η λειτουργία είναι σχεδόν πάντα για το καλύτερο, αφού κάνει τις συνδέσεις πιο εξαρτημένες.';
$txt['install_settings_dbsession_info2'] = 'Αυτή η λειτουργία είναι γενικά μια καλή ιδέα αλλά είναι πιθανόν να μη δουλέψει σε αυτόν τον διακομιστή.';
$txt['install_settings_proceed'] = 'Συνέχεια';

$txt['db_settings'] = 'Ρυθμίσεις διακομιστή βάσης δεδομένων';
$txt['db_settings_info'] = 'Αυτές είναι οι ρυθμίσεις που χρησιμοποιεί ο διακομιστής βάσης δεδομένων σας.  Αν δεν γνωρίζετε τις τιμές, θα πρέπει να ρωτήσετε για αυτές τον παροχέα του ιστοτόπου σας.';
$txt['db_settings_type'] = 'Τύπος βάσης δεδομένων';
$txt['db_settings_type_info'] = 'Έχουν εντοπιστεί πολλοί τύποι υποστηριζόμενων βάσεων δεδομένων - ποια θέλετε να χρησιμοποιήσετε;';
$txt['db_settings_server'] = 'Όνομα διακομιστή';
$txt['db_settings_server_info'] = 'Αυτό είναι σχεδόν πάντα localhost - αν δεν το γνωρίζετε, δοκιμάστε localhost.';
$txt['db_settings_port'] = 'Θύρα';
$txt['db_settings_port_info'] = 'Αφήστε το κενό αν ο διακομιστής σας χρησιμοποιεί την προεπιλεγμένη θύρα ή δεν είστε σίγουροι.';
$txt['db_settings_username'] = 'Όνομα χρήστη';
$txt['db_settings_username_info'] = 'Συμπληρώστε το όνομα χρήστη που χρειάζεται για να συνδεθείτε στη βάση δεδομένων.<br />Αν δεν το γνωρίζεται, δοκιμάστε το όνομα χρήστη του FTP σας, σε αρκετές περιπτώσεις είναι το ίδιο.';
$txt['db_settings_password'] = 'Κωδικός';
$txt['db_settings_password_info'] = 'Συμπληρώστε τον κωδικό πρόσβασης που χρειάζεται για να συνδεθείτε στη βάση δεδομένων.<br />Αν δεν τον γνωρίζεται, δοκιμάστε τον πρόσβασης του FTP σας, σε αρκετές περιπτώσεις είναι ο ίδιος.';
$txt['db_settings_database'] = 'Όνομα βάσης δεδομένων';
$txt['db_settings_database_info'] = 'Συμπληρώστε το όνομα της βάσης δεδομένων που θέλετε να χρησιμοποιήσετε για το ElkArte.';
$txt['db_settings_database_info_note'] = 'Αν η βάση δεδομένων δεν υπάρχει, ο οδηγός εγκατάστασης θα προσπαθήσει να την δημιουργήσει.';
$txt['db_settings_database_file'] = 'Όνομα βάσης δεδομένων';
$txt['db_settings_database_file_info'] = 'Αυτό είναι το όνομα του αρχείου στο οποίο αποθηκεύονται τα δεδομένα του ElkArte. Σας συνιστούμε να χρησιμοποιήσετε το τυχαία παραγόμενο όνομα για αυτό και να ορίσετε τη διαδρομή αυτού του αρχείου να βρίσκεται εκτός της δημόσιας περιοχής του κεντρικού διακομιστή.';
$txt['db_settings_prefix'] = 'Πρόθεμα πινάκων';
$txt['db_settings_prefix_info'] = 'Το πρόθεμα για κάθε όνομα πινάκα στη βάση δεδομένων.  <strong>Μην εγκαθιστάτε δύο φόρουμ με το ίδιο πρόθεμα!</strong><br />Αυτή η επιλογή επιτρέπει πολλαπλές εγκαταστάσεις σε μία βάση δεδομένων.';
$txt['db_populate'] = 'Συμπλήρωση βάσης δεδομένων';
$txt['db_populate_info'] = 'Οι ρυθμίσεις σας έχουν αποθηκευτεί και η βάση δεδομένων έχει συμπληρωθεί με όλα τα απαιτούμενα δεδομένα για να ξεκινήσει το φόρουμ σας. Περίληψη συμπλήρωσης:';
$txt['db_populate_info2'] = 'Πατήστε &quot;Συνέχεια&quot; για να μεταβείτε στη σελίδα δημιουργίας λογαριασμού διαχειριστή.';
$txt['db_populate_inserts'] = 'Εισήχθηκαν %1$d γραμμές.';
$txt['db_populate_tables'] = 'Δημιουργήθηκαν %1$d πίνακες.';
$txt['db_populate_insert_dups'] = 'Αγνοήθηκαν %1$d διπλές εισαγωγές.';
$txt['db_populate_table_dups'] = 'Αγνοήθηκαν %1$d διπλοί πίνακες.';

$txt['user_settings'] = 'Δημιουργία του λογαριασμού σας';
$txt['user_settings_info'] = 'Το πρόγραμμα εγκατάστασης θα δημιουργήσει τώρα ένα νέο λογαριασμό διαχειριστή για εσάς.';
$txt['user_settings_username'] = 'Όνομα χρήστη';
$txt['user_settings_username_info'] = 'Επιλέξτε το όνομα χρήστη για να συνδεθείτε.';
$txt['user_settings_password'] = 'Κωδικός';
$txt['user_settings_password_info'] = 'Συμπληρώστε τον κωδικό που προτιμάτε, και να τον θυμάστε πάντα!';
$txt['user_settings_again'] = 'Κωδικός';
$txt['user_settings_again_info'] = '(μόνο για επαλήθευση.)';
$txt['user_settings_email'] = 'Διεύθυνση e-mail';
$txt['user_settings_email_info'] = 'Δώστε επίσης τη διεύθυνση e-mail σας.  <strong>Αυτή πρέπει να είναι μια έγκυρη διεύθυνση e-mail.</strong>';
$txt['user_settings_database'] = 'Κωδικός πρόσβασης βάσης δεδομένων';
$txt['user_settings_database_info'] = 'Το πρόγραμμα εγκατάστασης απαιτεί να δώσετε τον κωδικό της βάσης δεδομένων πριν τη δημιουργία λογαριασμού διαχειριστή, για λόγους ασφαλείας.';
$txt['user_settings_skip'] = 'Παράλειψη';
$txt['user_settings_skip_sure'] = 'Σίγουρα θέλετε να παραλείψετε την δημιουργία λογαρισμού διαχειριστή;';
$txt['user_settings_proceed'] = 'Τέλος';

$txt['ftp_checking_writable'] = 'Έλεγχος αρχείων για το αν είναι εγγράψιμα ';
$txt['ftp_setup'] = 'Πληροφορίες σύνδεσης FTP';
$txt['ftp_setup_info'] = 'Το πρόγραμμα εγκατάστασης μπορεί να συνδεθεί μέσω FTP για να διορθώσει τα αρχεία που χρειάζεται να είναι εγγράψιμα αλλά δεν είναι.  Αν δεν λειτουργεί, θα πρέπει να κάνετε τα αρχεία εγγράψιμα με μη αυτόματο τρόπο.  Σημειώστε ότι προς το παρόν δεν υποστηρίζει SSL.';
$txt['ftp_server'] = 'Διακομιστής';
$txt['ftp_server_info'] = 'Αυτή θα πρέπει να είναι η διεύθυνση και η θύρα του διακομιστή FTP.';
$txt['ftp_port'] = 'Θύρα';
$txt['ftp_username'] = 'Όνομα χρήστη';
$txt['ftp_username_info'] = 'Όνομα χρήστη για την σύνδεση.<em>Δεν θα αποθηκευθεί πουθενά.</em> ';
$txt['ftp_password'] = 'Κωδικός';
$txt['ftp_password_info'] = 'Ο κωδικός για τη σύνδεση. <em>Αυτός δεν θα αποθηκευτεί πουθενά.</em>';
$txt['ftp_path'] = 'Κατάλογος εγκατάστασης';
$txt['ftp_path_info'] = 'Αυτός είναι ο <em>σχετικός</em> κατάλογος που χρησιμοποιείτε στον διακομιστή FTP.';
$txt['ftp_path_found_info'] = 'Ο κατάλογος στο παραπάνω πεδίο ανιχνεύθηκε αυτόματα.';
$txt['ftp_connect'] = 'Σύνδεση';
$txt['ftp_setup_why'] = 'Τι κάνει αυτό το βήμα;';
$txt['ftp_setup_why_info'] = 'Μερικά αρχεία πρέπει να είναι εγγράψιμα για να λειτουργεί σωστά το ElkArte.Αυτό το βήμα σας επιτρέπει να αφήσετε να γίνουν εγγράψιμα αυτόματα. Ωστόσο, σε ορισμένες περιπτώσεις δεν θα λειτουργήσει - στην περίπτωση αυτή, παρακαλούμε να κάνετε τα ακόλουθα αρχεία 777 (εγγράψιμα, 755 σε μερικές σελίδες φιλοξενίας(hosts)):';
$txt['ftp_setup_again'] = 'για να ελέγξετε αν αυτά τα αρχεία είναι εγγράψιμα και πάλι.';

$txt['error_php_too_low'] = 'Προειδοποίηση! Δεν φαίνεται να έχετε εγκατεστημένη στον ιστότοπο σας μια έκδοση PHP που να πληροί τις <strong>ελάχιστες απαιτήσεις εγκατάστασης της ElkArte</strong>.<br />Αν δεν είστε ο διαχειριστής του hosting, θα χρειαστεί να ζητήσετε από τον διαχειριστή να αναβαθμίσει ή να χρησιμοποιήσει διαφορετικό κεντρικό υπολογιστή - διαφορετικά, αναβαθμίστε το PHP σε μια πρόσφατη έκδοση.<br /> <br />Αν ξέρετε για το γεγονός ότι η έκδοσή σας PHP είναι αρκετά υψηλή μπορείτε να συνεχίσετε, αν και αυτό αποθαρρύνεται έντονα.';
$txt['error_missing_files'] = 'Δεν βρέθηκαν κρίσιμα αρχεία εγκατάστασης στον κατάλογο αυτού του script!<br /><br />Σιγουρευτείτε ότι ανεβάσατε ολοκληρωμένο το πακέτο εγκατάστασης, συμπεριλαμβανομένου του αρχείου sql, και μετά δοκιμάστε ξανά.';
$txt['error_session_save_path'] = 'Παρακαλούμε ενημερώστε τον παροχέα σας ότι το <b>session.save_path που δηλώνεται στο php.ini</b> δεν είναι έγκυρο!  Χρειάζεται να αλλαχθεί σε ένα κατάλογο που <strong>υπάρχει</strong>, και είναι <strong>εγγράψιμος</strong> από τον χρήστη κάτω από τον οποίο τρέχει το PHP.<br />';
$txt['error_windows_chmod'] = 'Βρίσκεστε σε ένα διακομιστή Windows και ορισμένα κρίσιμα αρχεία δεν είναι εγγράψιμα. Ζητήστε από το host να δώσει <strong>δικαιώματα εγγραφής</strong> στον χρήστη που τρέχει PHP για τα αρχεία της εγκατάστασης ElkArte. Τα παρακάτω αρχεία ή κατάλογοι πρέπει να είναι εγγράψιμα:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Δεν ήταν δυνατή η σύνδεση με τον  διακομιστή FTP με αυτόν τον συνδυασμό πληροφοριών.';
$txt['error_db_file'] = 'Δεν βρέθηκε το database source script! Παρακαλώ ελέγξτε αν το αρχείο %1$s είναι μέσα στο φάκελο του φόρουμ σας.';
$txt['error_db_connect'] = 'Δεν μπόρεσε να γίνει σύνδεση στον διακομιστή βάσης δεδομένων με τα δοθέντα δεδομένα.<br /><br />Αν δεν είστε σίγουρος πως να τα συμπληρώσετε, παρακαλούμε επικοινωνήστε με τον παροχέα σας.';
$txt['error_db_too_low'] = 'Η έκδοση του διακομιστή βάσης δεδομένων είναι πολύ παλιά και δεν πληροί τις ελάχιστες απαιτήσεις του ElkArte. <br /> <br />Παρακαλείσθε να ζητήσετε από τον κεντρικό υπολογιστή σας να το αναβαθμίσει ή να του δώσει νέο και αν δεν θέλουν, δοκιμάστε έναν διαφορετικό host.';
$txt['error_db_database'] = 'Το πρόγραμμα εγκατάστασης δεν έχει πρόσβαση &quot;<em>%1$s</em> &quot; στη βάση δεδομένων. Πρέπει να δημιουργήσετε τη βάση δεδομένων στον πίνακα διαχείρισης πριν το χρησιμοποιήσει το ElkArte. Μερικοί προσθέτουν επίσης προθέματα - όπως το όνομα χρήστη - στα ονόματα της βάσης δεδομένων σας.';
$txt['error_db_queries'] = 'Μερικά ερωτήματα δεν εκτελέστηκαν σωστά.  Αυτό πιθανόν να έχει προκληθεί από μία έκδοση χωρίς υποστήριξη (παλιά ή αναπτυξιακή) του λογισμικού βάσης δεδομένων.<br /><br />Τεχνικές πληροφορίες για τα ερωτήματα:';
$txt['error_db_queries_line'] = 'Γραμμή #';
$txt['error_db_missing'] = 'Το πρόγραμμα εγκατάστασης δεν κατάφερε να ανιχνεύσει υποστήριξη βάσεων δεδομένων στην PHP που μπορεί να χρησιμοποιήσει το ElkArte. Ρωτήστε τον κεντρικό υπολογιστή σας για να βεβαιωθείτε ότι η PHP δημιουργήθηκε με την επιθυμητή βάση δεδομένων ή ότι φορτώνεται η κατάλληλη επέκταση php. Επί του παρόντος, το ElkArte υποστηρίζει τις &quot;%1$s&quot; επεκτάσεις';
$txt['error_db_script_missing'] = 'Ο εγκαταστάτης δεν μπόρεσε βρει αρχεία εγκατάστασης για τις βάσεις δεδομένων που ανιχνεύθηκαν. Ελέγξτε αν έχετε μεταφορτώσει τα απαραίτητα αρχεία εγκατάστασης στον φάκελο του φόρουμ σας, για παράδειγμα &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Ο εγκαταστάτης δεν μπόρεσε να ανιχνεύσει υποστήριξη συνδέσεων στην εγκατάσταση PHP του διακομιστή σας.  Παρακαλούμε ρωτήστε τον παροχέα σας για να σιγουρευτείτε οτι το PHP μεταγλωττίστηκε με υποστήριξη συνδέσεων (session support)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Δώσατε δύο τελείως διαφορετικούς κωδικούς!';
$txt['error_user_settings_no_password'] = 'Ο κωδικός σας πρέπει να είναι τουλάχιστον τεσσάρων χαρακτήρων.';
$txt['error_user_settings_taken'] = 'Λυπούμαστε, ένα μέλος είναι ήδη εγγεγραμμένο με αυτό το όνομα χρήστη ή / και διεύθυνση email.<br /> <br />Ο νέος λογαριασμός δεν έχει δημιουργηθεί.';
$txt['error_user_settings_query'] = 'Ένα σφάλμα βάσης δεδομένων συνέβη κατά τη δημιουργία διαχειριστή.  Το σφάλμα ήταν:';
$txt['error_subs_missing'] = 'Αδύνατον να βρεθεί η πηγή του αρχείου/Subs.php.Βεβαιωθείτε ότι έχει μεταφορτωθεί σωστά και δοκιμάστε ξανά.';
$txt['error_db_alter_priv'] = 'Ο λογαριασμός της βάσης δεδομένων που καθορίσατε δεν έχει άδεια για την ALTER, CREATE και / ή DROP στους πίνακες της βάση δεδομένων. αυτό είναι απαραίτητο για την καλή λειτουργία του ElkArte.';
$txt['error_versions_do_not_match'] = 'Το πρόγραμμα εγκατάστασης έχει εντοπίσει μια άλλη έκδοση του ElkArte που έχει ήδη εγκατασταθεί με τις καθορισμένες πληροφορίες. Αν προσπαθείτε να αναβαθμίσετε, θα πρέπει να χρησιμοποιήσετε το αρχείο αναβάθμισης και όχι το αρχείο εγκατάστασης.<br /> <br /> Διαφορετικά, μπορείτε να χρησιμοποιήσετε διαφορετικές πληροφορίες ή να δημιουργήσετε ένα αντίγραφο ασφαλείας και στη συνέχεια, να διαγράψετε τα δεδομένα που βρίσκονται στη βάση δεδομένων.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'Η τρέχουσα έκδοση της βάσης δεδομένων δεν υποστηρίζει την κωδικοποίηση χαρακτήρων UTF-8. Δεν μπορείτε να εγκαταστήσετε το ElkArte';
$txt['error_valid_email_needed'] = 'Δεν έχετε εισάγει μα έγκυρη διεύθυνση e-mail.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Προσοχή!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Πρέπει να δώσετε ένα όνομα για το όνομα αρχείου της βάσης δεδομένων του SQLite.';
$txt['error_db_prefix_numeric'] = 'Η επιλεγμένη βάση δεδομένων δεν υποστηρίζει την χρήση αριθμητικών προθεμάτων.';
$txt['error_invalid_characters_username'] = 'Μη έγκυρος χαρακτήρας στο όνομα χρήστη.';
$txt['error_username_too_long'] = 'Το όνομα χρήστη πρέπει να έχει μήκος μικρότερο των 25 χαρακτήρων.';
$txt['error_username_left_empty'] = 'Το πεδίο ονόματος χρήστη ήταν κενό.';
$txt['error_db_filename_exists'] = 'Η βάση δεδομένων που προσπαθείτε να δημιουργήσετε υπάρχει ήδη.  Διαγράψτε το τρέχον αρχείο βάση δεδομένων ή δώστε άλλο όνομα.';
$txt['error_db_prefix_reserved'] = 'Το πρόθεμα που δώσατε είναι ένα δεσμευμένο πρόθεμα.  Δώστε ένα άλλο πρόθεμα.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade Utility';
$txt['upgrade_warning'] = 'Προσοχή!';
$txt['upgrade_critical_error'] = 'Κρίσιμο σφάλμα!';
$txt['upgrade_continue'] = 'Συνέχεια';
$txt['upgrade_retry'] = 'Ξαναδοκιμάστε';
$txt['upgrade_skip'] = 'Παράλειψη';
$txt['upgrade_note'] = 'Σημείωση!';
$txt['upgrade_step'] = 'Βήμα';
$txt['upgrade_steps'] = 'Βήματα';
$txt['upgrade_progress'] = 'Πρόοδος';
$txt['upgrade_overall_progress'] = 'Συνολική πρόοδος';
$txt['upgrade_step_progress'] = 'Πρόοδος βήματος';
$txt['upgrade_time_elapsed'] = 'Χρόνος που πέρασε';
$txt['upgrade_time_mins'] = 'λεπτά';
$txt['upgrade_time_secs'] = 'δευτερόλεπτα';

$txt['upgrade_incomplete'] = 'Ημιτελές';
$txt['upgrade_not_quite_done'] = 'Δεν τέλειωσε ακόμα!';
$txt['upgrade_paused_overload'] = 'Η αναβάθμιση παύθηκε προσωρινά για να αποφευχθεί υπερφόρτωση στον διακομιστή σας.  Μην ανησυχείτε, όλα είναι εντάξει, απλά πατήστε το κουμπί <label for="contbutt">Συνέχεια</label> για να συνεχίσετε.';

$txt['upgrade_ready_proceed'] = 'Thank you for choosing to upgrade to ElkArte %1$s. All files appear to be in place, and we\'re ready to proceed.';

$txt['upgrade_error_script_js'] = 'The upgrade script cannot find script.js or it is out of date. Make sure your theme paths are correct. You can download a settings check and repair script from <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte tools</a>.';

$txt['upgrade_warning_lots_data'] = 'Η εφαρμογή αναβάθμισης διαπίστωσε ότι το φόρουμ σας περιέχει πολλά δεδομένα που χρειάζονται αναβάθμιση. Αυτή η διεργασία μπορεί να πάρει αρκετό χρόνο, ανάλογα με τον διακομιστή σας και το μέγεθος του φόρουμ, και για πολύ μεγάλα φόρουμ (~300,000 μηνύματα) μπορεί να πάρει αρκετές ώρες μέχρι να ολοκληρωθεί.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';