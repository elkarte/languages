<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Δεν σας επιτρέπεται η αλλαγή αυτού του προφίλ.';
$txt['website_title'] = 'Τίτλος ιστότοπου';
$txt['website_url'] = 'Διεύθυνση ιστότοπου';
$txt['signature'] = 'Υπογραφή';
$txt['profile_posts'] = 'μηνύματα';

$txt['profile_info'] = 'Extra Details';
$txt['profile_contact'] = 'Contact Information';
$txt['profile_moderation'] = 'Moderation Information';
$txt['profile_more'] = 'Υπογραφή';
$txt['profile_attachments'] = 'Recent Attachments';
$txt['profile_attachments_no'] = 'There are no Attachments from this member';
$txt['profile_recent_posts'] = 'Τελευταία μηνύματα';
$txt['profile_posts_no'] = 'There are no posts from this member';
$txt['profile_topics'] = 'Recent Topics';
$txt['profile_topics_no'] = 'There are no topics from this member';
$txt['profile_buddies_no'] = 'You have not set any buddies';
$txt['profile_user_info'] = 'User Info';
$txt['profile_contact_no'] = 'There is no contact information for this member';
$txt['profile_signature_no'] = 'There is no signature for this member';
$txt['profile_additonal_no'] = 'There is no additional information for this member';
$txt['profile_user_summary'] = 'Προφίλ';
$txt['profile_action'] = 'Currently';
$txt['profile_recent_activity'] = 'Recent Activity';
$txt['profile_activity'] = 'Δραστηριότητα';
$txt['profile_loadavg'] = 'Please try again later.  This information is not currently available due to high demand on the site.';

$txt['change_profile'] = 'Αλλαγή προφίλ';
$txt['preview_signature'] = 'Preview signature';
$txt['current_signature'] = 'Current signature';
$txt['signature_preview'] = 'Signature preview';
$txt['personal_picture'] = 'Προσωπική εικόνα';
$txt['no_avatar'] = 'Χωρίς προσωπική εικόνα';
$txt['choose_avatar_gallery'] = 'Επιλογή πορτραίτου από άλμπουμ';
$txt['preferred_language'] = 'Προτιμώμενη γλώσσα';
$txt['age'] = 'Ηλικία';
$txt['no_pic'] = '(χωρίς εικόνα)';
$txt['avatar_by_url'] = 'Specify your own avatar by URL. (e.g.: <em>http://www.mypage.com/mypic.png</em>)';
$txt['my_own_pic'] = 'Δηλώστε πορτραίτο με URL';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'Η επιλογή αυτή θα κάνει όλες τις ημερομηνίες του φόρουμ να εμφανίζονται με αυτή τη μορφή.';
$txt['time_format'] = 'Μορφή ώρας';
$txt['display_name_desc'] = 'Αυτό είναι το όνομα που θα εμφανίζεται στους επισκέπτες (επιτρέπονται ελληνικοί χαρακτήρες).';
$txt['personal_time_offset'] = 'Αριθμός διαφοράς ωρών +/- για να κάνετε την ώρα του φόρουμ να εμφανίζεται στη τοπική σας ώρα.';
$txt['dob'] = 'Ημερομηνία γέννησης';
$txt['dob_month'] = 'Μήνας (ΜΜ)';
$txt['dob_day'] = 'Ημέρα (ΗΗ)';
$txt['dob_year'] = 'Έτος (ΕΕΕΕ)';
$txt['password_strength'] = 'Για μεγαλύτερη ασφάλεια, συνιστούμε να χρησιμοποιήσετε 6 ή παραπάνω χαρακτήρες, με συνδυασμό γραμμάτων, αριθμών και συμβόλων.';
$txt['include_website_url'] = 'Είναι απαραίτητο αν δώσετε διεύθυνση URL παρακάτω.';
$txt['complete_url'] = 'Πρέπει να είναι ένα πλήρες URL, και να αρχίζει από http://';
$txt['sig_info'] = 'Η υπογραφή εμφανίζεται στο κάτω μέρος κάθε μηνύματός σας. Μπορεί να χρησιμοποιηθεί κώδικας BBC και φατσούλες στην υπογραφή σας.';
$txt['max_sig_characters'] = 'Μέγιστο πλήθος χαρακτήρων: %1$s; Χαρακτήρες που υπολείπονται: ';
$txt['send_member_pm'] = 'Αποστολή προσωπικού μηνύματος σε αυτό το μέλος';
$txt['hidden'] = 'κρυμμένο';
$txt['current_time'] = 'Ώρα του φόρουμ αυτή τη στιγμή';

$txt['language'] = 'Γλώσσα';
$txt['avatar_too_big'] = 'Το πορτραίτο σας είναι πολύ μεγάλο, μικρύνετέ το και ξαναπροσπαθήστε (μέγιστο';
$txt['invalid_registration'] = 'Λάθος ημερομηνία εγγραφής, έγκυρο παράδειγμα:';
$txt['current_password'] = 'Τρέχων κωδικός';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Για λόγους ασφαλείας πρέπει να δώσετε τον τρέχοντα κωδικό σας για να κάνετε αλλαγές στο προφίλ σας.';

$txt['timeoffset_autodetect'] = 'auto detect';

$txt['secret_question'] = 'Μυστική ερώτηση';
$txt['secret_desc'] = 'Για να βοηθηθείτε στο να ανακτήσετε τον κωδικό σας, δώστε εδώ μια ερώτηση με μια απάντηση που <strong>μόνο</strong> εσείς γνωρίζετε.';
$txt['secret_desc2'] = 'Επιλέξτε προσεκτικά, δεν θα θέλατε κάποιος να μαντέψει την απάντηση!';
$txt['secret_answer'] = 'Απάντηση';
$txt['incorrect_answer'] = 'Συγγνώμη, αλλά δεν δώσατε έναν έγκυρο συνδυασμό μυστικής ερώτησης και απάντησης στο προφίλ σας. Παρακαλούμε επιστρέψτε πίσω και χρησιμοποιήστε τον προκαθορισμένο τρόπο αλλαγής του κωδικού σας.';
$txt['enter_new_password'] = 'Παρακαλούμε δώστε την απάντηση στην ερώτηση, και τον νέο κωδικό που θέλετε να έχετε. Αν η απάντηση είναι σωστή, o κωδικός σας θα αλλάξει σε αυτόν που ορίσατε.';
$txt['secret_why_blank'] = 'γιατί αυτό είναι κενό;';

$txt['authentication_reminder'] = 'Υπενθύμιση πιστοποίησης';
$txt['password_reminder_desc'] = 'Αν ξεχάσατε τα στοιχεία του λογαριασμού σας, μην ανησυχείτε, μπορούν να ανακτηθούν. Για να ξεκινήσετε, παρακαλούμε δώστε το όνομα χρήστη ή τον κωδικό σας παρακάτω.';
$txt['authentication_options'] = 'Επιλέξτε μία από τις δύο παρακάτω επιλογές';
$txt['authentication_openid_email'] = 'Στείλε με email την υπενθύμιση της ταυτότητας μου OpenID';
$txt['authentication_openid_secret'] = 'Να απαντήσω την &quot;μυστική ερώτηση&quot; για να εμφανιστεί η ταυτότητά μου OpenID';
$txt['authentication_password_email'] = 'Στείλε μου νέο κωδικό με email';
$txt['authentication_password_secret'] = 'Να ορίσω νέο κωδικό αφού απαντήσω την &quot;μυστική ερώτηση&quot;';
$txt['openid_secret_reminder'] = 'Παρακαλούμε δώστε την απάντηση σας στην παρακάτω ερώτηση. Αν είναι σωστή, τότε θα εμφανιστεί η ταυτότητά σας OpenID.';
$txt['reminder_openid_is'] = 'Η ταυτότητά σας OpenID που σχετίζεται με αυτόν τον λογαριασμό είναι:<br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /><br />Παρακαλούμε σημειώστε αυτά τα στοιχεία σε περίπτωση που χρειαστούν στο μέλλον.';
$txt['reminder_continue'] = 'Συνέχεια';

$txt['accept_agreement_title'] = 'Accept agreement';
$txt['agreement_accepted_title'] = 'Συνέχεια';

$txt['current_theme'] = 'Τρέχουσα εμφάνιση';
$txt['change'] = 'Change Theme';
$txt['theme_forum_default'] = 'Προεπιλογή φόρουμ ή πίνακα';
$txt['theme_forum_default_desc'] = 'Αυτή είναι η προεπιλεγμένη εμφάνιση. Η εμφάνιση αυτή μπορεί να αλλάξει ανάλογα με τη ρύθμιση που έχει κάνει ο διαχειριστής και τον πίνακα που διαβάζετε.';

$txt['profileConfirm'] = 'Θέλετε σίγουρα να διαγράψετε αυτό το μέλος;';

$txt['custom_title'] = 'Προσαρμοσμένος τίτλος';

$txt['lastLoggedIn'] = 'Τελευταίο ενεργό';

$txt['notify_settings'] = 'Ρυθμίσεις ειδοποιήσεων:';
$txt['notify_save'] = 'Αποθήκευση ρυθμίσεων';
$txt['notify_important_email'] = 'Λήψη ενημερωτικών δελτίων, ανακοινώσεων και σημαντικών ειδοποιήσεων με e-mail.';
$txt['notify_regularity'] = 'Για θέματα και πίνακες για τους οποίους έχω ζητήσει ειδοποίηση, ειδοποίησέ με';
$txt['notify_regularity_none'] = 'Ποτέ';
$txt['notify_regularity_instant'] = 'Αμέσως';
$txt['notify_regularity_first_only'] = 'Αμέσως - αλλά μόνο για το πρώτο αδιάβαστο μήνυμα';
$txt['notify_regularity_daily'] = 'Ημερησίως';
$txt['notify_regularity_weekly'] = 'Εβδομαδιαίως';
$txt['auto_notify'] = 'Turn topic notification on when you post or reply to a topic.';
$txt['auto_notify_pbe_post'] = 'This is <strong>NOT</strong> recommended if you have "board" notifications enabled.';
$txt['notify_send_types'] = 'Notify me of topics and boards I\'ve requested notification on';
$txt['notify_send_type_everything'] = 'Απαντήσεις και συντονισμοί';
$txt['notify_send_type_everything_own'] = 'Συντονισμός μόνο αν δημιούργησα το θέμα';
$txt['notify_send_type_only_replies'] = 'Μόνο απαντήσεις';
$txt['notify_send_type_only_replies_pbe'] = 'All messages';
$txt['notify_send_type_nothing'] = 'Τίποτα απολύτως';
$txt['notify_send_body'] = 'When sending notifications of a reply to a topic, send the post in the email (but please don\'t reply to these emails.)';
$txt['notify_send_body_pbe'] = 'When sending email notifications, send the full text of the post in the email';
$txt['notify_send_body_pbe_post'] = '<strong>NOT</strong> available with Daily / Weekly summary';

$txt['notify_method'] = 'Notification and:';
$txt['notify_notification'] = 'no email (only mention/alert)';
$txt['notify_email'] = 'Immediate email';
$txt['notify_email_daily'] = 'Daily email';
$txt['notify_email_weekly'] = 'Weekly email';

$txt['notify_type_likemsg'] = 'Notify when one of your messages is liked';
$txt['notify_type_mentionmem'] = 'Notify when you are @mentioned';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Notify when someone adds you as buddy';
$txt['notify_type_quotedmem'] = 'Notify when someone quotes one of your messages';
$txt['notify_type_mailfail'] = 'Notify when email notifications are disabled (mention only)';

$txt['notifications_topics'] = 'Ειδοποιήσεις συζητήσεων';
$txt['notifications_topics_none'] = 'Προς το παρόν δεν λαμβάνετε ειδοποιήσεις από συζητήσεις.';
$txt['notifications_topics_howto'] = 'To receive notifications from a specific topic, click the &quot;Notify&quot; button while viewing it.';

$txt['notifications_boards'] = 'Ειδοποιήσεις πινάκων';
$txt['notifications_boards_none'] = 'Προς το παρόν δεν λαμβάνετε ειδοποιήσεις από πίνακες συζητήσεων.';
$txt['notifications_boards_howto'] = 'To request notifications from a specific board, either click the &quot;Notify&quot; button in the index of that board <strong>or</strong> use the checkboxes below to enable select board notifications.';
$txt['notifications_boards_current'] = 'You are receiving notifications on the boards shown in <strong>BOLD</strong>.  Use the checkboxes to turn these off or add additional boards to your notification list';
$txt['notifications_boards_update'] = 'Update';
$txt['notifications_update'] = 'Μη ειδοποίηση';

$txt['statPanel_showStats'] = 'Στατιστικά χρήστη: ';
$txt['statPanel_users_votes'] = 'Σύνολο ψήφων σε ψηφοφορίες';
$txt['statPanel_users_polls'] = 'Σύνολο δημιουργημένων ψηφοφοριών';
$txt['statPanel_total_time_online'] = 'Σύνολο χρόνου σε σύνδεση';
$txt['statPanel_noPosts'] = 'Δεν υπάρχει καμία αποστολή μηνύματος!';
$txt['statPanel_generalStats'] = 'Γενικά στατιστικά';
$txt['statPanel_posts'] = 'μηνύματα';
$txt['statPanel_topics'] = 'θέματα';
$txt['statPanel_total_posts'] = 'Σύνολο μηνυμάτων';
$txt['statPanel_total_topics'] = 'Σύνολο θεμάτων';
$txt['statPanel_votes'] = 'ψήφοι';
$txt['statPanel_polls'] = 'ψηφοφορίες';
$txt['statPanel_topBoards'] = 'Δημοφιλέστεροι πίνακες ανά αριθμό μηνυμάτων';
$txt['statPanel_topBoards_posts'] = '%1$d μηνύματα από τα %2$d μηνύματα του πίνακα (%3$01.2f%%) ';
$txt['statPanel_topBoards_memberposts'] = '%1$d μηνύματα από τα %2$d μηνύματα του μέλους (%3$01.2f%%) ';
$txt['statPanel_topBoardsActivity'] = 'Δημοφιλέστεροι πίνακες ανά επισκεψιμότητα';
$txt['statPanel_activityTime'] = 'Αποστολές μηνυμάτων ανά ώρα';
$txt['statPanel_activityTime_posts'] = '%1$d μηνύματα (%2$d%%) ';

$txt['deleteAccount_warning'] = 'Προσοχή! - Αυτές οι ενέργειες είναι μη αναστρέψιμες!';
$txt['deleteAccount_desc'] = 'Από αυτή τη σελίδα μπορείτε να διαγράψετε τον λογαριασμό και τα μηνύματα του χρήστη.';
$txt['deleteAccount_member'] = 'Διαγραφή λογαριασμού χρήστη';
$txt['deleteAccount_posts'] = 'Διαγραφή μηνυμάτων του μέλους';
$txt['deleteAccount_none'] = 'Κανένα';
$txt['deleteAccount_all_posts'] = 'Replies Only';
$txt['deleteAccount_topics'] = 'Topics and Replies';
$txt['deleteAccount_confirm'] = 'Θέλετε σίγουρα να διαγράψετε αυτόν τον λογαριασμό χρήστη;';
$txt['deleteAccount_approval'] = 'Παρακαλώ έχετε υπόψη οτι οι συντονιστές θα πρέπει να εγκρίνουν αυτή τη διαγραφή λογαριασμού πριν γίνει.';

$txt['profile_of_username'] = 'Προφίλ του %1$s';
$txt['profileInfo'] = 'Πληροφορίες προφίλ';
$txt['showPosts'] = 'Εμφάνιση μηνυμάτων';
$txt['showPosts_help'] = 'Αυτό το τμήμα σας επιτρέπει να δείτε όλα τα μηνύματα που στάλθηκαν από αυτόν τον χρήστη. Σημειώστε ότι μπορείτε να δείτε μόνο μηνύματα που στάλθηκαν σε περιοχές που αυτήν την στιγμή έχετε πρόσβαση.';
$txt['showMessages'] = 'Μηνύματα';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = 'Θέματα';
$txt['showUnwatched'] = 'Unwatched topics';
$txt['showAttachments'] = 'Συνημμένα';
$txt['viewWarning_help'] = 'This section allows you to view all warnings issued to this member.';
$txt['statPanel'] = 'Εμφάνιση στατιστικών';
$txt['editBuddyIgnoreLists'] = 'Λίστα φίλων/αγνοημένων';
$txt['editBuddies'] = 'Τροποποίηση λίστας φίλων';
$txt['editIgnoreList'] = 'Τροποποίηση λίστας αγνοημένων';
$txt['trackUser'] = 'Ανίχνευση χρήστη';
$txt['trackActivity'] = 'Δραστηριότητα';
$txt['trackIP'] = 'Διεύθυνση IP';
$txt['trackLogins'] = 'Logins';

$txt['likes_show'] = 'Show Likes';
$txt['likes_given'] = 'Posts you liked';
$txt['likes_profile_received'] = 'received';
$txt['likes_profile_given'] = 'given';
$txt['likes_received'] = 'Your posts liked by others';
$txt['likes_none_given'] = 'You have not liked any posts';
$txt['likes_none_received'] = 'No one has liked any of your posts :\'(';
$txt['likes_confirm_delete'] = 'Remove this like?';
$txt['likes_show_who'] = 'Show the members that liked this post';
$txt['likes_by'] = 'Liked by';
$txt['likes_delete'] = 'Διαγραφή';

$txt['authentication'] = 'Πιστοποίηση';
$txt['change_authentication'] = 'Εδώ μπορείτε να αλλάξετε τον τρόπο που συνδέεστε στο φόρουμ. Επιλέξτε είτε να χρησιμοποιείτε έναν λογαριασμό OpenID για την πιστοποίησή σας, είτε να χρησιμοποιείτε όνομα χρήστη και κωδικό.';

$txt['profileEdit'] = 'Αλλαγή προφίλ';
$txt['account_info'] = 'Αυτές είναι οι ρυθμίσεις του λογαριασμού σας. Αυτή η σελίδα περιέχει όλες τις κρίσιμες πληροφορίες που σας περιγράφουν σε αυτό το φόρουμ. Για λόγους ασφαλείας, θα χρειαστεί να δώσετε τον τρέχοντα κωδικό σας για να πραγματοποιήσετε αλλαγές σε αυτές τις πληροφορίες.';
$txt['forumProfile_info'] = 'You can change your personal information on this page. This information will be displayed throughout {forum_name_html_safe}. If you aren\'t comfortable with sharing some information, simply skip it - nothing here is required.';
$txt['theme_info'] = 'Αυτό το τμήμα σάς επιτρέπει να παραμετροποιήσετε τη μορφή και εμφάνιση του φόρουμ.';
$txt['notification_info'] = 'This allows you to be notified of replies to posts, newly posted topics, and forum announcements. You can change those settings here, or oversee the topics and boards you are currently receiving notifications for.';
$txt['groupmembership'] = 'Μέλος ομάδας';
$txt['groupMembership_info'] = 'Σε αυτό το τμήμα του προφίλ σας μπορείτε να αλλάξετε τις ομάδες στις οποίες ανήκετε.';
$txt['ignoreboards'] = 'Επιλογές αγνόησης πινάκων';
$txt['ignoreboards_info'] = 'This page lets you ignore particular boards.  When a board is ignored, the new post indicator will not show up on the board index.  New posts will not show up using the "unread post" search link (when searching it will not look in those boards). However, ignored boards will still appear on the board index and upon entering will show which topics have new posts.  When using the "unread replies" link, new posts in an ignored board will still be shown.';
$txt['contactprefs'] = 'Messaging';

$txt['profileAction'] = 'Ενέργειες';
$txt['deleteAccount'] = 'Διαγραφή λογαριασμού';
$txt['profileSendIm'] = 'Αποστολή προσωπικού μηνύματος';
$txt['profile_sendpm_short'] = 'Αποστολή ΠΜ';

$txt['profileBanUser'] = 'Αποκλεισμός χρήστη';

$txt['display_name'] = 'Εμφανιζόμενο όνομα';
$txt['enter_ip'] = 'IP (εύρος)';
$txt['errors_by'] = 'Μηνύματα σφάλματος από';
$txt['errors_desc'] = 'Ακολουθεί λίστα με όλα τα πρόσφατα σφάλματα που ο χρήστης δημιούργησε/έλαβε.';
$txt['errors_from_ip'] = 'Μηνύματα σφαλμάτων από το IP (εύρος)';
$txt['errors_from_ip_desc'] = 'Ακολουθεί λίστα όλων των πρόσφατων μηνυμάτων λαθών που δημιουργήθηκαν από αυτό το IP (εύρος).';
$txt['ip_address'] = 'Διεύθυνση IP';
$txt['ips_in_errors'] = 'IP που χρησιμοποιήθηκαν σε μηνύματα σφάλματος';
$txt['ips_in_messages'] = 'IP που χρησιμοποιήθηκαν σε πρόσφατα μηνύματα';
$txt['members_from_ip'] = 'Μέλη από το IP (εύρος)';
$txt['members_in_range'] = 'Μέλη πιθανόν στο ίδιο εύρος IP';
$txt['messages_from_ip'] = 'Μηνύματα που στάλθηκαν από το IP (εύρος)';
$txt['messages_from_ip_desc'] = 'Ακολουθεί λίστα από όλα τα μηνύματα που στάλθηκαν από αυτό το (εύρος).';
$txt['trackLogins_desc'] = 'Below is a list of all times this account was logged into.';
$txt['most_recent_ip'] = 'Πρόσφατη διευθύνση IP';
$txt['why_two_ip_address'] = 'Γιατί αναγράφονται δύο IP διευθύνσεις;';
$txt['no_errors_from_ip'] = 'Δεν βρέθηκαν μηνύματα σφάλματος από το συγκεκριμένο IP (εύρος)';
$txt['no_errors_from_user'] = 'Δεν βρέθηκαν μηνύματα σφάλματος από τον συγκεκριμένο χρήστη';
$txt['no_members_from_ip'] = 'Δεν βρέθηκαν μέλη από το συγκεκριμένο IP (εύρος)';
$txt['no_messages_from_ip'] = 'Δεν βρέθηκαν από το συγκεκριμένο IP (εύρος)';
$txt['trackLogins_none_found'] = 'No recent logins were found';
$txt['none'] = 'Κανένα';
$txt['own_profile_confirm'] = 'Είστε βέβαιος ότι θέλετε να διαγράψετε τον λογαριασμό σας;';
$txt['view_ips_by'] = 'Εμφάνιση IP που χρησιμοποιήθηκαν από';

$txt['avatar_will_upload'] = 'Αποστολή πορτραίτου';

$txt['activate_changed_email_title'] = 'Η διεύθυνση email αλλάχθηκε';
$txt['activate_changed_email_desc'] = 'Αλλάξατε την διεύθυνση email σας. Για να γίνει έγκυρη θα λάβετε ένα email. Πατήστε στον σύνδεσμο μέσα σε εκείνο το email για να επανενεργοποιήσετε τον λογαριασμό σας.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Αδύνατη η αποστολή υπενθύμισης με e-mail.';
$txt['send_email'] = 'Αποστολή e-mail στον χρήστη';
$txt['to_ask_password'] = 'για ερώτηση κωδικού';

$txt['user_email'] = 'Όνομα χρήστη/e-mail';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'Εστάλη ένα e-mail στη διεύθυνσή σας. Ακολουθήστε τον σύνδεσμο σε εκείνο το email για να ορίσετε νέο κωδικό.';
$txt['reminder_openid_sent'] = 'Η τρέχουσα ταυτότητά σας OpenID έχει αποσταλεί στην διεύθυνση email σας.';
$txt['reminder_set_password'] = 'Νέος κωδικός';
$txt['reminder_password_set'] = 'Ο νέος κωδικός ορίστηκε';
$txt['reminder_error'] = 'Το μέλος %1$s απέτυχε να απαντήσει τη μυστική ερώτηση του καθώς προσπαθούσε να αλλάξει έναν ξεχασμένο κωδικό.';

$txt['registration_not_approved'] = 'Αυτός ο λογαριασμός δεν έχει εγκριθεί ακόμα. Αν χρειάζεται να αλλάξετε την διεύθυνση e-mail σας, παρακαλώ πατήστε';
$txt['registration_not_activated'] = 'Αυτός ο λογαριασμός δεν έχει ενεργοποιηθεί ακόμα. Αν χρειάζεται να σας ξανασταλεί το e-mail ενεργοποίησης, παρακαλώ πατήστε';

$txt['primary_membergroup'] = 'Κύρια ομάδα μελών';
$txt['additional_membergroups'] = 'Πρόσθετες ομάδες μελών';
$txt['additional_membergroups_show'] = 'Show additional groups';
$txt['no_primary_membergroup'] = '(χωρίς κύρια ομάδα μελών)';
$txt['deadmin_confirm'] = 'Θέλετε σίγουρα να αφαιρέσετε τα δικαιώματα διαχείρισης σας; (μη-αναστρέψιμο)';

$txt['account_activate_method_2'] = 'Ο λογαριασμός απαιτεί επανενεργοποίηση μετά την αλλαγή του email';
$txt['account_activate_method_3'] = 'Ο λογαριασμός δεν έχει εγκριθεί';
$txt['account_activate_method_4'] = 'Ο λογαριασμός αναμένει έγκριση για διαγραφή';
$txt['account_activate_method_5'] = 'Ο λογαριασμός είναι &quot;με όριο ηλικίας&quot; και αναμένει έγκριση';
$txt['account_not_activated'] = 'Ο λογαριασμός δεν είναι ενεργοποιημένος';
$txt['account_activate'] = 'ενεργοποίηση';
$txt['account_approve'] = 'έγκριση';
$txt['user_is_banned'] = 'Ο χρήστης είναι αποκλεισμένος';
$txt['view_ban'] = 'Εμφάνιση';
$txt['user_banned_by_following'] = 'Αυτός ο χρήστης επηρεάζεται από τους ακόλουθους αποκλεισμούς';
$txt['user_cannot_due_to'] = 'Ο χρήστης δεν μπορεί να %1$s ως αποτέλεσμα του αποκλεισμού: &quot;%2$s&quot;';
$txt['ban_type_post'] = 'δημοσίευση';
$txt['ban_type_register'] = 'εγγραφή';
$txt['ban_type_login'] = 'σύνδεση';
$txt['ban_type_access'] = 'πρόσβαση στο φόρουμ';

$txt['show_online'] = 'Εμφάνιση της κατάστασης σύνδεσής μου στους υπόλοιπους χρήστες';

$txt['return_to_post'] = 'Επιστροφή στη συζήτηση μετά από την αποστολή.';
$txt['no_new_reply_warning'] = 'Να μην εμφανίζεται προειδοποίηση για νέες απαντήσεις που έγιναν κατά τη διάρκεια αποστολής μηνύματος.';
$txt['recent_pms_at_top'] = 'Εμφάνιση πιο πρόσφατων προσωπικών μηνυμάτων στην κορυφή.';
$txt['wysiwyg_default'] = 'Εμφάνιση κειμενογράφου WYSIWYG στη σελίδα αποστολής μηνύματος εξ ορισμού.';

$txt['timeformat_default'] = '(Προεπιλογή φόρουμ)';
$txt['timeformat_easy1'] = 'Μήνας Ημέρα, Έτος, ΩΩ:ΛΛ:ΔΔ πμ/μμ';
$txt['timeformat_easy2'] = 'Μήνας Ημέρα, Έτος, ΩΩ:ΛΛ:ΔΔ (24 ώρες)';
$txt['timeformat_easy3'] = 'ΕΕΕΕ-ΜΜ-ΗΗ, ΩΩ:ΛΛ:ΔΔ';
$txt['timeformat_easy4'] = 'ΗΗ Μήνας ΕΕΕΕ, ΩΩ:ΛΛ:ΔΔ';
$txt['timeformat_easy5'] = 'ΗΗ-ΜΜ-ΕΕΕΕ, ΩΩ:ΛΛ:ΔΔ';

$txt['poster'] = 'Αποστολέας';

$txt['use_sidebar_menu'] = 'Use sidebar menu instead of dropdowns.';
$txt['use_click_menu'] = 'Use click to open menus, instead of hover to open.';
$txt['show_no_avatars'] = 'Μη εμφάνιση πορτραίτων άλλων χρηστών.';
$txt['show_no_signatures'] = 'Μη εμφάνιση υπογραφών άλλων χρηστών.';
$txt['show_no_censored'] = 'Λέξεις χωρίς λογοκρισία.';
$txt['topics_per_page'] = 'Εμφανιζόμενα θέματα ανά σελίδα:';
$txt['messages_per_page'] = 'Εμφανιζόμενα μηνύματα ανά σελίδα:';
$txt['hide_poster_area'] = 'Hide the poster information area.';
$txt['per_page_default'] = 'προεπιλογή του φόρουμ';
$txt['calendar_start_day'] = 'First day of the week on the calendar:';
$txt['display_quick_reply'] = 'Χρήση γρήγορης απάντησης κατά την εμφάνιση θεμάτων: ';
$txt['use_editor_quick_reply'] = 'Use full editor in Quick Reply.';
$txt['display_quick_mod'] = 'Show quick-moderation as:';
$txt['display_quick_mod_none'] = 'μη εμφάνιση';
$txt['display_quick_mod_check'] = 'πλαίσια επιλογής';
$txt['display_quick_mod_image'] = 'εικονίδια';

$txt['whois_title'] = 'Ανίχνευση IP σε ένα διακομιστή whois';
$txt['whois_afrinic'] = 'AfriNIC (Αφρική)';
$txt['whois_apnic'] = 'APNIC (Ασία και Ειρηνικός)';
$txt['whois_arin'] = 'ARIN (Βορεία Αμερική, τμήμα Καραϊβικής και υποσαχάρια Αφρική)';
$txt['whois_lacnic'] = 'LACNIC (Λατινική Αμερική και Καραϊβική)';
$txt['whois_ripe'] = 'RIPE (Ευρώπη, Μέση Ανατολή και τμήματα Αφρικής και Ασίας)';

$txt['moderator_why_missing'] = 'γιατί δεν υπάρχει "Συντονιστής" εδώ;';
$txt['username_change'] = 'αλλαγή';
$txt['username_warning'] = 'Για να αλλάξετε το όνομα αυτού του μέλους, το φόρουμ πρέπει επίσης να επαναφέρει τον κωδικό του ο οποίος θα σταλεί στο μέλος με e-mail μαζί με το νέο του όνομα χρήστη.';

$txt['show_member_posts'] = 'Εμφάνιση μηνυμάτων του μέλους';
$txt['show_member_topics'] = 'Εμφάνιση θεμάτων του μέλους';
$txt['show_member_attachments'] = 'Εμφάνιση συνημμένων του μέλους';
$txt['show_posts_none'] = 'Δεν έχουν σταλεί ακόμη μηνύματα.';
$txt['show_topics_none'] = 'Δεν έχουν δημοσιοποιηθεί θέματα ακόμη.';
$txt['unwatched_topics_none'] = 'You don\'t have any topic in the unwatch list.';
$txt['show_attachments_none'] = 'Δεν έχουν σταλεί ακόμη συνημμένα.';
$txt['show_attach_filename'] = 'Όνομα αρχείου';
$txt['show_attach_downloads'] = 'Downloads';
$txt['show_attach_posted'] = 'Posted';

$txt['showPermissions'] = 'Εμφάνιση δικαιωμάτων';
$txt['showPermissions_status'] = 'Κατάσταση δικαιωμάτων';
$txt['showPermissions_help'] = 'Αυτό το τμήμα σας επιτρέπει να βλέπετε όλα τα δικαιώματα για αυτό το μέλος (τα δικαιώματα που του έχουν αρνηθεί είναι <del>διαγραμμένα</del>).';
$txt['showPermissions_given'] = 'Δόθηκε από';
$txt['showPermissions_denied'] = 'Αρνήθηκε από';
$txt['showPermissions_permission'] = 'Permission (denied permissions are shown <del>struck through</del>)';
$txt['showPermissions_none_general'] = 'Αυτό το μέλος δεν έχει γενικά δικαιώματα.';
$txt['showPermissions_none_board'] = 'Αυτό το μέλος δεν έχει ειδικά δικαιώματα πινάκων.';
$txt['showPermissions_all'] = 'Ως διαχειριστής, αυτό το μέλος έχει όλα τα δυνατά δικαιώματα.';
$txt['showPermissions_select'] = 'Ειδικά δικαιώματα πίνακα για';
$txt['showPermissions_general'] = 'Δικαιώματα ανά ομάδα μελών';
$txt['showPermissions_global'] = 'Όλοι οι πίνακες';
$txt['showPermissions_restricted_boards'] = 'Απαγορευμένοι πίνακες';
$txt['showPermissions_restricted_boards_desc'] = 'Οι παρακάτω πίνακες δεν είναι προσβάσιμοι από αυτόν τον χρήστη';

$txt['local_time'] = 'Τοπική ώρα';
$txt['posts_per_day'] = 'ανά ημέρα';

$txt['buddy_ignore_desc'] = 'Αυτή η περιοχή σας επιτρέπει να διατηρείτε λίστες φίλων και αγνοημένων για αυτό το φόρουμ. Η προσθήκη μελών σε αυτές τις λίστες, μεταξύ άλλων θα βοηθήσει στον έλεγχο της κυκλοφορίας mail και ΠΜ, ανάλογα με τις προτιμήσεις σας.';

$txt['buddy_add'] = 'Add to buddy list';
$txt['buddy_remove'] = 'Remove from buddy list';
$txt['buddy_add_button'] = 'Προσθήκη';
$txt['no_buddies'] = 'Η λίστα φίλων σας είναι άδεια';

$txt['ignore_add'] = 'Add to ignore list';
$txt['ignore_remove'] = 'Remove from ignore list';
$txt['ignore_add_button'] = 'Προσθήκη';
$txt['no_ignore'] = 'Η λίστα αγνοημένων σας είναι άδεια προς το παρόν';

$txt['regular_members'] = 'Εγγεγραμμένα μέλη';
$txt['regular_members_desc'] = 'Κάθε μέλος του φόρουμ είναι μέλος αυτής της ομάδας.';
$txt['group_membership_msg_free'] = 'Οι αλλαγές στις ομάδες μελών σας ανανεώθηκαν επιτυχώς.';
$txt['group_membership_msg_request'] = 'Η αίτησή σας υποβλήθηκε, παρακαλούμε να είστε υπομονετικοί μέχρι να εξεταστεί η αίτησή σας.';
$txt['group_membership_msg_primary'] = 'Η κύρια ομάδα μελών σας έχει ανανεωθεί';
$txt['current_membergroups'] = 'Τρέχουσες ομάδες μελών';
$txt['available_groups'] = 'Διαθέσιμες ομάδες';
$txt['join_group'] = 'Προσχώρηση στην ομάδα';
$txt['leave_group'] = 'Αποχώρηση από την ομάδα';
$txt['request_group'] = 'Αίτηση ένταξης';
$txt['approval_pending'] = 'Αναμένεται έγκριση';
$txt['make_primary'] = 'Θέσε ως κύρια ομάδα';

$txt['request_group_membership'] = 'Αίτηση ένταξης στην ομάδα';
$txt['request_group_membership_desc'] = 'Πριν μπορέσετε να ενταχθείτε σε αυτήν την ομάδα, η ένταξή σας πρέπει να εγκριθεί από τον συντονιστή. Παρακαλούμε δώστε έναν λόγο για την ένταξή σας σε αυτήν την ομάδα';
$txt['submit_request'] = 'Υποβολή αίτησης';

$txt['profile_updated_own'] = 'Το προφίλ σας ενημερώθηκε επιτυχώς.';
$txt['profile_updated_else'] = 'The profile for <strong>%1$s</strong> has been updated successfully.';

$txt['profile_error_signature_max_length'] = 'Η υπογραφή σας δεν μπορεί να είναι μεγαλύτερη από %1$d χαρακτήρες';
$txt['profile_error_signature_max_lines'] = 'Η υπογραφή σας δεν μπορεί να εκτείνεται σε πάνω από %1$d γραμμές';
$txt['profile_error_signature_max_image_size'] = 'Οι εικόνες στην υπογραφή σας δεν μπορούν να είναι μεγαλύτερες από %1$dx%2$d pixels';
$txt['profile_error_signature_max_image_width'] = 'Οι εικόνες στην υπογραφή σας δεν μπορούν να είναι φαρδύτερες από %1$d pixels';
$txt['profile_error_signature_max_image_height'] = 'Οι εικόνες στην υπογραφή σας δεν μπορούν να είναι ψηλότερες από %1$d pixels';
$txt['profile_error_signature_max_image_count'] = 'Δεν μπορείτε να έχετε πάνω από %1$d εικόνες στην υπογραφή σας';
$txt['profile_error_signature_max_font_size'] = 'Το κείμενο στην υπογραφή σας πρέπει να είναι μικρότερο από το μέγεθος %1$s';
$txt['profile_error_signature_allow_smileys'] = 'Δεν επιτρέπεται να χρησιμοποιήσετε φατσούλες στην υπογραφή σας';
$txt['profile_error_signature_max_smileys'] = 'Δεν επιτρέπεται να χρησιμοποιήσετε πάνω από %1$d φατσούλες στην υπογραφή σας';
$txt['profile_error_signature_disabled_bbc'] = 'Ο ακόλουθος κώδικας BBC δεν επιτρέπεται στην υπογραφή σας: %1$s';

$txt['profile_view_warnings'] = 'Εμφάνιση προειδοποιήσεων';
$txt['profile_issue_warning'] = 'Έκδοση προειδοποίησης';
$txt['profile_warning_level'] = 'Επίπεδο προειδοποίησης';
$txt['profile_warning_desc'] = 'Σε αυτό το τμήμα μπορείτε να ρυθμίσετε το επίπεδο προειδοποίησης του χρήστη και να τους απευθύνετε έγγραφη προειδοποίηση αν χρειάζεται. Μπορείτε επίσης να δείτε το ιστορικό προειδοποιήσεών του καθώς και τις επιπτώσεις του τρέχοντος επιπέδου προειδοποίησης όπως έχουν οριστεί από τον διαχειριστή.';
$txt['profile_warning_name'] = 'Όνομα μέλους';
$txt['profile_warning_impact'] = 'Αποτέλεσμα';
$txt['profile_warning_reason'] = 'Λόγος προειδοποίησης';
$txt['profile_warning_reason_desc'] = 'Αυτός είναι απαιτούμενος και θα καταγραφεί.';
$txt['profile_warning_effect_none'] = 'Κανένα.';
$txt['profile_warning_effect_watch'] = 'Το μέλος θα προστεθεί στη λίστα παρακολούθησης των συντονιστών.';
$txt['profile_warning_effect_own_watched'] = 'Είσαστε στην λίστα παρακολούθησης των συντονιστών.';
$txt['profile_warning_is_watch'] = 'υπό παρακολούθηση';
$txt['profile_warning_effect_moderate'] = 'Για όλα τα μηνύματα του μέλους θα απαιτείται έγκριση.';
$txt['profile_warning_effect_own_moderated'] = 'Όλα τα μηνύματά σας θα πρέπει να λαμβάνουν έγκριση.';
$txt['profile_warning_is_moderation'] = 'απαιτείται έγκριση μηνυμάτων';
$txt['profile_warning_effect_mute'] = 'Το μέλος δεν θα μπορεί να δημοσιεύσει μηνύματα.';
$txt['profile_warning_effect_own_muted'] = 'Δεν θα μπορείτε να δημοσιεύσετε μηνύματα.';
$txt['profile_warning_is_muted'] = 'δεν μπορεί να δημοσιεύσει μηνύματα';
$txt['profile_warning_effect_text'] = 'Επίπεδο >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Αποστολή ειδοποίησης';
$txt['profile_warning_notify_template'] = 'Επιλογή προτύπου:';
$txt['profile_warning_notify_subject'] = 'Τίτλος ειδοποίησης';
$txt['profile_warning_notify_body'] = 'Κείμενο ειδοποίησης';
$txt['profile_warning_notify_template_subject'] = 'Έχετε λάβει μια προειδοποίηση';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},

You have received a warning for %1$s. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},

You have received a warning for %1$s in regards to the message:
{MESSAGE}.

Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'spamming';
$txt['profile_warning_notify_title_spamming'] = 'Spamming';
$txt['profile_warning_notify_for_offence'] = 'δημοσίευση προσβλητικού υλικού';
$txt['profile_warning_notify_title_offence'] = 'Δημοσίευση προσβλητικού υλικού';
$txt['profile_warning_notify_for_insulting'] = 'προσβολή μελών ή/και συντονιστών/διαχειριστών';
$txt['profile_warning_notify_title_insulting'] = 'Προσβολή μελών ή/και συντονιστών/διαχειριστών';
$txt['profile_warning_issue'] = 'Έκδοση προειδοποίησης';
$txt['profile_warning_max'] = '(Μέγιστο 100)';
$txt['profile_warning_limit_attribute'] = 'Σημείωση: Δεν μπορείτε να μεταβάλετε το επίπεδο του μέλους πάνω από %1$d%% μέσα σε μια περίοδο 24 ωρών.';
$txt['profile_warning_errors_occurred'] = 'Η προειδοποίηση δεν στάλθηκε λόγω των παρακάτω σφαλμάτων';
$txt['profile_warning_success'] = 'Η προειδοποίηση έγινε επιτυχώς';
$txt['profile_warning_new_template'] = 'Νέο πρότυπο';

$txt['profile_warning_previous'] = 'Προηγούμενες προειδοποιήσεις';
$txt['profile_warning_previous_none'] = 'Το μέλος αυτό δεν έχει λάβει άλλες προειδοποιήσεις.';
$txt['profile_warning_previous_issued'] = 'Δόθηκε από';
$txt['profile_warning_previous_time'] = 'Χρόνος';
$txt['profile_warning_previous_level'] = 'Πόντοι';
$txt['profile_warning_previous_reason'] = 'Αιτιολογία';
$txt['profile_warning_previous_notice'] = 'Εμφάνιση σημείωσης που στάλθηκε στο μέλος';

$txt['viewwarning'] = 'Εμφάνιση προειδοποιήσεων';
$txt['profile_viewwarning_for_user'] = 'Προειδοποιήσεις για το μέλος %1$s';
$txt['profile_viewwarning_no_warnings'] = 'No warnings have been issued.';
$txt['profile_viewwarning_desc'] = 'Ακολουθεί περίληψη όλων των προειδοποιήσεων που έχουν δοθεί από την συντονιστική ομάδα του φόρουμ.';
$txt['profile_viewwarning_previous_warnings'] = 'Προηγούμενες προειδοποιήσεις';
$txt['profile_viewwarning_impact'] = 'Συνέπεια της προειδοποίησης';

$txt['subscriptions'] = 'Συνδρομές επί πληρωμή';

$txt['pm_settings_desc'] = 'Από αυτή τη σελίδα μπορείτε να αλλάξετε διάφορες επιλογές προσωπικών μηνυμάτων, συμπεριλαμβανομένου του πως εμφανίζονται τα μηνύματα και ποιος μπορεί να σας τα στέλνει.';
$txt['email_notify'] = 'Ειδοποίηση με e-mail κάθε φορά που λαμβάνετε ένα προσωπικό μήνυμα:';
$txt['email_notify_never'] = 'Ποτέ';
$txt['email_notify_buddies'] = 'Μόνο από φίλους';
$txt['email_notify_always'] = 'Πάντα';

$txt['receive_from'] = 'Members allowed to contact me:';
$txt['receive_from_everyone'] = 'Όλα τα μέλη';
$txt['receive_from_ignore'] = 'Όλα τα μέλη, εκτός από αυτά στην λίστα αγνοημένων';
$txt['receive_from_admins'] = 'Διαχειριστές μόνο';
$txt['receive_from_buddies'] = 'Φίλοι και Διαχειριστές μόνο';
$txt['receive_from_description'] = 'This setting applies to both Personal Messages and emails (if the option to email members is enabled)';

$txt['popup_messages'] = 'Εμφάνιση αναδυόμενου παραθύρου όταν λαμβάνω νέα μηνύματα.';
$txt['pm_remove_inbox_label'] = 'Remove the inbox label when applying another label.';
$txt['pm_display_mode'] = 'Εμφάνιση προσωπικών μηνυμάτων';
$txt['pm_display_mode_all'] = 'Όλα μαζί';
$txt['pm_display_mode_one'] = 'Ένα κάθε φορά';
$txt['pm_display_mode_linked'] = 'Ως συζήτηση';

$txt['history'] = 'History';
$txt['history_description'] = 'This section allows you to review certain profile actions performed on this member\'s profile as well as track their IP address and login history.';

$txt['trackEdits'] = 'Τροποποιήσεις προφίλ';
$txt['trackEdit_deleted_member'] = 'Διαγραμμένο μέλος';
$txt['trackEdit_no_edits'] = 'Δεν υπάρχουν τροποποιήσεις μέχρι στιγμής για αυτό το μέλος.';
$txt['trackEdit_action'] = 'Πεδίο';
$txt['trackEdit_before'] = 'Τιμή πριν';
$txt['trackEdit_after'] = 'Τιμή μετά';
$txt['trackEdit_applicator'] = 'Αλλάχθηκε από';

$txt['trackEdit_action_real_name'] = 'Όνομα μέλους';
$txt['trackEdit_action_usertitle'] = 'Προσαρμοσμένος τίτλος';
$txt['trackEdit_action_member_name'] = 'Όνομα χρήστη';
$txt['trackEdit_action_email_address'] = 'Διεύθυνση e-mail';
$txt['trackEdit_action_id_group'] = 'Κύρια ομάδα μελών';
$txt['trackEdit_action_additional_groups'] = 'Πρόσθετες ομάδες μελών';

$txt['otp_enabled_help'] = 'Enabling this will add a second factor (one-time password) for authentication.';
$txt['otp_token_help'] = 'This generates a secret token for time-based one-time password  apps such as Authy or Google Authenticator. Once the secret was generated use your favorite authenticator app and scan the qrcode.<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
