<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Κέντρο συντονισμού';
$txt['mc_main'] = 'Κύριο';
$txt['mc_logs'] = 'Αρχεία καταγραφής';
$txt['mc_posts'] = 'μηνύματα';
$txt['mc_groups'] = 'Members and groups';

$txt['mc_view_groups'] = 'Εμφάνιση ομάδων μελών';

$txt['mc_description'] = '<strong>Welcome, %1$s!</strong><br />This is your &quot;Moderation Center&quot;. From here you can perform all the moderation actions assigned to yourself by the Administrator. This home page contains a summary of all the latest happenings in your community. You can <a href="%2$s">personalize the layout by clicking here</a>.';
$txt['mc_group_requests'] = 'Αιτήσεις ένταξης σε ομάδα μελών';
$txt['mc_member_requests'] = 'Member Requests';
$txt['mc_unapproved_posts'] = 'Μηνήματα χωρίς έγκριση';
$txt['mc_watched_users'] = 'Recently Watched Members';
$txt['mc_watched_topics'] = 'Θέματα υπό παρακολούθηση';
$txt['mc_scratch_board'] = 'Moderator Scratch Board';
$txt['mc_latest_news'] = 'Latest News';
$txt['mc_recent_reports'] = 'Πρόσφατες αναφορές θεμάτων';
$txt['mc_warnings'] = 'Προειδοποιήσεις';
$txt['mc_notes'] = 'Σημειώσεις συντονιστών';
$txt['mc_required'] = 'Items Requiring Approval';
$txt['mc_attachments'] = 'Attachments needing approval';
$txt['mc_emailmod'] = 'Email Postings needing approval';
$txt['mc_topics'] = 'Topics needing approval';
$txt['mc_posts'] = 'μηνύματα';
$txt['mc_groupreq'] = 'Group requests needing approval';
$txt['mc_memberreq'] = 'Members needing approval';
$txt['mc_reports'] = 'Report posts needing approval';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'Δεν είναι δυνατή η σύνδεση με το αρχείο ενημερωμένων εκδόσεων του simplemachines.org.';

$txt['mc_recent_reports_none'] = 'Δεν υπάρχουν ιδιαίτερες αναφορές';
$txt['mc_watched_users_none'] = 'Δεν έχουν τεθεί παρακολουθήσεις προς το παρόν.';
$txt['mc_group_requests_none'] = 'Δεν υπάρχουν αιτήσεις για ένταξη σε ομάδες.';

$txt['mc_seen'] = '%1$s τελευταία σύνδεση %2$s';
$txt['mc_seen_never'] = '%1$s δεν εμφανίστηκε ποτέ';
$txt['mc_groupr_by'] = 'από';

$txt['mc_reported_posts_desc'] = 'Εδώ μπορείτε να όλες τις αναφορές για μηνύματα που έχουν υποβληθεί από μέλη της κοινότητας.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Ενεργές αναφορές';
$txt['mc_reportedp_closed'] = 'Παλιές αναφορές';
$txt['mc_reportedp_by'] = 'από';
$txt['mc_reportedp_reported_by'] = 'Αναφέρθηκε από';
$txt['mc_reportedp_last_reported'] = 'Αναφέρθηκε πιο πρόσφατα';
$txt['mc_reportedp_none_found'] = 'Δεν βρέθηκαν αναφορές';

$txt['mc_reportedp_details'] = 'Λεπτομέρειες';
$txt['mc_reportedp_close'] = 'Κλείσιμο';
$txt['mc_reportedp_open'] = 'Ανοικτές';
$txt['mc_reportedp_ignore'] = 'Dismiss';
$txt['mc_reportedp_unignore'] = 'Reopen';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Are you sure you wish to dismiss and ignore further reports about this message?

This will turn off further reports for all moderators of the forum.';
$txt['mc_reportedp_close_selected'] = 'Κλείσιμο επιλεγμένων';

$txt['mc_groupr_group'] = 'Ομάδες μελών';
$txt['mc_groupr_member'] = 'Μέλος';
$txt['mc_groupr_reason'] = 'Αιτιολογία';
$txt['mc_groupr_none_found'] = 'Δεν υπάρχουν προς το παρόν ιδιαίτερες αιτήσεις ένταξης σε ομάδα μελών.';
$txt['mc_groupr_submit'] = 'Υποβολή';
$txt['mc_groupr_reason_desc'] = 'Λόγος για την απόρριψη της αίτησης του %1$s για ένταξη στην ομάδα &quot;%2$s&quot;';
$txt['mc_groups_reason_title'] = 'Reasons for rejection';
$txt['with_selected'] = 'With selected';
$txt['mc_groupr_approve'] = 'Approve request';
$txt['mc_groupr_reject'] = 'Reject request (No Reason)';
$txt['mc_groupr_reject_w_reason'] = 'Reject request with reason';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Σίγουρα θέλετε να το κάνετε αυτό;';

$txt['mc_unapproved_attachments_none_found'] = 'Δεν βρέθηκαν μη εγκεκριμένα συνημμένα!';
$txt['mc_unapproved_attachments_desc'] = 'From here you can approve or delete any attachments awaiting moderation.';
$txt['mc_unapproved_replies_none_found'] = 'Δεν βρέθηκαν μη εγκεκριμένα μηνύματα!';
$txt['mc_unapproved_topics_none_found'] = 'Δεν βρέθηκαν μη εγκεκριμένα θέματα!';
$txt['mc_unapproved_posts_desc'] = 'Εδώ μπορείτε να εγκρίνετε ή να διαγράψετε τυχόν μηνύματα που περιμένουν συντονισμό.';
$txt['mc_unapproved_replies'] = 'Απαντήσεις';
$txt['mc_unapproved_topics'] = 'Θέματα';
$txt['mc_unapproved_by'] = 'από';
$txt['mc_unapproved_sure'] = 'Είστε βέβαιος ότι θέλετε να το κάνετε αυτό;';
$txt['mc_unapproved_attach_name'] = 'Όνομα συνημμένου';
$txt['mc_unapproved_attach_size'] = 'Μέγεθος αρχείου';
$txt['mc_unapproved_attach_poster'] = 'Αποστολέας';
$txt['mc_viewmodreport'] = 'Moderation report for %1$s by %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Μέλη που έχουν αναφέρει αυτό το μήνυμα';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Ενέργειες που έγιναν από άλλους συντονιστές';
$txt['mc_modreport_mod_comments'] = 'Σχόλια συντονιστή';
$txt['mc_modreport_no_mod_comment'] = 'Δεν υπάρχουν σχόλια συντονιστή αυτή τη στιγμή';
$txt['mc_modreport_add_mod_comment'] = 'Προσθήκη σχολίου';

$txt['show_notice'] = 'Κείμενο σημείωσης';
$txt['show_notice_subject'] = 'Τίτλος';
$txt['show_notice_text'] = 'Κείμενο';

$txt['mc_watched_users_title'] = 'Μέλη υπό παρακολούθηση';
$txt['mc_watched_users_desc'] = 'Εδώ μπορείτε να βλέπετε όλα τα μέλη που έχουν τεθεί &quot;υπό παρακολούθηση&quot; από την ομάδα συντονιστών.';
$txt['mc_watched_users_post'] = 'Εμφάνιση ανά μήνυμα';
$txt['mc_watched_users_warning'] = 'Επίπεδο προειδοποίησης';
$txt['mc_watched_users_last_login'] = 'Τελευταία σύνδεση';
$txt['mc_watched_users_last_post'] = 'Τελευταίο μήνυμα';
$txt['mc_watched_users_no_posts'] = 'Δεν υπάρχουν μηνύματα από μέλη υπό παρακολούθηση.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Σίγουρα θέλετε να διαγράψετε αυτό το μήνυμα;';
$txt['mc_watched_users_delete_posts'] = 'Σίγουρα θέλετε να διαγράψετε αυτά τα μηνύματα;';
$txt['mc_watched_users_posted'] = 'Posted';
$txt['mc_watched_users_member'] = 'Μέλος';

$txt['mc_warnings_description'] = 'Σε αυτήν την σελίδα μπορείτε να δείτε ποιες προειδοποιήσεις έχουν δοθεί σε μέλη του φόρουμ. Μπορείτε επίσης να προσθέσετε και να τροποποιήσετε τα πρότυπα ειδοποιήσεων που χρησιμοποιούνται όταν στέλνετε προειδοποίηση σε χρήστη.';
$txt['mc_warning_log'] = 'Αρχείο καταγραφής';
$txt['mc_warning_templates'] = 'Προσαρμοσμένα πρότυπα';
$txt['mc_warning_log_title'] = 'Viewing warning log';
$txt['mc_warning_templates_title'] = 'Custom warning templates';

$txt['mc_warnings_none'] = 'No warnings have been issued.';
$txt['mc_warnings_recipient'] = 'Παραλήπτης';

$txt['mc_warning_templates_none'] = 'Δεν έχουν οριστεί ακόμα πρότυπα προειδοποιήσεων';
$txt['mc_warning_templates_time'] = 'Δημιουργήθηκε στις';
$txt['mc_warning_templates_name'] = 'Πρότυπα';
$txt['mc_warning_templates_creator'] = 'Δημιουργήθηκε από';
$txt['mc_warning_template_add'] = 'Προσθήκη πρότυπου';
$txt['mc_warning_template_modify'] = 'Τροποποίηση πρότυπου';
$txt['mc_warning_template_delete'] = 'Διαγραφή επιλεγμένων';
$txt['mc_warning_template_delete_confirm'] = 'Σίγουρα θέλετε να διαγράψετε τα επιλεγμένα πρότυπα;';

$txt['mc_warning_template_desc'] = 'Use this page to fill in the details of the template. Note that the subject for the email is not part of the template. Note that as the notification is sent by PM you can use BBC within the template. If you use the {MESSAGE} variable then this template will not be available when issuing a generic warning (i.e. A warning not linked to a post).';
$txt['mc_warning_template_title'] = 'Τίτλος προτύπου';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Προσωπικό πρότυπο';
$txt['mc_warning_template_personal_desc'] = 'Αν επιλέξετε αυτήν την επιλογή τότε μόνο εσείς θα μπορείτε να δείτε, τροποποιήσετε, και να χρησιμοποιήσετε αυτό το πρότυπο. Αν δεν το επιλέξετε, όλοι οι συντονιστές θα μπορούν να χρησιμοποιήσουν αυτό το πρότυπο.';
$txt['mc_warning_template_error_no_title'] = 'You must set the title.';
$txt['mc_warning_template_error_no_body'] = 'You must set the notification body.';

$txt['mc_settings'] = 'Αλλαγή ρυθμίσεων';
$txt['mc_prefs_title'] = 'Προτιμήσεις συντονισμού';
$txt['mc_prefs_desc'] = 'Αυτό το τμήμα σας επιτρέπει να ορίσετε μερικές προσωπικές προτιμήσεις για συντονιστικές ενέργειες όπως ειδοποιήσεις με email.';
$txt['mc_prefs_homepage'] = 'Αντικείμενα που θα εμφανίζονται στην κεντρική σελίδα συντονισμού';
$txt['mc_prefs_latest_news'] = 'ElkArte News';
$txt['mc_prefs_show_reports'] = 'Εμφάνιση αριθμού ανοικτών αναφορών στην επικεφαλίδα του φόρουμ';
$txt['mc_prefs_notify_report'] = 'Ειδοποίηση για αναφορές θεμάτων';
$txt['mc_prefs_notify_report_never'] = 'Ποτέ';
$txt['mc_prefs_notify_report_moderator'] = 'Μόνο αν είναι πίνακας που συντονίζω';
$txt['mc_prefs_notify_report_always'] = 'Πάντα';
$txt['mc_prefs_notify_approval'] = 'Ειδοποίηση για αντικείμενα που περιμένουν έγκριση';
$txt['mc_logoff'] = 'End Moderator Session';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Προσθήκη νέας σημείωσης';
$txt['mc_add_note'] = 'Προσθήκη';