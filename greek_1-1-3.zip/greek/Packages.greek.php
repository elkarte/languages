<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Συνέχεια';
$txt['package_id'] = 'Αναγνωριστικό (ID)';
$txt['list_file'] = 'Λίστα αρχείων του πακέτου';
$txt['files_archive'] = 'Αρχεία στο πακέτο';
$txt['package_browse'] = 'Αναζήτηση';
$txt['add_server'] = 'Προσθήκη διακομιστή';
$txt['server_name'] = 'Όνομα διακομιστή';
$txt['serverurl'] = 'URL';
$txt['no_packages'] = 'Δεν υπάρχουν πακέτα.';
$txt['download'] = 'Λήψη';
$txt['download_success'] = 'Το πακέτο παρελήφθη επιτυχώς';
$txt['package_downloaded_successfully'] = 'Το πακέτο παρελήφθη επιτυχώς';
$txt['package_manager'] = 'Διαχείριση πακέτων';
$txt['install_mod'] = 'Install Add-on';
$txt['uninstall_mod'] = 'Uninstall Add-on';
$txt['no_adds_installed'] = 'No addons currently installed';
$txt['uninstall'] = 'Απεγκατάσταση';
$txt['delete_list'] = 'Delete Add-on List';
$txt['package_delete_list_warning'] = 'Are you sure you wish to clear the installed addons list?';

$txt['package_manager_desc'] = 'From this easy to use interface, you can download and install addons for use on your forum.';
$txt['installed_packages_desc'] = 'Μπορείτε να χρησιμοποιήσετε το παρακάτω αλληλεπιδραστικό εργαλείο για να δείτε τα πακέτα που έχουν εγκατασταθεί, και να αφαιρέσετε αυτά που δεν είναι πλέον απαραίτητα.';
$txt['download_packages_desc'] = 'From this section you can add or remove package servers, browse for packages, or download new packages from servers.';
$txt['package_servers_desc'] = 'From this easy to use interface, you can manage your package servers and download addon archives on your forum.';
$txt['upload_packages_desc'] = 'From this section you can upload a package file from your local computer directly to the forum.';

$txt['upload_new_package'] = 'Upload new package';
$txt['view_and_remove'] = 'View and remove installed packages';
$txt['modification_package'] = 'Add-on packages';
$txt['avatar_package'] = 'Avatar packages';
$txt['language_package'] = 'Language packages';
$txt['unknown_package'] = 'Other packages';
$txt['smiley_package'] = 'Smiley packages';
$txt['use_avatars'] = 'Χρήση πορτραίτων';
$txt['add_languages'] = 'Προσθήκη γλώσσας';
$txt['list_files'] = 'Λίστα αρχείων';
$txt['package_type'] = 'Τύπος πακέτου';
$txt['extracting'] = 'Εξαγωγή';
$txt['avatars_extracted'] = 'The avatars have been installed, you should now be able to use them.';
$txt['language_extracted'] = 'The language pack has been installed, you can now enable its use in the language settings area of your admin control panel.';

$txt['mod_name'] = 'Add-on Name';
$txt['mod_version'] = 'Έκδοση';
$txt['mod_author'] = 'Αποστολέας';
$txt['author_website'] = 'Ιστότοπος δημιουργού';
$txt['package_no_description'] = 'No description given';
$txt['package_description'] = 'Περιγραφή';
$txt['file_location'] = 'Λήψη';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'No source edits';
$txt['mod_date'] = 'Last updated';
$txt['mod_section_count'] = 'Browse the (%1d) addons in this section';

// Package Server strings
$txt['package_current'] = '(%s <em>You have the Current version %s</em>)';
$txt['package_update'] = '(%s <em>An update for your %s version is available</em>)';
$txt['package_installed'] = 'installed';
$txt['package_downloaded'] = 'έγινε λήψη';

$txt['package_installed_key'] = 'Installed addons:';
$txt['package_installed_current'] = 'τρέχουσα έκδοση';
$txt['package_installed_old'] = 'παλαιότερη έκδοση';
$txt['package_installed_warning1'] = 'This package is already installed, and no upgrade was found.';
$txt['package_installed_warning2'] = 'Πρέπει να απεγκαταστήσετε πρώτα την παλιά έκδοση για να αποφύγετε τα προβλήματα, ή ζητήστε από τον δημιουργό να δημιουργήσει μια αναβάθμιση από την παλιά σας έκδοση.';
$txt['package_installed_warning3'] = 'Θυμηθείτε να παίρνετε πάντα συχνά backup των πηγαίων αρχείων και της βάσης δεδομένων πριν την εγκατάσταση τροποποιήσεων, ιδιαίτερα εκδόσεων beta.';
$txt['package_installed_extract'] = 'Εξαγωγή πακέτου';
$txt['package_installed_done'] = 'Το πακέτο εγκαταστάθηκε επιτυχώς.  Θα πρέπει να μπορείτε να χρησιμοποιήσετε οποιαδήποτε λειτουργία προσθέτει ή αλλάζει, ή να μη μπορείτε να χρησιμοποιήσετε λειτουργίες που αφαιρεί.';
$txt['package_installed_redirecting'] = 'Ανακατεύθυνση...';
$txt['package_installed_redirect_go_now'] = 'Ανακατεύθυνση τώρα';
$txt['package_installed_redirect_cancel'] = 'Επιστροφή στη διαχείριση πακέτων';

$txt['package_upgrade'] = 'Αναβάθμιση';
$txt['package_uninstall_readme'] = 'Διάβασέ-με απεγκατάστασης';
$txt['package_install_readme'] = 'Σημειώσεις εγκατάστασης (Readme)';
$txt['package_install_license'] = 'License';
$txt['package_install_type'] = 'Τύπος';
$txt['package_install_action'] = 'Ενέργεια';
$txt['package_install_desc'] = 'Περιγραφή';
$txt['install_actions'] = 'Ενέργειες εγκατάστασης';
$txt['perform_actions'] = 'This will perform the following actions:';
$txt['corrupt_compatible'] = 'The package you are trying to download or install is either corrupt or not compatible with this version of the software.';
$txt['package_create'] = 'Δημιουργία';
$txt['package_move'] = 'Μετακίνηση';
$txt['package_delete'] = 'Διαγραφή';
$txt['package_extract'] = 'Εξαγωγή';
$txt['package_file'] = 'Αρχείο';
$txt['package_tree'] = 'Δένδρο';
$txt['execute_modification'] = 'Εκτέλεση τροποποίησης';
$txt['execute_code'] = 'Εκτέλεση κώδικα';
$txt['execute_database_changes'] = 'Execute file';
$txt['execute_hook_add'] = 'Add Hook';
$txt['execute_hook_remove'] = 'Remove Hook';
$txt['execute_hook_action'] = 'Adapting hook %1$s';
$txt['package_requires'] = 'Requires Modification';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Add Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'Ενέργειες εγκατάστασης για';
$txt['package_will_fail_title'] = 'Error in package %1$s';
$txt['package_will_fail_warning'] = 'At least one error was encountered during a test %1$s of this package.<br />It is <strong>strongly</strong> recommended that you do not continue with %1$s unless you know what you are doing, and have made a backup very recently.<br /><br />This error may be caused by a conflict between the package you\'re trying to install and another package you have already installed, an error in the package, a package which requires another package that you have not installed yet, or a package designed for another version of the software.';
$txt['package_will_fail_unknown_action'] = 'The package is trying to perform an unknown action: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Are you sure you wish to continue installing this addon, even though it will not install successfully?';
$txt['package_will_fail_popup_uninstall'] = 'Are you sure you wish to continue uninstalling this addon, even though it will not uninstall successfully?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'removal';
$txt['package_install_now'] = 'Install now';
$txt['package_uninstall_now'] = 'Uninstall now';
$txt['package_other_themes'] = 'Install in other themes';
$txt['package_other_themes_uninstall'] = 'UnInstall in other themes';
$txt['package_other_themes_desc'] = 'To use this addon in themes other than the default, the package manager needs to make additional changes to the other themes. If you\'d like to install this addon in the other themes, please select these themes below.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Τουλάχιστον ένα σφάλμα συνέβη κατα τη διάρκεια πειραματικής εγκατάστασης αυτής της εμφάνισης. Σίγουρα θέλετε να επιχειρήσετε την εγκατάσταση;';

$txt['package_bytes'] = 'bytes';

$txt['package_action_missing'] = '<strong class="error">Το αρχείο δε βρέθηκε</strong>';
$txt['package_action_error'] = '<strong class="error">Σφάλμα στο αρχείο τροποποίησης</strong>';
$txt['package_action_failure'] = '<strong class="error">Το τεστ απέτυχε</strong>';
$txt['package_action_success'] = '<strong>Το τεστ ήταν επιτυχές</strong>';
$txt['package_action_skipping'] = '<strong>Παράβλεψη αρχείου</strong>';

$txt['package_uninstall_actions'] = 'Ενέργειες απεγκατάστασης';
$txt['package_uninstall_done'] = 'The package has been successfully uninstalled.';
$txt['package_uninstall_cannot'] = 'This package cannot be uninstalled, because there is no uninstaller.<br /><br />Please contact the addon author for more information.';

$txt['package_install_options'] = 'Επιλογές εγκατάστασης';
$txt['package_install_options_desc'] = 'Set various options for how the package manager installs addons, including backups and ftp access';
$txt['package_install_options_ftp_why'] = 'Η χρήση της λειτουργίας FTP του Διαχειριστή Πακέτων είναι ο ευκολότερος τρόπος για να αποφύγετε να αλλάζετε χειροκίνητα τα δικαιώματα των αρχείων (chmod) σε εγγράψιμα για να λειτουργήσει ο διαχειριστής πακέτων.<br />Εδώ μπορείτε να ορίσετε προκαθορισμένες τιμές για κάποια πεδία.';
$txt['package_install_options_ftp_server'] = 'Διακομιστής FTP';
$txt['package_install_options_ftp_port'] = 'Θύρα';
$txt['package_install_options_ftp_user'] = 'Όνομα χρήστη';
$txt['package_install_options_make_backups'] = 'Δημιουργία εκδόσεων Backup των αντικατεστημένων αρχείων με μια περισπωμένη (~) στο τέλος των ονομάτων των.';
$txt['package_install_options_make_full_backups'] = 'Create an entire backup (excluding smileys, avatars and attachments) of the ElkArte install.';

$txt['package_ftp_necessary'] = 'Οι πληροφορίες FTP είναι απαιτούμενες';
$txt['package_ftp_why'] = 'Some of the files the package manager needs to modify are not writable.  This needs to be changed by logging into FTP and using it to chmod or create the files and directories.  Your FTP information may be temporarily cached for proper operation of the package manager. Note you can also do this manually using an FTP client - <a href="#" onclick="%1$s">to view a list of the affected files please click here</a>.';
$txt['package_ftp_why_file_list'] = 'Τα παρακάτω αρχεία πρέπει να γίνουν εγγράψιμα για να συνεχιστεί η εγκατάσταση:';
$txt['package_ftp_why_download'] = 'In order to download packages, the packages directory, and any files in it, must be writable.  Currently the system does not have the needed permissions to write to this directory.  The package manager can use your FTP information to attempt to fix this problem.';
$txt['package_ftp_server'] = 'Διακομιστής FTP';
$txt['package_ftp_port'] = 'Θύρα';
$txt['package_ftp_username'] = 'Όνομα χρήστη';
$txt['package_ftp_password'] = 'Κωδικός';
$txt['package_ftp_path'] = 'Local path to ElkArte';
$txt['package_ftp_test'] = 'Δοκιμή';
$txt['package_ftp_test_connection'] = 'Δοκιμή σύνδεσης';
$txt['package_ftp_test_success'] = 'Η σύνδεση FTP αποκαταστάθηκε.';
$txt['package_ftp_test_failed'] = 'Αποτυχία σύνδεσης με τον διακομιστή.';
$txt['package_ftp_bad_server'] = 'Αποτυχία σύνδεσης με τον διακομιστή.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Το πακέτο που πρόκειται να διαγράψετε είναι εγκατεστημένο!  Αν το διαγράψετε, ίσως να μη μπορέσετε να το απεγκαταστήσετε αργότερα.\\n\\nΣίγουρα θέλετε να το κάνετε;';

$txt['package_examine_file'] = 'Εμφάνιση αρχείου στο πακέτο';
$txt['package_file_contents'] = 'Περιεχόμενα αρχείου';

$txt['package_upload_title'] = 'Αποστολή πακέτου';
$txt['package_upload_select'] = 'Πακέτο προς αποστολή';
$txt['package_upload'] = 'Αποστολή';
$txt['package_uploaded_success'] = 'Το πακέτο απεστάλη με επιτυχία';
$txt['package_uploaded_successfully'] = 'Το πακέτο έχει αποσταλεί με επιτυχία';

$txt['package_modification_malformed'] = 'Malformed or invalid addon file.';
$txt['package_modification_missing'] = 'Το αρχείο δεν βρέθηκε.';
$txt['package_no_zlib'] = 'Λυπάμαι, οι ρυθμίσεις του PHP δεν παρέχουν υποστήριξη για <strong>zlib</strong>.  Χωρίς αυτό, το πρόγραμμα διαχείρισης πακέτων δεν μπορεί να λειτουργήσει.  Παρακαλώ επικοινωνήστε με τον παροχέα σας για περισσότερες πληροφορίες.';

$txt['package_cleanperms_title'] = 'Καθαρισμός δικαιωμάτων';
$txt['package_cleanperms_desc'] = 'Οι παρακάτω επιλογές σας επιτρέπουν να επαναφέρετε τα δικαιώματα των αρχείων σε όλη την εγκατάστασή σας, για να αυξήσετε την ασφάλεια ή να λύσετε προβλήματα δικαιωμάτων που πιθανόν έχετε κατά την εγκατάσταση πακέτων.';
$txt['package_cleanperms_type'] = 'Αλλαγή όλων των δικαιωμάτων αρχείων παντού στο φόρουμ έτσι ώστε';
$txt['package_cleanperms_standard'] = 'Μόνο συγκεκριμένα αρχεία είναι εγγράψιμα.';
$txt['package_cleanperms_free'] = 'Όλα τα αρχεία είναι εγγράψιμα.';
$txt['package_cleanperms_restrictive'] = 'Τα ελάχιστα δυνατά αρχεία είναι εγγράψιμα.';
$txt['package_cleanperms_go'] = 'Αλλαγή δικαιωμάτων αρχείων';

$txt['package_download_by_url'] = 'Λήψη πακέτου από διεύθυνση URL';
$txt['package_download_filename'] = 'Όνομα αρχείου';
$txt['package_download_filename_info'] = 'Προαιρετική τιμή.  Χρησιμοποιείται όταν το URL δεν τελειώνει με το όνομα αρχείου.  Για παράδειγμα: index.php?mod=5';

$txt['package_db_uninstall'] = 'Remove all data associated with this addon.';
$txt['package_db_uninstall_details'] = 'Λεπτομέρειες';
$txt['package_db_uninstall_actions'] = 'Checking this option will result in the following actions';
$txt['package_db_remove_table'] = 'Διαγραφή πίνακα &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Αφαίρεση στήλης &quot;%1$s&quot; από &quot;%2$s&quot;';
$txt['package_db_remove_index'] = 'Αφαίρεση δείκτη &quot;%1$s&quot; από &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Install Emulating:';
$txt['package_emulate_uninstall'] = 'Uninstall Emulating:';

// Operations.
$txt['operation_find'] = 'Εύρεση';
$txt['operation_replace'] = 'Αντικατάσταση';
$txt['operation_after'] = 'Προσθήκη μετά';
$txt['operation_before'] = 'Προσθήκη πριν';
$txt['operation_title'] = 'Ενέργειες';
$txt['operation_ignore'] = 'Αγνόηση σφαλμάτων';
$txt['operation_invalid'] = 'Η ενέργεια που επιλέξατε είναι άκυρη.';

$txt['package_file_perms_desc'] = 'Μπορείτε να χρησιμοποιήσετε αυτήν την περιοχή για να επιθεωρήσετε την κατάσταση εγγραψιμότητας κρίσιμων αρχείων και φακέλων μέσα στον φάκελο του φόρουμ σας. Σημειώστε ότι αυτό αφορά μόνο σε σημαντικούς φακέλος και αρχεία. Χρησιμοποιήστε έναν πελάτη FTP για πρόσθετες επιλογές.';
$txt['package_file_perms_name'] = 'File/Directory Name';
$txt['package_file_perms_status'] = 'Τρέχουσα κατάσταση';
$txt['package_file_perms_new_status'] = 'Νέα κατάσταση';
$txt['package_file_perms_status_read'] = 'Αναγνώστηκε';
$txt['package_file_perms_status_write'] = 'Εγγραφή';
$txt['package_file_perms_status_execute'] = 'Εκτέλεση';
$txt['package_file_perms_status_custom'] = 'Προσαρμοσμένη';
$txt['package_file_perms_status_no_change'] = 'Καμία αλλαγή';
$txt['package_file_perms_writable'] = 'Εγγράψιμο';
$txt['package_file_perms_not_writable'] = 'Μη εγγράψιμο';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Περισσότερα αρχεία';

$txt['package_file_perms_change'] = 'Αλλαγή δικαιωμάτων αρχείων';
$txt['package_file_perms_predefined'] = 'Χρήση προκαθορισμένων προφίλ δικαιωμάτων';
$txt['package_file_perms_predefined_note'] = 'Note that this only applies the predefined profile to key directories and files.';
$txt['package_file_perms_apply'] = 'Εφαρμογή μεμονωμένων δικαιωμάτων αρχείων που επιλέχθηκαν παραπάνω.';
$txt['package_file_perms_custom'] = 'Αν έχει επιλεχθεί το &quot;Προσαρμοσμένη&quot; τότε χρήση chmod με τιμή';
$txt['package_file_perms_pre_restricted'] = 'Περιορισμένη - το ελάχιστο δυνατό πλήθος αρχείων να είναι εγγράψιμο';
$txt['package_file_perms_pre_standard'] = 'Κανονική - σημαντικά αρχεία να είναι εγγράψιμα';
$txt['package_file_perms_pre_free'] = 'Ελεύθερη - όλα τα αρχεία να είναι εγγράψιμα';
$txt['package_file_perms_ftp_details'] = 'Στους περισσότερους διακομιστές είναι δυνατόν να αλλαχθούν τα δικαιώματα αρχείων μόνο με έναν λογαριασμό FTP. Παρακαλούμε δώστε τα στοιχεία της σύνδεσης FTP παρακάτω';
$txt['package_file_perms_ftp_retain'] = 'Note, the system will only retain the password information temporarily to aid operation of the package manager.';
$txt['package_file_perms_go'] = 'Εφαρμογή αλλαγών';

$txt['package_file_perms_applying'] = 'Εφαρμόζονται οι αλλαγές';
$txt['package_file_perms_items_done'] = '%1$d από %2$d αντικείμενα ολοκληρώθηκαν';
$txt['package_file_perms_skipping_ftp'] = '<strong>Προειδοποίηση:</strong> Αποτυχία σύνδεσης με τον διακομιστή FTP, γίνεται προσπάθεια για αλλαγή των δικαιωμάτων χωρίς αυτόν. Αυτό είναι <em>πιθανό</em> να αποτύχει, παρακαλούμε ελέγξτε τα αποτελέσματα μετά την ολοκλήρωση και δοκιμάστε ξανά με τα σωστά στοιχεία σύνδεσης FTP αν είναι απαραίτητο.';

$txt['package_file_perms_dirs_done'] = '%1$d από %2$d φάκελοι ολοκληρώθηκαν';
$txt['package_file_perms_files_done'] = '%1$d από %2$d αρχεία ολοκληρώθηκαν στον τρέχον φάκελο';

$txt['chmod_value_invalid'] = 'Δώσατε μια μη έγκυρη τιμή chmod. Το chmod πρέπει να είναι μεταξύ 0444 και 0777';

$txt['package_restore_permissions'] = 'Restore file permissions';
$txt['package_restore_permissions_desc'] = 'The following file permissions were changed in order to install the selected package(s). You can return these files back to their original status by clicking &quot;Restore&quot; below.';
$txt['package_restore_permissions_restore'] = 'Επαναφορά';
$txt['package_restore_permissions_filename'] = 'Όνομα αρχείου';
$txt['package_restore_permissions_orig_status'] = 'Αρχική κατάσταση';
$txt['package_restore_permissions_cur_status'] = 'Τρέχουσα κατάσταση';
$txt['package_restore_permissions_result'] = 'Αποτέλεσμα';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - ήταν %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Παραλείφθηκε</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Success</span>';
$txt['package_restore_permissions_action_failure'] = '<span style="color: red;">Αποτυχία</span>';
$txt['package_restore_permissions_action_done'] = 'An attempt to restore the selected files back to their original permissions has been completed, the results can be seen below. If a change failed, or for a more detailed view of file permissions, please see the <a href="%1$s">File Permissions</a> section.';

$txt['package_file_perms_warning'] = 'Παρακαλούμε σημειώστε';
$txt['package_file_perms_warning_desc'] = '
	Be careful when changing file permissions from this section - incorrect permissions can adversely affect the operation of your forum!<br />
	On some server configurations selecting the wrong permissions may stop the forum from operating.<br />
	Certain directories such as <em>attachments</em> need to be writable to use that functionality.<br />
	This functionality is mainly applicable on non-Windows based servers - it will not work as expected on Windows in regards to permission flags.<br />
	Before proceeding make sure you have an FTP client installed in case you do make an error and need to FTP into the server to remedy it.';

$txt['package_confirm_view_package_content'] = 'Σίγουρα θέλετε να δείτε τα περιεχόμενα του πακέτου από αυτήν την τοποθεσία:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Συνέχεια';
$txt['package_confirm_go_back'] = 'Πίσω';

$txt['package_readme_default'] = 'Προεπιλεγμένο';
$txt['package_available_readme_language'] = 'Διαθέσιμες γλώσσες για το Διάβασέ-με:';
$txt['package_license_default'] = 'Προεπιλεγμένο';
$txt['package_available_license_language'] = 'Available License Languages:';