<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Προεπιλεγμένη εμφάνιση ElkArte .<br /><br /> Δημιουργός: Συνεισφορά ElkArte ';