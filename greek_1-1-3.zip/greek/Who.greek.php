<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... no idea, sorry</em>';
$txt['who_admin'] = 'Viewing the admin portal';
$txt['who_moderate'] = 'Viewing the moderator portal';
$txt['who_generic'] = 'Viewing the %1$s';
$txt['who_unknown'] = '<em>Άγνωστη ενέργεια</em>';
$txt['who_user'] = 'χρήστης';
$txt['who_time'] = 'Χρόνος';
$txt['who_action'] = 'Ενέργεια';
$txt['who_show1'] = 'Εμφάνιση ';
$txt['who_show_members_only'] = 'Μόνο μέλη';
$txt['who_show_guests_only'] = 'Μόνο επισκέπτες';
$txt['who_show_spiders_only'] = 'Μόνο αράχνες';
$txt['who_show_all'] = 'Όλοι';
$txt['who_no_online_spiders'] = 'Δεν υπάρχουν συνδεδεμένες αράχνες αυτήν την στιγμή.';
$txt['who_no_online_guests'] = 'Δεν υπάρχουν συνδεδεμένοι επισκέπτες αυτή τη στιγμή.';
$txt['who_no_online_members'] = 'Δεν υπάρχουν συνδεδεμένα μέλη αυτή τη στιγμή.';

$txt['whospider_login'] = 'Βλέπει τη σελίδα σύνδεσης.';
$txt['whospider_register'] = 'Βλέπει τη σελίδα εγγραφής.';
$txt['whospider_reminder'] = 'Βλέπει τη σελίδα υπενθύμισης.';

$txt['whoall_activate'] = 'Ενεργοποιεί τον λογαριασμό του.';
$txt['whoall_buddy'] = 'Τροποποιεί τη λίστα φίλων.';
$txt['whoall_coppa'] = 'Συμπληρώνει τη φόρμα γονέα/κηδεμόνα.';
$txt['whoall_credits'] = 'Βλέπει τη σελίδα με τα εύσημα.';
$txt['whoall_emailuser'] = 'Στέλνει email σε άλλον χρήστη.';
$txt['whoall_groups'] = 'Βλέπει τη σελίδα ομάδων χρηστών.';
$txt['whoall_help'] = 'Viewing the <a href="{help_url}">help page</a>.';
$txt['whoall_quickhelp'] = 'Διαβάζει ένα παράθυρο βοήθειας.';
$txt['whoall_pm'] = 'Διαβάζει τα προσωπικά του μηνύματά.';
$txt['whoall_auth'] = 'Συνδέεται στο φόρουμ.';
$txt['whoall_login'] = 'Βλέπει τη σελίδα σύνδεσης.';
$txt['whoall_login2'] = 'Βλέπει τη σελίδα σύνδεσης.';
$txt['whoall_logout'] = 'Αποσυνδέεται από το φόρουμ.';
$txt['whoall_markasread'] = 'Ορίζει θέματα ως αναγνωσμένα ή μη αναγνωσμένα.';
$txt['whoall_mentions'] = 'Viewing their mentions list.';
$txt['whoall_modifykarma_applaud'] = 'Επιδοκιμάζει ένα μέλος.';
$txt['whoall_modifykarma_smite'] = 'Αποδοκιμάζει ένα μέλος.';
$txt['whoall_news'] = 'Διαβάζει τα νέα.';
$txt['whoall_notify'] = 'Αλλάζει τις ρυθμίσεις ειδοποιήσεων.';
$txt['whoall_notifyboard'] = 'Αλλάζει τις ρυθμίσεις ειδοποιήσεων.';
$txt['whoall_openidreturn'] = 'Συνδέεται χρησιμοποιώντας OpenID.';
$txt['whoall_quickmod'] = 'Συντονίζει ένα πίνακα.';
$txt['whoall_recent'] = 'Viewing a <a href="{recent_url}">list of recent topics</a>.';
$txt['whoall_register'] = 'Εγγράφεται για ένα λογαριασμό στο φόρουμ.';
$txt['whoall_reminder'] = 'Ζητά υπενθύμιση κωδικού.';
$txt['whoall_reporttm'] = 'Αναφέρει κάποιο θέμα σε συντονιστή.';
$txt['whoall_spellcheck'] = 'Χρησιμοποιεί τον ορθογραφικό έλεγχο';
$txt['whoall_unread'] = 'Διαβάζει μη αναγνωσμένα θέματα από την τελευταία του επίσκεψη.';
$txt['whoall_unreadreplies'] = 'Διαβάζει μη αναγνωσμένες απαντήσεις από την τελευταία του επίσκεψη.';
$txt['whoall_who'] = 'Viewing <a href="{who_url}">Who\'s Online</a>.';

$txt['whoall_collapse_collapse'] = 'Συμπτύσσει μια κατηγορία.';
$txt['whoall_collapse_expand'] = 'Αναπτύσσει μια κατηγορία.';
$txt['whoall_pm_removeall'] = 'Διαγράφει όλα τα προσωπικά του μηνύματα.';
$txt['whoall_pm_send'] = 'Στέλνει προσωπικό μήνυμα.';
$txt['whoall_pm_send2'] = 'Στέλνει προσωπικό μήνυμα.';

$txt['whotopic_announce'] = 'Announcing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Εγκρίνει ένα συνημμένο.';
$txt['whotopic_dlattach'] = 'Βλέπει ένα συνημμένο.';
$txt['whotopic_deletemsg'] = 'Διαγράφει ένα μήνυμα.';
$txt['whotopic_editpoll'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Modifying a post in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Liking a message in the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Locking the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Locking the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Merging the topic &quot;<a href="%1$s">%2$s</a>&quot; with another topic.';
$txt['whotopic_movetopic'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_movetopic2'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_post'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Printing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderating the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Removing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Removing the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Sending the topic &quot;<a href="%1$s">%2$s</a>&quot; to a friend.';
$txt['whotopic_splittopics'] = 'Splitting the topic &quot;<a href="%1$s">%2$s</a>&quot; into two topics.';
$txt['whotopic_sticky'] = 'Pinned the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Stopped watching a topic.';
$txt['whotopic_vote'] = 'Voting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Started watching a topic.';

$txt['whopost_quotefast'] = 'Quoting a post from &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Τροποποιεί το συμφωνητικό εγγραφής.';
$txt['whoadmin_featuresettings'] = 'Τροποποιεί λειτουργίες και επιλογές του φόρουμ.';
$txt['whoadmin_modlog'] = 'Διαβάζει το αρχείο καταγραφής συντονιστών.';
$txt['whoadmin_serversettings'] = 'Τροποποιεί ρυθμίσεις του φόρουμ.';
$txt['whoadmin_packageget'] = 'Λαμβάνει πακέτα.';
$txt['whoadmin_packages'] = 'Βλέπει τον διαχειριστή πακέτων.';
$txt['whoadmin_permissions'] = 'Τροποποιεί δικαιώματα του φόρουμ.';
$txt['whoadmin_pgdownload'] = 'Λαμβάνει ένα πακέτο.';
$txt['whoadmin_theme'] = 'Τροποποιεί επιλογές εμφάνισης.';
$txt['whoadmin_trackip'] = 'Ανιχνεύει μια διεύθυνση IP.';

$txt['whoallow_manageboards'] = 'Τροποποιεί τις ρυθμίσεις πινάκων και κατηγοριών.';
$txt['whoallow_admin'] = 'Viewing the <a href="{admin_url}">administration center</a>.';
$txt['whoallow_ban'] = 'Τροποποιεί τη λίστα αποκλεισμών.';
$txt['whoallow_boardrecount'] = 'Επαναϋπολογίζει τα σύνολα του φόρουμ.';
$txt['whoallow_calendar'] = 'Viewing the <a href="{calendar_url}">calendar</a>.';
$txt['whoallow_editnews'] = 'Τροποποιεί τα νέα.';
$txt['whoallow_mailing'] = 'Αποστέλλει e-mail στα μέλη του φόρουμ.';
$txt['whoallow_maintain'] = 'Πραγματοποιεί συντήρηση ρουτίνας στο φόρουμ.';
$txt['whoallow_manageattachments'] = 'Διαχειρίζεται τα συνημμένα.';
$txt['whoallow_moderate'] = 'Viewing the <a href="{moderate_url}">Moderation Center</a>.';
$txt['whoallow_memberlist'] = 'Viewing the <a href="{memberlist_url}">member list</a>.';
$txt['whoallow_optimizetables'] = 'Βελτιστοποιεί τους πίνακες της βάσης δεδομένων.';
$txt['whoallow_repairboards'] = 'Επιδιορθώνει τους πίνακες της βάσης δεδομένων.';
$txt['whoallow_search'] = '<a href="{search_url}">Searching</a> the forum.';
$txt['whoallow_search_results'] = 'Βλέπει τα αποτελέσματα μιας αναζήτησης.';
$txt['whoallow_setcensor'] = 'Τροποποιεί το κείμενο απαγορευμένων λέξεων.';
$txt['whoallow_setreserve'] = 'Τροποποιεί τα δεσμευμένα ονόματα.';
$txt['whoallow_stats'] = 'Viewing the <a href="{stats_url}">forum stats</a>.';
$txt['whoallow_viewErrorLog'] = 'Διαβάζει το αρχείο καταγραφής λαθών.';
$txt['whoallow_viewmembers'] = 'Βλέπει τη λίστα μελών.';

$txt['who_topic'] = 'Viewing the topic <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Viewing the board <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Viewing the board index of <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Viewing <a href="%1$s">%2$s</a>\'s profile.';
$txt['who_profile'] = 'Editing the profile of <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Posting a new topic in <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Posting a new poll in <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Email starting a new topic in <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Email posting in <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Sending a personal message by email.';

// Credits text
$txt['credits'] = 'Συντελεστές';
$txt['credits_intro'] = 'ElkArte is 100% free and open-source. We encourage and support an active, open community that accepts contributions from the public.  We want to thank everyone who supported the project by providing code, feedback, bug reports, and opinions, as none of this would have been possible without you.  We also want to specially acknowledge <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, the project that ElkArte was born from.';
$txt['credits_contributors'] = 'Contributors';
$txt['credits_and'] = 'και';
$txt['credits_copyright'] = 'Πνευματικά δικαιώματα';
$txt['credits_forum'] = 'Φόρουμ';
$txt['credits_addons'] = 'Add-ons';
$txt['credits_software_graphics'] = 'Software/Graphics';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Graphics';
$txt['credits_fonts'] = 'Fonts';
$txt['credits_groups_contrib'] = 'Contributors';
$txt['credits_contrib_list'] = 'For a complete list of the many individuals that contributed to the design and implementation of Elkarte, please refer to the official GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">list of contributors.</a>';
$txt['credits_license'] = 'License';
$txt['credits_copyright'] = 'Πνευματικά δικαιώματα';
$txt['credits_version'] = 'Έκδοση';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Μεταφραστές';
$txt['credits_translators_message'] = 'Thank you for your efforts which make it possible for people all around the world to use ElkArte.  For a complete list please refer to the offical Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">list of contributors.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';