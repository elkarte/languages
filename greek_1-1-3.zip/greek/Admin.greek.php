<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Πίνακες';
$txt['admin_back_to'] = 'Πίσω στον πίνακα διαχείρισης';
$txt['admin_users'] = 'Μέλη';
$txt['admin_newsletters'] = 'Ενημερωτικά δελτία';
$txt['include_these'] = 'Μέλη που θα συμπεριληφθούν';
$txt['exclude_these'] = 'Μέλη που θα εξαιρεθούν';
$txt['admin_newsletters_select_groups'] = 'Ομάδες που θα συμπεριληφθούν';
$txt['admin_newsletters_exclude_groups'] = 'Ομάδες που θα εξαιρεθούν';
$txt['admin_edit_news'] = 'Ειδήσεις';
$txt['admin_groups'] = 'Ομάδες μελών';
$txt['admin_members'] = 'Διαχείριση μελών';
$txt['admin_members_list'] = 'Η λίστα των εγγεγραμμένων μελών στην κοινότητα.';
$txt['admin_next'] = 'Επόμενο';
$txt['admin_censored_words'] = 'Απαγορευμένες λέξεις';
$txt['admin_censored_where'] = 'Εισάγετε τις απαγορευμένες λέξεις στο αριστερό πλαίσιο και τις λέξεις που θα τις αντικαταστήσουν στο πλαίσιο στα δεξιά. Έπειτα αν θέλετε επιλέξτε τον έλεγχο ολόκληρης της λέξης και την περίπτωση. Όταν τελειώσετε με κάθε λέξη, επιλέξτε αποθήκευση. Πολλαπλές καταχωρήσεις μπορούν να γίνουν επιλέγοντας πριν την καταχώρηση την επιλογή \'Προσθήκη νέας λέξης\'.';
$txt['admin_censored_desc'] = 'Λόγω της δημόσιας φύσης της κοινότητας μπορεί να υπάρχουν κάποιες λέξεις που θα θέλατε να μην αποστέλλονται από μέλη του φόρουμ. Παρακάτω μπορείτε να εισάγετε λέξεις οι οποίες θέλετε να αντικατασταθούν όποτε χρησιμοποιούνται από κάποιο μέλος.<br />Για να διαγραφεί μια λέξη αδειάστε τα αντίστοιχα πεδία.';
$txt['admin_reserved_names'] = 'Δεσμευμένα ονόματα';
$txt['admin_template_edit'] = 'Διαχείριση του προτύπου';
$txt['admin_modifications'] = 'Ρυθμίσεις τροποποιήσεων';
$txt['admin_security_moderation'] = 'Ασφάλεια και Συντονισμός';
$txt['admin_server_settings'] = 'Ρυθμίσεις του διακομιστή';
$txt['admin_reserved_set'] = 'Δεσμευμένα ονόματα';
$txt['admin_reserved_line'] = 'Μία δεσμευμένη λέξη ανά γραμμή.';
$txt['admin_basic_settings'] = 'Αυτή η σελίδα επιτρέπει την αλλαγή βασικών ρυθμίσεων της σελίδας σας. Να είστε προσεκτικοί με αυτές τις ρυθμίσεις, καθώς μπορούν να επηρεάσουν τη σωστή λειτουργία της σελίδας. ';
$txt['admin_maintain'] = 'Ενεργοποίηση κατάστασης συντήρησης';
$txt['admin_title'] = 'Όνομα κοινότητας';
$txt['admin_url'] = 'URL Ιστοσελίδας';
$txt['cookie_name'] = 'Όνομα cookie';
$txt['admin_webmaster_email'] = 'Διεύθυνση e-mail διαχειριστή';
$txt['boarddir'] = 'Κατάλογος SElkArte';
$txt['sourcesdir'] = 'Κατάλογος πηγών';
$txt['cachedir'] = 'Κατάλογος προσωρινή μνήμης (cache)';
$txt['admin_news'] = 'Ενεργοποίηση ειδήσεων';
$txt['admin_guest_post'] = 'Ενεργοποίηση μηνυμάτων από επισκέπτες;';
$txt['admin_manage_members'] = 'Μέλη';
$txt['admin_main'] = 'Κύριο';
$txt['admin_config'] = 'Διαμόρφωση';
$txt['admin_version_check'] = 'Λεπτομερής έλεγχος έκδοσης';
$txt['admin_elkfile'] = 'Φάκελος ElkArte';
$txt['admin_elkpackage'] = 'Πακέτο ElkArte';
$txt['admin_logoff'] = 'Διακοπή συνεδρίας διαχειριστή';
$txt['admin_maintenance'] = 'Συντήρηση';
$txt['admin_image_text'] = 'Προβολή κουμπιών ως εικόνες αντί για κείμενο';
$txt['admin_credits'] = 'Συντελεστές';
$txt['admin_agreement'] = 'Προβολή και αποδοχή συμφωνητικού κατά την εγγραφή';
$txt['admin_checkbox_agreement'] = 'Εμφάνιση πλαισίου αποδοχής για το συμφωνητικό στην φόρμα εγγραφής αντί συνόλου του κειμένου';
$txt['admin_checkbox_accept_agreement'] = 'Υποχρεώστε όλα τα μέλη να αποδεχθούν την νέα έκδοση του συμφωνητικού εγγραφής με την επόμενη σύνδεση στην κοινότητα';
$txt['admin_agreement_default'] = 'Προεπιλεγμένο';
$txt['admin_agreement_select_language'] = 'Γλώσσα προς τροποποίηση';
$txt['admin_agreement_select_language_change'] = 'Αλλαγή';

$txt['admin_privacypol'] = 'Εμφάνιση και αποδοχή συμφωνητικού εγγραφής κατά την εγγραφή';
$txt['admin_checkbox_accept_privacypol'] = 'Υποχρεώστε όλα τα μέλη να αποδεχθούν την νέα έκδοση του προσωπικού απορρήτου με την επόμενη σύνδεση στην κοινότητα';

$txt['admin_delete_members'] = 'Διαγραφή επιλεγμένων μελών';
$txt['admin_change_primary_membergroup'] = 'Αλλαγή κύριας ομάδας μέλους';
$txt['admin_change_secondary_membergroup'] = 'Αλλαγή/προσθήκη πρόσθετης ομάδας';
$txt['confirm_remove_membergroup'] = 'Με τα επιλεγμένα, όλες οι ομάδες χρηστών θα αφαιρεθούν! Είστε σίγουρος/η? ';
$txt['confirm_change_primary_membergroup'] = 'Είστε σίγουρος/η πως θέλετε να αλλάξετε την κύρια ομάδα για επιλεγμένα μέλη?';
$txt['confirm_change_secondary_membergroup'] = 'Είστε σίγουρος/η πως θέλετε να αλλάξετε την δευτερεύουσα ομάδα για επιλεγμένα μέλη?';
$txt['admin_ban_usernames'] = 'Αποκλεισμός με όνομα πρόσβασης';
$txt['admin_ban_useremails'] = 'Αποκλεισμός με διεύθυνση e-mail';
$txt['admin_ban_userips'] = 'Αποκλεισμός με IP';
$txt['admin_ban_usernames_and_emails'] = 'Αποκλεισμός με όνομα πρόσβασης και ηλ. διεύθυνση';
$txt['admin_ban_name'] = 'Μαζικός αποκλεισμός';
$txt['remove_groups'] = 'Αφαίρεση όλων των ομάδων';

$txt['admin_repair'] = 'Επισκευή όλων των πινάκων και θεμάτων';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Παρακαλούμε τοποθετείτε μία είδηση ανά πλαίσιο. Μερικά BBC tags, όπως το <span title="Έντονα">[b]</span>, <span title="Πλάγια">[i]</span> και <span title="Υπογράμμιση">[u]</span> επιτρέπονται στις ειδήσεις, όπως και οι φατσούλες. Διαγράψτε το κείμενο από ένα πλαίσιο ειδήσεων για να το αφαιρέσετε.';
$txt['administrators'] = 'Διαχειριστές της κοινότητας';
$txt['admin_reserved_desc'] = 'Τα δεσμευμένα ονόματα θα αποτρέψουν χρήστες από το να χρησιμοποιούν συγκεκριμένα ονόματα χρήστη ή και εμφανιζόμενα ονόματα. Επιλέξτε από τις παρακάτω επιλογές που επιθυμείτε να χρησιμοποιήσετε πριν την Υποβολή.';
$txt['admin_activation_email'] = 'Αποστολή e-mail ενεργοποίησης στα νέα μέλη κατά την εγγραφή';
$txt['admin_match_whole'] = 'Ταίριασμα ολόκληρου κλειδιού μόνο. Εάν δεν επιλεγεί, η αναζήτηση θα γίνει με μερικό ταίριασμα.';
$txt['admin_match_case'] = 'Ταίριασμα πεζών-κεφαλαίων.';
$txt['admin_check_user'] = 'Έλεγχος ονόματος χρήστη.';
$txt['admin_check_display'] = 'Έλεγχος εμφανιζόμενου ονόματος.';
$txt['admin_newsletter_send'] = 'Μπορείτε να στείλετε e-mail σε οποιονδήποτε από αυτή την σελίδα. Οι διευθύνσεις e-mail από τις επιλεγμένες ομάδες μελών θα εμφανιστούν από κάτω, αλλά μπορείτε να αφαιρέσετε ή να προσθέσετε οποιεσδήποτε διευθύνσεις επιθυμείτε. Βεβαιωθείτε ότι κάθε διεύθυνση διαχωρίζεται με τον εξής τρόπο: \'address1; address2\'.';
$txt['admin_fader_delay'] = 'Χρονική καθυστέρηση μεταξύ ειδήσεων στο πλαίσιο ειδήσεων (σε msec)';
$txt['zero_for_no_limit'] = '(0 για απεριόριστο)';
$txt['zero_to_disable'] = '(0 για απενεργοποίηση)';

$txt['admin_backup_fail'] = 'Η αποθήκευση του Settings.php απέτυχε. - βεβαιωθείτε ότι το Settings_bak.php υπάρχει και είναι εγγράψιμο.';
$txt['modSettings_info'] = 'Αλλαγή ή ρύθμιση επιλογών για τη λειτουργία της κοινότητας.';
$txt['database_server'] = 'Διακομιστής βάσης δεδομένων';
$txt['database_user'] = 'Όνομα χρήστη βάσης δεδομένων';
$txt['database_password'] = 'Κωδικός πρόσβασης βάσης δεδομένων';
$txt['database_name'] = 'Όνομα βάσης δεδομένων';
$txt['registration_agreement'] = 'Συμφωνία εγγραφής';
$txt['registration_agreement_desc'] = 'Η συμφωνία εγγραφής θα εμφανίζεται όταν οι χρήστες επιθυμούν να δημιουργήσουν λογαριασμό στην κοινότητα και θα πρέπει να αποδεχθούν την συμφωνία πριν προχωρήσουν στην εγγραφή.';
$txt['privacy_policy'] = 'Πολιτική απορρήτου ';
$txt['privacy_policy_desc'] = 'Η πολιτική απορρήτου εμφανίζεται όταν οι χρήστες δημιουργούν λογαριασμό στην κοινότητα και μπορεί να γίνει υποχρεωτική πριν οι χρήστες συνεχίσουν στην εγγραφή.';
$txt['database_prefix'] = 'Πρόθεμα πινάκων βάσης δεδομένων';
$txt['errors_list'] = 'Λίστα σφαλμάτων ιστοσελίδας';
$txt['errors_found'] = 'Τα ακόλουθα σφάλματα παρουσιάστηκαν στην ιστοσελίδα';
$txt['errors_fix'] = 'Θέλετε να γίνει προσπάθεια να διορθωθούν αυτά τα σφάλματα;';
$txt['errors_do_recount'] = 'Όλα τα σφάλματα διορθώθηκαν και μια περιοχή διάσωσης έχει δημιουργηθεί! Παρακαλώ κάντε κλικ στο παρακάτω κουμπί για να επαναμετρηθούν κάποια βασικά στατιστικά στοιχεία.';
$txt['errors_recount_now'] = 'Υπολογισμός εκ νέου των στατιστικών';
$txt['errors_fixing'] = 'Διόρθωση σφαλμάτων κοινότητας';
$txt['errors_fixed'] = 'Όλα τα λάθη διορθώθηκαν! Ελέγξτε τις νέες κατηγορίες, πίνακες ή θέματα για να αποφασίσετε τι θέλετε να κάνετε.';
$txt['attachments_avatars'] = 'Συνημμένα και πορτραίτα';
$txt['attachments_desc'] = 'Από εδώ μπορείτε να διαχειρίζεστε τα συνημμένα αρχεία του συστήματος. Μπορείτε να διαγράψετε τα συνημμένα κατά μέγεθος ή κατά ημερομηνία από το σύστημα. Στατιστικά για τα συνημμένα αρχεία προβάλλονται παρακάτω.';
$txt['attachment_stats'] = 'Στατιστικά συνημμένων αρχείων';
$txt['attachment_integrity_check'] = 'Έλεγχος ακεραιότητας συνημμένων';
$txt['attachment_integrity_check_desc'] = 'Αυτή η λειτουργία ελέγχει την ακεραιότητα και τα μεγέθη των συνημμένων και ονομάτων αρχείων που είναι καταχωρημένα στην βάση δεδομένων και, αν χρειάζεται, επιδιορθώνει τα σφάλματα που εντοπίζει.';
$txt['attachment_check_now'] = 'Εκτέλεση ελέγχου τώρα';
$txt['attachment_pruning'] = 'Διαγραφή συνημμένων';
$txt['attachment_pruning_message'] = 'Μήνυμα που θα προστεθεί στην δημοσίευση';
$txt['attachment_pruning_warning'] = 'Σίγουρα θέλετε να διαγράψετε αυτά τα συνημμένα;\\nΑυτό δεν μπορεί να αναιρεθεί!';

$txt['attachment_total'] = 'Σύνολο συνημμένων αρχείων';
$txt['attachmentdir_size'] = 'Συνολικό μέγεθος όλων των καταλόγων συνημμένων';
$txt['attachmentdir_size_current'] = 'Συνολικό μέγεθος του παρόντος φακέλου συνημμένων';
$txt['attachmentdir_files_current'] = 'Σύνολο αρχείων στον κατάλογο συνημμένων';
$txt['attachment_space'] = 'Διαθέσιμος χώρος στον κατάλογο συνημμένων';
$txt['attachment_files'] = 'Σύνολο εναπομεινάντων αρχείων';

$txt['attachment_options'] = 'Επιλογές συνημμένων αρχείων';
$txt['attachment_log'] = 'Καταγραφή συνημμένων';
$txt['attachment_remove_old'] = 'Διαγραφή συνημμένων παλαιότερων από';
$txt['attachment_remove_size'] = 'Διαγραφή συνημμένων μεγαλύτερων από';
$txt['attachment_name'] = 'Όνομα συνημμένου';
$txt['attachment_file_size'] = 'Μέγεθος αρχείου';
$txt['attachmentdir_size_not_set'] = 'Δεν έχει οριστεί μέγιστη χωρητικότητα καταλόγου';
$txt['attachmentdir_files_not_set'] = 'Κατάλογος χωρίς όρια αυτή την στιγμή';
$txt['attachment_delete_admin'] = '[το συνημμένο έχει διαγραφεί από τον Διαχειριστή]';
$txt['live'] = 'Τελευταίες ενημερώσεις λογισμικού';
$txt['remove_all'] = 'Διαγραφή όλων';
$txt['agreement_not_writable'] = 'Προειδοποίηση - το αρχείο agreement.txt δεν είναι εγγράψιμο. Οποιαδήποτε αλλαγή δεν θα αποθηκευθεί ';
$txt['agreement_backup_not_writable'] = 'Προειδοποίηση - η διαδρομή αντιγράφων σε forum_root/packages/backups δεν μπορεί να δημιουργηθεί.';
$txt['privacypol_not_writable'] = 'Προειδοποίηση - το αρχείο privacypolicy.txt δεν είναι εγγράψιμο. Οποιαδήποτε αλλαγή δεν θα αποθηκευθεί ';
$txt['privacypol_backup_not_writable'] = 'Προειδοποίηση - η διαδρομή αντιγράφων σε forum_root/packages/backups δεν μπορεί να δημιουργηθεί ';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(λεπτομέρειες)';

$txt['lfyi'] = 'Δεν είναι δυνατή η σύνδεση με το αρχείο ενημερωμένων εκδόσεων του ElkArte';

$txt['manage_calendar'] = 'Ημερολόγιο';
$txt['manage_search'] = 'Αναζήτηση';
$txt['viewmembers_online'] = 'Τελευταία σύνδεση';

$txt['smileys_manage'] = 'Φατσούλες και εικονίδια μηνυμάτων';
$txt['smileys_manage_info'] = 'Εγκατάσταση νέων ομάδων φατσούλων, προσθήκη φατσούλων στις ήδη υπάρχουσες, ή διαχείριση εικονιδίων μηνυμάτων';

$txt['bbc_manage'] = 'Κώδικες (BBC)';
$txt['bbc_manage_info'] = 'Προσθήκη,αφαίρεση και επεξεργασία κώδικά BBC.';

$txt['package_info'] = 'Εγκατάσταση νέων λειτουργιών ή τροποποίηση ήδη υπαρχόντων.';
$txt['theme_admin'] = 'Εμφάνιση και διάταξη';
$txt['theme_admin_info'] = 'Διαχείριση των εμφανίσεων και ρύθμιση των επιλογών τους.';
$txt['registration_center'] = 'Εγγραφές';
$txt['member_center_info'] = 'Προβολή της λίστας μελών, αναζήτηση μελών, και διαχείριση των μη εγκεκριμένων μελών και των μελών που δεν έχουν ακόμη ενεργοποιήσει τον λογαριασμό τους.';
$txt['viewmembers_online'] = 'Τελευταία σύνδεση';

$txt['display_name'] = 'Εμφανιζόμενο όνομα';
$txt['email_address'] = 'Διεύθυνση e-mail';
$txt['ip_address'] = 'Διεύθυνση IP';
$txt['member_id'] = 'Αναγνωριστικό (ID)';

$txt['unknown'] = 'άγνωστο';
$txt['security_wrong'] = 'Administration login attempt!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Αποστολή σε μορφή HTML. (μπορείτε να χρησιμοποιήσετε HTML στο Email)';
$txt['email_parsed_html'] = 'Προσθήκη &lt;br /&gt;s και &amp;nbsp;s στο μήνυμα.';
$txt['email_variables'] = 'Σε αυτό το μήνυμα μπορείτε να χρησιμοποιήσετε μερικές &quot;μεταβλητές<a href="{help_emailmembers}" class="help">&quot;.Επιλέξτε εδώ για περισσότερες πληροφορίες </a>';
$txt['email_force'] = 'Αποστολή στα μέλη ακόμα και αν έχουν επιλέξει να μην λαμβάνουν ανακοινώσεις.';
$txt['email_as_pms'] = 'Αποστολή στις ομάδες χρησιμοποιώντας προσωπικά μηνύματα.';
$txt['email_continue'] = 'Συνέχεια';
$txt['email_done'] = 'ολοκληρώθηκε.';
$txt['email_members_succeeded'] = 'Έχετε στείλει με επιτυχία το ενημερωτικό δελτίο!';

$txt['ban_title'] = 'Λίστα αποκλεισμών';
$txt['ban_ip'] = 'Αποκλεισμός IP: (π.χ. 192.168.12.213 ή 128.0.*.*) - μία εγγραφή ανά γραμμή';
$txt['ban_email'] = 'Αποκλεισμός e-mail: (π.χ. badguy@somewhere.gr) - μία εγγραφή ανά γραμμή';
$txt['ban_username'] = 'Αποκλεισμός ονόματος χρήστη: (π.χ. l33tuser) - μία εγγραφή ανά γραμμή';

$txt['ban_errors_detected'] = 'Το ακόλουθο ή ακόλουθα σφάλματα προέκυψαν κατά την αποθήκευση ή την επεξεργασία αποκλεισμού ή την αιτία αποκλεισμού.';
$txt['ban_description'] = 'Εδώ μπορείτε να αποκλείσετε την είσοδο σε άτομα κατά διεύθυνση IP, όνομα κεντρικού υπολογιστή, όνομα χρήστη ή e-mail.';
$txt['ban_add_new'] = 'Προσθήκη νέου αποκλεισμού';
$txt['ban_banned_entity'] = 'Αποκλεισμένη οντότητα';
$txt['ban_on_ip'] = 'Αποκλεισμός IP (π.χ. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Αποκλεισμός κεντρικού υπολογιστή (π.χ. *.mil)';
$txt['ban_on_email'] = 'Αποκλεισμός διεύθυνσης e-mail (π.χ. *@badsite.gr)';
$txt['ban_on_username'] = 'Αποκλεισμός ονόματος χρήστη';
$txt['ban_notes'] = 'Σημειώσεις';
$txt['ban_restriction'] = 'Περιορισμός';
$txt['ban_full_ban'] = 'Πλήρης αποκλεισμός';
$txt['ban_partial_ban'] = 'Μερικός αποκλεισμός';
$txt['ban_cannot_post'] = 'Απαγόρευση αποστολής';
$txt['ban_cannot_register'] = 'Απαγόρευση εγγραφής';
$txt['ban_cannot_login'] = 'Απαγόρευση σύνδεσης';
$txt['ban_add'] = 'Προσθήκη';
$txt['ban_edit_list'] = 'Λίστα αποκλεισμών';
$txt['ban_type'] = 'Τύπος αποκλεισμού';
$txt['ban_days'] = 'ημέρες';
$txt['ban_will_expire_within'] = 'Ο αποκλεισμός θα λήξει μετά από';
$txt['ban_added'] = 'Προστέθηκε';
$txt['ban_expires'] = 'Λήγει';
$txt['ban_hits'] = 'Επισκέψεις';
$txt['ban_actions'] = 'Ενέργειες';
$txt['ban_expiration'] = 'Λήξη';
$txt['ban_reason_desc'] = 'Αιτιολογία αποκλεισμού, που θα εμφανιστεί στο μέλος.';
$txt['ban_notes_desc'] = 'Σημειώσεις που πιθανόν να βοηθήσουν τους άλλους διαχειριστές.';
$txt['ban_remove_selected'] = 'Διαγραφή επιλεγμένων';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Σίγουρα θέλετε να διαγράψετε τους επιλεγμένους αποκλεισμούς;';
$txt['ban_modify'] = 'Τροποποίηση';
$txt['ban_name'] = 'Όνομα αποκλεισμού';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Τροποποίηση αποκλεισμού';
$txt['ban_add_notes'] = '<strong>Σημείωση</strong>: μετά τη δημουργία του παραπάνω αποκλεισμού, μπορείτε να προσθέσετε επιπλέον εγγραφές που θα ενεργοποιούν τον αποκλεισμό, όπως διευθύνσεις IP, ονόματα διακομιστών και διευθύνσεις email.';
$txt['ban_expired'] = 'Ληγμένος / Απενεργοποιημένος';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Δεν έχει επιλεγεί κανένας περιορισμός.';

$txt['ban_triggers'] = 'Εναύσματα';
$txt['ban_add_trigger'] = 'Προσθήκη εναύσματος';
$txt['ban_add_trigger_submit'] = 'Προσθήκη';
$txt['ban_edit_trigger'] = 'Τροποποίηση';
$txt['ban_edit_trigger_title'] = 'Τροποποίηση εναύσματος';
$txt['ban_edit_trigger_submit'] = 'Τροποποίηση';
$txt['ban_remove_selected_triggers'] = 'Αφαίρεση επιλεγμένων εναυσμάτων';
$txt['ban_no_entries'] = 'Δεν υπάρχουν προς το παρόν ενεργοί αποκλεισμοί.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Σίγουρα θέλετε να αφαιρέσετε τα επιλεγμένα εναύσματα';
$txt['ban_trigger_browse'] = 'Προβολή αιτιών αποκλεισμού';
$txt['ban_trigger_browse_description'] = 'Αυτή η οθόνη εμφανίζει όλα τα εναύσματα αποκλεισμών, ομαδοποιημένα με βάση την διεύθυνση IP, όνομα διακομιστή, διεύθυνση email και όνομα χρήστη.';

$txt['ban_log'] = 'Καταγραφή αποκλεισμών';
$txt['ban_log_description'] = 'Η καταγραφή αποκλεισμών δείχνει όλες τις προσπάθειες εισόδου στην κοινότητα από μέλη που έχουν αποκλεισθεί (\'πλήρης αποκλεισμός και \'απαγόρευση εγγραφής μόνο).';
$txt['ban_log_no_entries'] = 'Δεν υπάρχει καμία καταγραφή αποκλεισμού προς το παρόν.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'Διεύθυνση e-mail';
$txt['ban_log_member'] = 'Μέλος';
$txt['ban_log_date'] = 'Ημερομηνία';
$txt['ban_log_remove_all'] = 'Διαγραφή όλων';
$txt['ban_log_remove_all_confirm'] = 'Σίγουρα θέλετε να διαγράψετε όλες τις εγγραφές αποκλεισμών;';
$txt['ban_log_remove_selected'] = 'Διαγραφή επιλεγμένων';
$txt['ban_log_remove_selected_confirm'] = 'Σίγουρα θέλετε να διαγράψετε όλες τις εγγραφές αποκλεισμών;';
$txt['ban_no_triggers'] = 'Δεν υπάρχουν εναύσματα αποκλεισμών προς το παρόν.';

$txt['settings_not_writable'] = 'Αυτές οι ρυθμίσεις δεν μπορούν να τροποποιηθούν επειδή το Settings.php είναι μόνο για ανάγνωση.';

$txt['maintain_title'] = 'Συντήρηση κοινότητας';
$txt['maintain_info'] = 'Βασικά αντίγραφα ασφαλείας για την κοινότητα, έλεγχος σφαλμάτων βάσης δεδομένων, εκκαθάριση της προσωρινής μνήμης,hooks και πολλά άλλα.';
$txt['maintain_sub_database'] = 'Βάση δεδομένων';
$txt['maintain_sub_routine'] = 'Ρουτίνα';
$txt['maintain_sub_members'] = 'Μέλη';
$txt['maintain_sub_topics'] = 'Θέματα';
$txt['maintain_sub_attachments'] = 'Συνημμένα';
$txt['maintain_done'] = 'Η εργασία συντήρησης \'%1$s\' ολοκληρώθηκε επιτυχώς.';
$txt['maintain_fail'] = 'Η διαδικασία συντήρησης \'%1$s\' απέτυχε.';
$txt['maintain_no_errors'] = 'Συγχαρητήρια, δεν βρέθηκε σφάλμα!  Ευχαριστούμε για τον έλεγχο.';

$txt['maintain_tasks'] = 'Προγραμματισμένες Εργασίες';
$txt['maintain_tasks_desc'] = 'Διαχείριση όλων των εργασιών που έχουν προγραμματιστεί από το SMF.';

$txt['scheduled_log'] = 'Αρχείο καταγραφής εργασιών';
$txt['scheduled_log_desc'] = 'Εμφανίζει το αρχείο καταγραφής των εργασιών που έχουν εκτελεστεί.';
$txt['admin_log'] = 'Αρχείο καταγραφής διαχείρισης';
$txt['admin_log_desc'] = 'Εμφανίζει τις εργασίες που έχουν πραγματοποιηθεί από τους διαχειριστές της κοινότητας.';
$txt['moderation_log'] = 'Αρχείο καταγραφής συντονισμού';
$txt['moderation_log_desc'] = 'Εμφανίζει τις ενέργειες που έχουν πραγματοποιηθεί από τους συντονιστές της κοινότητας.';
$txt['badbehavior_log'] = 'Αρχείο μη αποδεκτής συμπεριφοράς';
$txt['badbehavior_log_desc'] = 'Λίστες αιτημάτων που έχουν αποκλειστεί ή έχουν σημειωθεί ύποπτες εξαιτίας μη αποδεκτής συμπεριφοράς. Εάν η λεπτομερής καταγραφή είναι ενεργοποιημένη, όλα τα HTTP αιτήματα καταγράφονται.';
$txt['spider_log_desc'] = 'Επανεξέταση των καταχωρήσεων που σχετίζονται με την δραστηριότητα αραχνών των μηχανών αναζήτησης στην ιστοσελίδα σας. ';
$txt['pruning_log_desc'] = 'Χρησιμοποιήστε αυτά τα εργαλεία για να διαγράψετε παλαιότερες εγγραφές στα διάφορα αρχεία καταγραφής.
';

$txt['mailqueue_title'] = 'E-mail';

$txt['db_error_send'] = 'Αποστολή e-mail σε περίπτωση σφάλματος σύνδεσης MySQL';
$txt['db_persist'] = 'Χρήση επίμονης (persistent) σύνδεσης';
$txt['ssi_db_user'] = 'Όνομα χρήστη βάσης δεδομένων για χρήση στη μέθοδο SSI';
$txt['ssi_db_passwd'] = 'Κωδικός βάσης δεδομένων για χρήση στη μέθοδο SSI';

$txt['default_language'] = 'Προεπιλεγμένη γλώσσα της κοινότητας';

$txt['maintenance_subject'] = 'Τίτλος προς εμφάνιση';
$txt['maintenance_message'] = 'Μήνυμα προς εμφάνιση';

$txt['errlog_desc'] = 'Το αρχείο καταγραφής σφαλμάτων εντοπίζει κάθε σφάλμα που παρουσιάζεται στην ιστοσελίδα σας. Για τη διαγραφή οποιωνδήποτε σφαλμάτων από τη βάση δεδομένων, τσεκάρετε το κουτάκι επιλογής, και κάντε κλικ στο κουμπί %s στο τέλος της σελίδας.';
$txt['errlog_no_entries'] = 'Δεν υπάρχουν εγγραφές στο αρχείο καταγραφής προς το παρόν.';

$txt['theme_settings'] = 'Ρυθμίσεις εμφάνισης';
$txt['theme_edit_settings'] = 'Επεξεργασία ρυθμίσεων της συγκεκριμένης εμφάνισης';
$txt['theme_current_settings'] = 'Τρέχουσα εμφάνιση';

$txt['dvc_your'] = 'Η έκδοσή σας';
$txt['dvc_current'] = 'Τρέχουσα έκδοση';
$txt['dvc_sources'] = 'Πηγές';
$txt['dvc_admin'] = 'Διαχείριση';
$txt['dvc_controllers'] = 'Ελεγκτές ';
$txt['dvc_database'] = 'Βάση δεδομένων';
$txt['dvc_subs'] = 'Εγγραφές';
$txt['dvc_default'] = 'Προεπιλεγμένα πρότυπα';
$txt['dvc_templates'] = 'Τρέχοντα πρότυπα';
$txt['dvc_languages'] = 'Αρχεία γλωσσών';

$txt['smileys_default_set_for_theme'] = 'Επιλογή προκαθορισμένης ομάδας φατσούλων γι\' αυτή την Εμφάνιση';
$txt['smileys_no_default'] = '(χρήση ενιαίας προκαθορισμένης ομάδας φατσούλων)';

$txt['censor_test'] = 'Δοκιμή των απαγορευμένων λέξεων';
$txt['censor_test_save'] = 'Δοκιμή';
$txt['censor_case'] = 'Αγνόησε πεζά - κεφαλαία κατά την απαγόρευση λέξεων.';
$txt['censor_whole_words'] = 'Έλεγχος μόνο ολόκληρων λέξεων';
$txt['censor_allow'] = 'Επιτρέψτε στους χρήστες να απενεργοποιησούν την απαγόρευση λέξεων.';

$txt['admin_confirm_password'] = '(επιβεβαίωση κωδικού)';
$txt['admin_incorrect_password'] = 'Εσφαλμένος κωδικός';

$txt['date_format'] = '(ΕΕΕΕ-MM-ΗΗ)';
$txt['undefined_gender'] = 'Μη ορισμένο';
$txt['age'] = 'Ηλικία χρήστη';
$txt['activation_status'] = 'Κατάσταση ενεργοποίησης';
$txt['activated'] = 'Ενεργό';
$txt['not_activated'] = 'Ανενεργό';
$txt['is_banned'] = 'Μπλοκαρισμένο ';
$txt['primary'] = 'Πρωτεύον';
$txt['additional'] = 'Πρόσθετα';
$txt['wild_cards_allowed'] = 'οι χαρακτήρες * και ? επιτρέπονται';
$txt['member_part_of_these_membergroups'] = 'Το μέλος ανήκει σ\' αυτές τις ομάδες μελών';
$txt['membergroups'] = 'Ομάδες μελών';
$txt['confirm_delete_members'] = 'Σίγουρα θέλετε να διαγράψετε τα επιλεγμένα μέλη\\;';

$txt['support_credits_title'] = 'Υποστήριξη και πληροφορίες';
$txt['support_credits_info'] = 'Σύνδεσμοι υποστήριξης σε κοινά θέματα και προβλήματα,θα σας ζητηθούν σχετικές πληροφορίες έκδοσης της ιστοσελίδας όταν ζητήσετε βοήθεια και μια λίστα με τους συνεισφέροντες στο έργο του ElkArte.';
$txt['support_title'] = 'Πληροφορίες Υποστήριξης';
$txt['support_versions_current'] = 'Τρέχουσα έκδοση';
$txt['support_versions_forum'] = 'Έκδοση φόρουμ';
$txt['support_versions_db'] = '%1$s έκδοση';
$txt['support_versions_server'] = 'Έκδοση διακομιστή';
$txt['support_versions_gd'] = 'Έκδοση GD';
$txt['support_versions_imagick'] = 'Έκδοση Imagick';
$txt['support_versions'] = 'Πληροφορίες έκδοσης';
$txt['support_resources'] = 'Πηγές υποστήριξης';
$txt['support_resources_p1'] = 'Το <a href="%1$s" target="_blank" class="new_win">Online εγχειρίδιο </a> παρέχει την βασική τεκμηρίωση για το ElkArte. Το Online εγχειρίδιο του ElkArte έχει πολλά έγγραφα που βοηθούν στο να απαντηθούν ερωτήσεις σχετικά με την υποστήριξη και να εξηγήσει <a href="%2$s" target="_blank" class="new_win">δυνατότητες</a>, <a href="%3$s" target="_blank" class="new_win">ρυθμίσεις</a>, <a href="%4$s" target="_blank" class="new_win">εμφανίσεις</a>, <a href="%5$s" target="_blank" class="new_win">πακέτα</a>, κλπ. Το online εγχειρίδιο τεκμηριώνει πλήρως κάθε τμήμα του ElkArte και απαντά γρήγορα στις περισσότερες ερωτήσεις.';
$txt['support_resources_p2'] = 'Αν δεν μπορείτε να βρείτε απαντήσεις στις ερωτήσεις σας στο online εγχειρίδιο, μπορείτε να ψάξετε στην <a href="%1$s">κοινότητα υποστήριξης</a> ή να ζητήσετε βοήθεια είτε στον <a href="%2$s">αγγλικό</a> είτε σε έναν από τους πολλούς <a href="%3$s">διεθνείς πίνακες υποστήριξης</a>. Η κοινότητα υποστήριξης του ElkArte μπορεί να χρησιμοποιηθεί για <a href="%4$s">υποστήριξη</a>, <a href="%5$s">εξατομίκευση</a>, και πολλά άλλα πράγματα όπως η συζήτηση για το ElkArte, εύρεση παρόχου web, και η συζήτηση για διαχειριστικά θέματα με άλλους διαχειριστές φόρουμ.';

$txt['latest_updates'] = 'Τελευταίες αξιοσημείωτες ενημερώσεις';
$txt['new_in_1_0_2'] = 'Η πιο σημαντική αλλαγή στο ElkArte 1.0.2 είναι το δικαίωμα διαχείρισης πορτραίτων. Προς το παρόν κάθε μέθοδο ρυθμίσεων των πορτραίτων είναι βασισμένη σε άδειες, απαιτείτε η ενεργοποίηση/απενεργοποίηση της κάθε μεθόδου για την κάθε ομάδα μελών.Με την έκδοση 1.0.2, τα εικονίδια avatars είναι εύκολα στην ενεργοποίηση/απενεργοποίηση για κάθε ομάδα μελών, αυτό επιτρέπει στις ενεργοποιημένες ομάδες να προσθέσουν avatar (με όλους τους διαθέσιμους τρόπους)<br />
Η μόνη διαθέσιμη άδεια για το κάθε μέλος είναι να αλλάξει ή όχι το εικονίδιο avatar.
Επιπλέον, υπάρχει μία ρύθμιση για το μέγιστο πλάτος και ύψος των πορτραίτων , οι τιμές αυτές διέπουν όλες τις μεθόδους πορτραίτων .<br /><br />
 Λόγω της φύσης των αλλαγών, δεν ήταν εφικτή η μεταφορά των υπαρχόντων ρυθμίσεων σε νέα έκδοση, για αυτό θα πρέπει να επισκεφθείτε την σελίδα με τις <a href="{admin_url};area=manageattachments;sa=avatars">Ρυθμίσεις Πορτραίτων</a> και να θέσετε τις επιλογές που επιθυμητέ.';

$txt['edit_permissions_info'] = 'Αλλαγή περιορισμών και διαθέσιμων λειτουργιών γενικά ή σε συγκεκριμένους πίνακες.';
$txt['membergroups_members'] = 'Κοινά μέλη';
$txt['membergroups_guests'] = 'Επισκέπτες';
$txt['membergroups_add_group'] = 'Προσθήκη ομάδας';
$txt['membergroups_permissions'] = 'Δικαιώματα';

$txt['permitgroups_restrict'] = 'Περιορισμένα';
$txt['permitgroups_standard'] = 'Κανονικά';
$txt['permitgroups_moderator'] = 'Συντονιστή';
$txt['permitgroups_maintenance'] = 'Συντήρησης';

$txt['confirm_delete_attachments'] = 'Σίγουρα θέλετε να διαγράψετε τα επιλεγμένα συνημμένα;';
$txt['attachment_manager_browse_files'] = 'Προβολή αρχείων';
$txt['attachment_manager_repair'] = 'Συντήρηση';
$txt['attachment_manager_avatars'] = 'Πορτραίτα';
$txt['attachment_manager_attachments'] = 'Συνημμένα';
$txt['attachment_manager_thumbs'] = 'Μικρογραφίες';
$txt['attachment_manager_last_active'] = 'Τελευταίο ενεργό';
$txt['attachment_manager_member'] = 'Μέλος';
$txt['attachment_manager_avatars_older'] = 'Διαγραφή πορτραίτων από μέλη ανενεργά για πάνω από';
$txt['attachment_manager_total_avatars'] = 'Σύνολο πορτραίτων';

$txt['attachment_manager_avatars_no_entries'] = 'Δεν υπάρχουν πορτραίτα προς το παρόν.';
$txt['attachment_manager_attachments_no_entries'] = 'Δεν υπάρχουν συνημμένα προς το παρόν.';
$txt['attachment_manager_thumbs_no_entries'] = 'Δεν υπάρχουν μικρογραφίες προς το παρόν.';

$txt['attachment_manager_settings'] = 'Ρυθμίσεις συνημμένων';
$txt['attachment_manager_avatar_settings'] = 'Ρυθμίσεις πορτραίτων';
$txt['attachment_manager_browse'] = 'Προβολή αρχείων';
$txt['attachment_manager_maintenance'] = 'Συντήρηση αρχείων';
$txt['attachmentEnable'] = 'Μέθοδος συνημμένων';
$txt['attachmentEnable_deactivate'] = 'Απενεργοποίηση συνημμένων';
$txt['attachmentEnable_enable_all'] = 'Ενεργοποίηση όλων των συνημμένων';
$txt['attachmentEnable_disable_new'] = 'Απενεργοποίηση νέων συνημμένων';
$txt['attachmentCheckExtensions'] = 'Έλεγχος τύπου συνημμένων';
$txt['attachmentExtensions'] = 'Επιτρεπόμενοι τύποι συνημμένων';
$txt['attachmentRecodeLineEndings'] = 'Αφαίρεση τέλους γραμμής σε συνημμένα κειμένου';
$txt['attachmentShowImages'] = 'Προβολή των συνημμένων ως εικόνες κάτω από το μήνυμα';
$txt['attachmentUploadDir'] = 'Φάκελος συνημμένων';
$txt['attachmentUploadDir_multiple_configure'] = 'Διαχείριση φακέλων συνημμένων';
$txt['attachmentDirSizeLimit'] = 'Μέγιστο μέγεθος καταλόγου συνημμένων';
$txt['attachmentPostLimit'] = 'Μέγιστο μέγεθος συνημμένων ανά μήνυμα';
$txt['attachmentSizeLimit'] = 'Μέγιστο μέγεθος ανά συνημμένο';
$txt['attachmentNumPerPostLimit'] = 'Μέγιστος αριθμός συνημμένων ανά μήνυμα';
$txt['attachment_img_enc_warning'] = 'Κανένα από τα δύο πρόσθετα GD module και ImageMagick δεν είναι εγκατεστημένα.Δεν είναι δυνατή η επανακωδικοποίηση της εικόνας.';
$txt['attachment_postsize_warning'] = 'Στο υπάρχον php.ini η ρύθμιση \'post_max_size\' ενδέχεται να μην το υποστηρίζει.';
$txt['attachment_filesize_warning'] = 'Στο υπάρχον php.ini η ρύθμιση \'upload_max_filesize\' ενδέχεται να μην το υποστηρίζει.';
$txt['attachment_image_reencode'] = 'Επανακωδικοποίηση δυνητικά επικίνδυνων συνημμένων εικόνων';
$txt['attachment_image_reencode_note'] = '(απαιτείται το πρόσθετο GD)';
$txt['attachment_image_paranoid_warning'] = 'Οι εκτενείς έλεγχοι ασφαλείας πιθανόν να έχουν ως αποτέλεσμα έναν μεγάλο αριθμό απορριπτέων συνημμένων.';
$txt['attachment_image_paranoid'] = 'Εκτέλεση εκτενών έλεγχων ασφαλείας σε μεταφορτωμένες συνημμένες εικόνες.';
$txt['attachment_autorotate'] = 'Εντοπισμός και διόρθωση εσφαλμένων περιστραμένων εικόνων ';
$txt['attachment_autorotate_na'] = '(Μη διαθέσιμο σε αυτό το σύστημα)';
$txt['attachmentThumbnails'] = 'Αλλαγή μεγέθους εικόνων όταν προβάλλονται στις δημοσιεύσεις';
$txt['attachment_thumb_png'] = 'Αποθήκευση μικρογραφιών ως PNG';
$txt['attachment_thumb_memory'] = 'Προσαρμογή μνήμης μικρογραφιών';
$txt['attachment_thumb_memory_note2'] = 'αν το σύστημα δεν μπορεί να χρησιμοποιήσει την μνήμη, δεν θα δημιουργηθεί μικρογραφία.';
$txt['attachment_thumb_memory_note1'] = 'Αφήστε το χωρίς επιλογή για την προσπάθεια δημιουργίας μικρογραφίας ';
$txt['attachmentThumbWidth'] = 'Μέγιστο πλάτος μικρογραφιών';
$txt['attachmentThumbHeight'] = 'Μεγιστο ύψος μικρογραφιών';
$txt['attachment_thumbnail_settings'] = 'Ρυθμίσεις Μικρογραφίας';
$txt['attachment_security_settings'] = 'Ρυθμίσεις ασφαλείας συνημμένων';

$txt['attachment_inline_title'] = 'Ρυθμίσεις συνημμένων μέσα στο κείμενο';
$txt['attachment_inline_enabled'] = 'Ενεργοποίηση εμφάνισης συνημμένων μέσα στο κείμενο';
$txt['attachment_inline_basicmenu'] = 'Εμφάνιση μόνο βασικού μενού';
$txt['attachment_inline_quotes'] = 'Επιλέξτε για ενεργοποίηση εμφάνισης συνημμένων μέσα σε παραθέσεις';

$txt['attach_dir_does_not_exist'] = 'Δεν υπάρχει';
$txt['attach_dir_not_writable'] = 'Μη εγγράψιμο';
$txt['attach_dir_files_missing'] = 'Λείπουν Φάκελοι (<a href="{repair_url}">Επισκεύη</a>)';
$txt['attach_dir_unused'] = 'Αχρησιμοποίητος';
$txt['attach_dir_empty'] = 'Κενό';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Βασικός κατάλογος';

$txt['attach_dir_desc'] = 'Δημιουργία νέων καταλόγων ή αλλαγή των ήδη υπάρχοντων, παρακάτω.Οι κατάλογοι μπορούν να μετονομαστούν εφόσον δεν περιέχουν υποκατάλογο. Εάν ο νέος κατάλογος πρόκειται να δημιουργηθεί μέσα στη δομή καταλόγου της ιστοσελίδας, θα χρειαστεί να πληκτρολογήσετε το όνομα του καταλόγου.Για να καταργήσετε έναν κατάλογο, αφήστε κενό το πεδίο εισαγωγής της διαδρομής.Οι κατάλογοι δεν μπορούν να διαγραφούν εάν περιέχουν αρχεία είτε υποκατλόγους
(εμφανίζεται σε παρενθέσεις μετά τον αριθμό αρχείου).';
$txt['attach_dir_base_desc'] = 'Μπορείτε να χρησιμοποιήσετε την παρακάτω περιοχή για να αλλάξετε τον τρέχοντα βασικό κατάλογο ή να δημιουργήσετε ένα νέο. Νέοι κατάλογοι βάσης προστίθενται επίσης στη λίστα καταλόγου συνημμένων. Μπορείτε επίσης να ορίσετε έναν υπάρχοντα κατάλογο ως βασικό κατάλογο.';
$txt['attach_dir_save_problem'] = 'Φαίνεται να υπάρχει πρόβλημα.';
$txt['attachments_no_create'] = 'Αδύνατον να δημιουργηθεί νέος κατάλογος συνημμένων. Παρακαλώ δοκιμάστε χρησιμοποιώντας FTP εφαρμογή ή τον διαχειριστή φακέλων της σελίδας σας.';
$txt['attachments_no_write'] = 'Ο κατάλογος δημιουργήθηκε αλλά δεν είναι εγγράψιμος.  Παρακαλώ δοκιμάστε χρησιμοποιώντας FTP εφαρμογή ή τον διαχειριστή φακέλων της σελίδας σας.';
$txt['attach_dir_reserved'] = 'Αδύνατη η προσθήκη. Αυτός ο κατάλογος είναι για το σύστημα και δεν μπορεί να χρησιμοποιηθεί για συνημμένα.';
$txt['attach_dir_duplicate_msg'] = 'Αδύνατη η προσθήκη.Αυτός ο κατάλογος υπάρχει ήδη.';
$txt['attach_dir_exists_msg'] = 'Αδύνατη η μετακίνηση. Ένας κατάλογος υπάρχει ήδη σε αυτή την διαδρομή.';
$txt['attach_dir_base_dupe_msg'] = 'Αδύνατη η προσθήκη. Αυτός ο βασικός κατάλογος υπάρχει ήδη.';
$txt['attach_dir_base_no_create'] = 'Αδύνατη η δημιουργία.Παρακαλώ επιβεβαιώστε την διαδρομή ή δημιουργήστε τον κατάλογο χρησιμοποιώντας κάποια FTP εφαρμογή ή τον διαχειριστή φακέλων της σελίδας σας και δοκιμάστε ξανά.';
$txt['attach_dir_no_rename'] = 'Αδύνατη η μετακίνηση ή μετονομασία.Παρακαλώ επιβεβαιώστε ότι είναι σωστή η διαδρομή ή πως ο κατάλογος δεν περιέχει άλλους υποκαταλόγους.';
$txt['attach_dir_no_delete'] = 'Δεν είναι κενός και δεν μπορεί να διαγραφεί. Παρακαλώ χρησιμοποιήστε κάποια FTP εφαρμογή ή των διαχειριστή φακέλων της σελίδας σας.';
$txt['attach_dir_no_remove'] = 'Εξακολουθεί να περιέχει αρχεία ή είναι βασική διαδρομή και δεν μπορεί να διαγραφεί.';
$txt['attach_dir_is_current'] = 'Αδύνατη η αφαίρεση ενώ είναι επιλεγμένος ως τρέχων κατάλογος.';
$txt['attach_dir_is_current_bd'] = 'Αδύνατη η αφαίρεση ενώ είναι επιλεγμένος ως τρέχων βασικός κατάλογος.';
$txt['attach_last_dir'] = 'Τελευταίος ενεργός κατάλογος συνημμένων.';
$txt['attach_current_dir'] = 'Τρέχον φάκελος';
$txt['attach_current'] = 'Τρέχων';
$txt['attach_path_manage'] = 'Διαχείριση διαδρομών συνημμένων';
$txt['attach_directories'] = 'Κατάλογοι Συνημμένων';
$txt['attach_paths'] = 'Διαδρομές συνημμένων';
$txt['attach_path'] = 'Διαδρομή';
$txt['attach_current_size'] = 'Τρέχον μέγεθος (KB)';
$txt['attach_num_files'] = 'Αρχεία';
$txt['attach_dir_status'] = 'Κατάσταση';
$txt['attach_add_path'] = 'Προσθήκη διαδρομής';
$txt['attach_path_current_bad'] = 'Μη έγκυρη τρέχουσα διαδρομή συνημμένων.';
$txt['attachmentDirFileLimit'] = 'Μέγιστος αριθμός αρχείων ανα κατάλογο';

$txt['attach_base_paths'] = 'Διαδρομή βασικού καταλόγου';
$txt['attach_num_dirs'] = 'Κατάλογοι';
$txt['max_image_width'] = 'Μέγιστό πλάτος προεπισκόπησης για τις δημοσιευμένες ή επισυναπτόμενες εικόνες
';
$txt['max_image_height'] = 'Μέγιστό ύψος προεπισκόπησης για τις δημοσιευμένες ή επισυναπτόμενες εικόνες';

$txt['automanage_attachments'] = 'Επιλογή μέθοδού διαχείρισης του καταλόγων συνημμένων';
$txt['attachments_normal'] = '(Μη αυτόματη) ElkArte προεπιλεγμένη συμπεριφορά';
$txt['attachments_auto_years'] = '(Αυτόματα) Υποδιαίρεση κατά έτη';
$txt['attachments_auto_months'] = '(Αυτόματη) Υποδιαίρεση κατά έτη και μήνες';
$txt['attachments_auto_days'] = '(Αυτόματη) Υποδιαίρεση κατά έτη, μήνες και ημέρες';
$txt['attachments_auto_16'] = '(Αυτόματα) 16 τυχαίους καταλόγους';
$txt['attachments_auto_16x16'] = '(Αυτόματα) 16 τυχαίους καταλόγους με 16 τυχαίους υποκαταλόγους';
$txt['attachments_auto_space'] = '(Αυτόματα) Όταν επιτευχθεί ένα όριο χώρου καταλόγου';

$txt['use_subdirectories_for_attachments'] = 'Δημιουργήστε νέους καταλόγους μέσα σε έναν βασικό κατάλογο';
$txt['use_subdirectories_for_attachments_note'] = 'Διαφορετικά,οι νέοι κατάλογοι θα δημιουργηθούν  μέσα στον κύριο κατάλογο της ιστοσελίδας.';
$txt['basedirectory_for_attachments'] = 'Ορίστε έναν βασικό κατάλογο για συνημμένα';
$txt['basedirectory_for_attachments_current'] = 'Τρέχων βασικός κατάλογος ';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Παρακαλώ, σας επισημαίνουμε πως η διαδρομή είναι λάθος.<br />(<a href="{attach_repair_url}">Προσπάθεια επισκεύης</a>)</div> ';
$txt['attach_current_dir_warning'] = '<div class="smalltext">Φαίνεται να υπάρχει πρόβλημα με αυτή την διαδρομή.<br />(<a href="{attach_repair_url}">Προσπάθεια επισκευής</a>)</div> ';

$txt['attachment_transfer'] = 'Μεταφορά συνημμένων';
$txt['attachment_transfer_desc'] = 'Μεταφορά αρχείων μεταξύ καταλόγων.';
$txt['attachment_transfer_select'] = 'Επιλέξτε κατάλογο';
$txt['attachment_transfer_now'] = 'Μεταφορά';
$txt['attachment_transfer_from'] = 'Μεταφορά αρχείων από ';
$txt['attachment_transfer_auto'] = 'Αυτόματη μετακίνηση με βάση το διάστημα ή τον αριθμό αρχείων';
$txt['attachment_transfer_auto_select'] = 'Επιλογή κεντρικού καταλόγου';
$txt['attachment_transfer_to'] = ' Ή μετακινήστε τα σε έναν συγκεκριμένο κατάλογο.';
$txt['attachment_transfer_empty'] = 'Μεταφορά όλων των αρχείων από τον κεντρικό κατάλογο.';
$txt['attachment_transfer_no_base'] = 'Δεν υπάρχουν διαθέσιμοι βασικοί κατάλογοι.';
$txt['attachment_transfer_forum_root'] = 'Ριζικός κατάλογος ιστοσελίδας.';
$txt['attachment_transfer_no_room'] = 'Μέγιστο μέγεθος καταλόγου ή μέγιστο όριο αρχείων.';
$txt['attachment_transfer_no_find'] = 'Δεν βρέθηκαν αρχεία για μεταφορά.';
$txt['attachments_transfered'] = '%1$dτα αρχεία μεταφέρθηκαν σε%2$s';
$txt['attachments_not_transfered'] = '%1$d τα αρχεία δεν μεταφέρθηκαν.';
$txt['attachment_transfer_no_dir'] = 'Ούτε ο κατάλογος προέλευσης ούτε μία από τις επιλογές προορισμού έχουν επιλεγεί.';
$txt['attachment_transfer_same_dir'] = 'Δεν μπορείτε να επιλέξετε τον ίδιο κατάλογο ως πηγή και προορισμό.';
$txt['attachment_transfer_progress'] = 'Παρακαλώ περιμένετε. Η μεταφορά βρίσκεται σε εξέλιξη.';

$txt['avatar_settings'] = 'Γενικές ρυθμίσεις προτραίτων';
$txt['avatar_default'] = 'Ενεργοποιήστε ένα προεπιλεγμένο πορτραίτο για όλους τους χρήστες που δεν έχουν δικό τους πορτραίτο';
$txt['avatar_directory'] = 'Κατάλογος πορτραίτων';
$txt['avatar_url'] = 'URL πορτραίτων';
$txt['avatar_max_width'] = 'Μέγιστο πλάτος πορτραίτων σε pixels (px)';
$txt['avatar_max_height'] = 'Μέγιστο ύψος πορτραίτων σε pixels (px)';
$txt['avatar_action_too_large'] = 'Αν το πορτραίτο είναι πολύ μεγάλο...';
$txt['option_refuse'] = 'Να μην γίνει αποδεκτό';
$txt['option_resize'] = 'Αφήστε το CSS να αλλάξει το μέγεθος';
$txt['option_download_and_resize'] = 'Η λήψη και αλλαγή μεγέθους (απαιτεί το πρόσθετο GD  ή το ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Ενεργοποιήστε τη χρήση gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'Χρήση PNG για πορτραίτα που έχουν σμικρυνθεί';
$txt['avatar_img_enc_warning'] = 'Κανένα από τα δύο πρόσθετα GD module και ImageMagick δεν είναι εγκατεστημένα.Κάποια χαρακτηριστικά των πορτραίτων είναι απενεργοποιημένα';
$txt['avatar_external'] = 'Εξωτερικά πορτραίτα';
$txt['avatar_external_enabled'] = 'Ενεργοποίηση χρήσης εξωτερικών (απομακρυσμένων / URL) πορτραίτων';
$txt['avatar_upload'] = 'Πορτραίτα που μπορούν να φορτωθούν';
$txt['avatar_resize_options'] = 'Επιλογές αποθήκευσης διακομιστή';
$txt['avatar_upload_enabled'] = 'Ενεργοποιήστε τη μεταφόρτωση των πορτραίτων';
$txt['avatar_server_stored'] = 'Πορτραίτα αποθηκευμένα σε διακομιστή';
$txt['avatar_stored_enabled'] = 'Ενεργοποιήστε την επιλογή των αποθηκευμένων πορτραίτων';
$txt['profile_set_avatar'] = 'Οι ομάδες μελών που επιτρέπεται να επιλέγουν πορτραίτο';
$txt['avatar_select_permission'] = 'Επιλογή δικαιωμάτων για κάθε ομάδα';
$txt['avatar_download_external'] = 'Λήψη πορτραίτου από συγκεκριμένο URL';
$txt['custom_avatar_enabled'] = 'Φόρτωση πορτραίτων σε...';
$txt['option_attachment_dir'] = 'Κατάλογος συνημμένων';
$txt['option_specified_dir'] = 'Καθορισμένος κατάλογος...';
$txt['custom_avatar_dir'] = 'Κατάλογος φόρτωσης';
$txt['custom_avatar_dir_desc'] = 'Δεν πρέπει να είναι ο ίδιος με αυτό του καταλόγου του διακομιστή.';
$txt['custom_avatar_url'] = 'URL φόρτωσης';
$txt['custom_avatar_check_empty'] = 'Ο εξατομικευμένος κατάλογος πορτραίτων που έχετε ορίσει μπορεί να είναι κενός ή μη έγκυρος. Παρακαλείσθε να εξασφαλίσετε ότι αυτές οι ρυθμίσεις είναι σωστές.';
$txt['avatar_reencode'] = 'Επανακωδικοποίηση δυνητικά επικίνδυνων συνημμένων πορτραίτων';
$txt['avatar_reencode_note'] = '(απαιτείται το πρόσθετο GD)';
$txt['avatar_paranoid_warning'] = 'Οι εκτενείς έλεγχοι ασφαλείας πιθανόν να έχουν ως αποτέλεσμα έναν μεγάλο αριθμό απορριπτέων πορτραίτων.';
$txt['avatar_paranoid'] = 'Εκτέλεση εκτενών έλεγχων ασφαλείας σε μεταφορτωμένα συνημμένα πορτραίτα.';

$txt['repair_attachments'] = 'Συντήρηση συνημμένων';
$txt['repair_attachments_complete'] = 'Η συντήρηση ολοκληρώθηκε';
$txt['repair_attachments_complete_desc'] = 'Όλα τα επιλεγμένα σφάλματα έχουν διορθωθεί';
$txt['repair_attachments_no_errors'] = 'Δεν βρέθηκαν σφάλματα!';
$txt['repair_attachments_error_desc'] = 'Τα ακόλουθα σφάλματα βρέθηκαν κατά τη διάρκεια της συντήρησης. Ενεργοποιήστε το πλαίσιο δίπλα από τα σφάλματα που θέλετε να διορθώσετε και πατήστε το κουμπί "Συνέχεια".';
$txt['repair_attachments_continue'] = 'Συνέχεια';
$txt['repair_attachments_cancel'] = 'Άκυρο';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d μικρογραφίες δεν συσχετίζονται με συνημμένα';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d γονικά στοιχεία αναφέρεται ότι έχουν μικρογραφίες χωρίς να έχουν';
$txt['attach_repair_file_missing_on_disk'] = '%1$d συνημμένα/πορτραίτα έχουν καταχωρήσεις αλλά δεν υπάρχουν πλέον στον δίσκο';
$txt['attach_repair_file_wrong_size'] = '%1$d συνημμένα/πορτραίτα αναφέρεται ότι έχουν λάθος μέγεθος αρχείου';
$txt['attach_repair_file_size_of_zero'] = '%1$d συνημμένα/πορτραίτα έχουν μέγεθος μηδέν στον δίσκο. (Αυτά θα διαγραφούν)';
$txt['attach_repair_attachment_no_msg'] = '%1$d συνημμένα δεν έχουν πια κάποιο μήνυμα που να συσχετίζεται με αυτά';
$txt['attach_repair_avatar_no_member'] = '%1$d πορτραίτα δεν έχουν πια κάποιο μέλος που να συσχετίζεται με αυτά';
$txt['attach_repair_wrong_folder'] = '%1$d συνημμένα βρίσκονται σε λάθος φάκελο';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d τα αρχεία δεν έχουν αντιστοιχία δεδομένων με την βάση δεδομένων.(Αυτά θα διαγραφούν)';

$txt['news_title'] = 'Ειδήσεις και ενημερωτικά δελτία';
$txt['news_settings_desc'] = 'Εδώ μπορείτε να αλλάξετε τίς ρυθμίσεις και τα δικαιώματα σχετικά με τις ειδήσεις και τα ενημερωτικά δελτία.';
$txt['news_mailing_desc'] = 'Από αυτό το μενού μπορείτε να στείλετε μηνύματα σε όλα τα μέλη που είναι εγγεγραμμένα και έχουν εισάγει την διεύθυνση e-mail τους. Μπορείτε να τροποποιήσετε την λίστα διανομής, ή να στείλετε μηνύματα σε όλους. Χρήσιμο για σημαντικές ενημερώσεις/ειδήσεις.';
$txt['news_error_no_news'] = 'Τίποτα για προεπισκόπηση';
$txt['groups_edit_news'] = 'Ομάδες μελών που επιτρέπεται να τροποποιούν τις ειδήσεις';
$txt['groups_send_mail'] = 'Ομάδες μελών που επιτρέπεται να αποστέλλουν ενημερωτικά δελτία';
$txt['xmlnews_enable'] = 'Ενεργοποίηση ειδήσεων XML/RSS';
$txt['xmlnews_maxlen'] = 'Μέγιστο μέγεθος μηνύματος:<div class="smalltext">(0 για απενεργοποίηση, κακή ιδέα.)</div>';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Αριθμός στοιχείων στην ροή ειδήσεων';
$txt['xmlnews_maxlen_note'] = '(0 για απανεργοποίηση, κακή ιδέα.)';
$txt['editnews_clickadd'] = 'Κάντε κλικ εδώ για να προσθέσετε άλλη μια είδηση.';
$txt['editnews_remove_selected'] = 'Διαγραφή επιλεγμένων';
$txt['editnews_remove_confirm'] = 'Σίγουρα θέλετε να διαγράψετε τις επιλεγμένες ειδήσεις;';
$txt['censor_clickadd'] = 'Κάντε κλικ εδώ για να προσθέσετε άλλη μία λέξη.';

$txt['layout_controls'] = 'Κοινότητα';
$txt['logs'] = 'Αρχεία καταγραφής';
$txt['generate_reports'] = 'Δημιουργία αναφορών';

$txt['update_available'] = 'Υπάρχει διαθέσιμη αναβάθμιση!';
$txt['update_message'] = 'Χρησιμοποιείτε μια παλιά έκδοση του ElkArte, η οποία περιέχει μερικά σφάλματα τα οποία έχουν ήδη διορθωθεί.
	Σας συνιστούμε <a href="" id="update-link">να αναβαθμίσετε την κοινότητα</a> με την τελευταία έκδοση όσο το δυνατόν γρηγορότερα!';

$txt['manageposts'] = 'Μηνύματα και θέματα';
$txt['manageposts_title'] = 'Διαχείριση μηνυμάτων και θεμάτων';
$txt['manageposts_description'] = 'Εδώ μπορείτε να διαχειριστείτε όλες τις ρυθμίσεις σχετκά με τα θέματα και τα μηνύματα.';

$txt['manageposts_seconds'] = 'δευτερόλεπτα';
$txt['manageposts_minutes'] = 'λεπτά';
$txt['manageposts_characters'] = 'χαρακτήρες';
$txt['manageposts_days'] = 'ημέρες';
$txt['manageposts_posts'] = 'μηνύματα';
$txt['manageposts_topics'] = 'θέματα';

$txt['pollMode'] = 'Ενεργοποίηση ψηφοφοριών';

$txt['manageposts_settings'] = 'Ρυθμίσεις μηνυμάτων';
$txt['manageposts_settings_description'] = 'Εδώ μπορείτε να ρυθμίσετε όλα τα σχετικά με τα μηνύματα και την αποστολή μηνυμάτων.';

$txt['manageposts_bbc_settings'] = 'Κώδικας BBC ';
$txt['manageposts_bbc_settings_description'] = 'Ο κώδικας BBC (Bulletin Board Code) μπορεί να χρησιμοποιηθεί για να μορφοποιήσει τα μηνύματα της κοινότητας. Για παράδειγμα, για να τονιστεί η λέξη \'σπίτι\' μπορείτε να γράψετε [b]σπίτι[/b]. Όλες οι εντολές του BBC περικλείονται από άγκιστρα (\'[\' και \']\').';
$txt['manageposts_bbc_settings_title'] = 'Ρυθμίσεις κώδικα BBC';

$txt['manageposts_topic_settings'] = 'Ρυθμίσεις θεμάτων';
$txt['manageposts_topic_settings_description'] = 'Εδώ μπορείτε να κάνετε όλες τις ρυθμίσεις που αφορούν τα θέματα.';

$txt['managedrafts_settings'] = 'Ρυθμίσεις πρόχειρων';
$txt['managedrafts_settings_description'] = 'Εδώ μπορείτε να ορίσετε όλες τις ρυθμίσεις που αφορούν τα πρόχειρα.';
$txt['manage_drafts'] = 'Πρόχειρα';

$txt['mail_center'] = 'Κέντρο λίστας mail';
$txt['mm_emailerror'] = 'Αποτυχημένα Emails';
$txt['mm_emailfilters'] = 'Φίλτρα';
$txt['mm_emailparsers'] = 'Αναλυτές';
$txt['mm_emailtemplates'] = 'Πρότυπα';
$txt['mm_emailsettings'] = 'Επιλογές';

$txt['removeNestedQuotes'] = 'Αφαίρεση ένθετων παραθέσεων κατά την παράθεση';
$txt['enableSpellChecking'] = 'Ενεργοποίηση ορθογραφικού ελέγχου';
$txt['enableSpellChecking_warning'] = 'αυτό δεν λειτουργεί σε όλους τους διακομιστές!';
$txt['enableSpellChecking_error'] = 'δεν λειτουργεί στον διακομιστή σας.';
$txt['enableVideoEmbeding'] = 'Ενεργοποιήστε την αυτόματη ενσωμάτωση συνδέσμων βίντεο.';
$txt['enableCodePrettify'] = 'Ενεργοποιήστε την προεπεξεργασία των ετικετών κώδικα';
$txt['max_messageLength'] = 'Μέγιστο επιτρεπόμενο μέγεθος μηνύματος';
$txt['max_messageLength_zero'] = '0 για απεριόριστο.';
$txt['convert_to_mediumtext'] = 'Η βάση δεδομένων σας δεν είναι ρυθμισμένη για να δέχεται μηνύματα μεγαλύτερα των 65535 χαρακτήρων.Παρακαλώ χρησιμοποιήστε την σελίδα <a href="%1$s">συντήρηση βάσης δεδομένων </a> για την μετατροπή της βάσης δεδομένων και επιστρέψτε πίσω για να αυξήσετε το μέγεθος του μέγιστου επιτρεπόμενου ορίου δημοσίευσης. 
  ';
$txt['topicSummaryPosts'] = 'Αριθμός μηνυμάτων που θα προβάλλονται στην περίληψη του θέματος';
$txt['spamWaitTime'] = 'Χρόνος που απαιτείται μεταξύ αποστολών μηνυμάτων από την ίδια IP';
$txt['edit_wait_time'] = 'Περίοδος χάριτος για τροποποίηση μηνύματος';
$txt['edit_disable_time'] = 'Μέγιστος χρόνος μετά την αποστολή για τροποποίηση μηνύματος';
$txt['edit_disable_time_zero'] = '0 για απενεργοποίηση';
$txt['preview_characters'] = 'Μέγιστο μήκος προεπισκόπησης τελευταίας/πρώτης δημοσίευσης';
$txt['preview_characters_units'] = 'χαρακτήρες';
$txt['preview_characters_zero'] = '0 για να εμφανιστεί ολόκληρο το μήνυμα';
$txt['message_index_preview'] = 'Εμφάνιση προεπισκόπησης μηνυμάτων στο ευρετήριο μηνυμάτων';
$txt['message_index_preview_off'] = 'Να μην εμφανίζονται οι προεπισκοπήσεις';
$txt['message_index_preview_first'] = 'Εμφάνιση κειμένου της πρώτης ανάρτησης';
$txt['message_index_preview_last'] = 'Εμφάνιση κειμένου της τελευταίας ανάρτησης';

$txt['enableBBC'] = 'Ενεργοποίηση κώδικα BBC (Bulletin Board Code)';
$txt['enablePostHTML'] = 'Ενεργοποίηση <em>βασικής</em> HTML στα μηνύματα';
$txt['autoLinkUrls'] = 'Δημιουργία συνδέσμου αυτομάτως στα URL';
$txt['disabledBBC'] = 'Ενεργοποίημένες εντολές BBC';
$txt['bbcTagsToUse'] = 'Ενεργοποίημένες εντολές BBC';
$txt['bbcTagsToUse_select'] = 'Επιλέξτε τις εντολές που επιτρέπεται να χρησιμοποιηθούν';
$txt['bbcTagsToUse_select_all'] = 'Επιλογή όλων των εντολών';

$txt['enableParticipation'] = 'Ενεργοποίηση εικονιδίων συμμετοχής';
$txt['enableFollowup'] = 'Ενεργοποιήση παρακολούθησης';
$txt['enable_unwatch'] = 'Ενεργοποιήστε την μη παρακολούθηση θεμάτων';
$txt['oldTopicDays'] = 'Χρόνος πρίν το θέμα αναφερθεί ως παλιό, κατά την απάντηση';
$txt['oldTopicDays_zero'] = '0 για απενεργοποίηση';
$txt['defaultMaxTopics'] = 'Αριθμός των θεμάτων ανά σελίδα στη λίστα θεμάτων';
$txt['defaultMaxMessages'] = 'Αριθμός μηνυμάτων ανά σελίδα στη σελίδα του θέματος';
$txt['disable_print_topic'] = 'Απενεργοποιήστε τη δυνατότητα εκτύπωσης θέματος ';
$txt['hotTopicPosts'] = 'Αριθμός δημοσιεύσεων για δημοφιλές θέμα';
$txt['hotTopicVeryPosts'] = 'Αριθμός δημοσιεύσεων για πολύ δημοφιλές θέμα';
$txt['useLikesNotViews'] = 'Χρησιμοποιήστε αριθμό likes στα μηνύματα για να ορίσετε καυτά θέματα';
$txt['enableAllMessages'] = 'Μέγιστο μέγεθος θέματος για προβολή &quot;Όλων&quot; των μηνυμάτων';
$txt['enableAllMessages_zero'] = '0 για να μην προβάλλονται ποτέ &quot;Όλα&quot;';
$txt['disableCustomPerPage'] = 'Απενεργοποίηση εξατομίκευσης πλήθους θεμάτων/μηνυμάτων ανά σελίδα';
$txt['enablePreviousNext'] = 'Ενεργοποίηση συνδέσμου προηγούμενο/επόμενο θέμα';

$txt['not_done_title'] = 'Δεν έχει ολοκληρωθεί ακόμη!';
$txt['not_done_reason'] = 'Για να αποφύγετε υπερφόρτωση του διακομιστή, η διεργασία έχει προσωρινά διακοπεί. Θα συνεχιστεί αυτόματα σε μερικά δευτερόλεπτα. Αν δεν γίνει αυτό, παρακαλώ κάντε κλικ στο Συνέχεια.';
$txt['not_done_continue'] = 'Συνέχεια';

$txt['general_settings'] = 'Γενικά';
$txt['database_paths_settings'] = 'Βάση δεδομένων και διαδρομές';
$txt['cookies_sessions_settings'] = 'Cookies και περίοδοι λειτουργίας';
$txt['caching_settings'] = 'Προσωρινή αποθήκευση (cache)';
$txt['loadavg'] = 'Φόρτωση διακομιστή';
$txt['loadavg_settings'] = 'Διαχείριση φόρτωσης';
$txt['phpinfo_settings'] = 'πληροφορίες PHP';
$txt['phpinfo_localsettings'] = 'Τοπικές ρυθμίσεις';
$txt['phpinfo_defaultsettings'] = 'Προεπιλεγμένες ρυθμίσεις';
$txt['phpinfo_itemsettings'] = 'Επιλογές';

$txt['language_configuration'] = 'Γλώσσες';
$txt['language_description'] = 'Αυτό το τμήμα σας επιτρέπει να τροποποιείτε τις γλώσσες που έχουν εγκατασταθεί στο φόρουμ σας, και να μεταφορτώσετε νέες από τον ιστοτόπο του ElkArte.Επίσης από εδώ μπορείτε να τροποποιήσετε ρυθμίσεις σχετικές με τις γλώσσες.';
$txt['language_edit'] = 'Τροποποίηση γλωσσών';
$txt['language_add'] = 'Προσθήκη γλώσσας';
$txt['language_settings'] = 'Επιλογές';

$txt['advanced'] = 'Προχωρημένο';
$txt['simple'] = 'Απλό';

$txt['admin_news_select_recipients'] = 'Επιλέξτε ποιοι θα λαμβάνουν αντίγραφο του ενημερωτικού δελτίου';
$txt['admin_news_select_group'] = 'Ομάδες μελών';
$txt['admin_news_select_group_desc'] = 'Επιλέξτε τις ομάδες που θα λαμβάνουν το ενημερωτικό δελτίο.';
$txt['admin_news_select_members'] = 'Μέλη';
$txt['admin_news_select_members_desc'] = 'Επιπλέον μέλη που θα λαμβάνουν το ενημερωτικό δελτίο.';
$txt['admin_news_select_excluded_members'] = 'Εξαιρούμενα μέλη';
$txt['admin_news_select_excluded_members_desc'] = 'Μέλη που δεν πρέπει να λαμβάνουν το ενημερωτικό δελτίο.';
$txt['admin_news_select_excluded_groups'] = 'Εξαιρούμενες ομάδες';
$txt['admin_news_select_excluded_groups_desc'] = 'Επιλέξτε ομάδες που δεν πρέπει να λαμβάνουν το ενημερωτικό δελτίο.';
$txt['admin_news_select_email'] = 'Διευθύνσεις email';
$txt['admin_news_select_email_desc'] = 'Μια λίστα από διευθύνσεις, χωρισμένες με ελλ. ερωτηματικό, που δεν πρέπει να λαμβάνουν το ενημερωτικό δελτίο. (π.χ. διεύθυνση1; διεύθυνση2)';
$txt['admin_news_select_override_notify'] = 'Παράκαμψη ρυθμίσεων ειδοποιήσεων';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Δεν μπορείτε να στείλετε προσωπικό μήνυμα σε μια διεύθυνση email. Αν συνεχίσετε, όλες οι εισαγμένες διευθύνσεις email θα αγνοηθούν.\\n\\nΣίγουρα θέλετε να το κάνετε αυτό;';

$txt['mailqueue_browse'] = 'Εμφάνιση ουράς';
$txt['mailqueue_settings'] = 'Επιλογές';

$txt['admin_search'] = 'Γρήγορη αναζήτηση';
$txt['admin_search_type_internal'] = 'Εργασία/Ρύθμιση';
$txt['admin_search_type_member'] = 'Μέλος';
$txt['admin_search_type_online'] = 'Ηλεκτρονικό εγχειρίδιο';
$txt['admin_search_go'] = 'Ψάξε';
$txt['admin_search_results'] = 'Αποτελέσματα αναζήτησης';
$txt['admin_search_results_desc'] = 'Αποτελέσματα για την αναζήτηση: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Αναζήτηση ξανά';
$txt['admin_search_results_none'] = 'Δεν βρέθηκαν αποτελέσματα!';

$txt['admin_search_section_sections'] = 'Τμήμα';
$txt['admin_search_section_settings'] = 'Ρύθμιση';

$txt['core_settings_title'] = 'Χαρακτηριστικά πυρήνα';
$txt['core_settings_desc'] = 'Αυτή η σελίδα σάς επιτρέπει να ενεργοποιήσετε ή να απενεργοποιήσετε τις προαιρετικές δυνατότητες του κοινότητας σας.';
$txt['mods_cat_features'] = 'Γενικά';
$txt['mods_cat_security_general'] = 'Γενικά';
$txt['antispam_title'] = 'Anti-spam';
$txt['badbehavior_title'] = 'Μη αποδεκτή συμπεριφορά ';
$txt['mods_cat_modifications_misc'] = 'Διάφορα';
$txt['mods_cat_layout'] = 'Διαρρύθμιση';
$txt['karma'] = 'Κάρμα';
$txt['moderation_settings_short'] = 'Συντονισμός';
$txt['signature_settings_short'] = 'Υπογραφές';
$txt['custom_profile_shorttitle'] = 'Πεδία προφίλ';
$txt['pruning_title'] = 'Διαγραφή αρχείων καταγραφής';

$txt['core_settings_activation_message'] = 'Το χαρακτηριστικό {core_feature} έχει ενεργοποιηθεί, κάντε κλικ στον τίτλο για να το ρυθμίσετε';
$txt['core_settings_deactivation_message'] = 'Το χαρακτηριστικό {core_feature} έχει απενεργοποιηθεί';
$txt['core_settings_generic_error'] = 'Παρουσιάστηκε σφάλμα, επαναλάβετε τη φόρτωση της σελίδας και προσπαθήστε ξανά.';

$txt['boardsEdit'] = 'Τροποποίηση πινάκων';
$txt['mboards_new_cat'] = 'Δημιουργία νέας κατηγορίας';
$txt['manage_holidays'] = 'Διαχείριση εορτών';
$txt['calendar_settings'] = 'Ρυθμίσεις ημερολογίου';
$txt['search_weights'] = 'Βαρύτητες';
$txt['search_method'] = 'Μέθοδος αναζήτησης';
$txt['search_sphinx'] = 'Διαμόρφωση Sphinx';

$txt['smiley_sets'] = 'Σύνολα φατσούλων';
$txt['smileys_add'] = 'Προσθήκη φατσούλας';
$txt['smileys_edit'] = 'Τροποποίηση φατσούλων';
$txt['smileys_set_order'] = 'Ορισμός διάταξης φατσούλων';
$txt['icons_edit_message_icons'] = 'Τροποποίηση εικονιδίων μηνυμάτων';

$txt['membergroups_new_group'] = 'Προσθήκη ομάδας μελών';
$txt['membergroups_edit_groups'] = 'Τροποποίηση ομάδας μελών';
$txt['permissions_groups'] = 'Δικαιώματα ανά ομάδα μελών';
$txt['permissions_boards'] = 'Δικαιώματα ανά πίνακα';
$txt['permissions_profiles'] = 'Τροποποίηση προφίλ';
$txt['permissions_post_moderation'] = 'Συντονισμός μηνυμάτων';

$txt['browse_packages'] = 'Εμφάνιση πακέτων';
$txt['download_packages'] = 'Λήψη πακέτων';
$txt['upload_packages'] = 'Μεταφόρτωση πακέτου';
$txt['installed_packages'] = 'Εγκατεστημένα πακέτα';
$txt['package_file_perms'] = 'Δικαιώματα αρχείων';
$txt['package_settings'] = 'Επιλογές';
$txt['package_servers'] = 'Διακομιστές πακέτων';
$txt['themeadmin_admin_title'] = 'Διαχείριση και εγκατάσταση';
$txt['themeadmin_list_title'] = 'Ρυθμίσεις εμφάνισης';
$txt['themeadmin_reset_title'] = 'Επιλογές μελών';
$txt['themeadmin_edit_title'] = 'Τροποποίηση εμφανίσεων';
$txt['admin_browse_register_new'] = 'Εγγραφή νέου μέλους';

$txt['search_engines'] = 'Μηχανές αναζήτησης';
$txt['spider_logs'] = 'Αρχεία καταγραφής';
$txt['spider_stats'] = 'Στατιστικά';

$txt['paid_subscriptions'] = 'Συνδρομές επί πληρωμή';
$txt['paid_subs_view'] = 'Εμφάνιση συνδρομών';

$txt['maintain_sub_hooks_list'] = 'Ενσωμάτωση Hooks';
$txt['hooks_field_hook_name'] = 'Όνομα Hook';
$txt['hooks_field_function_name'] = 'Function Name';
$txt['hooks_field_function'] = 'Function';
$txt['hooks_field_included_file'] = 'Included file';
$txt['hooks_field_file_name'] = 'Όνομα αρχείου';
$txt['hooks_field_hook_exists'] = 'Κατάσταση';
$txt['hooks_active'] = 'Exists';
$txt['hooks_disabled'] = 'Απενεργοποιημένο'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Not found';
$txt['hooks_no_hooks'] = 'Επί του παρόντος δεν υπάρχουν hook στο σύστημα.';
$txt['hooks_disable_legend'] = 'Υπόμνημα';
$txt['hooks_disable_legend_exists'] = 'το hook υπάρχει και είναι ενεργό';
$txt['hooks_disable_legend_disabled'] = 'το hook υπάρχει αλλά έχει απενεργοποιηθεί
';
$txt['hooks_disable_legend_missing'] = 'το hook δεν βρέθηκε';
$txt['hooks_reset_filter'] = 'Reset filter';

$txt['board_perms_allow'] = 'Επιτρέπεται';
$txt['board_perms_ignore'] = 'Αγνόηση';
$txt['board_perms_deny'] = 'Αρνείται';
$txt['all_boards_in_cat'] = 'Όλοι οι πίνακες σε αυτήν την κατηγορία';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Words separator';

$txt['admin_order_title'] = 'Ordering Error';
$txt['admin_order_error'] = 'An unknown error occurred while processing your request';

// Known controllers that can work on the front page
$txt['default'] = 'Προεπιλεγμένο';
$txt['front_page'] = 'Επιλέξτε την ενέργεια που θα εμφανιστεί στην πρώτη σελίδα:';

$txt['BoardIndex_Controller'] = 'Κεντρική σελίδα';
$txt['MessageIndex_Controller'] = 'Περιεχόμενο κεντρικής σελίδας';
$txt['message_index_frontpage'] = 'Επιλέξτε το πίνακα που θα εμφανιστεί στην πρώτη σελίδα:';
$txt['Recent_Controller'] = 'Πρόσφατες δημοσιεύσεις';
$txt['recent_frontpage'] = 'Αριθμός μηνυμάτων που θα εμφανίζονται';
