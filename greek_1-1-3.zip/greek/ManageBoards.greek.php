<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Διαχείριση πινάκων και κατηγοριών';
$txt['order'] = 'Σειρά';
$txt['full_name'] = 'Πλήρες όνομα';
$txt['name_on_display'] = 'Αυτό είναι το όνομα που θα εμφανίζεται.';
$txt['boards_and_cats_desc'] = 'Edit your categories and boards here. List multiple moderators as <em>&quot;username&quot;, &quot;username&quot;</em>. (these must be usernames and *not* display names)<br />To create a new board, click the Add Board button.<br />To move a board you can drag and drop it to its new location in the list (across cataegories and Child of locations)<br />To create a new board as a child of a current board, select "Child of..." from the Order drop down menu when creating the board.';
$txt['parent_members_only'] = 'Κοινά μέλη';
$txt['parent_guests_only'] = 'Επισκέπτες';
$txt['catConfirm'] = 'Θέλετε σίγουρα να διαγράψετε αυτή τη κατηγορία;';
$txt['boardConfirm'] = 'Θέλετε σίγουρα να διαγράψετε αυτόν τον πίνακα;';

$txt['catEdit'] = 'Τροποποίηση κατηγορίας';
$txt['collapse_enable'] = 'Με σύμπτυξη';
$txt['collapse_desc'] = 'Να επιτρέπεται στους χρήστες να συμπτύσσουν αυτήν την κατηγορία';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'Μετά ';
$txt['mboards_order_first'] = 'Στην πρώτη θέση';
$txt['mboards_board_error'] = 'Failed to resolve move location.';

$txt['mboards_new_board'] = 'Προσθήκη πίνακα';
$txt['mboards_new_cat_name'] = 'Νέα κατηγορία';
$txt['mboards_add_cat_button'] = 'Προσθήκη κατηγορίας';
$txt['mboards_new_board_name'] = 'Νέος πίνακας';

$txt['mboards_modify'] = 'τροποποίηση';
$txt['mboards_permissions'] = 'δικαιώματα';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Σίγουρα θέλετε να ρυθμίσετε αυτόν το πίνακα ώστε να χρησιμοποιεί τοπικά δικαιώματα;';

$txt['mboards_delete_cat'] = 'Διαγραφή κατηγορίας';
$txt['mboards_delete_board'] = 'Διαγραφή πίνακα';

$txt['mboards_delete_cat_contains'] = 'Η διαγραφή αυτής της κατηγορίας θα μετακινήσει επίσης τους παρακάτω θυγατρικούς πίνακες, συμπεριλαμβανομένων όλων των θεμάτων, μηνυμάτων και συνημμένων μέσα σε κάθε πίνακα';
$txt['mboards_delete_option1'] = 'Διαγραφή κατηγορίας και όλων των πινάκων που περιέχονται σε αυτή.';
$txt['mboards_delete_option2'] = 'Διαγραφή κατηγορίας και μετακίνηση όλων των πινάκων που περιέχονται σε αυτή στο';
$txt['mboards_delete_board_contains'] = 'Deleting this board will also move the sub-boards below, including all topics, posts and attachments within each board';
$txt['mboards_delete_board_option1'] = 'Delete board and move sub-boards contained within to category level.';
$txt['mboards_delete_board_option2'] = 'Delete board and move all sub-boards contained within to';
$txt['mboards_delete_what_do'] = 'Επιλέξτε τι θέλετε να κάνετε με αυτούς τους πίνακες';
$txt['mboards_delete_confirm'] = 'Επιβεβαίωση';
$txt['mboards_delete_cancel'] = 'Άκυρο';

$txt['mboards_category'] = 'Κατηγορία';
$txt['mboards_description'] = 'Περιγραφή';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Επιτρεπόμενες ομάδες';
$txt['mboards_groups_desc'] = 'Ομάδες που επιτρέπεται να έχουν πρόσβαση στον πίνακα.<br /><em>Σημείωση: Αν το μέλος ανήκει σε οποιαδήποτε από τις επιλεγμένες ομάδες χρηστών, θα έχουν πρόσβαση σε αυτόν τον πίνακα.</em>';
$txt['mboards_groups_regular_members'] = 'Αυτή η ομάδα περιέχει όλα τα μέλη για τα οποία δεν έχει οριστεί κύρια ομάδα.';
$txt['mboards_groups_post_group'] = 'Αυτή η ομάδα είναι ομάδα με βάση τις δημοσιεύσεις.';
$txt['mboards_moderators'] = 'Συντονιστές';
$txt['mboards_moderators_desc'] = 'Πρόσθετα μέλη που θα έχουν δικαιώματα συντονισμού στον πίνακα. Σημειώστε ότι οι διαχειριστές δεν χρειάζεται να αναφέρονται εδώ.';
$txt['mboards_count_posts'] = 'Καταμέτρηση μηνυμάτων';
$txt['mboards_count_posts_desc'] = 'Όταν δημοσιεύονται νέες απαντήσεις και θέματα αυξάνεται ο αριθμός των μηνυμάτων των αντίστοιχων μελών.';
$txt['mboards_unchanged'] = 'Μη αλλαγμένο';
$txt['mboards_theme'] = 'Εμφάνιση πίνακα';
$txt['mboards_theme_desc'] = 'Δίνει τη δυνατότητα αλλαγής της εμφάνιση του φόρουμ μόνο μέσα σε αυτόν τον πίνακα.';
$txt['mboards_theme_default'] = '(γενική προεπιλογή φόρουμ)';
$txt['mboards_override_theme'] = 'Παράκαμψη εμφάνισης μέλους';
$txt['mboards_override_theme_desc'] = 'Χρησιμοποίηση της εμφάνισης αυτού του πίνακα ακόμα και αν το μέλος δεν χρησιμοποιεί την προεπιλεγμένη εμφάνιση.';

$txt['mboards_redirect'] = 'Ανακατεύθυνση σε μια διαδικτυακή διεύθυνση';
$txt['mboards_redirect_desc'] = 'Ενεργοποιήστε αυτήν την επιλογή για να ανακατευθύνετε όσους εισέρχονται σε αυτόν τον πίνακα σε μια άλλη διαδικτυακή διεύθυνση.';
$txt['mboards_redirect_url'] = 'Διεύθυνση για ανακατεύθυνση';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Μηδενισμός μετρητή ανακατεύθυνσης';
$txt['mboards_redirect_reset_desc'] = 'Με την επιλογή αυτή μηδενίζεται ο μετρητής ανακατεύθυνσης για αυτόν τον πίνακα.';
$txt['mboards_current_redirects'] = 'Αυτή τη στιγμή: %1$s';
$txt['mboards_redirect_disabled'] = 'Σημείωση: Ο πίνακας πρέπει να είναι άδειος από θέματα για να ενεργοποιηθεί αυτή η δυνατότητα.';
$txt['mboards_redirect_disabled_recycle'] = 'Σημείωση: Δεν μπορείτε να ορίσετε τον πίνακα ανακύκλωσης ως πίνακα ανακατεύθυνσης.';

$txt['mboards_order_before'] = 'Πριν';
$txt['mboards_order_child_of'] = 'Θυγατρικός του';
$txt['mboards_order_in_category'] = 'Στην κατηγορία';
$txt['mboards_current_position'] = 'Παρούσα θέση';
$txt['no_valid_parent'] = 'Ο πίνακας %1$s δεν έχει έγκυρο γονικό πίνακα. Χρησιμοποιήστε τη λειτουργία \'εύρεση και διόρθωση σφαλμάτων\' για να το διορθώσετε.';

$txt['mboards_recycle_disabled_delete'] = 'You must select an alternative recycle bin board or disable recycling before you can delete this board.';

$txt['mboards_settings_desc'] = 'Τροποποίηση γενικών ρυθμίσεων για πίνακες και κατηγορίες.';
$txt['groups_manage_boards'] = 'Ομάδες μελών που επιτρέπεται να διαχειρίζονται πίνακες και κατηγορίες';
$txt['recycle_enable'] = 'Ενεργοποίηση ανακύκλωσης διαγραμμένων θεμάτων';
$txt['recycle_board'] = 'Πίνακας για ανακυκλωμένα θέματα';
$txt['recycle_board_unselected_notice'] = 'Έχετε ενεργοποιήσει την ανακύκλωση θεμάτων χωρίς να έχετε ορίσει πίνακα στον οποίο θα μπουν.  Αυτή η λειτουργία δεν θα ενεργοποιηθεί μέχρι να ορίσετε έναν πίνακα για να μπαίνουν τα ανακυκλωμένα θέματα.';
$txt['countChildPosts'] = 'Μέτρηση μηνυμάτων θυγατρικού στο σύνολο του γονικού';
$txt['allow_ignore_boards'] = 'Να επιτρέπεται να αγνοούνται οι πίνακες';
$txt['deny_boards_access'] = 'Enable the option to deny board access based on membergroup';
$txt['boardsaccess_option_desc'] = 'For each permission you can choose \'Allow\' (A), \'Ignore\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />If you deny access, any member - (including moderators) - in that group will be denied access.<br />For this reason, you should set deny carefully, only when <strong>necessary</strong>. Ignore, on the other hand, denies unless otherwise granted.';

$txt['mboards_select_destination'] = 'Επιλέξτε προορισμό για τον πίνακα \'<strong>%1$s</strong>\'';
$txt['mboards_cancel_moving'] = 'Ακύρωση μετακίνησης';
$txt['mboards_move'] = 'μετακίνηση';

$txt['mboards_no_cats'] = 'Δεν έχουν οριστεί ακόμα κατηγορίες ή πίνακες.';
