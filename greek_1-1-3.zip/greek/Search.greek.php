<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Ορισμός παραμέτρων αναζήτησης';
$txt['choose_board'] = 'Επιλέξτε πίνακα για αναζήτηση ή αναζητήστε σε όλους';
$txt['all_words'] = 'Ταίριασμα όλων των λέξεων';
$txt['any_words'] = 'Ταίριασμα οποιωνδήποτε λέξεων';
$txt['by_user'] = 'Από χρήστη';

$txt['search_post_age'] = 'Ηλικία μηνύματος';
$txt['search_between'] = 'μεταξύ';
$txt['search_and'] = 'και';
$txt['search_options'] = 'Επιλογές';
$txt['search_show_complete_messages'] = 'Εμφάνιση αποτελεσμάτων ως μηνύματα';
$txt['search_subject_only'] = 'Μόνο τίτλοι θεμάτων';
$txt['search_relevance'] = 'Σχετικότητα';
$txt['search_date_posted'] = 'Ημερομηνία μηνύματος';
$txt['search_order'] = 'Ταξινόμηση αποτελεσμάτων';
$txt['search_orderby_relevant_first'] = 'Πρώτα τα πιο σχετικά αποτελέσματα';
$txt['search_orderby_large_first'] = 'Πρώτα τα μεγαλύτερα θέματα';
$txt['search_orderby_small_first'] = 'Πρώτα τα μικρότερα θέματα';
$txt['search_orderby_recent_first'] = 'Πρώτα τα νεότερα θέματα';
$txt['search_orderby_old_first'] = 'Πρώτα τα παλαιότερα θέματα';
$txt['search_visual_verification_label'] = 'Επαλήθευση';
$txt['search_visual_verification_desc'] = 'Παρακαλούμε δώστε τον κωδικό στην παραπάνω εικόνα για να χρησιμοποιήσετε την αναζήτηση.';

$txt['search_specific_topic'] = 'Αναζήτηση μόνο των μηνυμάτων στο θέμα;';

$txt['groups_search_posts'] = 'Ομάδες μελών με πρόσβαση στη λειτουργία αναζήτησης';
$txt['search_dropdown'] = 'Enable the Quick Search dropdown';
$txt['search_results_per_page'] = 'Αριθμός αποτελεσμάτων αναζήτησης ανά σελίδα';
$txt['search_weight_frequency'] = 'Σχετική βαρύτητα αναζήτησης για το πλήθος ταιριαστών μηνυμάτων στο θέμα';
$txt['search_weight_age'] = 'Σχετική βαρύτητα αναζήτησης για την παλαιότητα του τελευταίου ταιριαστού μηνύματος';
$txt['search_weight_length'] = 'Σχετική βαρύτητα αναζήτησης για το μέγεθος του θέματος';
$txt['search_weight_subject'] = 'Σχετική βαρύτητα αναζήτησης για ταιριαστό τίτλο θέματος';
$txt['search_weight_first_message'] = 'Σχετική βαρύτητα αναζήτησης για το πρώτο ταιριαστό μήνυμα';
$txt['search_weight_sticky'] = 'Relative search weight for a pinned topic';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Here you can change the basic settings of the search function.';
$txt['search_settings_title'] = 'Search Settings';

$txt['search_weights_desc'] = 'Here you can change the individual components of the relevance rating.';
$txt['search_weights_sphinx'] = 'To update weight factors with Sphinx, you must generate and install a new sphinx.conf file.';
$txt['search_weights_title'] = 'Αναζήτηση - βαρύτητες';
$txt['search_weights_total'] = 'Σύνολο';
$txt['search_weights_save'] = 'Αποθήκευση';

$txt['search_method_desc'] = 'Εδώ μπορείτε να ορίσετε τη μέθοδο αναζήτησης.';
$txt['search_method_title'] = 'Αναζήτηση - μέθοδος';
$txt['search_method_save'] = 'Αποθήκευση';
$txt['search_method_messages_table_space'] = 'χώρος που χρησιμοποιείται από τα μηνύματα του φόρουμ στη βάση δεδομένων';
$txt['search_method_messages_index_space'] = 'χώρος που χρησιμοποιείται για το ευρετήριο μηνυμάτων στη βάση δεδομένων';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Ευρετήριο πλήρους κειμένου';
$txt['search_method_no_index_exists'] = 'δεν υπάρχει αυτή τη στιγμή';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'δεν μπορεί να δημιουργηθεί επειδή το μέγιστο μήκος μηνύματος είναι πάνω από 65535 ή το τύπος του πίνακα SQL δεν είναι MyISAM';
$txt['search_method_index_already_exists'] = 'έχει ήδη δημιουργηθεί';
$txt['search_method_fulltext_remove'] = 'αφαίρεση ευρετηρίου πλήρους κειμένου';
$txt['search_method_index_partial'] = 'μερικός ευρετηριασμός';
$txt['search_index_custom_resume'] = 'συνέχεια';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'In order to be able to use fulltext search, you\\\'ll have to create a fulltext index first.';
$txt['search_index_custom_warning'] = 'Για να μπορέσετε να χρησιμοποιήσετε την αναζήτηση προσαρμοσμένου ευρετηρίου, θα πρέπει πρώτα να δημιουργήσετε ένα προσαρμοσμένο ευρετήριο!';

$txt['search_index'] = 'Ευρετήριο αναζήτησης';
$txt['search_index_none'] = 'Χωρίς ευρετήριο';
$txt['search_index_custom'] = 'Προσαρμοσμένο ευρετήριο';
$txt['search_index_label'] = 'Ευρετήριο';
$txt['search_index_size'] = 'Μέγεθος';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Επιβολή χρήσης ευρετηρίου αναζήτησης';
$txt['search_match_words'] = 'Ταίριασμα ολόκληρης λέξης μόνο';
$txt['search_max_results'] = 'Μέγιστος αριθμός αποτελεσμάτων';
$txt['search_max_results_disable'] = '(0: χωρίς όριο)';
$txt['search_floodcontrol_time'] = 'Ελάχιστος χρόνος μεταξύ αναζητήσεων από το ίδιο μέλος';
$txt['search_floodcontrol_time_desc'] = '(σε δευτερόλεπτα, 0 για απεριόριστο)';

$txt['additional_search_engines'] = 'Additional search engines';
$txt['setup_search_engine_add_more'] = 'Add another search engine';

$txt['search_create_index'] = 'Δημιουργία ευρετηρίου';
$txt['search_create_index_why'] = 'Γιατί να δημιουργήσω ευρετήριο αναζήτησης;';
$txt['search_create_index_start'] = 'Δημιουργία';
$txt['search_predefined'] = 'Προκαθορισμένο προφίλ';
$txt['search_predefined_small'] = 'Ευρετήριο μικρού μεγέθους';
$txt['search_predefined_moderate'] = 'Ευρετήριο μεσαίου μεγέθους';
$txt['search_predefined_large'] = 'Ευρετήριο μεγάλου μεγέθους';
$txt['search_create_index_continue'] = 'Συνέχεια';
$txt['search_create_index_not_ready'] = 'ElkArte is currently creating a search index of your messages. To avoid overloading your server, the process has been temporarily paused. It should automatically continue in a few seconds. If it doesn\'t, please click continue below.';
$txt['search_create_index_progress'] = 'Πρόοδος';
$txt['search_create_index_done'] = 'Custom search index successfully created.';
$txt['search_create_index_done_link'] = 'Συνέχεια';
$txt['search_double_index'] = 'Δημιουργήσατε δύο ευρετήρια του πίνακα μηνυμάτων. Για καλύτερη απόδοση συνιστούμε να διαγράψετε ένα από τα δύο ευρετήρια.';

$txt['search_error_indexed_chars'] = 'Μη έγκυρος αριθμός ευρετηριασμένων χαρακτήρων. Απαιτούνται τουλάχιστον 3 για ένα χρήσιμο ευρετήριο.';
$txt['search_error_max_percentage'] = 'Μη έγκυρο ποσοστών λέξεων παράβλεψης. Χρησιμοποιήστε μια τιμή τουλάχιστον 5%.';
$txt['error_string_too_long'] = 'Η λέξη/φράση για αναζήτηση πρέπει να είναι μικρότερη από %1$d χαρακτήρες.';

$txt['search_warning_ignored_word'] = 'The following term has been ignored in your search';
$txt['search_warning_ignored_words'] = 'The following terms have been ignored in your search';

$txt['search_adjust_query'] = 'Ρύθμιση παραμέτρων αναζήτησης';
$txt['search_adjust_submit'] = 'Αναθεώρηση αναζήτησης';
$txt['search_did_you_mean'] = 'Ίσως θέλατε να ψάξετε για';

$txt['search_example'] = '<em>π.χ.</em> Όργουελ "Η φάρμα των ζώων" -ταινία';

$txt['search_engines_description'] = 'Σε αυτή τη σελίδα μπορείτε να ορίσετε με τι λεπτομέρεια θέλετε να ανιχνεύσετε τις μηχανές αναζήτησης όταν επισκέπτονται το φόρουμ σας, καθώς και να δείτε τα αρχεία καταγραφής μηχανών αναζήτησης.';
$txt['spider_mode'] = 'Search Engine Tracking Level';
$txt['spider_mode_note'] = 'Note higher level tracking increases server resource requirement.';
$txt['spider_mode_off'] = 'Απενεργοποιημένο';
$txt['spider_mode_standard'] = 'Κανονικά';
$txt['spider_mode_high'] = 'Συντονισμός';
$txt['spider_mode_vhigh'] = 'Aggressive';
$txt['spider_settings_desc'] = 'You can change settings for spider tracking from this page. Note, if you wish to <a href="%1$s">enable automatic pruning of the hit logs you can set this up here</a>';

$txt['spider_group'] = 'Apply restrictive permissions from group';
$txt['spider_group_note'] = 'To enable you to stop spiders indexing some pages.';
$txt['spider_group_none'] = 'Απενεργοποιημένο';

$txt['show_spider_online'] = 'Εμφάνιση αραχνών στη λίστα των συνδεδεμένων χρηστών';
$txt['show_spider_online_no'] = 'Καθόλου';
$txt['show_spider_online_summary'] = 'Εμφάνιση πλήθους αραχνών';
$txt['show_spider_online_detail'] = 'Εμφάνιση λεπτομερειών αράχνης';
$txt['show_spider_online_detail_admin'] = 'Εμφάνιση λεπτομερειών αράχνης - για διαχειριστές μόνο';

$txt['spider_name'] = 'Όνομα αράχνης';
$txt['spider_last_seen'] = 'Τελευταία εμφάνιση';
$txt['spider_last_never'] = 'Ποτέ';
$txt['spider_agent'] = 'User Agent';
$txt['spider_ip_info'] = 'Διευθύνσεις IP';
$txt['spiders_add'] = 'Προσθήκη νέας αράχνης';
$txt['spiders_edit'] = 'Τροποποίηση αράχνης';
$txt['spiders_remove_selected'] = 'Διαγραφή επιλεγμένων';
$txt['spider_remove_selected_confirm'] = 'Are you sure you want to remove these spiders?\\n\\nAll associated statistics will also be deleted!';
$txt['spiders_no_entries'] = 'Δεν έχουν ορισθεί αράχνες προς το παρόν.';

$txt['add_spider_desc'] = 'Από αυτή τη σελίδα μπορείτε να αλλάξετε τα κριτήρια με τα οποία κατηγοριοποιείται μια αράχνη. Αν το  user agent/διεύθυνση IP ταιριάζει με αυτά που έχουν εισαχθεί παρακάτω, θα εντοπιστεί ως αράχνη μηχανής αναζήτησης και θα ανιχνευθεί όπως έχει οριστεί στις ρυθμίσεις.';
$txt['spider_name_desc'] = 'Όνομα με το οποίο θα αναφέρεται η αράχνη.';
$txt['spider_agent_desc'] = 'User agent associated with this spider.';
$txt['spider_ip_info_desc'] = 'Λίστα διευθύνσεων IP που σχετίζονται με αυτήν την αράχνη, διαχωρισμένες με κόμμα.';

$txt['spider_time'] = 'Χρόνος';
$txt['spider_viewing'] = 'Επισκέπτεται';
$txt['spider_logs_empty'] = 'Δεν υπάρχουν καταγραφές αραχνών προς το παρόν.';
$txt['spider_logs_info'] = 'Σημείωση: Η καταγραφή κάθε ενέργειας της αράχνης συμβαίνει μόνο αν το επίπεδο ανίχνευσης έχει ρυθμιστεί σε &quot;υψηλό&quot; ή &quot;πολύ υψηλό&quot;. Λεπτομέρειες για κάθε ενέργεια της αράχνης καταγράφεται μόνο αν το επίπεδο ανίχνευσης έχει ρυθμιστεί σε &quot;πολύ υψηλό&quot;.';
$txt['spider_disabled'] = 'Απενεργοποιημένο';
$txt['spider_log_empty_log'] = 'Διαγραφή όλων';
$txt['spider_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log';

$txt['spider_logs_delete'] = 'Διαγραφή καταγραφών';
$txt['spider_logs_delete_older'] = 'Delete all entries older than %1$s days.';
$txt['spider_logs_delete_submit'] = 'Διαγραφή';

$txt['spider_stats_delete_older'] = 'Delete all spider statistics from spiders not seen in %1$s days.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Σίγουρα θέλετε να διαγράψετε όλες τις εγγραφές στο αρχείο καταγραφής;';

$txt['spider_stats_select_month'] = 'Μετάβαση στον μήνα';
$txt['spider_stats_page_hits'] = 'Επισκέψεις σελίδων';
$txt['spider_stats_no_entries'] = 'Δεν υπάρχουν διαθέσιμα στατιστικά αραχνών προς το παρόν.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'You have not yet selected to use Sphinx or SphinxQL as your Search Method';
$txt['sphinx_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using the Sphinx API.';
$txt['sphinxql_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using SphinxQL commands.';
$txt['sphinx_test_connect_failed'] = 'Unable to connect to the Sphinx daemon. Make sure it is running and configured properly. Sphinx search will not work until you fix the problem.';
$txt['sphinxql_test_connect_failed'] = 'Unable to access SphinxQL. Make sure your sphinx.conf has a separate listen directive for the SphinxQL port. SphinxQL search will not work until you fix the problem';
$txt['sphinx_test_api_missing'] = 'The sphinxapi.php file is missing in your &quot;sources&quot; directory. You need to copy this file from the Sphinx distribution. Sphinx search will not work until you fix the problem.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Index data path:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Log file path:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';