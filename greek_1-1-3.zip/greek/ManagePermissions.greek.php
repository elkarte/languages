<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Διαχείριση δικαιωμάτων';
$txt['permissions_modify'] = 'Τροποποίηση';
$txt['permissions_view'] = 'Εμφάνιση';
$txt['permissions_allowed'] = 'Επιτρέπεται';
$txt['permissions_denied'] = 'Απαγορεύεται';
$txt['permission_cannot_edit'] = '<strong>Note:</strong> You cannot edit this permission profile as it is a predefined profile included within the forum software by default. If you wish to change the permissions of this profile you must first create a duplicate profile. You can <a href="%1$s">carry out this task by clicking here</a>.';

$txt['permissions_for_profile'] = 'Δικαιώματα για προφίλ';
$txt['permissions_boards_desc'] = 'Η παρακάτω λίστα δείχνει ποιο σετ δικαιωμάτων έχει οριστεί για κάθε πίνακα του φόρουμ. Μπορείτε να τροποποιήσετε το ορισμένο προφίλ δικαιωμάτων είτε κάνοντας κλικ στο όνομα του πίνακα είτε επιλέγοντας &quot;τροποποιηση όλων&quot; από το τέλος της σελίδας. Για να τροποποιήσετε το ίδιο το προφίλ κάνοντας κλικ στο όνομα του προφίλ.';
$txt['permissions_board_all'] = 'Τροποποίηση όλων';
$txt['permission_profile'] = 'Προφίλ δικαιωμάτων';
$txt['permission_profile_desc'] = 'Which <a target="_blank" href="%1$s">permission set</a> the board should use.';
$txt['permission_profile_inherit'] = 'Inherit from parent board';

$txt['permissions_profile'] = 'Προφίλ';
$txt['permissions_profiles_desc'] = 'Τα προφίλ δικαιωμάτων εκχωρούνται σε μεμονωμένους πίνακες έτσι ώστε να σας επιτρέπουν να διαχειρίζεστε εύκολα τις ρυθμίσεις ασφαλείας. Σε αυτή τη περιοχή μπορείτε να δημιουργήσετε, τροποποιήσετε και διαγράψετε προφίλ δικαιωάτων.';
$txt['permissions_profiles_change_for_board'] = 'Τροποποίηση προφίλ δικαιωμάτων για: &quot;%1$s&quot;';
$txt['permissions_profile_default'] = 'Προεπιλεγμένο';
$txt['permissions_profile_no_polls'] = 'Χωρίς ψηφοφορίες';
$txt['permissions_profile_reply_only'] = 'Μόνο απάντηση';
$txt['permissions_profile_read_only'] = 'Μόνο ανάγνωση';

$txt['permissions_profile_rename'] = 'Rename all';
$txt['permissions_profile_edit'] = 'Τροποποίηση προφίλ';
$txt['permissions_profile_new'] = 'Νέο προφίλ';
$txt['permissions_profile_new_create'] = 'Δημιουργία';
$txt['permissions_profile_name'] = 'Όνομα προφίλ';
$txt['permissions_profile_used_by'] = 'Χρησιμοποιείται από';
$txt['permissions_profile_used_by_one'] = '1 πίνακας';
$txt['permissions_profile_used_by_many'] = '%1$d πίνακες';
$txt['permissions_profile_used_by_none'] = 'Κανένα πίνακα';
$txt['permissions_profile_do_edit'] = 'Τροποποίηση';
$txt['permissions_profile_do_delete'] = 'Διαγραφή';
$txt['permissions_profile_copy_from'] = 'Αντιγραφή δικαιωμάτων από';

$txt['permissions_includes_inherited'] = 'Κληρονομημένες ομάδες';
$txt['permissions_includes_inherited_from'] = 'Inherited from: ';

$txt['permissions_all'] = 'όλα';
$txt['permissions_none'] = 'κανένα';
$txt['permissions_set_permissions'] = 'Ορισμός δικαιωμάτων';

$txt['permissions_advanced_options'] = 'Προχωρημένες ρυθμίσεις';
$txt['permissions_with_selection'] = 'Με επιλογή';
$txt['permissions_apply_pre_defined'] = 'Εφαρμογή έτοιμου προφίλ δικαιωμάτων';
$txt['permissions_select_pre_defined'] = 'Επιλογή έτοιμου προφίλ';
$txt['permissions_copy_from_board'] = 'Αντιγραφή δικαιωμάτων από αυτόν τον πίνακα';
$txt['permissions_select_board'] = 'Επιλέξτε πίνακα';
$txt['permissions_like_group'] = 'Ορισμός ίδιων δικαιωμάτων με αυτό της ομάδας';
$txt['permissions_select_membergroup'] = 'Select a member group';
$txt['permissions_add'] = 'Προσθήκη δικαιώματος';
$txt['permissions_remove'] = 'Αφαίρεση δικαιώματος';
$txt['permissions_deny'] = 'Αρνηση δικαιώματος';
$txt['permissions_select_permission'] = 'Επιλογή δικαιώματος';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Μπορείτε να επιλέξετε μόνο μία λειτουργία για αλλαγή δικαιωμάτων';
$txt['permissions_no_action'] = 'Δεν επιλέχθηκε λειτουργία';
$txt['permissions_deny_dangerous'] = 'Πρόκειται να αρνηθείτε ένα ή περισσότερα δικαιώματα.\\nΑυτό μπορεί να είναι επικίνδυνο και να προκαλέσει απροσδόκητα αποτελέσματα εάν δεν έχετε σιγουρευτεί ότι κανένας δεν έχει μπει κατά λάθος στην ομάδα ή ομάδες για τις οποίες αρνείστε τα δικαιώματα.\\n\\nΣίγουρα θέλετε να συνεχίσετε;';

$txt['permissions_modify_group'] = 'Τροποποίηση ομάδας';
$txt['permissions_general'] = 'Δικαιώματα ανά ομάδα μελών';
$txt['permissions_board'] = 'Συνολικά δικαιώματα πίνακα';
$txt['permissions_board_desc'] = '<strong>Σημείωση</strong>: Η αλλαγή αυτών των δικαιωμάτων πίνακα θα επηρεάσει όλους τους πίνακες στους οποίους έχει εκχωρηθεί το &quot;προκαθορισμένο&quot; προφίλ δικαιωμάτων. Πίνακες που δεν χρησιμοποιούν το &quot;προκαθορισμένο&quot; προφίλ δεν θα επηρεαστούν από αλλαγές σε αυτή τη σελίδα.';
$txt['permissions_commit'] = 'Αποθήκευση αλλαγών';
$txt['permissions_on'] = 'στον πίνακα';
$txt['permissions_local_for'] = 'Τοπικά δικαιώματα για ομάδα';
$txt['permissions_option_on'] = 'E';
$txt['permissions_option_off'] = 'Α';
$txt['permissions_option_deny'] = 'Χ';
$txt['permissions_option_desc'] = 'For each permission you can pick either \'Allow\' (A), \'Disallow\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />Remember that if you deny a permission, any member - whether moderator or otherwise - that is in that group will be denied that as well.<br />For this reason, you should use deny carefully, only when <strong>necessary</strong>. Disallow, on the other hand, denies unless otherwise granted.';

$txt['permissiongroup_general'] = 'Γενικά';
$txt['permissionname_view_stats'] = 'Εμφάνιση στατιστικών του φόρουμ';
$txt['permissionhelp_view_stats'] = 'Τα στατιστικά του φόρουμ είναι μια σελίδα που συνοψίζει όλα τα στατιστικά του φόρουμ, όπως πλήθος μελών, ημερήσιο αριθμό μηνυμάτων και πολλά top-10 στατιστικά. Η παραχώρηση αυτού του δικαιώματος προσθέτει έναν σύνδεσμο (link) στο κάτω μέρος του καταλόγου πινάκων (board index) (\'[Περισσότερα Στατιστικά]\').';
$txt['permissionname_view_mlist'] = 'View the member list and groups';
$txt['permissionhelp_view_mlist'] = 'The member list shows all members that have registered on your forum. The list can be sorted and searched. The member list is linked from both the board index and the stats page, by clicking on the number of members. It also applies to the groups page which is a mini memberlist of people in that group.';
$txt['permissionname_who_view'] = 'Εμφάνιση συνδεδεμένων μελών';
$txt['permissionhelp_who_view'] = 'Η εμφάνιση συνδεδεμένων μελών δείχνει όλα τα μέλη που είναι την συγκεκριμένη στιγμή συνδεδεμένα και τι κάνουν τη συγκεκριμένη στιγμή. Αυτό το δικαίωμα λειτουργεί μόνο αν έχει παραχωρηθεί στο \'Χαρακτηριστικά και Επιλογές\'. Μπορείτε να δείτε ποιος είναι συνδεμένος πατώντας το σύνδεσμο στον τομέα \'Συνδεδεμένοι Χρήστες\' στον κατάλογο πινάκων. Αν αυτή η λειτουργία απαγορευθεί, τα μέλη θα μπορούν να βλέπουν ποιοί είναι συνδεδεμένοι, αλλά δεν θα βλέπουν πού βρίσκονται';
$txt['permissionname_search_posts'] = 'Αναζήτηση μηνυμάτων και θεμάτων';
$txt['permissionhelp_search_posts'] = 'Η αναζήτηση επιτρέπει στον χρήστη να αναζητήσει σε όλους τους πίνακες που έχει πρόσβαση. Όταν παραχωρηθεί το δικαίωμα αναζήτησης, προστίθεται ένα κουμπί\'Αναζήτηση\' στην γραμμή κουμπιών του φόρουμ.';
$txt['permissionname_karma_edit'] = 'Τροποποίηση του κάρμα άλλων μελών';
$txt['permissionhelp_karma_edit'] = 'Karma is a feature that shows the popularity of a member. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to cast a vote. This permission has no effect on guests.';
$txt['permissionname_like_posts'] = 'Like other users\' posts';
$txt['permissionhelp_like_posts'] = 'Likes is a feature that shows the popularity of a post. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to like a post or unlike one they previously liked.  This permission has no effect on guests.';
$txt['permissionname_like_posts_stats'] = 'See like posts stats';
$txt['permissionhelp_like_posts_stats'] = 'This will allow users to see stats of posts liking';
$txt['permissionname_disable_censor'] = 'Disable word censor';
$txt['permissionhelp_disable_censor'] = 'Allows members the option to disable the word censor.';

$txt['permissiongroup_pm'] = 'Προσωπικά μηνύματα';
$txt['permissionname_pm_read'] = 'Ανάγνωση προσωπικών μηνυμάτων';
$txt['permissionhelp_pm_read'] = 'Αυτό το δικαίωμα επιτρέπει στους χρήστες την πρόσβαση στο τμήμα Προσωπικών Μηνυμάτων και να διαβάσουν τα προσωπικά τους μηνύματα. Χωρίς αυτό το δικαίωμα, ο χρήστης δεν μπορεί να στείλει προσωπικά μηνύματα.';
$txt['permissionname_pm_send'] = 'Αποστολή προσωπικών μηνυμάτων';
$txt['permissionhelp_pm_send'] = 'Αποστολή προσωπικών μηνυμάτων σε άλλα εγγεγραμένα μέλη. Απαιτεί το δικαίωμα \'Ανάγνωση προσωπικών μηνυμάτων\'.';
$txt['permissionname_send_email_to_members'] = 'Send emails';
$txt['permissionhelp_send_email_to_members'] = 'Send emails to other registered members.';

$txt['permissiongroup_calendar'] = 'Ημερολόγιο';
$txt['permissionname_calendar_view'] = 'Εμφάνιση ημερολόγιου';
$txt['permissionhelp_calendar_view'] = 'Το ημερολόγιο εμφανίζει για κάθε μήνα τα γενέθλια, τις εκδηλώσεις και τις αργίες. Αυτό το δικαίωμα επιτρέπει την πρόσβαση στο ημερολόγιο. Όταν ενεργοποιηθεί αυτό το δικαίωμα, προστίθεται ένα κουμπί στην επάνω γραμμή κουμπιών και εμφανίζεται μια λίστα στο κάτω μέρος της κεντρικής σελίδας του φόρουμ με τα τρέχοντα και προσεχή γενέθλια, τις εκδηλώσεις και τις αργίες. Το ημερολόγιο πρέπει να ενεργοποιηθεί μέσα από το \'Χαρακτηριστικά και επιλογές\'.';
$txt['permissionname_calendar_post'] = 'Δημιουργία εκδηλώσεων στο ημερολόγιο';
$txt['permissionhelp_calendar_post'] = 'Μία εκδήλωση είναι ένα θέμα συνδεδεμένη με μια συγκεκριμένη ημερομηνία ή εύρος ημερομηνιών. Η δημιουργία εκδηλώσεων μπορεί να γίνει από το ημερολόγιο. Μία εκδήλωση μπορεί να δημιουργηθεί μόνο αν ο χρήστης έχει δικαίωμα δημιουργίας νέων θεμάτων.';
$txt['permissionname_calendar_edit'] = 'Τροποποίηση εκδηλώσεων στο ημερολόγιο';
$txt['permissionhelp_calendar_edit'] = 'Μια εκδήλωση είναι ένα θέμα συνδεδεμένο με μια συγκεκριμένη ημερομηνία ή εύρος ημερομηνιών. Μία εκδήλωση μπορεί να τροποποιηθεί πατώντας επάνω στον κόκκινο αστερίσκο (*) δίπλα από την εκδήλωση στο ημερολόγιο. Για να μπορεί να τροποποιήσει μια εκδήλωση, ο χρήστης πρέπει να έχει επαρκή δικαιώματα ώστε να μπορεί να τροποποιεί το πρώτο μήνυμα του θέματος που είναι συνδεδεμένο με την εκδήλωση.';
$txt['permissionname_calendar_edit_own'] = 'Προσωπικές εκδηλώσεις';
$txt['permissionname_calendar_edit_any'] = 'Οποιεσδήποτε εκδηλώσεις';

$txt['permissiongroup_maintenance'] = 'Διαχείριση φόρουμ';
$txt['permissionname_admin_forum'] = 'Διαχείριση του φόρουμ και της βάσης δεδομένων';
$txt['permissionhelp_admin_forum'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη να:<ul><li>αλλάζει ρυθμίσεις στο φόρουμ, βάση δεδομένων και Εμφανίσεις</li><li>να διαχειρίζεται πακέτα</li><li>να χρησιμοποιεί τα εργαλεία συντήρησης του φόρουμ και της βάσης δεδομένων</li><li>να δει τα αρχεία καταγραφής λαθών και ενεργειών συντονιστών</li></ul>. Χρησιμοποιήστε αυτό το δικαίωμα με προσοχή, καθώς είναι πολύ ισχυρό.';
$txt['permissionname_manage_boards'] = 'Διαχείριση πινάκων και κατηγοριών';
$txt['permissionhelp_manage_boards'] = 'Αυτό το δικαίωμα επιτρέπει δημιουργία, τροποποίηση, και αφαίρεση πινάκων και κατηγοριών.';
$txt['permissionname_manage_attachments'] = 'Διαχείριση συνημμένων και πορτραίτων';
$txt['permissionhelp_manage_attachments'] = 'Αυτό το δικαίωμα επιτρέπει πρόσβαση στο κέντρο συνημμένων, όπου βρίσκονται σε κατάλογο όλα τα συνημμένα του φόρουμ και τα πορτραίτα και μπορούν να διαγραφούν.';
$txt['permissionname_manage_smileys'] = 'Διαχείριση φατσούλων';
$txt['permissionhelp_manage_smileys'] = 'Αυτό το δικαίωμα επιτρέπει πρόσβαση στο κέντρο των φατσούλων. Σε αυτό μπορείτε να προσθέσετε, τροποποιήσετε και να διαγράψετε φατσούλες και ομάδες φατσούλων.';
$txt['permissionname_edit_news'] = 'Τροποποίηση ειδήσεων';
$txt['permissionhelp_edit_news'] = 'The news function allows a random news line to appear on each screen. In order to use the news function, enable it in the forum settings.';
$txt['permissionname_access_mod_center'] = 'Πρόσβαση στο κέντρο συντονισμού';
$txt['permissionhelp_access_mod_center'] = 'Με αυτό το δικαίωμα οποιοδήποτε μέλος αυτής της ομάδας μπορεί να προσπελάσει το κέντρο συντονισμού moderation center from where they will have access to functionality to ease moderation. Note that this does not in itself grant any moderation privileges.';

$txt['permissiongroup_member_admin'] = 'Διαχείριση μελών';
$txt['permissionname_moderate_forum'] = 'Συντονισμός των μελών του φόρουμ';
$txt['permissionhelp_moderate_forum'] = 'Αυτό το δικαίωμα περιέχει όλες τις σημαντικές λειτουργίες συντονισμού μελών:<ul class="normallist">
<li>πρόσβαση στη διαχείριση εγγραφών</li><li>πρόσβαση στη σελίδα εμφάνισης/διαγραφής μελών</li><li>εκτενείς πληροφορίες προφίλ, συμπεριλαμβανομένης της ανίχνευσης IP/χρήστη και (κρυφή) κατάσταση σύνδεσης</li><li>ενεργοποίηση λογαριασμών</li><li>λήψη ειδοποιήσεων έγκρισης και έγκριση λογαριασμών</li><li>υπέρβαση της αγνόησης Π.Μ.</li><li>διάφορα άλλα μικροπράγματα.</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Διαχείριση και ορισμός ομάδων μελών';
$txt['permissionhelp_manage_membergroups'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη να τροποποιεί ομάδες μελών και να ορίζει ομάδες μελών σε άλλα μέλη.';
$txt['permissionname_manage_permissions'] = 'Διαχείριση δικαιωμάτων';
$txt['permissionhelp_manage_permissions'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη να τροποποιεί όλα τα δικαιώματα μιας ομάδας μελών, συνολικά ή για μεμονωμένους πίνακες.';
$txt['permissionname_manage_bans'] = 'Διαχείριση λίστας αποκλεισμού';
$txt['permissionhelp_manage_bans'] = 'This permission allows a user to add or remove user names, IP addresses, hostnames and email addresses to or from a list of banned users. It also allows a user to view and remove log entries of banned users that attempted to login.';
$txt['permissionname_send_mail'] = 'Broadcast to multiple members';
$txt['permissionhelp_send_mail'] = 'Mass mail all forum members or just a few member groups by email or personal message (the latter requires the \'Send Personal Message\' permission).';
$txt['permissionname_issue_warning'] = 'Προειδοποιήσεις προς τα μέλη';
$txt['permissionhelp_issue_warning'] = 'Προειδοποίηση προς μέλη του φόρουμ και αλλαγή του επιπέδου προειδοποίησης αυτών των μελών. Προαπαιτείται να είναι ενεργοποιημένη η λειτουργία των προειδοποιήσεων.';

$txt['permissiongroup_profile'] = 'Προφίλ μελών';
$txt['permissionname_profile_view'] = 'Εμφάνιση σύνοψης και στατιστικών του προφίλ';
$txt['permissionhelp_profile_view'] = 'This permission allows users clicking on a user name to see a summary of profile settings, some statistics and all posts of the user.';
$txt['permissionname_profile_view_own'] = 'Προσωπικό προφίλ';
$txt['permissionname_profile_view_any'] = 'Οποιοδήποτε προφίλ';
$txt['permissionname_profile_identity'] = 'Τροποποίηση ρυθμίσεων λογαριασμού';
$txt['permissionhelp_profile_identity'] = 'Account settings are the basic settings of a profile, like password, email address, member group and preferred language.';
$txt['permissionname_profile_identity_own'] = 'Προσωπικό προφίλ';
$txt['permissionname_profile_identity_any'] = 'Οποιοδήποτε προφίλ';
$txt['permissionname_profile_extra'] = 'Τροποποίηση επιπλέον ρυθμίσεων προφίλ';
$txt['permissionhelp_profile_extra'] = 'Οι επιπλέον ρυθμίσεις προφίλ περιλαμβάνουν ρυθμίσεις για τα Πορτραίτα, προτιμήσεις για τις Εμφανίσεις, Ειδοποιήσεις και Προσωπικά Μηνύματα.';
$txt['permissionname_profile_extra_own'] = 'Προσωπικό προφίλ';
$txt['permissionname_profile_extra_any'] = 'Οποιοδήποτε προφίλ';
$txt['permissionname_profile_title'] = 'Τροποποίηση πρόσθετου τίτλου';
$txt['permissionhelp_profile_title'] = 'Ο πρόσθετος τίτλος εμφανίζεται στην σελίδα εμφάνισης θεμάτων, κάτω από το προφίλ του κάθε χρήστη που έχει πρόσθετο τίτλο.';
$txt['permissionname_profile_title_own'] = 'Προσωπικό προφίλ';
$txt['permissionname_profile_title_any'] = 'Οποιοδήποτε προφίλ';
$txt['permissionname_profile_remove'] = 'Διαγραφή λογαριασμού';
$txt['permissionhelp_profile_remove'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη να διαγράψει τον λογαριασμό του, όταν τεθεί στο \'Προσωπικός λογαριασμός\'.';
$txt['permissionname_profile_remove_own'] = 'Προσωπικός λογαριασμός';
$txt['permissionname_profile_remove_any'] = 'Οποιοδήποτε λογαριασμός';
$txt['permissionname_profile_set_avatar'] = 'Select an avatar';
$txt['permissionhelp_profile_set_avatar'] = 'If enabled this will allow a user to select an avatar.';

$txt['permissiongroup_general_board'] = 'Γενικά';
$txt['permissionname_moderate_board'] = 'Συντονισμός πίνακα';
$txt['permissionhelp_moderate_board'] = 'Το δικαίωμα συντονισμού πίνακα προσθέτει μερικά μικρά δικαιώματα που κάνουν έναν συντονιστή πραγματικό συντονιστή. Στα δικαιώματα αυτά συμπεριλαμβάνονται οι απαντήσεις σε κλειδωμένα θέματα, αλλαγές στον χρόνο λήξης μίας ψηφοφορίας και η εμφάνιση αποτελεσμάτων ψηφοφορίας.';

$txt['permissiongroup_topic'] = 'Θέματα';
$txt['permissionname_post_new'] = 'Δημιουργία νέων θεμάτων';
$txt['permissionhelp_post_new'] = 'Αυτό το δικαίωμα επιτρέπει στους χρήστες να δημιουργήσουν ένα νέο θέμα. Δεν επιτρέπει αποστολή απαντήσεων σε θέματα.';
$txt['permissionname_merge_any'] = 'Συγχώνευση θεμάτων σε ένα';
$txt['permissionhelp_merge_any'] = 'Merge two or more topics into one. The order of messages within the merged topic will be based on the time the messages were created. A user can only merge topics on those boards a user is allowed to merge. In order to merge multiple topics at once, a user has to enable quick moderation in their profile settings.';
$txt['permissionname_split_any'] = 'Διαχωρισμός θεμάτων';
$txt['permissionhelp_split_any'] = 'Διαχωρισμός θέματος σε δύο ξεχωριστά θέματα.';
$txt['permissionname_send_topic'] = 'Αποστολή θεμάτων σε φίλους';
$txt['permissionhelp_send_topic'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη να στείλει με e-mail ένα θέμα σε έναν φίλο, εισάγοντας την διεύθυνση email του, και επιτρέπει την προσθήκη ενός μηνύματος.';
$txt['permissionname_make_sticky'] = 'Pin topics';
$txt['permissionhelp_make_sticky'] = 'Pinned topics are topics that always remain on top of a board. They can be useful for announcements or other important messages.';
$txt['permissionname_move'] = 'Move topics';
$txt['permissionhelp_move'] = 'Μετακίνηση θέματος από ένα πίνακα σε άλλο. Οι χρήστες μπορούν να επιλέξουν μόνο πίνακες προορισμού στους οποίους τους επιτρέπεται η πρόσβαση.';
$txt['permissionname_move_own'] = 'Θέμα του ιδίου';
$txt['permissionname_move_any'] = 'Οποιοδήποτε θέμα';
$txt['permissionname_lock'] = 'Κλείδωμα θεμάτων';
$txt['permissionhelp_lock'] = 'This permission allows a user to lock a topic. This can be done in order to make sure no one can reply to a topic. Only users with a \'Moderate board\' permission can still post in locked topics.';
$txt['permissionname_lock_own'] = 'Θέμα του ιδίου';
$txt['permissionname_lock_any'] = 'Οποιοδήποτε θέμα';
$txt['permissionname_remove'] = 'Διαγραφή θεμάτων';
$txt['permissionhelp_remove'] = 'Διαγραφή θεμάτων ως οντότητα. Σημείωση: αυτό το δικαίωμα δεν επιτρέπει τη διαγραφή συγκεκριμένων μηνυμάτων μέσα σε ένα θέμα!';
$txt['permissionname_remove_own'] = 'Θέμα του ιδίου';
$txt['permissionname_remove_any'] = 'Οποιαδήποτε θέματα';
$txt['permissionname_post_reply'] = 'Αποστολή απαντήσεων σε θέματα';
$txt['permissionhelp_post_reply'] = 'Αυτό το δικαίωμα επιτρέπει τις απαντήσεις σε θέματα.';
$txt['permissionname_post_reply_own'] = 'Θέμα του ιδίου';
$txt['permissionname_post_reply_any'] = 'Οποιοδήποτε θέμα';
$txt['permissionname_modify_replies'] = 'Τροποποίηση απαντήσεων σε προσωπικά θέματα';
$txt['permissionhelp_modify_replies'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη που άρχισε ένα θέμα να τροποποιήσει όλες τις απαντήσεις σε αυτό το θέμα.';
$txt['permissionname_delete_replies'] = 'Διαγραφή απαντήσεων σε προσωπικά θέματα';
$txt['permissionhelp_delete_replies'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη που ξεκίνησε ένα θέμα να διαγράψει όλες τις απαντήσεις σε αυτό το θέμα.';
$txt['permissionname_announce_topic'] = 'Ανακοίνωση θέματος';
$txt['permissionhelp_announce_topic'] = 'This allows a user to send an announcement email about a topic to all members or to a few member groups.';

$txt['permissionname_approve_emails'] = 'Moderate Post by Email Failures';
$txt['permissionhelp_approve_emails'] = 'Allow moderators to access the Post by Email failure log to perform actions including approve, delete, view and bounce.  Note, since the system may not always know what board a post goes to, this permission should be only be given to members with full board access';
$txt['permissionname_postby_email'] = 'Post by Email';
$txt['permissionhelp_postby_email'] = 'This permission allows users to start new topics as well as reply to topic and PM notifications by email.';

$txt['permissiongroup_post'] = 'μηνύματα';
$txt['permissionname_delete'] = 'Διαγραφή μηνυμάτων';
$txt['permissionhelp_delete'] = 'Διαγραφή μηνυμάτων. Αυτό δεν επιτρέπει σε έναν χρήστη να διαγράψει το πρώτο μήνυμα ενός θέματος.';
$txt['permissionname_delete_own'] = 'Προσωπικό μήνυμα';
$txt['permissionname_delete_any'] = 'Οποιαδήποτε μήνυμα';
$txt['permissionname_modify'] = 'Τροποποίηση μηνυμάτων';
$txt['permissionhelp_modify'] = 'Τροποποίηση μηνυμάτων';
$txt['permissionname_modify_own'] = 'Προσωπικό μήνυμα';
$txt['permissionname_modify_any'] = 'Οποιαδήποτε μήνυμα';
$txt['permissionname_report_any'] = 'Αναφορά μηνυμάτων στους συντονιστές';
$txt['permissionhelp_report_any'] = 'Αυτό το δικαίωμα προσθέτει ένα σύνδεσμο σε κάθε μήνυμα, επιτρέποντας στον χρήστη να αναφέρει ένα μήνυμα σε συντονιστή. Σε κάθε αναφορά, όλοι οι συντονιστές του συγκεκριμένου πίνακα λαμβάνουν ένα email με ένα σύνδεσμο στην αναφερθέν μήνυμα και μια περιγραφή του προβλήματος (όπως δίνεται από τον χρήστη που κάνει την αναφορά).';

$txt['permissiongroup_poll'] = 'Ψηφοφορίες';
$txt['permissionname_poll_view'] = 'Εμφάνιση ψηφοφοριών';
$txt['permissionhelp_poll_view'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη να δει μια ψηφοφορία. Χωρίς αυτό το δικαίωμα, ο χρήστης θα βλέπει μόνο το θέμα.';
$txt['permissionname_poll_vote'] = 'Ψήφος σε ψηφοφορίες';
$txt['permissionhelp_poll_vote'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν (εγγεγραμμένο) χρήστη να δώσει μία ψήφο. Δεν ισχύει για επισκέπτες.';
$txt['permissionname_poll_post'] = 'Δημιουργία ψηφοφοριών';
$txt['permissionhelp_poll_post'] = 'Αυτό το δικαίωμα επιτρέπει σε έναν χρήστη να δημοσιεύσει μία νέα ψηφοφορία. Ο χρήστης πρέπει να έχει πρέπει να έχει το δικαίωμα \'Δημιουργία νέου θέματος\'.';
$txt['permissionname_poll_add'] = 'Προσθήκη ψηφοφορίας σε θέματα';
$txt['permissionhelp_poll_add'] = 'Η προσθήκη ψηφοφορίας σε θέματα επιτρέπει στον χρήστη να προσθέσει μία ψηφοφορία αφότου έχει δημιουργηθεί ο θέμα. Αυτό το δικαίωμα απαιτεί επαρκή δικαιώματα τροποποίησης του πρώτου μηνύματος μίας θέματος.';
$txt['permissionname_poll_add_own'] = 'Προσωπικά θέματα';
$txt['permissionname_poll_add_any'] = 'Οποιαδήποτε θέματα';
$txt['permissionname_poll_edit'] = 'Τροποποίηση ψηφοφοριών';
$txt['permissionhelp_poll_edit'] = 'Αυτό το δικαίωμα επιτρέπει την τροποποίηση των επιλογών και τον μηδενισμό μίας ψηφοφορίας. Για να τροποποιηθεί ο μέγιστος αριθμός ψήφων και ο χρόνος λήξης, ο χρήστης χρειάζεται δικαιώματα \'Συντονισμού πίνακα\'.';
$txt['permissionname_poll_edit_own'] = 'Προσωπική ψηφοφορία';
$txt['permissionname_poll_edit_any'] = 'Οποιαδήποτε ψηφοφορία';
$txt['permissionname_poll_lock'] = 'Κλείδωμα ψηφοφοριών';
$txt['permissionhelp_poll_lock'] = 'Το κλείδωμα ψηφοφοριών αποτρέπει την αποδοχή περαιτέρω ψήφων σε μία ψηφοφορία.';
$txt['permissionname_poll_lock_own'] = 'Προσωπική ψηφοφορία';
$txt['permissionname_poll_lock_any'] = 'Οποιαδήποτε ψηφοφορία';
$txt['permissionname_poll_remove'] = 'Διαγραφή ψηφοφοριών';
$txt['permissionhelp_poll_remove'] = 'Αυτό το δικαίωμα επιτρέπει τη διαγραφή ψηφοφοριών.';
$txt['permissionname_poll_remove_own'] = 'Προσωπική ψηφοφορία';
$txt['permissionname_poll_remove_any'] = 'Οποιαδήποτε ψηφοφορία';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Save drafts of new posts';
$txt['permissionname_simple_post_draft'] = 'Save drafts of new posts';
$txt['permissionhelp_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionhelp_simple_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionname_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionname_simple_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionhelp_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionname_simple_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionhelp_pm_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid losing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionname_simple_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionhelp_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';
$txt['permissionhelp_simple_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';

$txt['permissiongroup_approval'] = 'Συντονισμός μηνυμάτων';
$txt['permissionname_approve_posts'] = 'Έγκριση μηνυμάτων που περιμένουν στην ουρά έγκρισης';
$txt['permissionhelp_approve_posts'] = 'Αυτό το δικαίωμα επιτρέπει στον χρήστη να εγκρίνει τα μη εγκεκριμένα μηνύματα ενός πίνακα.';
$txt['permissionname_post_unapproved_replies'] = 'Δημοσίευση μη εγκεκριμένων απαντήσεων';
$txt['permissionhelp_post_unapproved_replies'] = 'Αυτό το δικαίωμα επιτρέπει στον χρήστη να δημοσιεύει απαντήσεις σε κάποιο θέμα. Οι απαντήσεις δεν θα εμφανιστούν μέχρι να εγκριθούν από κάποιον συντονιστή.';
$txt['permissionname_post_unapproved_replies_own'] = 'Θέμα του ιδίου';
$txt['permissionname_post_unapproved_replies_any'] = 'Οποιοδήποτε θέμα';
$txt['permissionname_post_unapproved_topics'] = 'Δημοσίευση μη εγκεκριμένων θεμάτων';
$txt['permissionhelp_post_unapproved_topics'] = 'Αυτό το δικαίωμα επιτρέπει στον χρήστη να δημοσιεύει ένα νέο θέμα για το οποίο απαιτείται έγκριση πριν εμφανιστεί.';
$txt['permissionname_post_unapproved_attachments'] = 'Δημοσίευση μη εγκεκριμένων συνημμένων';
$txt['permissionhelp_post_unapproved_attachments'] = 'Αυτό το δικαίωμα επιτρέπει στον χρήστη να επισυνάπτει αρχεία στα μηνύματά του. Τα συνημμένα αρχεία θα πρέπει στη συνέχεια να λάβουν έγκριση πριν εμφανιστούν στους υπόλοιπους χρήστες.';

$txt['permissiongroup_notification'] = 'Ειδοποιήσεις';
$txt['permissionname_mark_any_notify'] = 'Ειδοποίηση για απαντήσεις';
$txt['permissionhelp_mark_any_notify'] = 'Αυτή η δυνατότητα επιτρέπει στον χρήστη να λαμβάνει μια ειδοποίηση όποτε κάποιος απαντάει σε ένα θέμα στο οποίο έχει εγγραφεί για ειδοποιήσεις.';
$txt['permissionname_mark_notify'] = 'Ειδοποίηση για νέα θέματα';
$txt['permissionhelp_mark_notify'] = 'Η ειδοποίηση για νέα θέματα είναι μια δυνατότητα που επιτρέπει σε έναν χρήστη να λαμβάνει e-mail κάθε φορά που δημιουργείται ένα νέο θέμα στον πίνακα που έχει εγγραφεί για ειδοποιήσεις.';

$txt['permissiongroup_attachment'] = 'Συνημμένα';
$txt['permissionname_view_attachments'] = 'Εμφάνιση συνημμένων';
$txt['permissionhelp_view_attachments'] = 'Τα συνημμένα είναι αρχεία που επισυνάπτονται σε δημοσιευμένα μηνύματα. Αυτή η δυνατότητα μπορεί να ενεργοποιηθεί και να παραμετροποιηθεί από το \'Συνημμένα και πορτραίτα\'. Αφού τα συνημμένα δεν μπορούν να προσπελαστούν απευθείας, μπορείτε να τα αποτρέψετε τη λήψη τους από χρήστες που δεν έχουν αυτό το δικαίωμα.';
$txt['permissionname_post_attachment'] = 'Δημοσίευση συνημμένων';
$txt['permissionhelp_post_attachment'] = 'Τα συνημμένα είναι αρχεία που επισυνάπτονται σε δημοσιευμένα μηνύματα. Ένα μήνυμα μπορεί να περιέχει πολλά συνημμένα.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Ρυθμίσεις δικαιωμάτων';
$txt['groups_manage_permissions'] = 'Member groups allowed to manage permissions';
$txt['permission_enable_deny'] = 'Ενεργοποίηση επιλογής για άρνηση δικαιωμάτων';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Η απενεργοποίηση αυτής της επιλογής θα ενημερώσει τα δικαιώματα \\\'Αρνείται\\\' σε \\\'Απαγορεύεται\\\'.';
$txt['permission_by_board_desc'] = 'Here you can set which permission profile a board uses. You can create new permission profiles from the &quot;Edit Profiles&quot; menu.';
$txt['permission_settings_desc'] = 'Εδώ μπορείτε να ορίσετε ποιός έχει το δικαίωμα να αλλάζει τα δικαιώματα, καθώς επίσης και πόσο εξειδικευμένο θα είναι το σύστημα δικαιωμάτων.';
$txt['permission_enable_postgroups'] = 'Ενεργοποίηση δικαιωμάτων για ομάδες μελών βασισμένες στον αριθμό μηνυμάτων';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Η απενεργοποίηση αυτής της επιλογής θα αφαιρέσει τα δικαιώματα που έχουν οριστεί για τις ομάδες μελών με βάση τον αριθμό μηνυμάτων.';

$txt['permissions_post_moderation_desc'] = 'From this page you can easily change which groups have their posts moderated for a particular permission profile.';
$txt['permissions_post_moderation_deny_note'] = 'Σημειώστε ότι αν και έχετε ενεργοποιήσει τα προχωρημένα δικαιώματα δεν μπορείτε εφαρμόσετε το &quot;\'Αρνείται\' (Χ)&quot; από αυτήν την σελίδα. Παρακαλούμε τροποποιήστε τα δικαιώματα από την σχετική σελίδα αν θέλετε να εφαρμόσετε το \'Αρνείται\' (Χ).';
$txt['permissions_post_moderation_select'] = 'Επιλογή προφίλ';
$txt['permissions_post_moderation_new_topics'] = 'Νέα θέματα';
$txt['permissions_post_moderation_replies_own'] = 'Απαντήσεις του ιδίου';
$txt['permissions_post_moderation_replies_any'] = 'Οποιεσδήποτε απαντήσεις';
$txt['permissions_post_moderation_attachments'] = 'Συνημμένα';
$txt['permissions_post_moderation_legend'] = 'Υπόμνημα';
$txt['permissions_post_moderation_allow'] = 'Μπορεί να δημιουργήσει';
$txt['permissions_post_moderation_moderate'] = 'Μπορεί να δημιουργήσει αλλά απαιτείται έγκριση';
$txt['permissions_post_moderation_disallow'] = 'Δεν μπορεί να δημιουργήσει';
$txt['permissions_post_moderation_group'] = 'Ομάδα';

$txt['auto_approve_topics'] = 'Post new topics without requiring approval';
$txt['auto_approve_replies'] = 'Post replies to topics without requiring approval';
$txt['auto_approve_attachments'] = 'Post attachments without requiring approval';
