<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Περισσότεροι συνδεδεμένοι';

$txt['stats_center'] = 'Κέντρο στατιστικών';
$txt['general_stats'] = 'Γενικά στατιστικά';
$txt['top_posters'] = 'Κορυφαίοι 10 αποστολείς';
$txt['top_boards'] = 'Κορυφαίοι 10 πίνακες';
$txt['forum_history'] = 'Ιστορικό του φόρουμ (με χρήση διαφοράς ώρας)';
$txt['stats_new_topics'] = 'Νέα θέματα';
$txt['stats_new_posts'] = 'Νέα μηνύματα';
$txt['stats_new_members'] = 'Νέα μέλη';
$txt['page_views'] = 'Εμφανίσεις σελίδων';
$txt['top_topics_replies'] = 'Κορυφαία 10 θέματα (με βάση τις απαντήσεις)';
$txt['top_topics_views'] = 'Κορυφαία 10 θέματα (με βάση τις εμφανίσεις)';
$txt['yearly_summary'] = 'Μηνιαία περίληψη';
$txt['top_starters'] = 'Κορυφαίοι αποστολείς νέων θεμάτων';
$txt['most_time_online'] = 'Μεγαλύτερος χρόνος σύνδεσης';

$txt['average_members'] = 'Μέσος όρος εγγραφών ανά ημέρα';
$txt['average_posts'] = 'Μέσος όρος μηνυμάτων ανά ημέρα';
$txt['average_topics'] = 'Μέσος όρος θεμάτων ανά ημέρα';
$txt['average_online'] = 'Μέσος όρος συνδεδεμένων ανά ημέρα';
$txt['users_online'] = 'Συνδεδεμένοι χρήστες';
$txt['emails_sent'] = 'Average Emails per day';
$txt['users_online_today'] = 'Συνδεδεμένοι σήμερα';
$txt['num_hits'] = 'Συνολικές εμφανίσεις σελίδων';
$txt['average_hits'] = 'Μέσος όρος εμφανίσεων σελίδων ανά ημέρα';

$txt['ssi_comment'] = 'σχόλιο';
$txt['ssi_comments'] = 'σχόλια';
$txt['ssi_write_comment'] = 'Γράψτε σχόλιο';
$txt['ssi_no_guests'] = 'Δεν μπορείτε να δηλώσετε έναν πίνακα που δεν επιτρέπει πρόσβαση σε επισκέπτες.  Ελέγξτε το αναγνωριστικό (ID) του πίνακα πριν ξαναπροσπαθήσετε.';
$txt['xml_rss_desc'] = 'Live information from {forum_name}';