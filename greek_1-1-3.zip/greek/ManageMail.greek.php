<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Από αυτή τη σελίδα μπορείτε να ρυθμίσετε τις επιλογές email, καθώς και να δείτε και να διαχειριστείτε την τρέχουσα ουρά email αν είναι ενεργοποιημένη.';
$txt['mail_settings'] = 'Mail Settings';

$txt['mail_type'] = 'Τύπος email';
$txt['mail_type_default'] = '(προκαθορισμένος PHP)';
$txt['smtp_host'] = 'Διακομιστής SMTP';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'Θύρα SMTP';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'Όνομα χρήστη SMTP';
$txt['smtp_password'] = 'Κωδικός SMTP';

$txt['mail_queue'] = 'Enable mail queue';
$txt['mail_period_limit'] = 'Μέγιστος αριθμός αποστελλώμενων email ανά λεπτό';
$txt['mail_period_limit_desc'] = '(0 για απενεργοποίηση)';
$txt['mail_batch_size'] = 'Μέγιστο πλήθος αποστελλόμενων email ανά ανανέωση σελίδας';

$txt['mailqueue_stats'] = 'Mail queue statistics';
$txt['mailqueue_oldest'] = 'Παλαιότερα email';
$txt['mailqueue_oldest_not_available'] = '(-)';
$txt['mailqueue_size'] = 'Queue length';

$txt['mailqueue_age'] = 'Ηλικία';
$txt['mailqueue_priority'] = 'Προτεραιότητα';
$txt['mailqueue_recipient'] = 'Παραλήπτης';
$txt['mailqueue_subject'] = 'Τίτλος';
$txt['mailqueue_clear_list'] = 'Send mail queue now';
$txt['mailqueue_no_items'] = 'Η ουρά email αυτή τη στιγμή είναι άδεια';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Σίγουρα θέλετε να αποστείλετε ολόκληρη την ουρα email τώρα; Αυτό θα παρακάμψει τυχόν περιορισμούς που έχετε θέσει.';

$txt['mq_day'] = '%1.1f ημέρα';
$txt['mq_days'] = '%1.1f ημέρες';
$txt['mq_hour'] = '%1.1f ώρα';
$txt['mq_hours'] = '%1.1f ώρες';
$txt['mq_minute'] = '%1$d λεπτό';
$txt['mq_minutes'] = '%1$d λεπτά';
$txt['mq_second'] = '%1$d δευτερόλεπτο';
$txt['mq_seconds'] = '%1$d δευτερόλεπτα';

$txt['mq_mpriority_5'] = 'Πολύ χαμηλή';
$txt['mq_mpriority_4'] = 'Χαμηλή';
$txt['mq_mpriority_3'] = 'Κανονική';
$txt['mq_mpriority_2'] = 'Υψηλή';
$txt['mq_mpriority_1'] = 'Πολύ υψηλή';

$txt['birthday_email'] = 'Birthday message to use';
$txt['birthday_body'] = 'Email body';
$txt['birthday_subject'] = 'Email subject';