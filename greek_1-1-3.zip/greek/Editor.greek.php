<?php
// Version: 1.1; Editor

global $editortxt;

$editortxt['Close'] = 'Κλείσιμο';
$editortxt['Bold'] = 'Έντονα';
$editortxt['Italic'] = 'Πλάγια';
$editortxt['Underline'] = 'Υπογραμμισμένα';
$editortxt['Strikethrough'] = 'Διαγραμμένο';
$editortxt['Subscript'] = 'Δείκτης';
$editortxt['Superscript'] = 'Εκθέτης';
$editortxt['Align left'] = 'Αριστερή στοίχιση ';
$editortxt['Center'] = 'Στο κέντρο';
$editortxt['Align right'] = 'Δεξιά στοίχιση ';
$editortxt['Justify'] = 'Αιτιολογία';
$editortxt['Font Name'] = 'Γραμματοσειρά';
$editortxt['Font Size'] = 'Μέγεθος γραμμάτων';
$editortxt['Font Color'] = 'Χρώμα γραμματοσειράς';
$editortxt['Remove Formatting'] = 'Αφαίρεση μορφοποίησης';
$editortxt['Cut'] = 'Αποκοπή';
$editortxt['Your browser does not allow the cut command. Please use the keyboard shortcut Ctrl/Cmd-X'] = 'Το πρόγραμμα περιήγησής σας δεν επιτρέπει την εντολή αποκοπής. Χρησιμοποιήστε τη συντόμευση πληκτρολογίου Ctrl / Cmd-X';
$editortxt['Copy'] = 'Αντιγραφή';
$editortxt['Your browser does not allow the copy command. Please use the keyboard shortcut Ctrl/Cmd-C'] = 'Το πρόγραμμα περιήγησης δεν επιτρέπει την αντιγραφή.
Παρακαλώ δοκιμάστε την συντόμευση πληκτρολογίου Ctrl/Cmd-C  ';
$editortxt['Paste'] = 'Επικόλληση ';
$editortxt['Your browser does not allow the paste command. Please use the keyboard shortcut Ctrl/Cmd-V'] = 'Το πρόγραμμα περιήγησης δεν επιτρέπει την επικόλληση.
Παρακαλώ δοκιμάστε την συντόμευση πληκτρολογίου Ctrl/Cmd-V ';
$editortxt['Paste your text inside the following box:'] = 'Κάντε επικόλληση του κειμένου σας στο πλαίσιο:';
$editortxt['Paste Text'] = 'Επικόλληση Κειμένου';
$editortxt['Bullet list'] = 'Λίστα με κουκκίδες ';
$editortxt['Numbered list'] = 'Αριθμημένη λίστα ';
$editortxt['Undo'] = 'Αναίρεση';
$editortxt['Redo'] = 'Επαναφορά';
$editortxt['Rows:'] = 'Γραμμές';
$editortxt['Cols:'] = 'Cols:';
$editortxt['Insert a table'] = 'Εισαγωγή πίνακα';
$editortxt['Insert a horizontal rule'] = 'Εισαγωγή οριζόντιου κανόνα';
$editortxt['Code'] = 'Κώδικας';
$editortxt['Insert a Quote'] = 'Εισαγωγή παράθεσης';
$editortxt['Width (optional):'] = 'Πλάτος (προαιρετικό):';
$editortxt['Height (optional):'] = 'Ύψος(προαιρετικό):';
$editortxt['Insert an image'] = 'Εισαγωγή εικόνας
 ';
$editortxt['E-mail:'] = 'Ηλ. ταχυδρομείο:';
$editortxt['Insert an email'] = 'Εισαγωγή ηλ. ταχυδρομείου';
$editortxt['URL:'] = 'URL:';
$editortxt['Insert a link'] = 'Εισαγωγή συνδέσμου';
$editortxt['Unlink'] = 'Unlink';
$editortxt['More'] = 'Περισσότερες';
$editortxt['Insert an emoticon'] = 'Προσθήκη emoticon';
$editortxt['Video URL:'] = 'Βίντεο URL';
$editortxt['Insert'] = 'Εισαγωγή ';
$editortxt['Insert a YouTube video'] = 'Εισαγωγή βίντεο YouTube';
$editortxt['Insert current date'] = 'Εισαγωγή τρέχουσας ημερομηνίας';
$editortxt['Insert current time'] = 'Εισαγωγή τρέχουσας ώρας';
$editortxt['Print'] = 'Εκτύπωση';
$editortxt['Preformatted Text'] = 'Προμορφοποιημένο κείμενο';
$editortxt['View source'] = 'Προβολή πηγής';
$editortxt['Glow'] = 'Λάμψη';
$editortxt['Insert FTP Link'] = 'Εισαγωγή συνδέσμου FTP';
$editortxt['Shadow'] = 'Σκιά';
$editortxt['Teletype'] = 'Γραφομηχανή';
$editortxt['Move'] = 'Μετακίνηση';
$editortxt['Insert Spoiler'] = 'Εισαγωγή Spoiler';
$editortxt['Insert Footnote'] = 'Εισαγωγή υποσημείωσης';
$editortxt['Split Tag'] = 'Διαχωρισμός παράθεσης  (ctrl + enter)';