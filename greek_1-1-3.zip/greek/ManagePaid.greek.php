<?php
// Version: 1.1; ManagePaid

// Symbols.
$txt['usd_symbol'] = '$%1.2f';
$txt['eur_symbol'] = '&euro;%1.2f';
$txt['gbp_symbol'] = '&pound;%1.2f';

$txt['usd'] = 'USD ($)';
$txt['eur'] = 'EURO (&euro;)';
$txt['gbp'] = 'GBP (&pound;)';
$txt['other'] = 'Άλλο';

$txt['paid_username'] = 'Όνομα χρήστη';

$txt['paid_subscriptions_desc'] = 'Σε αυτό το τμήμα μπορείτε να προσθέτετε, να αφαιρείτε και να τροποποιείτε τις συνδρομές επί πληρωμή στο φόρουμ σας.';
$txt['paid_subs_settings'] = 'Επιλογές';
$txt['paid_subs_settings_desc'] = 'Εδώ μπορείτε να τροποποιήσετε τις διαθέσιμες μεθόδους πληρωμής για τους χρήστες σας.';
$txt['paid_subs_view'] = 'Εμφάνιση συνδρομών';
$txt['paid_subs_view_desc'] = 'Σε αυτό το τμήμα μπορείτε να δείτε όλες τις διαθέσιμες συνδρομές .';

// Setting type strings.
$txt['paid_enabled'] = 'Ενεργοποίηση συνδρομών επί πληρωμή';
$txt['paid_enabled_desc'] = 'This must be checked for the paid subscriptions to be used on the forum.';
$txt['paid_email'] = 'Αποστολή e-mail ειδοποίησης';
$txt['paid_email_desc'] = 'Πληροφόρηση στον διαχειριστή για το πότε αλλάζει αυτόματα κάποια συνδρομή.';
$txt['paid_email_to'] = 'E-mail για αλληλογραφία';
$txt['paid_email_to_desc'] = 'Λίστα διευθύνσεων e-mail για αποστολή ειδοποιήσεων, πλέον των διαχειριστών του φόρουμ, χωρισμένες με κόμμα.';
$txt['paidsubs_test'] = 'Ενεργοποίηση δοκιμαστικής λειτουργίας';
$txt['paidsubs_test_desc'] = 'Αυτό θέτει τις συνδρομές επί πληρωμή σε &quot;δοκιμαστική&quot; λειτουργία, η οποία, όταν είναι δυνατόν, χρησιμοποιεί sandbox μεθόδους πληρωμής στο paypal κ.ά. Μην το ενεργοποιείτε εκτός αν ξέρετε τι κάνετε!';
$txt['paidsubs_test_confirm'] = 'Είστε βέβαιοι ότι θέλετε να ενεργοποιήσετε τη δοκιμαστική λειτουργία;';
$txt['paid_email_no'] = 'Χωρίς αποστολή ειδοποιήσεων';
$txt['paid_email_error'] = 'Πληροφόρηση όταν κάποια συνδρομή αποτύχει';
$txt['paid_email_all'] = 'Πληροφόρηση σε όλες τις αυτόματες αλλαγές συνδρομών';
$txt['paid_currency'] = 'Επιλογή νομίσματος';
$txt['paid_currency_code'] = 'Κώδικας νομίσματος';
$txt['paid_currency_code_desc'] = 'Κώδικας που χρησιμοποιείται από διαμεσολαβητές πληρωμών';
$txt['paid_currency_symbol'] = 'Σύμβολο που χρησιμοποιείται από την μέθοδο πληρωμής';
$txt['paid_currency_symbol_desc'] = 'Χρησιμοποιείστε \'%1.2f\' για να ορίσετε που μπαίνει το νούμερο, για παράδειγμα $%1.2f, %1.2fDM κλπ';

$txt['paypal_email'] = 'Διεύθυνση e-mail στο Paypal';
$txt['paypal_email_desc'] = 'Αφήστε το κενό αν δεν θέλετε να χρησιμοποιήσετε το paypal.';

$txt['authorize_id'] = 'Αναγνωριστικό (ID) εγκατάστασης Authorize.net';
$txt['authorize_id_desc'] = 'Το αναγνωριστικό (ID) εγκατάστασης που δημιουργείται από το Authorize.net. Αφήστε το κενό αν δεν χρησιμοποιείτε Authorize.net';
$txt['authorize_transid'] = 'Αναγνωριστικό (ID) συναλλαγής Authorize.Net';

$txt['2co_id'] = '2checkout.com Install ID';
$txt['2co_id_desc'] = 'Το αναγνωριστικό (ID) εγκατάστασης που δημιουργείται από το 2co.com. Αφήστε το κενό αν δεν χρησιμοποιείτε 2co.com';
$txt['2co_password'] = '2checkout.com Secret Word';
$txt['2co_password_desc'] = 'Η μυστική σας λέξη του 2checkout.';
$txt['2co_password_wrong'] = 'Your 2checkout secret word was not accepted.';

$txt['paid_settings_save'] = 'Αποθήκευση';

$txt['paid_note'] = '<strong class="alert">Note:</strong><br />For subscriptions to be automatically updated for your users, you
	will need to setup a return URL for each of your payment methods. For all payment types, this return URL should be set as:<br /><br />
	&nbsp;&nbsp;&bull;&nbsp;&nbsp;<strong>{board_url}/subscriptions.php</strong><br /><br />
	You can edit the link for PayPal directly <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ipn-notify" target="_blank">by clicking here</a>.<br />
	For the other gateways (if installed) you can normally find it in your customer panels, usually under the term &quot;Return URL&quot; or &quot;Callback URL&quot;.';

// View subscription strings.
$txt['paid_name'] = 'Όνομα';
$txt['paid_status'] = 'Κατάσταση';
$txt['paid_cost'] = 'Κόστος';
$txt['paid_duration'] = 'Διάρκεια';
$txt['paid_active'] = 'Ενεργή';
$txt['paid_pending'] = 'Αναμένει πληρωμή';
$txt['paid_finished'] = 'Ολοκληρωμένη';
$txt['paid_total'] = 'Σύνολο';
$txt['paid_is_active'] = 'Ενεργό';
$txt['paid_none_yet'] = 'Δεν έχετε ορίσει ακόμη καμία συνδρομή.';
$txt['paid_none_ordered'] = 'You don\'t any subscriptions.';
$txt['paid_payments_pending'] = 'Πληρωμές σε αναμονή';
$txt['paid_order'] = 'Σειρά';

$txt['yes'] = 'Ναι';
$txt['no'] = 'Όχι';

// Add/Edit/Delete subscription.
$txt['paid_add_subscription'] = 'Προσθήκη νέας συνδρομής';
$txt['paid_edit_subscription'] = 'Τροποποίηση συνδρομής';
$txt['paid_delete_subscription'] = 'Διαγραφή συνδρομής';

$txt['paid_mod_name'] = 'Όνομα συνδρομής';
$txt['paid_mod_desc'] = 'Περιγραφή';
$txt['paid_mod_reminder'] = 'Αποστολή e-mail υπενθύμισης';
$txt['paid_mod_reminder_desc'] = 'Ημέρες πριν την λήξη της συνδρομής για την αποστολή υπενθύμισης. (Σε ημέρες, 0 για απενεργοποίηση)';
$txt['paid_mod_email'] = 'E-mail προς αποστολή κατά την ολοκλήρωση';
$txt['paid_mod_email_desc'] = 'Όπου {NAME} είναι το όνομα του μέλους, {FORUM} είναι το όνομα της κοινότητας. Ο τίτλος του e-mail πρέπει να είναι στην πρώτη γραμμή. Αφήστε κενό για μη αποστολή ειδοποίησης.';
$txt['paid_mod_cost_usd'] = 'Κόστος (USD)';
$txt['paid_mod_cost_eur'] = 'Κόστος (EUR)';
$txt['paid_mod_cost_gbp'] = 'Κόστος (GBP)';
$txt['paid_mod_cost_blank'] = 'Αφήστε το κενό για να μη χρησιμοποιηθεί αυτό το νόμισμα.';
$txt['paid_mod_span'] = 'Διάρκεια συνδρομής';
$txt['paid_mod_span_days'] = 'Ημέρες';
$txt['paid_mod_span_weeks'] = 'Εβδομάδες';
$txt['paid_mod_span_months'] = 'Μήνες';
$txt['paid_mod_span_years'] = 'Έτη';
$txt['paid_mod_active'] = 'Ενεργή';
$txt['paid_mod_active_desc'] = 'Η συνδρομή πρέπει να είναι ενεργή για να μπορούν να εγγραφούν νέα μέλη.';
$txt['paid_mod_prim_group'] = 'Κύρια ομάδα κατόπιν της εγγραφής';
$txt['paid_mod_prim_group_desc'] = 'Κύρια ομάδα μελών για την ένταξη του μέλους μετά την εγγραφή.';
$txt['paid_mod_add_groups'] = 'Πρόσθετες ομάδες κατόπιν της εγγραφής';
$txt['paid_mod_add_groups_desc'] = 'Πρόσθετες ομάδες μελών για την ένταξη του μέλους μετά την εγγραφή.';
$txt['paid_mod_no_group'] = 'Καμία αλλαγή';
$txt['paid_mod_edit_note'] = 'Σημειώστε ότι καθώς αυτή η ομάδα έχει ήδη συνδρομητές, οι ρυθμίσεις της ομάδας δεν μπορούν να αλλάξουν!';
$txt['paid_mod_delete_warning'] = '<strong>ΠΡΟΕΙΔΟΠΟΙΗΣΗ</strong><br /><br />Αν διαγράψετε αυτήν την συνδρομή, όλα τα μέλη που είναι τώρα εγγεγραμμένοι θα χάσουν όλα τα δικαιώματα πρόσβασης που δίνονται από αυτήν την συνδρομή. Εκτός αν είστε σίγουρος ότι θέλετε να το κάνετε αυτό, συνιστάται απλά να απενεργοποιήσετε την συνδρομή από το να την διαγράψετε.<br />';
$txt['paid_mod_repeatable'] = 'Να επιτρέπεται στο μέλος να ανανεώνει αυτόματα αυτήν την συνδρομή';
$txt['paid_mod_allow_partial'] = 'Να επιτρέπεται μερική συνδρομή';
$txt['paid_mod_allow_partial_desc'] = 'Αν αυτή η επιλογή είναι ενεργοποιημένη, στην περίπτωση που το μέλος πληρώσει λιγότερο από το απαιτούμενο, θα τους δοθεί μια συνδρομή με το ποσοστό της διάρκειας για το οποίο έχουν πληρώσει.';
$txt['paid_mod_fixed_price'] = 'Συνδρομή για σταθερή τιμή και διάρκεια';
$txt['paid_mod_flexible_price'] = 'Η τιμή της συνδρομής διαφέρει ανάλογα με τη διάρκεια που ζητήθηκε';
$txt['paid_mod_price_breakdown'] = 'Ευέλικτη τιμολόγηση';
$txt['paid_mod_price_breakdown_desc'] = 'Ορίστε εδώ το πόσο θα πρέπει να κοστίζει η συνδρομή ανάλογα με την περίοδο για την οποία εγγράφονται τα μέλη. Για παράδειγμα, θα πρέπει να κοστίζει 12 ευρώ για συνδρομή ενός μήνα, αλλά μόνο 100 ευρώ για συνδρομή ενός έτους. Αν δεν θέλετε να ορίσετε μια τιμή για συγκεκριμένη χρονική περίοδο, αφήστε το κενό.';
$txt['flexible'] = 'Ευέλικτη';

$txt['paid_per_day'] = 'Τιμή ανά ημέρα';
$txt['paid_per_week'] = 'Τιμή ανά εβδομάδα';
$txt['paid_per_month'] = 'Τιμή ανά μήνα';
$txt['paid_per_year'] = 'Τιμή ανά έτος';
$txt['day'] = 'Ημέρα';
$txt['week'] = 'Εβδομάδα';
$txt['month'] = 'Μήνας';
$txt['year'] = 'Έτος';

// View subscribed users.
$txt['viewing_users_subscribed'] = 'Εμφάνιση μελών';
$txt['view_users_subscribed'] = 'Εμφάνιση μελών συνδρομητών στo: &quot;%1$s&quot;';
$txt['no_subscribers'] = 'There are currently no subscribers to this subscription.';
$txt['add_subscriber'] = 'Προσθήκη νέου συνδρομητή';
$txt['edit_subscriber'] = 'Τροποποίηση συνδρομητή';
$txt['delete_selected'] = 'Διαγραφή επιλεγμένων';
$txt['complete_selected'] = 'Ολοκλήρωση επιλεγμένων';

// @todo These strings are used in conjunction with JavaScript.  Use numeric entities.
$txt['delete_are_sure'] = 'Σίγουρα θέλετε να διαγράψετε όλες τις καταχωρήσεις για τις επιλεγμένες συνδρομές;';
$txt['complete_are_sure'] = 'Σίγουρα θέλετε να ολοκληρώσετε τις επιλεγμένες συνδρομές;';

$txt['start_date'] = 'Ημερομηνία αρχής';
$txt['end_date'] = 'Ημερομηνία λήξης';
$txt['start_date_and_time'] = 'Ημερομηνία και ώρα αρχής';
$txt['end_date_and_time'] = 'Ημερομηνία και ώρα λήξης';
$txt['one_username'] = 'Εισαγάγετε μόνο ένα όνομα χρήστη.';
$txt['minute'] = 'Λεπτά';
$txt['error_member_not_found'] = 'Το μέλος που δόθηκε δεν βρέθηκε';
$txt['member_already_subscribed'] = 'Αυτό το μέλος είναι ήδη εγγεγραμμένο σε αυτή τη συνδρομή. Παρακαλούμε τροποποιήστε την υπάρχουσα συνδρομή του.';
$txt['search_sub'] = 'Εύρεση μέλους';

// Make payment.
$txt['paid_confirm_payment'] = 'Επιβεβαίωση πληρωμής';
$txt['paid_confirm_desc'] = 'Για να συνεχίσετε με την πληρωμή παρακαλούμε ελέγξτε τα παρακάτω στοιχεία και πατήστε το &quot;Παραγγελίαρω&quot;';
$txt['paypal'] = 'PayPal';
$txt['paid_confirm_paypal'] = 'Για να πληρώσετε χρησιμοποιώντας το <a href="http://www.paypal.com">PayPal</a> πατήστε το παρακάτω κουμπί. Θα παραπεμφθείτε στην ιστοσελίδα του PayPal για πληρωμή.';
$txt['paid_paypal_order'] = 'Παραγγελία μέσω PayPal';
$txt['authorize'] = 'Authorize.Net';
$txt['paid_confirm_authorize'] = 'Για να πληρώσετε χρησιμοποιώντας το <a href="http://www.authorize.net">Authorize.Net</a> πατήστε το παρακάτω κουμπί. Θα παραπεμφθείτε στην ιστοσελίδα του Authorize.Net για πληρωμή.';
$txt['paid_authorize_order'] = 'Παραγγελία μέσω Authorize.Net';
$txt['2co'] = '2checkout';
$txt['paid_confirm_2co'] = 'Για να πληρώσετε χρησιμοποιώντας το <a href="http://www.2co.com">2co.com</a> πατήστε το παρακάτω κουμπί. Θα ανακατευθυνθείτε στην ιστοσελίδα του 2co.com για πληρωμή.';
$txt['paid_2co_order'] = 'Παραγγελία μέσω 2co.com';
$txt['paid_done'] = 'Η πληρωμή ολοκληρώθηκε';
$txt['paid_done_desc'] = 'Ευχαριστούμε για την πληρωμή σας. Όταν επαληθευτεί η συναλλαγή, η συνδρομή σας θα ενεργοποιηθεί.';
$txt['paid_sub_return'] = 'Επιστροφή στις συνδρομές';
$txt['paid_current_desc'] = 'Ακολουθεί λίστα όλων των ενεργών και προηγούμενων συνδρομών σας. Για να επεκτείνετε μια υπάρχουσα συνδρομή επιλέξτε την από την παραπάνω λίστα.';
$txt['paid_admin_add'] = 'Προσθήκη αυτής της συνδρομής';

$txt['paid_not_set_currency'] = 'Δεν έχετε ορίσει ακόμα το νόμισμά σας. Παρακαλούμε κάντε το από το μενού ρυθμίσεων πριν συνεχίσετε';
$txt['paid_no_cost_value'] = 'Πρέπει να καθορίσετε το κόστος και διάρκεια συνδρομής.';
$txt['paid_all_freq_blank'] = 'Πρέπει να καθορίσετε το κόστος για τουλάχιστον μία από τις τέσσερις διάρκειες.';

// Some error strings.
$txt['paid_no_data'] = 'Τα δεδομένα που στάλθηκαν δεν ήταν έγκυρα.';

$txt['paypal_could_not_connect'] = 'Αποτυχία σύνδεσης με τον διακομιστή του PayPal';
$txt['paypal_currency_unkown'] = 'The currency code from PayPal (%1$s) does not match the code in your settings (%2$s)';
$txt['paid_sub_not_active'] = 'That subscription is not taking any new users.';
$txt['paid_disabled'] = 'Paid subscriptions are currently disabled.';
$txt['paid_unknown_transaction_type'] = 'Άγνωστος τύπος συναλλαγής συνδρομής επί πληρωμή.';
$txt['paid_empty_member'] = 'Ο δείκτης χειρισμού συνδρομής δεν μπόρεσε να ανακτήσει το αναγνωριστικό μέλους';
$txt['paid_could_not_find_member'] = 'Η διαχείριση συνδρομών επί πληρωμή δεν μπόρεσε να βρει το μέλος με αναγνωριστικό (ID): %1$d';
$txt['paid_count_not_find_subscription'] = 'Ο δείκτης χειρισμού συνδρομής επί πληρωμή δεν μπόρεσε να βρει συνδρομή για το μέλος με αναγνωριστικό (ID): %1$s, αναγνωριστικό (ID) συνδρομής: %2$s';
$txt['paid_count_not_find_subscription_log'] = 'Ο δείκτης χειρισμού συνδρομής δεν μπόρεσε να βρεί καταχώρηση στο αρχείο καταγραφής συνδρομών για το μέλος με αναγνωριστικό (ID): %1$s, αναγνωριστικό (ID) συνδρομής: %2$s';
$txt['paid_count_not_find_outstanding_payment'] = 'Δεν ήταν δυνατή η εύρεση καταχώρισης εκκρεμούς πληρωμής για το αναγνωριστικό μέλους: %1$s, αναγνωριστικό (ID) συνδρομής: το %2$s παραβλέπεται';
$txt['paid_admin_not_setup_gateway'] = 'Λυπούμαστε αλλά ο διαχειριστής δεν έχει ακόμη τελειώσει με τον καθορισμό συνδρομών επί πληρωμή – παρακαλούμε επιστρέψτε αργότερα.';
$txt['paid_make_recurring'] = 'Αυτή η πληρωμή να γίνει επαναλαμβανόμενη';

$txt['subscriptions'] = 'Συνδρομές';
$txt['subscription'] = 'Συνδρομή';
$txt['subscribers'] = 'Subscribers';
$txt['paid_subs_desc'] = 'Below is a list of all the subscriptions which are available on this site.';
$txt['paid_subs_none'] = 'There are currently no paid subscriptions available.';

$txt['paid_current'] = 'Υπάρχουσες συνδρομές';
$txt['pending_payments'] = 'Πληρωμές σε αναμονή';
$txt['pending_payments_desc'] = 'Αυτό το μέλος προσπάθησε να κάνει τις ακόλουθες πληρωμές γα αυτήν την συνδρομή αλλά η επιβεβαίωση δεν έχει ακόμα ληφθεί από το φόρουμ. Αν είστε σίγουρος ότι η πληρωμή έχει γίνει πατήστε &quot;αποδοχή&quot; ως ενέργεια στην συνδρομή. Εναλλακτικά μπορείτε να πατήσετε &quot;Διαγραφή&quot; για να διαγράψετε όλες τις καταχωρήσεις αναφορικά με την πληρωμή.';
$txt['pending_payments_value'] = 'Ποσό';
$txt['pending_payments_accept'] = 'Αποδοχή';
$txt['pending_payments_remove'] = 'Διαγραφή';