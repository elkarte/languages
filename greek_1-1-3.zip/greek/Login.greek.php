<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Συμφωνία εγγραφής';
$txt['registration_privacy_policy'] = 'Πολιτική απορρήτου ';
$txt['agreement_agree'] = 'Αποδέχομαι τους όρους του συμφωνητικού';
$txt['agreement_no_agree'] = 'Δεν αποδέχομαι τους όρους της συμφωνίας.';
$txt['policy_agree'] = 'Αποδέχομαι τους όρους της πολιτικής απορρήτου.';
$txt['policy_no_agree'] = 'Δεν αποδέχομαι τους όρους της πολιτικής απορρήτου.';
$txt['agreement_agree_coppa_above'] = 'Αποδέχομαι τους όρους του συμφωνητικού και είμαι τουλάχιστον %1$d ετών.';
$txt['agreement_agree_coppa_below'] = 'Αποδέχομαι τους όρους του συμφωνητικού και είμαι νεότερος από %1$d ετών.';
$txt['agree_coppa_above'] = 'Είμαι τουλάχιστον %1$dχρονών';
$txt['agree_coppa_below'] = 'Είμαι μικρότερος από %1$d χρονών';

// Registration form.
$txt['registration_form'] = 'Φόρμα εγγραφής';
$txt['error_too_quickly'] = 'Περάσατε τη διαδικασία εγγραφής πολύ γρήγορα, γρηγορότερα από ό,τι κανονικά θα ήταν εφικτό. Περιμένετε λίγο και δοκιμάστε ξανά.';
$txt['error_token_verification'] = 'Η επαλήθευση του απέτυχε. Παρακαλώ προσπαθήστε ξανά.';
$txt['need_username'] = 'Πρέπει να δώσετε ένα όνομα χρήστη.';
$txt['no_password'] = 'Ο κωδικός είναι απαραίτητος';
$txt['improper_password'] = 'Ο κωδικός πρόσβασης είναι πολύ μεγάλος.';
$txt['incorrect_password'] = 'Λάθος κωδικός';
$txt['openid_not_found'] = 'Δεν βρέθηκε το αναγνωριστικό OpenID.';
$txt['maintain_mode'] = 'Κατάσταση συντήρησης';
$txt['registration_successful'] = 'Η εγγραφή ήταν επιτυχής';
$txt['valid_email_needed'] = 'Παρακαλώ δώστε μία έγκυρη διεύθυνση e-mail, %1$s.';
$txt['required_info'] = 'Απαιτούμενα στοιχεία';
$txt['additional_information'] = 'Πρόσθετες πληροφορίες';
$txt['warning'] = 'Προσοχή!';
$txt['only_members_can_access'] = 'Μόνο εγγεγραμμένα μέλη μπορούν να προσπελάσουν αυτήν την περιοχή.';
$txt['login_below'] = 'Παρακαλούμε συνδεθείτε παρακάτω.';
$txt['login_below_or_register'] = 'Παρακαλούμε συνδεθείτε παρακάτω ή <a href="%1$s">δημιουργήστε λογαριασμό</a>με %2$s';
$txt['checkbox_agreement'] = 'Αποδέχομαι τη συμφωνία εγγραφής';
$txt['checkbox_privacypol'] = 'Αποδέχομαι την πολιτική απορρήτου';
$txt['confirm_request_accept_agreement'] = 'Είστε βέβαιοι ότι θέλετε να αναγκάσετε όλα τα μέλη να αποδεχθούν τη συμφωνία?';
$txt['confirm_request_accept_privacy_policy'] = 'Είστε βέβαιοι ότι θέλετε να αναγκάσετε όλα τα μέλη να αποδεχθούν την πολιτική απορρήτου?';

$txt['login_hash_error'] = 'Η κωδικός έχει αναβαθμιστεί πρόσφατα.<br />Παρακαλώ πληκτρολογήστε ξανά τον κωδικό σας.';

$txt['ban_register_prohibited'] = 'Συγγνώμη, δεν σας επιτρέπεται να εγγραφείτε σε αυτό το φόρουμ';
$txt['under_age_registration_prohibited'] = 'Λυπούμαστε, αλλά χρήστες κάτω από την ηλικία των %1$d ετών δεν επιτρέπεται να εγγραφούν σε αυτό το φόρουμ.';

$txt['activate_account'] = 'Ενεργοποίηση λογαριασμού';
$txt['activate_success'] = 'Ο λογαριασμός σας ενεργοποιήθηκε. Μπορείτε να προχωρήσετε σε σύνδεση.';
$txt['activate_not_completed1'] = 'Η διεύθυνση e-mail σας χρειάζεται να πιστοποιηθεί πριν να μπορέσετε να συνδεθείτε.';
$txt['activate_not_completed2'] = 'Χρειάζεστε κι άλλο e-mail ενεργοποίησης;';
$txt['activate_after_registration'] = 'Ευχαριστούμε για την εγγραφή. Θα λάβετε σύντομα ένα email με έναν σύνδεσμο για να ενεργοποιήσετε τον λογαριασμό σας. Αν δεν λάβετε email μετά από κάποιο καιρό, ελέγξτε τον φάκελο ανεπιθύμητης αλληλογραφίας (spam folder)';
$txt['invalid_userid'] = 'Ο χρήστης δεν υπάρχει';
$txt['invalid_activation_code'] = 'Λάθος κωδικός ενεργοποίησης';
$txt['invalid_activation_username'] = 'Όνομα χρήστη ή e-mail';
$txt['invalid_activation_new'] = 'Αν εγγραφήκατε με εσφαλμένη διεύθυνση e-mail, γράψτε μια νέα καθώς και τον κωδικό σας, εδώ.';
$txt['invalid_activation_new_email'] = 'Νέα διεύθυνση e-mail';
$txt['invalid_activation_password'] = 'Παλιός κωδικός';
$txt['invalid_activation_resend'] = 'Αποστολή ξανά του κωδικού ενεργοποίησης';
$txt['invalid_activation_known'] = 'Αν ήδη γνωρίζετε τον κωδικό ενεργοποίησης, γράψτε τον εδώ.';
$txt['invalid_activation_retry'] = 'Κωδικός ενεργοποίησης';
$txt['invalid_activation_submit'] = 'Ενεργοποίηση';

$txt['coppa_no_concent'] = 'Ο διαχειριστής δεν έχει ακόμη λάβει την έγκριση του γονέα/κηδεμόνα για τον λογαριασμό σας.';
$txt['coppa_need_more_details'] = 'Χρειάζεστε περισσότερες λεπτομέρειες;';

$txt['awaiting_delete_account'] = 'Ο λογαριασμός σας έχει σημανθεί για διαγραφή!<br />Αν θέλετε να επαναφέρετε τον λογαριασμό σας, επιλέξτε το &quot;Επαναενεργοποίηση του λογαριασμού μου&quot;, και συνδεθείτε ξανά.';
$txt['undelete_account'] = 'Επαναενεργοποίηση του λογαριασμού μου';

$txt['in_maintain_mode'] = 'Αυτός ο πίνακας είναι σε κατάσταση συντήρησης.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Παρακαλούμε διαβάστε/αποδεχτείτε τους όρους για να αποσταλεί η φόρμα.';
$txt['register_passwords_differ_js'] = 'Οι δύο κωδικοί που εισαγάγατε δεν είναι οι ίδιοι!';
$txt['register_did_you'] = 'Εννοείται';

$txt['approval_after_registration'] = 'Ευχαριστούμε για την εγγραφή. Ο διαχειριστής πρέπει να εγκρίνει την εγγραφή σας πριν να μπορέσετε να χρησιμοποιήσετε τον λογαριασμό σας. Θα λάβετε σύντομα ένα email που θα σας ενημερώνει για την απόφαση του διαχειριστή.';

$txt['admin_settings_desc'] = 'Εδώ μπορείτε να αλλάξετε μια πληθώρα ρυθμίσεων σχετικά με την εγγραφή νέων μελών.';

$txt['setting_enableOpenID'] = 'Επιτρέπει στους χρήστες να κάνουν εγγραφή χρησιμοποιώντας το OpenID';

$txt['setting_registration_method'] = 'Μέθοδος εγγραφής για τα νέα μέλη';
$txt['setting_registration_disabled'] = 'Εγγραφές απενεργοποιημένες';
$txt['setting_registration_standard'] = 'Άμεση εγγραφή';
$txt['setting_registration_activate'] = 'Ενεργοποίηση με email';
$txt['setting_registration_approval'] = 'Έγκριση από διαχειριστή';
$txt['setting_notify_new_registration'] = 'Ειδοποίηση προς τους διαχειριστές όταν ένα νέο μέλος εγγράφεται';
$txt['setting_force_accept_agreement'] = 'Αναγκάστε τα μέλη να αποδεχθούν τη συμφωνία εγγραφής όταν αλλάξει';
$txt['force_accept_privacy_policy'] = 'Αναγκάστε τα μέλη να αποδεχθούν την πολιτική απορρήτου όταν αλλάξει';
$txt['setting_send_welcomeEmail'] = 'Αποστολή email καλωσορίσματος στα νέα μέλη';
$txt['setting_show_DisplayNameOnRegistration'] = 'Επιτρέψτε στους χρήστες να εισάγουν το εμφανιζόμενο όνομα';

$txt['setting_coppaAge'] = 'Ηλικία κάτω από την οποία θα εφαρμόζονται περιορισμοί εγγραφής';
$txt['setting_coppaAge_desc'] = '(0 για απενεργοποίηση)';
$txt['setting_coppaType'] = 'Ενέργεια που θα πραγματοποιείται όταν εγγράφεται ένας χρήστης με ηλικία κάτω από την ελάχιστη';
$txt['setting_coppaType_reject'] = 'Απόρριψη εγγραφής';
$txt['setting_coppaType_approval'] = 'Απαιτείται έγκριση γονέα/κηδεμόνα';
$txt['setting_coppaPost'] = 'Ταχυδρομική διεύθυνση στην οποία θα στέλνονται οι φόρμες έγκρισης';
$txt['setting_coppaPost_desc'] = 'Ισχύει μόνο αν ενεργοποιηθεί ο περιορισμός ηλικίας';
$txt['setting_coppaFax'] = 'Νούμερο Fax στο οποίο θα στέλνονται οι φόρμες έγκρισης';
$txt['setting_coppaPhone'] = 'Τηλέφωνο επικοινωνίας για γονείς που θέλουν να ρωτήσουν σχετικά με τον περιορισμό ηλικίας';

$txt['admin_register'] = 'Εγγραφή νέου μέλους';
$txt['admin_register_desc'] = 'Εδώ μπορείτε να εγγράψετε νέα μέλη στο φόρουμ και, αν θέλετε, να στείλετε τα στοιχεία τους με email.';
$txt['admin_register_username'] = 'Νέο όνομα χρήστη';
$txt['admin_register_email'] = 'Διεύθυνση e-mail';
$txt['admin_register_password'] = 'Κωδικός';
$txt['admin_register_username_desc'] = 'Όνομα χρήστη νέου μέλους';
$txt['admin_register_email_desc'] = 'Διεύθυνση e-mail του μέλους<br />(απαραίτητη αν επιλέξετε να στείλετε τα στοιχεία με email)';
$txt['admin_register_password_desc'] = 'Νέος κωδικός για τον χρήστη';
$txt['admin_register_email_detail'] = 'Αποστολή με e-mail του νέου κωδικού στον χρήστη';
$txt['admin_register_email_detail_desc'] = 'Η διεύθυνση email είναι προαπαιτούμενη, ακόμη κι αν δεν έχει επιλεχθεί';
$txt['admin_register_email_activate'] = 'Απαιτείται ο χρήστης να ενεργοποιήσει τον λογαριασμό;';
$txt['admin_register_group'] = 'Κύρια ομάδα μελών';
$txt['admin_register_group_desc'] = 'Κύρια ομάδα μελών όπου θα ανήκει το νέο μέλος';
$txt['admin_register_group_none'] = '(χωρίς κύρια ομάδα μελών)';
$txt['admin_register_done'] = 'Το μέλος %1$s εγγράφηκε επιτυχώς!';

$txt['coppa_title'] = 'Φόρουμ με περιορισμό ηλικίας';
$txt['coppa_after_registration'] = 'Ευχαριστούμε για την εγγραφή σας στο φόρουμ {forum_name_html_safe}.<br /><br />Επειδή είστε κάτω από την ηλικία των {MINIMUM_AGE},είναι μια νομική απαίτηση να αποκτήσετε την άδεια γονέα ή κηδεμόνα πριν να αρχίσετε να χρησιμοποιείτε το λογαριασμό σας. Για να κανονίσετε την ενεργοποίηση του λογαριασμού, παρακαλούμε να εκτυπώσετε την παρακάτω φόρμα:';
$txt['coppa_form_link_popup'] = 'Ανοιγμα φόρμας σε νέο παράθυρο';
$txt['coppa_form_link_download'] = 'Λήψη φόρμας ως αρχείο κειμένου';
$txt['coppa_send_to_one_option'] = 'Μετά, ζήτησε από τον γονέα/κηδεμόνα σου να στείλει την συμπληρωμένη φόρμα με:';
$txt['coppa_send_to_two_options'] = 'Μετά, ζήτησε από τον γονέα/κηδεμόνα σου να στείλει την συμπληρωμένη φόρμα με είτε:';
$txt['coppa_send_by_post'] = 'Ταχυδρομικώς, στην ακόλουθη διεύθυνση:';
$txt['coppa_send_by_fax'] = 'Fax, στον ακόλουθο αριθμό:';
$txt['coppa_send_by_phone'] = 'Εναλλακτικά, ζήτησε να τηλεφωνήσει στον διαχειριστή στον αριθμό {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Έντυπο άδειας για εγγραφή σε  {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Διεύθυνση';
$txt['coppa_form_date'] = 'Ημερομηνία';
$txt['coppa_form_body'] = 'Εγώ ο/η {PARENT_NAME},<br /><br /> δίνω την άδεια μου στον/στην {CHILD_NAME} (child name) να γίνει μέλος του φόρουμ: {forum_name_html_safe}, με όνομα πρόσβασης:  {USER_NAME}.<br /><br />Κατανοώ ότι ορισμένες προσωπικές πληροφορίες που καταχωρήθηκαν από το μέλος {USER_NAME} μπορεί να εμφανιστούν σε άλλους χρήστες του φόρουμ.<br /><br />Υπογραφή:<br />{PARENT_NAME} (κηδεμόνας).';

$txt['visual_verification_sound_again'] = 'Επανάληψη αναπαραγωγής';
$txt['visual_verification_sound_close'] = 'Κλείσιμο παραθύρου';
$txt['visual_verification_sound_direct'] = 'Έχετε δυσκολία να το ακούσετε; Δοκιμάστε έναν απευθείας σύνδεσμο.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Το όνομα χρήστη είναι διαθέσιμο';
$txt['registration_username_unavailable'] = 'Το όνομα χρήστη δεν είναι διαθέσιμο';
$txt['registration_username_check'] = 'Έλεγχος για διαθεσιμότητα του ονόματος χρήστη';
$txt['registration_password_short'] = 'Ο κωδικός είναι πολύ μικρός σε μήκος';
$txt['registration_password_reserved'] = 'Ο κωδικός εμπεριέχει το όνομα χρήστη ή email';
$txt['registration_password_numbercase'] = 'Ο κωδικός πρέπει να περιέχει και κεφαλαία και μικρά, καθώς και νούμερα';
$txt['registration_password_no_match'] = 'Οι κωδικοί δεν ταιριάζουν';
$txt['registration_password_valid'] = 'Ο κωδικός είναι έγκυρος';

$txt['registration_errors_occurred'] = 'Τα παρακάτω λάθη ανιχνεύθηκαν στην εγγραφή σας. Παρακαλούμε διορθώστε τα για να συνεχίσετε:';

$txt['authenticate_label'] = 'Μέθοδος πιστοποίησης';
$txt['authenticate_password'] = 'Κωδικός';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'URL πιστοποίησης OpenID ';
$txt['otp_required'] = 'Ένας κωδικός πρόσβασης μίας χρήσης απαιτείται για να συνδεθείτε!';
$txt['disable_otp'] = 'Απενεργοποίηση ελέγχου ταυτότητας δύο παραγόντων';

// Contact form
$txt['admin_contact_form'] = 'Επικοινωνήστε με τους διαχειριστές';
$txt['contact_your_message'] = 'Το μήνυμα σας';
$txt['errors_contact_form'] = 'Παρουσιάστηκαν τα ακόλουθα σφάλματα κατά την διάρκεια του αιτήματος επικοινωνίας';
$txt['contact_subject'] = 'Ένας επισκέπτης σας έστειλε ένα μήνυμα';
$txt['contact_thankyou'] = 'Σας ευχαριστούμε για το μήνυμά σας. Κάποιος θα επικοινωνήσει μαζί σας το συντομότερο δυνατό.';
