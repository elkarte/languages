<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Προγραμματισμένες Εργασίες';
$txt['scheduled_tasks_header'] = 'Όλες οι προγραμματισμένες εργασίες';
$txt['scheduled_tasks_name'] = 'Όνομα εργασίας';
$txt['scheduled_tasks_next_time'] = 'Επόμενη εκτέλεση';
$txt['scheduled_tasks_regularity'] = 'Συχνότητα';
$txt['scheduled_tasks_enabled'] = 'Ενεργή';
$txt['scheduled_tasks_run_now'] = 'Εκτέλεση εργασίας τώρα';
$txt['scheduled_tasks_save_changes'] = 'Αποθήκευση αλλαγών';
$txt['scheduled_tasks_time_offset'] = '<strong>Note:</strong> All times given below are <em>server time</em> and do not take any time offsets setup within the admin panel into account.';
$txt['scheduled_tasks_were_run'] = 'Όλες οι επιλεγμένες εργασίες ολοκληρώθηκαν';
$txt['scheduled_tasks_were_run_errors'] = 'The following errors occurred while running the scheduled tasks:';

$txt['scheduled_tasks_na'] = '(-)';
$txt['scheduled_task_approval_notification'] = 'Ειδοποιήσεις έγκρισης';
$txt['scheduled_task_desc_approval_notification'] = 'Αποστολή e-mail σε όλους τους συντονιστές συνοψίζοντας τα μηνύματα που περιμένουν έγκριση.';
$txt['scheduled_task_auto_optimize'] = 'Βελτιστοποίηση βάσης δεδομένων';
$txt['scheduled_task_desc_auto_optimize'] = 'Βελτιστοποίηση της βάσης δεδομένων για να επιλυθούν ζητήματα κατακερματισμού.';
$txt['scheduled_task_daily_maintenance'] = 'Ημερήσια συντήρηση';
$txt['scheduled_task_desc_daily_maintenance'] = 'Εκτελεί ουσιαστική ημερήσια συντήρηση στο φόρουμ - δεν θα πρέπει να απενεργοποιηθεί.';
$txt['scheduled_task_daily_digest'] = 'Ημερήσια περίληψη ειδοποιήσεων';
$txt['scheduled_task_desc_daily_digest'] = 'Στέλνει με e-mail την ημερήσια ανασκόπηση στους συνδρομητές ειδοποιήσεων.';
$txt['scheduled_task_weekly_digest'] = 'Εβδομαδιαία περίληψη ειδοποιήσεων';
$txt['scheduled_task_desc_weekly_digest'] = 'Στέλνει με e-mail την εβδομαδιαία ανασκόπηση στους συνδρομητές ειδοποιήσεων.';
$txt['scheduled_task_birthdayemails'] = 'Αποστολή e-mail γενεθλίων';
$txt['scheduled_task_desc_birthdayemails'] = 'Στέλνει ευχετήρια e-mail για τα χρόνια πολλά.';
$txt['scheduled_task_weekly_maintenance'] = 'Εβδομαδιαία συντήρηση';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Εκτελεί ουσιαστική εβδομαδιαία συντήρηση στο φόρουμ - δεν θα πρέπει να απενεργοποιηθεί.';
$txt['scheduled_task_paid_subscriptions'] = 'Έλεγχος συνδρομών επί πληρωμή';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Στελνει τις απαραίτητες υπενθυμίσεις για πληρωμή συνδρομών και διαγράφει τις ληγμένες συνδρομές μελών.';
$txt['scheduled_task_remove_topic_redirect'] = 'Remove MOVED: Redirection Topics';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Deletes "MOVED:" topic notifications as specified when the moved notice was created.';
$txt['scheduled_task_remove_temp_attachments'] = 'Remove Temporary Attachment Files';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Deletes temporary files created while attaching a file to a post that for any reason weren\'t renamed or deleted before.';
$txt['scheduled_task_remove_old_drafts'] = 'Remove Old Drafts';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Deletes drafts older than the number of days defined in the draft settings in the admin panel.';
$txt['scheduled_task_remove_old_followups'] = 'Remove Old Follow-ups';
$txt['scheduled_task_desc_remove_old_followups'] = 'Deletes follow-up entries still present in the database, but pointing to non-existent topics.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Fetch Emails from IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Fetches emails for the mailing list feature from an IMAP box and processes them.';
$txt['scheduled_task_user_access_mentions'] = 'Users Mentions Access';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verify users access to each board and set accessibility to related mentions accordingly.';

$txt['scheduled_task_reg_starting'] = 'Αρχή από %1$s';
$txt['scheduled_task_reg_repeating'] = 'με επανάληψη κάθε %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'λεπτό/ά';
$txt['scheduled_task_reg_unit_h'] = 'ώρα/ες';
$txt['scheduled_task_reg_unit_d'] = 'ημέρες';
$txt['scheduled_task_reg_unit_w'] = 'εβδομάδα/ες';

$txt['scheduled_task_edit'] = 'Τροποποίηση προγραμματισμένης εργασίας';
$txt['scheduled_task_edit_repeat'] = 'Επανάληψη εργασίας κάθε';
$txt['scheduled_task_edit_pick_unit'] = 'Επιλέξτε μονάδα';
$txt['scheduled_task_edit_interval'] = 'Περίοδος';
$txt['scheduled_task_edit_start_time'] = 'Ώρα εκκίνησης';
$txt['scheduled_task_edit_start_time_desc'] = 'Η ώρα εκκίνησης της πρώτης εκτέλεσης της ημέρας (ώρες:λεπτά)';
$txt['scheduled_task_time_offset'] = 'Σημείωση: η ώρα εκκίνησης πρέπει να είναι η διαφορά ώρας συν την ώρα του εξυπηρετητή. Τρέχουσα ώρα εξυπηρετητή: %1$s';

$txt['scheduled_view_log'] = 'Εμφάνιση αρχείου καταγραφής';
$txt['scheduled_log_empty'] = 'Αυτήν την στιγμή δεν υπάρχουν εγγραφές στο αρχείο καταγραφής εργασιών.';
$txt['scheduled_log_time_run'] = 'Ώρα εκτέλεσης';
$txt['scheduled_log_time_taken'] = 'Χρόνος που απαιτήθηκε';
$txt['scheduled_log_time_taken_seconds'] = '%1$d δευτερόλεπτα';
$txt['scheduled_log_completed'] = 'Task completed';
$txt['scheduled_log_empty_log'] = 'Διαγραφή όλων';
$txt['scheduled_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log?';