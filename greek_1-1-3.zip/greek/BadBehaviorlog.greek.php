<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Ημερομηνία';
$txt['badbehaviorlog_protocol'] = 'Πρωτόκολλο ';
$txt['badbehaviorlog_method'] = 'Μέθοδος';
$txt['badbehaviorlog_request'] = 'Αίτημα';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'ID Μέλους';
$txt['badbehaviorlog_username'] = 'Όνομα χρήστη';
$txt['badbehaviorlog_headers'] = 'Κεφαλίδες ';
$txt['badbehaviorlog_agent'] = 'Πλοηγός ';
$txt['badbehaviorlog_entity'] = 'Αποστολή';
$txt['badbehaviorlog_key'] = 'Κλειδί';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Σύνολο καταχωρήσεων';
$txt['badbehaviorlog_error_valid_code'] = 'Κωδικός Αιτίας';
$txt['badbehaviorlog_error_valid_response'] = 'Κατάσταση HTTP';
$txt['badbehaviorlog_error_valid_explaination'] = 'Αιτία HTTP';
$txt['badbehaviorlog_error_valid_log'] = 'Λεπτομέρειες';
$txt['badbehaviorlog_log'] = 'Αρχείο Μη Αποδεκτής Συμπεριφοράς';
$txt['badbehaviorlog_desc'] = 'Παρακάτω είναι η λίστα όλων των καταχωρίσεων μη αποδεκτής συμπεριφοράς που έχουν καταγραφεί';
$txt['badbehaviorlog_details'] = 'Επιπλέον Πληροφορίες';
$txt['badbehaviorlog_no_entries_found'] = 'Αυτήν τη στιγμή δεν υπάρχουν καταχωρήσεις στο αρχείο μη αποδεκτής συμπεριφοράς.';

$txt['badbehaviorlog_remove_selection'] = 'Διαγραφή επιλεγμένων';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Είστε βέβαιοι ότι θέλετε να διαγράψετε τις επιλεγμένες καταχωρίσεις;';
$txt['badbehaviorlog_remove_filtered_results'] = 'Καταργήστε όλα τα φιλτραρισμένα αποτελέσματα';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Είστε βέβαιοι ότι θέλετε να διαγράψετε τις φιλτραρισμένες καταχωρίσεις;';
$txt['badbehaviorlog_sure_remove'] = 'Είστε βέβαιοι ότι θέλετε να καθαρίσετε εντελώς το αρχείο μη αποδεκτής συμπεριφοράς;';

$txt['badbehaviorlog_remove'] = 'Διαγραφή επιλεγμένων';
$txt['badbehaviorlog_removeall'] = 'Διαγραφή όλων';
$txt['badbehaviorlog_clear_filter'] = 'Καθαρισμός φίλτρου';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Εφαρμογή φίλτρου του τύπου';
$txt['badbehaviorlog_apply_filter'] = 'Εφαρμογή φίλτρου';
$txt['badbehaviorlog_applying_filter'] = 'Εφαρμόζεται το φίλτρο';
$txt['badbehaviorlog_filter_only_member'] = 'Εμφάνιση αρχείων καταγραφής μη αποδεκτής συμπεριφοράς μέλους';
$txt['badbehaviorlog_filter_only_ip'] = 'Εμφάνιση αρχείων μη αποδεκτής συμπεριφοράς για αυτή την IP';
$txt['badbehaviorlog_filter_only_session'] = 'Εμφάνιση αρχείων μη αποδεκτής συμπεριφοράς για αυτή την συνεδρία';
$txt['badbehaviorlog_filter_only_headers'] = 'Εμφάνιση αρχείων μη αποδεκτής συμπεριφοράς για αυτό το URL';
$txt['badbehaviorlog_filter_only_agent'] = 'Εμφανίζονται μόνο οι καταχωρήσεις με τον ίδιο εξυπηρετητή χρήστη';

$txt['badbehaviorlog_session'] = 'Συνεδρία';
$txt['badbehaviorlog_error_url'] = 'URL της σελίδας που καταγράφηκε';

$txt['badbehaviorlog_reverse_direction'] = 'Αντίστροφη χρονολογική σειρά της λίστας';
$txt['badbehaviorlog_filter_only_type'] = 'Προβολή αρχείων καταγραφής με αυτόν τον κωδικό';