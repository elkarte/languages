<?php
// Version: 1.1; LikePosts

global $txt;

// Like posts stats strings
$txt['like_posts_stats_desc'] = 'Στατιστικά σχετικά με τα περισσότερα likes σε μηνύματα και θέματα';
$txt['like_post_tab_mlm'] = 'Μηνύματα με τα περισσότερα likes';
$txt['like_post_tab_mlt'] = 'Θέματα με τα περισσότερα likes';
$txt['like_post_tab_mlb'] = 'Πίνακες με τα περισσότερα likes';
$txt['like_post_tab_mlmember'] = 'Μέλη με τα περισσότερα likes ';
$txt['like_post_tab_mlgmember'] = 'Μέλη που έχουν δώσει τα περισσότερα like';
$txt['like_post_generic_heading1'] = 'like(s)';
$txt['like_post_liked_by_others'] = 'Likes που ελήφθησαν';
$txt['like_post_show'] = 'Εμφάνιση';
$txt['like_post_hide'] = 'Απόκρυψη';

// For message
$txt['like_post_users_who_liked'] = 'σε%1% χρήστες αρέσει το μήνυμα';

// For topic
$txt['like_post_most_popular_topic_heading1'] = 'έχει λάβει συνολικά (%1%) like(s).';
$txt['like_post_most_popular_topic_sub_heading1'] = 'Το θέμα περιέχει (%1%) μηνύματα με likes. %2%ορισμένα από τα μηνύματα με like.';

// For board
$txt['like_post_most_popular_board_heading1'] = 'έχει ληφθεί';
$txt['like_post_most_popular_board_sub_heading1'] = 'Ο πίνακας περιέχει';
$txt['like_post_most_popular_board_sub_heading2'] = 'θέματα, από τα οποία';
$txt['like_post_most_popular_board_sub_heading3'] = 'θέματα που αρέσουν';
$txt['like_post_most_popular_board_sub_heading4'] = 'Τα θέματα περιέχουν';
$txt['like_post_most_popular_board_sub_heading5'] = 'διάφορα μηνύματα, εκ των οποίων';
$txt['like_post_most_popular_board_sub_heading6'] = 'μηνύματα που αρέσουν';

// Most liked user
$txt['like_post_total_likes_received'] = 'Σύνολο Likes που ελήφθησαν';
$txt['like_post_most_popular_user_heading1'] = '%1%φορές αυτός ο χρήστης άρεσε πολύ σε δημοσιεύσεις';

// Most like giving user
$txt['like_post_total_likes_given'] = 'Σύνολο Likes που έχουν δοθεί ';
$txt['like_post_most_like_given_user_heading1'] = '%1%άρεσαν σε δημοσιεύσεις';

// Like posts generic strings
$txt['like_post_topic'] = 'Θέμα';
$txt['like_post_message'] = 'Μήνυμα';
$txt['like_post_board'] = 'Πίνακας';
$txt['like_post_total_posts'] = 'Σύνολο μηνυμάτων';
$txt['like_post_posted_at'] = 'Δημοσιεύτηκε στις';
$txt['like_post_read_more'] = 'Διαβάστε περισσότερα ...';

// Error msgs
$txt['like_post_error_no_data'] = 'Λυπούμαστε, φαίνεται ότι δεν υπάρχει κάτι προς εμφάνιση!';
$txt['like_post_error_something_wrong'] = 'Λυπούμαστε, φαίνεται ότι υπάρχει πρόβλημα με την ανάκτηση των δεδομένων ...';
