<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Ημερομηνία';
$txt['modlog_member'] = 'Μέλος';
$txt['modlog_position'] = 'Αξίωμα';
$txt['modlog_action'] = 'Ενέργεια';
$txt['modlog_ip'] = 'IP';
$txt['modlog_search_result'] = 'Αποτελέσματα αναζήτησης';
$txt['modlog_total_entries'] = 'Σύνολο καταχωρήσεων';
$txt['modlog_ac_approve_topic'] = 'Έγκριση θέματος &quot;{topic}&quot; από &quot;{member}&quot;';
$txt['modlog_ac_unapprove_topic'] = 'Unapproved topic &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_approve'] = 'Έγκριση μηνύματος &quot;{subject}&quot; στο &quot;{topic}&quot; από &quot;{member}&quot;';
$txt['modlog_ac_unapprove'] = 'Unapproved message &quot;{subject}&quot; in &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_lock'] = 'Κλείδωμα &quot;{topic}&quot;';
$txt['modlog_ac_warning'] = 'Προειδοποιήθηκε το μέλος {member} για το μήνυμα &quot;{message}&quot;';
$txt['modlog_ac_unlock'] = 'Ξεκλείδωμα &quot;{topic}&quot;';
$txt['modlog_ac_sticky'] = 'Pinned &quot;{topic}&quot;';
$txt['modlog_ac_unsticky'] = 'Unpinned &quot;{topic}&quot;';
$txt['modlog_ac_delete'] = 'Διαγραφή &quot;{subject}&quot; από &quot;{member}&quot; από το &quot;{topic}&quot;';
$txt['modlog_ac_delete_member'] = 'Διαγραφή μέλους &quot;{name}&quot;';
$txt['modlog_ac_remove'] = 'Διαγραφή θέματος &quot;{topic}&quot; από &quot;{board}&quot;';
$txt['modlog_ac_modify'] = 'Τροποποίηση &quot;{message}&quot; από &quot;{member}&quot;';
$txt['modlog_ac_merge'] = 'Συγχώνευση θεμάτων και δημιουργία του &quot;{topic}&quot;';
$txt['modlog_ac_split'] = 'Διαχωρισμός &quot;{topic}&quot; και δημιουργία του &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = 'Μετακίνηση &quot;{topic}&quot; από &quot;{board_from}&quot; σε &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Τροποποίηση του προφίλ του &quot;{member}&quot;';
$txt['modlog_ac_pruned'] = 'Διαγραφή μηνυμάτων παλαιότερα από {days} ημέρες';
$txt['modlog_ac_news'] = 'Τροποποίηση των νέων';
$txt['modlog_enter_comment'] = 'Εισάγετε σχόλιο συντονισμού';
$txt['modlog_moderation_log'] = 'Αρχείο καταγραφής συντονισμού';
$txt['modlog_moderation_log_desc'] = 'Ακολουθεί μια λίστα όλων των συντονιστικών ενεργειών που έχουν πραγματοποιηθεί από συντονιστές του φόρουμ.<br /><strong>Σημείωση:</strong> Οι καταχωρήσεις δεν μπορούν να διαγραφούν από αυτό το αρχείο μέχρι να γίνουν τουλάχιστον εικοσιτεσσάρων ωρών.';
$txt['modlog_no_entries_found'] = 'Δεν υπάρχουν προς το παρόν εγγραφές στο αρχείο καταγραφής συντονισμού.';
$txt['modlog_remove'] = 'Διαγραφή επιλεγμένων';
$txt['modlog_removeall'] = 'Διαγραφή όλων';
$txt['modlog_remove_selected_confirm'] = 'Είστε βέβαιοι ότι θέλετε να διαγράψετε τις επιλεγμένες καταχωρίσεις;';
$txt['modlog_remove_all_confirm'] = 'Are you sure you want to completely clear the log?';
$txt['modlog_go'] = 'Ψάξε';
$txt['modlog_add'] = 'Προσθήκη';
$txt['modlog_search'] = 'Γρήγορη αναζήτηση';
$txt['modlog_by'] = 'Από';
$txt['modlog_id'] = '<em>(Αναγνωριστικό ID:%1$d)</em>';

$txt['modlog_ac_add_warn_template'] = 'Προσθήκη προτύπου προειδοποιήσεων: &quot;{template}&quot;';
$txt['modlog_ac_modify_warn_template'] = 'Τροποποίηση προτύπου προειδοποιήσεων: &quot;{template}&quot;';
$txt['modlog_ac_delete_warn_template'] = 'Διαγραφή προτύπου προειδοποιήσεων: &quot;{template}&quot;';

$txt['modlog_ac_ban'] = 'Προσθήκη εναυσμάτων αποκλεισμού:';
$txt['modlog_ac_ban_update'] = 'Edited ban triggers:';
$txt['modlog_ac_ban_remove'] = 'Removed ban triggers:';
$txt['modlog_ac_ban_trigger_member'] = ' <em>Μέλος:</em> {member}';
$txt['modlog_ac_ban_trigger_email'] = ' <em>Email:</em> {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = ' <em>IP:</em> {ip_range}';
$txt['modlog_ac_ban_trigger_hostname'] = ' <em>Όνομα διακομιστή:</em> {hostname}';

$txt['modlog_admin_log'] = 'Αρχείο καταγραφής διαχείρισης';
$txt['modlog_admin_log_desc'] = 'Ακολουθεί λίστα διαχειριστικών ενεργειών που έχουν καταγραφεί στο φόρουμ.<br /><strong>Σημείωση:</strong> Οι καταχωρήσεις δεν μπορούν να διαγραφούν από αυτό το αρχείο μέχρι να γίνουν τουλάχιστον εικοσιτεσσάρων ωρών.';
$txt['modlog_admin_log_no_entries_found'] = 'Δεν υπάρχουν προς το παρόν εγγραφές στο αρχείο καταγραφής διαχείρισης.';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Αναβάθμιση του φόρουμ στην έκδοση {version}';
$txt['modlog_ac_install'] = 'Εγκατεστημένη έκδοση {version}';
$txt['modlog_ac_add_board'] = 'Προσθήκη νέου πίνακα: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Τροποποίηση του πίνακα &quot;{board}&quot;';
$txt['modlog_ac_delete_board'] = 'Διαγραφή του πίνακα &quot;{boardname}&quot;';
$txt['modlog_ac_add_cat'] = 'Προσθήκη νέας κατηγορίας, &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Τροποποίηση της κατηγορίας &quot;{catname}&quot;';
$txt['modlog_ac_delete_cat'] = 'Διαγραφή της κατηγορίας &quot;{catname}&quot;';

$txt['modlog_ac_delete_group'] = 'Διαγραφή της ομάδας &quot;{group}&quot;';
$txt['modlog_ac_add_group'] = 'Προσθήκη της ομάδας &quot;{group}&quot;';
$txt['modlog_ac_edited_group'] = 'Τροποποίηση της ομάδας &quot;{group}&quot;';
$txt['modlog_ac_added_to_group'] = 'Ένταξη του μέλους &quot;{member}&quot; στην ομάδα &quot;{group}&quot;';
$txt['modlog_ac_removed_from_group'] = 'Αφαίρεση του μέλους &quot;{member}&quot; από την ομάδα &quot;{group}&quot;';
$txt['modlog_ac_removed_all_groups'] = 'Αφαίρεση του μέλους &quot;{member}&quot; από όλες τις ομάδες';

$txt['modlog_ac_remind_member'] = 'Αποστολή υπενθύμισης στο μέλος &quot;{member}&quot; για ενεργοποίηση του λογαριασμού του';
$txt['modlog_ac_approve_member'] = 'Έγκριση/ενεργοποίηση του λογαριασμού του μέλους &quot;{member}&quot;';
$txt['modlog_ac_newsletter'] = 'Αποστολή ενημερωτικού δελτίου';

$txt['modlog_ac_install_package'] = 'Εγκαταστάθηκε νέο πακέτο: &quot;{package}&quot;, έκδοση {version} ';
$txt['modlog_ac_upgrade_package'] = 'Αναβαθμίστηκε το πακέτο: &quot;{package}&quot; στην έκδοση {version} ';
$txt['modlog_ac_uninstall_package'] = 'Απεγκαταστάθηκε το πακέτο: &quot;{package}&quot;, έκδοση {version} ';

$txt['modlog_ac_database_backup'] = 'Database backup taken by {member}.';
$txt['modlog_ac_editing_theme'] = '{member} edited a theme.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Επαναφορά θέματος &quot;{topic}&quot; από &quot;{board}&quot; σε &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Επαναφορά μηνυμάτων από &quot;{subject}&quot; στο θέμα &quot;{topic}&quot; στον πίνακα &quot;{board}&quot;.';

$txt['modlog_parameter_guest'] = '<em>Επισκέπτης</em>';

$txt['modlog_ac_approve_attach'] = 'Approved &quot;{filename}&quot; in &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Removed unapproved &quot;{filename}&quot; in &quot;{message}&quot;';