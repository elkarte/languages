<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Λίστα προσωπικών μηνυμάτων';
$txt['pm_add'] = 'Προσθήκη';
$txt['make_bcc'] = 'Προσθήκη κρυφής κοινοποίησης';
$txt['pm_to'] = 'Προς';
$txt['pm_bcc'] = 'Αντίγραφο';
$txt['inbox'] = 'Εισερχόμενα';
$txt['conversation'] = 'Συνομιλία';
$txt['messages'] = 'Μηνύματα';
$txt['sent_items'] = 'Απεσταλμένα';
$txt['new_message'] = 'Νέο μήνυμα';
$txt['delete_message'] = 'Διαγραφή μηνυμάτων';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Διαγραφή όλων των μηνυμάτων στο PMBOX';
$txt['delete_all_confirm'] = 'Είστε βεβαιος ότι θέλετε να διαγράψετε όλα τα μηνύματα;';

$txt['delete_selected_confirm'] = 'Είστε βέβαιος ότι θέλετε να διαγράψετε όλα τα επιλεγμένα προσωπικά μηνύματα;';

$txt['sent_to'] = 'Εστάλη στον/στην';
$txt['reply_to_all'] = 'Απάντηση σε όλους';
$txt['delete_conversation'] = 'Διαγραφή συνομιλίας';

$txt['pm_capacity'] = 'Χωρητικότητα';
$txt['pm_currently_using'] = '%1$s μηνύματα, %2$s%% γεμάτο.';
$txt['pm_sent'] = 'Το μήνυμα στάλθηκε επιτυχώς.';

$txt['pm_error_user_not_found'] = 'Το μέλος \'%1$s\' δεν βρέθηκε.';
$txt['pm_error_ignored_by_user'] = 'Το μέλος \'%1$s\' έχει απαγορεύσει τη λήψη προσωπικών μηνυμάτων από εσάς.';
$txt['pm_error_data_limit_reached'] = 'PM could not be sent to \'%1$s\' as their inbox is full.';
$txt['pm_error_user_cannot_read'] = 'Το μέλος \'%1$s\' δεν μπορεί να λάβει προσωπικά μηνύματα.';
$txt['pm_successfully_sent'] = 'Το προσωπικό μήνυμα εστάλη επιτυχώς στο μέλος \'%1$s\'.';
$txt['pm_send_report'] = 'Αποστολή αναφοράς';
$txt['pm_undisclosed_recipients'] = 'Μη ορατοί παραλήπτες';
$txt['pm_too_many_recipients'] = 'Δεν μπορείτε να στείλετε προσωπικά μηνύματα σε παραπάνω από %1$d παραλήπτες κάθε φορά.';

$txt['pm_read'] = 'Αναγνώστηκε';
$txt['pm_replied'] = 'Έχει απαντηθεί';
$txt['pm_mark_unread'] = 'Mark as Unread';

// Message Pruning.
$txt['pm_prune'] = 'Prune messages';
$txt['pm_prune_desc'] = 'Delete all personal messages older than %1$s days.';
$txt['pm_prune_warning'] = 'Είστε βέβαιος ότι θέλετε να διαγράψετε τα προσωπικά σας μηνύματα;';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Further actions';
$txt['pm_actions_delete_selected'] = 'Διαγραφή επιλεγμένων';
$txt['pm_actions_filter_by_label'] = 'Filter by label';
$txt['pm_actions_go'] = 'Ψάξε';

// Manage Labels Screen.
$txt['pm_apply'] = 'Εφαρμογή';
$txt['pm_manage_labels'] = 'Manage labels';
$txt['pm_labels_delete'] = 'Είστε βέβαιος ότι θέλετε να διαγράψετε τις επιλεγμένες ετικέτες;';
$txt['pm_labels_desc'] = 'Εδώ μπορείτε να προσθέσετε, να τροποποιήσετε και να διαγράψετε ετικέτες που χρησιμοποιούνται στο κέντρο προσωπικών μηνυμάτων σας.';
$txt['pm_label_add_new'] = 'Add new label';
$txt['pm_label_name'] = 'Label name';
$txt['pm_labels_no_exist'] = 'Προς το παρόν δεν έχετε καμμία ετικέτα!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Ετικέτα';
$txt['pm_msg_label_title'] = 'Label message';
$txt['pm_msg_label_apply'] = 'Add label';
$txt['pm_msg_label_remove'] = 'Remove label';
$txt['pm_msg_label_inbox'] = 'Εισερχόμενα';
$txt['pm_sel_label_title'] = 'Label selected';

// Sidebar Headings.
$txt['pm_labels'] = 'Ετικέτες';
$txt['pm_messages'] = 'Μηνύματα';
$txt['pm_actions'] = 'Ενέργειες';
$txt['pm_preferences'] = 'Προτιμήσεις';

$txt['pm_is_replied_to'] = 'Έχετε προωθήσει ή απαντήσει σε αυτό το μήνυμα.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Report to admin';
$txt['pm_report_title'] = 'Report personal message';
$txt['pm_report_desc'] = 'Από αυτήν τη σελίδα μπορείτε να αναφέρετε το προσωπικό μήνυμα που λάβατε στην ομάδα Διαχειριστών. Παρακαλούμε, σιγουρευτείτε ότι περιλαμβάνει μια περιγραφή για το λόγο που θέλετε να αναφέρετε αυτό το μήνυμα, καθώς αυτή θα αποσταλεί μαζί με το περιεχόμενο του εν λόγω μηνύματος.';
$txt['pm_report_admins'] = 'Διαχειριστής στον οποίο θα σταλεί η αναφορά';
$txt['pm_report_all_admins'] = 'Αποστολή σε όλους τους Διαχειριστές';
$txt['pm_report_reason'] = 'Ο λόγος που αναφέρετε αυτό το μήνυμα';
$txt['pm_report_message'] = 'Αναφορά μηνύματος';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[ΑΝΑΦΟΡΑ] ';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = 'Ο/η {REPORTER} έχει αναφέρει το παρακάτω προσωπικό μήνυμα, με αποστολέα τον/την {SENDER}, για τον ακόλουθο λόγο:';
$txt['pm_report_pm_other_recipients'] = 'Οι υπόλοιποι παραλήπτες του μηνύματος είναι:';
$txt['pm_report_pm_hidden'] = '%1$d μη ορατοί παραλήπτες';
$txt['pm_report_pm_unedited_below'] = 'Ακολουθεί το αρχικό περιεχόμενο του αναφερόμενου προσωπικού μηνύματος:';
$txt['pm_report_pm_sent'] = 'Εστάλη στις:';

$txt['pm_report_done'] = 'Ευχαριστούμε για την υποβολή αυτής της αναφοράς. Θα έχετε νέα από την ομάδα διαχειριστών σύντομα.';
$txt['pm_report_return'] = 'Επιστροφή στα εισερχόμενα';

$txt['pm_search_title'] = 'Search personal messages';
$txt['pm_search_bar_title'] = 'Search messages';
$txt['pm_search_text'] = 'Αναζήτηση για';
$txt['pm_search_go'] = 'Αναζήτηση';
$txt['pm_search_advanced'] = 'Εμφάνιση επιλογών για προχωρημένους';
$txt['pm_search_simple'] = 'Απόκρυψη επιλογών για προχωρημένους';
$txt['pm_search_user'] = 'Από χρήστη';
$txt['pm_search_match_all'] = 'Ταίριασμα όλων των λέξεων';
$txt['pm_search_match_any'] = 'Ταίριασμα οποιωνδήποτε λέξεων';
$txt['pm_search_options'] = 'Επιλογές';
$txt['pm_search_post_age'] = 'Ηλικία μηνύματος';
$txt['pm_search_show_complete'] = 'Εμφάνιση πλήρους μηνύματος στα αποτελέσματα.';
$txt['pm_search_subject_only'] = 'Αναζήτηση με βάση τον τίτλο και τον αποστολέα μόνο.';
$txt['pm_search_sent_only'] = 'Search only in sent items.';
$txt['pm_search_between'] = 'μεταξύ';
$txt['pm_search_between_and'] = 'και';
$txt['pm_search_between_days'] = 'ημέρες';
$txt['pm_search_order'] = 'Ταξινόμηση αποτελεσμάτων';
$txt['pm_search_choose_label'] = 'Επιλέξτε ετικέτες για την αναζήτηση, ή αναζητήστε σε όλα';

$txt['pm_search_results'] = 'Search results';
$txt['pm_search_none_found'] = 'No messages found';

$txt['pm_search_orderby_relevant_first'] = 'Πρώτα τα πιο σχετικά ';
$txt['pm_search_orderby_recent_first'] = 'Πρώτα τα πιο πρόσφατα';
$txt['pm_search_orderby_old_first'] = 'Πρώτα τα πιο παλιά';

$txt['pm_visual_verification_label'] = 'Επαλήθευση';
$txt['pm_visual_verification_desc'] = 'Please enter the code in the image above in order to send this PM.';

$txt['pm_settings'] = 'Change settings';
$txt['pm_change_view'] = 'Change view';

$txt['pm_manage_rules'] = 'Manage rules';
$txt['pm_manage_rules_desc'] = 'Τα φίλτρα μηνυμάτων σας επιτρέπουν να ταξινομήσετε αυτόματα τα εισερχόμενα μηνύματα ανάλογα με τα κριτήρια που ορίζετε. Παρακάτω βλέπετε όλα τα φίλτρα που έχετε ορίσει. Για να τροποποιήσετε ένα φίλτρο απλά πατήστε πάνω στο όνομα του.';
$txt['pm_rules_none'] = 'Δεν έχετε ακόμη ορίσει φίλτρα μηνυμάτων.';
$txt['pm_rule_title'] = 'Φίλτρο';
$txt['pm_add_rule'] = 'Add new rule';
$txt['pm_apply_rules'] = 'Apply rules now';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Σίγουρα θέλετε να εφαρμόσετε τα τρέχοντα φίλτρα σε όλα τα προσωπικά μηνύματα σας;';
$txt['pm_edit_rule'] = 'Edit rule';
$txt['pm_rule_save'] = 'Save rule';
$txt['pm_delete_selected_rule'] = 'Delete selected rules';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Σίγουρα θέλετε να διαγράψετε τα επιλεγμένα φίλτρα';
$txt['pm_rule_name'] = 'Όνομα';
$txt['pm_rule_name_desc'] = 'Όνομα με το οποίο θα αναφέρεστε σε αυτό το φίλτρο';
$txt['pm_rule_name_default'] = '[ΟΝΟΜΑ]';
$txt['pm_rule_description'] = 'Περιγραφή';
$txt['pm_rule_not_defined'] = 'Προσθέστε κριτήρια για να αρχίσετε να δημιουργείτε την περιγραφή αυτού του φίλτρου.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>Σημείωση:</strong> Φαίνεται ότι έχετε απενεργοποιήσει την javascript. Συνιστούμε να ενεργοποιήσετε την javascript για να χρησιμοποιήσετε αυτήν την δυνατότητα.';
$txt['pm_rule_criteria'] = 'Κριτήρια';
$txt['pm_rule_criteria_add'] = 'Add criteria';
$txt['pm_rule_criteria_pick'] = 'Choose criteria';
$txt['pm_rule_mid'] = 'Sender name';
$txt['pm_rule_gid'] = 'Sender\'s group';
$txt['pm_rule_sub'] = 'Message subject contains';
$txt['pm_rule_msg'] = 'Message body contains';
$txt['pm_rule_bud'] = 'Sender is buddy';
$txt['pm_rule_sel_group'] = 'Select group';
$txt['pm_rule_logic'] = 'When checking criteria';
$txt['pm_rule_logic_and'] = 'Όλα τα κριτήρια πρέπει να πληρούνται';
$txt['pm_rule_logic_or'] = 'Οποιαδήποτε από τα κριτήρια μπορούν να πληρούνται';
$txt['pm_rule_actions'] = 'Ενέργειες';
$txt['pm_rule_sel_action'] = 'Select an action';
$txt['pm_rule_add_action'] = 'Add action';
$txt['pm_rule_label'] = 'Ετικέτα στο μήνυμα';
$txt['pm_rule_sel_label'] = 'Select label';
$txt['pm_rule_delete'] = 'Delete message';
$txt['pm_rule_no_name'] = 'Ξεχάσατε να δώσετε ένα όνομα στο φίλτρο.';
$txt['pm_rule_no_criteria'] = 'Ένα φίλτρο πρέπει να έχει τουλάχιστον ένα κριτήριο και μία ενέργεια.';
$txt['pm_rule_too_complex'] = 'The rule you are creating is too long to save. Try breaking it up into smaller rules.';

$txt['pm_readable_and'] = '<em>και</em>';
$txt['pm_readable_or'] = '<em>ή</em>';
$txt['pm_readable_start'] = 'Αν ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'μήνυμα είναι από &quot;{MEMBER}&quot;';
$txt['pm_readable_group'] = 'αποστολέας είναι από την ομάδα &quot;{GROUP}&quot;';
$txt['pm_readable_subject'] = 'τίτλος μηνύματος περιέχει &quot;{SUBJECT}&quot;';
$txt['pm_readable_body'] = 'σώμα μηνύματος περιέχει &quot;{BODY}&quot;';
$txt['pm_readable_buddy'] = 'αποστολέας είναι στη λίστα φίλων';
$txt['pm_readable_label'] = 'βάλε ετικέτα &quot;{LABEL}&quot;';
$txt['pm_readable_delete'] = 'διέγραψε το μήνυμα';
$txt['pm_readable_then'] = '<strong>τότε</strong>';