<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'The default ElkArte theme.<br /><br />Author: ElkArte contributors';