<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Das Standard-ElkArte-Theme.<br /><br />Autoren: ElkArte-Mitwirkende';