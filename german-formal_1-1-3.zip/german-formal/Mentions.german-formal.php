<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Meine Benachrichtigungen';
$txt['my_unread_mentions'] = 'Meine ungelesenen Benachrichtungen';
$txt['my_mentions_pages'] = 'Seite %1$d';
$txt['no_mentions_yet'] = 'Keine Erwähnungen';
$txt['no_new_mentions'] = 'Keine neuen Erwähnungen';

$txt['mentions_from'] = 'Mitglied';
$txt['mentions_when'] = 'Wann';
$txt['mentions_what'] = 'Text';
$txt['mentions_all'] = 'Alle anzeigen';
$txt['mentions_unread'] = 'Ungelesene anzeigen';
$txt['mentions_action'] = 'Aktionen';
$txt['mentions_delete_warning'] = 'Bist du sicher, dass du diesen Eintrag löschen möchtest?';
$txt['mentions_markread'] = 'Als gelesen markieren';
$txt['mentions_markunread'] = 'Als ungelesen markieren';

$txt['mentions_settings'] = 'Notifications Settings';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = 'Enable site notifications';
$txt['mentions_buddy'] = 'Mitglieder benachrichtigen, die zu Freundeslisten hinzugefügt werden';
$txt['mentions_dont_notify_rlike'] = 'Mitglied nicht informieren, wenn ein Beitrag nicht mehr gefällt';

$txt['mention_mentionmem'] = 'Hat Sie in der Nachricht {msg_link} erwähnt';
$txt['mention_likemsg'] = 'Gefällt Ihre Nachricht {msg_link}';
$txt['mention_rlikemsg'] = 'Gefällt Ihre Nachricht {msg_link} nicht mehr';
$txt['mention_buddy'] = 'Hat Sie zu seiner Freundesliste hinzugefügt.';
$txt['mention_quotedmem'] = 'Quoted a message of yours in {msg_link}';
$txt['mention_mailfail'] = 'Disabled email notification due to delivery failure';

$txt['mentions_type_all'] = 'Alle Erwähnungen';
$txt['mentions_type_mentionmem'] = 'Erwähnungen';
$txt['mentions_type_likemsg'] = 'gefällt\'s';
$txt['mentions_type_rlikemsg'] = 'Gefällt mir nicht mehr';
$txt['mentions_type_buddy'] = 'Freund';
$txt['mentions_type_quotedmem'] = 'Quoted';
$txt['mentions_type_mailfail'] = 'Delivery Failure';

$txt['mentions_mark_all_read'] = 'Diese Erwähnungen als gelesen markieren';

$txt['setting_notify_enable_this'] = 'Enable user notifications of this event.';

$txt['setting_buddy'] = 'Freunde';
$txt['setting_likemsg'] = 'gefällt\'s';
$txt['setting_rlikemsg'] = 'Removed likes';
$txt['setting_mentionmem'] = '@mentions';
$txt['setting_quotedmem'] = 'Zitiere';
$txt['setting_mailfail'] = 'Delivery Failures';