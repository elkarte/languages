<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Geplande taken';
$txt['scheduled_tasks_header'] = 'Alle geplande taken';
$txt['scheduled_tasks_name'] = 'Naam van de taak';
$txt['scheduled_tasks_next_time'] = 'Gepland voor';
$txt['scheduled_tasks_regularity'] = 'Periode';
$txt['scheduled_tasks_enabled'] = 'Ingeschakeld';
$txt['scheduled_tasks_run_now'] = 'Voer nu uit';
$txt['scheduled_tasks_save_changes'] = 'Opslaan';
$txt['scheduled_tasks_time_offset'] = '<strong>Note:</strong> All times given below are <em>server time</em> and do not take any time offsets setup within the admin panel into account.';
$txt['scheduled_tasks_were_run'] = 'Alle geselecteerde taken zijn uitgevoerd.';
$txt['scheduled_tasks_were_run_errors'] = 'The following errors occurred while running the scheduled tasks:';

$txt['scheduled_tasks_na'] = 'Niet aanwezig';
$txt['scheduled_task_approval_notification'] = 'Goedkeuringsnotificaties';
$txt['scheduled_task_desc_approval_notification'] = 'Verstuurt e-mails naar alle moderators met een overzicht van berichten die op goedkeuring wachten.';
$txt['scheduled_task_auto_optimize'] = 'Optimaliseer database';
$txt['scheduled_task_desc_auto_optimize'] = 'Optimaliseert de database om databasefragmentatie te beperken.';
$txt['scheduled_task_daily_maintenance'] = 'Dagelijks onderhoud';
$txt['scheduled_task_desc_daily_maintenance'] = 'Voert essentieel dagelijks onderhoud uit op het forum - zou niet uitgeschakeld moeten worden.';
$txt['scheduled_task_daily_digest'] = 'Dagelijks notificatieoverzicht';
$txt['scheduled_task_desc_daily_digest'] = 'Verstuurt het dagelijkse notificatieoverzicht naar mensen die zich daarop geabonneerd hebben.';
$txt['scheduled_task_weekly_digest'] = 'Wekelijks notificatieoverzicht';
$txt['scheduled_task_desc_weekly_digest'] = 'Verstuurt het wekelijkse notificatieoverzicht naar mensen die zich daarop geabonneerd hebben.';
$txt['scheduled_task_birthdayemails'] = 'Verstuur verjaardagse-mails';
$txt['scheduled_task_desc_birthdayemails'] = 'Verstuurt e-mails met felicitaties aan de jarigen.';
$txt['scheduled_task_weekly_maintenance'] = 'Wekelijks onderhoud';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Voert essentieel wekelijks onderhoud uit op het forum - zou niet uitgeschakeld moeten worden.';
$txt['scheduled_task_paid_subscriptions'] = 'Controles van betaalde abonnementen';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Verstuurt nodige herinneringen aangaande betaalde abonnementen en verwijdert verlopen lidmaatschappen.';
$txt['scheduled_task_remove_topic_redirect'] = 'Remove MOVED: Redirection Topics';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Deletes "MOVED:" topic notifications as specified when the moved notice was created.';
$txt['scheduled_task_remove_temp_attachments'] = 'Remove Temporary Attachment Files';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Deletes temporary files created while attaching a file to a post that for any reason weren\'t renamed or deleted before.';
$txt['scheduled_task_remove_old_drafts'] = 'Remove Old Drafts';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Deletes drafts older than the number of days defined in the draft settings in the admin panel.';
$txt['scheduled_task_remove_old_followups'] = 'Remove Old Follow-ups';
$txt['scheduled_task_desc_remove_old_followups'] = 'Deletes follow-up entries still present in the database, but pointing to non-existent topics.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Fetch Emails from IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Fetches emails for the mailing list feature from an IMAP box and processes them.';
$txt['scheduled_task_user_access_mentions'] = 'Users Mentions Access';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verify users access to each board and set accessibility to related mentions accordingly.';

$txt['scheduled_task_reg_starting'] = 'Beginnend op %1$s';
$txt['scheduled_task_reg_repeating'] = 'zich herhalend elke %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minu(u)t(en)';
$txt['scheduled_task_reg_unit_h'] = 'u(u)r(en)';
$txt['scheduled_task_reg_unit_d'] = 'dag(en)';
$txt['scheduled_task_reg_unit_w'] = 'we(e)k(en)';

$txt['scheduled_task_edit'] = 'Bewerk geplande taak';
$txt['scheduled_task_edit_repeat'] = 'Herhaal taak elke';
$txt['scheduled_task_edit_pick_unit'] = 'Kies eenheid';
$txt['scheduled_task_edit_interval'] = 'Interval';
$txt['scheduled_task_edit_start_time'] = 'Starttijd';
$txt['scheduled_task_edit_start_time_desc'] = 'Tijdstip waarop de taak het eerst uitgevoerd moet worden (uren:minuten)';
$txt['scheduled_task_time_offset'] = 'Merk op dat de starttijd ten opzichte van de servertijd gegeven moet worden. De huidige servertijd is: %1$s';

$txt['scheduled_view_log'] = 'Bekijk log';
$txt['scheduled_log_empty'] = 'Er zijn momenteel geen ingangen in het takenlog.';
$txt['scheduled_log_time_run'] = 'Uitgevoerd op';
$txt['scheduled_log_time_taken'] = 'Tijd benodigd';
$txt['scheduled_log_time_taken_seconds'] = '%1$d seconden';
$txt['scheduled_log_completed'] = 'Task completed';
$txt['scheduled_log_empty_log'] = 'Clear Log';
$txt['scheduled_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log?';