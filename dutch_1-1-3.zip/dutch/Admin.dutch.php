<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Boards';
$txt['admin_back_to'] = 'Back to admin panel';
$txt['admin_users'] = 'Leden';
$txt['admin_newsletters'] = 'Nieuwsbrieven';
$txt['include_these'] = 'Members to include';
$txt['exclude_these'] = 'Members to exclude';
$txt['admin_newsletters_select_groups'] = 'Groups to include';
$txt['admin_newsletters_exclude_groups'] = 'Groups to exclude';
$txt['admin_edit_news'] = 'Nieuws';
$txt['admin_groups'] = 'Member groups';
$txt['admin_members'] = 'Beheer leden';
$txt['admin_members_list'] = 'Hieronder staat een lijst van alle leden die momenteel geregistreerd zijn op je forum.';
$txt['admin_next'] = 'Volgende';
$txt['admin_censored_words'] = 'Gecensureerde woorden';
$txt['admin_censored_where'] = 'Enter the word to be censored into the left box and the word to change it to, into the right box. Then select if you want to check the whole word and the case. When you\'re finished with each word, click Save. Multiple entries can be made prior to saving by clicking the \'Add another word\' button.';
$txt['admin_censored_desc'] = 'Due to the public nature of forums there may be some words that you wish to prohibit being posted by users of your forum. You can enter any words below that you wish to be censored whenever used by a member.<br />Clear a box to remove that word from the censor.';
$txt['admin_reserved_names'] = 'Gereserveerde namen';
$txt['admin_template_edit'] = 'Edit your forum template';
$txt['admin_modifications'] = 'Add-on Settings';
$txt['admin_security_moderation'] = 'Beveiliging en moderatie';
$txt['admin_server_settings'] = 'Serverinstellingen';
$txt['admin_reserved_set'] = 'Set reserved names';
$txt['admin_reserved_line'] = 'E&eacute;n gereserveerd woord per regel.';
$txt['admin_basic_settings'] = 'Op deze pagina kun je de basisinstellingen van het forum veranderen. Wees erg voorzichtig hiermee, want een kleine fout kan ervoor zorgen dat het forum stopt met functioneren.';
$txt['admin_maintain'] = 'Onderhoudsmodus ingeschakeld';
$txt['admin_title'] = 'Forumnaam';
$txt['admin_url'] = 'URL naar het forum';
$txt['cookie_name'] = 'Cookie name';
$txt['admin_webmaster_email'] = 'Webmaster email address';
$txt['boarddir'] = 'ElkArte Directory';
$txt['sourcesdir'] = 'Sources-directory';
$txt['cachedir'] = 'Cachemap';
$txt['admin_news'] = 'Gebruik nieuws';
$txt['admin_guest_post'] = 'Enable guest posting';
$txt['admin_manage_members'] = 'Leden';
$txt['admin_main'] = 'SMF';
$txt['admin_config'] = 'Configuratie';
$txt['admin_version_check'] = 'Detailed version check';
$txt['admin_elkfile'] = 'ElkArte File';
$txt['admin_elkpackage'] = 'ElkArte Package';
$txt['admin_logoff'] = 'End Admin Session';
$txt['admin_maintenance'] = 'Onderhoud';
$txt['admin_image_text'] = 'Toon knoppen als plaatjes in plaats van tekst';
$txt['admin_credits'] = 'Credits';
$txt['admin_agreement'] = 'Laat de forumregels zien wanneer iemand zich registreert';
$txt['admin_checkbox_agreement'] = 'Show a checkbox for the agreement in registration form instead of a full page';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Standaard';
$txt['admin_agreement_select_language'] = 'Te bewerken taal';
$txt['admin_agreement_select_language_change'] = 'Verander';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Verwijder de geselecteerde leden';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Repair All boards and topics';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Please place one news item per box. BBC tags, such as <span>[b]</span>, <span>[i]</span> and <span>[u]</span> are allowed in your news, as well as smileys. Clear a news item\'s text box to remove it.';
$txt['administrators'] = 'Forumbeheerders';
$txt['admin_reserved_desc'] = 'Reserved names will keep members from registering certain user names or using these words in their displayed names. Choose the options you wish to use from the bottom before submitting.';
$txt['admin_activation_email'] = 'Stuur een activeringsmail naar nieuwe leden bij registratie';
$txt['admin_match_whole'] = 'Dit geldt alleen voor hele namen. Indien niet aangevinkt zal er naar overeenkomst worden gezocht binnen de naam.';
$txt['admin_match_case'] = 'Hoofdlettergevoelig. Indien niet aangevinkt zijn de resultaten ongevoelig voor hoofdletters.';
$txt['admin_check_user'] = 'Check user name.';
$txt['admin_check_display'] = 'Controleer getoonde naam.';
$txt['admin_newsletter_send'] = 'You can email anyone from this page. The email addresses of the selected member groups should appear below, but you may remove or add any email addresses you wish. Be sure that each address is separated in this fashion: \'address1; address2\'.';
$txt['admin_fader_delay'] = 'Overgangsduur tussen items voor de nieuwsfader';
$txt['zero_for_no_limit'] = '(0 voor geen limiet)';
$txt['zero_to_disable'] = '(0 to disable)';

$txt['admin_backup_fail'] = 'Het maken van een backup van Settings.php is mislukt - controleer of Settings_bak.php bestaat en schrijfbaar is.';
$txt['modSettings_info'] = 'Settings for General features, Karma, Signatures, Likes and much more that control how this forum operates.';
$txt['database_server'] = 'Databaseserver';
$txt['database_user'] = 'Database User';
$txt['database_password'] = 'Databasewachtwoord';
$txt['database_name'] = 'Databasenaam';
$txt['registration_agreement'] = 'Registratieovereenkomst';
$txt['registration_agreement_desc'] = 'Deze overeenkomst wordt getoond wanneer een gebruiker zich registreert op het forum en moet geaccepteerd worden voordat de gebruiker verder kan met de registratie.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Databasetabelvoorvoegsel';
$txt['errors_list'] = 'Lijst van foutmeldingen';
$txt['errors_found'] = 'De volgende foutmeldingen zijn ontstaan (leeg bij geen fouten)';
$txt['errors_fix'] = 'Wil je proberen deze fouten te herstellen?';
$txt['errors_do_recount'] = 'All errors have been fixed and a salvage area has been created. Please click the button below to recount some key statistics.';
$txt['errors_recount_now'] = 'Statistieken hertellen';
$txt['errors_fixing'] = 'Bezig fouten te herstellen';
$txt['errors_fixed'] = 'All errors fixed. Please check on any categories, boards, or topics created to decide what to do with them.';
$txt['attachments_avatars'] = 'Bijlagen en avatars';
$txt['attachments_desc'] = 'Van hieruit kun je alle bijgevoegde bestanden beheren. Je kunt bestanden verwijderen op formaat of datum. Gegevens over de bijgevoegde bestanden worden hieronder ook weergegeven.';
$txt['attachment_stats'] = 'File attachment statistics';
$txt['attachment_integrity_check'] = 'Attachment integrity check';
$txt['attachment_integrity_check_desc'] = 'Deze functie zal de integriteit en groottes van de bestanden die in de database staan controleren en, indien nodig, de fouten corrigeren.';
$txt['attachment_check_now'] = 'Voer controle nu uit';
$txt['attachment_pruning'] = 'Bijlagen opruimen';
$txt['attachment_pruning_message'] = 'Aan bericht toe te voegen bericht';
$txt['attachment_pruning_warning'] = 'Weet je zeker dat je deze bijlagen wilt verwijderen?\\nDit kan niet ongedaan gemaakt worden!';

$txt['attachment_total'] = 'Total attachments';
$txt['attachmentdir_size'] = 'Total size of all attachment directories';
$txt['attachmentdir_size_current'] = 'Total size of current attachment directory';
$txt['attachmentdir_files_current'] = 'Total files in current attachment directory';
$txt['attachment_space'] = 'Total space available';
$txt['attachment_files'] = 'Total files remaining';

$txt['attachment_options'] = 'Opties';
$txt['attachment_log'] = 'Logbestand';
$txt['attachment_remove_old'] = 'Remove attachments older than %1$s days';
$txt['attachment_remove_size'] = 'Remove attachments larger than %1$s KiB';
$txt['attachment_name'] = 'Attachment name';
$txt['attachment_file_size'] = 'Grootte';
$txt['attachmentdir_size_not_set'] = 'Er is momenteel geen maximumgrootte opgegeven voor de map';
$txt['attachmentdir_files_not_set'] = 'No directory file limit is currently set';
$txt['attachment_delete_admin'] = '[verwijderd door de beheerder]';
$txt['live'] = 'Latest Software Updates';
$txt['remove_all'] = 'Clear Log';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(meer details)';

$txt['lfyi'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['manage_calendar'] = 'Kalender';
$txt['manage_search'] = 'Zoekfunctie';
$txt['viewmembers_online'] = 'Laatst online';

$txt['smileys_manage'] = 'Smileys en berichticonen';
$txt['smileys_manage_info'] = 'Install new smiley sets, add smileys to existing sets or manage your message icons.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Install, download and upload Modification packages; check File Permissions and FTP settings.';
$txt['theme_admin'] = 'Theme Management';
$txt['theme_admin_info'] = 'Install new themes, select themes that are available for your users and set or reset theme options.';
$txt['registration_center'] = 'Registratie';
$txt['member_center_info'] = 'View the member list, search for members, or manage account approvals and activations.';
$txt['viewmembers_online'] = 'Laatst online';

$txt['display_name'] = 'Getoonde naam';
$txt['email_address'] = 'E-mailadres';
$txt['ip_address'] = 'IP-adres';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'onbekend';
$txt['security_wrong'] = 'Administration login attempt!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Stuur in HTML-formaat (hiermee kun je HTML in de e-mail gebruiken).';
$txt['email_parsed_html'] = 'Voeg &lt;br /&gt;s en &amp;nbsp;s toe aan dit bericht.';
$txt['email_variables'] = 'In this message you can use a few &quot;variables&quot;.<a href="{help_emailmembers}" class="help"> Click here for more information</a>.';
$txt['email_force'] = 'Stuur dit ook aan leden die ervoor gekozen hebben geen aankondigingen te ontvangen.';
$txt['email_as_pms'] = 'Stuur dit aan deze groepen door middel van persoonlijke berichten.';
$txt['email_continue'] = 'Doorgaan';
$txt['email_done'] = 'Klaar.';
$txt['email_members_succeeded'] = 'You have successfully sent your newsletter!';

$txt['ban_title'] = 'Banlijst';
$txt['ban_ip'] = 'IP-ban: (bijv. 192.168.12.213 of 128.0.*.*) - &eacute;&eacute;n per regel';
$txt['ban_email'] = 'E-mailban: (bijv. ikwileenban@example.com) - &eacute;&eacute;n e-mailadres per regel';
$txt['ban_username'] = 'Gebruikersnaamban: (bijv. super_gebruiker123) - &eacute;&eacute;n naam per regel';

$txt['ban_errors_detected'] = 'The following error or errors occurred while saving or editing the ban or the trigger';
$txt['ban_description'] = 'Here you can ban troublesome people either by IP, hostname, user name, or email.';
$txt['ban_add_new'] = 'Add new ban';
$txt['ban_banned_entity'] = 'Te verbannen entiteit';
$txt['ban_on_ip'] = 'Ban op basis van IP (bijv. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Ban op basis van hostnaam (e.g. *.mil)';
$txt['ban_on_email'] = 'Ban op basis van e-mail (e.g. *@badsite.com)';
$txt['ban_on_username'] = 'Ban on User Name';
$txt['ban_notes'] = 'Opmerkingen';
$txt['ban_restriction'] = 'Beperking';
$txt['ban_full_ban'] = 'Volledige ban';
$txt['ban_partial_ban'] = 'Gedeeltelijke ban';
$txt['ban_cannot_post'] = 'Kan&nbsp;niet&nbsp;posten';
$txt['ban_cannot_register'] = 'Kan&nbsp;niet&nbsp;registreren';
$txt['ban_cannot_login'] = 'Kan niet inloggen';
$txt['ban_add'] = 'Voeg toe';
$txt['ban_edit_list'] = 'Banlijst';
$txt['ban_type'] = 'Bantype';
$txt['ban_days'] = 'dag(en)';
$txt['ban_will_expire_within'] = 'Ban loopt af na';
$txt['ban_added'] = 'Toegevoegd';
$txt['ban_expires'] = 'Aflooptijd';
$txt['ban_hits'] = 'Hits';
$txt['ban_actions'] = 'Acties';
$txt['ban_expiration'] = 'Aflooptijd';
$txt['ban_reason_desc'] = 'De reden voor de ban, zoals getoond wordt aan het verbannen lid.';
$txt['ban_notes_desc'] = 'Opmerkingen bedoeld voor andere teamleden.';
$txt['ban_remove_selected'] = 'Verwijder selectie';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Weet je zeker dat je de geselecteerde bans wilt verwijderen?';
$txt['ban_modify'] = 'Bewerk';
$txt['ban_name'] = 'Ban-naam';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Bewerk ban';
$txt['ban_add_notes'] = '<strong>Let op</strong>: na het aanmaken van bovenstaande ban kun je meer items toevoegen die de ban in werking stellen, zoals IP-adressen, hostnamen en e-mailadressen.';
$txt['ban_expired'] = 'Verlopen / uitgeschakeld';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Geen beperking geselecteerd.';

$txt['ban_triggers'] = 'Triggers';
$txt['ban_add_trigger'] = 'Voeg bantrigger toe';
$txt['ban_add_trigger_submit'] = 'Voeg toe';
$txt['ban_edit_trigger'] = 'Bewerk';
$txt['ban_edit_trigger_title'] = 'Bewerk bantrigger';
$txt['ban_edit_trigger_submit'] = 'Bewerk';
$txt['ban_remove_selected_triggers'] = 'Verwijder geselecteerde bantriggers';
$txt['ban_no_entries'] = 'Er zijn momenteel geen bannen van kracht.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Weet je zeker dat je de geselecteerde triggers wilt verwijderen?';
$txt['ban_trigger_browse'] = 'Bekijk bantriggers';
$txt['ban_trigger_browse_description'] = 'This screen shows all banned entities grouped by IP address, hostname, email address and user name.';

$txt['ban_log'] = 'Banlog';
$txt['ban_log_description'] = 'Het banlog geeft alle pogingen weer van gebande gebruikers om in te loggen (alleen \'volledige ban\' en \'kan niet registreren\'-ban).';
$txt['ban_log_no_entries'] = 'Er zijn momenteel geen ingangen in het banlog.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'E-mailadres';
$txt['ban_log_member'] = 'Lid';
$txt['ban_log_date'] = 'Datum';
$txt['ban_log_remove_all'] = 'Clear Log';
$txt['ban_log_remove_all_confirm'] = 'Weet je zeker dat je alle banlogregels wilt verwijderen?';
$txt['ban_log_remove_selected'] = 'Verwijder selectie';
$txt['ban_log_remove_selected_confirm'] = 'Weet je zeker dat je alle geselecteerde banlogregels wilt verwijderen?';
$txt['ban_no_triggers'] = 'Er zijn momenteel geen bantriggers geconfigureerd.';

$txt['settings_not_writable'] = 'Deze instellingen kunnen niet worden aangepast omdat Settings.php niet schrijfbaar is.';

$txt['maintain_title'] = 'Forumonderhoud';
$txt['maintain_info'] = 'Basic forum backups, Database error checking, Clearing the Cache, Integration Hooks and more.';
$txt['maintain_sub_database'] = 'Database';
$txt['maintain_sub_routine'] = 'Routine';
$txt['maintain_sub_members'] = 'Leden';
$txt['maintain_sub_topics'] = 'Topics';
$txt['maintain_sub_attachments'] = 'Bijlagen';
$txt['maintain_done'] = 'De onderhoudstaak \'%1$s\' is met succes uitgevoerd.';
$txt['maintain_fail'] = 'The maintenance task \'%1$s\' failed.';
$txt['maintain_no_errors'] = 'Congratulations, no errors were found.  Thanks for checking.';

$txt['maintain_tasks'] = 'Geplande taken';
$txt['maintain_tasks_desc'] = 'Manage all the scheduled tasks.';

$txt['scheduled_log'] = 'Takenlog';
$txt['scheduled_log_desc'] = 'Lists logs of the tasks that were run.';
$txt['admin_log'] = 'Beheerlog';
$txt['admin_log_desc'] = 'Overzicht van de door beheerders van je forum uitgevoerde administratieve taken.';
$txt['moderation_log'] = 'Moderatielog';
$txt['moderation_log_desc'] = 'Overzicht van moderatieactiviteiten die zijn uitgevoerd door de moderators van je forum.';
$txt['badbehavior_log'] = 'Bad Behavior Log';
$txt['badbehavior_log_desc'] = 'Lists requests that were blocked or marked suspicious by bad behavior.  If verbose logging is on all HTTP requests are listed.';
$txt['spider_log_desc'] = 'Overzicht van de recente activiteit van de spiders van zoekmachines op je forum.';
$txt['pruning_log_desc'] = 'Hiermee kunnen oude ingangen in de logboeken automatisch verwijderd worden.';

$txt['mailqueue_title'] = 'E-mail';

$txt['db_error_send'] = 'E-mail versturen bij een database-verbindingsfout';
$txt['db_persist'] = 'Gebruik een vaste verbinding (persistent connection)';
$txt['ssi_db_user'] = 'Database user name to use in SSI mode';
$txt['ssi_db_passwd'] = 'Databasewachtwoord voor SSI-modus';

$txt['default_language'] = 'Default forum language';

$txt['maintenance_subject'] = 'Weer te geven onderwerp';
$txt['maintenance_message'] = 'Weer te geven bericht';

$txt['errlog_desc'] = 'Het foutenlogbestand slaat alle fouten in chronologische volgorde op. Om de fouten te verwijderen, moet je deze aanvinken en op de %1$s knop onderaan de pagina drukken.';
$txt['errlog_no_entries'] = 'Er zijn momenteel geen ingangen in het foutenlog.';

$txt['theme_settings'] = 'Thema-instellingen';
$txt['theme_edit_settings'] = 'Edit this theme\'s settings';
$txt['theme_current_settings'] = 'Huidige thema';

$txt['dvc_your'] = 'Jouw versie';
$txt['dvc_current'] = 'Huidige versie';
$txt['dvc_sources'] = 'Sources';
$txt['dvc_admin'] = 'Beheer';
$txt['dvc_controllers'] = 'Controllers';
$txt['dvc_database'] = 'Database';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Standaardtemplates';
$txt['dvc_templates'] = 'Huidige templates';
$txt['dvc_languages'] = 'Taalbestanden';

$txt['smileys_default_set_for_theme'] = 'Select default smiley set for this theme:';
$txt['smileys_no_default'] = 'Use default smiley set';

$txt['censor_test'] = 'Test de gecensureerde woorden';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Ignore case when censoring.';
$txt['censor_whole_words'] = 'Check only whole words.';
$txt['censor_allow'] = 'Allow users to turn off word censoring.';

$txt['admin_confirm_password'] = '(confirm password)';
$txt['admin_incorrect_password'] = 'Ongeldig wachtwoord';

$txt['date_format'] = '(YYYY-MM-DD)';
$txt['undefined_gender'] = 'Niet gespecificeerd';
$txt['age'] = 'Leeftijd';
$txt['activation_status'] = 'Activeringsstatus';
$txt['activated'] = 'Geactiveerd';
$txt['not_activated'] = 'Niet geactiveerd';
$txt['is_banned'] = 'Banned';
$txt['primary'] = 'Primair';
$txt['additional'] = 'Extra';
$txt['wild_cards_allowed'] = 'jokertekens * en ? zijn toegestaan';
$txt['member_part_of_these_membergroups'] = 'Member is part of these member groups';
$txt['membergroups'] = 'Member groups';
$txt['confirm_delete_members'] = 'Weet je zeker dat je de geselecteerde leden wilt verwijderen?';

$txt['support_credits_title'] = 'Support &amp; Credits';
$txt['support_credits_info'] = 'Support links for most common issues, the relevant forum version information you will be asked for when you request help and a list of contributors to the ElkArte project.';
$txt['support_title'] = 'Ondersteuningsinformatie';
$txt['support_versions_current'] = 'Current version';
$txt['support_versions_forum'] = 'This version';
$txt['support_versions_db'] = '%1$s-versie';
$txt['support_versions_server'] = 'Serverversie';
$txt['support_versions_gd'] = 'GD-versie';
$txt['support_versions_imagick'] = 'Imagick version';
$txt['support_versions'] = 'Versie-informatie';
$txt['support_resources'] = 'Hulpbronnen voor ondersteuning';
$txt['support_resources_p1'] = 'Our <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> provides the main documentation for ElkArte. The ElkArte Online Manual has many documents to help answer support questions and explain <a href="%2$s" target="_blank" class="new_win">Features</a>, <a href="%3$s" target="_blank" class="new_win">Settings</a>, <a href="%4$s" target="_blank" class="new_win">Themes</a>, <a href="%5$s" target="_blank" class="new_win">Packages</a>, etc. The Online Manual documents each area of ElkArte thoroughly and should answer most questions quickly.';
$txt['support_resources_p2'] = 'If you can\'t find the answers to your questions in the Documentation Wiki, you may want to search our <a href="%1$s" target="_blank" class="new_win">Support Community</a> or ask for assistance in our support boards. The ElkArte Support Community can be used for <a href="%2$s" target="_blank" class="new_win">support</a>, <a href="%3$s" target="_blank" class="new_win">customization</a>, and many other things such as discussing ElkArte, finding a host, and discussing administrative issues with other forum administrators.';

$txt['latest_updates'] = 'Latest noteworthy updates';
$txt['new_in_1_0_2'] = 'The most significant change in ElkArte 1.0.2 is avatar permission management. Currently each method of setting an avatar is permission-based, requiring the enabling/disabling of each method for each group. With 1.0.2 avatars are simply enabled/disabled by user group, this allows the enabled groups to add an avatar (by all available methods).<br />
The only permission available is a general one to allow members to change or not their avatars. Additionally there is only one setting for maximum width and height of avatars, these values apply to all avatar methods.<br /><br />
Due to the nature of the changes it was not impossible to migrate existing settings to the new format, for that reason you are encouraged to visit the <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Settings</a> page and set the options you prefer.';

$txt['edit_permissions_info'] = 'Use permission settings to manage global and specific board features and what actions that guest, members and moderators can do.';
$txt['membergroups_members'] = 'Niet-gegroepeerde leden';
$txt['membergroups_guests'] = 'Ongeregistreerde gasten';
$txt['membergroups_add_group'] = 'Voeg ledengroep toe';
$txt['membergroups_permissions'] = 'Permissies';

$txt['permitgroups_restrict'] = 'Beperkt';
$txt['permitgroups_standard'] = 'Standaard';
$txt['permitgroups_moderator'] = 'Moderator';
$txt['permitgroups_maintenance'] = 'Onderhoud';

$txt['confirm_delete_attachments'] = 'Weet je zeker dat je de geselecteerde bijlagen wilt verwijderen?';
$txt['attachment_manager_browse_files'] = 'Bekijk bestanden';
$txt['attachment_manager_repair'] = 'Controleer';
$txt['attachment_manager_avatars'] = 'Avatars';
$txt['attachment_manager_attachments'] = 'Bijlagen';
$txt['attachment_manager_thumbs'] = 'Miniaturen';
$txt['attachment_manager_last_active'] = 'Laatst actief';
$txt['attachment_manager_member'] = 'Lid';
$txt['attachment_manager_avatars_older'] = 'Remove avatars from members not active for more than %1$s days';
$txt['attachment_manager_total_avatars'] = 'Total avatars';

$txt['attachment_manager_avatars_no_entries'] = 'Er zijn op dit moment geen avatars.';
$txt['attachment_manager_attachments_no_entries'] = 'Er zijn op dit moment geen bijlagen.';
$txt['attachment_manager_thumbs_no_entries'] = 'Er zijn op dit moment geen minituren.';

$txt['attachment_manager_settings'] = 'Bijlage-instellingen';
$txt['attachment_manager_avatar_settings'] = 'Avatarinstellingen';
$txt['attachment_manager_browse'] = 'Bekijk bestanden';
$txt['attachment_manager_maintenance'] = 'Bestandsonderhoud';
$txt['attachmentEnable'] = 'Bijlagemodus';
$txt['attachmentEnable_deactivate'] = 'Deactiveer bijlagen';
$txt['attachmentEnable_enable_all'] = 'Activeer alle bijlagen';
$txt['attachmentEnable_disable_new'] = 'Deactiveer nieuwe bijlagen';
$txt['attachmentCheckExtensions'] = 'Controleer de extensie van de bijlage';
$txt['attachmentExtensions'] = 'Alleen deze bijlage-extensies toestaan';
$txt['attachmentRecodeLineEndings'] = 'Regeleinden voor tekstuele bijlagen herschrijven';
$txt['attachmentShowImages'] = 'Toon de bijlage als afbeelding in het bericht';
$txt['attachmentUploadDir'] = 'Bijlagenmap';
$txt['attachmentUploadDir_multiple_configure'] = 'Manage attachment directories';
$txt['attachmentDirSizeLimit'] = 'Max attachment directory space';
$txt['attachmentPostLimit'] = 'Max attachment size per post';
$txt['attachmentSizeLimit'] = 'Max size per attachment';
$txt['attachmentNumPerPostLimit'] = 'Max number of attachments per post';
$txt['attachment_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Image re-encoding is not possible.';
$txt['attachment_postsize_warning'] = 'The current php.ini setting \'post_max_size\' may not support this.';
$txt['attachment_filesize_warning'] = 'The current php.ini setting \'upload_max_filesize\' may not support this.';
$txt['attachment_image_reencode'] = 'Herencodeer potentieel gevaarlijke afbeeldingsbijlagen ';
$txt['attachment_image_reencode_note'] = '(requires GD module or ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'De uitgebreide beveiligingschecks kunnen leiden tot een groter aantal verworpen bijlagen.';
$txt['attachment_image_paranoid'] = 'Voer uitgebreide beveiligingscontroles uit op ge&uuml;ploade afbeeldingsbijlagen';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'Herschaal bijlagen die als afbeelding onder berichten worden getoond';
$txt['attachment_thumb_png'] = 'Sla miniaturen op in PNG-formaat';
$txt['attachment_thumb_memory'] = 'Adaptive thumbnail memory';
$txt['attachment_thumb_memory_note2'] = 'If the system can not get the memory no thumbnail will be created.';
$txt['attachment_thumb_memory_note1'] = 'Leave this unchecked to always attempt to create a thumbnail';
$txt['attachmentThumbWidth'] = 'Maximumbreedte van miniaturen';
$txt['attachmentThumbHeight'] = 'Maximumhoogte van miniaturen';
$txt['attachment_thumbnail_settings'] = 'Thumbnail Settings';
$txt['attachment_security_settings'] = 'Attachment security settings';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Bestaat niet';
$txt['attach_dir_not_writable'] = 'Niet beschrijfbaar';
$txt['attach_dir_files_missing'] = 'Files Missing (<a href="{repair_url}">Repair</a>)';
$txt['attach_dir_unused'] = 'Ongebruikt';
$txt['attach_dir_empty'] = 'Empty';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Base directory';

$txt['attach_dir_desc'] = 'Create new directories or change the current directory below. Directories can be renamed as long as they do not contain a sub-directory. If the new directory is to be created within the forum directory structure, you\'ll just need to type the directory name. To remove a directory, blank the path input field. Directories can not be deleted if they contain either files or sub-directories (shown in brackets next to the file count).';
$txt['attach_dir_base_desc'] = 'You may use the area below to change the current base directory or create a new one. New base directories are also added to the Attachment Directory list. You may also designate an existing directory to be a base directory.';
$txt['attach_dir_save_problem'] = 'Oops, there seems to be a problem.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory. Please do so using a FTP client or your site file manager.';
$txt['attachments_no_write'] = 'This directory has been created but is not writable. Please attempt to do so using a FTP client or your site file manager.';
$txt['attach_dir_reserved'] = 'Unable to add. This directory is a system directory and cannot be used for attachments.';
$txt['attach_dir_duplicate_msg'] = 'Unable to add. This directory already exists.';
$txt['attach_dir_exists_msg'] = 'Unable to move. A directory already exists at that path.';
$txt['attach_dir_base_dupe_msg'] = 'Unable to add. This base directory has already been created.';
$txt['attach_dir_base_no_create'] = 'Unable to create. Please verify the path input or create this directory using an FTP client or site file manager and re-try.';
$txt['attach_dir_no_rename'] = 'Unable to move or rename. Please verify that the path is correct or that this directory does not contain any sub-directories.';
$txt['attach_dir_no_delete'] = 'Is not empty and can not be deleted. Please do so using a FTP client or site file manager.';
$txt['attach_dir_no_remove'] = 'Still contains files or is a base directory and can not be deleted.';
$txt['attach_dir_is_current'] = 'Unable to remove while it is selected as the current directory.';
$txt['attach_dir_is_current_bd'] = 'Unable to remove while it is selected as the current base directory.';
$txt['attach_last_dir'] = 'Last active attachment directory';
$txt['attach_current_dir'] = 'Current attachment directory';
$txt['attach_current'] = 'Current';
$txt['attach_path_manage'] = 'Manage attachment paths';
$txt['attach_directories'] = 'Attachment Directories';
$txt['attach_paths'] = 'Attachment directory paths';
$txt['attach_path'] = 'Pad';
$txt['attach_current_size'] = 'Size (KiB)';
$txt['attach_num_files'] = 'Bestanden';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Voeg pad toe';
$txt['attach_path_current_bad'] = 'Ongeldig huidig bijlagenpad.';
$txt['attachmentDirFileLimit'] = 'Maximum number of files per directory';

$txt['attach_base_paths'] = 'Base directory paths';
$txt['attach_num_dirs'] = 'Directories';
$txt['max_image_width'] = 'Max display width of posted or attached images';
$txt['max_image_height'] = 'Max display height of posted or attached images';

$txt['automanage_attachments'] = 'Choose the method for the management of the attachment directories';
$txt['attachments_normal'] = '(Manual) ElkArte default behaviour';
$txt['attachments_auto_years'] = '(Auto) Subdivide by years';
$txt['attachments_auto_months'] = '(Auto) Subdivide by years and months';
$txt['attachments_auto_days'] = '(Auto) Subdivide by years, months and days';
$txt['attachments_auto_16'] = '(Auto) 16 random directories';
$txt['attachments_auto_16x16'] = '(Auto) 16 random directories with 16 random sub-directories';
$txt['attachments_auto_space'] = '(Auto) When either directory space limit is reached';

$txt['use_subdirectories_for_attachments'] = 'Create new directories within a base directory';
$txt['use_subdirectories_for_attachments_note'] = 'Otherwise any new directories will be created within the forum\'s main directory.';
$txt['basedirectory_for_attachments'] = 'Set a base directory for attachments';
$txt['basedirectory_for_attachments_current'] = 'Current base directory';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Please note that the directory is wrong. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">There seems to be a problem with this directory. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';

$txt['attachment_transfer'] = 'Transfer Attachments';
$txt['attachment_transfer_desc'] = 'Transfer files between directories.';
$txt['attachment_transfer_select'] = 'Select directory';
$txt['attachment_transfer_now'] = 'Transfer';
$txt['attachment_transfer_from'] = 'Transfer files from';
$txt['attachment_transfer_auto'] = 'Move them automatically by space or file count';
$txt['attachment_transfer_auto_select'] = 'Select base directory';
$txt['attachment_transfer_to'] = 'Or move them to a specific directory.';
$txt['attachment_transfer_empty'] = 'Move all files from the source directory.';
$txt['attachment_transfer_no_base'] = 'No base directories available.';
$txt['attachment_transfer_forum_root'] = 'Forum root directory.';
$txt['attachment_transfer_no_room'] = 'Directory size or file count limit reached.';
$txt['attachment_transfer_no_find'] = 'No files were found to transfer.';
$txt['attachments_transfered'] = '%1$d files were transferred to %2$s';
$txt['attachments_not_transfered'] = '%1$d files were not transferred.';
$txt['attachment_transfer_no_dir'] = 'Either the source directory or one of the target options were not selected.';
$txt['attachment_transfer_same_dir'] = 'You cannot select the same directory as both the source and target.';
$txt['attachment_transfer_progress'] = 'Please wait. Transfer in progress.';

$txt['avatar_settings'] = 'General avatar settings';
$txt['avatar_default'] = 'Enable a default avatar for all users without their own avatar';
$txt['avatar_directory'] = 'Avatardirectory';
$txt['avatar_url'] = 'Avatar-URL';
$txt['avatar_max_width'] = 'Maximum width of avatars in pixels (px)';
$txt['avatar_max_height'] = 'Maximum height of avatars in pixels (px)';
$txt['avatar_action_too_large'] = 'Als de avatar te groot is...';
$txt['option_refuse'] = 'Weiger hem';
$txt['option_resize'] = 'Let the CSS resize it';
$txt['option_download_and_resize'] = 'Download and resize it (requires GD module or ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Enable use of gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'Gebruik PNG voor verkleinde avatars';
$txt['avatar_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Some avatar features are disabled.';
$txt['avatar_external'] = 'Externe avatars';
$txt['avatar_external_enabled'] = 'Enable use of external (remote/URL) avatars';
$txt['avatar_upload'] = 'Uploadbare avatars';
$txt['avatar_resize_options'] = 'Server storage options';
$txt['avatar_upload_enabled'] = 'Enable the upload of avatars';
$txt['avatar_server_stored'] = 'Op de server opgeslagen avatars';
$txt['avatar_stored_enabled'] = 'Enable the selection of server stored avatars';
$txt['profile_set_avatar'] = 'Member groups allowed to select an avatar';
$txt['avatar_select_permission'] = 'Selecteer permissies per groep';
$txt['avatar_download_external'] = 'Download avatar vanaf ingevoerde URL';
$txt['custom_avatar_enabled'] = 'Upload avatars naar...';
$txt['option_attachment_dir'] = 'Bijlagenmap';
$txt['option_specified_dir'] = 'Specifieke map...';
$txt['custom_avatar_dir'] = 'Uploadmap';
$txt['custom_avatar_dir_desc'] = 'This should be a valid and writable directory, different than the server-stored directory.';
$txt['custom_avatar_url'] = 'Upload-URL';
$txt['custom_avatar_check_empty'] = 'De opgegeven map voor ge&uuml;ploade avatars lijkt ongeldig te zijn. Controleer of de instellingen juist zijn.';
$txt['avatar_reencode'] = 'Herencodeer potentieel gevaarlijke avatars';
$txt['avatar_reencode_note'] = '(vereist GD-module)';
$txt['avatar_paranoid_warning'] = 'De uitgebreide beveiligingschecks kunnen leiden tot een groter aantal verworpen avatars.';
$txt['avatar_paranoid'] = 'Voer uitgebreide beveiligingscontroles uit op ge&uuml;ploade avatars';

$txt['repair_attachments'] = 'Bijlagen beheren';
$txt['repair_attachments_complete'] = 'Onderhoud voltooid';
$txt['repair_attachments_complete_desc'] = 'Alle geselecteerde fouten zijn nu gecorrigeerd.';
$txt['repair_attachments_no_errors'] = 'No errors were found';
$txt['repair_attachments_error_desc'] = 'De volgende fouten zijn gevonden tijdens het onderhoud. Vink de vakjes naast de items die je wilt repareren aan, en klik op Doorgaan.';
$txt['repair_attachments_continue'] = 'Doorgaan';
$txt['repair_attachments_cancel'] = 'Annuleren';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d miniaturen horen niet bij een grote afbeelding';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d grote afbeeldingen hebben geen miniatuur';
$txt['attach_repair_file_missing_on_disk'] = '%1$d bijlagen/avatars staan in de database, maar bestaan niet langer op schijf';
$txt['attach_repair_file_wrong_size'] = '%1$d bijlagen/avatars hebben een verkeerde grootte in de database';
$txt['attach_repair_file_size_of_zero'] = '%1$d  bijlagen/avatars hebben een leeg bestand op schijf (deze zullen worden verwijderd)';
$txt['attach_repair_attachment_no_msg'] = '%1$d bijlagen horen niet langer bij een bericht';
$txt['attach_repair_avatar_no_member'] = '%1$d avatars horen niet langer bij een lid';
$txt['attach_repair_wrong_folder'] = '%1$d attachments are in the wrong directory';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d files do not have a corresponding entry in the database. (These will be deleted)';

$txt['news_title'] = 'Nieuws en nieuwsbrieven';
$txt['news_settings_desc'] = 'Hier kun je instellingen en permissies veranderen op het gebied van nieuws en nieuwsbrieven.';
$txt['news_mailing_desc'] = 'From this menu you can send messages to all users who\'ve registered and entered their email addresses. You may edit the distribution list, or send messages to all. Useful for important update/news information.';
$txt['news_error_no_news'] = 'Nothing to preview';
$txt['groups_edit_news'] = 'Ledengroepen die nieuwsberichten kunnen aanpassen';
$txt['groups_send_mail'] = 'Ledengroepen die forumnieuwsbrieven kunnen versturen';
$txt['xmlnews_enable'] = 'XML/RSS nieuws aanzetten?';
$txt['xmlnews_maxlen'] = 'Maximum message length';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Number of items in a news feed';
$txt['xmlnews_maxlen_note'] = '(0 to disable, bad idea.)';
$txt['editnews_clickadd'] = 'Add another item';
$txt['editnews_remove_selected'] = 'Verwijder selectie';
$txt['editnews_remove_confirm'] = 'Weet je zeker dat je de geselecteerde nieuwsitems wilt verwijderen?';
$txt['censor_clickadd'] = 'Add another word';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Logboeken';
$txt['generate_reports'] = 'Genereer rapporten';

$txt['update_available'] = 'Update Available';
$txt['update_message'] = 'You\'re using an outdated version of ElkArte, which contains some bugs which have since been fixed.
	It is recommended that you <a href="#" id="update-link">update your forum</a> to the latest version as soon as possible. It only takes a minute!';

$txt['manageposts'] = 'Berichten en topics';
$txt['manageposts_title'] = 'Beheer berichten en topics';
$txt['manageposts_description'] = 'Hier kun je alles instellen met betrekking tot berichten en topics.';

$txt['manageposts_seconds'] = 'seconden';
$txt['manageposts_minutes'] = 'minuten';
$txt['manageposts_characters'] = 'karakters';
$txt['manageposts_days'] = 'dagen';
$txt['manageposts_posts'] = 'berichten';
$txt['manageposts_topics'] = 'topics';

$txt['pollMode'] = 'Polls activeren';

$txt['manageposts_settings'] = 'Berichtinstellingen';
$txt['manageposts_settings_description'] = 'Hier kun je alles instellen met betrekking tot berichten en het plaatsen ervan.';

$txt['manageposts_bbc_settings'] = 'Bulletin Board Code';
$txt['manageposts_bbc_settings_description'] = 'Bulletin Board Code kan gebruikt worden om forumberichten op te maken. Bijvoorbeeld, om het woord \'huis\' vet weer te geven kun je [b]huis[/b] typen. Alle Bulletin Board Code-tags zijn omgeven door vierkante haken (\'[\' en \']\').';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code settings';

$txt['manageposts_topic_settings'] = 'Topicinstellingen';
$txt['manageposts_topic_settings_description'] = 'Hier kun je alles instellen wat te maken heeft met topics';

$txt['managedrafts_settings'] = 'Draft Settings';
$txt['managedrafts_settings_description'] = 'Here you can set all settings involving drafts.';
$txt['manage_drafts'] = 'Drafts';

$txt['mail_center'] = 'Maillist Center';
$txt['mm_emailerror'] = 'Failed Emails';
$txt['mm_emailfilters'] = 'Filters';
$txt['mm_emailparsers'] = 'Parsers';
$txt['mm_emailtemplates'] = 'Templates';
$txt['mm_emailsettings'] = 'Instellingen';

$txt['removeNestedQuotes'] = 'Verwijder geneste citaten bij citeren berichten';
$txt['enableSpellChecking'] = 'Schakel spellingscontrole in';
$txt['enableSpellChecking_warning'] = 'this does not work on all servers.';
$txt['enableSpellChecking_error'] = 'this does not work on your server.';
$txt['enableVideoEmbeding'] = 'Enable auto-embedding of video links.';
$txt['enableCodePrettify'] = 'Enable prettifying of code tags';
$txt['max_messageLength'] = 'Maximale grootte van een bericht';
$txt['max_messageLength_zero'] = '0 voor geen maximum';
$txt['convert_to_mediumtext'] = 'Your database is not setup to accept messages longer than 65535 characters. Please use the <a href="%1$s">database maintenance</a> page to convert the database and then come back to increase the maximum allowed post size.';
$txt['topicSummaryPosts'] = 'Aantal berichten te tonen bij topic samenvatting';
$txt['spamWaitTime'] = 'Minimale tijd tussen het plaatsen van berichten';
$txt['edit_wait_time'] = 'Vrije bewerktijd na plaatsing';
$txt['edit_disable_time'] = 'Maximale tijd dat een bericht nog bewerkt mag worden';
$txt['edit_disable_time_zero'] = '0 om uit te schakelen';
$txt['preview_characters'] = 'Maximum length of last/first post preview';
$txt['preview_characters_units'] = 'karakters';
$txt['preview_characters_zero'] = '0 to show the entire message';
$txt['message_index_preview'] = 'Show post previews on the message index';
$txt['message_index_preview_off'] = 'Do not show the previews';
$txt['message_index_preview_first'] = 'Show the text of the first post';
$txt['message_index_preview_last'] = 'Show the text of the last post';

$txt['enableBBC'] = 'Gebruik bulletin board code';
$txt['enablePostHTML'] = 'Gebruik van basis-HTML toestaan';
$txt['autoLinkUrls'] = 'URLs automatisch linken';
$txt['disabledBBC'] = 'Ingeschakelde BBC-tags';
$txt['bbcTagsToUse'] = 'Ingeschakelde BBC-tags';
$txt['bbcTagsToUse_select'] = 'Selecteer de tags die gebruikt mogen worden';
$txt['bbcTagsToUse_select_all'] = 'Selecteer alle tags';

$txt['enableParticipation'] = 'Deelname-iconen aanzetten?';
$txt['enableFollowup'] = 'Enable followups';
$txt['enable_unwatch'] = 'Enable unwatching of topics';
$txt['oldTopicDays'] = 'Dagen alvorens een topic als oud wordt beschouwd, en er gewaarschuwd wordt bij reactie';
$txt['oldTopicDays_zero'] = '0 om uit te schakelen';
$txt['defaultMaxTopics'] = 'Aantal topics per pagina op de topicsindex';
$txt['defaultMaxMessages'] = 'Aantal berichten per pagina in een topicpagina';
$txt['disable_print_topic'] = 'Disable print topic feature';
$txt['hotTopicPosts'] = 'Aantal berichten voor een \'populair topic\'?';
$txt['hotTopicVeryPosts'] = 'Aantal berichten voor een \'zeer populair topic\'?';
$txt['useLikesNotViews'] = 'Use number of likes in place of posts to define hot topics';
$txt['enableAllMessages'] = 'Maximale topicgrootte om de &quot;Alle&quot; berichten-knop weer te geven';
$txt['enableAllMessages_zero'] = '0 om nooit &quot;Alle&quot; berichten te tonen';
$txt['disableCustomPerPage'] = 'Schakel het aanpassen van hoeveelheid topics/berichten per pagina uit';
$txt['enablePreviousNext'] = 'Vorige/volgende topic-mod activeren';

$txt['not_done_title'] = 'Not done yet';
$txt['not_done_reason'] = 'Om overbelasting van je server te voorkomen, is het proces tijdelijk gestopt. Het zou automatisch binnen enkele seconden verder moeten gaan. Als dit niet het geval is, klik dan hieronder op \'Doorgaan\'.';
$txt['not_done_continue'] = 'Doorgaan';

$txt['general_settings'] = 'Algemeen';
$txt['database_paths_settings'] = 'Database en paden';
$txt['cookies_sessions_settings'] = 'Cookies en sessies';
$txt['caching_settings'] = 'Caching';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Local Settings';
$txt['phpinfo_defaultsettings'] = 'Default Settings';
$txt['phpinfo_itemsettings'] = 'Instellingen';

$txt['language_configuration'] = 'Talen';
$txt['language_description'] = 'This section allows you to edit languages installed on your forum or download new ones from the ElkArte site. You may also edit language-related settings here.';
$txt['language_edit'] = 'Bewerk talen';
$txt['language_add'] = 'Taal toevoegen';
$txt['language_settings'] = 'Instellingen';

$txt['advanced'] = 'Geavanceerd';
$txt['simple'] = 'Eenvoudig';

$txt['admin_news_select_recipients'] = 'Selecteer wie er een exemplaar van deze nieuwsbrief moeten krijgen.';
$txt['admin_news_select_group'] = 'Member groups';
$txt['admin_news_select_group_desc'] = 'Selecteer welke groepen deze nieuwsbrief moeten krijgen.';
$txt['admin_news_select_members'] = 'Leden';
$txt['admin_news_select_members_desc'] = 'Additional members to receive the newsletter.';
$txt['admin_news_select_excluded_members'] = 'Uitgesloten leden';
$txt['admin_news_select_excluded_members_desc'] = 'Members who should not receive the newsletter.';
$txt['admin_news_select_excluded_groups'] = 'Uitgesloten groepen';
$txt['admin_news_select_excluded_groups_desc'] = 'Selecteer welke groepen deze nieuwsbrief zeker niet moeten krijgen.';
$txt['admin_news_select_email'] = 'E-mailadressen';
$txt['admin_news_select_email_desc'] = 'A semi-colon separated list of email addresses which should be sent this newsletter. (i.e. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Override notification settings';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Je kunt geen persoonlijk bericht aan een e-mailadres versturen. Als je doorgaat, worden alle ingevoerde e-mailadressen genegeerd.\\n\\nWeet je zeker dat je door wilt gaan?';

$txt['mailqueue_browse'] = 'Wachtrij doorbladeren';
$txt['mailqueue_settings'] = 'Instellingen';

$txt['admin_search'] = 'Snel zoeken';
$txt['admin_search_type_internal'] = 'Taak/instelling';
$txt['admin_search_type_member'] = 'Lid';
$txt['admin_search_type_online'] = 'Online Documentatie';
$txt['admin_search_go'] = 'zoek';
$txt['admin_search_results'] = 'Zoekresultaten';
$txt['admin_search_results_desc'] = 'Resultaten voor zoekopdracht: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Zoek nogmaals';
$txt['admin_search_results_none'] = 'No results found.';

$txt['admin_search_section_sections'] = 'Sectie';
$txt['admin_search_section_settings'] = 'Instellingen';

$txt['core_settings_title'] = 'Basisfeatures';
$txt['core_settings_desc'] = 'This page allows you to turn on or off optional features of your forum.';
$txt['mods_cat_features'] = 'Algemeen';
$txt['mods_cat_security_general'] = 'Algemeen';
$txt['antispam_title'] = 'Verificatie';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Diversen';
$txt['mods_cat_layout'] = 'Lay-out';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderatie';
$txt['signature_settings_short'] = 'Handtekeningen';
$txt['custom_profile_shorttitle'] = 'Profielvelden';
$txt['pruning_title'] = 'Logopschoning';

$txt['core_settings_activation_message'] = 'The feature {core_feature} has been activated, click on the title to configure it';
$txt['core_settings_deactivation_message'] = 'The feature {core_feature} has been deactivated';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Boards bewerken';
$txt['mboards_new_cat'] = 'Create new category';
$txt['manage_holidays'] = 'Feestdagen beheren';
$txt['calendar_settings'] = 'Kalenderinstellingen';
$txt['search_weights'] = 'Gewichten';
$txt['search_method'] = 'Zoekmethode';
$txt['search_sphinx'] = 'Configure Sphinx';

$txt['smiley_sets'] = 'Smileysets';
$txt['smileys_add'] = 'Smiley toevoegen';
$txt['smileys_edit'] = 'Smileys bewerken';
$txt['smileys_set_order'] = 'Set Smiley order';
$txt['icons_edit_message_icons'] = 'Edit message icons';

$txt['membergroups_new_group'] = 'Add Member Group';
$txt['membergroups_edit_groups'] = 'Edit Member Groups';
$txt['permissions_groups'] = 'Permissies per ledengroep';
$txt['permissions_boards'] = 'Permissies per board';
$txt['permissions_profiles'] = 'Permissieprofielen';
$txt['permissions_post_moderation'] = 'Berichtmoderatie';

$txt['browse_packages'] = 'Pakketten bekijken';
$txt['download_packages'] = 'Download pakketten';
$txt['upload_packages'] = 'Upload Package';
$txt['installed_packages'] = 'Ge&iuml;nstalleerde pakketten';
$txt['package_file_perms'] = 'Bestandpermissies';
$txt['package_settings'] = 'Instellingen';
$txt['package_servers'] = 'Package Servers';
$txt['themeadmin_admin_title'] = 'Beheer en installeer';
$txt['themeadmin_list_title'] = 'Thema-instellingen';
$txt['themeadmin_reset_title'] = 'Herstel lidopties';
$txt['themeadmin_edit_title'] = 'Bewerk thema\'s';
$txt['admin_browse_register_new'] = 'Register new member';

$txt['search_engines'] = 'Zoekmachines';
$txt['spider_logs'] = 'Spiderlog';
$txt['spider_stats'] = 'Statistieken';

$txt['paid_subscriptions'] = 'Betaalde abonnementen';
$txt['paid_subs_view'] = 'Bekijk abonnementen';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks';
$txt['hooks_field_hook_name'] = 'Hook Name';
$txt['hooks_field_function_name'] = 'Function Name';
$txt['hooks_field_function'] = 'Function';
$txt['hooks_field_included_file'] = 'Included file';
$txt['hooks_field_file_name'] = 'Bestandsnaam';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Exists';
$txt['hooks_disabled'] = 'Uitgeschakeld'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Not found';
$txt['hooks_no_hooks'] = 'There are currently no hooks in the system.';
$txt['hooks_disable_legend'] = 'Legenda';
$txt['hooks_disable_legend_exists'] = 'the hook exists and is active';
$txt['hooks_disable_legend_disabled'] = 'the hook exists but has been disabled';
$txt['hooks_disable_legend_missing'] = 'the hook has not been found';
$txt['hooks_reset_filter'] = 'Reset filter';

$txt['board_perms_allow'] = 'Toestaan';
$txt['board_perms_ignore'] = 'Negeer';
$txt['board_perms_deny'] = 'Ontzeggen';
$txt['all_boards_in_cat'] = 'All boards in this category';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Words separator';

$txt['admin_order_title'] = 'Ordering Error';
$txt['admin_order_error'] = 'An unknown error occurred while processing your request';

// Known controllers that can work on the front page
$txt['default'] = 'Standaard';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
