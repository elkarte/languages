<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8javascript:;';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Welkom';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Schrijfbaarheidcontrole';
$txt['install_step_forum'] = 'Standaardinstellingen';
$txt['install_step_databaseset'] = 'Database-instellingen';
$txt['install_step_databasechange'] = 'Database vullen';
$txt['install_step_admin'] = 'Beheerderaccount';
$txt['install_step_delete'] = 'Finalize Installation';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'Taal';
$txt['installer_language_set'] = 'Stel deze taal in';
$txt['congratulations'] = 'Gefeliciteerd, de installatieprocedure is voltooid!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'De installatiemap is nog beschrijfbaar, verlaag de permissies (CHMOD) om beter beveiligd te zijn.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(Dit werkt niet op alle servers.)</em>';
$txt['go_to_your_forum'] = 'Je kunt <a href="%1$s">je zojuist ge&iuml;nstalleerde forum</a> bekijken en gebruiken. Je moet zijn ingelogd alvorens je het beheergedeelte kunt bekijken.';
$txt['good_luck'] = 'Thanks for installing ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Welkom';
$txt['install_welcome_desc'] = 'Welcome to ElkArte. This script will guide you through the process for installing %1$s. We\'ll gather a few details about your forum over the next few steps, and after a couple of minutes your forum will be ready for use.';
$txt['install_all_lovely'] = 'We hebben enkele begintests gedaan en alles lijkt in orde te zijn. Klik simpelweg op de &quot;Doorgaan&quot;-knop hieronder om alles op gang te brengen.';

$txt['user_refresh_install'] = 'Forum vernieuwd';
$txt['user_refresh_install_desc'] = 'Terwijl het installatieprogramma bezig was met installeren, is gebleken dat (met de instellingen die je hebt gegeven) er &eacute;&eacute;n of meer te cre&euml;ren tabellen reeds bestonden.<br />Alle ontbrekende tabellen zijn alsnog aangemaakt met de standaard gegevens, en er is geen data verwijderd uit de reeds bestaande tabellen.';

$txt['default_topic_subject'] = 'Welcome to ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Algemene discussie';
$txt['default_board_description'] = 'Praat gerust over van alles en nog wat op dit board.';
$txt['default_category_name'] = 'Algemeen';
$txt['default_time_format'] = '%e %B %Y, %H:%M:%S';
$txt['default_news'] = 'ElkArte - Just Installed!';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[mep]';
$txt['default_karmaApplaudLabel'] = '[toejuichen]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGuest\\nroot\\nBeheer\\nForumbeheerder\\nGast';
$txt['default_smileyset_name'] = 'Fugue\'s Set';
$txt['default_theme_name'] = 'ElkArte Default Theme';

$txt['default_administrator_group'] = 'Forumbeheerder';
$txt['default_global_moderator_group'] = 'Algemene moderator';
$txt['default_moderator_group'] = 'Moderator';
$txt['default_newbie_group'] = 'Nieuweling';
$txt['default_junior_group'] = 'Junior';
$txt['default_full_group'] = 'Volwaardig lid';
$txt['default_senior_group'] = 'Senior';
$txt['default_hero_group'] = 'Held';

$txt['default_smiley_smiley'] = 'Glimlach';
$txt['default_wink_smiley'] = 'Knipoog';
$txt['default_cheesy_smiley'] = 'Lachen';
$txt['default_grin_smiley'] = 'Grijns';
$txt['default_angry_smiley'] = 'Boos';
$txt['default_sad_smiley'] = 'Droevig';
$txt['default_shocked_smiley'] = 'Geschrokken';
$txt['default_cool_smiley'] = 'Cool';
$txt['default_huh_smiley'] = 'Huh?';
$txt['default_roll_eyes_smiley'] = 'Rollende ogen';
$txt['default_tongue_smiley'] = 'Tong';
$txt['default_embarrassed_smiley'] = 'Beschaamd';
$txt['default_lips_sealed_smiley'] = 'Ik zeg niets';
$txt['default_undecided_smiley'] = 'Ik weet het niet';
$txt['default_kiss_smiley'] = 'Kus';
$txt['default_cry_smiley'] = 'Huilen';
$txt['default_evil_smiley'] = 'Gemeen';
$txt['default_azn_smiley'] = 'Aziaat';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Lach';
$txt['default_police_smiley'] = 'Politie';
$txt['default_angel_smiley'] = 'Engel';

$txt['error_message_click'] = 'Klik hier';
$txt['error_message_try_again'] = 'om deze stap nog eens te proberen.';
$txt['error_message_bad_try_again'] = 'om toch door te gaan met de installatie, maar let op dat dit <em>sterk</em> wordt afgeraden.';

$txt['install_settings'] = 'Standaardinstellingen';
$txt['install_settings_info'] = 'This page requires you to define a few key settings for your forum. ElkArte has automatically detected key settings for you.';
$txt['install_settings_name'] = 'Forumnaam';
$txt['install_settings_name_info'] = 'This is the name of your forum, e.g. &quot;The Testing Forum&quot;.';
$txt['install_settings_name_default'] = 'Mijn forum';
$txt['install_settings_url'] = 'URL naar het forum';
$txt['install_settings_url_info'] = 'Dit is de URL naar je forum <strong>ZONDER de \'/\'!</strong><br />In de meeste gevallen is de standaardwaarde juist.';
$txt['install_settings_compress'] = 'Gzip-output';
$txt['install_settings_compress_title'] = 'Comprimeer de output om bandbreedte te besparen.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'This function does not work properly on all servers, but can save you a lot of bandwidth.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Click here to test it</a>. (it should just say "PASS".)';
$txt['install_settings_dbsession'] = 'Database-sessies';
$txt['install_settings_dbsession_title'] = 'Gebruik de database voor sessies in plaats van bestanden.';
$txt['install_settings_dbsession_info1'] = 'Deze feature is bijna altijd beter, omdat die sessies betrouwbaarder maakt.';
$txt['install_settings_dbsession_info2'] = 'Deze feature is meestal goed, maar zou mogelijkerwijs niet goed werken op deze server.';
$txt['install_settings_proceed'] = 'Ga verder';

$txt['db_settings'] = 'Database-serverinstellingen';
$txt['db_settings_info'] = 'Deze instellingen worden gebruikt voor de databaseserver. Als je de gegevens niet weet, vraag deze dan aan je host of zoek ze op.';
$txt['db_settings_type'] = 'Databasetype';
$txt['db_settings_type_info'] = 'Multiple supported database types were detected - which one do you wish to use?';
$txt['db_settings_server'] = 'Servernaam';
$txt['db_settings_server_info'] = 'Dit is meestal localhost - dus als je het niet weet, probeer dan localhost.';
$txt['db_settings_port'] = 'Poort';
$txt['db_settings_port_info'] = 'Leave empty if your server is listening on the default port, or you are uncertain.';
$txt['db_settings_username'] = 'User name';
$txt['db_settings_username_info'] = 'Fill in the user name you need to connect to your database here.<br />If you don\'t know what it is, try the user name of your FTP account, most of the time they are the same.';
$txt['db_settings_password'] = 'Wachtwoord';
$txt['db_settings_password_info'] = 'Here you should put the password you need to connect to your database.<br />If you don\'t know this, you should try the password to your FTP account.';
$txt['db_settings_database'] = 'Databasenaam';
$txt['db_settings_database_info'] = 'Fill in the name of the database you want to use for ElkArte to store its data in.';
$txt['db_settings_database_info_note'] = 'Als de database niet bestaat, zal er worden geprobeerd deze aan te maken.';
$txt['db_settings_database_file'] = 'Database file name';
$txt['db_settings_database_file_info'] = 'This is the name of the file in which to store the ElkArte data. We recommend you use the randomly generated name for this and set the path of this file to be outside of the public area of your webserver.';
$txt['db_settings_prefix'] = 'Tabelvoorvoegsel';
$txt['db_settings_prefix_info'] = 'Het voorvoegsel dat voor de naam van elke tabel in de database staat. <strong>Installeer niet twee forums met hetzelfde voorvoegsel!</strong><br />Dit voorvoegsel stelt je in staat om meerdere installaties in &eacute;&eacute;n database te hebben.';
$txt['db_populate'] = 'Database invullen';
$txt['db_populate_info'] = 'De instellingen zijn nu opgeslagen en de database is voorzien van alle gegevens die nodig zijn om je forum draaiende te maken. Kort overzicht van het invullen:';
$txt['db_populate_info2'] = 'Klik op &quot;Doorgaan&quot; om verder te gaan naar de pagina voor het aanmaken van een beheerdersaccount.';
$txt['db_populate_inserts'] = '%1$d rijen ingevoegd.';
$txt['db_populate_tables'] = '%1$d tabellen aangemaakt.';
$txt['db_populate_insert_dups'] = '%1$d dubbele invoegingen genegeerd.';
$txt['db_populate_table_dups'] = '%1$d dubbele tabellen genegeerd.';

$txt['user_settings'] = 'Maak je account aan';
$txt['user_settings_info'] = 'Er wordt nu een nieuwe beheerdersaccount voor je aangemaakt.';
$txt['user_settings_username'] = 'Your user name';
$txt['user_settings_username_info'] = 'Choose the name you want to login with.';
$txt['user_settings_password'] = 'Wachtwoord';
$txt['user_settings_password_info'] = 'Vul hier het wachtwoord in dat je wilt gebruiken. Onthoud dit goed!';
$txt['user_settings_again'] = 'Wachtwoord';
$txt['user_settings_again_info'] = '(controle)';
$txt['user_settings_email'] = 'E-mailadres';
$txt['user_settings_email_info'] = 'Vul je e-mailadres in. <strong>Dit moet een geldig e-mailadres zijn.</strong>';
$txt['user_settings_database'] = 'Databasewachtwoord';
$txt['user_settings_database_info'] = 'Uit veiligheidsoverwegingen dien je het databasewachtwoord op te geven om een beheeraccount aan te kunnen maken.';
$txt['user_settings_skip'] = 'Overslaan';
$txt['user_settings_skip_sure'] = 'Weet je zeker dat je het aanmaken van een beheerderaccount wilt overslaan?';
$txt['user_settings_proceed'] = 'Klaar';

$txt['ftp_checking_writable'] = 'Checking if files are writable';
$txt['ftp_setup'] = 'FTP-verbindingsinformatie';
$txt['ftp_setup_info'] = 'Er kan een verbinding worden gemaakt via FTP om de bestanden die schrijfbaar moeten worden gemaakt als zodanig te CHMOD\'en. Als dit niet wekrt, zul je dit handmatig moeten doen met een FTP-programma. <strong>Let op:</strong> SSL wordt momenteel niet ondersteund.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'This should be the server address and port for your FTP server.';
$txt['ftp_port'] = 'Poort';
$txt['ftp_username'] = 'User name';
$txt['ftp_username_info'] = 'The user name to login with. <em>This will not be saved anywhere.</em>';
$txt['ftp_password'] = 'Wachtwoord';
$txt['ftp_password_info'] = 'Het wachtwoord om mee in te loggen. <em>Dit wordt nergens opgeslagen.</em>';
$txt['ftp_path'] = 'Installatiepad';
$txt['ftp_path_info'] = 'Dit is het <em>relatieve</em> pad dat je gebruikt in je FTP-server.';
$txt['ftp_path_found_info'] = 'Het pad in het veld hierboven is automatisch gedetecteerd.';
$txt['ftp_connect'] = 'Verbinden';
$txt['ftp_setup_why'] = 'Waarvoor is deze stap?';
$txt['ftp_setup_why_info'] = 'Some files need to be writable for ElkArte to work properly.  This step allows you to let the installer make them writable for you.  However, in some cases it won\'t work - in that case, please make the following files 777 (writable, 755 on some hosts):';
$txt['ftp_setup_again'] = 'om te testen of deze bestanden schrijfbaar zijn.';

$txt['error_php_too_low'] = 'Warning!  You do not appear to have a version of PHP installed on your webserver that meets ElkArte\'s <strong>minimum installations requirements</strong>.<br />If you are not the host, you will need to ask your host to upgrade, or use a different host - otherwise, please upgrade PHP to a recent version.<br /><br />If you know for a fact that your PHP version is high enough you may continue, although this is strongly discouraged.';
$txt['error_missing_files'] = 'Kan belangrijke installatiebestanden in de directory waar dit script in staat niet vinden!<br /><br />Zorg ervoor dat je het gehele pakket uploadt, inclusief het .sql bestand, en probeer het opnieuw.';
$txt['error_session_save_path'] = 'Informeer je host dat de <strong>session.save_path gespecificeerd in php.ini</strong> niet juist is! Het moet worden aangepast naar een directory die <strong>bestaat</strong>, en <strong>schrijfbaar</strong> is voor de gebruiker waarop PHP draait.<br />';
$txt['error_windows_chmod'] = 'You\'re on a windows server, and some crucial files are not writable.  Please ask your host to give <strong>write permissions</strong> to the user PHP is running under for the files in your ElkArte installation.  The following files or directories need to be writable:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Kan geen verbinding maken met de FTP-server met deze gegevens.';
$txt['error_db_file'] = 'SMF kan het databasebronscript niet vinden! Ben er zeker van dat het bestand %1$s in je forumbronmap is geplaatst.';
$txt['error_db_connect'] = 'Kan geen verbinding maken met de database met deze gegevens.<br /><br />Als je niet weet welke gegevens je moet ingeven, neem dan contact op met je host.';
$txt['error_db_too_low'] = 'The version of your database server is very old and does not meet ElkArte\'s minimum requirements.<br /><br />Please ask your host to either upgrade it or supply a new one, and if they won\'t, please try a different host.';
$txt['error_db_database'] = 'The installer was unable to access the &quot;<em>%1$s</em>&quot; database.  With some hosts, you have to create the database in your administration panel before ElkArte can use it.  Some also add prefixes - like your username - to your database names.';
$txt['error_db_queries'] = 'Enkele queries zijn niet goed uitgevoerd. Dit kan worden veroorzaakt door een niet-ondersteunde (ontwikkelings- of oude) version van je databasesoftware.<br /><br />Technische informatie over de queries:';
$txt['error_db_queries_line'] = 'Regel #';
$txt['error_db_missing'] = 'The installer was unable to detect database support in PHP that ElkArte can utilize.  Please ask your host to ensure that PHP was compiled with the desired database, or that the proper php extension is being loaded.  Currently ElkArte supports the:  &quot;%1$s&quot; extensions';
$txt['error_db_script_missing'] = 'Het installatiescript kon geen installatiebestanden voor het geselecteerde databasesysteem vinden. Controleer of je de benodigde installatiebestanden hebt geupload naar je forummap, bijvoorbeeld &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Het installatiescript kon niet detecteren of sessies worden ondersteund in de PHP-installatie van deze server. Informeer bij je webhost om er zeker van te zijn dat PHP is gecompileerd met sessieondersteuning (in feite moet het expliciet zonder dit worden gecompileerd).'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'De wachtwoorden die je hebt opgegeven wijken af van elkaar!';
$txt['error_user_settings_no_password'] = 'Je wachtwoord moet ten minste vier karakters lang zijn.';
$txt['error_user_settings_taken'] = 'Sorry, a member is already registered with that user name and/or email address.<br /><br />A new account has not been created.';
$txt['error_user_settings_query'] = 'Er is een fout opgetreden in de database bij het aanmaken van de account. De fout was:';
$txt['error_subs_missing'] = 'Unable to find the sources/Subs.php file.  Please make sure it was uploaded properly, and then try again.';
$txt['error_db_alter_priv'] = 'The database account you specified does not have permission to ALTER, CREATE, and/or DROP tables in the database; this is necessary for ElkArte to function properly.';
$txt['error_versions_do_not_match'] = 'The installer has detected another version of ElkArte already installed with the specified information.  If you are trying to upgrade, you should use the upgrader, not the installer.<br /><br />Otherwise, you may wish to use different information, or create a backup and then delete the data currently in the database.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'The current version of your database doesn\'t support the use of the UTF-8 character set. You can not install ElkArte';
$txt['error_valid_email_needed'] = 'Het is noodzakelijk dat je een geldig e-mailadres invoert.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Waarschuwing!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Het is nodig een bestandsnaam in te vullen voor de SQLite-database.';
$txt['error_db_prefix_numeric'] = 'Het geselecteerde databasetype ondersteunt geen numerieke voorvoegsels.';
$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';
$txt['error_username_too_long'] = 'User name must be less than 25 characters long.';
$txt['error_username_left_empty'] = 'User name field was left empty.';
$txt['error_db_filename_exists'] = 'De database die je probeert aan te maken bestaat reeds. Verwijder het huidige databasebestand of kies een andere naam.';
$txt['error_db_prefix_reserved'] = 'Het ingevoerde voorvoegsel is gereserveerd. Gebruik een ander voorvoegsel.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade Utility';
$txt['upgrade_warning'] = 'Waarschuwing!';
$txt['upgrade_critical_error'] = 'Kritieke fout!';
$txt['upgrade_continue'] = 'Doorgaan';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Overslaan';
$txt['upgrade_note'] = 'Opmerking!';
$txt['upgrade_step'] = 'Stap';
$txt['upgrade_steps'] = 'Stappen';
$txt['upgrade_progress'] = 'Voortgang';
$txt['upgrade_overall_progress'] = 'Totale voortgang';
$txt['upgrade_step_progress'] = 'Voortgang van stap';
$txt['upgrade_time_elapsed'] = 'Verstreken tijd';
$txt['upgrade_time_mins'] = 'minuten';
$txt['upgrade_time_secs'] = 'seconden';

$txt['upgrade_incomplete'] = 'Onvoltooid';
$txt['upgrade_not_quite_done'] = 'Nog niet klaar!';
$txt['upgrade_paused_overload'] = 'Het upgraden is gepauzeerd om overbelasting van je server te voorkomen. Geen zorgen, er is niets mis - klik op de knop <label for="contbutt">\'doorgaan\'</label> hieronder om verder te gaan.';

$txt['upgrade_ready_proceed'] = 'Thank you for choosing to upgrade to ElkArte %1$s. All files appear to be in place, and we\'re ready to proceed.';

$txt['upgrade_error_script_js'] = 'The upgrade script cannot find script.js or it is out of date. Make sure your theme paths are correct. You can download a settings check and repair script from <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte tools</a>.';

$txt['upgrade_warning_lots_data'] = 'Het upgradescript heeft gedetecteerd dat je forum veel data bevat die ge&uuml;pgrade moet worden. Dit proces zal aardig wat tijd in beslag nemen, afhankelijk van de servercapaciteit en de forumgrootte; voor erg grote fora (~300.000 berichten) kan het voltooien van dit proces enkele uren duren.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';