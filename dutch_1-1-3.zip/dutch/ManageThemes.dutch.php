<?php
// Version: 1.1; ManageThemes

$txt['themeadmin_explain'] = 'Themes create the different look and feel of your forum. The Global Theme Settings section permits any site administrator to select a theme for the site default theme. Admins can also enable members to select any installed theme for their use and to enable selectable themes. The Install a New Theme section is how the site administration installs a theme.';
$txt['themeadmin_manage'] = 'Beheer en installeer';
$txt['theme_forum_theme'] = 'Global Theme Settings';
$txt['theme_allow'] = 'Sta leden toe hun eigen thema te selecteren?';
$txt['theme_guests'] = 'Overall forum default theme:';
$txt['theme_select'] = 'kies...';
$txt['theme_reset'] = 'Reset all members to the following theme:';
$txt['theme_nochange'] = 'Geen verandering';
$txt['theme_forum_default'] = 'Forumstandaard';

$txt['theme_remove'] = 'De&iuml;nstalleer';
$txt['theme_remove_confirm'] = 'Are you sure you want to uninstall this theme?';

$txt['theme_install'] = 'Installeer een nieuw thema';
$txt['theme_install_file'] = 'From a local archive: (e.g. .zip or .tar.gz)';
$txt['theme_install_dir'] = 'From a directory on the host server:';
$txt['theme_install_error'] = 'That theme directory doesn\'t exist, or doesn\'t contain a theme.';
$txt['theme_install_write_error'] = 'The themes directory must be writable to continue.';
$txt['theme_install_go'] = 'Installeer';
$txt['theme_install_new'] = 'Create a copy of the ElkArte default theme named:';
$txt['theme_install_new_confirm'] = 'Weet je zeker dat je dit nieuwe thema wilt installeren?';
$txt['theme_install_writable'] = 'Warning - you cannot create or install a new theme as your themes directory is not currently writable.';
$txt['theme_install_general'] = 'The theme doesn\'t seem to be where it should, please double check the information you provided.';
$txt['theme_installed'] = 'Installatie succesvol!';
$txt['theme_installed_message'] = 'is met succes ge&iuml;nstalleerd.';

$txt['theme_pick'] = 'Kies een thema...';
$txt['theme_preview'] = 'Bekijk thema';
$txt['theme_set'] = 'Gebruik dit thema';
$txt['theme_user'] = 'persoon gebruikt dit thema.';
$txt['theme_users'] = 'personen gebruiken dit thema.';
$txt['theme_pick_variant'] = 'Select Variant:';

$txt['theme_edit'] = 'Bewerk thema';
$txt['theme_edit_style'] = 'Pas de stylesheets aan. (kleuren, fonts, enz.)';
$txt['theme_edit_index'] = 'Pas de index template aan (de hoofd template)';
$txt['theme_edit_no_save'] = 'This file cannot be saved because it is not writable.  Please make sure the following file is 777 or has the proper permissions';
$txt['theme_edit_save'] = 'Opslaan';
$txt['theme_edit_not_writable'] = 'Niet beschrijfbaar';

$txt['theme_global_description'] = 'Dit is het standaardthema, wat betekent dat je thema zal veranderen als de beheerder het standaardthema wijzigt.';

$txt['theme_url_config'] = 'Thema-URL\'s en -instellingen';
$txt['theme_variants'] = 'Themavarianten';
$txt['theme_options'] = 'Themaopties en -voorkeuren';
$txt['actual_theme_name'] = 'Naam van dit thema: ';
$txt['actual_theme_dir'] = 'De map van dit thema: ';
$txt['actual_theme_url'] = 'De URL van dit thema: ';
$txt['actual_images_url'] = 'URL naar de plaatjes van dit thema: ';

$txt['theme_variants_default'] = 'Default theme variant:';
$txt['theme_variants_user_disable'] = 'Disable user variant selection.';

$txt['site_slogan'] = 'Site slogan:';
$txt['site_slogan_desc'] = '(Add your own text for a slogan here.)';
$txt['header_layout'] = 'Header layout:';
$txt['header_layout_desc'] = '(This setting allows you to select one of three layouts for the header.)';
$txt['header_layout_default_name'] = 'Default:';
$txt['header_layout_default_desc'] = 'The logo is placed on the right and the name of the community on the left.';
$txt['header_layout_logo_only_name'] = 'Only logo:';
$txt['header_layout_logo_only_desc'] = 'Only the logo is displayed, in a centered position.';
$txt['header_layout_inverted_name'] = 'Logo on the left:';
$txt['header_layout_inverted_desc'] = 'Similar to Default, but with logo and name inverted (i.e. name on the right, logo on the left).';
$txt['header_layout_default'] = 'Standaard';
$txt['header_layout_logo_only'] = 'Only logo';
$txt['header_layout_inverted'] = 'Logo on the left';
$txt['forum_width'] = 'Forum width:';
$txt['forum_width_desc'] = '(Sets the forum width. Examples: 950px, 80%, 1240px.)';

$txt['enable_news'] = 'News line in the forum header:';
$txt['enable_news_off'] = 'Off';
$txt['enable_news_random'] = 'Random';
$txt['enable_news_fader'] = 'Fader';
$txt['enable_news_off_name'] = 'Off:';
$txt['enable_news_off_desc'] = 'No news shown.';
$txt['enable_news_random_name'] = 'Random:';
$txt['enable_news_random_desc'] = 'One news shown chosen at random.';
$txt['enable_news_fader_name'] = 'Fader:';
$txt['enable_news_fader_desc'] = 'All the news are displayed sequentially.';

$txt['show_group_key'] = 'Show group key on board index.';
$txt['additional_options_collapsible'] = 'Enable collapsible additional post options.';
$txt['who_display_viewing'] = 'Show who is viewing the board index and posts:';
$txt['who_display_viewing_off'] = 'Niet tonen';
$txt['who_display_viewing_numbers'] = 'Toon alleen aantallen';
$txt['who_display_viewing_names'] = 'Toon ledennamen';
$txt['show_stats_index'] = 'Show statistics on board index.';
$txt['latest_members'] = 'Show latest member on board index.';
$txt['last_modification'] = 'Show last modification date on modified posts.';
$txt['user_avatars'] = 'Show user avatars in message view.';
$txt['member_list_bar'] = 'Laat de ledenlijstbalk zien op de boardindex';
$txt['current_pos_text_img'] = 'Show current position in forum as link instead of text.';
$txt['show_view_profile_button'] = 'Show view profile button under post.';
$txt['enable_mark_as_read'] = 'Enable and show \'Mark as Read\' buttons.';
$txt['header_logo_url'] = 'Logo image URL:';
$txt['header_logo_url_desc'] = '(Leave blank to show forum name or default logo.)';

$txt['recent_post_topics'] = 'Show recent posts or recent topics on board index.';
$txt['show_recent_topics'] = 'Show recent topics';
$txt['show_recent_posts'] = 'Show recent posts';
$txt['number_recent_posts'] = 'Number of recent posts or topics to display on board index:';
$txt['number_recent_posts_desc'] = '(To disable the recent posts/topics bar set this value to zero.)';
$txt['hide_post_group'] = 'Hide post group titles for grouped members.';
$txt['hide_post_group_desc'] = '(Enabling this will not display a member\'s post group title on the message view if they are assigned to a non-post based group.)';

$txt['theme_options_defaults'] = 'Dit zijn de standaardwaarden voor sommige lidspecifieke instellingen. Het veranderen hiervan zal van invloed zijn op nieuwe leden en gasten.';
$txt['theme_options_title'] = 'Verander of verwijder standaardinstellingen';

$txt['themeadmin_title'] = 'Theme Management and Options';
$txt['themeadmin_description'] = 'Hier kun je de instellingen voor je thema\'s veranderen, de te selecteren thema\'s wijzigen, de ledenopties herstellen, etc.';
$txt['themeadmin_admin_desc'] = 'Themes provide the different \'looks and feels\' of your forum. Theme Management and Options allow you to install new site themes, change the default theme, reset all members to use a certain theme, and choose other settings related to theme selection. Remember to look at the theme settings for your different themes for their individual layout options.';
$txt['themeadmin_list_desc'] = 'In the Theme Settings area you can view the list of themes that you have installed, change their directory paths and settings, and uninstall them.';
$txt['themeadmin_reset_desc'] = 'In the Member Options area you have the ability to change theme-specific options that affect all members. You will only see those themes that have their own set of option settings.';
$txt['themeadmin_edit_desc'] = 'In the Modify Themes area you can alter the stylesheet and source code of your installed themes. You will need a basic understanding of CSS and PHP to effectively change a theme and not break your forum at the same time.';
$txt['themeadmin_modify_styles'] = 'Changing a themes style is risky so be certain of what you are doing. Always have a backup copy of the theme directory that you are working in to use to recover from an error with. For help with this before you start, visit the <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">ElkArte Community</a>.';

$txt['themeadmin_list_heading'] = 'Thema-instellingen';
$txt['themeadmin_list_tip'] = 'The layout settings may be different for each installed theme. Edit the installed themes to set their individual options, change their directory or URL settings, or to find other options.';
$txt['themeadmin_list_theme_dir'] = 'Theme directory: (templates)';
$txt['themeadmin_list_invalid'] = '(Warning! this path is not correct.)';
$txt['themeadmin_list_theme_url'] = 'URL to above directory:';
$txt['themeadmin_list_images_url'] = 'URL to images directory:';
$txt['themeadmin_list_reset'] = 'Herstel thema-URLs en -mappen';
$txt['themeadmin_list_reset_dir'] = 'Base path to Themes directory:';
$txt['themeadmin_list_reset_url'] = 'Base URL to the same directory:';
$txt['themeadmin_list_reset_go'] = 'Probeer alle thema\'s te herstellen';

$txt['themeadmin_reset_tip'] = 'Each theme may have custom options available for selection by your members. These include options like &quot;quick reply&quot;, avatars, signatures, layout options and other similar options.  This is where you can change the defaults or reset everyone\'s options.<br /><br />Remember this: A theme may be designed with some settings as the default. In which case you will not see a setting for those options.';
$txt['themeadmin_reset_defaults'] = 'Stel standaard (gast)opties voor dit thema in';
$txt['themeadmin_reset_defaults_current'] = 'opties momenteel ingesteld';
$txt['themeadmin_reset_members'] = 'Verander huidige instellingen van alle leden die dit thema gebruiken';
$txt['themeadmin_reset_remove'] = 'Verwijder de instellingen van alle leden en gebruik de standaardopties';
$txt['themeadmin_reset_remove_current'] = 'leden die momenteel hun eigen opties gebruiken';
// Don't use entities in the below string.
$txt['themeadmin_reset_remove_confirm'] = 'Weet je zeker dat je alle themaopties wilt verwijderen?\\nDit zou ook sommige aangepaste profielvelden kunnen wissen.';
$txt['themeadmin_reset_options_info'] = 'The options below will reset options for <em>everyone</em>.  To change an option, select &quot;change&quot; in the box next to it, and then select a value for it.  To use the default, select &quot;default&quot;.  Otherwise, use &quot;don\'t change&quot; to keep it as-is.';
$txt['themeadmin_reset_options_change'] = 'Verander';
$txt['themeadmin_reset_options_none'] = 'niet wijzigen';
$txt['themeadmin_reset_options_default'] = 'Standaard';

$txt['themeadmin_edit_browse'] = 'Bekijk de templates en bestanden voor dit thema.';
$txt['themeadmin_edit_style'] = 'Wijzig de stylesheets van dit thema.';
$txt['themeadmin_edit_copy_template'] = 'Kopieer een template van het thema waarop dit gebaseerd is.';
$txt['themeadmin_edit_exists'] = 'bestaat reeds';
$txt['themeadmin_edit_do_copy'] = 'kopieer';
$txt['themeadmin_edit_copy_warning'] = 'When the system needs a template or language file which is not in the current theme, it looks in the theme it is based on, or the default theme.<br />Unless you need to modify a template, it\'s better not to copy it.';
$txt['themeadmin_edit_copy_confirm'] = 'Weet je zeker dat je deze template wilt kopi&euml;ren?';
$txt['themeadmin_edit_overwrite_confirm'] = 'Are you sure you want to copy this template over the one that already exists?\nThis will OVERWRITE any changes you\\\'ve made';
$txt['themeadmin_edit_no_copy'] = '<em>(kan niet kopi&euml;ren)</em>';
$txt['themeadmin_edit_filename'] = 'Bestandsnaam';
$txt['themeadmin_edit_modified'] = 'Laatst gewijzigd';
$txt['themeadmin_edit_size'] = 'Grootte';
$txt['themeadmin_edit_error'] = 'Het bestand dat je probeerde op te slaan, genereerde de volgende fout:';
$txt['themeadmin_edit_on_line'] = 'Beginning on line:';
$txt['themeadmin_edit_preview'] = 'Bekijken';
$txt['themeadmin_selectable'] = 'Themes the user is permitted to select:';
$txt['themeadmin_themelist_link'] = 'Show the list of installed themes';

// Strings for the variants
$txt['variant_light'] = 'ElkArte Light';
$txt['variant_besocial'] = 'ElkArte Be Social!';
