<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... no idea, sorry</em>';
$txt['who_admin'] = 'Viewing the admin portal';
$txt['who_moderate'] = 'Viewing the moderator portal';
$txt['who_generic'] = 'Viewing the %1$s';
$txt['who_unknown'] = '<em>Onbekende actie</em>';
$txt['who_user'] = 'lid';
$txt['who_time'] = 'Tijd';
$txt['who_action'] = 'Actie';
$txt['who_show1'] = 'Toon ';
$txt['who_show_members_only'] = 'alleen leden';
$txt['who_show_guests_only'] = 'alleen gasten';
$txt['who_show_spiders_only'] = 'alleen spiders';
$txt['who_show_all'] = 'iedereen';
$txt['who_no_online_spiders'] = 'Er zijn momenteel geen spiders online.';
$txt['who_no_online_guests'] = 'Er zijn momenteel geen gasten online.';
$txt['who_no_online_members'] = 'Er zijn momenteel geen leden online.';

$txt['whospider_login'] = 'Bekijkt de inlogpagina.';
$txt['whospider_register'] = 'Bekijkt de registratiepagina.';
$txt['whospider_reminder'] = 'Bekijkt de herinneringspagina.';

$txt['whoall_activate'] = 'Activeert zijn/haar account.';
$txt['whoall_buddy'] = 'Past zijn/haar vriendenlijst aan.';
$txt['whoall_coppa'] = 'Vult het toestemmingsformulier van ouder/voogd in.';
$txt['whoall_credits'] = 'Bekijkt de creditspagina.';
$txt['whoall_emailuser'] = 'Verstuurt een e-mail naar een lid.';
$txt['whoall_groups'] = 'Bekijkt een ledengroeppagina.';
$txt['whoall_help'] = 'Viewing the <a href="{help_url}">help page</a>.';
$txt['whoall_quickhelp'] = 'Bekijkt de beheerdershelppagina.';
$txt['whoall_pm'] = 'Bekijkt zijn/haar berichten.';
$txt['whoall_auth'] = 'Logt in op het forum.';
$txt['whoall_login'] = 'Bekijkt de inlogpagina.';
$txt['whoall_login2'] = 'Bekijkt de inlogpagina.';
$txt['whoall_logout'] = 'Logt uit op het forum.';
$txt['whoall_markasread'] = 'Markeert topics als gelezen.';
$txt['whoall_mentions'] = 'Viewing their mentions list.';
$txt['whoall_modifykarma_applaud'] = 'Verhoogt het karma van een lid.';
$txt['whoall_modifykarma_smite'] = 'Verlaagt het karma van een lid.';
$txt['whoall_news'] = 'Bekijkt het nieuws.';
$txt['whoall_notify'] = 'Verandert notificatie-instellingen.';
$txt['whoall_notifyboard'] = 'Verandert notificatie-instellingen.';
$txt['whoall_openidreturn'] = 'Logt in met behulp van OpenID.';
$txt['whoall_quickmod'] = 'Modereert een board.';
$txt['whoall_recent'] = 'Viewing a <a href="{recent_url}">list of recent topics</a>.';
$txt['whoall_register'] = 'Registreert een account op het forum.';
$txt['whoall_reminder'] = 'Vraagt een wachtwoordherinnering aan.';
$txt['whoall_reporttm'] = 'Meldt een bericht aan de moderators.';
$txt['whoall_spellcheck'] = 'Gebruikt spellingscontrole';
$txt['whoall_unread'] = 'Bekijkt ongelezen berichten sinds het laatste bezoek.';
$txt['whoall_unreadreplies'] = 'Bekijkt ongelezen antwoorden sinds het laatste bezoek.';
$txt['whoall_who'] = 'Viewing <a href="{who_url}">Who\'s Online</a>.';

$txt['whoall_collapse_collapse'] = 'Klapt een categorie in.';
$txt['whoall_collapse_expand'] = 'Klapt een categorie uit.';
$txt['whoall_pm_removeall'] = 'Verwijdert al zijn/haar berichten.';
$txt['whoall_pm_send'] = 'Stuurt een bericht.';
$txt['whoall_pm_send2'] = 'Stuurt een bericht.';

$txt['whotopic_announce'] = 'Announcing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Keurt een bijlage goed.';
$txt['whotopic_dlattach'] = 'Bekijkt een bijlage.';
$txt['whotopic_deletemsg'] = 'Verwijdert een bericht.';
$txt['whotopic_editpoll'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Modifying a post in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Liking a message in the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Locking the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Locking the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Merging the topic &quot;<a href="%1$s">%2$s</a>&quot; with another topic.';
$txt['whotopic_movetopic'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_movetopic2'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_post'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Printing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderating the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Removing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Removing the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Sending the topic &quot;<a href="%1$s">%2$s</a>&quot; to a friend.';
$txt['whotopic_splittopics'] = 'Splitting the topic &quot;<a href="%1$s">%2$s</a>&quot; into two topics.';
$txt['whotopic_sticky'] = 'Pinned the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Stopped watching a topic.';
$txt['whotopic_vote'] = 'Voting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Started watching a topic.';

$txt['whopost_quotefast'] = 'Quoting a post from &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Wijzigt de registratieovereenkomst.';
$txt['whoadmin_featuresettings'] = 'Bewerkt de forumfeatures en opties.';
$txt['whoadmin_modlog'] = 'Bekijkt het moderatielog.';
$txt['whoadmin_serversettings'] = 'Wijzigt de foruminstellingen.';
$txt['whoadmin_packageget'] = 'Haalt pakketten op.';
$txt['whoadmin_packages'] = 'Bekijkt de pakketbeheerder.';
$txt['whoadmin_permissions'] = 'Wijzigt forumrechten.';
$txt['whoadmin_pgdownload'] = 'Download een package.';
$txt['whoadmin_theme'] = 'Wijzigt thema-instellingen.';
$txt['whoadmin_trackip'] = 'Traceert een IP-adres.';

$txt['whoallow_manageboards'] = 'Bewerkt boards en categorie&euml;n.';
$txt['whoallow_admin'] = 'Viewing the <a href="{admin_url}">administration center</a>.';
$txt['whoallow_ban'] = 'Wijzigt de banlijst.';
$txt['whoallow_boardrecount'] = 'Herberekent de forumtotalen.';
$txt['whoallow_calendar'] = 'Viewing the <a href="{calendar_url}">calendar</a>.';
$txt['whoallow_editnews'] = 'Wijzigt het nieuws.';
$txt['whoallow_mailing'] = 'Verstuurt een nieuwsbrief.';
$txt['whoallow_maintain'] = 'Voert routine forumonderhoud uit.';
$txt['whoallow_manageattachments'] = 'Beheer de bijlagen.';
$txt['whoallow_moderate'] = 'Viewing the <a href="{moderate_url}">Moderation Center</a>.';
$txt['whoallow_memberlist'] = 'Viewing the <a href="{memberlist_url}">member list</a>.';
$txt['whoallow_optimizetables'] = 'Optimaliseert de databasetabellen.';
$txt['whoallow_repairboards'] = 'Repareert de databasetabellen.';
$txt['whoallow_search'] = '<a href="{search_url}">Searching</a> the forum.';
$txt['whoallow_search_results'] = 'Bekijkt de zoekresultaten.';
$txt['whoallow_setcensor'] = 'Wijzigt censuurteksten.';
$txt['whoallow_setreserve'] = 'Wijzigt de gereserveerde namen.';
$txt['whoallow_stats'] = 'Viewing the <a href="{stats_url}">forum stats</a>.';
$txt['whoallow_viewErrorLog'] = 'Bekijkt het foutenlog.';
$txt['whoallow_viewmembers'] = 'Bekijkt de lijst met leden.';

$txt['who_topic'] = 'Viewing the topic <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Viewing the board <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Viewing the board index of <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Viewing <a href="%1$s">%2$s</a>\'s profile.';
$txt['who_profile'] = 'Editing the profile of <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Posting a new topic in <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Posting a new poll in <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Email starting a new topic in <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Email posting in <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Sending a personal message by email.';

// Credits text
$txt['credits'] = 'Credits';
$txt['credits_intro'] = 'ElkArte is 100% free and open-source. We encourage and support an active, open community that accepts contributions from the public.  We want to thank everyone who supported the project by providing code, feedback, bug reports, and opinions, as none of this would have been possible without you.  We also want to specially acknowledge <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, the project that ElkArte was born from.';
$txt['credits_contributors'] = 'Contributors';
$txt['credits_and'] = 'en';
$txt['credits_copyright'] = 'Copyright';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Add-ons';
$txt['credits_software_graphics'] = 'Software/Graphics';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Graphics';
$txt['credits_fonts'] = 'Fonts';
$txt['credits_groups_contrib'] = 'Contributors';
$txt['credits_contrib_list'] = 'For a complete list of the many individuals that contributed to the design and implementation of Elkarte, please refer to the official GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">list of contributors.</a>';
$txt['credits_license'] = 'License';
$txt['credits_copyright'] = 'Copyright';
$txt['credits_version'] = 'Versie';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Vertalers';
$txt['credits_translators_message'] = 'Thank you for your efforts which make it possible for people all around the world to use ElkArte.  For a complete list please refer to the offical Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">list of contributors.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';