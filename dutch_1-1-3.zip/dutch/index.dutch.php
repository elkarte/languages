<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'nl_NL.utf8';
$txt['lang_dictionary'] = 'nl';
$txt['lang_spelling'] = 'american';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'zondag';
$txt['monday'] = 'maandag';
$txt['tuesday'] = 'dinsdag';
$txt['wednesday'] = 'woensdag';
$txt['thursday'] = 'donderdag';
$txt['friday'] = 'vrijdag';
$txt['saturday'] = 'zaterdag';

$txt['sunday_short'] = 'Sun';
$txt['monday_short'] = 'Mon';
$txt['tuesday_short'] = 'Tue';
$txt['wednesday_short'] = 'Wed';
$txt['thursday_short'] = 'Thu';
$txt['friday_short'] = 'Fri';
$txt['saturday_short'] = 'Sat';

$txt['january'] = 'januari';
$txt['february'] = 'februari';
$txt['march'] = 'maart';
$txt['april'] = 'april';
$txt['may'] = 'mei';
$txt['june'] = 'juni';
$txt['july'] = 'juli';
$txt['august'] = 'augustus';
$txt['september'] = 'september';
$txt['october'] = 'oktober';
$txt['november'] = 'november';
$txt['december'] = 'december';

$txt['january_titles'] = 'januari';
$txt['february_titles'] = 'februari';
$txt['march_titles'] = 'maart';
$txt['april_titles'] = 'april';
$txt['may_titles'] = 'mei';
$txt['june_titles'] = 'juni';
$txt['july_titles'] = 'juli';
$txt['august_titles'] = 'augustus';
$txt['september_titles'] = 'september';
$txt['october_titles'] = 'oktober';
$txt['november_titles'] = 'november';
$txt['december_titles'] = 'december';

$txt['january_short'] = 'Jan';
$txt['february_short'] = 'Feb';
$txt['march_short'] = 'Mar';
$txt['april_short'] = 'Apr';
$txt['may_short'] = 'mei';
$txt['june_short'] = 'Jun';
$txt['july_short'] = 'Jul';
$txt['august_short'] = 'Aug';
$txt['september_short'] = 'Sep';
$txt['october_short'] = 'Oct';
$txt['november_short'] = 'Nov';
$txt['december_short'] = 'Dec';

$txt['time_am'] = 'am';
$txt['time_pm'] = 'pm';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Index';
$txt['community'] = 'Community';
// Sub menu labels
$txt['help'] = 'Help';
$txt['search'] = 'Zoekfunctie';
$txt['calendar'] = 'Kalender';
$txt['members'] = 'Leden';
$txt['recent_posts'] = 'Recente berichten';

$txt['admin'] = 'Beheer';
// Sub menu labels
$txt['errlog'] = 'Foutenlog';
$txt['package'] = 'Pakketbeheerder';
$txt['edit_permissions'] = 'Permissies';
$txt['modSettings_title'] = 'Foruminstellingen';

$txt['moderate'] = 'Moderatie';
// Sub menu labels
$txt['modlog_view'] = 'Moderatielog';
$txt['mc_emailerror'] = 'Unapproved Emails';
$txt['mc_reported_posts'] = 'Gerapporteerde posts';
$txt['mc_reported_pms'] = 'Reported Personal Messages';
$txt['mc_unapproved_attachments'] = 'Niet-goedgekeurde bijlagen';
$txt['mc_unapproved_poststopics'] = 'Niet-goedgekeurde posts en topics';

$txt['pm_short'] = 'Mijn berichten';
// Sub menu labels
$txt['pm_menu_read'] = 'Lees je berichten';
$txt['pm_menu_send'] = 'Stuur een bericht';

$txt['account_short'] = 'My Account';
// Sub menu labels
$txt['profile'] = 'Profiel';
$txt['mydrafts'] = 'My Drafts';
$txt['summary'] = 'Overzicht';
$txt['theme'] = 'Lay-out-voorkeuren';
$txt['account'] = 'Accountinstellingen';
$txt['forumprofile'] = 'Forumprofiel';

$txt['view_unread_category'] = 'Nieuw bericht';
$txt['view_replies_category'] = 'New Replies';

$txt['login'] = 'Log in';
$txt['register'] = 'Registreren';
$txt['logout'] = 'Log out';
// End main menu strings.

$txt['save'] = 'Opslaan';

$txt['modify'] = 'Bewerk';
$txt['forum_index'] = '%1$s - Forumindex';
$txt['board_name'] = 'Forumnaam';
$txt['posts'] = 'berichten';

$txt['member_postcount'] = 'berichten';
$txt['no_subject'] = '(Geen onderwerp)';
$txt['view_profile'] = 'Bekijk profiel';
$txt['guest_title'] = 'Gast';
$txt['author'] = 'Auteur';
$txt['on'] = 'op';
$txt['remove'] = 'Verwijder';
$txt['start_new_topic'] = 'Begin een nieuw topic';

// Use numeric entities in the below string.
$txt['username'] = 'Gebruikersnaam';
$txt['password'] = 'Wachtwoord';

$txt['username_no_exist'] = 'Deze gebruikersnaam bestaat niet.';
$txt['no_user_with_email'] = 'Er zijn geen gebruikersnamen verbonden aan dat e-mailadres.';

$txt['board_moderator'] = 'Board-moderator';
$txt['remove_topic'] = 'Verwijder';
$txt['topics'] = 'Topics';
$txt['modify_msg'] = 'Bewerk bericht';
$txt['name'] = 'Naam';
$txt['email'] = 'E-mail';
$txt['user_email_address'] = 'E-mailadres';
$txt['subject'] = 'Onderwerp';
$txt['message'] = 'Bericht';
$txt['redirects'] = 'keer aangeklikt';

$txt['choose_pass'] = 'Kies wachtwoord';
$txt['verify_pass'] = 'Herhaal wachtwoord';
$txt['position'] = 'Positie';
$txt['notify_announcements'] = 'Sign up to receive important site news by email';

$txt['profile_of'] = 'Bekijk profiel van';
$txt['total'] = 'Totaal';
$txt['posts_made'] = 'berichten';
$txt['topics_made'] = 'Topics';
$txt['website'] = 'Website';
$txt['contact'] = 'Contact Us';
$txt['warning_status'] = 'Waarschuwingsstatus';
$txt['user_warn_watch'] = 'Gebruiker staat op moderatietoezichtlijst';
$txt['user_warn_moderate'] = 'Gebruikersposts komen op goedkeuringslijst';
$txt['user_warn_mute'] = 'Gebruiker is verbannen van posten';
$txt['warn_watch'] = 'Toezicht';
$txt['warn_moderate'] = 'Gemodereerd';
$txt['warn_mute'] = 'Stilgelegd';
$txt['warning_issue'] = 'Warn';

$txt['message_index'] = 'Berichtenindex';
$txt['news'] = 'Nieuws';
$txt['page'] = 'Page';
$txt['prev'] = 'previous';
$txt['next'] = 'next';

$txt['post'] = 'Verzenden';
$txt['error_occurred'] = 'An Error Has Occurred';
$txt['send_error_occurred'] = 'An error has occurred, <a href="{href}">please click here to try again</a>.';
$txt['require_field'] = 'This is a required field.';
$txt['started_by'] = 'Started by author';
$txt['topic_started_by'] = 'Started by %1$s';
$txt['topic_started_by_in'] = 'Started by %1$s in %2$s';
$txt['replies'] = 'Reacties';
$txt['last_post'] = 'Laatste bericht';
$txt['first_post'] = 'First post';
$txt['last_poster'] = 'Last post author';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s </span><span class="board_lastposter">by %1$s</span><span class="board_lasttime"><strong>Last post: </strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s Posts in %2$s Topics by %3$s Members';
$txt['show'] = 'Show';
$txt['hide'] = 'Hide';
$txt['sort_by'] = 'Sort By';
$txt['sort_asc'] = 'Sort ascending';
$txt['sort_desc'] = 'Sort descending';

$txt['admin_login'] = 'Administration Log in';
// Use numeric entities in the below string.
$txt['topic'] = 'Topic';
$txt['help'] = 'Help';
$txt['notify'] = 'Notificatie';
$txt['unnotify'] = 'Notificatie opzeggen';
$txt['notify_request'] = 'Wil je een e-mail ontvangen als iemand antwoord geeft op dit topic?';
// Use numeric entities in the below string.
$txt['regards_team'] = "Regards,\nThe {forum_name_html_unsafe} Team.";
$txt['notify_replies'] = 'Notificatie bij reacties';
$txt['move_topic'] = 'Verplaatsen';
$txt['move_to'] = 'Verplaats naar';
$txt['pages'] = 'Pagina\'s';
$txt['users_active'] = 'Active in past %1$d minutes';
$txt['personal_messages'] = 'Persoonlijke berichten';
$txt['reply_quote'] = 'Reageer met citaat';
$txt['reply'] = 'Reactie';
$txt['reply_number'] = 'Reply #%1$s';
$txt['approve'] = 'Goedkeuren';
$txt['unapprove'] = 'Unapprove';
$txt['approve_all'] = 'alles goedkeuren';
$txt['awaiting_approval'] = 'Wachtend op goedkeuring';
$txt['attach_awaiting_approve'] = 'Bijlagen wachtend op goedkeuring';
$txt['post_awaiting_approval'] = 'NB: dit bericht wacht op goedkeuring van een moderator.';
$txt['there_are_unapproved_topics'] = 'There are %1$s topics and %2$s posts awaiting approval in this board. <a href="%3$s">Click here to view them</a>.';
$txt['send_message'] = 'Verzend bericht';

$txt['msg_alert_no_messages'] = 'you don\'t have any message';
$txt['msg_alert_one_message'] = 'you have <a href="%1$s">1 message</a>';
$txt['msg_alert_many_message'] = 'you have <a href="%1$s">%2$d messages</a>';
$txt['msg_alert_one_new'] = '1 is new';
$txt['msg_alert_many_new'] = '%1$d are new';
$txt['remove_message'] = 'Verwijder dit bericht';

$txt['topic_alert_none'] = 'Geen berichten...';
$txt['pm_alert_none'] = 'Geen berichten...';

$txt['online_users'] = 'Gebruikers Online'; //Deprecated
$txt['online_now'] = 'Online Now';
$txt['personal_message'] = 'Persoonlijke berichten';
$txt['jump_to'] = 'Ga naar';
$txt['go'] = 'zoek';
$txt['are_sure_remove_topic'] = 'Weet je zeker dat je dit topic wilt verwijderen?';
$txt['yes'] = 'Ja';
$txt['no'] = 'Nee';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'op';

$txt['search'] = 'Zoekfunctie';
$txt['all'] = 'Allemaal';
$txt['search_entireforum'] = 'Entire Forum';
$txt['search_thisbrd'] = 'This board';
$txt['search_thistopic'] = 'This topic';
$txt['search_members'] = 'Leden';

$txt['back'] = 'Terug';
$txt['continue'] = 'Doorgaan';
$txt['password_reminder'] = 'Wachtwoord vergeten?';
$txt['topic_started'] = 'Topic gestart door';
$txt['title'] = 'Titel';
$txt['post_by'] = 'Bericht door';
$txt['welcome_newest_member'] = 'Please welcome %1$s, our newest member.';
$txt['admin_center'] = 'Beheerscherm';
$txt['admin_session_active'] = 'You have an active admin session in place. We recommend to <strong><a class="strong" href="%1$s">end this session</a></strong> once you have finished your administrative tasks.';
$txt['admin_maintenance_active'] = 'Your forum is currently in maintenance mode, only admins can log in.  Remember to <strong><a class="strong" href="%1$s">exit maintenance</a></strong> once you have finished your administrative tasks.';
$txt['query_command_denied'] = 'The following MySQL errors are occurring, please verify your setup:';
$txt['query_command_denied_guests'] = 'It seems something has gone sour on the forum with the database. This problem should only be temporary, so please come back later and try again.  If you continue to see this message, please report the following message to the administrator:';
$txt['query_command_denied_guests_msg'] = 'the command %1$s is denied on the database';
$txt['last_edit_by'] = '<span class="lastedit">Last Edit</span>: %1$s by %2$s';
$txt['notify_deactivate'] = 'Weet je zeker dat je geen notificatie-e-mails meer wilt ontvangen bij nieuwe reacties in dit topic?';

$txt['date_registered'] = 'Datum van registratie';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'View all recent posts.';
$txt['is_recent_updated'] = '%1$s is the most recently updated topic';

$txt['male'] = 'Man';
$txt['female'] = 'Vrouw';

$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Hoi,';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Welkom,';
$txt['select_destination'] = 'Selecteer een bestemming';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Geplaatst door';

$txt['icon_smiley'] = 'Glimlach';
$txt['icon_angry'] = 'Boos';
$txt['icon_cheesy'] = 'Lachen';
$txt['icon_laugh'] = 'Lach';
$txt['icon_sad'] = 'Droevig';
$txt['icon_wink'] = 'Knipoog';
$txt['icon_grin'] = 'Grijns';
$txt['icon_shocked'] = 'Geschrokken';
$txt['icon_cool'] = 'Cool';
$txt['icon_huh'] = 'Verbaasd';
$txt['icon_rolleyes'] = 'Rollende ogen';
$txt['icon_tongue'] = 'Tong';
$txt['icon_embarrassed'] = 'Beschaamd';
$txt['icon_lips'] = 'Lippen verzegeld';
$txt['icon_undecided'] = 'Ik weet het niet';
$txt['icon_kiss'] = 'Kus';
$txt['icon_cry'] = 'Huilen';
$txt['icon_angel'] = 'Innocent';

$txt['moderator'] = 'Moderator';
$txt['moderators'] = 'Moderators';

$txt['views'] = 'Gelezen';
$txt['new'] = 'Nieuw';
$txt['no_redir'] = 'Redirected from %1$s';

$txt['view_all_members'] = 'Bekijk alle leden';
$txt['view'] = 'Bekijk';

$txt['viewing_members'] = 'Bekijk de leden %1$s tot %2$s';
$txt['of_total_members'] = 'van het totale aantal %1$s';

$txt['forgot_your_password'] = 'Wachtwoord vergeten?';

$txt['date'] = 'Datum';
// Use numeric entities in the below string.
$txt['from'] = 'Van';
$txt['to'] = 'Naar';

$txt['board_topics'] = 'Topics';
$txt['members_title'] = 'Leden';
$txt['members_list'] = 'Ledenlijst';
$txt['new_posts'] = 'Nieuw bericht';
$txt['old_posts'] = 'Geen nieuw bericht';
$txt['redirect_board'] = 'Doorlinkboard';
$txt['redirect_board_to'] = 'Redirecting to %1$s';

$txt['sendtopic_send'] = 'Zenden';
$txt['report_sent'] = 'Je rapport is met succes verstuurd.';
$txt['topic_sent'] = 'Your email has been sent successfully.';

$txt['time_offset'] = 'Tijdafwijking';
$txt['or'] = 'of';

$txt['mention'] = 'Notificaties';
$txt['notifications'] = 'Notificaties';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = 'Sorry %1$s, je bent verbannen van gebruik van dit forum!';
$txt['your_ban_expires'] = 'Deze verbanning loopt af op %1$s.';
$txt['your_ban_expires_never'] = 'Deze verbanning is permanent.';
$txt['ban_continue_browse'] = 'Je kunt het forum blijven doorbladeren als gast.';

$txt['mark_as_read'] = 'Markeer alle berichten als gelezen';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'Mark THESE messages as read';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'Gesloten topic';
$txt['normal_topic'] = 'Normaal topic';
$txt['participation_caption'] = 'Topic waaraan je hebt deelgenomen';

$txt['print'] = 'Print';
$txt['topic_summary'] = 'Samenvatting van topic';
$txt['not_applicable'] = 'Niet aanwezig';
$txt['name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['total_members'] = 'Totaal aantal leden';
$txt['total_posts'] = 'Totaal aantal berichten';
$txt['total_topics'] = 'Totaal aantal topics';

$txt['mins_logged_in'] = 'Aantal minuten dat je blijft<br />ingelogd';

$txt['preview'] = 'Bekijken';
$txt['always_logged_in'] = 'Altijd ingelogd blijven';

$txt['logged'] = 'Gelogd';
// Use numeric entities in the below string.
$txt['ip'] = 'IP';

$txt['www'] = 'WWW';
$txt['link'] = 'Link';

$txt['by'] = 'door'; //Deprecated

$txt['hours'] = 'uren';
$txt['minutes'] = 'minuten';
$txt['seconds'] = 'seconden';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'Uur';
$txt['days_word'] = 'dagen';

$txt['newest_member'] = ', ons nieuwste lid.'; //Deprecated

$txt['search_for'] = 'Zoeken op';
$txt['search_match'] = 'Match';

$txt['maintain_mode_on'] = 'Onthoud dat dit forum in de onderhoudsmodus staat!';

$txt['read'] = 'gelezen'; //Deprecated
$txt['times'] = 'keer'; //Deprecated
$txt['read_one_time'] = 'Read 1 time';
$txt['read_many_times'] = 'Read %1$d times';

$txt['forum_stats'] = 'Statistieken';
$txt['latest_member'] = 'Nieuwste lid';
$txt['total_cats'] = 'Totaal categorie&euml;n';
$txt['latest_post'] = 'Laatste bericht';

$txt['here'] = 'hier';
$txt['you_have_no_msg'] = 'You don\'t have any message...';
$txt['you_have_one_msg'] = 'You\'ve 1 message...<a href="%1$s">Click here to view it</a>';
$txt['you_have_many_msgs'] = 'You\'ve %2$d messages...<a href="%1$s">Click here to view them</a>';

$txt['total_boards'] = 'Totaal aantal boards';

$txt['print_page'] = 'Print pagina';
$txt['print_page_text'] = 'Text only';
$txt['print_page_images'] = 'Text with Images';

$txt['valid_email'] = 'Dit moet een geldig e-mailadres zijn.';

$txt['info_center_title'] = '%1$s - Infocentrum';

$txt['send_topic'] = 'Share';
$txt['unwatch'] = 'Unwatch';
$txt['watch'] = 'Watch';

$txt['sendtopic_title'] = 'Stuur dit onderwerp &quot;%1%s&quot; naar een vriend.';
$txt['sendtopic_sender_name'] = 'Je naam';
$txt['sendtopic_sender_email'] = 'Je e-mailadres';
$txt['sendtopic_receiver_name'] = 'Naam van je vriend';
$txt['sendtopic_receiver_email'] = 'E-mailadres van je vriend';
$txt['sendtopic_comment'] = 'Voeg een opmerking toe';

$txt['allow_user_email'] = 'Sta gebruikers toe mij een e-mail te sturen';

$txt['check_all'] = 'Vink alles aan';

// Use numeric entities in the below string.
$txt['database_error'] = 'Databasefout';
$txt['try_again'] = 'Probeer het opnieuw. Gaat het weer fout, meld het dan aan de beheerder.';
$txt['file'] = 'Bestand';
$txt['line'] = 'Regel';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'ElkArte has detected and automatically tried to repair an error in your database.  If you continue to have problems, or continue to receive these emails, please contact your host.';
$txt['database_error_versions'] = '<strong>Note:</strong> Your database version is %1$s.';
$txt['template_parse_error'] = 'Template-verwerkingsfout!';
$txt['template_parse_error_message'] = 'Het lijkt erop dat er iets verkeerd gegaan is met het templatesysteem van het forum. Dit probleeem zou slechts tijdelijk moeten zijn, dus probeer het later opnieuw. Als je dit bericht blijft krijgen, neem dan contact op met de beheerer.<br /><br />Je kunt ook proberen om <a href="javascript:location.reload();">deze pagina te verversen</a>.';
$txt['template_parse_error_details'] = 'There was a problem loading the <span class="tt"><strong>%1$s</strong></span> template or language file.  Please check the syntax and try again - remember, single quotes (<span class="tt">\'</span>) often have to be escaped with a backslash (<span class="tt">\\</span>).  To see more specific error information from PHP, try <a href="%2$s%1$s">accessing the file directly</a>.<br /><br />You may want to try to <a href="javascript:location.reload();">refresh this page</a> or <a href="%3$s">use the default theme</a>.';
$txt['template_parse_undefined'] = 'An undefined error occurred during the parsing of this template';

$txt['today'] = 'Today at %1$s';
$txt['yesterday'] = 'Yesterday at %1$s';

// Relative times
$txt['rt_now'] = 'just now';
$txt['rt_minute'] = 'A minute ago';
$txt['rt_minutes'] = '%s minutes ago';
$txt['rt_hour'] = 'An hour ago';
$txt['rt_hours'] = '%s hours ago';
$txt['rt_day'] = 'A day ago';
$txt['rt_days'] = '%s days ago';
$txt['rt_week'] = 'A week ago';
$txt['rt_weeks'] = '%s weeks ago';
$txt['rt_month'] = 'A month ago';
$txt['rt_months'] = '%s months ago';
$txt['rt_year'] = 'A year ago';
$txt['rt_years'] = '%s years ago';

$txt['new_poll'] = 'Nieuwe poll';
$txt['poll_question'] = 'Vraag';
$txt['poll_question_options'] = 'Question and Options';
$txt['poll_vote'] = 'Stem';
$txt['poll_total_voters'] = 'Totaal aantal stemmen';
$txt['draft_saved_on'] = 'Draft last saved';
$txt['poll_results'] = 'Bekijk de resultaten';
$txt['poll_lock'] = 'Vergrendel de poll';
$txt['poll_unlock'] = 'Ontgrendel de poll';
$txt['poll_edit'] = 'Bewerk de poll';
$txt['poll'] = 'Poll';
$txt['one_day'] = '1 dag';
$txt['one_week'] = '1 week';
$txt['two_weeks'] = '2 Weeks';
$txt['one_month'] = '1 maand';
$txt['two_months'] = '2 Months';
$txt['forever'] = 'blijvend';
$txt['quick_login_dec'] = 'Login met gebruikersnaam, wachtwoord en sessielengte';
$txt['one_hour'] = '1 uur';
$txt['moved'] = 'VERPLAATST';
$txt['moved_why'] = 'Geef even een korte beschrijving waarom<br />dit topic wordt verplaatst.';
$txt['board'] = 'Board';
$txt['in'] = 'in';
$txt['sticky_topic'] = 'Pinned Topic';
$txt['split'] = 'SPLIT';

$txt['delete'] = 'Verwijder';

$txt['byte'] = 'b';
$txt['kilobyte'] = 'kB';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[Meer statistieken]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Code';
$txt['code_select'] = '[Selecteer]';
$txt['quote_from'] = 'Citaat van';
$txt['quote'] = 'Citaat';
$txt['quote_new'] = 'New topic';
$txt['follow_ups'] = 'Follow-ups';
$txt['topic_derived_from'] = 'Topic derived from %1$s';
$txt['edit'] = 'Bewerk';
$txt['quick_edit'] = 'Quick Edit';
$txt['post_options'] = 'More...';

$txt['set_sticky'] = 'Pin';
$txt['set_nonsticky'] = 'Unpin';
$txt['set_lock'] = 'Sluit';
$txt['set_unlock'] = 'Heropen';

$txt['search_advanced'] = 'Show advanced options';
$txt['search_simple'] = 'Hide advanced options';

$txt['security_risk'] = 'GROOT BEVEILIGINGSRISICO:';
$txt['not_removed'] = 'You have not removed %1$s';
$txt['not_removed_extra'] = '%1$s is a backup of %2$s that was not generated by ElkArte. It can be accessed directly and used to gain unauthorised access to your forum. You should delete it immediately.';
$txt['generic_warning'] = 'Warning';
$txt['agreement_missing'] = 'You are requiring new users to accept a registration agreement, however the file (agreement.txt) doesn\'t exist.';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'You have just updated!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Click here to see what\'s new in this version of ElkArte!</a>!';

$txt['cache_writable'] = 'De cachemap is niet beschrijfbaar! Dit zal je forumprestaties ongunstig be&iuml;nvloeden.';

$txt['page_created_full'] = 'Page created in %1$.3f seconds with %2$d queries.';

$txt['report_to_mod_func'] = 'Gebruik deze functie om de moderators en administrators op de hoogte te stellen van berichten die verkeerd geplaatst zijn of in overtreding zijn met de regels van het forum.<br /><em>Houd er rekening mee dat je e-mailadres zal worden getoond aan de moderators bij het gebruik van deze functie.</em>';

$txt['online'] = 'Online';
$txt['member_is_online'] = '%1$s is online';
$txt['offline'] = 'Offline';
$txt['member_is_offline'] = '%1$s is offline';
$txt['pm_online'] = 'Persoonlijk bericht (Online)';
$txt['pm_offline'] = 'Persoonlijk bericht (Offline)';
$txt['status'] = 'Status';

$txt['skip_nav'] = 'Skip to main content';
$txt['go_up'] = 'Omhoog';
$txt['go_down'] = 'Omlaag';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Verjaardagen:';
$txt['events'] = 'Gebeurtenissen:';
$txt['birthdays_upcoming'] = 'Aanstaande verjaardagen:';
$txt['events_upcoming'] = 'Aanstaande evenementen:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Holidays:';
$txt['calendar_month'] = 'Maand:';
$txt['calendar_year'] = 'Jaar:';
$txt['calendar_day'] = 'Dag:';
$txt['calendar_event_title'] = 'Titel van gebeurtenis';
$txt['calendar_event_options'] = 'Opties voor gebeurtenis';
$txt['calendar_post_in'] = 'Plaatsen in:';
$txt['calendar_edit'] = 'Bewerk deze gebeurtenis';
$txt['event_delete_confirm'] = 'Deze gebeurtenis verwijderen?';
$txt['event_delete'] = 'Verwijder deze gebeurtenis';
$txt['calendar_post_event'] = 'Nieuwe gebeurtenis';
$txt['calendar'] = 'Kalender';
$txt['calendar_link'] = 'Link aan de kalender';
$txt['calendar_upcoming'] = 'Aanstaande kalender';
$txt['calendar_today'] = 'Kalender van vandaag';
$txt['calendar_week'] = 'Week';
$txt['calendar_week_title'] = 'Week %1$d van %2$d';
$txt['calendar_numb_days'] = 'Aantal dagen:';
$txt['calendar_how_edit'] = 'Hoe bewerk je deze gebeurtenissen?';
$txt['calendar_link_event'] = 'Koppel gebeurtenis aan bericht:';
$txt['calendar_confirm_delete'] = 'Weet je zeker dat je deze gebeurtenis wilt verwijderen?';
$txt['calendar_linked_events'] = 'Gekoppelde gebeurtenissen';
$txt['calendar_click_all'] = 'klik hier om alle %1$s te zien';

$txt['moveTopic1'] = 'Plaats een verwijstopic';
$txt['moveTopic2'] = 'Wijzig het onderwerp van dit bericht';
$txt['moveTopic3'] = 'Nieuwe onderwerp';
$txt['moveTopic4'] = 'Verander het onderwerp van elk bericht';
$txt['move_topic_unapproved_js'] = 'Waarschuwing! Dit topic is nog niet goedgekeurd.\\n\\nHet wordt afgeraden een verplaatst-topic te maken, tenzij je van plan bent het topic direct na het verplaatsen goed te keuren.';
$txt['movetopic_auto_board'] = '[BOARD]';
$txt['movetopic_auto_topic'] = '[TOPIC LINK]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Redirect to the moved topic';
$txt['movetopic_expires'] = 'Automatically remove the redirection topic';

$txt['merge_to_topic_id'] = 'ID van doeltopic';
$txt['split_topic'] = 'Split';
$txt['merge'] = 'Merge';
$txt['subject_new_topic'] = 'Titel van het nieuwe topic';
$txt['split_this_post'] = 'Splits alleen dit bericht';
$txt['split_after_and_this_post'] = 'Splits topic vanaf dit bericht.';
$txt['select_split_posts'] = 'Selecteer berichten om te splitsen.';

$txt['splittopic_notification'] = 'Post a message when the topic is split';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Move the new topic to another board';

$txt['new_topic'] = 'Nieuw topic';
$txt['split_successful'] = 'Onderwerp succesvol gesplitst in twee topics.';
$txt['origin_topic'] = 'Oorspronkelijke topic';
$txt['please_select_split'] = 'Selecteer welke berichten je wilt afsplitsen.';
$txt['merge_successful'] = 'Topics succesvol samengevoegd.';
$txt['new_merged_topic'] = 'Nieuw samengevoegd topic';
$txt['topic_to_merge'] = 'Topic dat moet worden samengevoegd';
$txt['target_board'] = 'Doelboard';
$txt['target_topic'] = 'Doeltopic ';
$txt['merge_confirm'] = 'Weet je zeker dat je';
$txt['with'] = 'wilt samenvoegen met';
$txt['merge_desc'] = 'Deze optie zal de twee topics samenvoegen. De berichten zullen worden gesorteerd op datum, dus het eerst geplaatste bericht zal bovenaan komen te staan.';

$txt['theme_template_error'] = 'Kan template \'%1$s\' niet laden.';
$txt['theme_language_error'] = 'Kan taalbestand \'%1$s\' niet laden.';

$txt['parent_boards'] = 'Sub-boards';

$txt['smtp_no_connect'] = 'Kan geen verbinding krijgen met de SMTP host';
$txt['smtp_port_ssl'] = 'SMTP-poortinstelling onjuist; het zou 465 moeten zijn voor SSL-servers.';
$txt['smtp_bad_response'] = 'Kan geen antwoordcodes van de mail server krijgen';
$txt['smtp_error'] = 'Problemen opgetreden gedurende het verzenden van mail. Foutmelding: ';
$txt['mail_send_unable'] = 'Kon mail niet verzenden naar e-mailadres \'%1$s\'';

$txt['mlist_search'] = 'Zoek naar leden';
$txt['mlist_search_again'] = 'Zoek nogmaals'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Zoek op e-mailadres';
$txt['mlist_search_group'] = 'Zoek op ledengroep';
$txt['mlist_search_name'] = 'Zoek op naam';
$txt['mlist_search_website'] = 'Zoek op website';
$txt['mlist_search_results'] = 'Zoekresultaten voor';
$txt['mlist_search_by'] = 'Zoek op %1$s';

$txt['attach_downloaded'] = 'downloaded %1$d times';
$txt['attach_viewed'] = 'viewed %1$d times';

$txt['settings'] = 'Instellingen';
$txt['never'] = 'Nooit';
$txt['more'] = 'meer';

$txt['hostname'] = 'Hostnaam';
$txt['you_are_post_banned'] = 'Sorry %1$s, je bent verbannen van het plaatsen van berichten en het versturen van persoonlijke berichten op dit forum.';
$txt['ban_reason'] = 'Reden';

$txt['add_poll'] = 'Voeg poll toe';
$txt['poll_options6'] = 'Je kunt tot %1$s opties selecteren.';
$txt['poll_remove'] = 'Verwijder poll';
$txt['poll_remove_warn'] = 'Weet je zeker dat je deze poll van dit topic wilt verwijderen?';
$txt['poll_results_expire'] = 'Resultaten zullen worden getoond als de poll is gesloten';
$txt['poll_expires_on'] = 'Poll sluit';
$txt['poll_expired_on'] = 'Poll gesloten';
$txt['poll_change_vote'] = 'Verwijder stem';
$txt['poll_return_vote'] = 'Stemopties';
$txt['poll_cannot_see'] = 'Je kunt op dit moment de uitslag van deze poll niet bekijken.';

$txt['quick_mod_approve'] = 'Keur selectie goed';
$txt['quick_mod_remove'] = 'Verwijder selectie';
$txt['quick_mod_lock'] = 'Sluit/heropen selectie';
$txt['quick_mod_sticky'] = 'Pin/Unpin selected';
$txt['quick_mod_move'] = 'Verplaats selectie naar';
$txt['quick_mod_merge'] = 'Voeg selectie samen';
$txt['quick_mod_markread'] = 'Markeer selectie als gelezen';
$txt['quick_mod_go'] = 'zoek';
$txt['quickmod_confirm'] = 'Weet je zeker dat je dit wilt doen?';

$txt['spell_check'] = 'Spellingscontrole';

$txt['quick_reply'] = 'Snel beantwoorden';
$txt['quick_reply_warning'] = 'Warning! This topic is currently locked, only admins and moderators can reply.';
$txt['quick_reply_verification'] = 'Na het verzenden van je post word je doorgewezen naar de reguliere postpagina om je bericht te verifi&euml;ren %1$s.';
$txt['quick_reply_verification_guests'] = '(vereist voor alle gasten)';
$txt['quick_reply_verification_posts'] = '(vereist voor alle leden met minder dan %1$d berichten)';
$txt['wait_for_approval'] = 'Merk op: het bericht zal niet verschijnen tot het is goedgekeurd door een moderator.';

$txt['notification_enable_board'] = 'Weet je zeker dat je notificatie van nieuwe topics voor dit board wilt activeren?';
$txt['notification_disable_board'] = 'Weet je zeker dat je notificatie van nieuwe topics voor dit board wilt deactiveren?';
$txt['notification_enable_topic'] = 'Weet je zeker dat je notificatie van nieuwe berichten voor dit topic wilt activeren?';
$txt['notification_disable_topic'] = 'Weet je zeker dat je notificatie van nieuwe berichten voor dit topic wilt deactiveren?';

$txt['report_to_mod'] = 'Report Post';
$txt['issue_warning_post'] = 'Geef een waarschuwing vanwege dit bericht';

$txt['like_post'] = 'Like';
$txt['unlike_post'] = 'Unlike';
$txt['likes'] = 'Likes';
$txt['liked_by'] = 'Liked by:';
$txt['liked_you'] = 'You';
$txt['liked_more'] = 'meer';
$txt['likemsg_are_you_sure'] = 'You already liked this message, are you sure you want to remove your like?';

$txt['unread_topics_visit'] = 'Recente ongelezen topics';
$txt['unread_topics_visit_none'] = 'No unread topics found since your last visit. <a href="{unread_all_url}" class="linkbutton">Click here to try all unread topics</a>';
$txt['unread_topics_all'] = 'Alle ongelezen berichten';
$txt['unread_replies'] = 'Ongelezen berichten';

$txt['who_title'] = 'Wie is online?';
$txt['who_and'] = ' en ';
$txt['who_viewing_topic'] = ' bekijken dit topic.';
$txt['who_viewing_board'] = ' bekijken dit board.';
$txt['who_member'] = 'Lid';

// Current footer strings
$txt['valid_html'] = 'Valid HTML 5';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'Gast';
$txt['guests'] = 'Ongeregistreerde gasten';
$txt['user'] = 'lid';
$txt['users'] = 'leden';
$txt['hidden'] = 'verborgen';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'verborgen';
$txt['buddy'] = 'vriend';
$txt['buddies'] = 'vrienden';
$txt['most_online_ever'] = 'Meeste online ooit';
$txt['most_online_today'] = 'Meeste online vandaag';

$txt['merge_select_target_board'] = 'Selecteer het doel-board waar het samen te voegen topic terecht komt';
$txt['merge_select_poll'] = 'Selecteer welke poll het samengevoegde topic moet krijgen';
$txt['merge_topic_list'] = 'Selecteer de samen te voegen topics';
$txt['merge_select_subject'] = 'Selecteer het onderwerp van het samengevoegde topic';
$txt['merge_custom_subject'] = 'Aangepast onderwerp';
$txt['merge_enforce_subject'] = 'Verander het onderwerp van alle berichten';
$txt['merge_include_notifications'] = 'neem notificatie mee?';
$txt['merge_check'] = 'Samenvoegen?';
$txt['merge_no_poll'] = 'Geen poll';

$txt['response_prefix'] = 'Re: ';
$txt['current_icon'] = 'Current icon';
$txt['message_icon'] = 'Berichticoon';

$txt['smileys_current'] = 'Huidige smileyset';
$txt['smileys_none'] = 'Geen smileys';
$txt['smileys_forum_board_default'] = 'Forum- of boardstandaard';

$txt['search_results'] = 'Zoekresultaten';
$txt['search_no_results'] = 'Sorry, niets relevants is gevonden';

$txt['totalTimeLogged2'] = ' dagen, ';
$txt['totalTimeLogged3'] = ' uren en ';
$txt['totalTimeLogged4'] = ' minuten.';
$txt['totalTimeLogged5'] = 'd ';
$txt['totalTimeLogged6'] = 'u ';
$txt['totalTimeLogged7'] = 'm';

$txt['approve_thereis'] = 'Er wacht'; //Deprecated
$txt['approve_thereare'] = 'Er wachten'; //Deprecated
$txt['approve_member'] = '&eacute;&eacute;n lid'; //Deprecated
$txt['approve_members'] = 'leden'; //Deprecated
$txt['approve_members_waiting'] = 'op goedkeuring.'; //Deprecated
$txt['approve_one_member_waiting'] = 'There is <a href="%1$s">one member</a> awaiting approval.';
$txt['approve_many_members_waiting'] = 'There are <a href="%1$s">%2$d members</a> awaiting approval.';

$txt['notifyboard_turnon'] = 'Wil je een notificatie per e-mail ontvangen wanneer iemand een nieuw topic wordt gestart in dit board?';
$txt['notifyboard_turnoff'] = 'Weet je zeker dat je geen notificatie-e-mails meer wilt ontvangen bij het starten van nieuwe topics in dit board?';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Zoek leden';
$txt['find_username'] = 'Naam, gebruikersnaam, of e-mailadres';
$txt['find_buddies'] = 'Toon alleen vrienden?';
$txt['find_wildcards'] = 'Toegestane jokertekens: *, ?';
$txt['find_no_results'] = 'Geen resultaten gevonden';
$txt['find_results'] = 'Resultaten';
$txt['find_close'] = 'Sluiten';

$txt['quickmod_delete_selected'] = 'Verwijder selectie';
$txt['quickmod_split_selected'] = 'Split Selected';

$txt['show_personal_messages_heading'] = 'New messages';
$txt['show_personal_messages'] = 'You have <strong>%1$s</strong> unread personal messages in your inbox.<br /><br /><a href="%2$s">Go to your inbox</a>';

$txt['help_popup'] = 'A little lost? Let me explain:';

$txt['previous_next_back'] = 'previous topic';
$txt['previous_next_forward'] = 'next topic';

$txt['upshrink_description'] = 'Klap de kop in of uit.';

$txt['mark_unread'] = 'Markeer als ongelezen';

$txt['ssi_not_direct'] = 'Het is niet mogelijk om SSI.php direct per URL te benaderen; gebruik het pad (%1$s) of voeg ?ssi_function=something toe.';
$txt['ssi_session_broken'] = 'SSI.php kon geen sessie laden! Dit zou tot problemen kunnen leiden bij het uitloggen en andere functies - zorg ervoor dat SSI.php ingevoegd staat voor ook maar *iets* anders in je scripts!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Bekijk bericht';
$txt['preview_fetch'] = 'Haalt concept op...';
$txt['pm_error_while_submitting'] = 'The following error or errors occurred while sending this personal message:';
$txt['warning_while_submitting'] = 'Something happened, review it here:';
$txt['error_while_submitting'] = 'The message has the following error or errors that must be corrected before continuing:';
$txt['error_old_topic'] = 'Waarschuwing: er is al ten minste %1$d dagen geen nieuw bericht geplaatst in dit topic.<br />Tenzij je zeker weet dat je hier wilt reageren, overweeg je beter om een nieuw topic aan te maken.';

$txt['split_selected_posts'] = 'Geselecteerde berichten';
$txt['split_selected_posts_desc'] = 'De berichten hieronder worden na het splitsen een nieuw topic.';
$txt['split_reset_selection'] = 'deselecteer alles';

$txt['modify_cancel'] = 'Annuleren';
$txt['mark_read_short'] = 'Markeer gelezen';

$txt['hello_member_ndt'] = 'Hallo';

$txt['unapproved_posts'] = 'Niet-goedgekeurde berichten (topics: %1$d, berichten: %2$d)';

$txt['ajax_in_progress'] = 'Laden...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = 'Er staan momenteel %1$d moderatorrapporten open.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'Click to see the new posts in %1$s';
$txt['verification'] = 'Verificatie';
$txt['visual_verification_hidden'] = 'Please leave this box empty';
$txt['visual_verification_description'] = 'Typ de afgebeelde letters over';
$txt['visual_verification_sound'] = 'Luister naar de letters';
$txt['visual_verification_request_new'] = 'Vraag een andere afbeelding aan';

// @todo Send email strings - should move?
$txt['send_email'] = 'Send email';
$txt['send_email_disclosed'] = 'NB: dit zal zichtbaar zijn voor de ontvanger.';
$txt['send_email_subject'] = 'Onderwerp';

$txt['ignoring_user'] = 'Je negeert deze gebruiker.';
$txt['show_ignore_user_post'] = '<em>[Show me the post.]</em>';

$txt['spider'] = 'spider';
$txt['spiders'] = 'Spiders';
$txt['openid'] = 'OpenID';

$txt['downloads'] = 'Downloads';
$txt['filesize'] = 'File size';
$txt['subscribe_webslice'] = 'Abonneer op Webslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Herstel topic';
$txt['restore_message'] = 'Herstel bericht';
$txt['quick_mod_restore'] = 'Herstel selectie';

// Editor prompt.
$txt['prompt_text_email'] = 'Welk e-mailadres wil je invoegen?';
$txt['prompt_text_ftp'] = 'Please enter the FTP address.';
$txt['prompt_text_url'] = 'Naar welke URL wil je linken?';
$txt['prompt_text_img'] = 'Wat is de URL van de afbeelding die je wilt invoegen?';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Verwijder item';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> has blocked %1$s access attempts in the last 7 days.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Templates: ';
$txt['debug_subtemplates'] = 'Subtemplates: '; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Subtemplates: ';
$txt['debug_language_files'] = 'Taalbestanden: ';
$txt['debug_sheets'] = 'Stylesheets: ';
$txt['debug_javascript'] = 'Scripts: ';
$txt['debug_files_included'] = 'Geopende bestanden: ';
$txt['debug_kb'] = 'kB.';
$txt['debug_show'] = 'toon';
$txt['debug_cache_hits'] = 'Cachehits: ';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s bytes';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss voor %2$s bytes';
$txt['debug_queries_used'] = 'Gebruikte query\'s: %1$d.';
$txt['debug_queries_used_and_warnings'] = 'Gebruikte query\'s: %1$d, %2$d waarschuwingen.';
$txt['debug_query_in_line'] = 'in <em>%1$s</em> regel <em>%2$s</em>, ';
$txt['debug_query_which_took'] = 'die %1$s duurde.';
$txt['debug_query_which_took_at'] = 'die %1$s seconden duurde na %2$s in het verzoek.';
$txt['debug_show_queries'] = '[Toon query\'s]';
$txt['debug_hide_queries'] = '[Verberg query\'s]';
$txt['debug_tokens'] = 'Tokens: ';
$txt['debug_browser'] = 'Browser ID: ';
$txt['debug_hooks'] = 'Hooks called: ';
$txt['debug_system_type'] = 'System: ';
$txt['debug_server_load'] = 'Server Load: ';
$txt['debug_script_mem_load'] = 'Script Memory Usage: ';
$txt['debug_script_cpu_load'] = 'Script CPU Time (user/system): ';

// Video embedding
$txt['preview_image'] = 'Video Preview Image';
$txt['ctp_video'] = 'Click to play video, double click to load video';
$txt['hide_video'] = 'Show/Hide video';
$txt['youtube'] = 'YouTube video:';
$txt['vimeo'] = 'Vimeo video:';
$txt['dailymotion'] = 'Dailymotion video:';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (click to show/hide)';

$txt['ok_uppercase'] = 'OK';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Warning';

$txt['via'] = 'via';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
