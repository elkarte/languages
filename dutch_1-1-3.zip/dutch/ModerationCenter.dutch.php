<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Moderatiecentrum';
$txt['mc_main'] = 'SMF';
$txt['mc_logs'] = 'Logboeken';
$txt['mc_posts'] = 'berichten';
$txt['mc_groups'] = 'Members and groups';

$txt['mc_view_groups'] = 'Bekijk ledengroepen';

$txt['mc_description'] = '<strong>Welcome, %1$s!</strong><br />This is your &quot;Moderation Center&quot;. From here you can perform all the moderation actions assigned to yourself by the Administrator. This home page contains a summary of all the latest happenings in your community. You can <a href="%2$s">personalize the layout by clicking here</a>.';
$txt['mc_group_requests'] = 'Verzoeken tot groeplidmaatschap';
$txt['mc_member_requests'] = 'Member Requests';
$txt['mc_unapproved_posts'] = 'Niet-goedgekeurde berichten';
$txt['mc_watched_users'] = 'Recently Watched Members';
$txt['mc_watched_topics'] = 'Gemodereerde topics';
$txt['mc_scratch_board'] = 'Moderator schetsboard';
$txt['mc_latest_news'] = 'Latest News';
$txt['mc_recent_reports'] = 'Recente topicrapporten';
$txt['mc_warnings'] = 'Waarschuwingen';
$txt['mc_notes'] = 'Moderatornotities';
$txt['mc_required'] = 'Items Requiring Approval';
$txt['mc_attachments'] = 'Attachments needing approval';
$txt['mc_emailmod'] = 'Email Postings needing approval';
$txt['mc_topics'] = 'Topics needing approval';
$txt['mc_posts'] = 'berichten';
$txt['mc_groupreq'] = 'Group requests needing approval';
$txt['mc_memberreq'] = 'Members needing approval';
$txt['mc_reports'] = 'Report posts needing approval';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['mc_recent_reports_none'] = 'Er zijn geen openstaande rapporten.';
$txt['mc_watched_users_none'] = 'Er worden momenteel geen leden in de gaten gehouden.';
$txt['mc_group_requests_none'] = 'Er staan momenteel geen verzoeken open voor groeplidmaatschap.';

$txt['mc_seen'] = '%1$s laatst gezien op %2$s ';
$txt['mc_seen_never'] = '%1$s nog nooit gezien';
$txt['mc_groupr_by'] = 'door';

$txt['mc_reported_posts_desc'] = 'Hier kun je alle door leden gerapporteerde posts bekijken.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Openstaande rapporten';
$txt['mc_reportedp_closed'] = 'Oude rapporten';
$txt['mc_reportedp_by'] = 'door';
$txt['mc_reportedp_reported_by'] = 'Gerapporteerd door';
$txt['mc_reportedp_last_reported'] = 'Laatst gerapporteerd';
$txt['mc_reportedp_none_found'] = 'Geen rapporten gevonden';

$txt['mc_reportedp_details'] = 'Details';
$txt['mc_reportedp_close'] = 'Sluiten';
$txt['mc_reportedp_open'] = 'Heropen';
$txt['mc_reportedp_ignore'] = 'Dismiss';
$txt['mc_reportedp_unignore'] = 'Reopen';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Are you sure you wish to dismiss and ignore further reports about this message?

This will turn off further reports for all moderators of the forum.';
$txt['mc_reportedp_close_selected'] = 'Sluit selectie';

$txt['mc_groupr_group'] = 'Ledengroepen';
$txt['mc_groupr_member'] = 'Lid';
$txt['mc_groupr_reason'] = 'Reden';
$txt['mc_groupr_none_found'] = 'Er zijn momenteel geen openstaande verzoeken voor groeplidmaatschappen.';
$txt['mc_groupr_submit'] = 'Verzend';
$txt['mc_groupr_reason_desc'] = 'Reden van afkeuring van %1$s\'s verzoek om deel uit te maken van &quot;%2$s&quot;';
$txt['mc_groups_reason_title'] = 'Reasons for rejection';
$txt['with_selected'] = 'With selected';
$txt['mc_groupr_approve'] = 'Approve request';
$txt['mc_groupr_reject'] = 'Reject request (No Reason)';
$txt['mc_groupr_reject_w_reason'] = 'Reject request with reason';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Weet je zeker dat je dit wilt doen?';

$txt['mc_unapproved_attachments_none_found'] = 'Er zijn momenteel geen niet-goedgekeurde bijlagen.';
$txt['mc_unapproved_attachments_desc'] = 'From here you can approve or delete any attachments awaiting moderation.';
$txt['mc_unapproved_replies_none_found'] = 'Er zijn momenteel geen niet-goedgekeurde berichten.';
$txt['mc_unapproved_topics_none_found'] = 'Er zijn momenteel geen niet-goedgekeurde topics.';
$txt['mc_unapproved_posts_desc'] = 'Vanaf hier kun je berichten die op goedkeuring wachten goedkeuren of verwijderen.';
$txt['mc_unapproved_replies'] = 'Reacties';
$txt['mc_unapproved_topics'] = 'Topics';
$txt['mc_unapproved_by'] = 'door';
$txt['mc_unapproved_sure'] = 'Weet je zeker dat je dit wilt doen?';
$txt['mc_unapproved_attach_name'] = 'Attachment name';
$txt['mc_unapproved_attach_size'] = 'File size';
$txt['mc_unapproved_attach_poster'] = 'Geplaatst door';
$txt['mc_viewmodreport'] = 'Moderation report for %1$s by %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Leden die dit bericht hebben gerapporteerd';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Acties ondernomen door andere moderators';
$txt['mc_modreport_mod_comments'] = 'Moderatorcommentaar';
$txt['mc_modreport_no_mod_comment'] = 'Er is momenteel geen moderatorcommentaar aanwezig.';
$txt['mc_modreport_add_mod_comment'] = 'Commentaar toevoegen';

$txt['show_notice'] = 'Notitietekst';
$txt['show_notice_subject'] = 'Onderwerp';
$txt['show_notice_text'] = 'Tekst';

$txt['mc_watched_users_title'] = 'Ledentoezicht';
$txt['mc_watched_users_desc'] = 'Vanuit hier kun je toezien op alle leden die een toezichtstatus hebben gekregen van het moderatieteam.';
$txt['mc_watched_users_post'] = 'Bekijk per bericht';
$txt['mc_watched_users_warning'] = 'Waarschuwingsniveau';
$txt['mc_watched_users_last_login'] = 'Laatst ingelogd';
$txt['mc_watched_users_last_post'] = 'Laatste bericht';
$txt['mc_watched_users_no_posts'] = 'Er zijn geen berichten geplaatst door leden onder toezicht.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Weet je zeker dat je dit bericht wilt verwijderen?';
$txt['mc_watched_users_delete_posts'] = 'Weet je zeker dat je deze berichten wilt verwijderen?';
$txt['mc_watched_users_posted'] = 'Geplaatst';
$txt['mc_watched_users_member'] = 'Lid';

$txt['mc_warnings_description'] = 'Vanuit deze sectie kun de waarschuwingen zien die zijn verstuurd naar leden van het forum. Ook kun je notificatiesjablonen voor het verzenden van waarschuwingen naar een lid toevoegen en verwijderen.';
$txt['mc_warning_log'] = 'Logboek';
$txt['mc_warning_templates'] = 'Sjablonen';
$txt['mc_warning_log_title'] = 'Viewing warning log';
$txt['mc_warning_templates_title'] = 'Custom warning templates';

$txt['mc_warnings_none'] = 'No warnings have been issued.';
$txt['mc_warnings_recipient'] = 'Ontvanger';

$txt['mc_warning_templates_none'] = 'Er zijn nog geen waarschuwingssjablonen gemaakt.';
$txt['mc_warning_templates_time'] = 'Gemaakt op';
$txt['mc_warning_templates_name'] = 'Template';
$txt['mc_warning_templates_creator'] = 'Gemaakt door';
$txt['mc_warning_template_add'] = 'Nieuw sjabloon';
$txt['mc_warning_template_modify'] = 'Bewerk sjabloon';
$txt['mc_warning_template_delete'] = 'Verwijder selectie';
$txt['mc_warning_template_delete_confirm'] = 'Weet je zeker dat je de geselecteerde sjablonen wilt verwijderen?';

$txt['mc_warning_template_desc'] = 'Use this page to fill in the details of the template. Note that the subject for the email is not part of the template. Note that as the notification is sent by PM you can use BBC within the template. If you use the {MESSAGE} variable then this template will not be available when issuing a generic warning (i.e. A warning not linked to a post).';
$txt['mc_warning_template_title'] = 'Sjabloontitel';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Persoonlijk sjabloon';
$txt['mc_warning_template_personal_desc'] = 'Als je deze optie selecteert, zal alleen jij dit sjabloon kunnen zien, bewerken en gebruiken. Indien je deze optie niet selecteert, kunnen alle moderators gebruik maken van dit sjabloon.';
$txt['mc_warning_template_error_no_title'] = 'You must set the title.';
$txt['mc_warning_template_error_no_body'] = 'You must set the notification body.';

$txt['mc_settings'] = 'Voorkeuren wijzigen';
$txt['mc_prefs_title'] = 'Moderatievoorkeuren';
$txt['mc_prefs_desc'] = 'Deze sectie stelt je in staat om wat persoonlijke voorkeuren met betrekking tot moderatie-activiteiten, zoals e-mailnotificaties, in te stellen.';
$txt['mc_prefs_homepage'] = 'Te tonen items op moderatie-hoofdscherm';
$txt['mc_prefs_latest_news'] = 'ElkArte News';
$txt['mc_prefs_show_reports'] = 'Toon teller met het aantal open rapportages in de forumheader';
$txt['mc_prefs_notify_report'] = 'Notificatie van topicrapportages';
$txt['mc_prefs_notify_report_never'] = 'Nooit';
$txt['mc_prefs_notify_report_moderator'] = 'Alleen als het gaat om een board dat ik modereer';
$txt['mc_prefs_notify_report_always'] = 'Altijd';
$txt['mc_prefs_notify_approval'] = 'Notificatie van items wachtend op goedkeuring';
$txt['mc_logoff'] = 'End Moderator Session';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Voeg nieuwe notitie toe';
$txt['mc_add_note'] = 'Voeg toe';