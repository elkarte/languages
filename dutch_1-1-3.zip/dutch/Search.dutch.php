<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Stel zoekparameters in';
$txt['choose_board'] = 'Kies een board waar je in wilt zoeken, of selecteer alle boards';
$txt['all_words'] = 'Zoek naar alle woorden';
$txt['any_words'] = 'Zoek naar enkele woorden';
$txt['by_user'] = 'Door gebruiker';

$txt['search_post_age'] = 'Berichtouderdom';
$txt['search_between'] = 'tussen';
$txt['search_and'] = 'en';
$txt['search_options'] = 'Opties';
$txt['search_show_complete_messages'] = 'Toon resultaten als berichten';
$txt['search_subject_only'] = 'Zoek alleen op onderwerp';
$txt['search_relevance'] = 'Relevantie';
$txt['search_date_posted'] = 'Datum geplaatst';
$txt['search_order'] = 'Resultaatvolgorde';
$txt['search_orderby_relevant_first'] = 'Meest relevante resultaten eerst';
$txt['search_orderby_large_first'] = 'Grootste topics eerst';
$txt['search_orderby_small_first'] = 'Kleinste topics eerst';
$txt['search_orderby_recent_first'] = 'Meest recente topics eerst';
$txt['search_orderby_old_first'] = 'Oudste topics eerst';
$txt['search_visual_verification_label'] = 'Verificatie';
$txt['search_visual_verification_desc'] = 'Typ de bovenstaande code in om uw zoekopdracht uit te voeren.';

$txt['search_specific_topic'] = 'Zoek alleen berichten in de topic';

$txt['groups_search_posts'] = 'Ledengroepen met toegang tot de zoekfunctie';
$txt['search_dropdown'] = 'Enable the Quick Search dropdown';
$txt['search_results_per_page'] = 'Aantal zoekresultaten per pagina';
$txt['search_weight_frequency'] = 'Relatieve zoekgewicht van het aantal berichten met trefwoorden per topic';
$txt['search_weight_age'] = 'Relatieve zoekgewicht van de leeftijd van het laatste bericht met trefwoorden';
$txt['search_weight_length'] = 'Relatieve zoekgewicht van de topiclengte';
$txt['search_weight_subject'] = 'Relatieve zoekgewicht van een berichtonderwerp met trefwoorden';
$txt['search_weight_first_message'] = 'Relatieve zoekgewicht van een eerste bericht met trefwoorden';
$txt['search_weight_sticky'] = 'Relative search weight for a pinned topic';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Here you can change the basic settings of the search function.';
$txt['search_settings_title'] = 'Search Settings';

$txt['search_weights_desc'] = 'Here you can change the individual components of the relevance rating.';
$txt['search_weights_sphinx'] = 'To update weight factors with Sphinx, you must generate and install a new sphinx.conf file.';
$txt['search_weights_title'] = 'Zoekfunctie - Wegingen';
$txt['search_weights_total'] = 'Totaal';
$txt['search_weights_save'] = 'Opslaan';

$txt['search_method_desc'] = 'Hier kun je de manier instellen waarop de zoekfunctie functioneert.';
$txt['search_method_title'] = 'Zoekfunctie - Methode';
$txt['search_method_save'] = 'Opslaan';
$txt['search_method_messages_table_space'] = 'Ruimte gebruikt voor forumberichten';
$txt['search_method_messages_index_space'] = 'Ruimte gebruikt voor het indexeren van berichten';
$txt['search_method_kilobytes'] = 'kB';
$txt['search_method_fulltext_index'] = 'Fulltext index';
$txt['search_method_no_index_exists'] = 'bestaat op dit moment niet';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'kan niet gemaakt worden omdat de maximale berichtlengte groter dan 65.535 is of het tabeltype niet MyISAM is';
$txt['search_method_index_already_exists'] = 'bestaat al';
$txt['search_method_fulltext_remove'] = 'verwijder fulltextindex';
$txt['search_method_index_partial'] = 'gedeeltelijk gecre&euml;erd';
$txt['search_index_custom_resume'] = 'hervatten';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'In order to be able to use fulltext search, you\\\'ll have to create a fulltext index first.';
$txt['search_index_custom_warning'] = 'Om een aangepaste zoekindex te gebruiken, dien je eerst een aangepaste index aan te maken!';

$txt['search_index'] = 'Zoekindex';
$txt['search_index_none'] = 'Geen index';
$txt['search_index_custom'] = 'Aangepaste index';
$txt['search_index_label'] = 'Index';
$txt['search_index_size'] = 'Grootte';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Forceer het gebruik van een zoekindex';
$txt['search_match_words'] = 'Alleen op hele woorden zoeken';
$txt['search_max_results'] = 'Maximaal aantal resultaten tonen';
$txt['search_max_results_disable'] = '(0 voor geen limiet)';
$txt['search_floodcontrol_time'] = 'Tijd vereist tussen zoekopdrachten van dezelfde gebruiker';
$txt['search_floodcontrol_time_desc'] = '(0 voor geen limiet, in seconden)';

$txt['additional_search_engines'] = 'Additional search engines';
$txt['setup_search_engine_add_more'] = 'Add another search engine';

$txt['search_create_index'] = 'Cre&euml;er index';
$txt['search_create_index_why'] = 'Waarom een zoekindex maken?';
$txt['search_create_index_start'] = 'Nieuw';
$txt['search_predefined'] = 'Vooraf gedefinieerd profiel';
$txt['search_predefined_small'] = 'Kleine index qua grootte';
$txt['search_predefined_moderate'] = 'Gemiddelde index qua grootte';
$txt['search_predefined_large'] = 'Grote index qua grootte';
$txt['search_create_index_continue'] = 'Doorgaan';
$txt['search_create_index_not_ready'] = 'ElkArte is currently creating a search index of your messages. To avoid overloading your server, the process has been temporarily paused. It should automatically continue in a few seconds. If it doesn\'t, please click continue below.';
$txt['search_create_index_progress'] = 'Voortgang';
$txt['search_create_index_done'] = 'Custom search index successfully created.';
$txt['search_create_index_done_link'] = 'Doorgaan';
$txt['search_double_index'] = 'Je hebt momenteel twee indices van de berichtentabel gemaakt. Voor de beste presaties kun je het beste &eacute;&eacute;n van de twee verwijderen.';

$txt['search_error_indexed_chars'] = 'Onjuist aantal ge&iuml;ndexeerde tekens. Ten minste drie tekens zijn vereist voor een goede index.';
$txt['search_error_max_percentage'] = 'Onjuist percentage over te slaan aantal woorden. Gebruik een waarde van ten minste 5%.';
$txt['error_string_too_long'] = 'De zoekopdracht mag niet langer zijn dan %1$d karakters.';

$txt['search_warning_ignored_word'] = 'The following term has been ignored in your search';
$txt['search_warning_ignored_words'] = 'The following terms have been ignored in your search';

$txt['search_adjust_query'] = 'Pas de zoekparameters aan';
$txt['search_adjust_submit'] = 'Zoek opnieuw';
$txt['search_did_you_mean'] = 'Wellicht zocht je naar';

$txt['search_example'] = '<em>bijv.</em> Orwell "Animal Farm" -film';

$txt['search_engines_description'] = 'Vanuit deze sectie kun je instellen in hoeverre je wilt bijhouden hoe zoekmachines je forum indexeren, alsook de logs hiervan bekijken.';
$txt['spider_mode'] = 'Search Engine Tracking Level';
$txt['spider_mode_note'] = 'Note higher level tracking increases server resource requirement.';
$txt['spider_mode_off'] = 'Uitgeschakeld';
$txt['spider_mode_standard'] = 'Standaard';
$txt['spider_mode_high'] = 'Moderatie';
$txt['spider_mode_vhigh'] = 'Aggressive';
$txt['spider_settings_desc'] = 'You can change settings for spider tracking from this page. Note, if you wish to <a href="%1$s">enable automatic pruning of the hit logs you can set this up here</a>';

$txt['spider_group'] = 'Apply restrictive permissions from group';
$txt['spider_group_note'] = 'To enable you to stop spiders indexing some pages.';
$txt['spider_group_none'] = 'Uitgeschakeld';

$txt['show_spider_online'] = 'Toon spiders in de onlinelijst';
$txt['show_spider_online_no'] = 'Helemaal niet';
$txt['show_spider_online_summary'] = 'Alleen hoeveelheid spiders';
$txt['show_spider_online_detail'] = 'Toon spidernamen';
$txt['show_spider_online_detail_admin'] = 'Toon spidernamen - alleen aan beheerders';

$txt['spider_name'] = 'Spidernaam';
$txt['spider_last_seen'] = 'Laatst gezien op';
$txt['spider_last_never'] = 'Nooit';
$txt['spider_agent'] = 'User Agent';
$txt['spider_ip_info'] = 'IP-adres';
$txt['spiders_add'] = 'Voeg nieuwe spider toe';
$txt['spiders_edit'] = 'Spider bewerken';
$txt['spiders_remove_selected'] = 'Verwijder selectie';
$txt['spider_remove_selected_confirm'] = 'Are you sure you want to remove these spiders?\\n\\nAll associated statistics will also be deleted!';
$txt['spiders_no_entries'] = 'Er zijn momenteel geen spiders geconfigureerd.';

$txt['add_spider_desc'] = 'Vanaf deze pagina kun je bepalen hoe een spider getypeerd wordt. Als de user agent danwel het IP-adres van een gast overeenkomt met de gegevens hieronder, zal hij worden gedetecteerd als een zoekmachine-spider en gevolgd worden op de ingestelde wijze.';
$txt['spider_name_desc'] = 'Naam waarmee naar de spider verwezen wordt.';
$txt['spider_agent_desc'] = 'Useragent geassocieerd met deze spider.';
$txt['spider_ip_info_desc'] = 'Komma-gescheiden lijst met IP-adressen behorend bij deze spider.';

$txt['spider_time'] = 'Tijd';
$txt['spider_viewing'] = 'Bekijkt';
$txt['spider_logs_empty'] = 'Er zijn op dit moment ingangen in het spiderlog.';
$txt['spider_logs_info'] = 'NB: het loggen van spideracties vindt alleen plaats als het opsporingsniveau is ingesteld op &quot;hoog&quot; of &quot;zeer hoog&quot;. Details van elke spideractie worden alleen gelogd als het opsporingsniveau op &quot;zeer hoog&quot; staat.';
$txt['spider_disabled'] = 'Uitgeschakeld';
$txt['spider_log_empty_log'] = 'Clear Log';
$txt['spider_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log';

$txt['spider_logs_delete'] = 'Verwijder logs';
$txt['spider_logs_delete_older'] = 'Delete all entries older than %1$s days.';
$txt['spider_logs_delete_submit'] = 'Verwijder';

$txt['spider_stats_delete_older'] = 'Delete all spider statistics from spiders not seen in %1$s days.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Weet je zeker dat je alle logingangen wilt verwijderen?';

$txt['spider_stats_select_month'] = 'Ga naar maand';
$txt['spider_stats_page_hits'] = 'Paginahits';
$txt['spider_stats_no_entries'] = 'Er zijn momenteel geen spiderstatistieken beschikbaar.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'You have not yet selected to use Sphinx or SphinxQL as your Search Method';
$txt['sphinx_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using the Sphinx API.';
$txt['sphinxql_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using SphinxQL commands.';
$txt['sphinx_test_connect_failed'] = 'Unable to connect to the Sphinx daemon. Make sure it is running and configured properly. Sphinx search will not work until you fix the problem.';
$txt['sphinxql_test_connect_failed'] = 'Unable to access SphinxQL. Make sure your sphinx.conf has a separate listen directive for the SphinxQL port. SphinxQL search will not work until you fix the problem';
$txt['sphinx_test_api_missing'] = 'The sphinxapi.php file is missing in your &quot;sources&quot; directory. You need to copy this file from the Sphinx distribution. Sphinx search will not work until you fix the problem.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Index data path:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Log file path:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';