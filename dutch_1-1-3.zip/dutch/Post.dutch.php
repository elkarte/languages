<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Antwoord';
$txt['post_in_board'] = 'Post in the board';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Voeg citaat toe';
$txt['disable_smileys'] = 'Disable smileys';
$txt['dont_use_smileys'] = 'Gebruik geen smileys.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'geplaatst op';
$txt['standard'] = 'Standaard';
$txt['thumbs_up'] = 'Duim omhoog';
$txt['thumbs_down'] = 'Duim omlaag';
$txt['exclamation_point'] = 'Uitroepteken';
$txt['question_mark'] = 'Vraagteken';
$txt['icon_poll'] = 'Poll';
$txt['lamp'] = 'Lampje';
$txt['add_smileys'] = 'Add smileys';
$txt['topic_notify_no'] = 'There are no topics with notification.';

$txt['rich_edit_wont_work'] = 'Je browser ondersteunt de Rich Text modus niet.';
$txt['rich_edit_function_disabled'] = 'Je browser ondersteunt deze functie niet.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Notificatie voor dit topic uitzetten door hier te klikken';

$txt['lock_after_post'] = 'Afsluiten na bericht';
$txt['notify_replies'] = 'Notificatie bij reacties';
$txt['lock_topic'] = 'Sluit dit topic.';
$txt['shortcuts'] = 'shortcuts: shift+alt+s submit/post or shift+alt+p preview';
$txt['shortcuts_drafts'] = 'shortcuts: shift+alt+s submit/post, shift+alt+p preview or shift+alt+d save draft';
$txt['option'] = 'Optie';
$txt['reset_votes'] = 'Reset vote count';
$txt['reset_votes_check'] = 'Vink dit aan als je de resultaten op 0 wilt zetten.';
$txt['votes'] = 'stemmen';
$txt['attach'] = 'Bijlage';
$txt['clean_attach'] = 'Clear attachment';
$txt['attached'] = 'Bijgevoegd'; // @deprecated since 1.1
$txt['allowed_types'] = 'Toegestane extensies';
$txt['cant_upload_type'] = 'You cannot upload that type of file. The only allowed extensions are %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Vink de bijlagen die je niet langer aangehecht wilt hebben uit'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Dat is een beschermde bestandsnaam.  Probeer een andere bestandsnaam.';
$txt['topic_locked_no_reply'] = 'Warning! This topic is currently/will be locked<br />Only admins and moderators can reply.';
$txt['attachment_requires_approval'] = 'Merk op dat enige bestanden die bijgevoegd zijn apart goedgekeurd moeten worden.';
$txt['error_temp_attachments'] = 'There are attachments found, which you have attached before but not posted. These attachments are now attached to this post. If you do not want to include them in this post, <a href="#postAttachment">you can remove them here</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'NB: dit bericht zal niet verschijnen voor het is goedgekeurd door een moderator.';

$txt['enter_comment'] = 'Geef je commentaar';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Gemeld bericht';
$txt['reported_to_mod_by'] = 'door';
$txt['rtm10'] = 'Verzend';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Het volgende bericht, "%1$s" van';
$txt['reported_by'] = 'is aan je gemeld door';
$txt['board_moderate'] = 'op een board waarop jij moderator bent';
$txt['report_comment'] = 'Het lid heeft het volgende bericht er aan toegevoegd';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximum total size %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximum individual size %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d per bericht';
$txt['attach_restrictions'] = 'Beperkingen:';

$txt['post_additionalopt_attach'] = 'Bijlagen en andere opties';
$txt['post_additionalopt'] = 'Other options';
$txt['sticky_after'] = 'Pin this topic.';
$txt['move_after2'] = 'Verplaats dit topic.';
$txt['back_to_topic'] = 'Terug naar dit topic.';
$txt['approve_this_post'] = 'Approve this post';

$txt['retrieving_quote'] = 'Retrieving quote...';

$txt['post_visual_verification_label'] = 'Verificatie';
$txt['post_visual_verification_desc'] = 'Typ de code van het plaatje hierboven over om deze post te plaatsen.';

$txt['poll_options'] = 'Pollinstellingen';
$txt['poll_run'] = 'Activeer de poll voor';
$txt['poll_run_limit'] = '(Laat leeg voor geen limiet.)';
$txt['poll_results_visibility'] = 'Zichtbaarheid van uitslag';
$txt['poll_results_anyone'] = 'Laat iedereen de uitslag zien van deze poll.';
$txt['poll_results_voted'] = 'Laat de uitslag alleen zien nadat iemand heeft gestemd.';
$txt['poll_results_after'] = 'Laat de uitslag alleen zien nadat de stemperiode is afgelopen.';
$txt['poll_max_votes'] = 'Maximum aantal stemmen per gebruiker';
$txt['poll_do_change_vote'] = 'Sta gebruikers toe hun stem te wijzigen';
$txt['poll_too_many_votes'] = 'Je hebt teveel opties geselecteerd. Bij deze poll mag je slechts %1$s opties selecteren.';
$txt['poll_add_option'] = 'Voeg optie toe';
$txt['poll_guest_vote'] = 'Sta gasten toe om te stemmen';

$txt['spellcheck_done'] = 'Spellingscontrole voltooid.';
$txt['spellcheck_change_to'] = 'Wijzig in:';
$txt['spellcheck_suggest'] = 'Suggesties:';
$txt['spellcheck_change'] = 'Verander';
$txt['spellcheck_change_all'] = 'Verander alles';
$txt['spellcheck_ignore'] = 'Negeer';
$txt['spellcheck_ignore_all'] = 'Negeer alles';

$txt['more_attachments'] = 'meer bijlagen';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Je mag helaas niet meer bijlagen plaatsen.';

$txt['more_smileys'] = 'meer';
$txt['more_smileys_title'] = 'Extra smileys';
$txt['more_smileys_pick'] = 'Selecteer een smiley';
$txt['more_smileys_close_window'] = 'Sluit venster';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = 'Stuur de leden een aankondiging over dit topic';
$txt['announce_title'] = 'Verstuur een aankondiging';
$txt['announce_desc'] = 'Met deze pagina kun je een aankondiging sturen aan de geselecteerde ledengroepen over dit topic.';
$txt['announce_sending'] = 'Bezit met het versturen van een aankondiging voor topic';
$txt['announce_done'] = 'gedaan';
$txt['announce_continue'] = 'Doorgaan';
$txt['announce_topic'] = 'Kondig dit topic aan';
$txt['announce_regular_members'] = 'Niet-gegroepeerde leden';

$txt['digest_subject_daily'] = 'Dagelijkse update';
$txt['digest_subject_weekly'] = 'Wekelijkse update';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'The following topics were started';
$txt['digest_new_topics_line'] = '"%1$s" in the %2$s board';
$txt['digest_new_replies'] = 'Er zijn reacties geplaatst in de volgende topics';
$txt['digest_new_replies_one'] = '1 reactie op "%1$s"';
$txt['digest_new_replies_many'] = '%1$d reacties in "%2$s"';
$txt['digest_mod_actions'] = 'De volgende moderatieacties hebben plaatsgevonden';
$txt['digest_mod_act_sticky'] = '"%1$s" was pinned';
$txt['digest_mod_act_lock'] = '"%1$s" is gesloten';
$txt['digest_mod_act_unlock'] = '"%1$s" is heropend';
$txt['digest_mod_act_remove'] = '"%1$s" is verwijderd';
$txt['digest_mod_act_move'] = '"%1$s" is verplaatst';
$txt['digest_mod_act_merge'] = '"%1$s" is samengevoegd';
$txt['digest_mod_act_split'] = '"%1$s" is gesplitst';

$txt['attach_error_title'] = 'Error uploading attachments.';
$txt['attach_warning'] = 'There was a problem during the uploading of <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Sorry, you are out of attachment space. The total attachment size allowed per post is %1$s KB. Space remaining is %2$s KB.';
$txt['attach_folder_warning'] = 'The attachments directory can not be located. Please notify an administrator of this problem.';
$txt['attach_folder_admin_warning'] = 'The path to the attachments directory (%1$s) is incorrect. Please correct it in the attachment settings area of your admin panel.';
$txt['attach_limit_nag'] = 'You have reached the maximum number of attachments allowed per post.';
$txt['attach_no_upload'] = 'There was a problem and your attachments could not be uploaded';
$txt['attach_remaining'] = '%1$d remaining';
$txt['attach_available'] = '%1$s KB available';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'The file appears to be empty. Please contact your forum administrator if this continues to be a problem';
$txt['attached_files_in_session'] = '<em>The above underlined file(s) have been uploaded but will not be attached to this post until it is submitted.</em>';

$txt['attach_php_error'] = 'Due to an error, your attachment could not be uploaded. Please contact the forum administrator if this problem continues.';
$txt['php_upload_error_1'] = 'The uploaded file exceeds the upload_max_filesize directive in php.ini. Please contact your host if you are unable to correct this issue.';
$txt['php_upload_error_3'] = 'The uploaded file was only partially uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_4'] = 'No file was uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_6'] = 'Unable to save. Missing a temporary directory. Please contact your host if you are unable to correct this problem.';
$txt['php_upload_error_7'] = 'Failed to write file to disk. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_8'] = 'A PHP extension stopped the file upload. This is a PHP related error. Please contact your host if this problem continues.';
$txt['error_temp_attachments_new'] = 'There are attachments which you had previously attached but not posted. These attachments are still attached to this post. This post does need to be submitted before these attachments are either saved or removed. You <a href="#postAttachment">can do that here</a>';
$txt['error_temp_attachments_found'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not post until these are either removed or that post has been submitted.<br />Click <a href="%1$s">here to remove </a>those attachments. Or <a href="%2$s">here to return to that post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not upload any more attachments until these are removed or that post has been submitted.<br />Click <a href="%1$s">here to remove these attachments</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Those attachments have now been removed and you have been returned to the page you were previously on';
$txt['error_temp_attachments_flushed'] = 'Please note that any files which had been previously attached, but not posted, have now been removed.';
$txt['error_topic_already_announced'] = 'Please note that this topic has already been announced.';

$txt['cant_access_upload_path'] = 'Geen toegang tot de uploadmap van de bijlagen!';
$txt['file_too_big'] = 'Your file is too large. The maximum attachment size allowed is %1$s KB.';
$txt['attach_timeout'] = 'Er is iets fout gegaan bij het wegschrijven van je bijlage, probeer het alsjeblieft nog eens.';
$txt['bad_attachment'] = 'Je bijlage passeerde de beveiliginscontroles niet en wordt daarom niet opgeslagen. Neem contact op met de forumbeheerder.';
$txt['ran_out_of_space'] = 'The upload directory is full. Please contact an administrator about this problem.';
$txt['attachments_no_write'] = 'De bijlage-upload-directory is niet schrijfbaar. De bijlage of avatar kan niet worden opgeslagen.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory.  Your attachment or avatar cannot be saved.';
$txt['attachments_limit_per_post'] = 'Je mag niet meer dan %1$d bijlagen per bericht uploaden';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Insert';
$txt['ila_opt_size'] = 'Grootte';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Geen';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Center';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/