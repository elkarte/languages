<?php
// Version: 1.1; ManageSmileys

$txt['smiley_sets_save'] = 'Opslaan';
$txt['smiley_sets_add'] = 'New Smiley Set';
$txt['smiley_sets_delete'] = 'Verwijder selectie';
$txt['smiley_sets_confirm'] = 'Weet je zeker dat je deze smileysets wilt verwijderen?\\n\\nLet op: dit zal niet de plaatjes zelf verwijderen, alleen de keuzes.';
$txt['smiley_sets_none'] = 'There are currently no smiley sets.';

$txt['setting_smiley_sets_default'] = 'Standaard smileyset';
$txt['setting_smiley_sets_enable'] = 'Sta leden toe een smileyset te selecteren';
$txt['setting_smiley_enable'] = 'Activeer aangepaste smileys';
$txt['setting_smileys_url'] = 'Basis-URL naar alle smileysets';
$txt['setting_smileys_dir'] = 'Absolute pad naar alle smileysets';
$txt['setting_messageIcons_enable'] = 'Stel instelbare berichticonen in';
$txt['setting_messageIcons_enable_note'] = '(anders worden de standaard berichticonen gebruikt)';
$txt['groups_manage_smileys'] = 'Groepen die smileys en berichticonen mogen beheren';

$txt['smiley_sets_name'] = 'Naam';
$txt['smiley_sets_url'] = 'URL';
$txt['smiley_sets_default'] = 'Standaard';

$txt['smileys_add_method'] = 'Afbeeldingslocatie';
$txt['smileys_add_existing'] = 'Use existing file';
$txt['smileys_add_upload'] = 'Upload new smiley';
$txt['smileys_add_upload_choose'] = 'Bestandsnaam om te uploaden';
$txt['smileys_add_upload_choose_desc'] = 'Plaatje dat gebruikt wordt door alle smileysets.';
$txt['smileys_add_upload_all'] = 'Gebruik hetzelfde plaatje voor alle smileysets';
$txt['smileys_add_upload_for1'] = 'Plaatje voor de ';
$txt['smileys_add_upload_for2'] = 'set';

$txt['smileys_enable_note'] = '(anders zullen de standaardsmileys worden gebruikt)';
$txt['smileys_code'] = 'Code';
$txt['smileys_filename'] = 'Bestandsnaam';
$txt['smileys_description'] = 'Tooltip of beschrijving';
$txt['smileys_remove'] = 'Verwijder';
$txt['smileys_save'] = 'Opslaan';
$txt['smileys_delete'] = 'Verwijder smiley';
// Don't use entities in the below string.
$txt['smileys_delete_confirm'] = 'Weet je zeker dat je deze smiley wilt verwijderen?';
$txt['smileys_with_selected'] = 'Met geselecteerde';
$txt['smileys_make_hidden'] = 'Maak onzichtbaar';
$txt['smileys_show_on_post'] = 'Show on post form';
$txt['smileys_show_on_popup'] = 'Show on popup';

$txt['smiley_settings_explain'] = 'Deze instellingen geven de mogelijkheid om in te stellen welke smileyset standaard geselecteerd is, of mensen hun eigen smileys mogen selecteren en paden naar smileys en andere configuratiegegegevens.';
$txt['smiley_editsets_explain'] = 'Smileysets zijn groepen smileys waartussen de gebruikers kunnen kiezen. Je zou bijvoorbeeld gele en rode smileys kunnen hebben.<br />Hier kun je de naam en locatie van elke smileyset instellen.';
$txt['smiley_editsmileys_explain'] = 'Change your smileys here by clicking on the smiley you want to modify. Remember that these smileys all have to exist in all the sets or some smileys won\'t show up.  Don\'t forget to save after you are done editing.';
$txt['smiley_setorder_explain'] = 'Verander de volgorde van de smileys hier.';
$txt['smiley_addsmiley_explain'] = 'Hier kun je een nieuwe smiley toevoegen - of van een bestaand bestand of door het uploaden van een nieuwe.';

$txt['smiley_set_select_default'] = 'Standaard smileyset';
$txt['smiley_set_new'] = 'Create new Smiley Set';
$txt['smiley_set_modify_existing'] = 'Modify existing Smiley Set';
$txt['smiley_set_modify'] = 'Bewerk';
$txt['smiley_set_import_directory'] = 'Importeer smileys die reeds in deze directory zijn';
$txt['smiley_set_import_single'] = 'Er is &eacute;&eacute;n smiley in deze smileyset die nog niet ge&iuml;mporteerd is. Klik';
$txt['smiley_set_import_multiple'] = 'Er zijn %1$d nog niet zijn ge&iuml;mporteerde smileys in deze map. Klik';
$txt['smiley_set_to_import_single'] = 'om deze nu te importeren.';
$txt['smiley_set_to_import_multiple'] = 'om deze nu te importeren.';

$txt['smileys_location'] = 'Locatie';
$txt['smileys_location_form'] = 'Postformulier';
$txt['smileys_location_hidden'] = 'verborgen';
$txt['smileys_location_popup'] = 'Popup';
$txt['smileys_modify'] = 'Bewerk';
$txt['smileys_not_found_in_set'] = 'Smiley niet gevonden in set(s)';
$txt['smileys_default_description'] = '(beschrijving)';
$txt['smiley_new'] = 'Voeg nieuwe smiley toe';
$txt['smiley_modify_existing'] = 'Bewerk smiley';
$txt['smiley_preview'] = 'Bekijken';
$txt['smiley_preview_using'] = 'gebruik smileyset';
$txt['smileys_confirm'] = 'Weet je zeker dat je deze smileys wilt verwijderen?\\n\\nLet op: dit verwijdert niet de plaatjes zelf, alleen de keuzes.';
$txt['smileys_location_form_description'] = 'Deze smileys zullen verschijnen boven het invoervak, bij het plaatsen van een nieuw forumbericht of Persoonlijk Bericht.';
$txt['smileys_location_popup_description'] = 'Deze smileys zullen getoond worden in een popup scherm, die getoond wordt nadat een gebruiker op \'[meer]\' geklik heeft';
$txt['smileys_move_select_destination'] = 'Selecteer de bestemming van de smiley';
$txt['smileys_move_select_smiley'] = 'Select smiley to move or drag it to the location you want';
$txt['smileys_move_here'] = 'Verplaats de smiley naar deze locatie';
$txt['smileys_no_entries'] = 'Er zijn momenteel geen smileys geconfigureerd.';
$txt['smileys_moved_done'] = 'Smiley successfully moved';
$txt['smileys_moved_fail'] = 'Unable to move smiley';

$txt['icons_edit_icons_explain'] = 'Hier kun je veranderen welke berichticonen beschikbaar zijn binnen je forum. Je kunt iconen toevoegen, bewerken en verwijderen, alsmede hun gebruik beperken tot bepaalde boards.';
$txt['icons_edit_icons_all_boards'] = 'Available in all boards';
$txt['icons_board'] = 'Board';
$txt['icons_confirm'] = 'Weet je zeker dat je deze iconen wilt verwijderen? \\n\\nBedenk dat dit alleen zal voorkomen dat plaatsers van nieuwe berichten deze iconen zullen gebruiken, de plaatjes blijven staan.';
$txt['icons_add_new'] = 'Add new icon';

$txt['icons_edit_icon'] = 'Edit message icon';
$txt['icons_new_icon'] = 'New message icon';
$txt['icons_location_first_icon'] = 'As first icon';
$txt['icons_location_after'] = 'Na';
$txt['icons_filename_all_png'] = 'All files must be &quot;png&quot; files';
$txt['icons_no_entries'] = 'Er zijn momenteel geen berichticonen geconfigureerd.';
$txt['icons_reordered'] = 'Message Icons successfully reordered';
$txt['icons_reorder_note'] = 'You can change the message icon order by dragging and dropping an item to a new location in the list.';