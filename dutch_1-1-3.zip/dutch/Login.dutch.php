<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Registratieovereenkomst';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'Ik accepteer de bepalingen van de overeenkomst.';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Ik accepteer de bepalingen van de overeenkomst en ben ten minste %1$d jaar oud.';
$txt['agreement_agree_coppa_below'] = 'Ik accepteer de bepalingen van de overeenkomst en ben jonger dan %1$d jaar oud.';
$txt['agree_coppa_above'] = 'I am at least %1$d years old.';
$txt['agree_coppa_below'] = 'I am younger than %1$d years old.';

// Registration form.
$txt['registration_form'] = 'Registratieformulier';
$txt['error_too_quickly'] = 'You went through the registration process too quickly, faster than should normally be possible. Please wait a moment and try again.';
$txt['error_token_verification'] = 'Token verification failed. Please try again.';
$txt['need_username'] = 'Je moet een gebruikersnaam invullen.';
$txt['no_password'] = 'Je hebt geen wachtwoord ingevuld.';
$txt['improper_password'] = 'The supplied password is too long.';
$txt['incorrect_password'] = 'Wachtwoord niet correct';
$txt['openid_not_found'] = 'Supplied OpenID identifier not found.';
$txt['maintain_mode'] = 'Onderhoudsstand';
$txt['registration_successful'] = 'Registratie succesvol';
$txt['valid_email_needed'] = 'Vul een geldig e-mailadres in, (%1$s)';
$txt['required_info'] = 'Verplichte velden';
$txt['additional_information'] = 'Additionele informatie';
$txt['warning'] = 'Waarschuwing!';
$txt['only_members_can_access'] = 'Alleen geregistreerde leden hebben toegang tot dit gedeelte.';
$txt['login_below'] = 'Please login below.';
$txt['login_below_or_register'] = 'Please login below or <a href="%1$s">register an account</a> with %2$s';
$txt['checkbox_agreement'] = 'I accept the registration agreement';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Password security has recently been upgraded.<br />Please enter your password again.';

$txt['ban_register_prohibited'] = 'Sorry, je mag je niet registreren op dit forum';
$txt['under_age_registration_prohibited'] = 'Sorry, maar gebruikers onder de leeftijd van %1$d mogen zich niet registreren op dit forum';

$txt['activate_account'] = 'Accountactivering';
$txt['activate_success'] = 'Je accountactivering verliep succesvol. Je kunt nu inloggen.';
$txt['activate_not_completed1'] = 'Je e-mailadres moet eerst gevalideerd worden voor je kunt inloggen.';
$txt['activate_not_completed2'] = 'Nieuwe activeringsemail nodig?';
$txt['activate_after_registration'] = 'Bedankt voor het registreren. Je ontvangt een e-mail met een link om je account te activeren.  Als je na verloop van tijd geen e-mail hebt ontvangen, check dan je spamfolder.';
$txt['invalid_userid'] = 'Gebruiker bestaat niet';
$txt['invalid_activation_code'] = 'Ongeldige activeringscode';
$txt['invalid_activation_username'] = 'Gebruikersnaam of e-mailadres';
$txt['invalid_activation_new'] = 'Type als je met een foutief e-mailadres bent geregistreerd het juiste e-mailadres en je wachtwoord hier in.';
$txt['invalid_activation_new_email'] = 'Nieuw e-mailadres';
$txt['invalid_activation_password'] = 'Oude wachtwoord';
$txt['invalid_activation_resend'] = 'Activeringscode opnieuw versturen';
$txt['invalid_activation_known'] = 'Als je de activeringscode al kent, kun je die hier intypen.';
$txt['invalid_activation_retry'] = 'Activeringscode';
$txt['invalid_activation_submit'] = 'Activeren';

$txt['coppa_no_concent'] = 'De forumbeheerder heeft nog geen toestemming van je ouders/voogden ontvangen voor je account.';
$txt['coppa_need_more_details'] = 'Meer details nodig?';

$txt['awaiting_delete_account'] = 'Je hebt je account gemarkeerd voor verwijdering!<br />Als je je account wilt herstellen, vink dan &quot;Herstel mijn account&quot; aan en log dan opnieuw in.';
$txt['undelete_account'] = 'Herstel mijn account';

$txt['in_maintain_mode'] = 'Het forum bevindt zich in de onderhoudsmodus.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Lees en accepteer de overeenkomst voor je jezelf registreert.';
$txt['register_passwords_differ_js'] = 'De twee wachtwoorden komen niet overeen!';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Bedankt voor je registratie. De beheerder moet je registratie goedkeuren alvorens je kunt inloggen. Je ontvangt hierover zeer binnenkort een e-mail.';

$txt['admin_settings_desc'] = 'Hier kun je diverse instellingen veranderen met betrekking tot de registratie van nieuwe leden.';

$txt['setting_enableOpenID'] = 'Sta gebruikers toe te registreren middels OpenID';

$txt['setting_registration_method'] = 'Registratiemethode voor nieuwe leden';
$txt['setting_registration_disabled'] = 'Registratie uitgeschakeld';
$txt['setting_registration_standard'] = 'Directe registratie';
$txt['setting_registration_activate'] = 'Activatie via e-mail';
$txt['setting_registration_approval'] = 'Goedkeuring door beheerder';
$txt['setting_notify_new_registration'] = 'Breng beheerders op de hoogte als een nieuw lid zich geregistreerd heeft';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Stuur een welkomst-e-mail naar het nieuwe lid als je geen wachtwoord via e-mail verstuurt?';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Leeftijd waar beneden de restricties gelden';
$txt['setting_coppaAge_desc'] = '(0 om uit te schakelen)';
$txt['setting_coppaType'] = 'Te nemen actie als een gebruiker onder de minimumleeftijd zich registreert';
$txt['setting_coppaType_reject'] = 'Verwerp de registratie';
$txt['setting_coppaType_approval'] = 'Vereis ouderlijke goedkeuring';
$txt['setting_coppaPost'] = 'Postadres waar het goedkeuringsformulier naar toe gestuurd moet worden';
$txt['setting_coppaPost_desc'] = 'Alleen van toepassing als de leeftijdsrestrictie ingesteld staat';
$txt['setting_coppaFax'] = 'Faxnummer waar de goedkeuring naar gefaxt kan worden';
$txt['setting_coppaPhone'] = 'Telefoonnummer voor ouders om contact op te nemen voor leeftijdsrestrictievragen';

$txt['admin_register'] = 'Registratie van een nieuw lid';
$txt['admin_register_desc'] = 'Vanaf hier kun je nieuwe leden registreren en hen, indien gewenst, de details mailen.';
$txt['admin_register_username'] = 'Nieuwe gebruikersnaam';
$txt['admin_register_email'] = 'E-mailadres';
$txt['admin_register_password'] = 'Wachtwoord';
$txt['admin_register_username_desc'] = 'Gebruikersnaam van het nieuwe lid';
$txt['admin_register_email_desc'] = 'E-mailadres van het lid';
$txt['admin_register_password_desc'] = 'Nieuw wachtwoord voor gebruiker';
$txt['admin_register_email_detail'] = 'E-mail nieuw wachtwoord naar gebruiker';
$txt['admin_register_email_detail_desc'] = 'E-mailadres vereist zelfs indien niet aangevinkt';
$txt['admin_register_email_activate'] = 'Gebruiker dient zijn account te activeren';
$txt['admin_register_group'] = 'Primaire ledengroep';
$txt['admin_register_group_desc'] = 'Primaire ledengroep waar het nieuwe lid toe zal behoren';
$txt['admin_register_group_none'] = '(geen primaire ledengroep)';
$txt['admin_register_done'] = 'Het lid %1$s is met succes geregistreerd!';

$txt['coppa_title'] = 'Leeftijdsbeperkt forum';
$txt['coppa_after_registration'] = 'Thank you for registering with {forum_name_html_safe}.<br /><br />Because you fall under the age of {MINIMUM_AGE}, it is a legal requirement to obtain your parent or guardian\'s permission before you may begin to use your account.  To arrange for account activation please print off the form below:';
$txt['coppa_form_link_popup'] = 'Laad het formulier in een nieuw venster';
$txt['coppa_form_link_download'] = 'Download formulier als een tekstbestand';
$txt['coppa_send_to_one_option'] = 'Zorg er daarna voor dat je ouders of voogd het ingevulde formulier opsturen naar:';
$txt['coppa_send_to_two_options'] = 'Zorg er daarna voor dat je ouders of voogd het ingevulde formulier opsturen naar:';
$txt['coppa_send_by_post'] = 'Post, naar het volgende adres:';
$txt['coppa_send_by_fax'] = 'Fax, naar het volgende nummer:';
$txt['coppa_send_by_phone'] = 'Eventueel kun je hen ook laten bellen naar de forumbeheerder op {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Permission form for registration at {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Adres';
$txt['coppa_form_date'] = 'Datum';
$txt['coppa_form_body'] = 'I {PARENT_NAME},<br /><br />give permission for {CHILD_NAME} (child name) to become a fully registered member of the forum: {forum_name_html_safe}, with the username: {USER_NAME}.<br /><br />I understand that certain personal information entered by {USER_NAME} may be shown to other users of the forum.<br /><br />Signed:<br />{PARENT_NAME} (Parent/Guardian).';

$txt['visual_verification_sound_again'] = 'Speel opnieuw';
$txt['visual_verification_sound_close'] = 'Sluit dit scherm';
$txt['visual_verification_sound_direct'] = 'Heb je problemen met het beluisteren? Probeer een directe link naar het geluid.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Gebruikersnaam is beschikbaar';
$txt['registration_username_unavailable'] = 'Gebruikersnaam is niet beschikbaar';
$txt['registration_username_check'] = 'Controleer beschikbaarheid gebruikersnaam';
$txt['registration_password_short'] = 'Wachtwoord is te kort';
$txt['registration_password_reserved'] = 'Wachtwoord bevat gebruikersnaam of e-mail';
$txt['registration_password_numbercase'] = 'Wachtwoord moet groot en klein kapitaal en nummers bevatten';
$txt['registration_password_no_match'] = 'Wachtwoorden komen niet overeen';
$txt['registration_password_valid'] = 'Wachtwoord is geldig';

$txt['registration_errors_occurred'] = 'De onderstaande fouten ontstonden bij je registratie. Verbeter ze voor je doorgaat.';

$txt['authenticate_label'] = 'Authenticatiemethode';
$txt['authenticate_password'] = 'Wachtwoord';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'OpenID authenticatie-URL';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'Contact the admins';
$txt['contact_your_message'] = 'Your message';
$txt['errors_contact_form'] = 'The following errors occurred while processing your contact request';
$txt['contact_subject'] = 'A guest has sent you a message';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
