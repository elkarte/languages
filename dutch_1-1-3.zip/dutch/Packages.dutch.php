<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Ga verder';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Lijst van bestanden in het pakket';
$txt['files_archive'] = 'Bestanden in het archief';
$txt['package_browse'] = 'Bladeren';
$txt['add_server'] = 'Server toevoegen';
$txt['server_name'] = 'Servernaam';
$txt['serverurl'] = 'URL';
$txt['no_packages'] = 'Nog geen pakketten';
$txt['download'] = 'Download';
$txt['download_success'] = 'Pakket is gedownload';
$txt['package_downloaded_successfully'] = 'Het pakket is met succes gedownload';
$txt['package_manager'] = 'Pakketbeheerder';
$txt['install_mod'] = 'Install Add-on';
$txt['uninstall_mod'] = 'Uninstall Add-on';
$txt['no_adds_installed'] = 'No addons currently installed';
$txt['uninstall'] = 'De&iuml;nstalleer';
$txt['delete_list'] = 'Delete Add-on List';
$txt['package_delete_list_warning'] = 'Are you sure you wish to clear the installed addons list?';

$txt['package_manager_desc'] = 'From this easy to use interface, you can download and install addons for use on your forum.';
$txt['installed_packages_desc'] = 'Je kunt de interface hieronder gebruiken om de pakketten die momenteel op het forum zijn ge&iuml;nstalleerd te bekijken en de pakketten die je niet meer nodig hebt te verwijderen.';
$txt['download_packages_desc'] = 'From this section you can add or remove package servers, browse for packages, or download new packages from servers.';
$txt['package_servers_desc'] = 'From this easy to use interface, you can manage your package servers and download addon archives on your forum.';
$txt['upload_packages_desc'] = 'From this section you can upload a package file from your local computer directly to the forum.';

$txt['upload_new_package'] = 'Upload new package';
$txt['view_and_remove'] = 'View and remove installed packages';
$txt['modification_package'] = 'Add-on packages';
$txt['avatar_package'] = 'Avatar packages';
$txt['language_package'] = 'Language packages';
$txt['unknown_package'] = 'Other packages';
$txt['smiley_package'] = 'Smiley packages';
$txt['use_avatars'] = 'Gebruik avatars';
$txt['add_languages'] = 'Taal toevoegen';
$txt['list_files'] = 'Overzicht bestanden';
$txt['package_type'] = 'Pakkettype';
$txt['extracting'] = 'Uitpakken';
$txt['avatars_extracted'] = 'The avatars have been installed, you should now be able to use them.';
$txt['language_extracted'] = 'The language pack has been installed, you can now enable its use in the language settings area of your admin control panel.';

$txt['mod_name'] = 'Add-on Name';
$txt['mod_version'] = 'Versie';
$txt['mod_author'] = 'Auteur';
$txt['author_website'] = 'Website van de maker';
$txt['package_no_description'] = 'No description given';
$txt['package_description'] = 'Beschrijving';
$txt['file_location'] = 'Download';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'No source edits';
$txt['mod_date'] = 'Last updated';
$txt['mod_section_count'] = 'Browse the (%1d) addons in this section';

// Package Server strings
$txt['package_current'] = '(%s <em>You have the Current version %s</em>)';
$txt['package_update'] = '(%s <em>An update for your %s version is available</em>)';
$txt['package_installed'] = 'installed';
$txt['package_downloaded'] = 'gedownload';

$txt['package_installed_key'] = 'Installed addons:';
$txt['package_installed_current'] = 'huidige versie';
$txt['package_installed_old'] = 'oudere versie';
$txt['package_installed_warning1'] = 'This package is already installed, and no upgrade was found.';
$txt['package_installed_warning2'] = 'Je zult de oude versie eerst moeten de&iuml;nstalleren om problemen te voorkomen, of de maker moeten vragen om een upgrade te maken voor jouw versie.';
$txt['package_installed_warning3'] = 'Denk eraan om een backup te maken van de database en de bestanden in de map \'Sources\' voor je mods installeert - zeker bij b&egrave;taversies.';
$txt['package_installed_extract'] = 'Pakket uitpakken';
$txt['package_installed_done'] = 'Het pakket is ge&iuml;nstalleerd. Je zou nu alle toegevoegde of gewijzigde functionaliteit moeten kunnen gebruiken.';
$txt['package_installed_redirecting'] = 'Bezig met doorschakelen...';
$txt['package_installed_redirect_go_now'] = 'Nu doorschakelen';
$txt['package_installed_redirect_cancel'] = 'Terug naar pakketbeheer';

$txt['package_upgrade'] = 'Upgrade';
$txt['package_uninstall_readme'] = 'Informatie voor de&iuml;nstallatie';
$txt['package_install_readme'] = 'Informatie voor installatie';
$txt['package_install_license'] = 'License';
$txt['package_install_type'] = 'Type';
$txt['package_install_action'] = 'Actie';
$txt['package_install_desc'] = 'Beschrijving';
$txt['install_actions'] = 'Installatie-acties';
$txt['perform_actions'] = 'This will perform the following actions:';
$txt['corrupt_compatible'] = 'The package you are trying to download or install is either corrupt or not compatible with this version of the software.';
$txt['package_create'] = 'Nieuw';
$txt['package_move'] = 'Verplaatsen';
$txt['package_delete'] = 'Verwijder';
$txt['package_extract'] = 'Uitpakken';
$txt['package_file'] = 'Bestand';
$txt['package_tree'] = 'Boom';
$txt['execute_modification'] = 'Voer aanpassing uit';
$txt['execute_code'] = 'Voer code uit';
$txt['execute_database_changes'] = 'Execute file';
$txt['execute_hook_add'] = 'Add Hook';
$txt['execute_hook_remove'] = 'Remove Hook';
$txt['execute_hook_action'] = 'Adapting hook %1$s';
$txt['package_requires'] = 'Requires Modification';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Add Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'Installatieacties voor';
$txt['package_will_fail_title'] = 'Error in package %1$s';
$txt['package_will_fail_warning'] = 'At least one error was encountered during a test %1$s of this package.<br />It is <strong>strongly</strong> recommended that you do not continue with %1$s unless you know what you are doing, and have made a backup very recently.<br /><br />This error may be caused by a conflict between the package you\'re trying to install and another package you have already installed, an error in the package, a package which requires another package that you have not installed yet, or a package designed for another version of the software.';
$txt['package_will_fail_unknown_action'] = 'The package is trying to perform an unknown action: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Are you sure you wish to continue installing this addon, even though it will not install successfully?';
$txt['package_will_fail_popup_uninstall'] = 'Are you sure you wish to continue uninstalling this addon, even though it will not uninstall successfully?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'removal';
$txt['package_install_now'] = 'Install now';
$txt['package_uninstall_now'] = 'Uninstall now';
$txt['package_other_themes'] = 'Install in other themes';
$txt['package_other_themes_uninstall'] = 'UnInstall in other themes';
$txt['package_other_themes_desc'] = 'To use this addon in themes other than the default, the package manager needs to make additional changes to the other themes. If you\'d like to install this addon in the other themes, please select these themes below.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Ten minste &eacute;&eacute;n fout is opgetreden tijdens een testinstallatie van dit thema. Weet je zeker dat je door wilt gaan met de installatie?';

$txt['package_bytes'] = 'bytes';

$txt['package_action_missing'] = '<strong class="error">Bestand niet gevonden</strong>';
$txt['package_action_error'] = '<strong class="error">Modificatieverwerkingsfout</strong>';
$txt['package_action_failure'] = '<strong class="error">Test mislukt</strong>';
$txt['package_action_success'] = '<strong>Succes</strong>';
$txt['package_action_skipping'] = '<strong>Bestand overgeslagen</strong>';

$txt['package_uninstall_actions'] = 'De&iuml;nstallatie-acties';
$txt['package_uninstall_done'] = 'The package has been successfully uninstalled.';
$txt['package_uninstall_cannot'] = 'This package cannot be uninstalled, because there is no uninstaller.<br /><br />Please contact the addon author for more information.';

$txt['package_install_options'] = 'Installatieopties';
$txt['package_install_options_desc'] = 'Set various options for how the package manager installs addons, including backups and ftp access';
$txt['package_install_options_ftp_why'] = 'De FTP-functionaliteit van het pakketbeheer is de meest eenvoudige manier om het handmatig CHMOD\'en van bestanden die de FTP zelf kan beschrijven te omzeilen.<br />Hier kun je de standaardwaarde voor sommige velden instellen.';
$txt['package_install_options_ftp_server'] = 'FTP-server';
$txt['package_install_options_ftp_port'] = 'Poort';
$txt['package_install_options_ftp_user'] = 'Gebruikersnaam';
$txt['package_install_options_make_backups'] = 'Maak backups van de aan te passen bestanden door een kopie te maken met een tilde (~) achter de bestandsnaam.';
$txt['package_install_options_make_full_backups'] = 'Create an entire backup (excluding smileys, avatars and attachments) of the ElkArte install.';

$txt['package_ftp_necessary'] = 'FTP-informatie benodigd';
$txt['package_ftp_why'] = 'Some of the files the package manager needs to modify are not writable.  This needs to be changed by logging into FTP and using it to chmod or create the files and directories.  Your FTP information may be temporarily cached for proper operation of the package manager. Note you can also do this manually using an FTP client - <a href="#" onclick="%1$s">to view a list of the affected files please click here</a>.';
$txt['package_ftp_why_file_list'] = 'De volgende bestanden moeten beschrijfbaar worden gemaakt om door te gaan met de installatie:';
$txt['package_ftp_why_download'] = 'In order to download packages, the packages directory, and any files in it, must be writable.  Currently the system does not have the needed permissions to write to this directory.  The package manager can use your FTP information to attempt to fix this problem.';
$txt['package_ftp_server'] = 'FTP-server';
$txt['package_ftp_port'] = 'Poort';
$txt['package_ftp_username'] = 'Gebruikersnaam';
$txt['package_ftp_password'] = 'Wachtwoord';
$txt['package_ftp_path'] = 'Local path to ElkArte';
$txt['package_ftp_test'] = 'Test';
$txt['package_ftp_test_connection'] = 'Verbinding testen';
$txt['package_ftp_test_success'] = 'Verbinding gemaakt met de FTP-server.';
$txt['package_ftp_test_failed'] = 'Kon geen verbinding maken met de server.';
$txt['package_ftp_bad_server'] = 'Kon geen verbinding maken met de server.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Het pakket dat je wilt verwijderen is momenteel ge&iuml;nstalleerd! Als je het verwijdert, zou het kunnen zijn dat je het later niet meer kunt de&iuml;nstalleren.\\n\\nWeet je het zeker?';

$txt['package_examine_file'] = 'Bekijk bestand in het pakket';
$txt['package_file_contents'] = 'Inhoud van het bestand';

$txt['package_upload_title'] = 'Upload een pakket';
$txt['package_upload_select'] = 'Pakket om te uploaden';
$txt['package_upload'] = 'Upload';
$txt['package_uploaded_success'] = 'Package succesvol geupload ';
$txt['package_uploaded_successfully'] = 'Het pakket is succesvol geupload';

$txt['package_modification_malformed'] = 'Malformed or invalid addon file.';
$txt['package_modification_missing'] = 'Het bestand kon niet gevonden worden.';
$txt['package_no_zlib'] = 'Sorry, je PHP-configuratie biedt geen ondersteuning voor <strong>zlib</strong>. Zonder dit kan het pakketbeheer niet werken. Neem contact op met je provider voor meer informatie.';

$txt['package_cleanperms_title'] = 'Permissies opschonen';
$txt['package_cleanperms_desc'] = 'Dit scherm stelt je in staat de permissies voor bestanden tijdens de installatie te herstellen, om beveiligingsredenen en eventuele problemen die je op een later tijdstip tegen zou kunnen komen bij het installeren van pakketten.';
$txt['package_cleanperms_type'] = 'Zet alle bestandspermissies tijdens de installatie zo dat';
$txt['package_cleanperms_standard'] = 'Alleen de standaardbestanden schrijfbaar zijn.';
$txt['package_cleanperms_free'] = 'Alle bestanden schrijfbaar zijn.';
$txt['package_cleanperms_restrictive'] = 'De minimumbestanden schrijfbaar zijn.';
$txt['package_cleanperms_go'] = 'Ga';

$txt['package_download_by_url'] = 'Download een pakket via URL';
$txt['package_download_filename'] = 'Naam van het bestand';
$txt['package_download_filename_info'] = 'Optionele waarde. Zou gebruikt moeten worden wanneer de URL niet met een bestandsnaam eindigt. Bijvoorbeeld: index.php?mod=5';

$txt['package_db_uninstall'] = 'Remove all data associated with this addon.';
$txt['package_db_uninstall_details'] = 'Details';
$txt['package_db_uninstall_actions'] = 'Checking this option will result in the following actions';
$txt['package_db_remove_table'] = 'Verwijder tabel &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Verwijder kolom &quot;%2$s&quot; van &quot;%1$s&quot;';
$txt['package_db_remove_index'] = 'Verwijder index &quot;%1$s&quot; van &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Install Emulating:';
$txt['package_emulate_uninstall'] = 'Uninstall Emulating:';

// Operations.
$txt['operation_find'] = 'Zoek';
$txt['operation_replace'] = 'Vervang';
$txt['operation_after'] = 'Voeg toe na';
$txt['operation_before'] = 'Voeg toe voor';
$txt['operation_title'] = 'Handelingen';
$txt['operation_ignore'] = 'Negeer fouten';
$txt['operation_invalid'] = 'De geselecteerde handeling is ongeldig.';

$txt['package_file_perms_desc'] = 'Je kunt deze sectie gebruiken om de schrijfbaarheidsstatus te bekijken van bepaalde essenti&euml;le bestanden en mappen van je forum. Merk op dat het hier louter om de sleutelbestanden en -mappen gaat. Voor andere bestanden en mappen kun je een FTP-client gebruiken.';
$txt['package_file_perms_name'] = 'File/Directory Name';
$txt['package_file_perms_status'] = 'Huidige status';
$txt['package_file_perms_new_status'] = 'Nieuwe status';
$txt['package_file_perms_status_read'] = 'gelezen';
$txt['package_file_perms_status_write'] = 'Schrijfbaar';
$txt['package_file_perms_status_execute'] = 'Uitvoerbaar';
$txt['package_file_perms_status_custom'] = 'Aangepast';
$txt['package_file_perms_status_no_change'] = 'Niet wijzigen';
$txt['package_file_perms_writable'] = 'Beschrijfbaar';
$txt['package_file_perms_not_writable'] = 'Niet beschrijfbaar';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Meer bestanden';

$txt['package_file_perms_change'] = 'Verander bestandspermissies';
$txt['package_file_perms_predefined'] = 'Gebruik een vooraf gedefinieerd permissieprofiel';
$txt['package_file_perms_predefined_note'] = 'Note that this only applies the predefined profile to key directories and files.';
$txt['package_file_perms_apply'] = 'Pas de hierboven geselecteerde permissies toe.';
$txt['package_file_perms_custom'] = 'Als &quot;Aangepast&quot; is geselecteerd, gebruik dan de volgende CHMOD waarde';
$txt['package_file_perms_pre_restricted'] = 'gerestricteerd - minimum aantal bestanden beschrijfbaar';
$txt['package_file_perms_pre_standard'] = 'standaard - sleutelbestanden beschrijfbaar';
$txt['package_file_perms_pre_free'] = 'vrij - alle bestanden beschrijfbaar';
$txt['package_file_perms_ftp_details'] = 'Op de meeste servers is het alleen mogelijk om bestandspermissies via FTP aan te passen. Vul hieronder je FTP-gegevens in';
$txt['package_file_perms_ftp_retain'] = 'Note, the system will only retain the password information temporarily to aid operation of the package manager.';
$txt['package_file_perms_go'] = 'Wijzigingen doorvoeren';

$txt['package_file_perms_applying'] = 'Wijzigingen worden doorgevoerd';
$txt['package_file_perms_items_done'] = '%1$d van de %2$d items voltooid';
$txt['package_file_perms_skipping_ftp'] = '<strong>Waarschuwing:</strong> kon geen verbinding maken met de FTP-server. Er wordt geprobeerd de wijzigingen zonder FTP door te voeren. Het is <em>aannemelijk</em> dat dit mislukt, dus controleer het resultaat na voltooiing en probeer het indien nodig nogmaals met de juiste FTP-informatie.';

$txt['package_file_perms_dirs_done'] = '%1$d van de %2$d mappen voltooid';
$txt['package_file_perms_files_done'] = '%1$d van de %2$d bestanden voltooid in de huidige map';

$txt['chmod_value_invalid'] = 'Je hebt een ongeldige chmod-waarde ingevuld. De waarde moet tussen 0444 en 0777 liggen!';

$txt['package_restore_permissions'] = 'Restore file permissions';
$txt['package_restore_permissions_desc'] = 'The following file permissions were changed in order to install the selected package(s). You can return these files back to their original status by clicking &quot;Restore&quot; below.';
$txt['package_restore_permissions_restore'] = 'Herstel bericht';
$txt['package_restore_permissions_filename'] = 'Bestandsnaam';
$txt['package_restore_permissions_orig_status'] = 'Originele status';
$txt['package_restore_permissions_cur_status'] = 'Huidige status';
$txt['package_restore_permissions_result'] = 'Resultaat';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - was %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Overgeslagen</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Success</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Mislukt</span>';
$txt['package_restore_permissions_action_done'] = 'An attempt to restore the selected files back to their original permissions has been completed, the results can be seen below. If a change failed, or for a more detailed view of file permissions, please see the <a href="%1$s">File Permissions</a> section.';

$txt['package_file_perms_warning'] = 'Opmerking';
$txt['package_file_perms_warning_desc'] = '
	Be careful when changing file permissions from this section - incorrect permissions can adversely affect the operation of your forum!<br />
	On some server configurations selecting the wrong permissions may stop the forum from operating.<br />
	Certain directories such as <em>attachments</em> need to be writable to use that functionality.<br />
	This functionality is mainly applicable on non-Windows based servers - it will not work as expected on Windows in regards to permission flags.<br />
	Before proceeding make sure you have an FTP client installed in case you do make an error and need to FTP into the server to remedy it.';

$txt['package_confirm_view_package_content'] = 'Weet je zeker dat je de pakketinhoud van deze locatie wilt ophalen:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Ga verder';
$txt['package_confirm_go_back'] = 'Ga terug';

$txt['package_readme_default'] = 'Standaard';
$txt['package_available_readme_language'] = 'Beschikbare talen voor deze leesmij:';
$txt['package_license_default'] = 'Standaard';
$txt['package_available_license_language'] = 'Available License Languages:';