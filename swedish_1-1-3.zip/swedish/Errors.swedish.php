<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Sorry, we can\'t let you access this section. We can\'t even tell you if it exists. You\'re welcome to visit the main page and choose your way from there.';
$txt['not_guests'] = 'Sorry, this action is not available to guests.';

$txt['mods_only'] = 'Only moderators can use the direct remove function, please remove this message through the modify feature.';
$txt['no_name'] = 'You didn\'t fill the name field out. We can\'t let you continue without a name, sorry.';
$txt['no_email'] = 'You didn\'t fill the email field out. We can\'t let you continue without an email, sorry.';
$txt['topic_locked'] = 'Det här ämnet är låst, du har inte behörighet att svara eller redigera inlägg...';
$txt['no_password'] = 'Lösenordsfältet är tomt';
$txt['passwords_dont_match'] = 'Dina två inskrivningar av lösenordet stämde inte överens med varann.';
$txt['register_to_use'] = 'Beklagar, du måste registrera dig som medlem innan du använder denna funktion.';
$txt['username_reserved'] = 'The user name you tried to use contains the reserved name \'%1$s\'. Please try another user name.';
$txt['numbers_one_to_nine'] = 'Detta fält tillåter bara nummer mellan 0 och 9';
$txt['not_a_user'] = 'Användaren vars profil du försöker att titta på existerar inte.';
$txt['not_a_topic'] = 'Ämnet existerar inte på den här tavlan.';
$txt['not_approved_topic'] = 'Detta ämne har inte godkänts ännu.';
$txt['email_in_use'] = 'E-postadressen (%1$s) används redan av en annan medlem. Om du tror att det är ditt eget, gå till inloggningssidan och använd funktionen "Glömt bort lösenordet?" med den e-postadressen.';

$txt['didnt_select_vote'] = 'Du angav inga röstningsalternativ.';
$txt['poll_error'] = 'Something isn\'t working, sorry: either that poll doesn\'t exist, the poll has been locked, or you tried to vote twice.';
$txt['locked_by_admin'] = 'Detta ämne har låsts av en administratör, du kan inte låsa upp det.';
$txt['not_enough_posts_karma'] = 'Beklagar, du har inte tillräckligt många poäng för att kunna förändra karma. Du behöver minst %1$d.';
$txt['cant_change_own_karma'] = 'Beklagar, du kan inte ändra din egen karma.';
$txt['karma_wait_time'] = 'Beklagar, du kan inte upprepa karmaförändringar utan att först vänta %1$s %2$s.';
$txt['feature_disabled'] = 'Beklagar, denna funktion är avstängd.';
$txt['feature_no_exists'] = 'Sorry, this feature doesn\'t exist.';
$txt['couldnt_connect'] = 'Kunde inte ta kontakt med servern, eller kunde inte hitta filen';
$txt['no_board'] = 'Tavlan du angav existerar inte';
$txt['no_message'] = 'The message is no longer available';
$txt['no_topic_id'] = 'Du angav ett ogiltigt ämnes-ID.';
$txt['split_first_post'] = 'Du kan inte dela upp ett ämne vid första inlägget.';
$txt['topic_one_post'] = 'Detta ämne innehåller bara ett enda inlägg, och kan därför inte delas upp.';
$txt['no_posts_selected'] = 'Inga inlägg markerade';
$txt['selected_all_posts'] = 'Det går inte att dela upp ämnet. Du har valt alla inlägg.';
$txt['cant_find_messages'] = 'Kan inte hitta inlägg';
$txt['cant_find_user_email'] = 'Kan inte hitta användarens e-postadress.';
$txt['cant_insert_topic'] = 'Kan inte infoga ämne';
$txt['session_timeout'] = 'Your session timed out while posting. Please go back and try again.';
$txt['session_timeout_file_upload'] = 'Your session timed out while uploading the file. Please try again.';
$txt['no_files_uploaded'] = 'There are no files to upload.';
$txt['session_verify_fail'] = 'Session verification failed. Please try logging out and back in again, and then try again.';
$txt['verify_url_fail'] = 'Unable to verify referring URL: %1$s. Please go back and try again.';
$txt['token_verify_fail'] = 'Token verification failed. Please go back and try again.';
$txt['guest_vote_disabled'] = 'Gäster kan inte rösta i denna omröstning.';

$txt['cannot_access_mod_center'] = 'Du har inte behörighet att komma åt moderationscentret.';
$txt['cannot_admin_forum'] = 'Du har inte behörighet att administrera detta forum.';
$txt['cannot_announce_topic'] = 'Du har inte behörighet att tillkännage ämnen på denna tavla.';
$txt['cannot_approve_posts'] = 'Du har inte behörighet att godkänna inlägg.';
$txt['cannot_post_unapproved_attachments'] = 'Du har inte behörighet att posta icke-godkända bifogade filer.';
$txt['cannot_post_unapproved_topics'] = 'Du har inte behörighet att skriva icke-godkända inlägg.';
$txt['cannot_post_unapproved_replies_own'] = 'Du har inte behörighet att skriva icke-godkända svar till ditt eget ämne';
$txt['cannot_post_unapproved_replies_any'] = 'Du har inte behörighet att skriva icke-godkända svar till andra användares ämnen';
$txt['cannot_calendar_edit_any'] = 'Du kan inte redigera kalenderhändelser.';
$txt['cannot_calendar_edit_own'] = 'Du har inte tillräcklig behörighet för att kunna ändra i dina egna händelser.';
$txt['cannot_calendar_post'] = 'Det är inte tillåtet att posta händelser - beklagar.';
$txt['cannot_calendar_view'] = 'Beklagar, men du har inte behörighet att visa kalendern.';
$txt['cannot_remove_any'] = 'Beklagar, men du har inte behörighet att kunna radera vilket ämne som helst.';
$txt['cannot_remove_own'] = 'Du kan inte radera dina egna inlägg på denna tavla.';
$txt['cannot_edit_news'] = 'Du har inte behörighet att ändra nyheter på detta forum.';
$txt['cannot_pm_read'] = 'Beklagar, du får inte läsa dina privata meddelanden.';
$txt['cannot_pm_send'] = 'Du har inte behörighet att skicka privata meddelanden.';
$txt['cannot_karma_edit'] = 'Du har inte behörighet att kunna ändra andra personers karma.';
$txt['cannot_like_posts'] = 'You are not allowed to like messages in this board.';
$txt['cannot_lock_any'] = 'Du har inte behörighet att kunna låsa vilket ämne som helst här.';
$txt['cannot_lock_own'] = 'Vi beklagar, men du kan inte låsa dina egna ämnen här.';
$txt['cannot_make_sticky'] = 'You don\'t have permission to pin this topic.';
$txt['cannot_manage_attachments'] = 'Du har inte behörighet att hantera bifogade filer eller personliga bilder.';
$txt['cannot_manage_bans'] = 'Du har inte behörighet att ändra listan över bannlysningar.';
$txt['cannot_manage_boards'] = 'Du har inte behörighet att hantera tavlor och kategorier.';
$txt['cannot_manage_membergroups'] = 'You don\'t have permission to modify or assign member groups.';
$txt['cannot_manage_permissions'] = 'Du har inte behörighet att hantera rättigheter.';
$txt['cannot_manage_smileys'] = 'Du har inte behörighet att hantera smileys och meddelandeikoner.';
$txt['cannot_mark_any_notify'] = 'Du har inte nödvändig behörighet för att begära underrättelser på detta ämne.';
$txt['cannot_mark_notify'] = 'Beklagar, men du har inte nödvändig behörighet för att begära underrättelser på denna tavla.';
$txt['cannot_merge_any'] = 'Du har inte behörighet att sammanfoga ämnen på en av de valda tavlorna.';
$txt['cannot_moderate_forum'] = 'Du har inte behörighet att moderera detta forum.';
$txt['cannot_moderate_board'] = 'Du kan inte moderera den här tavlan.';
$txt['cannot_modify_any'] = 'Du har inte behörighet att kunna redigera vilka inlägg som helst.';
$txt['cannot_modify_own'] = 'Beklagar, men du har inte behörighet att kunna redigera dina egna inlägg.';
$txt['cannot_modify_replies'] = 'Även fastän detta inlägg är ett svar på ditt ämne, så kan du inte ändra det.';
$txt['cannot_move_own'] = 'Du har inte behörighet att flytta dina egna ämnen på denna tavla.';
$txt['cannot_move_any'] = 'Du har inte behörighet att flytta ämnen på denna tavla.';
$txt['cannot_poll_add_own'] = 'Beklagar, du har inte behörighet att lägga till omröstningar till dina egna ämnen på denna tavla.';
$txt['cannot_poll_add_any'] = 'Du har inte behörighet att lägga till omröstningar till detta ämne.';
$txt['cannot_poll_edit_own'] = 'Du kan inte ändra i denna omröstning, trots att det är din egen.';
$txt['cannot_poll_edit_any'] = 'Du har nekats behörighet att ändra i omröstningar på denna tavla.';
$txt['cannot_poll_lock_own'] = 'Du har inte behörighet att låsa dina egna omröstningar på denna tavla.';
$txt['cannot_poll_lock_any'] = 'Beklagar, men du har inte behörighet att kunna låsa vilka omröstningar som helst.';
$txt['cannot_poll_post'] = 'Du har inte behörighet att skapa omröstningar i denna tavla.';
$txt['cannot_poll_remove_own'] = 'Du har inte behörighet att ta bort omröstningar från ditt ämne.';
$txt['cannot_poll_remove_any'] = 'Du kan inte ta bort vilken omröstning som helst på denna tavla.';
$txt['cannot_poll_view'] = 'Du har inte behörighet att visa omröstningar på denna tavla.';
$txt['cannot_poll_vote'] = 'Beklagar, men du kan inte rösta i omröstningar på denna tavla.';
$txt['cannot_post_attachment'] = 'Du har inte behörighet att bifoga filer här.';
$txt['cannot_post_new'] = 'Beklagar, du kan inte starta nya ämnen på denna tavla.';
$txt['cannot_post_new_board'] = 'Sorry, you cannot post new topics in the board %1$s.';
$txt['cannot_post_reply_any'] = 'Du får inte svara på ämnen på denna tavla.';
$txt['cannot_post_reply_own'] = 'Du får inte svara ens på dina egna ämnen på denna tavla.';
$txt['cannot_profile_remove_own'] = 'Beklagar, men du får inte radera ditt eget användarkonto.';
$txt['cannot_profile_remove_any'] = 'You don\'t have the appropriate permissions to remove accounts.';
$txt['cannot_profile_extra_any'] = 'Du har inte behörighet att ändra i profilinställningarna.';
$txt['cannot_profile_identity_any'] = 'Du har inte behörighet att ändra kontoinställningar.';
$txt['cannot_profile_title_any'] = 'Du kan inte ändra personers egna titlar.';
$txt['cannot_profile_extra_own'] = 'Beklagar, men du har inte nödvändig behörighet för att kunna ändra i din profil.';
$txt['cannot_profile_identity_own'] = 'Du får inte ändra din identitet för tillfället.';
$txt['cannot_profile_title_own'] = 'Du får inte ändra din egna titel.';
$txt['cannot_profile_set_avatar'] = 'You are not permitted to change your avatar.';
$txt['cannot_profile_view_own'] = 'Vi ber så mycket om ursäkt, men du kan inte visa din egen profil.';
$txt['cannot_profile_view_any'] = 'Vi ber så mycket om ursäkt, men du kan inte visa vilken profil som helst.';
$txt['cannot_delete_own'] = 'Ouch, sorry, you cannot delete your posts on this board.';
$txt['cannot_delete_replies'] = 'Beklagar, men du kan inte radera dessa inlägg, trots att de är svar på ditt eget ämne.';
$txt['cannot_delete_any'] = 'Ouch, sorry, you cannot delete posts in this board.';
$txt['cannot_report_any'] = 'Du har inte behörighet att anmäla inlägg till moderator på den här tavlan';
$txt['cannot_search_posts'] = 'Du har inte behörighet att använda sökfunktionerna på detta forum.';
$txt['cannot_send_mail'] = 'Du har inte behörighet att skicka ut e-postmeddelanden till alla.';
$txt['cannot_issue_warning'] = 'Beklagar, men du har inte behörighet att varna andra användare.';
$txt['cannot_send_topic'] = 'Beklagar, men administratören har stängt av möjligheten att skicka ämnen till vänner på denna tavla.';
$txt['cannot_send_email_to_members'] = 'Sorry, but the administrator has disallowed sending emails on this board.';
$txt['cannot_split_any'] = 'Att dela upp ämnen är inte tillåtet på denna tavla.';
$txt['cannot_view_attachments'] = 'Det verkar som att du inte har rätt till att ladda ner eller visa bifogade filer på denna tavla.';
$txt['cannot_view_mlist'] = 'You can\'t view the member list because you don\'t have permission to.';
$txt['cannot_view_stats'] = 'Du har inte rätt att visa forumstatistiken.';
$txt['cannot_who_view'] = 'Beklagar - du har inte nödvändig behörighet för att kunna visa Vilka är online-listan.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = ' We can\'t find that theme.';
$txt['theme_dir_wrong'] = 'Standardtemats katalog är felaktig, var vänlig och rätta till det genom att klicka här.';
$txt['registration_disabled'] = 'Beklagar, registrering av nya medlemmar är för tillfället avstängt.';
$txt['registration_agreement_missing'] = 'The registration agreement file, agreement.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Beklagar, ingen hemlig fråga har angetts för denna medlem.';
$txt['poll_range_error'] = 'Beklagar, omröstningen måste gälla längre än 0 dagar.';
$txt['delFirstPost'] = 'You are not allowed to delete the first post in a topic.<p>If you want to delete this topic, click on the Remove link, or ask a moderator/administrator to do it for you.</p>';
$txt['login_cookie_error'] = 'Inloggningen misslyckades. Var vänlig och kontrollera dina cookie-inställningar i webbläsaren.';
$txt['incorrect_answer'] = 'Beklagar, men du svarade fel på frågan. Var vänlig klicka Bakåt för att försöka igen, eller Bakåt två gånger för att använda standardmetoden för att få nytt lösenord.';
$txt['no_mods'] = 'Inga moderatorer hittades!';
$txt['parent_not_found'] = 'Tavelstrukturen är skadad: kan inte hitta överliggande tavla';
$txt['modify_post_time_passed'] = 'Du kan inte ändra i detta inlägg, då tidsgränsen för redigeringar har överskrivits.';

$txt['calendar_off'] = 'Du kan inte gå till kalendern just nu, då den är avstängd.';
$txt['calendar_export_off'] = 'You cannot export calendar events because that feature is currently disabled.';
$txt['invalid_month'] = 'Ogiltig månad.';
$txt['invalid_year'] = 'Ogiltigt år.';
$txt['invalid_day'] = 'Ogiltig dag.';
$txt['event_month_missing'] = 'Du har inte angett månad.';
$txt['event_year_missing'] = 'Du har inte angett år.';
$txt['event_day_missing'] = 'Du har inte angett dag.';
$txt['event_title_missing'] = 'Du har inte skrivit rubrik på händelsen.';
$txt['invalid_date'] = 'Ogiltigt datum.';
$txt['no_event_title'] = 'Ingen rubrik har angetts.';
$txt['missing_board_id'] = 'Tavel-ID saknas.';
$txt['missing_topic_id'] = 'Ämnes-ID saknas.';
$txt['topic_doesnt_exist'] = 'Ämnet existerar inte.';
$txt['not_your_topic'] = 'Det är inte du som startat det här ämnet.';
$txt['board_doesnt_exist'] = 'Tavlan existerar inte.';
$txt['no_span'] = 'Funktionen för händelser att vara mer än en dag är för tillfället avstängd.';
$txt['invalid_days_numb'] = 'Ogiltigt antal dagar för händelsen att vara.';

$txt['moveto_noboards'] = 'Det finns inga tavlor att flytta ämnet till!';
$txt['topic_already_moved'] = 'This topic %1$s has been moved to the board %2$s, please check its new location before moving it again.';

$txt['already_activated'] = 'We\'d love to process your request, but your account has already been activated.';
$txt['still_awaiting_approval'] = 'Ditt användarkonto inväntar fortfarande godkännande av administratör.';

$txt['invalid_email'] = 'Ogiltig e-postadress eller ogiltig grupp av e-postadresser.<br />Exempel på giltig e-postadress: ond.person@ondsida.se<br />Exempel på giltig grupp av e-postadresser: *@*.ondsida.se';
$txt['invalid_expiration_date'] = 'Utgångsdatum är ogiltigt';
$txt['invalid_hostname'] = 'Ogiltigt servernamn eller ogiltig grupp av servernamn.<br />Exempel på giltigt servernamn: proxy4.ondsida.se<br />Exempel på giltig grupp av servernamn: *.ondsida.se';
$txt['invalid_ip'] = 'Ogiltig IP-adress eller ogiltigt IP-intervall.<br />Exempel på giltig IP-adress: 127.0.0.1<br />Exempel på giltigt IP-intervall: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Ogiltigt IP / IP-intervall.<br />Exempel på giltig IP-adress: 127.0.0.1<br />Exempel på ett giltigt IP-intervall: 127.0.0.*';
$txt['invalid_username'] = 'Användarnamnet finns inte';
$txt['no_user_selected'] = 'Member not found';
$txt['no_ban_admin'] = 'Hey! We can\'t let you ban an admin. If you are certain about this, demote them first!';
$txt['no_bantype_selected'] = 'Ingen bannlysningstyp har valts';
$txt['ban_not_found'] = 'Bannlysning hittades inte';
$txt['ban_unknown_restriction_type'] = 'Begränsningstyp okänd';
$txt['ban_name_empty'] = 'Namnet på bannlysningen lämnades tomt';
$txt['ban_id_empty'] = 'Dang, sorry. We tried to find this ban ID, but it can\'t be found.';
$txt['ban_group_id_empty'] = 'A ban group needs a group ID, and this group didn\'t have any.';
$txt['ban_no_triggers'] = 'Did you forget to select ban triggers? We need at least one, and we haven\'t got any.';
$txt['ban_ban_item_empty'] = 'Ban trigger not found';
$txt['impossible_insert_new_bangroup'] = 'An error occurred while inserting the new ban';

$txt['like_heading_error'] = 'Error in Likes';
$txt['like_wait_time'] = 'Sorry, you can\'t repeat a like action without waiting %1$s %2$s.';
$txt['like_unlike_error'] = 'Oops, there was an error while liking/unliking the post';
$txt['cant_like_yourself'] = 'Liking your own posts ... it\'s like laughing at your own jokes when there is no one else around  ... lol ... Wait did I just lol myself?';

$txt['ban_name_exists'] = 'Bannlysningsnamn (%1$s) finns redan. Vänligen välj ett annat namn. ';
$txt['ban_trigger_already_exists'] = 'Bannlysningsutlösaren (%1$s) finns redan i %2$s';
$txt['attach_check_nag'] = 'Unable to continue due to incomplete data (%1$s).';

$txt['recycle_no_valid_board'] = 'Ingen giltig tavla har valts för återvinning av ämnen';
$txt['post_already_deleted'] = 'The topic or message has already been moved to the recycle board. Are you sure you want to delete it completely?<br />If so follow <a href="%1$s">this link</a>';

$txt['login_threshold_fail'] = 'Beklagar, men du har använt upp alla dina inloggningsförsök. Var vänlig kom tillbaka till forumet senare, och försök igen.';
$txt['login_threshold_brute_fail'] = 'Sorry, but you\'ve reached your login attempts threshold.  Please wait 30 seconds and try again.';

$txt['who_off'] = 'We would love to let you peek at Who\'s Online, but unfortunately right now it\'s disabled.';

$txt['merge_create_topic_failed'] = 'Dang, sorry. We tried, we really did, but creating a new topic failed.';
$txt['merge_need_more_topics'] = 'Merge topics requires at least two topics to merge, but we didn\'t get two. Please try again.';

$txt['post_WaitTime_broken'] = 'Senaste inlägget från din IP-adress var för mindre än %1$d sekunder sedan. Försök igen senare.';
$txt['register_WaitTime_broken'] = 'Du har redan registrerat dig för %1$d sekunder sedan!';
$txt['login_WaitTime_broken'] = 'Beklagar men du måste vänta minst %1$d sekunder innan du kan logga in igen.';
$txt['pm_WaitTime_broken'] = 'Det senaste privata meddelandet från din IP-adress var för mindre än %1$d sekunder sedan. Försök igen senare.';
$txt['reporttm_WaitTime_broken'] = 'Ditt senaste rapporterade ämne var för mindre än %1$d sekunder sedan. Försök igen senare.';
$txt['sendtopic_WaitTime_broken'] = 'Det senaste ämnet som skickades från din IP-adress var för mindre än %1$d sekunder sedan. Försök igen senare.';
$txt['sendmail_WaitTime_broken'] = 'Det senaste e-postmeddelandet som skickades från din IP-adress var för mindre än %1$d sekunder sedan. Försök igen senare.';
$txt['search_WaitTime_broken'] = 'Din senaste sökning genomfördes för mindre än %1$d sekunder sedan. Försök igen senare.';
$txt['remind_WaitTime_broken'] = 'Your last reminder was less than %1$d seconds ago. Please try again later.';
$txt['contact_WaitTime_broken'] = 'The last time you tried to use the contact form was less than %1$d seconds ago. Please try again later.';

$txt['topic_gone'] = 'We tried very hard to find the topic or board you are looking for, but it\'s nowhere to be found. It appears to be either missing or off limits to you.';
$txt['theme_edit_missing'] = 'We tried very hard to find the file you are trying to edit, but it can\'t be found.';

$txt['no_dump_database'] = 'Sorry, we can\'t let you make database backups. Only administrators can.';
$txt['pm_not_yours'] = 'Det privata meddelande du försökt att citera, är inte ditt eget eller existerar inte. Gå tillbaka och försök igen.';
$txt['mangled_post'] = 'Korrupt formulärdata - gå tillbaka och försök igen.';
$txt['too_many_groups'] = 'Sorry, you selected too many groups, please remove some.';
$txt['post_upload_error'] = 'The post data is missing. This error could be caused by trying to submit a file larger than allowed by the server.  Please contact your administrator if this problem continues.';
$txt['quoted_post_deleted'] = 'Inlägget du försöker att citera existerar inte, har just raderats eller så har du inte längre behörighet att visa det inlägget.';
$txt['pm_too_many_per_hour'] = 'Du har överskridit gränsen på %1$d privata meddelanden per timme.';
$txt['labels_too_many'] = 'Ledsen, %1$s meddelanden hade maximalt antal tillåtna etiketter!';

$txt['register_only_once'] = 'Beklagar, men du får inte registrera flera användarkonton samtidigt från samma dator.';
$txt['admin_setting_coppa_require_contact'] = 'Du måste antingen ange postadress eller faxnummer om du kräver godkännande av förälder/målsman.';

$txt['error_long_name'] = 'Namnet du angav var för långt.';
$txt['error_no_name'] = 'Inget namn angavs.';
$txt['error_bad_name'] = 'Namnet du angav kan inte användas, då det var eller innehöll ett reserverat namn.';
$txt['error_no_email'] = 'Ingen e-postadress angavs.';
$txt['error_bad_email'] = 'Ogiltig e-postadress angavs.';
$txt['error_email'] = 'email address';
$txt['error_message'] = 'meddelande';
$txt['error_no_event'] = 'Inget namn på händelsen angavs.';
$txt['error_no_subject'] = 'Ingen rubrik har fyllts i.';
$txt['error_no_question'] = 'Ingen fråga har angivits för omröstningen.';
$txt['error_no_message'] = 'Meddelandefältet är tomt.';
$txt['error_long_message'] = 'Inlägget överskrider maxlängden på %s tecken.';
$txt['error_no_comment'] = 'Fältet Kommentar lämnades tomt.';
$txt['error_post_too_long'] = 'Your message is too long. Please enter a maximum of 255 characters.';
$txt['error_session_timeout'] = 'Tiden för din session gick ut medan du skrev inlägget. Var vänlig och försök att skicka meddelandet igen.';
$txt['error_no_to'] = 'Ingen mottagare angavs.';
$txt['error_bad_to'] = 'En eller flera mottagare kunde inte hittas.';
$txt['error_bad_bcc'] = 'En eller flera blindkopie-mottagare kunde inte hittas.';
$txt['error_form_already_submitted'] = 'You already submitted this post!  You might have accidentally double clicked or refreshed the page.';
$txt['error_poll_few'] = 'Du måste ange minst två alternativ till omröstningen!';
$txt['error_poll_many'] = 'You must have no more than 256 choices.';
$txt['error_need_qr_verification'] = 'Slutför verifieringsavdelningen nedan för att skicka ditt inlägg.';
$txt['error_wrong_verification_code'] = 'Bokstäverna du skrev in stämde inte överens med de som visades i bilden.';
$txt['error_wrong_verification_answer'] = 'Du svarade inte på verifikationsfrågorna korrekt.';
$txt['error_need_verification_code'] = 'Ange verifieringskoden för att fortsätta till resultaten.';
$txt['error_bad_file'] = 'Sorry, but the file specified could not be opened: %1$s';
$txt['error_bad_line'] = 'Raden du angav är ogiltig.';
$txt['error_draft_not_saved'] = 'There was an error saving the draft';
$txt['error_name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['smiley_not_found'] = 'Smiley hittades inte.';
$txt['smiley_has_no_code'] = 'Ingen kod för denna smiley har angetts.';
$txt['smiley_has_no_filename'] = 'No file name for this smiley was given.';
$txt['smiley_not_unique'] = 'En smiley med den koden finns redan.';
$txt['smiley_set_already_exists'] = 'En smiley-uppsättning med den adressen finns redan';
$txt['smiley_set_not_found'] = 'Smiley-uppsättningen finns inte';
$txt['smiley_set_dir_not_found'] = 'The directory of the smiley set %1$s is either invalid or cannot be accessed';
$txt['smiley_set_path_already_used'] = 'Adressen till smiley-uppsättningen används redan för en annan uppsättning.';
$txt['smiley_set_unable_to_import'] = 'Kunde inte importera smiley-uppsättning. Antingen är sökvägen/katalogen ogiltig, eller så går den inte att anropa.';

$txt['smileys_upload_error'] = 'Lyckades inte att ladda upp fil.';
$txt['smileys_upload_error_blank'] = 'All smiley sets must have an image.';
$txt['smileys_upload_error_name'] = 'All smileys must have the same file name.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Ogiltig typ.';

$txt['search_invalid_weights'] = 'Search weights are not configured properly. At least one weight should be configured to be non-zero. Please report this error to an administrator.';

$txt['package_no_file'] = 'Kunde inte hitta paketfil!';
$txt['packageget_unable'] = 'Kunde inte ansluta till servern. Var vänlig och försök med <a href="%1$s" target="_blank" class="new_win">denna adress</a> istället.';
$txt['not_valid_server'] = 'Sorry, packages can only be downloaded like this from servers you have first authorized.';
$txt['package_cant_uninstall'] = 'Det här paketet har antingen aldrig installerats, eller så är det redan avinstallerat - det går inte att avinstallera det.';
$txt['package_cant_download'] = 'You cannot download or install new packages because the &quot;packages&quot; directory or one of the files in it are not writable!';
$txt['package_upload_error_nofile'] = 'Du valde inget paket att ladda upp.';
$txt['package_upload_error_failed'] = 'Kunde inte ladda upp paket. Vänligen kontrollera rättigheterna för mappen!';
$txt['package_upload_error_exists'] = 'The file you are uploading already exists on the server. Please delete it first, then try again.';
$txt['package_upload_already_exists'] = 'The package you are trying to upload already exists on the server under file name: %1$s';
$txt['package_upload_error_supports'] = 'Pakethanteraren tillåter för närvarande endast dessa filtyper: %1$s.';
$txt['package_upload_error_broken'] = 'Uppladdningen av paketet misslyckades på grund av följande fel:<br />&quot;%1$s&quot; ';

$txt['package_get_error_not_found'] = 'The package you are trying to install cannot be located. You may want to manually upload the package to your &quot;packages&quot; directory.';
$txt['package_get_error_missing_xml'] = 'Det paket som du försöker att installera saknar filen package-info.xml';
$txt['package_get_error_is_zero'] = 'Although the package was downloaded to the server it appears to be empty. Please check the &quot;packages&quot; directory, and the &quot;temp&quot; sub-directory are both writable. If you continue to experience this problem you should try extracting the package on your PC and uploading the extracted files into a subdirectory in your &quot;packages&quot; directory and try again. For example, if the package was called shout.tar.gz you should:<br />1) Download the package to your local PC and extract its files.<br />2) Create a new directory in your &quot;packages&quot; folder using an FTP client, in this example you may call it "shout".<br />3) Upload all the files from the extracted package to this directory.<br />4) Go back to the package manager browse page. The package will be automatically found.';
$txt['package_get_error_packageinfo_corrupt'] = 'Unable to find any valid information within the package-info.xml file included within the package. There may be an error in the add-on, or the package may be corrupt.';
$txt['package_get_error_is_theme'] = 'You can\'t install a theme from this section, please use the <a href="{MANAGETHEMEURL}">Theme Management</a> page to upload it';

$txt['no_membergroup_selected'] = 'No member group selected';
$txt['membergroup_does_not_exist'] = 'The member group doesn\'t exist or is invalid.';

$txt['at_least_one_admin'] = 'Det måste finnas minst en administratör på ett forum!';

$txt['error_functionality_not_windows'] = 'Ledsen  men denna funktion är inte tillgänglig för Windows-servrar.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Bifogad fil finns inte';

$txt['error_no_boards_selected'] = 'No valid boards were selected.';
$txt['error_invalid_search_string'] = 'Did you forget to enter something to search for?';
$txt['error_invalid_search_string_blacklist'] = 'Your search query contained trivial words. Please try again with a different query.';
$txt['error_search_string_small_words'] = 'Each word must be at least two characters long.';
$txt['error_query_not_specific_enough'] = 'Din sökning gav inga träffar.';
$txt['error_no_messages_in_time_frame'] = 'Inga inlägg hittades inom den valda tidsperioden.';
$txt['error_no_labels_selected'] = 'No labels were selected.';
$txt['error_no_search_daemon'] = 'Kunde inte få tillgång till sökmotorn.';

$txt['profile_errors_occurred'] = 'The following errors occurred when trying to update your profile';
$txt['profile_error_bad_offset'] = 'Tidsförskjutningen är för stor';
$txt['profile_error_no_name'] = 'Namn-fältet lämnades tomt';
$txt['profile_error_digits_only'] = 'Rutan \'Antal inlägg\' kan bara innehålla siffror.';
$txt['profile_error_name_taken'] = 'The selected user name/display name has already been taken';
$txt['profile_error_name_too_long'] = 'Det angivna namnet är för långt. Det får inte vara längre än max 60 tecken.';
$txt['profile_error_no_email'] = 'Du har inte angivit någon e-post-adress';
$txt['profile_error_bad_email'] = 'Du har angivit en ogiltig e-post-adress';
$txt['profile_error_email_taken'] = 'En annan medlem finns redan registrerad med samma e-post-adress';
$txt['profile_error_no_password'] = 'Du skrev inte in ditt lösenord';
$txt['profile_error_bad_new_password'] = 'Du skrev inte in samma nya lösenord båda gångerna';
$txt['profile_error_bad_password'] = 'Lösenordet du skrev in var fel';
$txt['profile_error_bad_avatar'] = 'Den personliga bilden du valt är för stor, eller är inte en personlig bild';
$txt['profile_error_password_short'] = 'Your password must be at least %1$s characters long.';
$txt['profile_error_password_restricted_words'] = 'Your password must not contain your user name, email address or other commonly used words.';
$txt['profile_error_password_chars'] = 'Ditt lösenord måste innehålla både versaler och gemener, samt siffror.';
$txt['profile_error_already_requested_group'] = 'Du har redan begärt tillträde till denna grupp!';
$txt['profile_error_openid_in_use'] = 'En annan användare använder redan autentiseringsadressen för OpenID';
$txt['profile_error_signature_not_yet_saved'] = 'The signature has not been saved.';
$txt['profile_error_personal_text_too_long'] = 'The personal text is too long.';
$txt['profile_error_user_title_too_long'] = 'The custom title is too long.';

$txt['mysql_error_space'] = ' - kontrollera databasens lagringsutrymme eller kontakta serveradministratören.';

$txt['icon_not_found'] = 'Ikonbilden kunde inte hittas i standardtemat - var vänlig försäkra dig om att filen har laddats upp och försök igen.';
$txt['icon_after_itself'] = 'The icon cannot be positioned after itself.';
$txt['icon_name_too_long'] = 'Icon file names cannot be more than 16 characters long';

$txt['name_censored'] = 'Beklagar, det namn du försökt använda, %1$s, innehöll ord som är otillåtet på forumet. Vänligen försök med ett annat namn.';

$txt['poll_already_exists'] = 'A topic can only have one poll associated with it.';
$txt['poll_not_found'] = 'Det finns ingen omröstning till detta ämne!';

$txt['error_while_adding_poll'] = 'Följande fel uppstod när du försökte att lägga till omröstningen';
$txt['error_while_editing_poll'] = 'Följande fel uppstod när du försökte att redigera omröstningen';

$txt['loadavg_search_disabled'] = 'P.g.a. hög belastning på servern har sökfunktionen temporärt och automatiskt stängts av. Vänligen försök igen om en liten stund.';
$txt['loadavg_generic_disabled'] = 'Beklagar, p.g.a. hög belastning på servern är denna funktion inte tillgänglig för tillfället.';
$txt['loadavg_allunread_disabled'] = 'The server\'s resources are temporarily under a too high demand to find all the topics you have not read.';
$txt['loadavg_unreadreplies_disabled'] = 'Servern är för tillfället överbelastad. Var vänlig försök igen om en liten stund.';
$txt['loadavg_show_posts_disabled'] = 'Vänligen försök igen senare. Denna medlems inlägg kan för tillfället inte nås p.g.a. för hög belastning på servern.';
$txt['loadavg_unread_disabled'] = 'The server\'s resources are temporarily under a too high demand to list out the topics you have not read.';
$txt['loadavg_userstats_disabled'] = 'Please try again later.  This member\'s statistics are not currently available due to high load on the server.';

$txt['cannot_edit_permissions_inherited'] = 'You cannot edit inherited permissions directly, you must either edit the parent group or edit the member group inheritance.';

$txt['mc_no_modreport_specified'] = 'Du måste välja vilken rapport du vill visa.';
$txt['mc_no_modreport_found'] = 'Den specificerade rapporten finns inte eller är utanför din gräns.';

$txt['st_cannot_retrieve_file'] = 'Kunde inte hämta filen %1$s.';
$txt['admin_file_not_found'] = 'Kunde inte ladda filen: %1$s.';

$txt['themes_none_selectable'] = 'Ett tema måste väljas.';
$txt['themes_default_selectable'] = 'Forumets standardtema måste vara valbart..';
$txt['ignoreboards_disallowed'] = 'Tillvalet Ignorera tavlor är inte aktiverat.';

$txt['mboards_delete_error'] = 'No category selected.';
$txt['mboards_delete_board_error'] = 'No board selected.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'You can not make a parent its own child.';
$txt['mboards_board_own_child_error'] = 'You can not make a board its own child.';

$txt['smileys_upload_error_notwritable'] = 'Följande smiley-mappar är inte skrivbara: %1$s';
$txt['smileys_upload_error_types'] = 'Smiley-bilder får bara ha följande filändelser: %1$s.';

$txt['change_email_success'] = 'Din e-postadress har ändrats och ett nytt aktiverings-mail har skickats till den adressen.';
$txt['resend_email_success'] = 'Ett nytt aktiverings-mail har skickats med framgång.';

$txt['custom_option_need_name'] = 'The profile option must have a name.';
$txt['custom_option_not_unique'] = 'Field name is not unique.';
$txt['custom_option_regex_error'] = 'The regex you entered is not valid';

$txt['warning_no_reason'] = 'Du måste ange en orsak för att ändra varningsstatus för en medlem';
$txt['warning_notify_blank'] = 'Du valde att meddela användaren men du fyllde inte i rubrik- eller meddelandefältet.';

$txt['cannot_connect_doc_site'] = 'Could not connect to the documentation site. Please check that your server configuration allows external internet connections and try again later.';

$txt['movetopic_no_reason'] = 'Du måste ange en orsak för att flytta eller avmarkera valet: \'Lämna kvar ett hänvisningsmeddelande...\'';
$txt['movetopic_no_board'] = 'You must choose a board to move the topic to.';

$txt['splittopic_no_reason'] = 'You must enter a reason for splitting the topic, or uncheck the option to \'post a redirection message\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Identifieraren skickade inte tillbaka rätt information.';
$txt['openid_return_no_mode'] = 'Identitetshanteraren reagerade inte med detta OpenID-läge.';
$txt['openid_not_resolved'] = 'Identitetshanteraren godkände inte din begäran.';
$txt['openid_no_assoc'] = 'Kunde inte hitta begärd koppling hos identitetshanteraren.';
$txt['openid_sig_invalid'] = 'Signaturen från identitetshanteraren är ogiltig.';
$txt['openid_load_data'] = 'Kunde inte ladda dara från din inloggningsbegäran. Var vänlig försök igen.';
$txt['openid_not_verified'] = 'The supplied OpenID has not been verified yet.  Please log in to verify.';

$txt['error_custom_field_too_long'] = 'Fältet &quot;%1$s&quot; får inte överstiga %2$d tecken.';
$txt['error_custom_field_invalid_email'] = 'Fältet &quot;%1$s&quot; måste innehålla en giltig e-postadress. ';
$txt['error_custom_field_not_number'] = 'Innehållet i fältet &quot;%1$s&quot; måste vara ett nummer.';
$txt['error_custom_field_inproper_format'] = 'Fältet &quot;%1$s&quot; har ett ogiltigt format.';
$txt['error_custom_field_empty'] = 'Fältet &quot;%1$s&quot; får inte lämnas tomt.';

$txt['email_no_template'] = 'E-postmallen &quot;%1$s&quot; kunde inte hittas.';

$txt['search_api_missing'] = 'The search API could not be found. Please contact the admin to check they have uploaded the correct files.';
$txt['search_api_not_compatible'] = 'The selected search API the forum is using is out of date - falling back to standard search. Please check the file %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Du får inte återställa det första inlägget i ett ämne.';
$txt['restored_disabled'] = 'Återskapande av ämnen har blivit avstängt.';
$txt['restore_not_found'] = 'The following messages could not be restored; the original topic may have been removed: %1$s You will need to move these manually.';

$txt['error_invalid_dir'] = 'Katalogen du angav är felaktig.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'The Sub-action you requested is not defined';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'No sortable items were found';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
