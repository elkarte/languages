<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Datum';
$txt['badbehaviorlog_protocol'] = 'Protocol';
$txt['badbehaviorlog_method'] = 'Method';
$txt['badbehaviorlog_request'] = 'Request';
$txt['badbehaviorlog_uri'] = 'Adress';
$txt['badbehaviorlog_id_member'] = 'Member ID';
$txt['badbehaviorlog_username'] = 'UserName';
$txt['badbehaviorlog_headers'] = 'Headers';
$txt['badbehaviorlog_agent'] = 'Browser';
$txt['badbehaviorlog_entity'] = 'Posta';
$txt['badbehaviorlog_key'] = 'Key';
$txt['badbehaviorlog_ip'] = 'IP-adress';
$txt['badbehaviorlog_total_entries'] = 'Totalt antal inlägg';
$txt['badbehaviorlog_error_valid_code'] = 'Reason Code';
$txt['badbehaviorlog_error_valid_response'] = 'HTTP Status';
$txt['badbehaviorlog_error_valid_explaination'] = 'HTTP Reason';
$txt['badbehaviorlog_error_valid_log'] = 'Detaljer';
$txt['badbehaviorlog_log'] = 'BadBehavior Log';
$txt['badbehaviorlog_desc'] = 'Below is a list of all the bad behavior entries that have been logged';
$txt['badbehaviorlog_details'] = 'Additional Details';
$txt['badbehaviorlog_no_entries_found'] = 'There are currently no bad behavior log entries.';

$txt['badbehaviorlog_remove_selection'] = 'Radera markerade';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Are you sure you want to delete the selected log entries?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Remove all filtered results';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Are you sure you want to delete the filtered entries?';
$txt['badbehaviorlog_sure_remove'] = 'Are you sure you want to completely clear the bad behavior log?';

$txt['badbehaviorlog_remove'] = 'Radera markerade';
$txt['badbehaviorlog_removeall'] = 'Clear Log';
$txt['badbehaviorlog_clear_filter'] = 'Rensa filter';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Använd filter av typen';
$txt['badbehaviorlog_apply_filter'] = 'Använd filter';
$txt['badbehaviorlog_applying_filter'] = 'Använder filter';
$txt['badbehaviorlog_filter_only_member'] = 'Only show the badbehavior logs of this member';
$txt['badbehaviorlog_filter_only_ip'] = 'Only show the badbehavior logs of this IP address';
$txt['badbehaviorlog_filter_only_session'] = 'Only show the badbehaviorlogs of this session';
$txt['badbehaviorlog_filter_only_headers'] = 'Only show the badbehavior logs of this URL';
$txt['badbehaviorlog_filter_only_agent'] = 'Only show the entries with the same user agent';

$txt['badbehaviorlog_session'] = 'Session';
$txt['badbehaviorlog_error_url'] = 'URL of the page that was logged';

$txt['badbehaviorlog_reverse_direction'] = 'Omvänd kronologisk listordning';
$txt['badbehaviorlog_filter_only_type'] = 'Only show the logs with this code';