<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Index för privata meddelanden';
$txt['pm_add'] = 'Lägg till';
$txt['make_bcc'] = 'Lägg till blindkopia';
$txt['pm_to'] = 'Till';
$txt['pm_bcc'] = 'Blindkopia';
$txt['inbox'] = 'Inkorg';
$txt['conversation'] = 'Konversation';
$txt['messages'] = 'Meddelanden';
$txt['sent_items'] = 'Skickade meddelanden';
$txt['new_message'] = 'Nytt meddelande';
$txt['delete_message'] = 'Radera meddelanden';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Radera alla meddelanden i din PMBOX';
$txt['delete_all_confirm'] = 'Är du säker på att du vill radera samtliga meddelanden?';

$txt['delete_selected_confirm'] = 'Är du säker på att du vill radera alla markerade meddelanden?';

$txt['sent_to'] = 'Skickat till';
$txt['reply_to_all'] = 'Svara till alla';
$txt['delete_conversation'] = 'Radera konversation';

$txt['pm_capacity'] = 'Lagringsgräns';
$txt['pm_currently_using'] = '%1$s meddelanden, %2$s%% full.';
$txt['pm_sent'] = 'Ditt meddelande har skickats.';

$txt['pm_error_user_not_found'] = 'Kunde inte hitta användaren \'%1$s\'.';
$txt['pm_error_ignored_by_user'] = 'Användaren \'%1$s\' har blockerat ditt meddelande.';
$txt['pm_error_data_limit_reached'] = 'PM could not be sent to \'%1$s\' as their inbox is full.';
$txt['pm_error_user_cannot_read'] = 'Användaren \'%1$s\' kan inte ta emot privata meddelanden.';
$txt['pm_successfully_sent'] = 'Meddelandet har skickats till \'%1$s\' utan problem.';
$txt['pm_send_report'] = 'Skicka anmälan';
$txt['pm_undisclosed_recipients'] = 'Anonyma mottagare';
$txt['pm_too_many_recipients'] = 'Du får inte skicka personliga meddelanden till fler än %1$d mottagare på en gång.';

$txt['pm_read'] = 'Läs';
$txt['pm_replied'] = 'Svarade till';
$txt['pm_mark_unread'] = 'Mark as Unread';

// Message Pruning.
$txt['pm_prune'] = 'Prune messages';
$txt['pm_prune_desc'] = 'Delete all personal messages older than %1$s days.';
$txt['pm_prune_warning'] = 'Är du säker på att du vill ta bort dina privata meddelanden?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Further actions';
$txt['pm_actions_delete_selected'] = 'Radera markerade';
$txt['pm_actions_filter_by_label'] = 'Filter by label';
$txt['pm_actions_go'] = 'OK';

// Manage Labels Screen.
$txt['pm_apply'] = 'Verkställ';
$txt['pm_manage_labels'] = 'Manage labels';
$txt['pm_labels_delete'] = 'Är du säker på att du vill radera markerade etiketter?';
$txt['pm_labels_desc'] = 'Härifrån kan du lägga till, redigera och ta bort etiketter som används i centret för privata meddelanden.';
$txt['pm_label_add_new'] = 'Add new label';
$txt['pm_label_name'] = 'Label name';
$txt['pm_labels_no_exist'] = 'För närvarande har du inga etiketter lagrade!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Etikett';
$txt['pm_msg_label_title'] = 'Label message';
$txt['pm_msg_label_apply'] = 'Add label';
$txt['pm_msg_label_remove'] = 'Remove label';
$txt['pm_msg_label_inbox'] = 'Inkorg';
$txt['pm_sel_label_title'] = 'Label selected';

// Sidebar Headings.
$txt['pm_labels'] = 'Etikett';
$txt['pm_messages'] = 'Meddelanden';
$txt['pm_actions'] = 'Åtgärder';
$txt['pm_preferences'] = 'Personliga inställningar';

$txt['pm_is_replied_to'] = 'Du har vidarebefordrat eller svarat på detta meddelande.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Report to admin';
$txt['pm_report_title'] = 'Report personal message';
$txt['pm_report_desc'] = 'Från denna sida kan du anmäla det privata meddelandet du fick till administratörerna på forumet. Var vänlig se till att bifoga en beskrivning om varför du anmält meddelandet, då detta kommer att skickas med tillsammans med innehållet i meddelandet.';
$txt['pm_report_admins'] = 'Administratör att skicka anmälan till';
$txt['pm_report_all_admins'] = 'Skicka till alla forumets administratörer';
$txt['pm_report_reason'] = 'Anledningen till att du anmäler detta meddelande';
$txt['pm_report_message'] = 'Anmäl meddelande';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[ANMÄLAN] ';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} har anmält nedanstående privata meddelande, skickat av {SENDER}, av denna anledning:';
$txt['pm_report_pm_other_recipients'] = 'Andra mottagare av meddelandet innefattar:';
$txt['pm_report_pm_hidden'] = '%1$d dold(a) mottagare';
$txt['pm_report_pm_unedited_below'] = 'Nedan återfinns innehållet i det privata meddelande som anmälan gäller:';
$txt['pm_report_pm_sent'] = 'Skickat:';

$txt['pm_report_done'] = 'Tack för att du skickat anmälan. Du borde höra något från admin inom kort.';
$txt['pm_report_return'] = 'återvänd till inkorgen';

$txt['pm_search_title'] = 'Search personal messages';
$txt['pm_search_bar_title'] = 'Search messages';
$txt['pm_search_text'] = 'Sök efter';
$txt['pm_search_go'] = 'Sök';
$txt['pm_search_advanced'] = 'Show advanced options';
$txt['pm_search_simple'] = 'Hide advanced options';
$txt['pm_search_user'] = 'Av användare';
$txt['pm_search_match_all'] = 'Matcha alla ord';
$txt['pm_search_match_any'] = 'Matcha något ord';
$txt['pm_search_options'] = 'Inställningar';
$txt['pm_search_post_age'] = 'Hur gamla inläggen får vara';
$txt['pm_search_show_complete'] = 'Visa hela meddelanden i sökresultat.';
$txt['pm_search_subject_only'] = 'Sök endast rubriker och avsändare.';
$txt['pm_search_sent_only'] = 'Search only in sent items.';
$txt['pm_search_between'] = 'mellan';
$txt['pm_search_between_and'] = 'och';
$txt['pm_search_between_days'] = 'dagar';
$txt['pm_search_order'] = 'Sortera resultat';
$txt['pm_search_choose_label'] = 'Välj etiketter att söka efter, eller samtliga';

$txt['pm_search_results'] = 'Search results';
$txt['pm_search_none_found'] = 'No messages found';

$txt['pm_search_orderby_relevant_first'] = 'Mest relevanta först';
$txt['pm_search_orderby_recent_first'] = 'Nyast först';
$txt['pm_search_orderby_old_first'] = 'Äldst först';

$txt['pm_visual_verification_label'] = 'Verifiering';
$txt['pm_visual_verification_desc'] = 'Please enter the code in the image above in order to send this PM.';

$txt['pm_settings'] = 'Change settings';
$txt['pm_change_view'] = 'Change view';

$txt['pm_manage_rules'] = 'Manage rules';
$txt['pm_manage_rules_desc'] = 'Meddelanderegler låter dig automatiskt sortera inkommande meddelanden, utifrån de kriterier du fastställer. Nedan återfinns alla regler du för närvarande har ställt in. För att ändra en regel, klicka på regelns namn.';
$txt['pm_rules_none'] = 'Du har ännu inte ställt in några regler.';
$txt['pm_rule_title'] = 'Regel';
$txt['pm_add_rule'] = 'Add new rule';
$txt['pm_apply_rules'] = 'Apply rules now';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Är du säker på att du vill verkställa de nuvarande reglerna på alla privata meddelanden?';
$txt['pm_edit_rule'] = 'Edit rule';
$txt['pm_rule_save'] = 'Save rule';
$txt['pm_delete_selected_rule'] = 'Delete selected rules';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Är du säker på att du vill radera de markerade reglerna?';
$txt['pm_rule_name'] = 'Namn';
$txt['pm_rule_name_desc'] = 'Namn att komma ihåg denna regel som';
$txt['pm_rule_name_default'] = '[NAMN]';
$txt['pm_rule_description'] = 'Beskrivning';
$txt['pm_rule_not_defined'] = 'Lägg till kriterier för att börja skapa regelns beskrivning.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>Obs:</strong> Det verkar som att du har inaktiverat Javascript-stöd. Vi rekommenderar starkt att du aktiverar Javascript för att använda denna funktion.</span>';
$txt['pm_rule_criteria'] = 'Kriterium';
$txt['pm_rule_criteria_add'] = 'Add criteria';
$txt['pm_rule_criteria_pick'] = 'Choose criteria';
$txt['pm_rule_mid'] = 'Sender name';
$txt['pm_rule_gid'] = 'Sender\'s group';
$txt['pm_rule_sub'] = 'Message subject contains';
$txt['pm_rule_msg'] = 'Message body contains';
$txt['pm_rule_bud'] = 'Sender is buddy';
$txt['pm_rule_sel_group'] = 'Select group';
$txt['pm_rule_logic'] = 'When checking criteria';
$txt['pm_rule_logic_and'] = 'Alla kriterier måste uppfyllas';
$txt['pm_rule_logic_or'] = 'Det räcker att något av kriterierna har uppfyllts';
$txt['pm_rule_actions'] = 'Åtgärder';
$txt['pm_rule_sel_action'] = 'Select an action';
$txt['pm_rule_add_action'] = 'Add action';
$txt['pm_rule_label'] = 'Förse med etikett';
$txt['pm_rule_sel_label'] = 'Select label';
$txt['pm_rule_delete'] = 'Delete message';
$txt['pm_rule_no_name'] = 'Du glömde ange ett namn för regeln.';
$txt['pm_rule_no_criteria'] = 'En regel måste ha minst ett kriterium och minst en åtgärd.';
$txt['pm_rule_too_complex'] = 'The rule you are creating is too long to save. Try breaking it up into smaller rules.';

$txt['pm_readable_and'] = '<em>och</em>';
$txt['pm_readable_or'] = '<em>eller</em>';
$txt['pm_readable_start'] = 'Om ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'meddelandet kommer från &quot;{MEMBER}&quot;';
$txt['pm_readable_group'] = 'avsändaren tillhör medlemsgruppen &quot;{GROUP}&quot;';
$txt['pm_readable_subject'] = 'meddelandets rubrik innehåller &quot;{SUBJECT}&quot;';
$txt['pm_readable_body'] = 'meddelandets brödtext innehåller &quot;{BODY}&quot;';
$txt['pm_readable_buddy'] = 'avsändaren är en kompis';
$txt['pm_readable_label'] = 'Märk med etiketten &quot;{LABEL}&quot;';
$txt['pm_readable_delete'] = 'radera meddelandet';
$txt['pm_readable_then'] = '<strong>så</strong>';