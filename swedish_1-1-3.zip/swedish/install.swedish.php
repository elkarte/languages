<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Välkommen';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Kontroll av skrivrättigheter';
$txt['install_step_forum'] = 'Grundläggande inställningar';
$txt['install_step_databaseset'] = 'Databasinställningar';
$txt['install_step_databasechange'] = 'Databasbestånd';
$txt['install_step_admin'] = 'Administratörskonto';
$txt['install_step_delete'] = 'Finalize Installation';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'Språk';
$txt['installer_language_set'] = 'Ställ in';
$txt['congratulations'] = 'Gratulerar, installationen är klar!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Din installationskatalog är fortfarande skrivbar. Det är en bra idé att ändra rättigheterna (CHMOD), så att katalogen inte längre är skrivbar av säkerhetsskäl.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(fungerar inte på alla servrar)</em>';
$txt['go_to_your_forum'] = 'Nu kan du se <a href="%1$s">ditt färdiginstallerade forum</a> och börja använda det. Du bör först se till att du är inloggad och sen bör du kunna komma åt administrationscentret.';
$txt['good_luck'] = 'Thanks for installing ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Välkommen';
$txt['install_welcome_desc'] = 'Welcome to ElkArte. This script will guide you through the process for installing %1$s. We\'ll gather a few details about your forum over the next few steps, and after a couple of minutes your forum will be ready for use.';
$txt['install_all_lovely'] = 'Vi har utfört några inledande tester av din server och allt verkar vara i sin ordning. Klicka bara på &quot;Fortsätt&quot; för att börja.';

$txt['user_refresh_install'] = 'Forumet uppdaterat';
$txt['user_refresh_install_desc'] = 'Under installationen, upptäckte installationsprogrammet att ett eller flera av tabellerna som skulle skapas redan fanns på servern.<br />Eventuella saknade tabeller i din installation har återskapats med standardversioner, men ingenting har tagits bort eller ändrats från dina befintliga tabeller.';

$txt['default_topic_subject'] = 'Welcome to ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Allmänna diskussioner';
$txt['default_board_description'] = 'Här kan du diskutera om allt och alla.';
$txt['default_category_name'] = 'Allmän kategori';
$txt['default_time_format'] = '%e %B %Y kl. %H:%M:%S';
$txt['default_news'] = 'ElkArte - Just Installed!';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[positivt]';
$txt['default_karmaApplaudLabel'] = '[negativt]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGäst\\nroot';
$txt['default_smileyset_name'] = 'Fugue\'s Set';
$txt['default_theme_name'] = 'ElkArte Default Theme';

$txt['default_administrator_group'] = 'Administratör';
$txt['default_global_moderator_group'] = 'Global moderator';
$txt['default_moderator_group'] = 'Moderator';
$txt['default_newbie_group'] = 'Nykomling';
$txt['default_junior_group'] = 'Juniormedlem';
$txt['default_full_group'] = 'Fullständig medlem';
$txt['default_senior_group'] = 'Seniormedlem';
$txt['default_hero_group'] = 'Hjältemedlem';

$txt['default_smiley_smiley'] = 'Leende (smiley)';
$txt['default_wink_smiley'] = 'Med glimten i ögat';
$txt['default_cheesy_smiley'] = 'Glad';
$txt['default_grin_smiley'] = 'Skrattande';
$txt['default_angry_smiley'] = 'Arg';
$txt['default_sad_smiley'] = 'Ledsen';
$txt['default_shocked_smiley'] = 'Chockad';
$txt['default_cool_smiley'] = 'Cool';
$txt['default_huh_smiley'] = 'Va?';
$txt['default_roll_eyes_smiley'] = 'Rullande ögon (ironi)';
$txt['default_tongue_smiley'] = 'Tunga';
$txt['default_embarrassed_smiley'] = 'Generad';
$txt['default_lips_sealed_smiley'] = 'Läpparna förseglade';
$txt['default_undecided_smiley'] = 'Obeslutsam';
$txt['default_kiss_smiley'] = 'Kyss';
$txt['default_cry_smiley'] = 'Gråtande';
$txt['default_evil_smiley'] = 'Elak';
$txt['default_azn_smiley'] = 'Azn';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Skrattande';
$txt['default_police_smiley'] = 'Polis';
$txt['default_angel_smiley'] = 'Ängel';

$txt['error_message_click'] = 'Klicka här';
$txt['error_message_try_again'] = 'för att försöka att göra om detta steg.';
$txt['error_message_bad_try_again'] = 'för att försöka att installera i alla fall, men observera att vi <em>avråder starkt</em> från detta.';

$txt['install_settings'] = 'Grundläggande inställningar';
$txt['install_settings_info'] = 'This page requires you to define a few key settings for your forum. ElkArte has automatically detected key settings for you.';
$txt['install_settings_name'] = 'Forumnamn';
$txt['install_settings_name_info'] = 'This is the name of your forum, e.g. &quot;The Testing Forum&quot;.';
$txt['install_settings_name_default'] = 'Mitt forum';
$txt['install_settings_url'] = 'Forumets URL';
$txt['install_settings_url_info'] = 'Detta är Internetadressen till ditt forum <strong>utan avslutande \'/\'!</strong>.<br />I de flesta fall kan du lämna detta fält orört då standardvärdet oftast är rätt.';
$txt['install_settings_compress'] = 'Utdata med Gzip';
$txt['install_settings_compress_title'] = 'Komprimera utdata för att spara bandbredd.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'This function does not work properly on all servers, but can save you a lot of bandwidth.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Click here to test it</a>. (it should just say "PASS".)';
$txt['install_settings_dbsession'] = 'Databassessioner';
$txt['install_settings_dbsession_title'] = 'Använd databasen för att lagra sessioner, istället för filer på servern.';
$txt['install_settings_dbsession_info1'] = 'Denna funktion är nästan alltid bäst att ha påslagen, då det gör sessioner mer pålitliga.';
$txt['install_settings_dbsession_info2'] = 'Denna funktion är som regel en bra idé, men det kanske inte fungerar som det ska på denna server.';
$txt['install_settings_proceed'] = 'Fortsätt';

$txt['db_settings'] = 'Databasinställningar';
$txt['db_settings_info'] = 'Det här är inställningarna för din databasmotor. Om du inte vet vad som ska stå här, bör du fråga ditt webbhotell.';
$txt['db_settings_type'] = 'Databastyp';
$txt['db_settings_type_info'] = 'Multiple supported database types were detected - which one do you wish to use?';
$txt['db_settings_server'] = 'Servernamn';
$txt['db_settings_server_info'] = 'Detta är nästan alltid localhost - så om du inte vet, prova med localhost.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Leave empty if your server is listening on the default port, or you are uncertain.';
$txt['db_settings_username'] = 'User name';
$txt['db_settings_username_info'] = 'Fill in the user name you need to connect to your database here.<br />If you don\'t know what it is, try the user name of your FTP account, most of the time they are the same.';
$txt['db_settings_password'] = 'Lösenord';
$txt['db_settings_password_info'] = 'Here you should put the password you need to connect to your database.<br />If you don\'t know this, you should try the password to your FTP account.';
$txt['db_settings_database'] = 'Namn på databasen';
$txt['db_settings_database_info'] = 'Fill in the name of the database you want to use for ElkArte to store its data in.';
$txt['db_settings_database_info_note'] = 'Om inte denna databas finns kommer installationen försöka skapa den.';
$txt['db_settings_database_file'] = 'Database file name';
$txt['db_settings_database_file_info'] = 'This is the name of the file in which to store the ElkArte data. We recommend you use the randomly generated name for this and set the path of this file to be outside of the public area of your webserver.';
$txt['db_settings_prefix'] = 'Tabellprefix';
$txt['db_settings_prefix_info'] = 'Detta prefix kommer att läggas till i början av alla tabellnamn i databasen. <strong>Installera inte två forum med samma prefix!</strong><br />Detta värde gör det möjligt att installera flera forum i samma databas.';
$txt['db_populate'] = 'Fyll databas';
$txt['db_populate_info'] = 'Dina inställningar har nu sparats och databasen har fyllts med all data som krävs för att få igång ditt forum.
Sammanfattning av befolkningen:';
$txt['db_populate_info2'] = 'Klicka på &quot;Fortsätt&quot; för att gå till sidan där du skapar ett administratörs konto ';
$txt['db_populate_inserts'] = 'Lade till %1$d rader. ';
$txt['db_populate_tables'] = 'Skapade %1$d tabeller.';
$txt['db_populate_insert_dups'] = 'Ignorerade %1$d dubbletter.';
$txt['db_populate_table_dups'] = 'Ignorerade %1$d dubbla tabeller';

$txt['user_settings'] = 'Skapa ditt konto';
$txt['user_settings_info'] = 'Installationsprogrammet kommer du att skapa ett administratörskonto åt dig.';
$txt['user_settings_username'] = 'Your user name';
$txt['user_settings_username_info'] = 'Choose the name you want to login with.';
$txt['user_settings_password'] = 'Lösenord';
$txt['user_settings_password_info'] = 'Ange det lösenord du vill använda här, och se till att komma ihåg det!';
$txt['user_settings_again'] = 'Lösenord';
$txt['user_settings_again_info'] = '(bara för verifiering)';
$txt['user_settings_email'] = 'E-postadress';
$txt['user_settings_email_info'] = 'Ange din e-postadress. <strong>Detta måste vara en giltig e-postadress.</strong>';
$txt['user_settings_database'] = 'Lösenord för MySQL-databasen';
$txt['user_settings_database_info'] = 'Installationsprogrammet kräver att du anger databaslösenordet för att kunna skapa administratörskontot, av säkerhetsskäl.';
$txt['user_settings_skip'] = 'Hoppa över';
$txt['user_settings_skip_sure'] = 'Vill du verkligen hoppa över skapandet av ett administratörs konto?';
$txt['user_settings_proceed'] = 'Avsluta';

$txt['ftp_checking_writable'] = 'Checking if files are writable';
$txt['ftp_setup'] = 'FTP-anslutningsinformation';
$txt['ftp_setup_info'] = 'Installationsprogrammet kan ansluta till din server via FTP, för att automatiskt kunna ställa in rättigheter på filer som behöver vara skrivbara och diverse annat. Om detta inte fungerar för dig, måste du ställa in dessa rättigheter manuellt. Observera att denna funktion i dagsläget inte stödjer säkra FTP-anslutningar via SSL.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'This should be the server address and port for your FTP server.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'User name';
$txt['ftp_username_info'] = 'The user name to login with. <em>This will not be saved anywhere.</em>';
$txt['ftp_password'] = 'Lösenord';
$txt['ftp_password_info'] = 'Lösenord att logga in med. <em>Detta kommer inte att sparas någonstans.</em>';
$txt['ftp_path'] = 'Installationssökväg';
$txt['ftp_path_info'] = 'Detta är den <em>relativa</em> sökväg till din FTP-server.';
$txt['ftp_path_found_info'] = 'Sökvägen ovan har känts av automatiskt.';
$txt['ftp_connect'] = 'Anslut';
$txt['ftp_setup_why'] = 'Vad behövs detta för?';
$txt['ftp_setup_why_info'] = 'Some files need to be writable for ElkArte to work properly.  This step allows you to let the installer make them writable for you.  However, in some cases it won\'t work - in that case, please make the following files 777 (writable, 755 on some hosts):';
$txt['ftp_setup_again'] = 'för att testa om filerna är skrivbara igen.';

$txt['error_php_too_low'] = 'Warning!  You do not appear to have a version of PHP installed on your webserver that meets ElkArte\'s <strong>minimum installations requirements</strong>.<br />If you are not the host, you will need to ask your host to upgrade, or use a different host - otherwise, please upgrade PHP to a recent version.<br /><br />If you know for a fact that your PHP version is high enough you may continue, although this is strongly discouraged.';
$txt['error_missing_files'] = 'Kunde inte hitta viktiga installationsfiler i katalogen som detta skript körs från!<br /><br />Se till så att du laddat upp samtliga filer som ingick i installationsarkivet, inklusive SQL-filen, och försök sedan igen.';
$txt['error_session_save_path'] = 'Var vänlig och meddela ditt webbhotell att variabeln <strong>session.save_path som anges i php.ini</strong> inte är giltig! Den måste peka på en katalog som <strong>existerar på servern</strong>, och som är <strong>skrivbar</strong> av användaren som PHP körs som.<br />';
$txt['error_windows_chmod'] = 'You\'re on a windows server, and some crucial files are not writable.  Please ask your host to give <strong>write permissions</strong> to the user PHP is running under for the files in your ElkArte installation.  The following files or directories need to be writable:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Kunde inte ansluta till FTP-servern med dessa anslutningsuppgifter.';
$txt['error_db_file'] = 'Kan inte hitta källfilen för databasen! Kontrollera att filen %1$s finns inom ditt forums källkatalog.';
$txt['error_db_connect'] = 'Lyckades inte anlita till databasmotorn med angivna uppgifter.<br /><br />Om du inte är säker på vad du ska skriva, vänligen kontakta ditt webbhotell.';
$txt['error_db_too_low'] = 'The version of your database server is very old and does not meet ElkArte\'s minimum requirements.<br /><br />Please ask your host to either upgrade it or supply a new one, and if they won\'t, please try a different host.';
$txt['error_db_database'] = 'The installer was unable to access the &quot;<em>%1$s</em>&quot; database.  With some hosts, you have to create the database in your administration panel before ElkArte can use it.  Some also add prefixes - like your username - to your database names.';
$txt['error_db_queries'] = 'En del av databasfrågorna kunde inte utföras korrekt. Det kan tänkas bero på att din databasmotor inte stöds till fullo (antingen ny betaversion eller för gammal version).<br /><br />Teknisk information om frågorna:';
$txt['error_db_queries_line'] = 'Rad #';
$txt['error_db_missing'] = 'The installer was unable to detect database support in PHP that ElkArte can utilize.  Please ask your host to ensure that PHP was compiled with the desired database, or that the proper php extension is being loaded.  Currently ElkArte supports the:  &quot;%1$s&quot; extensions';
$txt['error_db_script_missing'] = 'Installeraren kunde inte hitta några installations skript filer för den funna databastypen. Vänligen kontrollera du har uppladdat de nödvändiga installationsfilerna till din forumkatalog, exempelvis, &quot;%1$s&quot';
$txt['error_session_missing'] = 'Installeraren kunde inte känna av stöd för sessioner på din servers installation av PHP. Vänligen be ditt webbhotell att undersöka så att PHP har kompilerats med sessionsstöd.'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Du skrev in två olika lösenord!';
$txt['error_user_settings_no_password'] = 'Ditt lösenord måste vara minst fyra tecken långt.';
$txt['error_user_settings_taken'] = 'Sorry, a member is already registered with that user name and/or email address.<br /><br />A new account has not been created.';
$txt['error_user_settings_query'] = 'Ett databasfel uppstod medan vi försökte att skapa administratörskontot. Felet var:';
$txt['error_subs_missing'] = 'Unable to find the sources/Subs.php file.  Please make sure it was uploaded properly, and then try again.';
$txt['error_db_alter_priv'] = 'The database account you specified does not have permission to ALTER, CREATE, and/or DROP tables in the database; this is necessary for ElkArte to function properly.';
$txt['error_versions_do_not_match'] = 'The installer has detected another version of ElkArte already installed with the specified information.  If you are trying to upgrade, you should use the upgrader, not the installer.<br /><br />Otherwise, you may wish to use different information, or create a backup and then delete the data currently in the database.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'The current version of your database doesn\'t support the use of the UTF-8 character set. You can not install ElkArte';
$txt['error_valid_email_needed'] = 'Du har inte angett en giltig e-postadress.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Varning!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Du måste ange ett namn för databas filen för SQLite';
$txt['error_db_prefix_numeric'] = 'Den valda databastypen stöder inte användandet av numeriska prefix.';
$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';
$txt['error_username_too_long'] = 'User name must be less than 25 characters long.';
$txt['error_username_left_empty'] = 'User name field was left empty.';
$txt['error_db_filename_exists'] = 'Databasen du försöker skapa existerar redan. Radera den nuvarande databasen eller ange ett annat namn.';
$txt['error_db_prefix_reserved'] = 'Prefixet du angav är ett reserverat prefix. Vänligen ange ett annat prefix.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade Utility';
$txt['upgrade_warning'] = 'Varning!';
$txt['upgrade_critical_error'] = 'Allvarligt fel!';
$txt['upgrade_continue'] = 'Fortsätt';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Hoppa över';
$txt['upgrade_note'] = 'Notera!';
$txt['upgrade_step'] = 'Steg';
$txt['upgrade_steps'] = 'Steg';
$txt['upgrade_progress'] = 'Procent klart';
$txt['upgrade_overall_progress'] = 'Avklarat totalt';
$txt['upgrade_step_progress'] = 'Avklarat i detta steg';
$txt['upgrade_time_elapsed'] = 'Tid som gått åt';
$txt['upgrade_time_mins'] = 'minuter';
$txt['upgrade_time_secs'] = 'sekunder';

$txt['upgrade_incomplete'] = 'Ej färdigt';
$txt['upgrade_not_quite_done'] = 'Inte riktigt klart ännu!';
$txt['upgrade_paused_overload'] = 'Uppgraderingen har stoppats för att förhindra att din server överladdas. Oroa dig inte, inget är fel - klicka bara på <label for="contbutt">Fortsätt</label> nedan för att fortsätta.';

$txt['upgrade_ready_proceed'] = 'Thank you for choosing to upgrade to ElkArte %1$s. All files appear to be in place, and we\'re ready to proceed.';

$txt['upgrade_error_script_js'] = 'The upgrade script cannot find script.js or it is out of date. Make sure your theme paths are correct. You can download a settings check and repair script from <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte tools</a>.';

$txt['upgrade_warning_lots_data'] = 'Detta uppgraderingsskript har upptäckt att ditt forum innehåller mycket data som behöver uppgraderas. Denna process kan ta ett bra tag beroende på din server och ditt forums storlek, och väldigt stora forum (över 300,000 meddelanden) kan ta flera timmar att slutföra.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';