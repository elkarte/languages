<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'sv_SE.utf8';
$txt['lang_dictionary'] = 'sv';
$txt['lang_spelling'] = 'american';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'Sunday';
$txt['monday'] = 'Monday';
$txt['tuesday'] = 'Tuesday';
$txt['wednesday'] = 'Wednesday';
$txt['thursday'] = 'Thursday';
$txt['friday'] = 'Friday';
$txt['saturday'] = 'Saturday';

$txt['sunday_short'] = 'Sun';
$txt['monday_short'] = 'Mon';
$txt['tuesday_short'] = 'Tue';
$txt['wednesday_short'] = 'Wed';
$txt['thursday_short'] = 'Thu';
$txt['friday_short'] = 'Fri';
$txt['saturday_short'] = 'Sat';

$txt['january'] = 'January';
$txt['february'] = 'February';
$txt['march'] = 'March';
$txt['april'] = 'April';
$txt['may'] = 'May';
$txt['june'] = 'June';
$txt['july'] = 'July';
$txt['august'] = 'August';
$txt['september'] = 'September';
$txt['october'] = 'October';
$txt['november'] = 'November';
$txt['december'] = 'December';

$txt['january_titles'] = 'January';
$txt['february_titles'] = 'February';
$txt['march_titles'] = 'March';
$txt['april_titles'] = 'April';
$txt['may_titles'] = 'May';
$txt['june_titles'] = 'June';
$txt['july_titles'] = 'July';
$txt['august_titles'] = 'August';
$txt['september_titles'] = 'September';
$txt['october_titles'] = 'October';
$txt['november_titles'] = 'November';
$txt['december_titles'] = 'December';

$txt['january_short'] = 'Jan';
$txt['february_short'] = 'Feb';
$txt['march_short'] = 'Mar';
$txt['april_short'] = 'Apr';
$txt['may_short'] = 'May';
$txt['june_short'] = 'Jun';
$txt['july_short'] = 'Jul';
$txt['august_short'] = 'Aug';
$txt['september_short'] = 'Sep';
$txt['october_short'] = 'Oct';
$txt['november_short'] = 'Nov';
$txt['december_short'] = 'Dec';

$txt['time_am'] = 'AM';
$txt['time_pm'] = 'PM';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Startsida';
$txt['community'] = 'Community';
// Sub menu labels
$txt['help'] = 'Hjälp';
$txt['search'] = 'Sök';
$txt['calendar'] = 'Kalender';
$txt['members'] = 'Medlemmar';
$txt['recent_posts'] = 'Nyliga inlägg';

$txt['admin'] = 'Administrationscenter';
// Sub menu labels
$txt['errlog'] = 'Fellogg';
$txt['package'] = 'Pakethanterare';
$txt['edit_permissions'] = 'Rättigheter';
$txt['modSettings_title'] = 'Inställningar och alternativ';

$txt['moderate'] = 'Moderera';
// Sub menu labels
$txt['modlog_view'] = 'Moderatorlogg';
$txt['mc_emailerror'] = 'Unapproved Emails';
$txt['mc_reported_posts'] = 'Rapporterade inlägg';
$txt['mc_reported_pms'] = 'Reported Personal Messages';
$txt['mc_unapproved_attachments'] = 'Ej godkända bifogade filer';
$txt['mc_unapproved_poststopics'] = 'Ej godkända inlägg och ämnen';

$txt['pm_short'] = 'Mina meddelanden';
// Sub menu labels
$txt['pm_menu_read'] = 'Läs dina meddelanden';
$txt['pm_menu_send'] = 'Skicka ett meddelande';

$txt['account_short'] = 'My Account';
// Sub menu labels
$txt['profile'] = 'Profilen';
$txt['mydrafts'] = 'My Drafts';
$txt['summary'] = 'Sammanfattning';
$txt['theme'] = 'Utseende- och layoutinställningar';
$txt['account'] = 'Kontoinställningar';
$txt['forumprofile'] = 'Forumprofil';

$txt['view_unread_category'] = 'Nya inlägg';
$txt['view_replies_category'] = 'New Replies';

$txt['login'] = 'Log in';
$txt['register'] = 'Registrera';
$txt['logout'] = 'Log out';
// End main menu strings.

$txt['save'] = 'Spara';

$txt['modify'] = '&auml;ndra';
$txt['forum_index'] = '%1$s - Index';
$txt['board_name'] = 'Namn på tavla';
$txt['posts'] = 'Inlägg';

$txt['member_postcount'] = 'Inlägg';
$txt['no_subject'] = '(Ämne saknas)';
$txt['view_profile'] = 'Visa profil';
$txt['guest_title'] = 'gäst';
$txt['author'] = 'Upphovsman';
$txt['on'] = 'AM';
$txt['remove'] = 'Ta bort';
$txt['start_new_topic'] = 'Starta nytt ämne';

// Use numeric entities in the below string.
$txt['username'] = 'Användarnamn';
$txt['password'] = 'Lösenord';

$txt['username_no_exist'] = 'Användarnamnet finns inte.';
$txt['no_user_with_email'] = 'Det finns ingen användare som har den e-postadressen.';

$txt['board_moderator'] = 'Moderator';
$txt['remove_topic'] = 'Ta bort';
$txt['topics'] = 'Visa inlägg';
$txt['modify_msg'] = 'Redigera inlägg';
$txt['name'] = 'Namn';
$txt['email'] = 'E-post';
$txt['user_email_address'] = 'E-postadress';
$txt['subject'] = 'Ämne';
$txt['message'] = 'Meddelande';
$txt['redirects'] = 'Omdirigeringar';

$txt['choose_pass'] = 'Välj lösenord';
$txt['verify_pass'] = 'Skriv lösenordet igen';
$txt['position'] = 'Ställning';
$txt['notify_announcements'] = 'Sign up to receive important site news by email';

$txt['profile_of'] = 'Visa profil för';
$txt['total'] = 'Totalt';
$txt['posts_made'] = 'Inlägg';
$txt['topics_made'] = 'Visa inlägg';
$txt['website'] = 'Hemsida';
$txt['contact'] = 'Contact Us';
$txt['warning_status'] = 'Varningsstatus';
$txt['user_warn_watch'] = 'Användaren är på moderatorernas övervakningslista ';
$txt['user_warn_moderate'] = 'Användarens inlägg måste godkännas';
$txt['user_warn_mute'] = 'Användaren får inte skriva inlägg';
$txt['warn_watch'] = 'Övervakad';
$txt['warn_moderate'] = 'Modererad';
$txt['warn_mute'] = 'Nedtystad';
$txt['warning_issue'] = 'Warn';

$txt['message_index'] = 'Meddelandeindex';
$txt['news'] = 'Nyheter';
$txt['page'] = 'Page';
$txt['prev'] = 'previous';
$txt['next'] = 'next';

$txt['post'] = 'Posta';
$txt['error_occurred'] = 'An Error Has Occurred';
$txt['send_error_occurred'] = 'An error has occurred, <a href="{href}">please click here to try again</a>.';
$txt['require_field'] = 'This is a required field.';
$txt['started_by'] = 'Started by author';
$txt['topic_started_by'] = 'Started by %1$s';
$txt['topic_started_by_in'] = 'Started by %1$s in %2$s';
$txt['replies'] = 'Svar';
$txt['last_post'] = 'Senaste inlägg';
$txt['first_post'] = 'First post';
$txt['last_poster'] = 'Last post author';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s </span><span class="board_lastposter">by %1$s</span><span class="board_lasttime"><strong>Last post: </strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s Posts in %2$s Topics by %3$s Members';
$txt['show'] = 'Show';
$txt['hide'] = 'Hide';
$txt['sort_by'] = 'Sort By';
$txt['sort_asc'] = 'Sort ascending';
$txt['sort_desc'] = 'Sort descending';

$txt['admin_login'] = 'Administration Log in';
// Use numeric entities in the below string.
$txt['topic'] = 'Ämne';
$txt['help'] = 'Hjälp';
$txt['notify'] = 'Underrätta';
$txt['unnotify'] = 'Säg upp prenumerationen';
$txt['notify_request'] = 'Vill du få e-post när någon svarar på detta ämne?';
// Use numeric entities in the below string.
$txt['regards_team'] = "Regards,\nThe {forum_name_html_unsafe} Team.";
$txt['notify_replies'] = 'Underrätta via e-post';
$txt['move_topic'] = 'Flytta';
$txt['move_to'] = 'Flytta till';
$txt['pages'] = 'Sidor';
$txt['users_active'] = 'Active in past %1$d minutes';
$txt['personal_messages'] = 'Privata meddelanden';
$txt['reply_quote'] = 'Svara med citat';
$txt['reply'] = 'Svara';
$txt['reply_number'] = 'Reply #%1$s';
$txt['approve'] = 'Godkänn';
$txt['unapprove'] = 'Unapprove';
$txt['approve_all'] = 'godkänn alla';
$txt['awaiting_approval'] = 'Väntar på godkännande';
$txt['attach_awaiting_approve'] = 'Bifogade filer som väntar på godkännande';
$txt['post_awaiting_approval'] = 'OBS! Detta inlägg väntar på att godkännas av en moderator.';
$txt['there_are_unapproved_topics'] = 'There are %1$s topics and %2$s posts awaiting approval in this board. <a href="%3$s">Click here to view them</a>.';
$txt['send_message'] = 'Skicka meddelande';

$txt['msg_alert_no_messages'] = 'you don\'t have any message';
$txt['msg_alert_one_message'] = 'you have <a href="%1$s">1 message</a>';
$txt['msg_alert_many_message'] = 'you have <a href="%1$s">%2$d messages</a>';
$txt['msg_alert_one_new'] = '1 is new';
$txt['msg_alert_many_new'] = '%1$d are new';
$txt['remove_message'] = 'Radera inlägg';

$txt['topic_alert_none'] = 'Inga inlägg...';
$txt['pm_alert_none'] = 'Inga inlägg...';

$txt['online_users'] = 'Användare online'; //Deprecated
$txt['online_now'] = 'Online Now';
$txt['personal_message'] = 'Privata meddelanden';
$txt['jump_to'] = 'Gå till';
$txt['go'] = 'OK';
$txt['are_sure_remove_topic'] = 'Är du säker på att du vill radera det här ämnet?';
$txt['yes'] = 'Ja';
$txt['no'] = 'Nej';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'AM';

$txt['search'] = 'Sök';
$txt['all'] = 'Alla';
$txt['search_entireforum'] = 'Entire Forum';
$txt['search_thisbrd'] = 'This board';
$txt['search_thistopic'] = 'This topic';
$txt['search_members'] = 'Medlemmar';

$txt['back'] = 'Tillbaka';
$txt['continue'] = 'Fortsätt';
$txt['password_reminder'] = 'Lösenordspåminnelse';
$txt['topic_started'] = 'Ämnet startat av';
$txt['title'] = 'Titel';
$txt['post_by'] = 'Skrivet av';
$txt['welcome_newest_member'] = 'Please welcome %1$s, our newest member.';
$txt['admin_center'] = 'Administrationscenter';
$txt['admin_session_active'] = 'You have an active admin session in place. We recommend to <strong><a class="strong" href="%1$s">end this session</a></strong> once you have finished your administrative tasks.';
$txt['admin_maintenance_active'] = 'Your forum is currently in maintenance mode, only admins can log in.  Remember to <strong><a class="strong" href="%1$s">exit maintenance</a></strong> once you have finished your administrative tasks.';
$txt['query_command_denied'] = 'The following MySQL errors are occurring, please verify your setup:';
$txt['query_command_denied_guests'] = 'It seems something has gone sour on the forum with the database. This problem should only be temporary, so please come back later and try again.  If you continue to see this message, please report the following message to the administrator:';
$txt['query_command_denied_guests_msg'] = 'the command %1$s is denied on the database';
$txt['last_edit_by'] = '<span class="lastedit">Last Edit</span>: %1$s by %2$s';
$txt['notify_deactivate'] = 'Vill du stänga av underrättelse vid svar för det här ämnet?';

$txt['date_registered'] = 'Registreringsdatum';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'View all recent posts.';
$txt['is_recent_updated'] = '%1$s is the most recently updated topic';

$txt['male'] = 'Man';
$txt['female'] = 'Kvinna';

$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Hej';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Välkommen';
$txt['select_destination'] = 'Välj destination';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Skrivet av';

$txt['icon_smiley'] = 'Leende (smiley)';
$txt['icon_angry'] = 'Arg';
$txt['icon_cheesy'] = 'Glad';
$txt['icon_laugh'] = 'Skrattande';
$txt['icon_sad'] = 'Ledsen';
$txt['icon_wink'] = 'Med glimten i ögat';
$txt['icon_grin'] = 'Skrattande';
$txt['icon_shocked'] = 'Chockad';
$txt['icon_cool'] = 'Cool';
$txt['icon_huh'] = 'Va?';
$txt['icon_rolleyes'] = 'Rullande ögon (ironi)';
$txt['icon_tongue'] = 'Tunga';
$txt['icon_embarrassed'] = 'Generad';
$txt['icon_lips'] = 'Läpparna förseglade';
$txt['icon_undecided'] = 'Obeslutsam';
$txt['icon_kiss'] = 'Kyss';
$txt['icon_cry'] = 'Gråtande';
$txt['icon_angel'] = 'Innocent';

$txt['moderator'] = 'Moderator';
$txt['moderators'] = 'Moderatorer';

$txt['views'] = 'visningar';
$txt['new'] = 'Nya';
$txt['no_redir'] = 'Redirected from %1$s';

$txt['view_all_members'] = 'Visa alla medlemmar';
$txt['view'] = 'Visa';

$txt['viewing_members'] = 'Visar medlemmarna %1$s till %2$s';
$txt['of_total_members'] = 'av totalt %1$s medlemmar';

$txt['forgot_your_password'] = 'Glömt bort ditt lösenord?';

$txt['date'] = 'Datum';
// Use numeric entities in the below string.
$txt['from'] = 'Från';
$txt['to'] = 'Till';

$txt['board_topics'] = 'Visa inlägg';
$txt['members_title'] = 'Medlemmar';
$txt['members_list'] = 'Medlemslista';
$txt['new_posts'] = 'Nya inlägg';
$txt['old_posts'] = 'Inga nya inlägg';
$txt['redirect_board'] = 'Omdirigera tavla';
$txt['redirect_board_to'] = 'Redirecting to %1$s';

$txt['sendtopic_send'] = 'Skicka';
$txt['report_sent'] = 'Din rapport har skickats.';
$txt['topic_sent'] = 'Your email has been sent successfully.';

$txt['time_offset'] = 'Tidsskillnad';
$txt['or'] = 'eller';

$txt['mention'] = 'Underrättelser och e-post';
$txt['notifications'] = 'Underrättelser och e-post';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = 'Ledsen %1$s, du är bannlyst från det här forumet!';
$txt['your_ban_expires'] = 'Denna bannlysning kommer att upphöra %1$s.';
$txt['your_ban_expires_never'] = 'Denna bannlysning kommer aldrig att upphöra.';
$txt['ban_continue_browse'] = 'Du kan fortsätta att visa forumet som gäst.';

$txt['mark_as_read'] = 'Markera alla ämnen på samtliga tavlor som lästa';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'Mark THESE messages as read';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'Låst ämne';
$txt['normal_topic'] = 'Normalt ämne';
$txt['participation_caption'] = 'Ämne du har skrivit i';

$txt['print'] = 'Skriv ut';
$txt['topic_summary'] = 'Ämnessammanfattning';
$txt['not_applicable'] = 'N/A ';
$txt['name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['total_members'] = 'Totalt antal medlemmar';
$txt['total_posts'] = 'Totalt antal skrivna inlägg';
$txt['total_topics'] = 'Totalt antal ämnen';

$txt['mins_logged_in'] = 'Antal minuter att förbli inloggad';

$txt['preview'] = 'Förhandsgranska';
$txt['always_logged_in'] = 'Förbli inloggad för alltid';

$txt['logged'] = 'Loggat';
// Use numeric entities in the below string.
$txt['ip'] = 'IP-adress';

$txt['www'] = 'Hemsida';
$txt['link'] = 'Link';

$txt['by'] = 'av'; //Deprecated

$txt['hours'] = 'timmar';
$txt['minutes'] = 'minuter';
$txt['seconds'] = 'sekunder';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'Hour';
$txt['days_word'] = 'dagar';

$txt['newest_member'] = ', vår nyaste medlem.'; //Deprecated

$txt['search_for'] = 'Sök efter';
$txt['search_match'] = 'Match';

$txt['maintain_mode_on'] = 'Kom ihåg att detta forum är i underhållsläge.';

$txt['read'] = 'Läs'; //Deprecated
$txt['times'] = 'gånger'; //Deprecated
$txt['read_one_time'] = 'Read 1 time';
$txt['read_many_times'] = 'Read %1$d times';

$txt['forum_stats'] = 'Forumstatistik';
$txt['latest_member'] = 'Nyaste medlemmen';
$txt['total_cats'] = 'Totalt antal kategorier';
$txt['latest_post'] = 'Senaste inlägg';

$txt['here'] = 'här';
$txt['you_have_no_msg'] = 'You don\'t have any message...';
$txt['you_have_one_msg'] = 'You\'ve 1 message...<a href="%1$s">Click here to view it</a>';
$txt['you_have_many_msgs'] = 'You\'ve %2$d messages...<a href="%1$s">Click here to view them</a>';

$txt['total_boards'] = 'Totalt antal tavlor';

$txt['print_page'] = 'Skriv ut sidan';
$txt['print_page_text'] = 'Text only';
$txt['print_page_images'] = 'Text with Images';

$txt['valid_email'] = 'Detta måste vara en giltig e-postadress.';

$txt['info_center_title'] = '%1$s - Informationscenter';

$txt['send_topic'] = 'Share';
$txt['unwatch'] = 'Unwatch';
$txt['watch'] = 'Watch';

$txt['sendtopic_title'] = 'Skicka ämnet &quot;%1$s&quot; till en vän.';
$txt['sendtopic_sender_name'] = 'Ditt namn';
$txt['sendtopic_sender_email'] = 'Din e-postadress';
$txt['sendtopic_receiver_name'] = 'Mottagarens namn';
$txt['sendtopic_receiver_email'] = 'Mottagarens e-postadress';
$txt['sendtopic_comment'] = 'Lägg till kommantar';

$txt['allow_user_email'] = 'Tillåt användare att skicka e-post till mig';

$txt['check_all'] = 'Markera alla';

// Use numeric entities in the below string.
$txt['database_error'] = 'Databasfel';
$txt['try_again'] = 'Försök igen. Om du får detta felmeddelande upprepade gånger, var vänlig och meddela detta till administratör.';
$txt['file'] = 'Fil';
$txt['line'] = 'Rad';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'ElkArte has detected and automatically tried to repair an error in your database.  If you continue to have problems, or continue to receive these emails, please contact your host.';
$txt['database_error_versions'] = '<strong>Note:</strong> Your database version is %1$s.';
$txt['template_parse_error'] = 'Malltolkningsfel!';
$txt['template_parse_error_message'] = 'Det ser ut som att något gått snett med mallsystemet på forumet. Mest troligt är problemet högst tillfälligt, så kom gärna tillbaka lite senare och försök igen. Om du fortsätter att få detta meddelande, vänligen kontakta administratören.<br /><br />Du kan också försöka att <a href="javascript:location.reload();">uppdatera den här sidan</a>.';
$txt['template_parse_error_details'] = 'There was a problem loading the <span class="tt"><strong>%1$s</strong></span> template or language file.  Please check the syntax and try again - remember, single quotes (<span class="tt">\'</span>) often have to be escaped with a backslash (<span class="tt">\\</span>).  To see more specific error information from PHP, try <a href="%2$s%1$s">accessing the file directly</a>.<br /><br />You may want to try to <a href="javascript:location.reload();">refresh this page</a> or <a href="%3$s">use the default theme</a>.';
$txt['template_parse_undefined'] = 'An undefined error occurred during the parsing of this template';

$txt['today'] = 'Today at %1$s';
$txt['yesterday'] = 'Yesterday at %1$s';

// Relative times
$txt['rt_now'] = 'just now';
$txt['rt_minute'] = 'A minute ago';
$txt['rt_minutes'] = '%s minutes ago';
$txt['rt_hour'] = 'An hour ago';
$txt['rt_hours'] = '%s hours ago';
$txt['rt_day'] = 'A day ago';
$txt['rt_days'] = '%s days ago';
$txt['rt_week'] = 'A week ago';
$txt['rt_weeks'] = '%s weeks ago';
$txt['rt_month'] = 'A month ago';
$txt['rt_months'] = '%s months ago';
$txt['rt_year'] = 'A year ago';
$txt['rt_years'] = '%s years ago';

$txt['new_poll'] = 'Skapa ny omröstning';
$txt['poll_question'] = 'Fråga';
$txt['poll_question_options'] = 'Question and Options';
$txt['poll_vote'] = 'Skicka röst';
$txt['poll_total_voters'] = 'Antal personer som röstat';
$txt['draft_saved_on'] = 'Draft last saved';
$txt['poll_results'] = 'Visa resultat.';
$txt['poll_lock'] = 'Lås omröstning';
$txt['poll_unlock'] = 'Lås upp omröstning';
$txt['poll_edit'] = 'Redigera omröstning';
$txt['poll'] = 'Omröstning';
$txt['one_day'] = '1 dag';
$txt['one_week'] = '1 vecka';
$txt['two_weeks'] = '2 Weeks';
$txt['one_month'] = '1 månad';
$txt['two_months'] = '2 Months';
$txt['forever'] = 'För alltid';
$txt['quick_login_dec'] = 'Logga in med användarnamn, lösenord och önskad sessionslängd';
$txt['one_hour'] = '1 timme';
$txt['moved'] = 'FLYTTAD';
$txt['moved_why'] = 'Skriv en kort förklaring om<br />varför ämnet har flyttats.';
$txt['board'] = 'Tavla';
$txt['in'] = 'sv';
$txt['sticky_topic'] = 'Pinned Topic';
$txt['split'] = 'SPLIT';

$txt['delete'] = 'Radera';

$txt['byte'] = 'B';
$txt['kilobyte'] = 'kB';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[Mer statistik]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Kod';
$txt['code_select'] = '[Välj]';
$txt['quote_from'] = 'Citat från';
$txt['quote'] = 'Citera';
$txt['quote_new'] = 'New topic';
$txt['follow_ups'] = 'Follow-ups';
$txt['topic_derived_from'] = 'Topic derived from %1$s';
$txt['edit'] = 'Redigera';
$txt['quick_edit'] = 'Quick Edit';
$txt['post_options'] = 'More...';

$txt['set_sticky'] = 'Pin';
$txt['set_nonsticky'] = 'Unpin';
$txt['set_lock'] = 'Lås';
$txt['set_unlock'] = 'Lås upp';

$txt['search_advanced'] = 'Show advanced options';
$txt['search_simple'] = 'Hide advanced options';

$txt['security_risk'] = 'STOR SÄKERHETSRISK:';
$txt['not_removed'] = 'You have not removed %1$s';
$txt['not_removed_extra'] = '%1$s is a backup of %2$s that was not generated by ElkArte. It can be accessed directly and used to gain unauthorised access to your forum. You should delete it immediately.';
$txt['generic_warning'] = 'Warning';
$txt['agreement_missing'] = 'You are requiring new users to accept a registration agreement, however the file (agreement.txt) doesn\'t exist.';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'You have just updated!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Click here to see what\'s new in this version of ElkArte!</a>!';

$txt['cache_writable'] = 'Cachelagringskatalogen är inte skrivbar - detta kommer att påverka ditt forums prestanda avsevärt.';

$txt['page_created_full'] = 'Page created in %1$.3f seconds with %2$d queries.';

$txt['report_to_mod_func'] = 'Använd denna funktion för att meddela moderatorer och administratörer om ett olämpligt inlägg, eller ett inlägg som är postat i fel ämne/tavla.<br /><em>Observera att din e-postadress kommer att avslöjas för moderatorerna, om du använder denna funktion.</em>';

$txt['online'] = 'Inloggad';
$txt['member_is_online'] = '%1$s is online';
$txt['offline'] = 'Utloggad';
$txt['member_is_offline'] = '%1$s is offline';
$txt['pm_online'] = 'Privat meddelande (Inloggad)';
$txt['pm_offline'] = 'Privat meddelande (Utloggad)';
$txt['status'] = 'Status';

$txt['skip_nav'] = 'Skip to main content';
$txt['go_up'] = 'Gå upp';
$txt['go_down'] = 'Gå ned';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Födelsedagar:';
$txt['events'] = 'Händelser:';
$txt['birthdays_upcoming'] = 'Kommande födelsedagar:';
$txt['events_upcoming'] = 'Kommande händelser:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Holidays:';
$txt['calendar_month'] = 'Månad:';
$txt['calendar_year'] = 'År:';
$txt['calendar_day'] = 'Dag:';
$txt['calendar_event_title'] = 'Titel för händelsen';
$txt['calendar_event_options'] = 'Händelse tillval';
$txt['calendar_post_in'] = 'Posta på tavla:';
$txt['calendar_edit'] = 'Redigera händelse';
$txt['event_delete_confirm'] = 'Radera den här händelsen?';
$txt['event_delete'] = 'Radera händelse';
$txt['calendar_post_event'] = 'Posta ny händelse';
$txt['calendar'] = 'Kalender';
$txt['calendar_link'] = 'Länka till kalender';
$txt['calendar_upcoming'] = 'Kommande kalenderhändelser';
$txt['calendar_today'] = 'Dagens kalenderhändelser';
$txt['calendar_week'] = 'Week';
$txt['calendar_week_title'] = 'Vecka %1$d av %2$d';
$txt['calendar_numb_days'] = 'Antal dagar:';
$txt['calendar_how_edit'] = 'hur gör man för att ändra händelserna?';
$txt['calendar_link_event'] = 'Länka händelser';
$txt['calendar_confirm_delete'] = 'Är du säker på att du vill radera denna händelse?';
$txt['calendar_linked_events'] = 'Ihoplänkade händelser';
$txt['calendar_click_all'] = 'klicka för att se alla %1$s';

$txt['moveTopic1'] = 'Lämna kvar ett hänvisningsmeddelande på tavlan ämnet flyttats från';
$txt['moveTopic2'] = 'Ändra rubriken på ämnet';
$txt['moveTopic3'] = 'Ny rubrik';
$txt['moveTopic4'] = 'Ändra rubrik på samtliga meddelanden';
$txt['move_topic_unapproved_js'] = 'Varning! Detta ämne har inte blivit godkänt ännu. \\n\\n det är inte rekommenderat att du skapar vidarebefodrande ämnen om du avser att godkänna meddelandet
omedelbart efter flyttningen.';
$txt['movetopic_auto_board'] = '[TAVLA]';
$txt['movetopic_auto_topic'] = '[ÄMNESLÄNK]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Redirect to the moved topic';
$txt['movetopic_expires'] = 'Automatically remove the redirection topic';

$txt['merge_to_topic_id'] = 'ID för målämnet';
$txt['split_topic'] = 'Split';
$txt['merge'] = 'Merge';
$txt['subject_new_topic'] = 'Ämnesrad för det nya ämnet:';
$txt['split_this_post'] = 'Dela endast upp detta inlägg.';
$txt['split_after_and_this_post'] = 'Dela alla inlägg fr.o.m. detta.';
$txt['select_split_posts'] = 'Välj exakt vilka inlägg du vill dela upp.';

$txt['splittopic_notification'] = 'Post a message when the topic is split';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Move the new topic to another board';

$txt['new_topic'] = 'Nytt ämne';
$txt['split_successful'] = 'Ämnet har delats upp i två ämnen utan problem.';
$txt['origin_topic'] = 'Ursprungligt ämne';
$txt['please_select_split'] = 'Välj vilka inlägg du vill skapa ett nytt ämne av.';
$txt['merge_successful'] = 'Ämnena har nu sammanfogats till ett enda.';
$txt['new_merged_topic'] = 'Nyligen sammanfogade ämnen';
$txt['topic_to_merge'] = 'Ämne att sammanfoga med:';
$txt['target_board'] = 'Välj vilken tavla det ska hamna på:';
$txt['target_topic'] = 'Välj vilket ämne det ska hamna i:';
$txt['merge_confirm'] = 'Är du säker på att du vill sammanfoga';
$txt['with'] = 'med';
$txt['merge_desc'] = 'Denna funktion kommer att sammanfoga inläggen i två olika ämnen till ett enda ämne. Inläggen i det nya ämnet kommer att sorteras i datumordning. Det först skrivna inlägget kommer därmed att bli det första inlägget i det nya sammanfogade ämnet.';

$txt['theme_template_error'] = 'Kunde inte ladda mallen \'%1$s\'.';
$txt['theme_language_error'] = 'Kunde inte ladda språkfilen \'%1$s\'.';

$txt['parent_boards'] = 'Sub-boards';

$txt['smtp_no_connect'] = 'Lyckades inte att ansluta till SMTP-servern';
$txt['smtp_port_ssl'] = 'SMTP-porten är fel inställd, det bör vara port 465 för SSL-servrar.';
$txt['smtp_bad_response'] = 'Kunde inte avläsa svarskoden från servern';
$txt['smtp_error'] = 'Ett fel uppstod vid utskick av e-post. Fel: ';
$txt['mail_send_unable'] = 'Kunde inte skicka e-post till \'%1$s\'';

$txt['mlist_search'] = 'Sök efter medlemmar';
$txt['mlist_search_again'] = 'Sök igen'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Sök efter e-postadress';
$txt['mlist_search_group'] = 'Sök efter ställning';
$txt['mlist_search_name'] = 'Sök efter namn';
$txt['mlist_search_website'] = 'Sök efter hemsida';
$txt['mlist_search_results'] = 'Sökresultat för';
$txt['mlist_search_by'] = 'Sök efter %1$s';

$txt['attach_downloaded'] = 'downloaded %1$d times';
$txt['attach_viewed'] = 'viewed %1$d times';

$txt['settings'] = 'Inställningar';
$txt['never'] = 'Aldrig';
$txt['more'] = 'fler';

$txt['hostname'] = 'Servernamn';
$txt['you_are_post_banned'] = 'Beklagar %1$s, du är bannlyst och får inte skriva inlägg och skicka privata meddelanden på detta forum.';
$txt['ban_reason'] = 'Orsak';

$txt['add_poll'] = 'Lägg till omröstning';
$txt['poll_options6'] = 'Du kan bara välja upp till %1$s alternativ.';
$txt['poll_remove'] = 'Ta bort omröstning';
$txt['poll_remove_warn'] = 'Är du säker på att du vill ta bort omröstningen från det här ämnet?';
$txt['poll_results_expire'] = 'Resultaten kommer att visas när omröstningen avslutats';
$txt['poll_expires_on'] = 'Omröstningen avslutas';
$txt['poll_expired_on'] = 'Omröstningen har avslutats';
$txt['poll_change_vote'] = 'Ta bort röst';
$txt['poll_return_vote'] = 'Omröstningstillval';
$txt['poll_cannot_see'] = 'Just nu kan du inte se resultaten i denna omröstning';

$txt['quick_mod_approve'] = 'Godkänn markerade';
$txt['quick_mod_remove'] = 'Radera markerade';
$txt['quick_mod_lock'] = 'Lås/Lås upp markerade';
$txt['quick_mod_sticky'] = 'Pin/Unpin selected';
$txt['quick_mod_move'] = 'Flytta markerade till';
$txt['quick_mod_merge'] = 'Sammanfoga markerade';
$txt['quick_mod_markread'] = 'Markera förkryssade som lästa';
$txt['quick_mod_go'] = 'OK';
$txt['quickmod_confirm'] = 'Vill du verkligen göra detta?';

$txt['spell_check'] = 'Stavningskontroll';

$txt['quick_reply'] = 'Snabbsvar';
$txt['quick_reply_warning'] = 'Warning! This topic is currently locked, only admins and moderators can reply.';
$txt['quick_reply_verification'] = 'Efter att du skickat ditt inlägg kommer du omdirigeras till den vanliga Posta inlägg-sidan för att verifiera ditt inlägg %1$s.';
$txt['quick_reply_verification_guests'] = '(krävs för alla gäster)';
$txt['quick_reply_verification_posts'] = '(krävs för alla användare med mindre än %1$d inlägg)';
$txt['wait_for_approval'] = 'Notera: Detta inlägg kommer inte synas förrän det godkänts av en moderator.';

$txt['notification_enable_board'] = 'Är du säker på att du vill få e-post vid alla nya ämnen på denna tavla?';
$txt['notification_disable_board'] = 'Är du säker på att du inte längre vill få e-post vid nya ämnen på denna tavla?';
$txt['notification_enable_topic'] = 'Är du säker på att du vill få e-post vid svar till detta ämne?';
$txt['notification_disable_topic'] = 'Är du säker på att du inte längre vill få e-post vid svar till detta ämne?';

$txt['report_to_mod'] = 'Report Post';
$txt['issue_warning_post'] = 'Dela ut en varning på grund av detta meddelande';

$txt['like_post'] = 'Like';
$txt['unlike_post'] = 'Unlike';
$txt['likes'] = 'Likes';
$txt['liked_by'] = 'Liked by:';
$txt['liked_you'] = 'You';
$txt['liked_more'] = 'fler';
$txt['likemsg_are_you_sure'] = 'You already liked this message, are you sure you want to remove your like?';

$txt['unread_topics_visit'] = 'Nyliga olästa ämnen';
$txt['unread_topics_visit_none'] = 'No unread topics found since your last visit. <a href="{unread_all_url}" class="linkbutton">Click here to try all unread topics</a>';
$txt['unread_topics_all'] = 'Alla olästa ämnen';
$txt['unread_replies'] = 'Uppdaterade ämnen';

$txt['who_title'] = 'Vilka är online';
$txt['who_and'] = ' och ';
$txt['who_viewing_topic'] = ' tittar på detta ämne.';
$txt['who_viewing_board'] = ' tittar på denna tavla.';
$txt['who_member'] = 'Medlem';

// Current footer strings
$txt['valid_html'] = 'Valid HTML 5';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'gäst';
$txt['guests'] = 'Gäster';
$txt['user'] = 'Användare';
$txt['users'] = 'Användare';
$txt['hidden'] = 'Dolda';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'Dolda';
$txt['buddy'] = 'kompis';
$txt['buddies'] = 'kompisar';
$txt['most_online_ever'] = 'Flest online någonsin';
$txt['most_online_today'] = 'Flest online idag';

$txt['merge_select_target_board'] = 'Ange vilken tavla det sammanfogade ämnet ska hamna i';
$txt['merge_select_poll'] = 'Ange vilken omröstning som det sammanfogade ämnet ska ha';
$txt['merge_topic_list'] = 'Ange vilka ämnen som ska sammanfogas';
$txt['merge_select_subject'] = 'Ange rubrik för det sammanfogade ämnet';
$txt['merge_custom_subject'] = 'Ny rubrik';
$txt['merge_enforce_subject'] = 'Ändra rubrik på alla meddelanden';
$txt['merge_include_notifications'] = 'Inkludera underrättelser?';
$txt['merge_check'] = 'Sammanfoga?';
$txt['merge_no_poll'] = 'Ingen omröstning';

$txt['response_prefix'] = 'SV: ';
$txt['current_icon'] = 'Current icon';
$txt['message_icon'] = 'Inläggsikon';

$txt['smileys_current'] = 'Nuvarande smiley-uppsättning';
$txt['smileys_none'] = 'Inga smileys';
$txt['smileys_forum_board_default'] = 'Standard för tavlan/forumet';

$txt['search_results'] = 'Sökresultat';
$txt['search_no_results'] = 'Beklagar, sökningen gav inga resultat';

$txt['totalTimeLogged2'] = ' dagar, ';
$txt['totalTimeLogged3'] = ' timmar och ';
$txt['totalTimeLogged4'] = ' minuter.';
$txt['totalTimeLogged5'] = 'd ';
$txt['totalTimeLogged6'] = 'tim ';
$txt['totalTimeLogged7'] = 'min';

$txt['approve_thereis'] = 'Det finns'; //Deprecated
$txt['approve_thereare'] = 'Det finns'; //Deprecated
$txt['approve_member'] = 'en medlem'; //Deprecated
$txt['approve_members'] = 'medlemmar'; //Deprecated
$txt['approve_members_waiting'] = 'som väntar på godkännande.'; //Deprecated
$txt['approve_one_member_waiting'] = 'There is <a href="%1$s">one member</a> awaiting approval.';
$txt['approve_many_members_waiting'] = 'There are <a href="%1$s">%2$d members</a> awaiting approval.';

$txt['notifyboard_turnon'] = 'Vill du få e-post när någon startar ett nytt ämne på den här tavlan?';
$txt['notifyboard_turnoff'] = 'Är du säker på att du inte längre vill få underrättelser för nya ämnen på den här tavlan?';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Hitta medlemmar';
$txt['find_username'] = 'Namn, användarnamn eller e-postadress';
$txt['find_buddies'] = 'Visa endast kompisar?';
$txt['find_wildcards'] = 'Tillåtna jokertecken: *, ?';
$txt['find_no_results'] = 'Inga resultat hittades';
$txt['find_results'] = 'Resultat';
$txt['find_close'] = 'Stäng';

$txt['quickmod_delete_selected'] = 'Radera markerade';
$txt['quickmod_split_selected'] = 'Split Selected';

$txt['show_personal_messages_heading'] = 'New messages';
$txt['show_personal_messages'] = 'You have <strong>%1$s</strong> unread personal messages in your inbox.<br /><br /><a href="%2$s">Go to your inbox</a>';

$txt['help_popup'] = 'A little lost? Let me explain:';

$txt['previous_next_back'] = 'previous topic';
$txt['previous_next_forward'] = 'next topic';

$txt['upshrink_description'] = 'Krymp eller utöka forumhuvudet längst upp.';

$txt['mark_unread'] = 'Markera som oläst';

$txt['ssi_not_direct'] = 'Anropa inte SSI.php direkt genom dess adress, du kan istället använda sökvägen (%1$s) eller lägga till ?ssi_function=någonting.';
$txt['ssi_session_broken'] = 'SSI.php lyckades inte att ladda sessionen!  Detta kan orsaka problem med utloggning och andra funktioner - se till att SSI.php verkligen läggs till före *allting annat* i dina skript!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Förhandsgranska inlägg';
$txt['preview_fetch'] = 'Hämtar förhandsgranskning...';
$txt['pm_error_while_submitting'] = 'The following error or errors occurred while sending this personal message:';
$txt['warning_while_submitting'] = 'Something happened, review it here:';
$txt['error_while_submitting'] = 'The message has the following error or errors that must be corrected before continuing:';
$txt['error_old_topic'] = 'Varning: Det har inte skrivits nya inlägg i detta ämne på %1$d dagar.<br />Om du inte är säker på att du faktiskt vill svara i det här ämnet, så bör du överväga att istället starta ett nytt ämne.';

$txt['split_selected_posts'] = 'Valda inlägg';
$txt['split_selected_posts_desc'] = 'Ovanstående inlägg kommer att bilda ett nytt ämne efter uppdelningen.';
$txt['split_reset_selection'] = 'Nollställ val';

$txt['modify_cancel'] = 'Ångra';
$txt['mark_read_short'] = 'Markera som läst';

$txt['hello_member_ndt'] = 'Hej';

$txt['unapproved_posts'] = 'Icke godkända poster (Ämnen: %1$d, Inlägg: %2$d)';

$txt['ajax_in_progress'] = 'Laddar...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = 'Det finns just nu %1$d moderatorsrapporter öppna.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'Click to see the new posts in %1$s';
$txt['verification'] = 'Verifiering';
$txt['visual_verification_hidden'] = 'Please leave this box empty';
$txt['visual_verification_description'] = 'Skriv in bokstäverna som syns på bilden';
$txt['visual_verification_sound'] = 'Lyssna på bokstäverna muntligt';
$txt['visual_verification_request_new'] = 'Begär en ny bild';

// @todo Send email strings - should move?
$txt['send_email'] = 'Send email';
$txt['send_email_disclosed'] = 'Observera att detta kommer visas för mottagaren.';
$txt['send_email_subject'] = 'E-postmeddelandets ämne';

$txt['ignoring_user'] = 'Du ignorerar denna användare.';
$txt['show_ignore_user_post'] = '<em>[Show me the post.]</em>';

$txt['spider'] = 'Sökrobot';
$txt['spiders'] = 'Sökrobotar';
$txt['openid'] = 'OpenID ';

$txt['downloads'] = 'Nedladdningar';
$txt['filesize'] = 'File size';
$txt['subscribe_webslice'] = 'Prenumerera på webbslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Återställ ämne';
$txt['restore_message'] = 'Återställ';
$txt['quick_mod_restore'] = 'Återställ markerade';

// Editor prompt.
$txt['prompt_text_email'] = 'Var god ange e-postadressen.';
$txt['prompt_text_ftp'] = 'Please enter the FTP address.';
$txt['prompt_text_url'] = 'Ange den Internetadress du vill länka till';
$txt['prompt_text_img'] = 'Ange bildens Internetadress';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Radera objekt';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> has blocked %1$s access attempts in the last 7 days.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Teman:';
$txt['debug_subtemplates'] = 'Undermallar:'; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Undermallar:';
$txt['debug_language_files'] = 'Språkfiler:';
$txt['debug_sheets'] = 'Formatmallar:';
$txt['debug_javascript'] = 'Scripts: ';
$txt['debug_files_included'] = 'Inkluderade filer:';
$txt['debug_kb'] = 'kB';
$txt['debug_show'] = 'visa';
$txt['debug_cache_hits'] = 'Cacheträffar:';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s byte';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss för %2$s byte';
$txt['debug_queries_used'] = 'Antal frågor använda:';
$txt['debug_queries_used_and_warnings'] = 'Antal frågor använda: %1$d, %2$d varningar.';
$txt['debug_query_in_line'] = 'i <em>%1$s</em> rad <em>%2$s</em>,';
$txt['debug_query_which_took'] = 'vilket tog %1$s sekunder. ';
$txt['debug_query_which_took_at'] = 'vilket tog %1$s sekunder vid %2$s att verkställa.';
$txt['debug_show_queries'] = '[Visa frågor]';
$txt['debug_hide_queries'] = '[Dölj frågor]';
$txt['debug_tokens'] = 'Tokens: ';
$txt['debug_browser'] = 'Browser ID: ';
$txt['debug_hooks'] = 'Hooks called: ';
$txt['debug_system_type'] = 'System: ';
$txt['debug_server_load'] = 'Server Load: ';
$txt['debug_script_mem_load'] = 'Script Memory Usage: ';
$txt['debug_script_cpu_load'] = 'Script CPU Time (user/system): ';

// Video embedding
$txt['preview_image'] = 'Video Preview Image';
$txt['ctp_video'] = 'Click to play video, double click to load video';
$txt['hide_video'] = 'Show/Hide video';
$txt['youtube'] = 'YouTube video:';
$txt['vimeo'] = 'Vimeo video:';
$txt['dailymotion'] = 'Dailymotion video:';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (click to show/hide)';

$txt['ok_uppercase'] = 'OK';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Warning';

$txt['via'] = 'via';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
