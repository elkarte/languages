<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Hantera tavlor och kategorier';
$txt['order'] = 'Beställning';
$txt['full_name'] = 'Fullständigt namn';
$txt['name_on_display'] = 'Det här är det namn som kommer att visas';
$txt['boards_and_cats_desc'] = 'Edit your categories and boards here. List multiple moderators as <em>&quot;username&quot;, &quot;username&quot;</em>. (these must be usernames and *not* display names)<br />To create a new board, click the Add Board button.<br />To move a board you can drag and drop it to its new location in the list (across cataegories and Child of locations)<br />To create a new board as a child of a current board, select "Child of..." from the Order drop down menu when creating the board.';
$txt['parent_members_only'] = 'Vanliga medlemmar';
$txt['parent_guests_only'] = 'Gäster';
$txt['catConfirm'] = 'Vill du verkligen radera denna kategori?';
$txt['boardConfirm'] = 'Vill du verkligen radera denna tavla?';

$txt['catEdit'] = 'Redigera kategori';
$txt['collapse_enable'] = 'Går att fälla ihop';
$txt['collapse_desc'] = 'Tillåt användare att fälla ihop denna kategori';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'Efter ';
$txt['mboards_order_first'] = 'På första plats';
$txt['mboards_board_error'] = 'Failed to resolve move location.';

$txt['mboards_new_board'] = 'Lägg till tavla';
$txt['mboards_new_cat_name'] = 'Ny kategori';
$txt['mboards_add_cat_button'] = 'Lägg till kategori';
$txt['mboards_new_board_name'] = 'Ny tavla';

$txt['mboards_modify'] = 'ändra';
$txt['mboards_permissions'] = 'rättigheter';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Är du säker på att du vill byta till lokala rättigheter för denna tavla?';

$txt['mboards_delete_cat'] = 'Radera kategori';
$txt['mboards_delete_board'] = 'Radera tavla';

$txt['mboards_delete_cat_contains'] = 'Om du raderar denna kategori, så försvinner också nedan angivna tavlor, inklusive alla ämnen, inlägg och bilagor till varje tavla.';
$txt['mboards_delete_option1'] = 'Radera kategorin och samtliga tavlor inuti.';
$txt['mboards_delete_option2'] = 'Radera kategorin och flytta alla tavlor inuti till';
$txt['mboards_delete_board_contains'] = 'Deleting this board will also move the sub-boards below, including all topics, posts and attachments within each board';
$txt['mboards_delete_board_option1'] = 'Delete board and move sub-boards contained within to category level.';
$txt['mboards_delete_board_option2'] = 'Delete board and move all sub-boards contained within to';
$txt['mboards_delete_what_do'] = 'Välj vad du vill göra med dessa tavlor';
$txt['mboards_delete_confirm'] = 'Bekräfta';
$txt['mboards_delete_cancel'] = 'Ångra';

$txt['mboards_category'] = 'Kategori';
$txt['mboards_description'] = 'Beskrivning';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Tillåtna grupper';
$txt['mboards_groups_desc'] = 'Medlemsgrupper som har tillträde till denna tavla.<br /><em>Obs! Om medlemmen tillhör någon vanlig grupp eller inläggsbaserad grupp, kommer de att ha tillträde till tavlan.</em>';
$txt['mboards_groups_regular_members'] = 'Denna grupp innehåller alla medlemmar som inte har någon tilldelad primär medlemsgrupp.';
$txt['mboards_groups_post_group'] = 'Den här gruppen är en inläggsbaserad grupp';
$txt['mboards_moderators'] = 'Moderatorer';
$txt['mboards_moderators_desc'] = 'Medlemmar som ska ha behörighet som moderatorer på tavlan. Observera att administratörer inte behöver anges här.';
$txt['mboards_count_posts'] = 'Räkna antal inlägg';
$txt['mboards_count_posts_desc'] = 'Gör att nya inlägg och ämnen räknar upp medlemmars inläggsräknare.';
$txt['mboards_unchanged'] = 'Oförändrat';
$txt['mboards_theme'] = 'Tavlans tema';
$txt['mboards_theme_desc'] = 'Detta låter dig ändra utseendet på forumet enbart inuti denna tavla.';
$txt['mboards_theme_default'] = '(forumets standardutseende.)';
$txt['mboards_override_theme'] = 'Åsidosätt medlemmens tema';
$txt['mboards_override_theme_desc'] = 'Använd denna tavlas tema, även om medlemmen inte valt att använda standardutseendet.';

$txt['mboards_redirect'] = 'Omdirigera till en webbadress';
$txt['mboards_redirect_desc'] = 'Aktivera alternativet för att dirigera alla som klickar på den här tavlan till en annan webbadress.';
$txt['mboards_redirect_url'] = 'Adress att omdirigera användare till';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Nollställ räkning av omdirigerade personer';
$txt['mboards_redirect_reset_desc'] = 'Om du väljer det här kommer räkningen av antalet personer som omdirigerats från denna tavla att nollställas. ';
$txt['mboards_current_redirects'] = 'Just nu: %1$s';
$txt['mboards_redirect_disabled'] = 'Notera att tavlan måste vara tom för att detta ska kunna väljas';
$txt['mboards_redirect_disabled_recycle'] = 'Obs: Du kan inte göra Papperskorgstavlan till en omdirigeringstavla';

$txt['mboards_order_before'] = 'Före';
$txt['mboards_order_child_of'] = 'Undertavla till';
$txt['mboards_order_in_category'] = 'I kategori';
$txt['mboards_current_position'] = 'Nuvarande placering';
$txt['no_valid_parent'] = 'Tavlan %1$s har inte en giltig överliggande tavla. Använd funktionen \'sök och reparera\' för att åtgärda detta.';

$txt['mboards_recycle_disabled_delete'] = 'You must select an alternative recycle bin board or disable recycling before you can delete this board.';

$txt['mboards_settings_desc'] = 'Redigera allmänna tavel- och kategoriinställningar.';
$txt['groups_manage_boards'] = 'Medlemsgrupper som har rätt att hantera tavlor och kategorier';
$txt['recycle_enable'] = 'Aktivera återvinning av raderade ämnen';
$txt['recycle_board'] = 'Tavla där raderade ämnen hamnar';
$txt['recycle_board_unselected_notice'] = 'Du har gjort det möjligt för återvinning av ämnen utan att ange en tavla att placera dem i. Denna funktion kommer inte att vara aktiverad innan du anger en tavla att placera raderade ämnen i.';
$txt['countChildPosts'] = 'Räkna inlägg i underliggande tavlor till överliggande tavlors inlägg';
$txt['allow_ignore_boards'] = 'Tillåt tavlor att ignoreras';
$txt['deny_boards_access'] = 'Enable the option to deny board access based on membergroup';
$txt['boardsaccess_option_desc'] = 'For each permission you can choose \'Allow\' (A), \'Ignore\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />If you deny access, any member - (including moderators) - in that group will be denied access.<br />For this reason, you should set deny carefully, only when <strong>necessary</strong>. Ignore, on the other hand, denies unless otherwise granted.';

$txt['mboards_select_destination'] = 'Välj mål för tavla \'<strong>%1$s</strong>\' ';
$txt['mboards_cancel_moving'] = 'Avbryt flyttande';
$txt['mboards_move'] = 'flytta';

$txt['mboards_no_cats'] = 'Just nu finns det inga kategorier eller tavlor.';
