<?php
// Version: 1.1; ManageCalendar

$txt['calendar_desc'] = 'Härifrån kan du ändra alla delar av kalendern.';

// Calendar Settings
$txt['calendar_settings_desc'] = 'Härifrån kan du aktivera kalendern, och ange vilka inställningar som den ska använda.';
$txt['groups_calendar_view'] = 'Medlemsgrupper som får visa kalendern';
$txt['groups_calendar_post'] = 'Medlemsgrupper som får skapa nya kalenderhändelser';
$txt['groups_calendar_edit_own'] = 'Medlemsgrupper som får redigera sina egna händelser';
$txt['groups_calendar_edit_any'] = 'Medlemsgrupper som får redigera samtliga händelser';
$txt['setting_cal_enabled'] = 'Aktivera kalendern';
$txt['setting_cal_daysaslink'] = 'Visa dagar som länkar till \'Ny händelse\'';
$txt['setting_cal_days_for_index'] = 'Max antal dagar i förväg på forumindex';
$txt['setting_cal_showholidays'] = 'Visa högtider';
$txt['setting_cal_showbdays'] = 'Visa födelsedagar';
$txt['setting_cal_showevents'] = 'Visa händelser';
$txt['setting_cal_export'] = 'Allow events to be exported in iCal format';
$txt['setting_cal_show_never'] = 'Aldrig';
$txt['setting_cal_show_cal'] = 'Endast i kalendern';
$txt['setting_cal_show_index'] = 'Endast på forumindex';
$txt['setting_cal_show_all'] = 'Visa på forumindex och i kalendern';
$txt['setting_cal_defaultboard'] = 'Standardtavla att posta händelser i';
$txt['setting_cal_allow_unlinked'] = 'Tillåt händelser som inte länkas till foruminlägg';
$txt['setting_cal_minyear'] = 'Tidigaste tillåtna år';
$txt['setting_cal_maxyear'] = 'Senaste tillåtna år';
$txt['setting_cal_allowspan'] = 'Tillåt händelser att sträcka sig över flera dagar';
$txt['setting_cal_maxspan'] = 'Max antal dagar en händelse kan sträcka sig över';
$txt['setting_cal_showInTopic'] = 'Visa tillhörande kalenderhändelser vid visning av forumämnen';

// Adding/Editing/Viewing Holidays
$txt['manage_holidays_desc'] = 'Härifrån kan du lägga till och ta bort högtider och helgdagar från din forumkalender.';
$txt['current_holidays'] = 'Nuvarande högtider';
$txt['holidays_title'] = 'Högtid';
$txt['holidays_title_label'] = 'Titel';
$txt['holidays_delete_confirm'] = 'Är du säker på att du vill ta bort dessa högtider?';
$txt['holidays_add'] = 'Add new holiday';
$txt['holidays_edit'] = 'Edit existing holiday';
$txt['holidays_button_add'] = 'Lägg till';
$txt['holidays_button_edit'] = 'Redigera';
$txt['holidays_button_remove'] = 'Ta bort';
$txt['holidays_no_entries'] = 'Just nu finns inga helgdagar i databasen.';
$txt['every_year'] = 'Varje år';