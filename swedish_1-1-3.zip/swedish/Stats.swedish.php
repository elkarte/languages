<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Flest online';

$txt['stats_center'] = 'Statistikcenter';
$txt['general_stats'] = 'Allmän statistik';
$txt['top_posters'] = '10 största författarna';
$txt['top_boards'] = '10 största tavlorna';
$txt['forum_history'] = 'Forumhistorik (utifrån forumets allmänna tidszon)';
$txt['stats_new_topics'] = 'Nya ämnen';
$txt['stats_new_posts'] = 'Nya inlägg';
$txt['stats_new_members'] = 'Nya medlemmar';
$txt['page_views'] = 'Sidvisningar';
$txt['top_topics_replies'] = '10 största ämnena (utifrån antal svar)';
$txt['top_topics_views'] = '10 största ämnena (utifrån antal visningar)';
$txt['yearly_summary'] = 'Årlig sammanfattning';
$txt['top_starters'] = 'De medlemmar som startat flest ämnen';
$txt['most_time_online'] = 'De medlemmar som varit online längst tid';

$txt['average_members'] = 'Genomsnittligt antal registreringar per dag';
$txt['average_posts'] = 'Genomsnittligt antal nya inlägg per dag';
$txt['average_topics'] = 'Genomsnittligt antal nya ämnen per dag';
$txt['average_online'] = 'Genomsnittligt antal aktiva medlemmar per dag';
$txt['users_online'] = 'Användare online';
$txt['emails_sent'] = 'Average Emails per day';
$txt['users_online_today'] = 'Online idag';
$txt['num_hits'] = 'Totalt antal sidvisningar';
$txt['average_hits'] = 'Genomsnittligt antal sidvisningar per dag';

$txt['ssi_comment'] = 'kommentar';
$txt['ssi_comments'] = 'kommentarer';
$txt['ssi_write_comment'] = 'Skriv kommentar';
$txt['ssi_no_guests'] = 'Du kan inte ange en tavla som inte tillåter gäster. Vänligen kolla tavlans ID innan du örsöker igen.';
$txt['xml_rss_desc'] = 'Live information from {forum_name}';