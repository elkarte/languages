<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Hantera rättigheter';
$txt['permissions_modify'] = '&auml;ndra';
$txt['permissions_view'] = 'Visa';
$txt['permissions_allowed'] = 'Tillåtet';
$txt['permissions_denied'] = 'Inte tillåtet';
$txt['permission_cannot_edit'] = '<strong>Note:</strong> You cannot edit this permission profile as it is a predefined profile included within the forum software by default. If you wish to change the permissions of this profile you must first create a duplicate profile. You can <a href="%1$s">carry out this task by clicking here</a>.';

$txt['permissions_for_profile'] = 'Rättigheter för profil';
$txt['permissions_boards_desc'] = 'Följande lista visar vilka rättighetsprofiler som har aktiverats på varje tavla på ditt forum. Du kan ändra vilken rättighet som används genom att klicka på &quot;Redigera alla&quot; längst ner på sidan. För att redigera rättighetsprofilen klickar du helt enkelt på profilen.';
$txt['permissions_board_all'] = 'Redigera alla';
$txt['permission_profile'] = 'Rättighetsprofil';
$txt['permission_profile_desc'] = 'Which <a target="_blank" href="%1$s">permission set</a> the board should use.';
$txt['permission_profile_inherit'] = 'Ärv från överliggande tavla';

$txt['permissions_profile'] = 'Profilen';
$txt['permissions_profiles_desc'] = 'Rättighetsprofiler aktiveras för individuella tavlor för att enkelt kunna hantera dina säkerhetsinställningar. Härifrån kan du skapa, redigera och radera rättighetsprofiler.';
$txt['permissions_profiles_change_for_board'] = 'Redigera rättighetsprofil för: &quot;%1$s&quot;';
$txt['permissions_profile_default'] = 'Standard';
$txt['permissions_profile_no_polls'] = 'Inga omröstningar';
$txt['permissions_profile_reply_only'] = 'Endast svara';
$txt['permissions_profile_read_only'] = 'Endast läsa';

$txt['permissions_profile_rename'] = 'Rename all';
$txt['permissions_profile_edit'] = 'Redigera profiler';
$txt['permissions_profile_new'] = 'Ny profil';
$txt['permissions_profile_new_create'] = 'Skapa';
$txt['permissions_profile_name'] = 'Profilnamn';
$txt['permissions_profile_used_by'] = 'Används av';
$txt['permissions_profile_used_by_one'] = '1 tavla';
$txt['permissions_profile_used_by_many'] = '%1$d tavlor';
$txt['permissions_profile_used_by_none'] = 'Inga tavlor';
$txt['permissions_profile_do_edit'] = 'Redigera';
$txt['permissions_profile_do_delete'] = 'Radera';
$txt['permissions_profile_copy_from'] = 'Kopiera rättigheter från';

$txt['permissions_includes_inherited'] = 'Ärvda grupper';
$txt['permissions_includes_inherited_from'] = 'Inherited from: ';

$txt['permissions_all'] = 'alla';
$txt['permissions_none'] = 'inga';
$txt['permissions_set_permissions'] = 'Ställ in rättigheter';

$txt['permissions_advanced_options'] = 'Avancerade alternativ';
$txt['permissions_with_selection'] = 'Med markerade';
$txt['permissions_apply_pre_defined'] = 'Använd förvald rättighetsprofil';
$txt['permissions_select_pre_defined'] = 'Välj en förvald profil';
$txt['permissions_copy_from_board'] = 'Kopiera rättigheter från denna tavla';
$txt['permissions_select_board'] = 'Välj en tavla';
$txt['permissions_like_group'] = 'Ställ in rättigheter som denna grupp';
$txt['permissions_select_membergroup'] = 'Select a member group';
$txt['permissions_add'] = 'Lägg till rättighet';
$txt['permissions_remove'] = 'Ta bort rättighet';
$txt['permissions_deny'] = 'Neka rättighet';
$txt['permissions_select_permission'] = 'Välj en rättighet';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Du kan bara välja en handling för att ändra rättigheter';
$txt['permissions_no_action'] = 'Ingen handling vald';
$txt['permissions_deny_dangerous'] = 'Du har valt att förbjuda en eller flera rättigheter.\\nDetta kan vara farligt, och orsaka oväntade effekter, om du inte sett till att ingen av \\"misstag\\" råkar tillhöra den grupp eller de grupper som du förbjuder rättigheter till.\\n\\nÄr du säker på att du vill fortsätta?';

$txt['permissions_modify_group'] = 'Redigera grupp';
$txt['permissions_general'] = 'Allmänna rättigheter';
$txt['permissions_board'] = 'Globala rättigheter för alla tavlor';
$txt['permissions_board_desc'] = '<strong>Obs</strong>: Om du ändrar dessa tavelrättigheter kommer det att påverka alla tavlor som har tilldelats rättighetsprofilen &quot;Standard&quot;. Tavlor som inte använder profilen &quot;Standard&quot; kommer inte att påverkas av ändringar på denna sida.';
$txt['permissions_commit'] = 'Spara ändringar';
$txt['permissions_on'] = 'på tavla';
$txt['permissions_local_for'] = 'Lokala rättigheter för medlemsgrupp';
$txt['permissions_option_on'] = 'F';
$txt['permissions_option_off'] = 'X';
$txt['permissions_option_deny'] = 'F';
$txt['permissions_option_desc'] = 'For each permission you can pick either \'Allow\' (A), \'Disallow\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />Remember that if you deny a permission, any member - whether moderator or otherwise - that is in that group will be denied that as well.<br />For this reason, you should use deny carefully, only when <strong>necessary</strong>. Disallow, on the other hand, denies unless otherwise granted.';

$txt['permissiongroup_general'] = 'Allmänt';
$txt['permissionname_view_stats'] = 'Visa forumstatistik';
$txt['permissionhelp_view_stats'] = 'Forumstatistiken är en sida som sammanfattar statistik för forumet, som exempelvis antal medlemmar, antal inlägg per dag och topplistor över flera aspekter. Om du lägger till denna rättighet, läggs det till en länk längst ned på forumindexet  (\'[Mer statistik]\').';
$txt['permissionname_view_mlist'] = 'View the member list and groups';
$txt['permissionhelp_view_mlist'] = 'The member list shows all members that have registered on your forum. The list can be sorted and searched. The member list is linked from both the board index and the stats page, by clicking on the number of members. It also applies to the groups page which is a mini memberlist of people in that group.';
$txt['permissionname_who_view'] = 'Visa Vilka är online';
$txt['permissionhelp_who_view'] = 'Vilka är online visar en lista över samtliga medlemmar som är aktiva på forumet, och vad var och en av dessa gör just nu. Denna rättighet fungerar bara om du har aktiverat denna funktion i \'Inställningar och tillval\'. Du kan komma åt \'Vilka är online\' genom att klicka på länken i avdelningen \'Vilka är online\' på forumindex. även om detta inte tillåts, kommer medlemmar ändå att kunna se vilka som är online, bara inte var de är.';
$txt['permissionname_search_posts'] = 'Sök efter inlägg och ämnen';
$txt['permissionhelp_search_posts'] = 'Sökrättigheten gör att användaren tillåts söka efter inlägg i samtliga tavlor som han eller hon har rättigheter att besöka. När denna rättighet aktiveras, kommer en Sök-knapp att läggas till längst upp på forumet.';
$txt['permissionname_karma_edit'] = 'Ändra andra personers karma';
$txt['permissionhelp_karma_edit'] = 'Karma is a feature that shows the popularity of a member. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to cast a vote. This permission has no effect on guests.';
$txt['permissionname_like_posts'] = 'Like other users\' posts';
$txt['permissionhelp_like_posts'] = 'Likes is a feature that shows the popularity of a post. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to like a post or unlike one they previously liked.  This permission has no effect on guests.';
$txt['permissionname_like_posts_stats'] = 'See like posts stats';
$txt['permissionhelp_like_posts_stats'] = 'This will allow users to see stats of posts liking';
$txt['permissionname_disable_censor'] = 'Disable word censor';
$txt['permissionhelp_disable_censor'] = 'Allows members the option to disable the word censor.';

$txt['permissiongroup_pm'] = 'Privata meddelanden';
$txt['permissionname_pm_read'] = 'Läsa privata meddelanden';
$txt['permissionhelp_pm_read'] = 'Denna rättighet medför att användare kan komma åt avdelningen för privata meddelanden, och läsa sina privata meddelanden. Utan denna rättighet kan användare inte skicka privata meddelanden heller.';
$txt['permissionname_pm_send'] = 'Skicka privata meddelanden';
$txt['permissionhelp_pm_send'] = 'Skicka privata meddelanden till andra registrerade medlemmar. Kräver att \'Läs privata meddelanden\' också är påslaget.';
$txt['permissionname_send_email_to_members'] = 'Send emails';
$txt['permissionhelp_send_email_to_members'] = 'Send emails to other registered members.';

$txt['permissiongroup_calendar'] = 'Kalender';
$txt['permissionname_calendar_view'] = 'Visa kalendern';
$txt['permissionhelp_calendar_view'] = 'Kalendern visar alla aktuella födelsedagar, händelser och högtider för varje enskild månad. Denna rättighet gör att användaren kommer åt kalendern. När denna rättighet är aktiverad, kommer en knapp att läggas till längst upp på forumet, och en lista visas längst ner på forumindex med aktuella och kommande födelsedagar, händelser och högtider. Kalendern måste aktiveras från \'Konfiguration - Grundläggande inställningar\'.';
$txt['permissionname_calendar_post'] = 'Skapa händelser i kalendern';
$txt['permissionhelp_calendar_post'] = 'En händelse är ett nytt ämne som länkas till en särskild dag eller flera dagar i följd. Skapa händelser görs från kalendern. Händelser kan endast skapas om användaren har rättigheter att starta nya ämnen.';
$txt['permissionname_calendar_edit'] = 'Ändra händelser i kalendern';
$txt['permissionhelp_calendar_edit'] = 'En händelse är ett nytt ämne som länkas till en särskild dag eller flera dagar i följd. Händelser kan ändras genom att klicka på den röda asterisken (*) som visas intill händelsen i kalendern. För att kunna ändra händelser, måste användaren ifråga ha tillräckliga rättigheter för att kunna redigera det första inlägget i det ämne som händelsen länkar till.';
$txt['permissionname_calendar_edit_own'] = 'Egna händelser';
$txt['permissionname_calendar_edit_any'] = 'Samtliga händelser';

$txt['permissiongroup_maintenance'] = 'Forumadministration';
$txt['permissionname_admin_forum'] = 'Administrera forum och databas';
$txt['permissionhelp_admin_forum'] = 'Denna rättighet gör att användaren kommer åt att:<ul><li>ändra forum-, databas- och temainställningar</li><l
i>hantera paket</li><li>använda underhållsverktyg för forum och databaser</li><li>visa fellogg och moderatorlogg</li></ul> Använd denna rättighet med försiktighet, då det är mycket kraftfullt.';
$txt['permissionname_manage_boards'] = 'Hantera tavlor och kategorier';
$txt['permissionhelp_manage_boards'] = 'Denna rättighet tillåter skapande, redigering och radering av tavlor och kategorier.';
$txt['permissionname_manage_attachments'] = 'Hantera bifogade filer och personliga bilder';
$txt['permissionhelp_manage_attachments'] = 'Denna rättighet öppnar tillgång till bilage-centret, där alla bifogade filer på forumet och alla personliga bilder återfinns och kan tas bort.';
$txt['permissionname_manage_smileys'] = 'Hantera smileys och meddelandeikoner';
$txt['permissionhelp_manage_smileys'] = 'Detta öppnar access till Smileys och smileyuppsättningar. Där kan du lägga till, redigera och ta bort smileys och smiley-uppsättningar.';
$txt['permissionname_edit_news'] = 'Redigera nyheter';
$txt['permissionhelp_edit_news'] = 'The news function allows a random news line to appear on each screen. In order to use the news function, enable it in the forum settings.';
$txt['permissionname_access_mod_center'] = 'Komma åt moderationscentret';
$txt['permissionhelp_access_mod_center'] = 'Med denna rättighet kan alla medlemmar i denna grupp komma åt moderationscentret där de får tillgång till funktioner för lätt moderation. Notera att denna rättighet inte aktiverar några moderatorsprivilegier.';

$txt['permissiongroup_member_admin'] = 'Medlemsadministration';
$txt['permissionname_moderate_forum'] = 'Moderera forummedlemmar';
$txt['permissionhelp_moderate_forum'] = 'Denna rättighet inkluderar alla viktiga medlemshanteringsfunktioner:<ul><li>tillgång till registrering av medlemmar</li><li>tillgång till att visa och radera medlemmar</li><li>utökad profilinformation, inklusive IP-adress och online-status</li><li>aktivera användarkonton</li><li>få underrättelse om godkännanden, och möjlighet att godkänna användarkonton</li><li>immun mot att ignorera privata meddelanden</li><li>andra diverse småfunktioner</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Hantera och tilldela medlemsgrupper';
$txt['permissionhelp_manage_membergroups'] = 'Denna rättighet låter en användare ändra medlemsgrupper och tilldela medlemsgrupp till andra medlemmar.';
$txt['permissionname_manage_permissions'] = 'Hantera rättigheter';
$txt['permissionhelp_manage_permissions'] = 'Denna rättighet låter en användare redigera alla rättigheter för en medlemsgrupp, antingen globalt eller för enskilda tavlor.';
$txt['permissionname_manage_bans'] = 'Hantera bannlysningslista';
$txt['permissionhelp_manage_bans'] = 'This permission allows a user to add or remove user names, IP addresses, hostnames and email addresses to or from a list of banned users. It also allows a user to view and remove log entries of banned users that attempted to login.';
$txt['permissionname_send_mail'] = 'Broadcast to multiple members';
$txt['permissionhelp_send_mail'] = 'Mass mail all forum members or just a few member groups by email or personal message (the latter requires the \'Send Personal Message\' permission).';
$txt['permissionname_issue_warning'] = 'Dela ut varningar till medlemmar';
$txt['permissionhelp_issue_warning'] = 'Dela ut en varning till en medlem och redigera den medlemmens varningsnivå. Kräver att varningssystemet är aktiverat.';

$txt['permissiongroup_profile'] = 'Medlemsprofiler';
$txt['permissionname_profile_view'] = 'Visa profilsammanfattning och statistik';
$txt['permissionhelp_profile_view'] = 'This permission allows users clicking on a user name to see a summary of profile settings, some statistics and all posts of the user.';
$txt['permissionname_profile_view_own'] = 'Ens egen profil';
$txt['permissionname_profile_view_any'] = 'Allas profiler';
$txt['permissionname_profile_identity'] = 'Ändra kontoinställningar';
$txt['permissionhelp_profile_identity'] = 'Account settings are the basic settings of a profile, like password, email address, member group and preferred language.';
$txt['permissionname_profile_identity_own'] = 'Ens egen profil';
$txt['permissionname_profile_identity_any'] = 'Allas profiler';
$txt['permissionname_profile_extra'] = 'Ändra ytterligare profilinställningar';
$txt['permissionhelp_profile_extra'] = 'Ytterligare profilinställningar innebär bl.a. inställningar för personliga bilder, privata meddelanden, temainställningar och underrättelser.';
$txt['permissionname_profile_extra_own'] = 'Ens egen profil';
$txt['permissionname_profile_extra_any'] = 'Allas profiler';
$txt['permissionname_profile_title'] = 'Ändra anpassade titlar';
$txt['permissionhelp_profile_title'] = 'Anpassade titlar visas på ämnessidorna, precis under dennes användarnamn.';
$txt['permissionname_profile_title_own'] = 'Ens egen profil';
$txt['permissionname_profile_title_any'] = 'Allas profiler';
$txt['permissionname_profile_remove'] = 'Radera konto';
$txt['permissionhelp_profile_remove'] = 'Denna rättighet tillåter en användare att radera sitt eget konto, när det är ställt på \'Ens eget konto\'.';
$txt['permissionname_profile_remove_own'] = 'Ens eget konto';
$txt['permissionname_profile_remove_any'] = 'Allas konton';
$txt['permissionname_profile_set_avatar'] = 'Select an avatar';
$txt['permissionhelp_profile_set_avatar'] = 'If enabled this will allow a user to select an avatar.';

$txt['permissiongroup_general_board'] = 'Allmänt';
$txt['permissionname_moderate_board'] = 'Moderera tavla';
$txt['permissionhelp_moderate_board'] = '\'Moderera tavla\' lägger till några små rättigheter, för att göra en moderator till en riktig moderator. Det innefattar bl.a. möjlighet att svara på låsta ämnen, ändra tiden när en omröstning avslutas och att visa omröstningsresultat.';

$txt['permissiongroup_topic'] = 'Visa inlägg';
$txt['permissionname_post_new'] = 'Skapa nya ämnen';
$txt['permissionhelp_post_new'] = 'Denna rättighet låter användare skapa nya ämnen. It tillåter inte att skriva svar till ämnen.';
$txt['permissionname_merge_any'] = 'Sammanfoga ämnen';
$txt['permissionhelp_merge_any'] = 'Merge two or more topics into one. The order of messages within the merged topic will be based on the time the messages were created. A user can only merge topics on those boards a user is allowed to merge. In order to merge multiple topics at once, a user has to enable quick moderation in their profile settings.';
$txt['permissionname_split_any'] = 'Dela upp ämnen';
$txt['permissionhelp_split_any'] = 'Dela upp ett ämne till flera mindre ämnen.';
$txt['permissionname_send_topic'] = 'Skicka ämne till vän';
$txt['permissionhelp_send_topic'] = 'Denna rättighet låter användare e-posta ämnen till vänner eller bekanta, genom att ange deras e-postadress och eventuellt ett extra meddelande till personen ifråga.';
$txt['permissionname_make_sticky'] = 'Pin topics';
$txt['permissionhelp_make_sticky'] = 'Pinned topics are topics that always remain on top of a board. They can be useful for announcements or other important messages.';
$txt['permissionname_move'] = 'Move topics';
$txt['permissionhelp_move'] = 'Flytta ett ämne från en tavla till en annan. Användare kan bara flytta ämnen till tavlor som de har behörighet att besöka.';
$txt['permissionname_move_own'] = 'Eget ämne';
$txt['permissionname_move_any'] = 'Alla ämnen';
$txt['permissionname_lock'] = 'Lås ämnen';
$txt['permissionhelp_lock'] = 'This permission allows a user to lock a topic. This can be done in order to make sure no one can reply to a topic. Only users with a \'Moderate board\' permission can still post in locked topics.';
$txt['permissionname_lock_own'] = 'Eget ämne';
$txt['permissionname_lock_any'] = 'Alla ämnen';
$txt['permissionname_remove'] = 'Radera ämnen';
$txt['permissionhelp_remove'] = 'Radera ämnen som helhet. Observera att detta rättighet inte tillåter användare att radera enskilda inlägg i ett ämne!';
$txt['permissionname_remove_own'] = 'Eget ämne';
$txt['permissionname_remove_any'] = 'Alla ämnen';
$txt['permissionname_post_reply'] = 'Skriva svar till ämnen';
$txt['permissionhelp_post_reply'] = 'Denna rättighet låter användare svara på befintliga ämnen.';
$txt['permissionname_post_reply_own'] = 'Eget ämne';
$txt['permissionname_post_reply_any'] = 'Alla ämnen';
$txt['permissionname_modify_replies'] = 'Redigera svar till egna ämnen';
$txt['permissionhelp_modify_replies'] = 'Med denna rättighet kan användare som startat ett ämne redigera samtliga svar i det ämnet.';
$txt['permissionname_delete_replies'] = 'Radera svar till egna ämnen';
$txt['permissionhelp_delete_replies'] = 'Med denna rättighet kan användare som startat ett ämne radera samtliga svar till det ämnet.';
$txt['permissionname_announce_topic'] = 'Tillkännage ämne';
$txt['permissionhelp_announce_topic'] = 'This allows a user to send an announcement email about a topic to all members or to a few member groups.';

$txt['permissionname_approve_emails'] = 'Moderate Post by Email Failures';
$txt['permissionhelp_approve_emails'] = 'Allow moderators to access the Post by Email failure log to perform actions including approve, delete, view and bounce.  Note, since the system may not always know what board a post goes to, this permission should be only be given to members with full board access';
$txt['permissionname_postby_email'] = 'Post by Email';
$txt['permissionhelp_postby_email'] = 'This permission allows users to start new topics as well as reply to topic and PM notifications by email.';

$txt['permissiongroup_post'] = 'Inlägg';
$txt['permissionname_delete'] = 'Radera inlägg';
$txt['permissionhelp_delete'] = 'Ta bort inlägg. Detta tillåter inte användare att ta bort det första inlägget i ett ämne.';
$txt['permissionname_delete_own'] = 'Egna inlägg';
$txt['permissionname_delete_any'] = 'Alla inlägg';
$txt['permissionname_modify'] = 'Redigera inlägg';
$txt['permissionhelp_modify'] = 'Ändra befintliga inlägg';
$txt['permissionname_modify_own'] = 'Egna inlägg';
$txt['permissionname_modify_any'] = 'Alla inlägg';
$txt['permissionname_report_any'] = 'Anmäla inlägg till moderatorerna';
$txt['permissionhelp_report_any'] = 'Denna rättighet lägger till en länk till varje inlägg, som låter användaren enkelt anmäla inlägget (om det är olämpligt) till en moderator. Vid anmälan kommer samtliga moderatorer på den aktuella tavlan att få ett e-post-meddelande med en länk till det anmälda inlägget och en beskrivning över vad problemet är (som anmälaren skrivit).';

$txt['permissiongroup_poll'] = 'Omröstningar';
$txt['permissionname_poll_view'] = 'Visa omröstningar';
$txt['permissionhelp_poll_view'] = 'Denna rättighet låter användare se omröstningar. Utan denna rätt kommer användaren bara att se själva ämnet.';
$txt['permissionname_poll_vote'] = 'Rösta i omröstningar';
$txt['permissionhelp_poll_vote'] = 'Denna rättighet låter registrerade användare rösta i befintliga omröstningar. Det gäller inte för oregistrerade gäster.';
$txt['permissionname_poll_post'] = 'Skapa omröstningar';
$txt['permissionhelp_poll_post'] = 'Denna rättighet låter användare starta nya omröstningar.';
$txt['permissionname_poll_add'] = 'Lägga till omröstningar till befintliga ämnen';
$txt['permissionhelp_poll_add'] = 'Detta tillåter användare att lägga till en omröstning i efterhand till ett befintligt ämne. Denna rättighet kräver tillräcklig behörighet för att kunna redigera det första inlägget i ett ämne.';
$txt['permissionname_poll_add_own'] = 'Egna ämnen';
$txt['permissionname_poll_add_any'] = 'Alla ämnen';
$txt['permissionname_poll_edit'] = 'Ändra i omröstningar';
$txt['permissionhelp_poll_edit'] = 'Denna rättighet låter användare ändra valmöjligheterna i en omröstning, samt nollställa resultaten. För att kunna ändra maximalt antal röster och tiden när an omröstning stängs måste användaren ha rättigheten \'Moderera tavla\'.';
$txt['permissionname_poll_edit_own'] = 'Egna omröstningar';
$txt['permissionname_poll_edit_any'] = 'Alla omröstningar';
$txt['permissionname_poll_lock'] = 'Låsa omröstningar';
$txt['permissionhelp_poll_lock'] = 'Att låsa omröstningar förhindrar fler personer från att rösta i omröstningen, utan att påverka själva ämnet i sig.';
$txt['permissionname_poll_lock_own'] = 'Egna omröstningar';
$txt['permissionname_poll_lock_any'] = 'Alla omröstningar';
$txt['permissionname_poll_remove'] = 'Radera omröstningar';
$txt['permissionhelp_poll_remove'] = 'Denna rättighet låter användare ta bort omröstningar från ett ämne.';
$txt['permissionname_poll_remove_own'] = 'Egna omröstningar';
$txt['permissionname_poll_remove_any'] = 'Alla omröstningar';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Save drafts of new posts';
$txt['permissionname_simple_post_draft'] = 'Save drafts of new posts';
$txt['permissionhelp_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionhelp_simple_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionname_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionname_simple_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionhelp_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionname_simple_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionhelp_pm_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid losing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionname_simple_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionhelp_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';
$txt['permissionhelp_simple_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';

$txt['permissiongroup_approval'] = 'Inläggsmoderering';
$txt['permissionname_approve_posts'] = 'Godkänn inlägg som väntar på godkännande';
$txt['permissionhelp_approve_posts'] = 'Denna rättighet låter användaren godkänna alla ej godkända inlägg på en tavla.';
$txt['permissionname_post_unapproved_replies'] = 'Posta ej godkända svar';
$txt['permissionhelp_post_unapproved_replies'] = 'Denna rättighet låter användaren skriva svar till ämnen, som inte syns innan det har godkänts av en moderator.';
$txt['permissionname_post_unapproved_replies_own'] = 'Eget ämne';
$txt['permissionname_post_unapproved_replies_any'] = 'Alla ämnen';
$txt['permissionname_post_unapproved_topics'] = 'Posta ej godkända ämnen';
$txt['permissionhelp_post_unapproved_topics'] = 'Denna rättighet gör att nya ämnen måste godkännas innan de visas för allmänheten.';
$txt['permissionname_post_unapproved_attachments'] = 'Bifoga ej godkända filer';
$txt['permissionhelp_post_unapproved_attachments'] = 'Denna rättighet låter användare bifoga filer till sina inlägg. Filerna syns inte för andra användare förrän de har godkänts av en moderator.';

$txt['permissiongroup_notification'] = 'Underrättelser och e-post';
$txt['permissionname_mark_any_notify'] = 'Begära underrättelser till ämnen';
$txt['permissionhelp_mark_any_notify'] = 'Denna funktion låter användare välja att få e-post när personer svarar på ämnen som de prenumererar på.';
$txt['permissionname_mark_notify'] = 'Begära underrättelser till nya ämnen';
$txt['permissionhelp_mark_notify'] = 'Denna funktion låter användare välja att få e-post varje gång som nya ämnen skapas på tavlor som de prenumererar på.';

$txt['permissiongroup_attachment'] = 'Visa bifogade filer.';
$txt['permissionname_view_attachments'] = 'Visa bifogade filer';
$txt['permissionhelp_view_attachments'] = 'Bifogade filer är filer som laddats upp och bifogats till inlägg. Denna funktion kan aktiveras och ställas in i \'Bifogade filer och personliga bilder\'. Då bifogade filer aldrig anropas direkt, så går det bra att förhindra folk som inte har denna rättighet att ladda hem filerna.';
$txt['permissionname_post_attachment'] = 'Bifoga filer till inlägg';
$txt['permissionhelp_post_attachment'] = 'För att kunna bifoga filer till inlägg som skrivs. Ett inlägg kan innehålla flera bifogade filer.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Rättighetsinställningar';
$txt['groups_manage_permissions'] = 'Member groups allowed to manage permissions';
$txt['permission_enable_deny'] = 'Aktivera möjligheten att förbjuda rättigheter';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Att stänga av detta alternativ kommer att ändra alla \\\'Förbjud\\\'-rättigheter till \\\'Neka\\\'.';
$txt['permission_by_board_desc'] = 'Here you can set which permission profile a board uses. You can create new permission profiles from the &quot;Edit Profiles&quot; menu.';
$txt['permission_settings_desc'] = 'Här kan du ange vilka som har rättigheter att ändra rättigheter, samt hur sofistikerat rättighetssystemet ska vara.';
$txt['permission_enable_postgroups'] = 'Aktivera rättigheter för medlemsgrupper baserat på antal inlägg';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Att inaktivera denna inställning kommer att ta bort alla rättigheter som finns angivet för medlemsgrupper baserat på antal inlägg.';

$txt['permissions_post_moderation_desc'] = 'From this page you can easily change which groups have their posts moderated for a particular permission profile.';
$txt['permissions_post_moderation_deny_note'] = 'Observera att när du har avancerade rättigheter aktiverade kan du inte &quot;Förbjuda&quot; rättigheter från denna sida. Redigera rättigheterna direkt om du vill förbjuda en rättighet.';
$txt['permissions_post_moderation_select'] = 'Välj profil';
$txt['permissions_post_moderation_new_topics'] = 'Nya ämnen';
$txt['permissions_post_moderation_replies_own'] = 'Egna svar';
$txt['permissions_post_moderation_replies_any'] = 'Alla svar';
$txt['permissions_post_moderation_attachments'] = 'Visa bifogade filer.';
$txt['permissions_post_moderation_legend'] = 'Betydelser';
$txt['permissions_post_moderation_allow'] = 'Kan skapa';
$txt['permissions_post_moderation_moderate'] = 'Kan skapa men kräver godkännande';
$txt['permissions_post_moderation_disallow'] = 'Kan inte skapa';
$txt['permissions_post_moderation_group'] = 'Grupp';

$txt['auto_approve_topics'] = 'Post new topics without requiring approval';
$txt['auto_approve_replies'] = 'Post replies to topics without requiring approval';
$txt['auto_approve_attachments'] = 'Post attachments without requiring approval';
