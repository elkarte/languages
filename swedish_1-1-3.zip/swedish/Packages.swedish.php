<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Fortsätt';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Visa filer i paketet';
$txt['files_archive'] = 'Filer i arkiv';
$txt['package_browse'] = 'Bläddra';
$txt['add_server'] = 'Lägg till server';
$txt['server_name'] = 'Servernamn';
$txt['serverurl'] = 'Adress';
$txt['no_packages'] = 'Inga tillgängliga paket än.';
$txt['download'] = 'Ladda hem';
$txt['download_success'] = 'Paketet har laddats hem utan problem';
$txt['package_downloaded_successfully'] = 'Paketet har laddats hem utan problem';
$txt['package_manager'] = 'Pakethanterare';
$txt['install_mod'] = 'Install Add-on';
$txt['uninstall_mod'] = 'Uninstall Add-on';
$txt['no_adds_installed'] = 'No addons currently installed';
$txt['uninstall'] = 'Avinstallera';
$txt['delete_list'] = 'Delete Add-on List';
$txt['package_delete_list_warning'] = 'Are you sure you wish to clear the installed addons list?';

$txt['package_manager_desc'] = 'From this easy to use interface, you can download and install addons for use on your forum.';
$txt['installed_packages_desc'] = 'Du kan använda gränssnittet nedan för att visa de paket som för närvarande är installerade på ditt forum, samt ta bort de du inte längre behöver.';
$txt['download_packages_desc'] = 'From this section you can add or remove package servers, browse for packages, or download new packages from servers.';
$txt['package_servers_desc'] = 'From this easy to use interface, you can manage your package servers and download addon archives on your forum.';
$txt['upload_packages_desc'] = 'From this section you can upload a package file from your local computer directly to the forum.';

$txt['upload_new_package'] = 'Upload new package';
$txt['view_and_remove'] = 'View and remove installed packages';
$txt['modification_package'] = 'Add-on packages';
$txt['avatar_package'] = 'Avatar packages';
$txt['language_package'] = 'Language packages';
$txt['unknown_package'] = 'Other packages';
$txt['smiley_package'] = 'Smiley packages';
$txt['use_avatars'] = 'Använd personliga bilder';
$txt['add_languages'] = 'Lägg till språk';
$txt['list_files'] = 'Visa filer';
$txt['package_type'] = 'Pakettyp';
$txt['extracting'] = 'Packar upp';
$txt['avatars_extracted'] = 'The avatars have been installed, you should now be able to use them.';
$txt['language_extracted'] = 'The language pack has been installed, you can now enable its use in the language settings area of your admin control panel.';

$txt['mod_name'] = 'Add-on Name';
$txt['mod_version'] = 'Version';
$txt['mod_author'] = 'Upphovsman';
$txt['author_website'] = 'Upphovsmannens hemsida';
$txt['package_no_description'] = 'No description given';
$txt['package_description'] = 'Beskrivning';
$txt['file_location'] = 'Ladda hem';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'No source edits';
$txt['mod_date'] = 'Last updated';
$txt['mod_section_count'] = 'Browse the (%1d) addons in this section';

// Package Server strings
$txt['package_current'] = '(%s <em>You have the Current version %s</em>)';
$txt['package_update'] = '(%s <em>An update for your %s version is available</em>)';
$txt['package_installed'] = 'installed';
$txt['package_downloaded'] = 'nedladdat';

$txt['package_installed_key'] = 'Installed addons:';
$txt['package_installed_current'] = 'aktuell version';
$txt['package_installed_old'] = 'äldre version';
$txt['package_installed_warning1'] = 'This package is already installed, and no upgrade was found.';
$txt['package_installed_warning2'] = 'Du bör avinstallera den äldre versionen först för att undvika eventuella problem, eller fråga upphovsmannen av modifieringen efter en uppgradering från din äldre version.';
$txt['package_installed_warning3'] = 'Kom ihåg att alltid göra regelbundna säkerhetskopior av källfilerna och databasen innan du installerar paket, i synnerhet vid beta-versioner.';
$txt['package_installed_extract'] = 'Packar upp paket';
$txt['package_installed_done'] = 'Paketet har installerats utan problem. Du bör nu kunna se ändringarna och använda de funktioner som ändrats eller kommit till, eller inte längre använda de funktioner som tagits bort.';
$txt['package_installed_redirecting'] = 'Vidarebefordrar...';
$txt['package_installed_redirect_go_now'] = 'Vidarebefordra nu';
$txt['package_installed_redirect_cancel'] = 'Tillbaka till pakethanteraren';

$txt['package_upgrade'] = 'Uppgradera';
$txt['package_uninstall_readme'] = 'Avinstallera readme-filen';
$txt['package_install_readme'] = 'Hjälpfil för installation';
$txt['package_install_license'] = 'License';
$txt['package_install_type'] = 'Typ';
$txt['package_install_action'] = 'Aktivitet';
$txt['package_install_desc'] = 'Beskrivning';
$txt['install_actions'] = 'Installera åtgärder';
$txt['perform_actions'] = 'This will perform the following actions:';
$txt['corrupt_compatible'] = 'The package you are trying to download or install is either corrupt or not compatible with this version of the software.';
$txt['package_create'] = 'Skapa';
$txt['package_move'] = 'Flytta';
$txt['package_delete'] = 'Radera';
$txt['package_extract'] = 'Packa upp';
$txt['package_file'] = 'Fil';
$txt['package_tree'] = 'Träd';
$txt['execute_modification'] = 'Utför modifiering';
$txt['execute_code'] = 'Utför kod';
$txt['execute_database_changes'] = 'Execute file';
$txt['execute_hook_add'] = 'Add Hook';
$txt['execute_hook_remove'] = 'Remove Hook';
$txt['execute_hook_action'] = 'Adapting hook %1$s';
$txt['package_requires'] = 'Requires Modification';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Add Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'Installationshändelser för';
$txt['package_will_fail_title'] = 'Error in package %1$s';
$txt['package_will_fail_warning'] = 'At least one error was encountered during a test %1$s of this package.<br />It is <strong>strongly</strong> recommended that you do not continue with %1$s unless you know what you are doing, and have made a backup very recently.<br /><br />This error may be caused by a conflict between the package you\'re trying to install and another package you have already installed, an error in the package, a package which requires another package that you have not installed yet, or a package designed for another version of the software.';
$txt['package_will_fail_unknown_action'] = 'The package is trying to perform an unknown action: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Are you sure you wish to continue installing this addon, even though it will not install successfully?';
$txt['package_will_fail_popup_uninstall'] = 'Are you sure you wish to continue uninstalling this addon, even though it will not uninstall successfully?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'removal';
$txt['package_install_now'] = 'Install now';
$txt['package_uninstall_now'] = 'Uninstall now';
$txt['package_other_themes'] = 'Install in other themes';
$txt['package_other_themes_uninstall'] = 'UnInstall in other themes';
$txt['package_other_themes_desc'] = 'To use this addon in themes other than the default, the package manager needs to make additional changes to the other themes. If you\'d like to install this addon in the other themes, please select these themes below.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Minst ett fel inträffade under en testinstallation av det här temat. Är du säker på att du vill genomföra installationen?';

$txt['package_bytes'] = 'bytes';

$txt['package_action_missing'] = '<strong class="error">Filen hittades inte</strong>';
$txt['package_action_error'] = '<strong class="error">Tolkningsfel</strong>';
$txt['package_action_failure'] = '<strong class="error">Test misslyckat</strong>';
$txt['package_action_success'] = '<strong>Test avslutat utan problem</strong>';
$txt['package_action_skipping'] = '<strong>Hoppar över fil</strong>';

$txt['package_uninstall_actions'] = 'Avinstallera åtgärder';
$txt['package_uninstall_done'] = 'The package has been successfully uninstalled.';
$txt['package_uninstall_cannot'] = 'This package cannot be uninstalled, because there is no uninstaller.<br /><br />Please contact the addon author for more information.';

$txt['package_install_options'] = 'Installationsalternativ';
$txt['package_install_options_desc'] = 'Set various options for how the package manager installs addons, including backups and ftp access';
$txt['package_install_options_ftp_why'] = 'Att använda pakethanterarens FTP-stöd är det enklaste sättet att undvika att manuellt behöva göra alla nödvändiga filer skrivbara för att pakethanteraren ska fungera.<br />Här kan du ange standardvärden för vissa alternativ.';
$txt['package_install_options_ftp_server'] = 'FTP-server';
$txt['package_install_options_ftp_port'] = 'Port';
$txt['package_install_options_ftp_user'] = 'Användarnamn';
$txt['package_install_options_make_backups'] = 'Säkerhetskopiera ändrade filer med ett tilde-tecken (~) i slutet av filnamnen.';
$txt['package_install_options_make_full_backups'] = 'Create an entire backup (excluding smileys, avatars and attachments) of the ElkArte install.';

$txt['package_ftp_necessary'] = 'FTP-information som krävs';
$txt['package_ftp_why'] = 'Some of the files the package manager needs to modify are not writable.  This needs to be changed by logging into FTP and using it to chmod or create the files and directories.  Your FTP information may be temporarily cached for proper operation of the package manager. Note you can also do this manually using an FTP client - <a href="#" onclick="%1$s">to view a list of the affected files please click here</a>.';
$txt['package_ftp_why_file_list'] = 'Följande filer måste göras skrivbara för att fortsätta installationen:';
$txt['package_ftp_why_download'] = 'In order to download packages, the packages directory, and any files in it, must be writable.  Currently the system does not have the needed permissions to write to this directory.  The package manager can use your FTP information to attempt to fix this problem.';
$txt['package_ftp_server'] = 'FTP-server';
$txt['package_ftp_port'] = 'Port';
$txt['package_ftp_username'] = 'Användarnamn';
$txt['package_ftp_password'] = 'Lösenord';
$txt['package_ftp_path'] = 'Local path to ElkArte';
$txt['package_ftp_test'] = 'Test';
$txt['package_ftp_test_connection'] = 'Testa anslutning';
$txt['package_ftp_test_success'] = 'FTP-anslutningen har upprättats.';
$txt['package_ftp_test_failed'] = 'Kunde inte kontakta servern';
$txt['package_ftp_bad_server'] = 'Kunde inte kontakta servern';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Paketet du håller på att radera är för närvarande installerat! Om du tar bort paketet, kommer du inte att kunna avinstallera det senare.\\n\\n&Är du säker på att du vill göra detta?';

$txt['package_examine_file'] = 'Visa fil i paket';
$txt['package_file_contents'] = 'Innehållet i filen';

$txt['package_upload_title'] = 'Ladda upp paket';
$txt['package_upload_select'] = 'Paket att ladda upp';
$txt['package_upload'] = 'Ladda upp';
$txt['package_uploaded_success'] = 'Paketuppladdning slutförd';
$txt['package_uploaded_successfully'] = 'Uppladdningen av paketet slutfördes utan problem';

$txt['package_modification_malformed'] = 'Malformed or invalid addon file.';
$txt['package_modification_missing'] = 'Filen kunde inte hittas.';
$txt['package_no_zlib'] = 'Beklagar, din PHP-konfiguration har inte stöd för <strong>zlib</strong>. Utan denna modul, fungerar inte pakethanteraren. Var vänlig kontakta ditt webbhotell angående detta.';

$txt['package_cleanperms_title'] = 'Städning av rättigheter';
$txt['package_cleanperms_desc'] = 'Detta gränssnitt låter dig nollställa rättigheter för filer som används under installationen, för att öka säkerheten och lösa eventuella rättighetsproblem som du kanske råkar ut för vid installation av paket.';
$txt['package_cleanperms_type'] = 'Ändra alla filrättigheter på forumet, så att';
$txt['package_cleanperms_standard'] = 'Bara standardfilerna är skrivbara.';
$txt['package_cleanperms_free'] = 'Samtliga filer är skrivbara.';
$txt['package_cleanperms_restrictive'] = 'Bara de allra nödvändigaste filerna är skrivbara.';
$txt['package_cleanperms_go'] = 'Ändra filrättigheter';

$txt['package_download_by_url'] = 'Ladda hem paket från en webbadress';
$txt['package_download_filename'] = 'Filens namn';
$txt['package_download_filename_info'] = 'Frivilligt värde. Bör användas när webbadressen inte slutar med filnamnet. Exempelvis: index.php?mod=5';

$txt['package_db_uninstall'] = 'Remove all data associated with this addon.';
$txt['package_db_uninstall_details'] = 'Detaljer';
$txt['package_db_uninstall_actions'] = 'Checking this option will result in the following actions';
$txt['package_db_remove_table'] = 'Ta bort tabellen &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Ta bort kolumnen &quot;%1$s&quot; från &quot;%2$s&quot;';
$txt['package_db_remove_index'] = 'Ta bort index &quot;%1$s&quot; från &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Install Emulating:';
$txt['package_emulate_uninstall'] = 'Uninstall Emulating:';

// Operations.
$txt['operation_find'] = 'Hitta';
$txt['operation_replace'] = 'Ersätt';
$txt['operation_after'] = 'Lägg till efter';
$txt['operation_before'] = 'Lägg till före';
$txt['operation_title'] = 'Operationer';
$txt['operation_ignore'] = 'Ignorera fel';
$txt['operation_invalid'] = 'Operationen du valde är inkorrekt.';

$txt['package_file_perms_desc'] = 'Du kan använda denna sektion för att förhandsgranska skrivbarhetsstatusen av kritiska filer och mappar inom din forumkatalog. Observera att detta endast gäller viktigare forumkataloger och filer - använd en FTP-klient för fler alternativ.';
$txt['package_file_perms_name'] = 'File/Directory Name';
$txt['package_file_perms_status'] = 'Nuvarande status';
$txt['package_file_perms_new_status'] = 'Ny status';
$txt['package_file_perms_status_read'] = 'Läs';
$txt['package_file_perms_status_write'] = 'Skriv';
$txt['package_file_perms_status_execute'] = 'Utför';
$txt['package_file_perms_status_custom'] = 'Anpassad';
$txt['package_file_perms_status_no_change'] = 'Ingen ändring';
$txt['package_file_perms_writable'] = 'Skrivbar';
$txt['package_file_perms_not_writable'] = 'Ej skrivbar';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Fler filer';

$txt['package_file_perms_change'] = 'Ändra filrättigheter';
$txt['package_file_perms_predefined'] = 'Använd fördefinierade rättighetsprofiler';
$txt['package_file_perms_predefined_note'] = 'Note that this only applies the predefined profile to key directories and files.';
$txt['package_file_perms_apply'] = 'Tillämpa individuell filrättighet enligt vald inställning ovan.';
$txt['package_file_perms_custom'] = 'Om skräddarsydd har blivit valt, använd CHMOD-värde ';
$txt['package_file_perms_pre_restricted'] = 'Begränsad - Minimal uppsättning filer skrivbara';
$txt['package_file_perms_pre_standard'] = 'Standard - Vanliga nyckelfiler skrivbara';
$txt['package_file_perms_pre_free'] = 'Fritt - Alla filer skrivbara';
$txt['package_file_perms_ftp_details'] = 'På de flesta servrar är det möjligt att ändra filrättigheter med användandet av FTP. Vänligen ange dina FTP-uppgifter nedan.';
$txt['package_file_perms_ftp_retain'] = 'Note, the system will only retain the password information temporarily to aid operation of the package manager.';
$txt['package_file_perms_go'] = 'Gör ändringar';

$txt['package_file_perms_applying'] = 'Tillämpa ändringar';
$txt['package_file_perms_items_done'] = '%1$d av %2$d föremål har slutförts';
$txt['package_file_perms_skipping_ftp'] = '<strong>Varning:</strong>Misslyckades att koppla upp mot FTP server och försöker ändra rättigheter utan. Detta kommer <em>sannolikt</em> att misslyckas - vänligen se igenom resultaten då det är slutfört och försök igen med korrekta FTP detaljer om nödvändigt.';

$txt['package_file_perms_dirs_done'] = '%1$d av %2$d mappar har slutförts';
$txt['package_file_perms_files_done'] = '%1$d av %2$d filer har slutförts i den nuvarande mappen.';

$txt['chmod_value_invalid'] = 'Du har försökt att ange ett inkorrekt chmod-värde (rättighetsvärde). Chmod måste vara mellan 0444 och 0777';

$txt['package_restore_permissions'] = 'Restore file permissions';
$txt['package_restore_permissions_desc'] = 'The following file permissions were changed in order to install the selected package(s). You can return these files back to their original status by clicking &quot;Restore&quot; below.';
$txt['package_restore_permissions_restore'] = 'Återställ';
$txt['package_restore_permissions_filename'] = 'Filnamn';
$txt['package_restore_permissions_orig_status'] = 'Ursprunglig status';
$txt['package_restore_permissions_cur_status'] = 'Nuvarande status';
$txt['package_restore_permissions_result'] = 'Åtgärd';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - var %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Hoppades över</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Success</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Misslyckades</span>  ';
$txt['package_restore_permissions_action_done'] = 'An attempt to restore the selected files back to their original permissions has been completed, the results can be seen below. If a change failed, or for a more detailed view of file permissions, please see the <a href="%1$s">File Permissions</a> section.';

$txt['package_file_perms_warning'] = 'Obs!';
$txt['package_file_perms_warning_desc'] = '
	Be careful when changing file permissions from this section - incorrect permissions can adversely affect the operation of your forum!<br />
	On some server configurations selecting the wrong permissions may stop the forum from operating.<br />
	Certain directories such as <em>attachments</em> need to be writable to use that functionality.<br />
	This functionality is mainly applicable on non-Windows based servers - it will not work as expected on Windows in regards to permission flags.<br />
	Before proceeding make sure you have an FTP client installed in case you do make an error and need to FTP into the server to remedy it.';

$txt['package_confirm_view_package_content'] = 'Är du säker på att du vill visa paketinnehållet från den här platsen:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Fortsätt';
$txt['package_confirm_go_back'] = 'Gå tillbaka';

$txt['package_readme_default'] = 'Standard';
$txt['package_available_readme_language'] = 'Tillgängliga readme-språk:';
$txt['package_license_default'] = 'Standard';
$txt['package_available_license_language'] = 'Available License Languages:';