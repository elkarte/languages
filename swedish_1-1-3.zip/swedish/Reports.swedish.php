<?php
// Version: 1.1; Reports

$txt['generate_reports_desc'] = 'I denna avdelning kan du framställa ett antal rapporter, som kan hjälpa dig vid administration av forumet. Följ bara instruktionerna nedan för att välja vad du vill g&ouml;ra.';
$txt['generate_reports_continue'] = 'Fortsätt';
$txt['generate_reports_type'] = 'Välj typ av rapport';
$txt['gr_type_boards'] = 'Tavlor';
$txt['gr_type_desc_boards'] = 'Rapporter som visar aktuella inställningar och åtkomstnivåer för alla tavlor på ditt forum.';
$txt['gr_type_board_perms'] = 'Tavelrättigheter';
$txt['gr_type_desc_board_perms'] = 'Framställ rapport som visar alla rättigheter som varje enskild medlemsgrupp har på de olika tavlorna på forumet.';
$txt['gr_type_member_groups'] = 'Medlemsgrupper';
$txt['gr_type_desc_member_groups'] = 'Rapport som visar inställningar för alla medlemsgrupper på.';
$txt['gr_type_group_perms'] = 'Grupprättigheter';
$txt['gr_type_desc_group_perms'] = 'Rapport om de rättigheter som alla medlemsgrupper har på forumet.';
$txt['gr_type_staff'] = 'Personal';
$txt['gr_type_desc_staff'] = 'Denna rapport sammanfattar alla medlemmar som för närvarande har auktoritetsposter på forumet.';

$txt['full_member'] = 'Fullständig medlem';
$txt['results'] = 'Resultat';

// Board permissions
$txt['board_perms_permission'] = 'Rättighet';
$txt['board_perms_allow'] = 'Tillåt';
$txt['board_perms_deny'] = 'Neka';
$txt['board_perms_name_announce_topic'] = 'Tillkännage ämne';
$txt['board_perms_name_approve_posts'] = 'Godkänn inlägg';
$txt['board_perms_name_delete_any'] = 'Radera alla inlägg';
$txt['board_perms_name_delete_own'] = 'Radera egna inlägg';
$txt['board_perms_name_delete_replies'] = 'Radera svar till egna ämnen';
$txt['board_perms_name_lock_any'] = 'Låsa alla ämnen';
$txt['board_perms_name_lock_own'] = 'Låsa egna ämnen';
$txt['board_perms_name_make_sticky'] = 'Pin topics';
$txt['board_perms_name_mark_any_notify'] = 'Begära underrättelser på alla ämnen';
$txt['board_perms_name_mark_notify'] = 'Begära underrättelser på egna ämnen';
$txt['board_perms_name_merge_any'] = 'Sammanfoga ämnen';
$txt['board_perms_name_moderate_board'] = 'Moderera tavlan';
$txt['board_perms_name_modify_any'] = 'Redigera alla inlägg';
$txt['board_perms_name_modify_own'] = 'Redigera egna inlägg';
$txt['board_perms_name_modify_replies'] = 'Redigera svar till egna ämnen';
$txt['board_perms_name_move_any'] = 'Flytta alla ämnen';
$txt['board_perms_name_move_own'] = 'Flytta egna ämnen';
$txt['board_perms_name_poll_add_any'] = 'Lägga till omröstning till alla ämnen';
$txt['board_perms_name_poll_add_own'] = 'Lägga till omröstning till egna ämnen';
$txt['board_perms_name_poll_edit_any'] = 'Redigera alla omröstningar';
$txt['board_perms_name_poll_edit_own'] = 'Redigera egna omröstningar';
$txt['board_perms_name_poll_lock_any'] = 'Låsa alla omröstningar';
$txt['board_perms_name_poll_lock_own'] = 'Låsa egna omröstningar';
$txt['board_perms_name_poll_post'] = 'Skapa nya omröstningar';
$txt['board_perms_name_poll_remove_any'] = 'Ta bort alla omröstningar';
$txt['board_perms_name_poll_remove_own'] = 'Ta bort egna omröstningar';
$txt['board_perms_name_poll_view'] = 'Visa omröstningar';
$txt['board_perms_name_poll_vote'] = 'Rösta i omröstningar';
$txt['board_perms_name_post_attachment'] = 'Bifoga filer till inlägg';
$txt['board_perms_name_post_new'] = 'Skapa nya ämnen';
$txt['board_perms_name_post_reply_any'] = 'Skriva svar till alla ämnen';
$txt['board_perms_name_post_reply_own'] = 'Skriva svar till egna ämnen';
$txt['board_perms_name_post_unapproved_attachments'] = 'Visa ej godkända bilagor';
$txt['board_perms_name_post_unapproved_topics'] = 'Visa ej godkända ämnen';
$txt['board_perms_name_post_unapproved_replies_any'] = 'Visa ej godkända svar i allas ämnen';
$txt['board_perms_name_post_unapproved_replies_own'] = 'Visa ej godkända svar i egna ämnen';
$txt['board_perms_name_remove_any'] = 'Ta bort alla ämnen';
$txt['board_perms_name_remove_own'] = 'Ta bort egna ämnen';
$txt['board_perms_name_report_any'] = 'Anmäla alla inlägg';
$txt['board_perms_name_send_topic'] = 'Skicka ämne till vän';
$txt['board_perms_name_split_any'] = 'Dela upp alla ämnen';
$txt['board_perms_name_view_attachments'] = 'Visa bifogade filer';

$txt['board_perms_group_no_polls'] = 'Denna tavla tillåter inte omröstningar';
$txt['board_perms_group_reply_only'] = 'Denna tavla tillåter bara användare att svara på befintliga ämnen';
$txt['board_perms_group_read_only'] = 'På denna tavla får användare inte skriva inlägg alls';

// Membergroup info!
$txt['member_group_color'] = 'Färg';
$txt['member_group_min_posts'] = 'Minsta antal inlägg';
$txt['member_group_max_messages'] = 'Max antal personliga meddelanden';
$txt['member_group_icons'] = 'Icons';
$txt['member_group_settings'] = 'Inställningar';
$txt['member_group_access'] = 'Tavelbehörighet';

// Board info.
$txt['none'] = 'Ingen';
$txt['board_category'] = 'Kategori';
$txt['board_parent'] = 'Överliggande tavla';
$txt['board_num_topics'] = 'Antal ämnen';
$txt['board_num_posts'] = 'Antal inlägg';
$txt['board_count_posts'] = 'Räkna antal inlägg';
$txt['board_theme'] = 'Tavlans tema';
$txt['board_override_theme'] = 'Tvinga tema för tavlan';
$txt['board_profile'] = 'Rättighetsprofil';
$txt['board_moderators'] = 'Moderatorer';
$txt['board_groups'] = 'Grupper med behörighet';
$txt['board_disallowed_groups'] = 'Groups with Access Denied';

// Group Permissions.
$txt['group_perms_name_access_mod_center'] = 'Komma åt moderatorscentret';
$txt['group_perms_name_admin_forum'] = 'Administrera forum';
$txt['group_perms_name_calendar_edit_any'] = 'Redigera alla händelser';
$txt['group_perms_name_calendar_edit_own'] = 'Redigera egna händelser';
$txt['group_perms_name_calendar_post'] = 'Skapa nya händelser';
$txt['group_perms_name_calendar_view'] = 'Visa händelser';
$txt['group_perms_name_edit_news'] = 'Redigera forumnyheter';
$txt['group_perms_name_issue_warning'] = 'Utförda varningar';
$txt['group_perms_name_karma_edit'] = 'Redigera medlemmars karma';
$txt['group_perms_name_manage_attachments'] = 'Hantera bifogade filer';
$txt['group_perms_name_manage_bans'] = 'Hantera bannlysningar';
$txt['group_perms_name_manage_boards'] = 'Hantera tavlor';
$txt['group_perms_name_manage_membergroups'] = 'Manage member groups';
$txt['group_perms_name_manage_permissions'] = 'Hantera rättigheter';
$txt['group_perms_name_manage_smileys'] = 'Hantera smileys och meddelandeikoner';
$txt['group_perms_name_moderate_forum'] = 'Moderera tavlor';
$txt['group_perms_name_pm_read'] = 'Läsa privata meddelanden';
$txt['group_perms_name_pm_send'] = 'Skicka privata meddelanden';
$txt['group_perms_name_profile_extra_any'] = 'Redigera allas personliga tillval';
$txt['group_perms_name_profile_extra_own'] = 'Redigera sina egna personliga tillval';
$txt['group_perms_name_profile_identity_any'] = 'Redigera allas kontoinställningar';
$txt['group_perms_name_profile_identity_own'] = 'Redigera sina egna kontoinställningar';
$txt['group_perms_name_profile_set_avatar'] = 'Select an avatar';
$txt['group_perms_name_profile_remove_any'] = 'Radera allas konton';
$txt['group_perms_name_profile_remove_own'] = 'Radera sitt eget konto';
$txt['group_perms_name_profile_title_any'] = 'Redigera allas anpassade titlar';
$txt['group_perms_name_profile_title_own'] = 'Redigera sin egen anpassade titel';
$txt['group_perms_name_profile_view_any'] = 'Visa allas profiler';
$txt['group_perms_name_profile_view_own'] = 'View own profile';
$txt['group_perms_name_search_posts'] = 'Söka efter inlägg';
$txt['group_perms_name_send_mail'] = 'Skicka e-post till medlemmar';
$txt['group_perms_name_view_mlist'] = 'View the member list';
$txt['group_perms_name_view_stats'] = 'Visa forumstatistik';
$txt['group_perms_name_who_view'] = 'Visa vilka som är online';

$txt['report_error_too_many_staff'] = 'You have too many staff members. The report will not work with more than 300 staff members.';
$txt['report_staff_position'] = 'Ställning';
$txt['report_staff_moderates'] = 'Modererar';
$txt['report_staff_posts'] = 'Inlägg';
$txt['report_staff_last_login'] = 'Senast inloggad';
$txt['report_staff_all_boards'] = 'Alla tavlor';
$txt['report_staff_no_boards'] = 'Inga tavlor';