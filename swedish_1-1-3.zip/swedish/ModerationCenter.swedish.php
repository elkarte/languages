<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Moderationscenter';
$txt['mc_main'] = 'Start';
$txt['mc_logs'] = 'Loggar';
$txt['mc_posts'] = 'Inlägg';
$txt['mc_groups'] = 'Members and groups';

$txt['mc_view_groups'] = 'Visa medlemsgrupper';

$txt['mc_description'] = '<strong>Welcome, %1$s!</strong><br />This is your &quot;Moderation Center&quot;. From here you can perform all the moderation actions assigned to yourself by the Administrator. This home page contains a summary of all the latest happenings in your community. You can <a href="%2$s">personalize the layout by clicking here</a>.';
$txt['mc_group_requests'] = 'Gruppförfrågningar';
$txt['mc_member_requests'] = 'Member Requests';
$txt['mc_unapproved_posts'] = 'Ej godkända inlägg';
$txt['mc_watched_users'] = 'Recently Watched Members';
$txt['mc_watched_topics'] = 'Bevakade ämnen';
$txt['mc_scratch_board'] = 'Moderatorernas anslagstavla';
$txt['mc_latest_news'] = 'Latest News';
$txt['mc_recent_reports'] = 'Nya rapporter av ämnen';
$txt['mc_warnings'] = 'Varningar';
$txt['mc_notes'] = 'Noteringar från moderatorer';
$txt['mc_required'] = 'Items Requiring Approval';
$txt['mc_attachments'] = 'Attachments needing approval';
$txt['mc_emailmod'] = 'Email Postings needing approval';
$txt['mc_topics'] = 'Topics needing approval';
$txt['mc_posts'] = 'Inlägg';
$txt['mc_groupreq'] = 'Group requests needing approval';
$txt['mc_memberreq'] = 'Members needing approval';
$txt['mc_reports'] = 'Report posts needing approval';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['mc_recent_reports_none'] = 'Det finns inga rapporter att visa.';
$txt['mc_watched_users_none'] = 'Inga bevakningar är ingång just nu.';
$txt['mc_group_requests_none'] = 'Det finns inga öppna ansökningar om gruppmedlemskap.';

$txt['mc_seen'] = '%1$s sågs senast %2$s ';
$txt['mc_seen_never'] = '%1$s har inte setts till ';
$txt['mc_groupr_by'] = 'av';

$txt['mc_reported_posts_desc'] = 'Här kan du se alla rapporter av inlägg och ämnen som medlemmarna på detta forum gjort.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Aktiva rapporter';
$txt['mc_reportedp_closed'] = 'Gamla rapporter';
$txt['mc_reportedp_by'] = 'av';
$txt['mc_reportedp_reported_by'] = 'Rapporterat av';
$txt['mc_reportedp_last_reported'] = 'Senast rapporterat';
$txt['mc_reportedp_none_found'] = 'Inga rapporter hittades';

$txt['mc_reportedp_details'] = 'Detaljer';
$txt['mc_reportedp_close'] = 'Stäng';
$txt['mc_reportedp_open'] = 'Öppna';
$txt['mc_reportedp_ignore'] = 'Dismiss';
$txt['mc_reportedp_unignore'] = 'Reopen';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Are you sure you wish to dismiss and ignore further reports about this message?

This will turn off further reports for all moderators of the forum.';
$txt['mc_reportedp_close_selected'] = 'Stäng markerade';

$txt['mc_groupr_group'] = 'Medlemsgrupper';
$txt['mc_groupr_member'] = 'Medlem';
$txt['mc_groupr_reason'] = 'Orsak';
$txt['mc_groupr_none_found'] = 'Just nu finns inga gruppförfrågningar';
$txt['mc_groupr_submit'] = 'Skicka';
$txt['mc_groupr_reason_desc'] = 'Anledning till att %1$ss ansökan om inträde anslås &quot;%2$s&quot;';
$txt['mc_groups_reason_title'] = 'Reasons for rejection';
$txt['with_selected'] = 'With selected';
$txt['mc_groupr_approve'] = 'Approve request';
$txt['mc_groupr_reject'] = 'Reject request (No Reason)';
$txt['mc_groupr_reject_w_reason'] = 'Reject request with reason';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Vill du verkligen göra detta?';

$txt['mc_unapproved_attachments_none_found'] = 'Inga bifogade filer som väntar på godkännande hittades!';
$txt['mc_unapproved_attachments_desc'] = 'From here you can approve or delete any attachments awaiting moderation.';
$txt['mc_unapproved_replies_none_found'] = 'Inga inlägg som väntar på godkännande hittades!';
$txt['mc_unapproved_topics_none_found'] = 'Inga ämnen som väntar på godkännande hittades!';
$txt['mc_unapproved_posts_desc'] = 'Här kan du godkänna eller neka inlägg som väntar på moderation.';
$txt['mc_unapproved_replies'] = 'Svar';
$txt['mc_unapproved_topics'] = 'Visa inlägg';
$txt['mc_unapproved_by'] = 'av';
$txt['mc_unapproved_sure'] = 'Vill du verkligen göra detta?';
$txt['mc_unapproved_attach_name'] = 'Attachment name';
$txt['mc_unapproved_attach_size'] = 'File size';
$txt['mc_unapproved_attach_poster'] = 'Författare';
$txt['mc_viewmodreport'] = 'Moderation report for %1$s by %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Medlemmar som har rapporterat detta inlägg';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Åtgärder som vidtagits av andra moderatorer';
$txt['mc_modreport_mod_comments'] = 'Kommentarer';
$txt['mc_modreport_no_mod_comment'] = 'Inga moderatorer har kommenterat denna rapport';
$txt['mc_modreport_add_mod_comment'] = 'Lägg till kommentar';

$txt['show_notice'] = 'Varningstext';
$txt['show_notice_subject'] = 'Ämne';
$txt['show_notice_text'] = 'Text';

$txt['mc_watched_users_title'] = 'Bevakade användare';
$txt['mc_watched_users_desc'] = 'Här kan du hålla reda på alla medlemmar som har tilldelats en &quot;bevakning&quot; av moderatorerna.';
$txt['mc_watched_users_post'] = 'Sortera efter inlägg';
$txt['mc_watched_users_warning'] = 'Varningsnivå';
$txt['mc_watched_users_last_login'] = 'Senast inloggad';
$txt['mc_watched_users_last_post'] = 'Senaste inlägg';
$txt['mc_watched_users_no_posts'] = 'Det finns inga inlägg från bevakade användare.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Vill du verkligen radera detta inlägg?';
$txt['mc_watched_users_delete_posts'] = 'Vill du verkligen radera dessa inlägg?';
$txt['mc_watched_users_posted'] = 'Postad';
$txt['mc_watched_users_member'] = 'Medlem';

$txt['mc_warnings_description'] = 'Härifrån kan du se vilka varningar som delats ut till medlemmar på forumet. Du kan också lägga till och hantera underrättelsemallarna som används när medlemmar varnas.';
$txt['mc_warning_log'] = 'Varningslogg';
$txt['mc_warning_templates'] = 'Mallar';
$txt['mc_warning_log_title'] = 'Viewing warning log';
$txt['mc_warning_templates_title'] = 'Custom warning templates';

$txt['mc_warnings_none'] = 'No warnings have been issued.';
$txt['mc_warnings_recipient'] = 'Mottagare';

$txt['mc_warning_templates_none'] = 'Inga varningsmallar har skapats ännu';
$txt['mc_warning_templates_time'] = 'Skapad';
$txt['mc_warning_templates_name'] = 'Mall';
$txt['mc_warning_templates_creator'] = 'Skapad av';
$txt['mc_warning_template_add'] = 'Lägg till mall';
$txt['mc_warning_template_modify'] = 'Ändra mall';
$txt['mc_warning_template_delete'] = 'Radera markerade';
$txt['mc_warning_template_delete_confirm'] = 'Vill du verkligen radera de markerade mallarna?';

$txt['mc_warning_template_desc'] = 'Use this page to fill in the details of the template. Note that the subject for the email is not part of the template. Note that as the notification is sent by PM you can use BBC within the template. If you use the {MESSAGE} variable then this template will not be available when issuing a generic warning (i.e. A warning not linked to a post).';
$txt['mc_warning_template_title'] = 'Mallens namn';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Personlig mall';
$txt['mc_warning_template_personal_desc'] = 'Om du markerar detta alternativ kommer endast du själv kunna se, redigera och använda denna mall. Om detta inte är valt kommer alla moderatorer att kunna använda denna mall.';
$txt['mc_warning_template_error_no_title'] = 'You must set the title.';
$txt['mc_warning_template_error_no_body'] = 'You must set the notification body.';

$txt['mc_settings'] = 'Ändra inställningar';
$txt['mc_prefs_title'] = 'Inställningar';
$txt['mc_prefs_desc'] = 'I denna sektion kan du ange några personliga inställningar angående moderationscentret';
$txt['mc_prefs_homepage'] = 'Rubriker att visa under menyn moderera';
$txt['mc_prefs_latest_news'] = 'ElkArte News';
$txt['mc_prefs_show_reports'] = 'Visa antalet öppna rapporter i forumets sidhuvud';
$txt['mc_prefs_notify_report'] = 'Underrätta om rapporterade ämnen';
$txt['mc_prefs_notify_report_never'] = 'Aldrig';
$txt['mc_prefs_notify_report_moderator'] = 'Endast om det gäller en tavla som jag modererar';
$txt['mc_prefs_notify_report_always'] = 'Alltid';
$txt['mc_prefs_notify_approval'] = 'Underrätta om föremål som väntar på godkännande';
$txt['mc_logoff'] = 'End Moderator Session';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Skriv en ny notering';
$txt['mc_add_note'] = 'Lägg till';