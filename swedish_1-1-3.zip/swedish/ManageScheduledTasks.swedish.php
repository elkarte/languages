<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Schemalagda uppgifter';
$txt['scheduled_tasks_header'] = 'Alla schemalagda uppgifter';
$txt['scheduled_tasks_name'] = 'Uppgiftens namn';
$txt['scheduled_tasks_next_time'] = 'Kommer att köras nästa gång';
$txt['scheduled_tasks_regularity'] = 'Regelbundenhet';
$txt['scheduled_tasks_enabled'] = 'Aktiverat';
$txt['scheduled_tasks_run_now'] = 'Kör uppgift nu';
$txt['scheduled_tasks_save_changes'] = 'Spara ändringar';
$txt['scheduled_tasks_time_offset'] = '<strong>Note:</strong> All times given below are <em>server time</em> and do not take any time offsets setup within the admin panel into account.';
$txt['scheduled_tasks_were_run'] = 'Alla markerade uppgifter slutfördes';
$txt['scheduled_tasks_were_run_errors'] = 'The following errors occurred while running the scheduled tasks:';

$txt['scheduled_tasks_na'] = 'N/A ';
$txt['scheduled_task_approval_notification'] = 'Underrättelse av godkännanden';
$txt['scheduled_task_desc_approval_notification'] = 'Skicka e-post till alla moderatorer med sammanfattning av inlägg som väntar på godkännande.';
$txt['scheduled_task_auto_optimize'] = 'Optimera databas';
$txt['scheduled_task_desc_auto_optimize'] = 'Optimera databasen för att lösa fragmenteringsproblem och förbättra hastigheten.';
$txt['scheduled_task_daily_maintenance'] = 'Dagligt underhåll';
$txt['scheduled_task_desc_daily_maintenance'] = 'Kör viktigt underhåll på forumet dagligen - bör inte stängas av.';
$txt['scheduled_task_daily_digest'] = 'Daglig underrättelsesammanfattning';
$txt['scheduled_task_desc_daily_digest'] = 'Skickar ut daglig sammanfattning för alla som begärt underrättelser.';
$txt['scheduled_task_weekly_digest'] = 'Veckovis underrättelsesammanfattning';
$txt['scheduled_task_desc_weekly_digest'] = 'Skickar ut veckovis sammanfattning för alla som begärt underrättelser.';
$txt['scheduled_task_birthdayemails'] = 'Skicka födelsedagsepost';
$txt['scheduled_task_desc_birthdayemails'] = 'Skickar ut e-post som önskar medlemmar grattis på födelsedagen.';
$txt['scheduled_task_weekly_maintenance'] = 'Veckovist underhåll';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Kör viktigt underhåll av forumet varje vecka - bör inte stängas av.';
$txt['scheduled_task_paid_subscriptions'] = 'Betald prenumerationskontroll';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Skickar ut eventuella nödvändiga påminnelser om betalning av prenumerationer, och tar bort prenumerationer som gått ut.';
$txt['scheduled_task_remove_topic_redirect'] = 'Remove MOVED: Redirection Topics';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Deletes "MOVED:" topic notifications as specified when the moved notice was created.';
$txt['scheduled_task_remove_temp_attachments'] = 'Remove Temporary Attachment Files';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Deletes temporary files created while attaching a file to a post that for any reason weren\'t renamed or deleted before.';
$txt['scheduled_task_remove_old_drafts'] = 'Remove Old Drafts';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Deletes drafts older than the number of days defined in the draft settings in the admin panel.';
$txt['scheduled_task_remove_old_followups'] = 'Remove Old Follow-ups';
$txt['scheduled_task_desc_remove_old_followups'] = 'Deletes follow-up entries still present in the database, but pointing to non-existent topics.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Fetch Emails from IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Fetches emails for the mailing list feature from an IMAP box and processes them.';
$txt['scheduled_task_user_access_mentions'] = 'Users Mentions Access';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verify users access to each board and set accessibility to related mentions accordingly.';

$txt['scheduled_task_reg_starting'] = 'Startar vid %1$s';
$txt['scheduled_task_reg_repeating'] = 'repeterar varje %1$d %2$s ';
$txt['scheduled_task_reg_unit_m'] = 'minut(er)';
$txt['scheduled_task_reg_unit_h'] = 'timmar';
$txt['scheduled_task_reg_unit_d'] = 'dag(ar)';
$txt['scheduled_task_reg_unit_w'] = 'veckor';

$txt['scheduled_task_edit'] = 'Redigera schemalagd aktivitet';
$txt['scheduled_task_edit_repeat'] = 'Repetera uppgift varje';
$txt['scheduled_task_edit_pick_unit'] = 'Välj enhet';
$txt['scheduled_task_edit_interval'] = 'Intervall';
$txt['scheduled_task_edit_start_time'] = 'Starttid';
$txt['scheduled_task_edit_start_time_desc'] = 'Tidpunkt för första förekommande aktiviteten (timmar:minuter)';
$txt['scheduled_task_time_offset'] = 'Observera att starttiden ska utgå ifrån den nuvarande serverklockan. Nuvarande servertid är: %1$s';

$txt['scheduled_view_log'] = 'Visa logg';
$txt['scheduled_log_empty'] = 'Just nu finns det inga föremål i loggen.';
$txt['scheduled_log_time_run'] = 'Körd tid';
$txt['scheduled_log_time_taken'] = 'Har tagit';
$txt['scheduled_log_time_taken_seconds'] = '%1$d sekunder';
$txt['scheduled_log_completed'] = 'Task completed';
$txt['scheduled_log_empty_log'] = 'Clear Log';
$txt['scheduled_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log?';