<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Skriv svar';
$txt['post_in_board'] = 'Post in the board';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Infoga citat';
$txt['disable_smileys'] = 'Disable smileys';
$txt['dont_use_smileys'] = 'Använd inte smileys.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Skrivet';
$txt['standard'] = 'Standard';
$txt['thumbs_up'] = 'Tummen upp';
$txt['thumbs_down'] = 'Tummen ner';
$txt['exclamation_point'] = 'Utropstecken';
$txt['question_mark'] = 'Frågetecken';
$txt['icon_poll'] = 'Omröstning';
$txt['lamp'] = 'Lampa';
$txt['add_smileys'] = 'Add smileys';
$txt['topic_notify_no'] = 'There are no topics with notification.';

$txt['rich_edit_wont_work'] = 'Din webbläsare stödjer inte WYSIWYG-redigering.';
$txt['rich_edit_function_disabled'] = 'Din webbläsare stödjer inte denna funktion.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Avsluta prenumerationen på detta ämne genom att klicka här';

$txt['lock_after_post'] = 'Lås ämnet efter detta inlägg';
$txt['notify_replies'] = 'Underrätta via e-post vid nya svar.';
$txt['lock_topic'] = 'Lås detta ämne.';
$txt['shortcuts'] = 'shortcuts: shift+alt+s submit/post or shift+alt+p preview';
$txt['shortcuts_drafts'] = 'shortcuts: shift+alt+s submit/post, shift+alt+p preview or shift+alt+d save draft';
$txt['option'] = 'Alternativ';
$txt['reset_votes'] = 'Reset vote count';
$txt['reset_votes_check'] = 'Markera om du vill nollställa alla röster tillbaka till 0.';
$txt['votes'] = 'röster';
$txt['attach'] = 'Bifoga';
$txt['clean_attach'] = 'Clear attachment';
$txt['attached'] = 'Bifogat'; // @deprecated since 1.1
$txt['allowed_types'] = 'Tillåtna filtyper';
$txt['cant_upload_type'] = 'You cannot upload that type of file. The only allowed extensions are %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Kryssa av de bifogade filer du inte längre vill bifoga'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Detta är ett otillåtet namn. Vänligen försök med ett annat filnamn.';
$txt['topic_locked_no_reply'] = 'Warning! This topic is currently/will be locked<br />Only admins and moderators can reply.';
$txt['attachment_requires_approval'] = 'Observera att eventuella bifogade filer inte kommer att synas, förrän de godkänts av moderator.';
$txt['error_temp_attachments'] = 'There are attachments found, which you have attached before but not posted. These attachments are now attached to this post. If you do not want to include them in this post, <a href="#postAttachment">you can remove them here</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Påminnelse: Detta inlägg kommer inte att synas förrän det godkänts av moderator.';

$txt['enter_comment'] = 'Lägg till kommentar';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Anmält inlägg';
$txt['reported_to_mod_by'] = 'av';
$txt['rtm10'] = 'Skicka';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Följande inlägg, "%1$s" av';
$txt['reported_by'] = 'har anmälts av';
$txt['board_moderate'] = 'på en tavla som du är moderator för';
$txt['report_comment'] = 'Anmälaren har lämnat följande kommentar';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximum total size %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximum individual size %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d per inlägg';
$txt['attach_restrictions'] = 'Begränsningar:';

$txt['post_additionalopt_attach'] = 'Bilagor och andra tillval';
$txt['post_additionalopt'] = 'Other options';
$txt['sticky_after'] = 'Pin this topic.';
$txt['move_after2'] = 'Flytta detta ämne.';
$txt['back_to_topic'] = 'Återgå till ämnet efter postandet.';
$txt['approve_this_post'] = 'Approve this post';

$txt['retrieving_quote'] = 'Retrieving quote...';

$txt['post_visual_verification_label'] = 'Verifiering';
$txt['post_visual_verification_desc'] = 'Skriv in bokstäverna i nedanstående bild, för att posta inlägget.';

$txt['poll_options'] = 'Omröstningsalternativ';
$txt['poll_run'] = 'Kör omröstningen i';
$txt['poll_run_limit'] = '(Lämna tomt för ingen begränsning)';
$txt['poll_results_visibility'] = 'Resultatsynlighet';
$txt['poll_results_anyone'] = 'Visa omröstningens resultat för samtliga.';
$txt['poll_results_voted'] = 'Visa endast resultat efter att någon har röstat.';
$txt['poll_results_after'] = 'Visa bara resultat efter att omröstningen har avslutats.';
$txt['poll_max_votes'] = 'Max antal röster per användare';
$txt['poll_do_change_vote'] = 'Tillåt användare att ändra sin röst';
$txt['poll_too_many_votes'] = 'Du valde för många alternativ. För denna omröstning får du bara välja upp till %1$s alternativ.';
$txt['poll_add_option'] = 'Lägg till nytt alternativ';
$txt['poll_guest_vote'] = 'Tillåt gäster att rösta';

$txt['spellcheck_done'] = 'Stavningskontrollen avslutad.';
$txt['spellcheck_change_to'] = 'Ändra till:';
$txt['spellcheck_suggest'] = 'Förslag:';
$txt['spellcheck_change'] = 'Ändra';
$txt['spellcheck_change_all'] = 'Ändra samtliga';
$txt['spellcheck_ignore'] = 'Ignorera';
$txt['spellcheck_ignore_all'] = 'Ignorera samtliga';

$txt['more_attachments'] = 'fler bilagor';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Beklagar, du får inte bifoga fler filer.';

$txt['more_smileys'] = 'fler';
$txt['more_smileys_title'] = 'Fler smileys';
$txt['more_smileys_pick'] = 'Välj en smiley';
$txt['more_smileys_close_window'] = 'Stäng fönstret';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = 'Skicka tillkännagivande om detta ämne till medlemmarna:';
$txt['announce_title'] = 'Skicka tillkännagivande';
$txt['announce_desc'] = 'Denna formulär låter dig skicka ett tillkännagivande till valda medlemsgrupper om detta ämne.';
$txt['announce_sending'] = 'Skickar tillkännagivande om ämne';
$txt['announce_done'] = 'klart';
$txt['announce_continue'] = 'Fortsätt';
$txt['announce_topic'] = 'Tillkännage ämne.';
$txt['announce_regular_members'] = 'Vanliga medlemmar';

$txt['digest_subject_daily'] = 'Daglig sammanfattning';
$txt['digest_subject_weekly'] = 'Veckovis sammanfattning';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'The following topics were started';
$txt['digest_new_topics_line'] = '"%1$s" in the %2$s board';
$txt['digest_new_replies'] = 'Svar har skrivits i dessa ämnen';
$txt['digest_new_replies_one'] = '1 svar i "%1$s"';
$txt['digest_new_replies_many'] = '%1$d svar i "%2$s"';
$txt['digest_mod_actions'] = 'Följande moderatorsåtgärder har utförts';
$txt['digest_mod_act_sticky'] = '"%1$s" was pinned';
$txt['digest_mod_act_lock'] = '"%1$s" har låsts';
$txt['digest_mod_act_unlock'] = '"%1$s" har låsts upp';
$txt['digest_mod_act_remove'] = '"%1$s" har tagits bort';
$txt['digest_mod_act_move'] = '"%1$s" har flyttats';
$txt['digest_mod_act_merge'] = '"%1$s" har sammanfogats';
$txt['digest_mod_act_split'] = '"%1$s" har delats upp';

$txt['attach_error_title'] = 'Error uploading attachments.';
$txt['attach_warning'] = 'There was a problem during the uploading of <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Sorry, you are out of attachment space. The total attachment size allowed per post is %1$s KB. Space remaining is %2$s KB.';
$txt['attach_folder_warning'] = 'The attachments directory can not be located. Please notify an administrator of this problem.';
$txt['attach_folder_admin_warning'] = 'The path to the attachments directory (%1$s) is incorrect. Please correct it in the attachment settings area of your admin panel.';
$txt['attach_limit_nag'] = 'You have reached the maximum number of attachments allowed per post.';
$txt['attach_no_upload'] = 'There was a problem and your attachments could not be uploaded';
$txt['attach_remaining'] = '%1$d remaining';
$txt['attach_available'] = '%1$s KB available';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'The file appears to be empty. Please contact your forum administrator if this continues to be a problem';
$txt['attached_files_in_session'] = '<em>The above underlined file(s) have been uploaded but will not be attached to this post until it is submitted.</em>';

$txt['attach_php_error'] = 'Due to an error, your attachment could not be uploaded. Please contact the forum administrator if this problem continues.';
$txt['php_upload_error_1'] = 'The uploaded file exceeds the upload_max_filesize directive in php.ini. Please contact your host if you are unable to correct this issue.';
$txt['php_upload_error_3'] = 'The uploaded file was only partially uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_4'] = 'No file was uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_6'] = 'Unable to save. Missing a temporary directory. Please contact your host if you are unable to correct this problem.';
$txt['php_upload_error_7'] = 'Failed to write file to disk. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_8'] = 'A PHP extension stopped the file upload. This is a PHP related error. Please contact your host if this problem continues.';
$txt['error_temp_attachments_new'] = 'There are attachments which you had previously attached but not posted. These attachments are still attached to this post. This post does need to be submitted before these attachments are either saved or removed. You <a href="#postAttachment">can do that here</a>';
$txt['error_temp_attachments_found'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not post until these are either removed or that post has been submitted.<br />Click <a href="%1$s">here to remove </a>those attachments. Or <a href="%2$s">here to return to that post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not upload any more attachments until these are removed or that post has been submitted.<br />Click <a href="%1$s">here to remove these attachments</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Those attachments have now been removed and you have been returned to the page you were previously on';
$txt['error_temp_attachments_flushed'] = 'Please note that any files which had been previously attached, but not posted, have now been removed.';
$txt['error_topic_already_announced'] = 'Please note that this topic has already been announced.';

$txt['cant_access_upload_path'] = 'Kan inte komma åt sökvägen för uppladdning av bifogade filer!';
$txt['file_too_big'] = 'Your file is too large. The maximum attachment size allowed is %1$s KB.';
$txt['attach_timeout'] = 'Din bifogade fil kunde inte sparas. Det här kan inträffa om det tog för lång tid att ladda upp filen, eller om filen är större än servern tillåter.<br /><br />Var vänlig och kontakta serveradministratören för mer information.';
$txt['bad_attachment'] = 'Din bilaga avvisades tack vare säkerhetsinställningar och kan inte laddas upp. Vänligen kontakta en administratör.';
$txt['ran_out_of_space'] = 'The upload directory is full. Please contact an administrator about this problem.';
$txt['attachments_no_write'] = 'Uppladdningskatalogen för bifogade filer är inte skrivbar. Din bilaga eller personliga bild kan inte sparas.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory.  Your attachment or avatar cannot be saved.';
$txt['attachments_limit_per_post'] = 'Du kan inte ladda upp fler än %1$d filer per inlägg';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Insert';
$txt['ila_opt_size'] = 'Storlek';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Ingen';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Center';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/