<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Datum';
$txt['modlog_member'] = 'Medlem';
$txt['modlog_position'] = 'Ställning';
$txt['modlog_action'] = 'Aktivitet';
$txt['modlog_ip'] = 'IP-adress';
$txt['modlog_search_result'] = 'Sökresultat';
$txt['modlog_total_entries'] = 'Totalt antal inlägg';
$txt['modlog_ac_approve_topic'] = 'Godkänt ämne &quot;{topic}&quot; av &quot;{member}&quot;';
$txt['modlog_ac_unapprove_topic'] = 'Unapproved topic &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_approve'] = 'Godkänt inlägg &quot;{subject}&quot; i &quot;{topic}&quot; av &quot;{member}&quot;';
$txt['modlog_ac_unapprove'] = 'Unapproved message &quot;{subject}&quot; in &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_lock'] = 'Låst &quot;{topic}&quot;';
$txt['modlog_ac_warning'] = 'Varnad {member} för &quot;{message}&quot; ';
$txt['modlog_ac_unlock'] = 'Låste upp &quot;{topic}&quot;';
$txt['modlog_ac_sticky'] = 'Pinned &quot;{topic}&quot;';
$txt['modlog_ac_unsticky'] = 'Unpinned &quot;{topic}&quot;';
$txt['modlog_ac_delete'] = 'Raderat &quot;{subject}&quot; av &quot;{member}&quot; från &quot;{topic}&quot;';
$txt['modlog_ac_delete_member'] = 'Raderat medlem &quot;{name}&quot;';
$txt['modlog_ac_remove'] = 'Tagit bort ämnet &quot;{topic}&quot; från &quot;{board}&quot;';
$txt['modlog_ac_modify'] = 'Redigerat &quot;{message}&quot; av &quot;{member}&quot;';
$txt['modlog_ac_merge'] = 'Sammanfogat ämnen för att skapa &quot;{topic}&quot;';
$txt['modlog_ac_split'] = 'Delat upp &quot;{topic}&quot; för att skapa &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = 'Flyttat &quot;{topic}&quot; från &quot;{board_from}&quot; till &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Redigerat profilen tillhörande &quot;{member}&quot;';
$txt['modlog_ac_pruned'] = 'Rensat inlägg äldre än {days} dagar';
$txt['modlog_ac_news'] = 'Redigerat nyheterna';
$txt['modlog_enter_comment'] = 'Ange moderatorskommentar';
$txt['modlog_moderation_log'] = 'Moderatorlogg';
$txt['modlog_moderation_log_desc'] = 'Nedan återfinns en lista på alla moderatorsåtgärder som har utförts av moderatorerna på ditt forum.<br /><strong>Obs:</strong> Poster kan inte tas bort från loggen förrän de är minst 24 timmar gamla.';
$txt['modlog_no_entries_found'] = 'Det finns för närvarande inga poster i moderatorsloggen. ';
$txt['modlog_remove'] = 'Radera markerade';
$txt['modlog_removeall'] = 'Clear Log';
$txt['modlog_remove_selected_confirm'] = 'Are you sure you want to delete the selected log entries?';
$txt['modlog_remove_all_confirm'] = 'Are you sure you want to completely clear the log?';
$txt['modlog_go'] = 'OK';
$txt['modlog_add'] = 'Lägg till';
$txt['modlog_search'] = 'Snabbsök';
$txt['modlog_by'] = 'av';
$txt['modlog_id'] = '<em>Raderat - ID:%1$d</em>';

$txt['modlog_ac_add_warn_template'] = 'Lade till varningsmall: &quot;{template}&quot;';
$txt['modlog_ac_modify_warn_template'] = 'Ändrade varningsmallen: &quot;{template}&quot;';
$txt['modlog_ac_delete_warn_template'] = 'Raderade varningsmallen: &quot;{template}&quot;';

$txt['modlog_ac_ban'] = 'Lagt till bannlysningsutlösare:';
$txt['modlog_ac_ban_update'] = 'Edited ban triggers:';
$txt['modlog_ac_ban_remove'] = 'Removed ban triggers:';
$txt['modlog_ac_ban_trigger_member'] = ' <em>Member:</em> {member}';
$txt['modlog_ac_ban_trigger_email'] = ' <em>E-post:</em> {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = ' <em>IP:</em> {ip_range}';
$txt['modlog_ac_ban_trigger_hostname'] = ' <em>Värdnamn:</em> {hostname}';

$txt['modlog_admin_log'] = 'Administratörsloggen';
$txt['modlog_admin_log_desc'] = 'Nedan återfinns en lista på alla administratörssåtgärder som har utförts på ditt forum.<br /><strong>Obs:</strong> Poster kan inte tas bort från loggen förrän de är minst 24 timmar gamla.';
$txt['modlog_admin_log_no_entries_found'] = 'Det finns för närvarande inga poster i administrationsloggen';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Upgraderat forumet till version {version}';
$txt['modlog_ac_install'] = 'Installerad version {version}';
$txt['modlog_ac_add_board'] = 'Lagt till en ny tavla: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Ändrat &quot;{board}&quot; tavlan';
$txt['modlog_ac_delete_board'] = 'Raderat &quot;{boardname}&quot; tavlan';
$txt['modlog_ac_add_cat'] = 'Lagt till en ny kategori, &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Ändrat &quot;{catname}&quot; kategorin';
$txt['modlog_ac_delete_cat'] = 'Raderat &quot;{catname}&quot; kategorin';

$txt['modlog_ac_delete_group'] = 'Raderat &quot;{group}&quot; gruppen';
$txt['modlog_ac_add_group'] = 'Lagt till &quot;{group}&quot; gruppen';
$txt['modlog_ac_edited_group'] = 'ändrat &quot;{group}&quot; gruppen';
$txt['modlog_ac_added_to_group'] = 'Lagt till &quot;{member}&quot; i &quot;{group}&quot; gruppen';
$txt['modlog_ac_removed_from_group'] = 'Raderat &quot;{member}&quot; från &quot;{group}&quot; gruppen';
$txt['modlog_ac_removed_all_groups'] = 'Tagit bort &quot;{member}&quot; ur alla grupper';

$txt['modlog_ac_remind_member'] = 'Skickat en påminnelse till &quot;{member}&quot; för att aktivera kontot.';
$txt['modlog_ac_approve_member'] = 'Godkännt/Aktiverat kontot för &quot;{member}&quot;';
$txt['modlog_ac_newsletter'] = 'Skickat nyhetsbrev';

$txt['modlog_ac_install_package'] = 'Installerat nytt paket: &quot;{package}&quot;, version {version}';
$txt['modlog_ac_upgrade_package'] = 'Uppdaterat paket: &quot;{package}&quot; till version {version}';
$txt['modlog_ac_uninstall_package'] = 'Avinstallerat paket: &quot;{package}&quot;, version {version}';

$txt['modlog_ac_database_backup'] = 'Database backup taken by {member}.';
$txt['modlog_ac_editing_theme'] = '{member} edited a theme.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Återskapat ämnet &quot;{topic}&quot; från &quot;{board}&quot; till &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Återskapat inlägg från &quot;{subject}&quot; till ämnet &quot;{topic}&quot; i &quot;{board}&quot; tavlan.';

$txt['modlog_parameter_guest'] = '<em>Gäst</em>';

$txt['modlog_ac_approve_attach'] = 'Approved &quot;{filename}&quot; in &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Removed unapproved &quot;{filename}&quot; in &quot;{message}&quot;';