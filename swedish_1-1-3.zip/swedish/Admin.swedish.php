<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Tavlor';
$txt['admin_back_to'] = 'Back to admin panel';
$txt['admin_users'] = 'Medlemmar';
$txt['admin_newsletters'] = 'Nyhetsbrev';
$txt['include_these'] = 'Members to include';
$txt['exclude_these'] = 'Members to exclude';
$txt['admin_newsletters_select_groups'] = 'Groups to include';
$txt['admin_newsletters_exclude_groups'] = 'Groups to exclude';
$txt['admin_edit_news'] = 'Nyheter';
$txt['admin_groups'] = 'Member groups';
$txt['admin_members'] = 'Hantera medlemmar';
$txt['admin_members_list'] = 'I nedanstående lista återfinns alla medlemmar som för närvarande är registrerade på forumet.';
$txt['admin_next'] = 'Nästa';
$txt['admin_censored_words'] = 'Censurerade ord';
$txt['admin_censored_where'] = 'Enter the word to be censored into the left box and the word to change it to, into the right box. Then select if you want to check the whole word and the case. When you\'re finished with each word, click Save. Multiple entries can be made prior to saving by clicking the \'Add another word\' button.';
$txt['admin_censored_desc'] = 'Due to the public nature of forums there may be some words that you wish to prohibit being posted by users of your forum. You can enter any words below that you wish to be censored whenever used by a member.<br />Clear a box to remove that word from the censor.';
$txt['admin_reserved_names'] = 'Reserverade namn';
$txt['admin_template_edit'] = 'Edit your forum template';
$txt['admin_modifications'] = 'Add-on Settings';
$txt['admin_security_moderation'] = 'Säkerhet och moderation';
$txt['admin_server_settings'] = 'Serverinställningar';
$txt['admin_reserved_set'] = 'Set reserved names';
$txt['admin_reserved_line'] = 'Ett reserverat ord per rad.';
$txt['admin_basic_settings'] = 'På denna sida kan du ändra de grundläggande inställningarna för forumet. Var mycket försiktig med dessa inställningar, då de kan tänkas göra forumet oanvändbart.';
$txt['admin_maintain'] = 'Aktivera underhållsläge?';
$txt['admin_title'] = 'Forumets namn';
$txt['admin_url'] = 'Forumets URL';
$txt['cookie_name'] = 'Cookie name';
$txt['admin_webmaster_email'] = 'Webmaster email address';
$txt['boarddir'] = 'ElkArte Directory';
$txt['sourcesdir'] = 'Källfilskatalog (Sources)';
$txt['cachedir'] = 'Cachekatalog';
$txt['admin_news'] = 'Aktivera nyheter';
$txt['admin_guest_post'] = 'Enable guest posting';
$txt['admin_manage_members'] = 'Medlemmar';
$txt['admin_main'] = 'Start';
$txt['admin_config'] = 'Konfiguration';
$txt['admin_version_check'] = 'Detailed version check';
$txt['admin_elkfile'] = 'ElkArte File';
$txt['admin_elkpackage'] = 'ElkArte Package';
$txt['admin_logoff'] = 'End Admin Session';
$txt['admin_maintenance'] = 'Underhåll';
$txt['admin_image_text'] = 'Visa knappar som bilder istället för text';
$txt['admin_credits'] = 'Erkännanden';
$txt['admin_agreement'] = 'Visa och kräv samtycke av registreringsvillkor vid registrering';
$txt['admin_checkbox_agreement'] = 'Show a checkbox for the agreement in registration form instead of a full page';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Standard';
$txt['admin_agreement_select_language'] = 'Språk att ändra';
$txt['admin_agreement_select_language_change'] = 'Ändra';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Radera markerade medlemmar';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Repair All boards and topics';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Please place one news item per box. BBC tags, such as <span>[b]</span>, <span>[i]</span> and <span>[u]</span> are allowed in your news, as well as smileys. Clear a news item\'s text box to remove it.';
$txt['administrators'] = 'Forumadministratörer';
$txt['admin_reserved_desc'] = 'Reserved names will keep members from registering certain user names or using these words in their displayed names. Choose the options you wish to use from the bottom before submitting.';
$txt['admin_activation_email'] = 'Skicka aktiveringse-post till nya medlemmar efter registrering';
$txt['admin_match_whole'] = 'Sök endast efter hela namn. Om avmarkerat, kommer sökning efter reserverade namn också att göras inne i användarnamn.';
$txt['admin_match_case'] = 'Versal-/gemenkänslig sökning. Om avmarkerat, kommer sökningar inte att göra skillnad på gemener och versaler';
$txt['admin_check_user'] = 'Check user name.';
$txt['admin_check_display'] = 'Kontrollera visade namn.';
$txt['admin_newsletter_send'] = 'You can email anyone from this page. The email addresses of the selected member groups should appear below, but you may remove or add any email addresses you wish. Be sure that each address is separated in this fashion: \'address1; address2\'.';
$txt['admin_fader_delay'] = 'Fördröjning för uttoning mellan varje text i forumnyheterna';
$txt['zero_for_no_limit'] = '(0 för ingen gräns)';
$txt['zero_to_disable'] = '(0 to disable)';

$txt['admin_backup_fail'] = 'Lyckades inte säkerhetskopiera Settings.php - se till att Settings_bak.php existerar och är skrivbar.';
$txt['modSettings_info'] = 'Settings for General features, Karma, Signatures, Likes and much more that control how this forum operates.';
$txt['database_server'] = 'Servernamn för databasen';
$txt['database_user'] = 'Database User';
$txt['database_password'] = 'Lösenord för MySQL-databasen';
$txt['database_name'] = 'Namn på databasen';
$txt['registration_agreement'] = 'Användaravtalet';
$txt['registration_agreement_desc'] = 'Dessa villkor visas när användare registrerar nya användarkonton, och måste godkännas innan användaren kan gå vidare med registreringen.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Tabellprefix för databasen';
$txt['errors_list'] = 'Lista på felmeddelanden på forumet';
$txt['errors_found'] = 'Följande fel genomsyrar ditt forum (listan är tom om det inte finns några fel)';
$txt['errors_fix'] = 'Vill du försöka åtgärda dessa fel?';
$txt['errors_do_recount'] = 'All errors have been fixed and a salvage area has been created. Please click the button below to recount some key statistics.';
$txt['errors_recount_now'] = 'Visa Statistik';
$txt['errors_fixing'] = 'Åtgärdar fel på forumet';
$txt['errors_fixed'] = 'All errors fixed. Please check on any categories, boards, or topics created to decide what to do with them.';
$txt['attachments_avatars'] = 'Bifogade filer och personliga bilder';
$txt['attachments_desc'] = 'Härifrån kan du hantera alla bifogade filer på forumet. Du kan radera bifogade filer utifrån filstorlek eller datum. Statistik för bifogade filer visas nedan.';
$txt['attachment_stats'] = 'File attachment statistics';
$txt['attachment_integrity_check'] = 'Attachment integrity check';
$txt['attachment_integrity_check_desc'] = 'Denna funktion kontrollerar integritet, storlek och filnamn för bifogade filer i databasen, och om nödvändigt korrigerar upphittade fel.';
$txt['attachment_check_now'] = 'Kör kontroll nu';
$txt['attachment_pruning'] = 'Rensning av bifogade filer';
$txt['attachment_pruning_message'] = 'Meddelande att lägga till i inlägget';
$txt['attachment_pruning_warning'] = 'Är du säker på att du vill radera dessa bifogade filer?\\nDetta kan inte göras ogjort.';

$txt['attachment_total'] = 'Total attachments';
$txt['attachmentdir_size'] = 'Total size of all attachment directories';
$txt['attachmentdir_size_current'] = 'Total size of current attachment directory';
$txt['attachmentdir_files_current'] = 'Total files in current attachment directory';
$txt['attachment_space'] = 'Total space available';
$txt['attachment_files'] = 'Total files remaining';

$txt['attachment_options'] = 'Tillval för bifogade filer';
$txt['attachment_log'] = 'Loggfil över bifogade filer';
$txt['attachment_remove_old'] = 'Remove attachments older than %1$s days';
$txt['attachment_remove_size'] = 'Remove attachments larger than %1$s KiB';
$txt['attachment_name'] = 'Attachment name';
$txt['attachment_file_size'] = 'Filstorlek';
$txt['attachmentdir_size_not_set'] = 'Ingen maxstorlek har angivits';
$txt['attachmentdir_files_not_set'] = 'No directory file limit is currently set';
$txt['attachment_delete_admin'] = '[bifogad fil raderad av administratör]';
$txt['live'] = 'Latest Software Updates';
$txt['remove_all'] = 'Clear Log';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(mer detaljerat)';

$txt['lfyi'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['manage_calendar'] = 'Kalender';
$txt['manage_search'] = 'Sök';
$txt['viewmembers_online'] = 'Senast online';

$txt['smileys_manage'] = 'Smileys och smileyuppsättningar';
$txt['smileys_manage_info'] = 'Install new smiley sets, add smileys to existing sets or manage your message icons.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Install, download and upload Modification packages; check File Permissions and FTP settings.';
$txt['theme_admin'] = 'Theme Management';
$txt['theme_admin_info'] = 'Install new themes, select themes that are available for your users and set or reset theme options.';
$txt['registration_center'] = 'Registreringshantering';
$txt['member_center_info'] = 'View the member list, search for members, or manage account approvals and activations.';
$txt['viewmembers_online'] = 'Senast online';

$txt['display_name'] = 'Visat namn';
$txt['email_address'] = 'E-postadress';
$txt['ip_address'] = 'IP-adress';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'okänt';
$txt['security_wrong'] = 'Administration login attempt!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Skicka i HTML-format (med detta val kan du använda normala HTML-koder i ditt e-post-meddelande).';
$txt['email_parsed_html'] = 'Lägg till &lt;br /&gt;s och &amp;nbsp;s till detta meddelande.';
$txt['email_variables'] = 'In this message you can use a few &quot;variables&quot;.<a href="{help_emailmembers}" class="help"> Click here for more information</a>.';
$txt['email_force'] = 'Skicka meddelandet även till användare som valt att inte ta emot tillkännagivanden.';
$txt['email_as_pms'] = 'Skicka till dessa grupper genom privata meddelanden.';
$txt['email_continue'] = 'Fortsätt';
$txt['email_done'] = 'klar.';
$txt['email_members_succeeded'] = 'You have successfully sent your newsletter!';

$txt['ban_title'] = 'Redigera bannlysningslistan';
$txt['ban_ip'] = 'Bannlysning via IP-adress: (ex. 192.168.12.213 eller 128.0.*.*) - en adress per rad';
$txt['ban_email'] = 'Bannlysning via e-postadress: (ex. badguy@somewhere.com) - en adress per rad';
$txt['ban_username'] = 'Bannlysning via användarnamn: (ex. l33tuser) - ett namn per rad';

$txt['ban_errors_detected'] = 'The following error or errors occurred while saving or editing the ban or the trigger';
$txt['ban_description'] = 'Here you can ban troublesome people either by IP, hostname, user name, or email.';
$txt['ban_add_new'] = 'Add new ban';
$txt['ban_banned_entity'] = 'Vad ska bannlysas';
$txt['ban_on_ip'] = 'Bannlys via IP-adress (ex. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Bannlys via servernamn (ex. *.se)';
$txt['ban_on_email'] = 'Bannlys via e-postadress (ex. *@badsite.se)';
$txt['ban_on_username'] = 'Ban on User Name';
$txt['ban_notes'] = 'Anteckningar';
$txt['ban_restriction'] = 'Restriktioner';
$txt['ban_full_ban'] = 'Fullständig bannlysning (helt utelåst)';
$txt['ban_partial_ban'] = 'Delvis bannlysning';
$txt['ban_cannot_post'] = 'Kan inte skriva inlägg';
$txt['ban_cannot_register'] = 'Kan inte registrera nytt användarkonto';
$txt['ban_cannot_login'] = 'Kan inte logga in';
$txt['ban_add'] = 'Lägg till';
$txt['ban_edit_list'] = 'Redigera bannlysningslistan';
$txt['ban_type'] = 'Typ av bannlysning';
$txt['ban_days'] = 'dag(ar)';
$txt['ban_will_expire_within'] = 'Bannlysningen kommer att upphöra om';
$txt['ban_added'] = 'Lagt till';
$txt['ban_expires'] = 'Upphör';
$txt['ban_hits'] = 'Träffar';
$txt['ban_actions'] = 'Åtgärder';
$txt['ban_expiration'] = 'Upphör';
$txt['ban_reason_desc'] = 'Anledning till bannlysningen, som kommer att visas för den bannlysta medlemmen.';
$txt['ban_notes_desc'] = 'Anteckningar/information som kan underlätta för annan personal.';
$txt['ban_remove_selected'] = 'Radera markerade';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Är du säker på att du vill ta bort de markerade bannlysningarna?';
$txt['ban_modify'] = '&auml;ndra';
$txt['ban_name'] = 'Namn på bannlysning';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Redigera bannlysning';
$txt['ban_add_notes'] = '<strong>Obs!</strong> Efter att du skapat ovanstående bannlysning, kan du ställa in fler aspekter som utlöser bannlysningen, som ex. IP-adresser, servernamn och e-postadresser.';
$txt['ban_expired'] = 'Går ut / avstängd';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Inga begränsningar valda.';

$txt['ban_triggers'] = 'Utlösare';
$txt['ban_add_trigger'] = 'Lägg till bannlysningsutlösare';
$txt['ban_add_trigger_submit'] = 'Lägg till';
$txt['ban_edit_trigger'] = '&auml;ndra';
$txt['ban_edit_trigger_title'] = 'ändra bannlysningsutlösare';
$txt['ban_edit_trigger_submit'] = '&auml;ndra';
$txt['ban_remove_selected_triggers'] = 'Radera markerade bannlysningsutlösare';
$txt['ban_no_entries'] = 'Det finns inga aktiva blockningar just nu.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'är du säker på att du vill ta bort alla markerade bannlysningsutlösare?';
$txt['ban_trigger_browse'] = 'Bläddra bannlysningsutlösare';
$txt['ban_trigger_browse_description'] = 'This screen shows all banned entities grouped by IP address, hostname, email address and user name.';

$txt['ban_log'] = 'Bannlysningslogg';
$txt['ban_log_description'] = 'Bannlysningsloggen visar samtliga försök att komma in på forumet från bannlysta användare (\'full bannlysning\' and \'kan inte registrera\'-bannlysning).';
$txt['ban_log_no_entries'] = 'Det finns inga bannlysningsposter i dagsläget.';
$txt['ban_log_ip'] = 'IP-adress';
$txt['ban_log_email'] = 'E-postadress';
$txt['ban_log_member'] = 'Medlem';
$txt['ban_log_date'] = 'Datum';
$txt['ban_log_remove_all'] = 'Clear Log';
$txt['ban_log_remove_all_confirm'] = 'Är du säker på att du vill ta bort alla poster i bannlysningsloggen?';
$txt['ban_log_remove_selected'] = 'Radera markerade';
$txt['ban_log_remove_selected_confirm'] = 'Är du säker på att du vill ta bort markerade poster i bannlysningsloggen?';
$txt['ban_no_triggers'] = 'Det finns inga bannlysningsutlösare i dagsläget.';

$txt['settings_not_writable'] = 'Dessa ändringar kan inte ändras, på grund av att Settings.php för närvarande är skrivskyddad.';

$txt['maintain_title'] = 'Forumunderhåll';
$txt['maintain_info'] = 'Basic forum backups, Database error checking, Clearing the Cache, Integration Hooks and more.';
$txt['maintain_sub_database'] = 'Databas';
$txt['maintain_sub_routine'] = 'Rutin';
$txt['maintain_sub_members'] = 'Medlemmar';
$txt['maintain_sub_topics'] = 'Visa inlägg';
$txt['maintain_sub_attachments'] = 'Visa bifogade filer.';
$txt['maintain_done'] = 'Underhåll avslutad';
$txt['maintain_fail'] = 'The maintenance task \'%1$s\' failed.';
$txt['maintain_no_errors'] = 'Congratulations, no errors were found.  Thanks for checking.';

$txt['maintain_tasks'] = 'Schemalagda uppgifter';
$txt['maintain_tasks_desc'] = 'Manage all the scheduled tasks.';

$txt['scheduled_log'] = 'Schemalogg.';
$txt['scheduled_log_desc'] = 'Lists logs of the tasks that were run.';
$txt['admin_log'] = 'Administratörsloggen';
$txt['admin_log_desc'] = 'Visa en lista över alla administrativa åtgärder som utförts på ditt forum.';
$txt['moderation_log'] = 'Moderatorlogg';
$txt['moderation_log_desc'] = 'Visa en lista över alla moderatorers aktiviteter på ditt forum.';
$txt['badbehavior_log'] = 'Bad Behavior Log';
$txt['badbehavior_log_desc'] = 'Lists requests that were blocked or marked suspicious by bad behavior.  If verbose logging is on all HTTP requests are listed.';
$txt['spider_log_desc'] = 'Visa loggfiler som berör aktivitet hos sökmotorers robotar på ditt forum.';
$txt['pruning_log_desc'] = 'Använd dessa tillbehör för att rensa äldre poster i diverse loggfiler.';

$txt['mailqueue_title'] = 'E-post';

$txt['db_error_send'] = 'Skicka e-post vid felmeddelanden från MySQL-databasen';
$txt['db_persist'] = 'Använd permanenta kopplingar till databasen (s.k. persistent connection)';
$txt['ssi_db_user'] = 'Database user name to use in SSI mode';
$txt['ssi_db_passwd'] = 'Databaslösenord att använda i SSI läge';

$txt['default_language'] = 'Default forum language';

$txt['maintenance_subject'] = 'Ämnesrad på meddelandet';
$txt['maintenance_message'] = 'Meddelande att visa';

$txt['errlog_desc'] = 'Felloggen lagrar alla felmeddelanden som uppstått på forumet, för samtliga medlemmar. För att ta bort fel från listan, kryssa för kryssrutan och klicka på %s-knappen längst ner på sidan.';
$txt['errlog_no_entries'] = 'Det finns för tillfället ingen felloggs meddelande.';

$txt['theme_settings'] = 'Temainställningar';
$txt['theme_edit_settings'] = 'Edit this theme\'s settings';
$txt['theme_current_settings'] = 'Nuvarande tema';

$txt['dvc_your'] = 'Din version';
$txt['dvc_current'] = 'Aktuell version';
$txt['dvc_sources'] = 'Källkod';
$txt['dvc_admin'] = 'Administrationscenter';
$txt['dvc_controllers'] = 'Controllers';
$txt['dvc_database'] = 'Databas';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Standardmallar';
$txt['dvc_templates'] = 'Nuvarande mallar';
$txt['dvc_languages'] = 'Språkfiler';

$txt['smileys_default_set_for_theme'] = 'Select default smiley set for this theme:';
$txt['smileys_no_default'] = 'Use default smiley set';

$txt['censor_test'] = 'Testa censurerade ord';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Ignore case when censoring.';
$txt['censor_whole_words'] = 'Check only whole words.';
$txt['censor_allow'] = 'Allow users to turn off word censoring.';

$txt['admin_confirm_password'] = '(confirm password)';
$txt['admin_incorrect_password'] = 'Inkorrekt lösenord';

$txt['date_format'] = '(ÅÅÅÅ-MM-DD)';
$txt['undefined_gender'] = 'Odefinierat';
$txt['age'] = 'Användarens ålder';
$txt['activation_status'] = 'Aktiveringsstatus';
$txt['activated'] = 'Activated';
$txt['not_activated'] = 'Ej aktiverat';
$txt['is_banned'] = 'Banned';
$txt['primary'] = 'Primär';
$txt['additional'] = 'Ytterligare';
$txt['wild_cards_allowed'] = 'Jokertecken (* och ?) kan användas';
$txt['member_part_of_these_membergroups'] = 'Member is part of these member groups';
$txt['membergroups'] = 'Member groups';
$txt['confirm_delete_members'] = 'Är du säker på att du vill radera de markerade medlemmarna?';

$txt['support_credits_title'] = 'Support &amp; Credits';
$txt['support_credits_info'] = 'Support links for most common issues, the relevant forum version information you will be asked for when you request help and a list of contributors to the ElkArte project.';
$txt['support_title'] = 'Supportinformation';
$txt['support_versions_current'] = 'Current version';
$txt['support_versions_forum'] = 'This version';
$txt['support_versions_db'] = '%1$s-version';
$txt['support_versions_server'] = 'Server-version';
$txt['support_versions_gd'] = 'GD-version';
$txt['support_versions_imagick'] = 'Imagick version';
$txt['support_versions'] = 'Versionsinformation';
$txt['support_resources'] = 'Supportmöjligheter';
$txt['support_resources_p1'] = 'Our <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> provides the main documentation for ElkArte. The ElkArte Online Manual has many documents to help answer support questions and explain <a href="%2$s" target="_blank" class="new_win">Features</a>, <a href="%3$s" target="_blank" class="new_win">Settings</a>, <a href="%4$s" target="_blank" class="new_win">Themes</a>, <a href="%5$s" target="_blank" class="new_win">Packages</a>, etc. The Online Manual documents each area of ElkArte thoroughly and should answer most questions quickly.';
$txt['support_resources_p2'] = 'If you can\'t find the answers to your questions in the Documentation Wiki, you may want to search our <a href="%1$s" target="_blank" class="new_win">Support Community</a> or ask for assistance in our support boards. The ElkArte Support Community can be used for <a href="%2$s" target="_blank" class="new_win">support</a>, <a href="%3$s" target="_blank" class="new_win">customization</a>, and many other things such as discussing ElkArte, finding a host, and discussing administrative issues with other forum administrators.';

$txt['latest_updates'] = 'Latest noteworthy updates';
$txt['new_in_1_0_2'] = 'The most significant change in ElkArte 1.0.2 is avatar permission management. Currently each method of setting an avatar is permission-based, requiring the enabling/disabling of each method for each group. With 1.0.2 avatars are simply enabled/disabled by user group, this allows the enabled groups to add an avatar (by all available methods).<br />
The only permission available is a general one to allow members to change or not their avatars. Additionally there is only one setting for maximum width and height of avatars, these values apply to all avatar methods.<br /><br />
Due to the nature of the changes it was not impossible to migrate existing settings to the new format, for that reason you are encouraged to visit the <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Settings</a> page and set the options you prefer.';

$txt['edit_permissions_info'] = 'Use permission settings to manage global and specific board features and what actions that guest, members and moderators can do.';
$txt['membergroups_members'] = 'Vanliga medlemmar';
$txt['membergroups_guests'] = 'Gäster';
$txt['membergroups_add_group'] = 'Lägg till grupp';
$txt['membergroups_permissions'] = 'Rättigheter';

$txt['permitgroups_restrict'] = 'Restriktiv';
$txt['permitgroups_standard'] = 'Standard';
$txt['permitgroups_moderator'] = 'Moderator';
$txt['permitgroups_maintenance'] = 'Underhåll';

$txt['confirm_delete_attachments'] = 'Är du säker på att du vill radera de markerade bifogade filerna?';
$txt['attachment_manager_browse_files'] = 'Bläddra filer';
$txt['attachment_manager_repair'] = 'Underhåll';
$txt['attachment_manager_avatars'] = 'Personliga bilder (avatars)';
$txt['attachment_manager_attachments'] = 'Visa bifogade filer.';
$txt['attachment_manager_thumbs'] = 'Miniatyrbilder';
$txt['attachment_manager_last_active'] = 'Senast aktiv';
$txt['attachment_manager_member'] = 'Medlem';
$txt['attachment_manager_avatars_older'] = 'Remove avatars from members not active for more than %1$s days';
$txt['attachment_manager_total_avatars'] = 'Total avatars';

$txt['attachment_manager_avatars_no_entries'] = 'Det finns för tillfället inga visningsbilder.';
$txt['attachment_manager_attachments_no_entries'] = 'Det finns för tillfället inga bilagor.';
$txt['attachment_manager_thumbs_no_entries'] = 'Det finns för tillfället inga tumnaglar.';

$txt['attachment_manager_settings'] = 'Inställningar för bifogade filer';
$txt['attachment_manager_avatar_settings'] = 'Inställningar för personliga bilder';
$txt['attachment_manager_browse'] = 'Bläddra filer';
$txt['attachment_manager_maintenance'] = 'Filunderhåll';
$txt['attachmentEnable'] = 'Bifogningsläge';
$txt['attachmentEnable_deactivate'] = 'Inaktivera alla bilagor';
$txt['attachmentEnable_enable_all'] = 'Aktivera alla bilagor';
$txt['attachmentEnable_disable_new'] = 'Inaktivera nya bilagor';
$txt['attachmentCheckExtensions'] = 'Kontrollera filtillägg på bilagor';
$txt['attachmentExtensions'] = 'Tillåtna filtillägg på bilagor';
$txt['attachmentRecodeLineEndings'] = 'Koda om radbrytningar i textbilagor';
$txt['attachmentShowImages'] = 'Visa bifogade bildfiler som bilder under inlägg';
$txt['attachmentUploadDir'] = 'Katalog för bifogade filer';
$txt['attachmentUploadDir_multiple_configure'] = 'Manage attachment directories';
$txt['attachmentDirSizeLimit'] = 'Max attachment directory space';
$txt['attachmentPostLimit'] = 'Max attachment size per post';
$txt['attachmentSizeLimit'] = 'Max size per attachment';
$txt['attachmentNumPerPostLimit'] = 'Max number of attachments per post';
$txt['attachment_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Image re-encoding is not possible.';
$txt['attachment_postsize_warning'] = 'The current php.ini setting \'post_max_size\' may not support this.';
$txt['attachment_filesize_warning'] = 'The current php.ini setting \'upload_max_filesize\' may not support this.';
$txt['attachment_image_reencode'] = 'Omkoda potentiellt farliga bildbilagor';
$txt['attachment_image_reencode_note'] = '(requires GD module or ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'De omfattande säkerhetskontrollerna kan resultera i ett stort antal avvisade bilagor.';
$txt['attachment_image_paranoid'] = 'Utför omfattande säkerhetskontroller av uppladdade bildbilagor';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'Storleksförändra bilder när de visas under inlägg';
$txt['attachment_thumb_png'] = 'Spara miniatyrbilder som PNG';
$txt['attachment_thumb_memory'] = 'Adaptive thumbnail memory';
$txt['attachment_thumb_memory_note2'] = 'If the system can not get the memory no thumbnail will be created.';
$txt['attachment_thumb_memory_note1'] = 'Leave this unchecked to always attempt to create a thumbnail';
$txt['attachmentThumbWidth'] = 'Maximal bredd för miniatyrbilder';
$txt['attachmentThumbHeight'] = 'Maximal höjd för miniatyrbilder';
$txt['attachment_thumbnail_settings'] = 'Thumbnail Settings';
$txt['attachment_security_settings'] = 'Attachment security settings';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Existerar inte';
$txt['attach_dir_not_writable'] = 'Ej skrivbar';
$txt['attach_dir_files_missing'] = 'Files Missing (<a href="{repair_url}">Repair</a>)';
$txt['attach_dir_unused'] = 'Oanvänd';
$txt['attach_dir_empty'] = 'Empty';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Base directory';

$txt['attach_dir_desc'] = 'Create new directories or change the current directory below. Directories can be renamed as long as they do not contain a sub-directory. If the new directory is to be created within the forum directory structure, you\'ll just need to type the directory name. To remove a directory, blank the path input field. Directories can not be deleted if they contain either files or sub-directories (shown in brackets next to the file count).';
$txt['attach_dir_base_desc'] = 'You may use the area below to change the current base directory or create a new one. New base directories are also added to the Attachment Directory list. You may also designate an existing directory to be a base directory.';
$txt['attach_dir_save_problem'] = 'Oops, there seems to be a problem.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory. Please do so using a FTP client or your site file manager.';
$txt['attachments_no_write'] = 'This directory has been created but is not writable. Please attempt to do so using a FTP client or your site file manager.';
$txt['attach_dir_reserved'] = 'Unable to add. This directory is a system directory and cannot be used for attachments.';
$txt['attach_dir_duplicate_msg'] = 'Unable to add. This directory already exists.';
$txt['attach_dir_exists_msg'] = 'Unable to move. A directory already exists at that path.';
$txt['attach_dir_base_dupe_msg'] = 'Unable to add. This base directory has already been created.';
$txt['attach_dir_base_no_create'] = 'Unable to create. Please verify the path input or create this directory using an FTP client or site file manager and re-try.';
$txt['attach_dir_no_rename'] = 'Unable to move or rename. Please verify that the path is correct or that this directory does not contain any sub-directories.';
$txt['attach_dir_no_delete'] = 'Is not empty and can not be deleted. Please do so using a FTP client or site file manager.';
$txt['attach_dir_no_remove'] = 'Still contains files or is a base directory and can not be deleted.';
$txt['attach_dir_is_current'] = 'Unable to remove while it is selected as the current directory.';
$txt['attach_dir_is_current_bd'] = 'Unable to remove while it is selected as the current base directory.';
$txt['attach_last_dir'] = 'Last active attachment directory';
$txt['attach_current_dir'] = 'Current attachment directory';
$txt['attach_current'] = 'Current';
$txt['attach_path_manage'] = 'Manage attachment paths';
$txt['attach_directories'] = 'Attachment Directories';
$txt['attach_paths'] = 'Attachment directory paths';
$txt['attach_path'] = 'Sökväg';
$txt['attach_current_size'] = 'Size (KiB)';
$txt['attach_num_files'] = 'Filer';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Lägg till sökväg';
$txt['attach_path_current_bad'] = 'Nuvarande sökväg till bifogade filer är ogiltig.';
$txt['attachmentDirFileLimit'] = 'Maximum number of files per directory';

$txt['attach_base_paths'] = 'Base directory paths';
$txt['attach_num_dirs'] = 'Directories';
$txt['max_image_width'] = 'Max display width of posted or attached images';
$txt['max_image_height'] = 'Max display height of posted or attached images';

$txt['automanage_attachments'] = 'Choose the method for the management of the attachment directories';
$txt['attachments_normal'] = '(Manual) ElkArte default behaviour';
$txt['attachments_auto_years'] = '(Auto) Subdivide by years';
$txt['attachments_auto_months'] = '(Auto) Subdivide by years and months';
$txt['attachments_auto_days'] = '(Auto) Subdivide by years, months and days';
$txt['attachments_auto_16'] = '(Auto) 16 random directories';
$txt['attachments_auto_16x16'] = '(Auto) 16 random directories with 16 random sub-directories';
$txt['attachments_auto_space'] = '(Auto) When either directory space limit is reached';

$txt['use_subdirectories_for_attachments'] = 'Create new directories within a base directory';
$txt['use_subdirectories_for_attachments_note'] = 'Otherwise any new directories will be created within the forum\'s main directory.';
$txt['basedirectory_for_attachments'] = 'Set a base directory for attachments';
$txt['basedirectory_for_attachments_current'] = 'Current base directory';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Please note that the directory is wrong. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">There seems to be a problem with this directory. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';

$txt['attachment_transfer'] = 'Transfer Attachments';
$txt['attachment_transfer_desc'] = 'Transfer files between directories.';
$txt['attachment_transfer_select'] = 'Select directory';
$txt['attachment_transfer_now'] = 'Transfer';
$txt['attachment_transfer_from'] = 'Transfer files from';
$txt['attachment_transfer_auto'] = 'Move them automatically by space or file count';
$txt['attachment_transfer_auto_select'] = 'Select base directory';
$txt['attachment_transfer_to'] = 'Or move them to a specific directory.';
$txt['attachment_transfer_empty'] = 'Move all files from the source directory.';
$txt['attachment_transfer_no_base'] = 'No base directories available.';
$txt['attachment_transfer_forum_root'] = 'Forum root directory.';
$txt['attachment_transfer_no_room'] = 'Directory size or file count limit reached.';
$txt['attachment_transfer_no_find'] = 'No files were found to transfer.';
$txt['attachments_transfered'] = '%1$d files were transferred to %2$s';
$txt['attachments_not_transfered'] = '%1$d files were not transferred.';
$txt['attachment_transfer_no_dir'] = 'Either the source directory or one of the target options were not selected.';
$txt['attachment_transfer_same_dir'] = 'You cannot select the same directory as both the source and target.';
$txt['attachment_transfer_progress'] = 'Please wait. Transfer in progress.';

$txt['avatar_settings'] = 'General avatar settings';
$txt['avatar_default'] = 'Enable a default avatar for all users without their own avatar';
$txt['avatar_directory'] = 'Katalog för personliga bilder';
$txt['avatar_url'] = 'Internetadress för personliga bilder';
$txt['avatar_max_width'] = 'Maximum width of avatars in pixels (px)';
$txt['avatar_max_height'] = 'Maximum height of avatars in pixels (px)';
$txt['avatar_action_too_large'] = 'Om den personliga bilden är för stor...';
$txt['option_refuse'] = 'Acceptera den inte';
$txt['option_resize'] = 'Let the CSS resize it';
$txt['option_download_and_resize'] = 'Download and resize it (requires GD module or ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Enable use of gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'Använd PNG-format för storleksförändrade personliga bilder?';
$txt['avatar_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Some avatar features are disabled.';
$txt['avatar_external'] = 'Externa personliga bilder';
$txt['avatar_external_enabled'] = 'Enable use of external (remote/URL) avatars';
$txt['avatar_upload'] = 'Uppladdningsbara personliga bilder';
$txt['avatar_resize_options'] = 'Server storage options';
$txt['avatar_upload_enabled'] = 'Enable the upload of avatars';
$txt['avatar_server_stored'] = 'Server-lagrade personliga bilder';
$txt['avatar_stored_enabled'] = 'Enable the selection of server stored avatars';
$txt['profile_set_avatar'] = 'Member groups allowed to select an avatar';
$txt['avatar_select_permission'] = 'Välj rättigheter för varje grupp';
$txt['avatar_download_external'] = 'Ladda hem personliga bilder till angiven adress';
$txt['custom_avatar_enabled'] = 'Ladda upp personliga bilder till...';
$txt['option_attachment_dir'] = 'Katalog för bifogade filer';
$txt['option_specified_dir'] = 'Specifik katalog...';
$txt['custom_avatar_dir'] = 'Katalog för uppladdning';
$txt['custom_avatar_dir_desc'] = 'This should be a valid and writable directory, different than the server-stored directory.';
$txt['custom_avatar_url'] = 'Internetadress för uppladdning';
$txt['custom_avatar_check_empty'] = 'Platsen du angav för din avatar är tom eller ogiltig. Kolla så att det är rätt.';
$txt['avatar_reencode'] = 'Koda om potentiellt farliga avatarer';
$txt['avatar_reencode_note'] = '(kräver GD-modul)';
$txt['avatar_paranoid_warning'] = 'De omfattande säkerhetskontrollerna kan resultera i ett stort antal avvisade avatarer.';
$txt['avatar_paranoid'] = 'Utför omfattande säkerhetskontroller av uppladdade avatarer';

$txt['repair_attachments'] = 'Underhåll bifogade filer';
$txt['repair_attachments_complete'] = 'Underhåll avslutat';
$txt['repair_attachments_complete_desc'] = 'Alla valda fel har rättats till';
$txt['repair_attachments_no_errors'] = 'No errors were found';
$txt['repair_attachments_error_desc'] = 'Följande fel hittades under underhållet. Markera de fel du vill rätta till, och välj Fortsätt.';
$txt['repair_attachments_continue'] = 'Fortsätt';
$txt['repair_attachments_cancel'] = 'Ångra';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d miniatyrbilder tillhör ingen bifogad fil';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d bifogade filer har markerats som att de har miniatyrbilder, men har det i själva verket inte';
$txt['attach_repair_file_missing_on_disk'] = '%1$d bifogade filer eller personliga bilder finns registrerade, men finns inte kvar på servern';
$txt['attach_repair_file_wrong_size'] = '%1$d bifogade filer eller personliga bilder rapporteras som fel filstorlek';
$txt['attach_repair_file_size_of_zero'] = '%1$d bifogade filer eller personliga bilder är tomma. (Dessa kommer att raderas)';
$txt['attach_repair_attachment_no_msg'] = '%1$d bifogade filer tillhör inte längre något inlägg';
$txt['attach_repair_avatar_no_member'] = '%1$d personliga bilder tillhör inte längre någon medlem';
$txt['attach_repair_wrong_folder'] = '%1$d attachments are in the wrong directory';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d files do not have a corresponding entry in the database. (These will be deleted)';

$txt['news_title'] = 'Nyheter och nyhetsbrev';
$txt['news_settings_desc'] = 'Härifrån kan du ändra inställningar och rättigheter relaterade till nyheter och nyhetsbrev.';
$txt['news_mailing_desc'] = 'From this menu you can send messages to all users who\'ve registered and entered their email addresses. You may edit the distribution list, or send messages to all. Useful for important update/news information.';
$txt['news_error_no_news'] = 'Nothing to preview';
$txt['groups_edit_news'] = 'Grupper som får redigera nyhetstexter';
$txt['groups_send_mail'] = 'Grupper som får skicka ut forumnyhetsbrev';
$txt['xmlnews_enable'] = 'Aktivera XML/RSS-nyheter';
$txt['xmlnews_maxlen'] = 'Maximum message length';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Number of items in a news feed';
$txt['xmlnews_maxlen_note'] = '(0 to disable, bad idea.)';
$txt['editnews_clickadd'] = 'Add another item';
$txt['editnews_remove_selected'] = 'Radera markerade';
$txt['editnews_remove_confirm'] = 'Är du säker på att du vill radera den markerade nyheten?';
$txt['censor_clickadd'] = 'Add another word';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Loggar';
$txt['generate_reports'] = 'Skapa rapporter';

$txt['update_available'] = 'Update Available';
$txt['update_message'] = 'You\'re using an outdated version of ElkArte, which contains some bugs which have since been fixed.
	It is recommended that you <a href="#" id="update-link">update your forum</a> to the latest version as soon as possible. It only takes a minute!';

$txt['manageposts'] = 'Inlägg och ämnen';
$txt['manageposts_title'] = 'Hantera inlägg och ämnen';
$txt['manageposts_description'] = 'Härifrån kan du hantera alla inställningar som har att göra med inlägg och ämnen.';

$txt['manageposts_seconds'] = 'sekunder';
$txt['manageposts_minutes'] = 'minuter';
$txt['manageposts_characters'] = 'tecken';
$txt['manageposts_days'] = 'dagar';
$txt['manageposts_posts'] = 'inlägg';
$txt['manageposts_topics'] = 'ämnen';

$txt['pollMode'] = 'Aktivera omröstningar';

$txt['manageposts_settings'] = 'Skrivinställningar';
$txt['manageposts_settings_description'] = 'Här kan du ställa in allt som har att göra med inlägg och skrivande av inlägg.';

$txt['manageposts_bbc_settings'] = 'Forumkod (Bulletin Board Code)';
$txt['manageposts_bbc_settings_description'] = 'Forumkoder, eller s.k. BBC-koder, kan användas för att märka upp meddelanden på forumet. T.ex. kan du skriva ordet \'hus\' med fetstil, genom att skriva [b]hus[/b]. Alla BBC-koder omges av hakparenteser (\'[\' och \']\').';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code settings';

$txt['manageposts_topic_settings'] = 'Ämnesinställningar';
$txt['manageposts_topic_settings_description'] = 'Här kan du ställa in allt som har med ämnen att göra.';

$txt['managedrafts_settings'] = 'Draft Settings';
$txt['managedrafts_settings_description'] = 'Here you can set all settings involving drafts.';
$txt['manage_drafts'] = 'Drafts';

$txt['mail_center'] = 'Maillist Center';
$txt['mm_emailerror'] = 'Failed Emails';
$txt['mm_emailfilters'] = 'Filters';
$txt['mm_emailparsers'] = 'Parsers';
$txt['mm_emailtemplates'] = 'Templates';
$txt['mm_emailsettings'] = 'Inställningar';

$txt['removeNestedQuotes'] = 'Ta bort nästlade citat när användare citerar';
$txt['enableSpellChecking'] = 'Aktivera stavningskontroll';
$txt['enableSpellChecking_warning'] = 'this does not work on all servers.';
$txt['enableSpellChecking_error'] = 'this does not work on your server.';
$txt['enableVideoEmbeding'] = 'Enable auto-embedding of video links.';
$txt['enableCodePrettify'] = 'Enable prettifying of code tags';
$txt['max_messageLength'] = 'Max antal tillåtna tecken i inlägg';
$txt['max_messageLength_zero'] = '0 för ingen begränsning';
$txt['convert_to_mediumtext'] = 'Your database is not setup to accept messages longer than 65535 characters. Please use the <a href="%1$s">database maintenance</a> page to convert the database and then come back to increase the maximum allowed post size.';
$txt['topicSummaryPosts'] = 'Antal inlägg som ska visas vid ämnessammanfattningar';
$txt['spamWaitTime'] = 'Minsta tillåtna tid mellan inlägg från samma IP-adress';
$txt['edit_wait_time'] = 'Hur lång tid innan ändringar i inlägg börjar stämplas med \'Redigerad av\'';
$txt['edit_disable_time'] = 'Max tillåten tid efter postande som inlägg kan redigeras';
$txt['edit_disable_time_zero'] = '0 för att inaktivera';
$txt['preview_characters'] = 'Maximum length of last/first post preview';
$txt['preview_characters_units'] = 'tecken';
$txt['preview_characters_zero'] = '0 to show the entire message';
$txt['message_index_preview'] = 'Show post previews on the message index';
$txt['message_index_preview_off'] = 'Do not show the previews';
$txt['message_index_preview_first'] = 'Show the text of the first post';
$txt['message_index_preview_last'] = 'Show the text of the last post';

$txt['enableBBC'] = 'Aktivera forumkoder (BBC)';
$txt['enablePostHTML'] = 'Aktivera <em>grundläggande</em> HTML-kod i inlägg';
$txt['autoLinkUrls'] = 'Automatlänka Internetadresser i inlägg';
$txt['disabledBBC'] = 'Aktiverade BBC-koder';
$txt['bbcTagsToUse'] = 'Aktiverade BBC-koder';
$txt['bbcTagsToUse_select'] = 'Välj vilka koder som kan användas';
$txt['bbcTagsToUse_select_all'] = 'Markera samtliga';

$txt['enableParticipation'] = 'Aktivera medverkandeikoner';
$txt['enableFollowup'] = 'Enable followups';
$txt['enable_unwatch'] = 'Enable unwatching of topics';
$txt['oldTopicDays'] = 'Antal dagar innan det varnas för att ett ämne är gammalt vid svar';
$txt['oldTopicDays_zero'] = '0 för att inaktivera';
$txt['defaultMaxTopics'] = 'Antal ämnen per sida på tavlor';
$txt['defaultMaxMessages'] = 'Antal inlägg per sida i ämnen';
$txt['disable_print_topic'] = 'Disable print topic feature';
$txt['hotTopicPosts'] = 'Antal inlägg för att klassas som hett ämne';
$txt['hotTopicVeryPosts'] = 'Antal inlägg för att klassas som mycket hett ämne';
$txt['useLikesNotViews'] = 'Use number of likes in place of posts to define hot topics';
$txt['enableAllMessages'] = 'Max antal inlägg för att kunna visa &quot;Alla&quot; inlägg';
$txt['enableAllMessages_zero'] = '0 för att aldrig visa &quot;Alla&quot;';
$txt['disableCustomPerPage'] = 'Inaktivera möjlighet för användare att välja antal ämnen/svar per sida';
$txt['enablePreviousNext'] = 'Aktivera föregående/nästa-länkar';

$txt['not_done_title'] = 'Not done yet';
$txt['not_done_reason'] = 'För att undvika att servern blir överbelastad, har processen tillfälligt avbrutits. Den bör återstartas automatiskt om några sekunder. Om det inte gör det, klicka här nedan.';
$txt['not_done_continue'] = 'Fortsätt';

$txt['general_settings'] = 'Allmänt';
$txt['database_paths_settings'] = 'Databas och sökvägar';
$txt['cookies_sessions_settings'] = 'Cookies och sessioner';
$txt['caching_settings'] = 'Cachning';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Local Settings';
$txt['phpinfo_defaultsettings'] = 'Default Settings';
$txt['phpinfo_itemsettings'] = 'Inställningar';

$txt['language_configuration'] = 'Språk';
$txt['language_description'] = 'This section allows you to edit languages installed on your forum or download new ones from the ElkArte site. You may also edit language-related settings here.';
$txt['language_edit'] = 'Redigera språk';
$txt['language_add'] = 'Lägg till språk';
$txt['language_settings'] = 'Inställningar';

$txt['advanced'] = 'Avancerad';
$txt['simple'] = 'Enkel';

$txt['admin_news_select_recipients'] = 'Välj vem som ska få nyhetsbrevet';
$txt['admin_news_select_group'] = 'Member groups';
$txt['admin_news_select_group_desc'] = 'Välj vilka grupper som ska få nyhetsbrevet.';
$txt['admin_news_select_members'] = 'Medlemmar';
$txt['admin_news_select_members_desc'] = 'Additional members to receive the newsletter.';
$txt['admin_news_select_excluded_members'] = 'Uteslutna medlemmar';
$txt['admin_news_select_excluded_members_desc'] = 'Members who should not receive the newsletter.';
$txt['admin_news_select_excluded_groups'] = 'Uteslutna grupper';
$txt['admin_news_select_excluded_groups_desc'] = 'Välj grupper som absolut inte ska få nyhetsbrevet.';
$txt['admin_news_select_email'] = 'E-postadresser';
$txt['admin_news_select_email_desc'] = 'A semi-colon separated list of email addresses which should be sent this newsletter. (i.e. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Override notification settings';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Du kan inte skicka ett privat meddelande till en e-postadress. Om du fortsätter kommer alla e-postadresser att hoppas över.\\n\\nVill du göra det här?';

$txt['mailqueue_browse'] = 'Visa e-postkön';
$txt['mailqueue_settings'] = 'Inställningar';

$txt['admin_search'] = 'Snabbsök';
$txt['admin_search_type_internal'] = 'Uppgift/Inställning';
$txt['admin_search_type_member'] = 'Medlem';
$txt['admin_search_type_online'] = 'Onlinemanual';
$txt['admin_search_go'] = 'OK';
$txt['admin_search_results'] = 'Sökresultat';
$txt['admin_search_results_desc'] = 'Resultat av din sökning: &quot;%1$s&quot; ';
$txt['admin_search_results_again'] = 'Sök igen';
$txt['admin_search_results_none'] = 'No results found.';

$txt['admin_search_section_sections'] = 'Avdelning';
$txt['admin_search_section_settings'] = 'Inställningar';

$txt['core_settings_title'] = 'Grundläggande inställningar';
$txt['core_settings_desc'] = 'This page allows you to turn on or off optional features of your forum.';
$txt['mods_cat_features'] = 'Allmänt';
$txt['mods_cat_security_general'] = 'Allmänt';
$txt['antispam_title'] = 'Spamskydd';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Blandat';
$txt['mods_cat_layout'] = 'Layout ';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderation';
$txt['signature_settings_short'] = 'Signaturer';
$txt['custom_profile_shorttitle'] = 'Profilfält';
$txt['pruning_title'] = 'Loggrensning';

$txt['core_settings_activation_message'] = 'The feature {core_feature} has been activated, click on the title to configure it';
$txt['core_settings_deactivation_message'] = 'The feature {core_feature} has been deactivated';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Hantera tavlor';
$txt['mboards_new_cat'] = 'Create new category';
$txt['manage_holidays'] = 'Hantera högtider';
$txt['calendar_settings'] = 'Kalenderinställningar';
$txt['search_weights'] = 'Vikter';
$txt['search_method'] = 'Sökmetod';
$txt['search_sphinx'] = 'Configure Sphinx';

$txt['smiley_sets'] = 'Smileyuppsättning';
$txt['smileys_add'] = 'Lägg till smiley';
$txt['smileys_edit'] = 'Ändra smileys';
$txt['smileys_set_order'] = 'Set Smiley order';
$txt['icons_edit_message_icons'] = 'Edit message icons';

$txt['membergroups_new_group'] = 'Add Member Group';
$txt['membergroups_edit_groups'] = 'Edit Member Groups';
$txt['permissions_groups'] = 'Allmänna rättigheter';
$txt['permissions_boards'] = 'Tavelrättigheter';
$txt['permissions_profiles'] = 'Redigera profiler';
$txt['permissions_post_moderation'] = 'Inläggsmoderering';

$txt['browse_packages'] = 'Visa paket';
$txt['download_packages'] = 'Ladda ner paket';
$txt['upload_packages'] = 'Upload Package';
$txt['installed_packages'] = 'Installerade paket';
$txt['package_file_perms'] = 'Filrättigheter';
$txt['package_settings'] = 'Inställningar';
$txt['package_servers'] = 'Package Servers';
$txt['themeadmin_admin_title'] = 'Hantera och installera';
$txt['themeadmin_list_title'] = 'Temainställningar';
$txt['themeadmin_reset_title'] = 'Medlemsvalmöjligheter';
$txt['themeadmin_edit_title'] = 'Redigera teman';
$txt['admin_browse_register_new'] = 'Register new member';

$txt['search_engines'] = 'Sökmotorer';
$txt['spider_logs'] = 'Loggfil';
$txt['spider_stats'] = 'Statistik';

$txt['paid_subscriptions'] = 'Betalda prenumerationer';
$txt['paid_subs_view'] = 'Visa Prenumerationer';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks';
$txt['hooks_field_hook_name'] = 'Hook Name';
$txt['hooks_field_function_name'] = 'Function Name';
$txt['hooks_field_function'] = 'Function';
$txt['hooks_field_included_file'] = 'Included file';
$txt['hooks_field_file_name'] = 'Filnamn';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Exists';
$txt['hooks_disabled'] = 'Avstängt'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Not found';
$txt['hooks_no_hooks'] = 'There are currently no hooks in the system.';
$txt['hooks_disable_legend'] = 'Betydelser';
$txt['hooks_disable_legend_exists'] = 'the hook exists and is active';
$txt['hooks_disable_legend_disabled'] = 'the hook exists but has been disabled';
$txt['hooks_disable_legend_missing'] = 'the hook has not been found';
$txt['hooks_reset_filter'] = 'Reset filter';

$txt['board_perms_allow'] = 'Tillåt';
$txt['board_perms_ignore'] = 'Ignorera';
$txt['board_perms_deny'] = 'Neka';
$txt['all_boards_in_cat'] = 'All boards in this category';

$txt['url'] = 'Adress';
$txt['words_sep'] = 'Words separator';

$txt['admin_order_title'] = 'Ordering Error';
$txt['admin_order_error'] = 'An unknown error occurred while processing your request';

// Known controllers that can work on the front page
$txt['default'] = 'Standard';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
