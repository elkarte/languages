<?php
// Version: 1.1; ManageSmileys

$txt['smiley_sets_save'] = 'Spara ändringar';
$txt['smiley_sets_add'] = 'New Smiley Set';
$txt['smiley_sets_delete'] = 'Radera markerade';
$txt['smiley_sets_confirm'] = '&Auml;r du s&auml;ker p&aring; att du vill radera denna smiley-upps&auml;ttning?\\n\\nNote: Detta kommer inte att radera sj&auml;lva bilderna, utan bara m&ouml;jligheten att v&auml;lja dem.';
$txt['smiley_sets_none'] = 'There are currently no smiley sets.';

$txt['setting_smiley_sets_default'] = 'Standard-smileyupps&auml;ttning';
$txt['setting_smiley_sets_enable'] = 'Aktivera val av smiley-upps&auml;ttningar f&ouml;r medlemmar';
$txt['setting_smiley_enable'] = 'Anv&auml;nd anpassade smileys';
$txt['setting_smileys_url'] = 'Basadress f&ouml;r alla smiley-upps&auml;ttningar';
$txt['setting_smileys_dir'] = 'Absolut s&ouml;kv&auml;g till alla smiley-upps&auml;ttningar';
$txt['setting_messageIcons_enable'] = 'Aktivera anpassade meddelandeikoner';
$txt['setting_messageIcons_enable_note'] = '(annars kommer standardikonerna att anv&auml;ndas)';
$txt['groups_manage_smileys'] = 'Grupper som f&aring;r hantera smileys och meddelandeikoner';

$txt['smiley_sets_name'] = 'Namn';
$txt['smiley_sets_url'] = 'Adress';
$txt['smiley_sets_default'] = 'Standard';

$txt['smileys_add_method'] = 'Bildk&auml;lla';
$txt['smileys_add_existing'] = 'Use existing file';
$txt['smileys_add_upload'] = 'Upload new smiley';
$txt['smileys_add_upload_choose'] = 'Fil att ladda upp';
$txt['smileys_add_upload_choose_desc'] = 'Bild att anv&auml;nda f&ouml;r alla smiley-upps&auml;ttningar';
$txt['smileys_add_upload_all'] = 'Samma bild f&ouml;r alla upps&auml;ttningar';
$txt['smileys_add_upload_for1'] = 'Bild f&ouml;r upps&auml;ttningen';
$txt['smileys_add_upload_for2'] = 'set';

$txt['smileys_enable_note'] = '(annars kommer standard-smileysarna att anv&auml;ndas)';
$txt['smileys_code'] = 'Kod';
$txt['smileys_filename'] = 'Filnamn';
$txt['smileys_description'] = 'Beskrivning (visas n&auml;r man f&ouml;r muspekaren &ouml;ver)';
$txt['smileys_remove'] = 'Ta bort';
$txt['smileys_save'] = 'Spara ändringar';
$txt['smileys_delete'] = 'Radera smiley';
// Don't use entities in the below string.
$txt['smileys_delete_confirm'] = 'Är du säker på att du vill radera denna smiley?';
$txt['smileys_with_selected'] = 'Med markerade';
$txt['smileys_make_hidden'] = 'G&ouml;r till dolda';
$txt['smileys_show_on_post'] = 'Show on post form';
$txt['smileys_show_on_popup'] = 'Show on popup';

$txt['smiley_settings_explain'] = 'Dessa &auml;ndringar l&aring;ter dig &auml;ndra standardupps&auml;ttningen med smileys, l&aring;ter folk anv&auml;nda sina egna smileys samt l&aring;ter dig &auml;ndra s&ouml;kv&auml;gar och konfigurera.';
$txt['smiley_editsets_explain'] = 'Smiley-upps&auml;ttningar &auml;r grupper av s.k. smileys, som dina anv&auml;ndare kan v&auml;lja mellan. Exempelvis kanske du har en r&ouml;d upps&auml;ttning och en gul upps&auml;ttning av smileys.<br />H&auml;r kan du st&auml;lla in namn och adress till alla smiley-upps&auml;ttningar - kom dock ihåg att alla smiley-uppsättningar delar på samma smileys.';
$txt['smiley_editsmileys_explain'] = 'Change your smileys here by clicking on the smiley you want to modify. Remember that these smileys all have to exist in all the sets or some smileys won\'t show up.  Don\'t forget to save after you are done editing.';
$txt['smiley_setorder_explain'] = '&Auml;ndra ordningen av smileysarna h&auml;r.';
$txt['smiley_addsmiley_explain'] = 'H&auml;r kan du l&auml;gga till en ny smiley - antingen fr&aring;n en befintlig fil, eller genom att ladda upp en ny.';

$txt['smiley_set_select_default'] = 'Standard-smileyupps&auml;ttning';
$txt['smiley_set_new'] = 'Create new Smiley Set';
$txt['smiley_set_modify_existing'] = 'Modify existing Smiley Set';
$txt['smiley_set_modify'] = '&auml;ndra';
$txt['smiley_set_import_directory'] = 'Importera smileys som redan finns i denna katalog';
$txt['smiley_set_import_single'] = 'Det finns en smiley i denna smiley-upps&auml;ttning som &auml;nnu inte importerats Klicka';
$txt['smiley_set_import_multiple'] = 'Det finns %1$d smileys i denna katalog som ännu inte har importerats. Klicka';
$txt['smiley_set_to_import_single'] = 'f&ouml;r att importera den nu.';
$txt['smiley_set_to_import_multiple'] = 'f&ouml;r att importera dem nu.';

$txt['smileys_location'] = 'S&ouml;kv&auml;g';
$txt['smileys_location_form'] = 'Skriv inl&auml;gg-formul&auml;r';
$txt['smileys_location_hidden'] = 'Dolda';
$txt['smileys_location_popup'] = 'Popup-f&ouml;nster';
$txt['smileys_modify'] = '&auml;ndra';
$txt['smileys_not_found_in_set'] = 'Smileyn finns inte i smiley-upps&auml;ttningen';
$txt['smileys_default_description'] = '(L&auml;gg till beskrivning)';
$txt['smiley_new'] = 'L&auml;gg till ny smiley';
$txt['smiley_modify_existing'] = 'Modifiera smiley';
$txt['smiley_preview'] = 'Förhandsgranska';
$txt['smiley_preview_using'] = 'anv&auml;nder smiley-upps&auml;ttning';
$txt['smileys_confirm'] = '&Auml;r du s&auml;ker p&aring; att du vill radera dessa smileys?\\n\\nOBS! Detta kommer inte att radera sj&auml;lva bilderna, utan bara m&ouml;jligheten att v&auml;lja dem.';
$txt['smileys_location_form_description'] = 'Dessa smileys kommer att synas ovanf&ouml;r textrutan, n&auml;r du skriver foruminl&auml;gg eller privata meddelanden.';
$txt['smileys_location_popup_description'] = 'Dessa smileys kommer att visas i ett popup-f&ouml;nster, som visas efter att anv&auml;ndaren klickat p&aring; \'[fler]\'';
$txt['smileys_move_select_destination'] = 'V&auml;lj smiley-m&aring;l';
$txt['smileys_move_select_smiley'] = 'Select smiley to move or drag it to the location you want';
$txt['smileys_move_here'] = 'Flytta smiley till denna plats';
$txt['smileys_no_entries'] = 'Just nu finns det inga smileys.';
$txt['smileys_moved_done'] = 'Smiley successfully moved';
$txt['smileys_moved_fail'] = 'Unable to move smiley';

$txt['icons_edit_icons_explain'] = 'H&auml;rifr&aring;n kan du &auml;ndra vilka meddelandeikoner som ska finnas tillg&auml;ngliga p&aring; forumet. Du kan l&auml;gga till, redigera och ta bort ikoner, samt begr&auml;nsa anv&auml;ndning till vissa tavlor.';
$txt['icons_edit_icons_all_boards'] = 'Available in all boards';
$txt['icons_board'] = 'Tavla';
$txt['icons_confirm'] = 'Är du s&auml;ker p&aring; att du vill ta bort dessa ikoner?\\n\\nObservera att detta enbart f&ouml;rhindrar anv&auml;ndning fr.o.m. nu, bilderna i sig f&ouml;rsvinner inte.';
$txt['icons_add_new'] = 'Add new icon';

$txt['icons_edit_icon'] = 'Edit message icon';
$txt['icons_new_icon'] = 'New message icon';
$txt['icons_location_first_icon'] = 'As first icon';
$txt['icons_location_after'] = 'Efter';
$txt['icons_filename_all_png'] = 'All files must be &quot;png&quot; files';
$txt['icons_no_entries'] = 'Just nu finns inga meddelandeikoner.';
$txt['icons_reordered'] = 'Message Icons successfully reordered';
$txt['icons_reorder_note'] = 'You can change the message icon order by dragging and dropping an item to a new location in the list.';