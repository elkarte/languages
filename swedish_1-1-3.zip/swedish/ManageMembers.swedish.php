<?php
// Version: 1.1; ManageMembers

$txt['groups'] = 'Grupper';
$txt['viewing_groups'] = 'Visar medlemsgrupper';

$txt['membergroups_title'] = 'Hantera medlemsgrupper';
$txt['membergroups_description'] = 'Medlemsgrupper är grupper med medlemmar som har liknande rättigheter, utseende eller åtkomsträtt. En del medlemsgrupper baseras på antal inlägg som en användare har skrivit. Du kan lägga till någon till en medlemsgrupp genom att gå till dennes profil, och ändra kontoinställningarna.';
$txt['membergroups_modify'] = '&auml;ndra';
$txt['membergroups_modify_parent'] = 'Modify parent group';

$txt['membergroups_add_group'] = 'Lägg till grupp';
$txt['membergroups_regular'] = 'Allmänna grupper';
$txt['membergroups_post'] = 'Inläggsbaserade grupper';
$txt['membergroups_guests_na'] = 'n/a';

$txt['membergroups_group_name'] = 'Namn på medlemsgruppen';
$txt['membergroups_new_board'] = 'Synliga tavlor';
$txt['membergroups_new_board_desc'] = 'Tavlor som medlemsgruppen kan se.';
$txt['membergroups_new_board_post_groups'] = '<em>Obs: Vanligtvis behöver inte inläggsgrupper någon behörighet, eftersom den vanliga medlemsgruppen som medlemmen tillhör ger behörigheter.</em>';
$txt['membergroups_new_as_inherit'] = 'ärv från';
$txt['membergroups_new_as_type'] = 'av typen';
$txt['membergroups_new_as_copy'] = 'baserad på';
$txt['membergroups_new_copy_none'] = '(ingen)';
$txt['membergroups_can_edit_later'] = 'Du kan ändra detta senare';

$txt['membergroups_edit_group'] = 'Redigera medlemsgrupp';
$txt['membergroups_edit_name'] = 'Namn på medlemsgruppen';
$txt['membergroups_edit_inherit_permissions'] = 'Ärv rättigheter';
$txt['membergroups_edit_inherit_permissions_desc'] = 'Välj &quot;Nej&quot; för att möjliggöra för en grupp att ha egna rättigheter.';
$txt['membergroups_edit_inherit_permissions_no'] = 'Nej - använd unika rättigheter';
$txt['membergroups_edit_inherit_permissions_from'] = 'Ärv från';
$txt['membergroups_edit_hidden'] = 'Synlighet';
$txt['membergroups_edit_hidden_no'] = 'Synligt';
$txt['membergroups_edit_hidden_boardindex'] = 'Visible - Apart from in group key';
$txt['membergroups_edit_hidden_all'] = 'Osynligt';
// Do not use numeric entities in the below string.
$txt['membergroups_edit_hidden_warning'] = 'Är du säker på att du inte vill tillåta tilldelning av denna grupp som en användares huvudsakliga medlemsgrupp?\\n\\nDet kommer att begränsa så att gruppen bara kan användas som ytterligare (sekundära) medlemsgrupper, och kommer att uppdatera alla nuvarande huvudsakliga medlemmar att bara ha gruppen som ytterligare medlemsgrupp.';
$txt['membergroups_edit_desc'] = 'Gruppbeskrivning';
$txt['membergroups_edit_group_type'] = 'Group type';
$txt['membergroups_edit_select_group_type'] = 'Select Group type';
$txt['membergroups_group_type_private'] = 'Privat <span class="smalltext">(Medlemskap måste tilldelas)</span>';
$txt['membergroups_group_type_protected'] = 'Skyddat<span class="smalltext">(Endast administratör kan hantera och tilldela)</span> ';
$txt['membergroups_group_type_request'] = 'Ansökningsbar <span class="smalltext">(Användare kan ansöka om medlemsskap)</span>';
$txt['membergroups_group_type_free'] = 'Öppet <span class="smalltext">(Användare kan gå med och lämma gruppen som de vill)</span>';
$txt['membergroups_group_type_post'] = 'Inläggsbaserat <span class="smalltext">(Medlemskap utifrån antal skrivna inlägg)</span>';
$txt['membergroups_min_posts'] = 'Minsta antalet inlägg som krävs';
$txt['membergroups_online_color'] = 'Färg i online-listan';
$txt['membergroups_icon_count'] = 'Number of icon images';
$txt['membergroups_icon_image'] = 'Icon image filename';
$txt['membergroups_icon_image_note'] = 'Upload icon images in to the default theme directory to enable selection.<br />Select the icon to change it.';
$txt['membergroups_max_messages'] = 'Max antal privata meddelanden';
$txt['membergroups_max_messages_note'] = '(0 = obegränsat)';
$txt['membergroups_max_messages_desc'] = 'Here you can set the limit of personal messages a user can keep on the server.<br />
To allow store an unlimited number of personal messages, you can set the value to 0';
$txt['membergroups_edit_save'] = 'Spara';
$txt['membergroups_delete'] = 'Radera';
$txt['membergroups_confirm_delete'] = 'Are you sure you want to delete this group?';

$txt['membergroups_members_title'] = 'Visar alla medlemmar i gruppen';
$txt['membergroups_members_group_members'] = 'Gruppmedlemmar';
$txt['membergroups_members_no_members'] = 'Denna grupp är för närvarande tom';
$txt['membergroups_members_add_title'] = 'Lägg till en medlem till denna grupp';
$txt['membergroups_members_add_desc'] = 'Lista över medlemmar att lägga till';
$txt['membergroups_members_add'] = 'Lägg till medlemmar';
$txt['membergroups_members_remove'] = 'Ta bort från grupp';
$txt['membergroups_members_last_active'] = 'Senast aktiv';
$txt['membergroups_members_additional_only'] = 'Lägg till som ytterligare grupp.';
$txt['membergroups_members_group_moderators'] = 'Gruppmoderatorer';
$txt['membergroups_members_description'] = 'Beskrivning';
// Use javascript escaping in the below.
$txt['membergroups_members_deadmin_confirm'] = 'Vill du verkligen ta bort dig själv från Administratör gruppen?';

$txt['membergroups_postgroups'] = 'Inläggsbaserade medlemsgrupper';
$txt['membergroups_settings'] = 'Medlemsgruppsinställningar';
$txt['groups_manage_membergroups'] = 'Grupper som har behörighet att ändra medlemsgrupper';
$txt['membergroups_select_permission_type'] = 'Välj rättighetsprofil';
$txt['membergroups_images_url'] = '{theme URL}/images/group_icons/';
$txt['membergroups_select_visible_boards'] = 'Visa tavlor';
$txt['membergroups_members_top'] = 'Medlemmar';
$txt['membergroups_name'] = 'Namn';
$txt['membergroups_icons'] = 'Icons';

$txt['admin_browse_approve'] = 'Medlemmar vars konton väntar på godkännande';
$txt['admin_browse_approve_desc'] = 'Härifrån kan du hantera alla medlemmar som väntar på att deras konton ska godkännas.';
$txt['admin_browse_activate'] = 'Medlemmar vars konton väntar på att aktiveras';
$txt['admin_browse_activate_desc'] = 'Dennma skärm visar alla medlemmar som fortfarande inte har aktiverat sina konton på forumet.';
$txt['admin_browse_awaiting_approval'] = 'Awaiting Approval [%1$d]';
$txt['admin_browse_awaiting_activate'] = 'Awaiting Activation [%1$d]';

$txt['admin_browse_username'] = 'Användarnamn';
$txt['admin_browse_email'] = 'E-postadress';
$txt['admin_browse_ip'] = 'IP-adress';
$txt['admin_browse_registered'] = 'Registrerad';
$txt['admin_browse_id'] = 'ID';
$txt['admin_browse_with_selected'] = 'Med markerade';
$txt['admin_browse_no_members_approval'] = 'Inga medlemmar väntar på godkännande för närvarande.';
$txt['admin_browse_no_members_activate'] = 'Det finns inga medlemmar som inte har aktiverat sina konton.';

// Don't use entities in the below strings, except the main ones. (lt, gt, quot.)
$txt['admin_browse_warn'] = 'alla markerade medlemmar?';
$txt['admin_browse_outstanding_warn'] = 'alla berörda medlemmar?';
$txt['admin_browse_w_approve'] = 'Godkänn';
$txt['admin_browse_w_activate'] = 'Aktivera';
$txt['admin_browse_w_delete'] = 'Radera';
$txt['admin_browse_w_reject'] = 'Reject (Delete)';
$txt['admin_browse_w_remind'] = 'Påminn';
$txt['admin_browse_w_approve_deletion'] = 'Godkänn (radera konton)';
$txt['admin_browse_w_email'] = 'och skicka e-post';
$txt['admin_browse_w_approve_require_activate'] = 'Approve and require activation';

$txt['admin_browse_filter_by'] = 'Filtrera genom';
$txt['admin_browse_filter_show'] = 'Visar';
$txt['admin_browse_filter_type_0'] = 'Unactivated new accounts';
$txt['admin_browse_filter_type_2'] = 'Unactivated email changes';
$txt['admin_browse_filter_type_3'] = 'Unapproved new accounts';
$txt['admin_browse_filter_type_4'] = 'Unapproved account deletions';
$txt['admin_browse_filter_type_5'] = 'Ej godkända "minderåriga" konton';

$txt['admin_browse_outstanding'] = 'Ofullständiga medlemmar';
$txt['admin_browse_outstanding_days_1'] = 'Med alla medlemmar som registrerade sig längre än';
$txt['admin_browse_outstanding_days_2'] = 'dagar sedan';
$txt['admin_browse_outstanding_perform'] = 'Vidta följande åtgärd';
$txt['admin_browse_outstanding_go'] = 'Genomför åtgärd';

$txt['check_for_duplicate'] = 'Check for duplicates';
$txt['dont_check_for_duplicate'] = 'Don\'t check for duplicates';
$txt['duplicates'] = 'Dubletter';

$txt['not_activated'] = 'Ej aktiverat';