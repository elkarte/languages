<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Ställ in sökparametrar';
$txt['choose_board'] = 'Välj en tavla att söka i, eller sök alla';
$txt['all_words'] = 'Matcha alla ord';
$txt['any_words'] = 'Matcha något ord';
$txt['by_user'] = 'Av användare';

$txt['search_post_age'] = 'Hur gamla inläggen får vara';
$txt['search_between'] = 'mellan';
$txt['search_and'] = 'och';
$txt['search_options'] = 'Inställningar';
$txt['search_show_complete_messages'] = 'Visa resultat som inlägg';
$txt['search_subject_only'] = 'Sök endast i ämnesrubriker';
$txt['search_relevance'] = 'Relevans';
$txt['search_date_posted'] = 'Skrivet';
$txt['search_order'] = 'Sortera resultat';
$txt['search_orderby_relevant_first'] = 'Mest relevanta sökresultat först';
$txt['search_orderby_large_first'] = 'Största ämnena först';
$txt['search_orderby_small_first'] = 'Minsta ämnena först';
$txt['search_orderby_recent_first'] = 'Nyaste ämnena först';
$txt['search_orderby_old_first'] = 'Äldsta ämnena först';
$txt['search_visual_verification_label'] = 'Verifiering';
$txt['search_visual_verification_desc'] = 'Skriv in bokstäverna som visas i nedanstående bild för att använda sökningen.';

$txt['search_specific_topic'] = 'Leta bara efter inlägg i ämnet';

$txt['groups_search_posts'] = 'Medlemsgrupper som kan komma åt sökfunktionen';
$txt['search_dropdown'] = 'Enable the Quick Search dropdown';
$txt['search_results_per_page'] = 'Antal sökresultat per sida';
$txt['search_weight_frequency'] = 'Relativ sökvikt för antal inlägg som matchar inom ett ämne';
$txt['search_weight_age'] = 'Relativ sökvikt för hur gammalt det senaste matchande inlägget är';
$txt['search_weight_length'] = 'Relativ sökvikt för ämnets storlek';
$txt['search_weight_subject'] = 'Relativ sökvikt för matchande rubrik';
$txt['search_weight_first_message'] = 'Relativ sökvikt för ämnen där första inlägget matchar';
$txt['search_weight_sticky'] = 'Relative search weight for a pinned topic';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Here you can change the basic settings of the search function.';
$txt['search_settings_title'] = 'Search Settings';

$txt['search_weights_desc'] = 'Here you can change the individual components of the relevance rating.';
$txt['search_weights_sphinx'] = 'To update weight factors with Sphinx, you must generate and install a new sphinx.conf file.';
$txt['search_weights_title'] = 'Sök - vikter';
$txt['search_weights_total'] = 'Totalt';
$txt['search_weights_save'] = 'Spara';

$txt['search_method_desc'] = 'Här kan du ange på vilket sätt som sökningarna ska ske.';
$txt['search_method_title'] = 'Sök - metod';
$txt['search_method_save'] = 'Spara';
$txt['search_method_messages_table_space'] = 'Utrymme som används av forumets inlägg i databasen';
$txt['search_method_messages_index_space'] = 'Utrymme som används av index för inläggen i databasen';
$txt['search_method_kilobytes'] = 'kB';
$txt['search_method_fulltext_index'] = 'Fulltext-index';
$txt['search_method_no_index_exists'] = 'finns inte för närvarande';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'kan inte skapas, då den längsta längden på inläggen överstiger 65&nbsp;536 tecken eller tabelltypen inte är MyISAM';
$txt['search_method_index_already_exists'] = 'har redan skapats';
$txt['search_method_fulltext_remove'] = 'Ta bort fulltext-index';
$txt['search_method_index_partial'] = 'delvis skapat';
$txt['search_index_custom_resume'] = 'återuppta';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'In order to be able to use fulltext search, you\\\'ll have to create a fulltext index first.';
$txt['search_index_custom_warning'] = 'För att kunna använda anpassad indexsökning, måste du först skapa ett anpassat index!';

$txt['search_index'] = 'Sökindex';
$txt['search_index_none'] = 'Inget index';
$txt['search_index_custom'] = 'Anpassat index';
$txt['search_index_label'] = 'Index';
$txt['search_index_size'] = 'Storlek';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Tvinga användning av sökindex';
$txt['search_match_words'] = 'Matcha endast hela ord';
$txt['search_max_results'] = 'Max antal resultat att visa';
$txt['search_max_results_disable'] = '(0: ingen gräns)';
$txt['search_floodcontrol_time'] = 'Minsta tid mellan sökningar gjorda av samma medlem';
$txt['search_floodcontrol_time_desc'] = '(i sekunder, 0 för ingen gräns)';

$txt['additional_search_engines'] = 'Additional search engines';
$txt['setup_search_engine_add_more'] = 'Add another search engine';

$txt['search_create_index'] = 'Skapa index';
$txt['search_create_index_why'] = 'Varför skapa ett sökindex?';
$txt['search_create_index_start'] = 'Skapa';
$txt['search_predefined'] = 'Fördefinierad profil';
$txt['search_predefined_small'] = 'Litet index';
$txt['search_predefined_moderate'] = 'Medelstort index';
$txt['search_predefined_large'] = 'Stort index';
$txt['search_create_index_continue'] = 'Fortsätt';
$txt['search_create_index_not_ready'] = 'ElkArte is currently creating a search index of your messages. To avoid overloading your server, the process has been temporarily paused. It should automatically continue in a few seconds. If it doesn\'t, please click continue below.';
$txt['search_create_index_progress'] = 'Procent klart';
$txt['search_create_index_done'] = 'Custom search index successfully created.';
$txt['search_create_index_done_link'] = 'Fortsätt';
$txt['search_double_index'] = 'Du har för närvarande skapat två index på inläggstabellen. För bästa prestanda, rekommenderar vi att du tar bort ett av de två indexen.';

$txt['search_error_indexed_chars'] = 'Ogiltigt antal indexerade tecken. Minst 3 tecken behövs för ett meningsfullt index.';
$txt['search_error_max_percentage'] = 'Ogiltig procentandel av ord att hoppa över. Använd minst 5%.';
$txt['error_string_too_long'] = 'Söksträngen måste vara mindre än %1$d tecken.';

$txt['search_warning_ignored_word'] = 'The following term has been ignored in your search';
$txt['search_warning_ignored_words'] = 'The following terms have been ignored in your search';

$txt['search_adjust_query'] = 'Justera sökparametrar';
$txt['search_adjust_submit'] = 'Förfina sökning';
$txt['search_did_you_mean'] = 'Du kanske hade tänkt att söka på';

$txt['search_example'] = '<i>t.ex:</i> "Rudyard Kipling" Djungelboken -film';

$txt['search_engines_description'] = 'Här kan du ställa in hur noggrant du vill spåra sökmotorer i deras indexering av ditt forum, liksom att studera sökmotorsloggar.';
$txt['spider_mode'] = 'Search Engine Tracking Level';
$txt['spider_mode_note'] = 'Note higher level tracking increases server resource requirement.';
$txt['spider_mode_off'] = 'Avstängt';
$txt['spider_mode_standard'] = 'Standard';
$txt['spider_mode_high'] = 'Moderera';
$txt['spider_mode_vhigh'] = 'Aggressive';
$txt['spider_settings_desc'] = 'You can change settings for spider tracking from this page. Note, if you wish to <a href="%1$s">enable automatic pruning of the hit logs you can set this up here</a>';

$txt['spider_group'] = 'Apply restrictive permissions from group';
$txt['spider_group_note'] = 'To enable you to stop spiders indexing some pages.';
$txt['spider_group_none'] = 'Avstängt';

$txt['show_spider_online'] = 'Visa sökrobotar i Vilka är online-listan';
$txt['show_spider_online_no'] = 'Inte alls';
$txt['show_spider_online_summary'] = 'Visa antal sökrobotar';
$txt['show_spider_online_detail'] = 'Visa detaljer om sökrobotar';
$txt['show_spider_online_detail_admin'] = 'Visa detaljer om sökrobotar endast för administratörer';

$txt['spider_name'] = 'Namn på sökrobot';
$txt['spider_last_seen'] = 'Sågs senast';
$txt['spider_last_never'] = 'Aldrig';
$txt['spider_agent'] = 'Webbläsare';
$txt['spider_ip_info'] = 'IP-adresser';
$txt['spiders_add'] = 'Lägg till ny sökrobot';
$txt['spiders_edit'] = 'Redigera sökrobot';
$txt['spiders_remove_selected'] = 'Radera markerade';
$txt['spider_remove_selected_confirm'] = 'Are you sure you want to remove these spiders?\\n\\nAll associated statistics will also be deleted!';
$txt['spiders_no_entries'] = 'Det finns för närvarande inga sökrobotar konfigurerade.';

$txt['add_spider_desc'] = 'På denna sida kan du ändra hur sökrobotar kategoriseras. Om en gästs webbläsare eller IP-adress stämmer överens med det som anges nedan, kommer dessa att identifieras som en sökmotor och spåras i enlighet med forumets inställningar.';
$txt['spider_name_desc'] = 'Namn som sökroboten kommer att identifieras som.';
$txt['spider_agent_desc'] = 'Webbläsare som denna sökrobot brukar identifieras med.';
$txt['spider_ip_info_desc'] = 'Kommaseparerad lista över IP-adresser som denna sökrobot använder sig av.';

$txt['spider_time'] = 'Tid';
$txt['spider_viewing'] = 'Visar';
$txt['spider_logs_empty'] = 'Det finns för närvarande inga poster i sökrobotloggen.';
$txt['spider_logs_info'] = 'Observera att alla sökrobotarnas handlingar bara loggas om spårningen är satt till antingen &quot;Hög&quot; eller &quot;Väldigt hög&quot;. Ingående information om alla sökrobotarnas handling loggas bara om spårningen är satt till &quot;väldigt hög&quot;.';
$txt['spider_disabled'] = 'Avstängt';
$txt['spider_log_empty_log'] = 'Clear Log';
$txt['spider_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log';

$txt['spider_logs_delete'] = 'Radera poster';
$txt['spider_logs_delete_older'] = 'Delete all entries older than %1$s days.';
$txt['spider_logs_delete_submit'] = 'Radera';

$txt['spider_stats_delete_older'] = 'Delete all spider statistics from spiders not seen in %1$s days.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Är du säker på att du vill tömma alla poster i loggen?';

$txt['spider_stats_select_month'] = 'Hoppa till månad';
$txt['spider_stats_page_hits'] = 'Sidbesök';
$txt['spider_stats_no_entries'] = 'Det finns för närvarande ingen tillgänglig statistik för sökrobotar.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'You have not yet selected to use Sphinx or SphinxQL as your Search Method';
$txt['sphinx_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using the Sphinx API.';
$txt['sphinxql_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using SphinxQL commands.';
$txt['sphinx_test_connect_failed'] = 'Unable to connect to the Sphinx daemon. Make sure it is running and configured properly. Sphinx search will not work until you fix the problem.';
$txt['sphinxql_test_connect_failed'] = 'Unable to access SphinxQL. Make sure your sphinx.conf has a separate listen directive for the SphinxQL port. SphinxQL search will not work until you fix the problem';
$txt['sphinx_test_api_missing'] = 'The sphinxapi.php file is missing in your &quot;sources&quot; directory. You need to copy this file from the Sphinx distribution. Sphinx search will not work until you fix the problem.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Index data path:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Log file path:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';