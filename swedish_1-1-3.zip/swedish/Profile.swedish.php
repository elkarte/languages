<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Du har inte tillstånd att redigera den här användarens profil.';
$txt['website_title'] = 'Namn på ev. egen hemsida';
$txt['website_url'] = 'Adress till ev. egen hemsida';
$txt['signature'] = 'Signatur';
$txt['profile_posts'] = 'Inlägg';

$txt['profile_info'] = 'Extra Details';
$txt['profile_contact'] = 'Contact Information';
$txt['profile_moderation'] = 'Moderation Information';
$txt['profile_more'] = 'Signatur';
$txt['profile_attachments'] = 'Recent Attachments';
$txt['profile_attachments_no'] = 'There are no Attachments from this member';
$txt['profile_recent_posts'] = 'Nyliga inlägg';
$txt['profile_posts_no'] = 'There are no posts from this member';
$txt['profile_topics'] = 'Recent Topics';
$txt['profile_topics_no'] = 'There are no topics from this member';
$txt['profile_buddies_no'] = 'You have not set any buddies';
$txt['profile_user_info'] = 'User Info';
$txt['profile_contact_no'] = 'There is no contact information for this member';
$txt['profile_signature_no'] = 'There is no signature for this member';
$txt['profile_additonal_no'] = 'There is no additional information for this member';
$txt['profile_user_summary'] = 'Profilen';
$txt['profile_action'] = 'Currently';
$txt['profile_recent_activity'] = 'Recent Activity';
$txt['profile_activity'] = 'Aktivitet';
$txt['profile_loadavg'] = 'Please try again later.  This information is not currently available due to high demand on the site.';

$txt['change_profile'] = 'Spara ändringar';
$txt['preview_signature'] = 'Preview signature';
$txt['current_signature'] = 'Current signature';
$txt['signature_preview'] = 'Signature preview';
$txt['personal_picture'] = 'Personlig bild';
$txt['no_avatar'] = 'Ingen personlig bild';
$txt['choose_avatar_gallery'] = 'Välj en befintlig bild';
$txt['preferred_language'] = 'Välj språk';
$txt['age'] = 'Ålder';
$txt['no_pic'] = '(ingen bild)';
$txt['avatar_by_url'] = 'Specify your own avatar by URL. (e.g.: <em>http://www.mypage.com/mypic.png</em>)';
$txt['my_own_pic'] = 'Välj personlig bild via URL';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'Detta val gör att alla datum på forumet visas i detta format.';
$txt['time_format'] = 'Tidsformat';
$txt['display_name_desc'] = 'Detta är det visade namn som andra personer kommer att se.';
$txt['personal_time_offset'] = 'Antal timmar +/- för att få den visade tiden att stämma överens med din lokala tid.';
$txt['dob'] = 'Födelsedatum';
$txt['dob_month'] = 'Månad (MM)';
$txt['dob_day'] = 'Dag (DD)';
$txt['dob_year'] = 'År (ÅÅÅÅ)';
$txt['password_strength'] = 'För bästa säkerhet bör du använda sex eller fler tecken, och gärna även en kombination av både bokstäver och siffror.';
$txt['include_website_url'] = 'Detta måste fyllas i om du anger en Internetadress nedan.';
$txt['complete_url'] = 'Detta måste vara en fullständig Internetadress.';
$txt['sig_info'] = 'Signaturer visas längst ned i alla dina inlägg och dina privata meddelanden. BBC-koder och smileys får användas.';
$txt['max_sig_characters'] = 'Max %1$d; tecken återstår: ';
$txt['send_member_pm'] = 'Skicka privat meddelande till denna medlem';
$txt['hidden'] = 'dold';
$txt['current_time'] = 'Aktuell servertid';

$txt['language'] = 'Språk';
$txt['avatar_too_big'] = 'Din personliga bild är för stor, vänligen förminska den och försök igen (max';
$txt['invalid_registration'] = 'Ogiltigt datum för när medlemmen registrerade sig, giltigt exempel:';
$txt['current_password'] = 'Nuvarande lösenord';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Av säkerhetsskäl måste du alltid ange ditt nuvarande lösenord för att kunna göra ändringar i din profil.';

$txt['timeoffset_autodetect'] = 'auto detect';

$txt['secret_question'] = 'Hemlig fråga';
$txt['secret_desc'] = 'För att enkelt kunna få tillbaka ditt lösenord om du glömt bort det, skriv här en fråga som <strong>bara</strong> du själv vet svaret på.';
$txt['secret_desc2'] = 'Välj försiktigt, du vill väl inte att någon utomstående ska kunna gissa sig till svaret på frågan...?';
$txt['secret_answer'] = 'Svar';
$txt['incorrect_answer'] = 'Beklagar, men du har inte angett en giltig hemlig fråga eller svar i din profil. Klicka på Bakåt och använd istället standardmetoden för att få ett nytt lösenord.';
$txt['enter_new_password'] = 'Skriv in svaret på din hemliga fråga, och det lösenord du vill byta till. Ditt lösenord kommer att ändras till det du skriver in, förutsatt att du svarar rätt på frågan.';
$txt['secret_why_blank'] = 'varför står det inget här?';

$txt['authentication_reminder'] = 'Påminnelse om lösenord';
$txt['password_reminder_desc'] = 'Om du har glömt dina inloggningsuppgifter behöver du inte oroa dig, de kan tas tillbaka. För att göra detta skriver du in ditt användarnamn eller din e-postadress nedan.';
$txt['authentication_options'] = 'Välj en av de två alternativen nedan';
$txt['authentication_openid_email'] = 'Skicka mig en påminnelse om min OpenID-identitet';
$txt['authentication_openid_secret'] = 'Svar på min &quot;hemliga fråga&quot; för att visa min OpenID-identitet.';
$txt['authentication_password_email'] = 'Skicka mig ett nytt lösenord';
$txt['authentication_password_secret'] = 'Låt mig ange ett nytt lösenord genom att svara på min &quot;hemliga fråga&quot;';
$txt['openid_secret_reminder'] = 'Ange ditt svar på frågan nedan. Om du svarar rätt visas ditt OpenID identitet.';
$txt['reminder_openid_is'] = 'OpenID-identiteten som är kopplad till ditt konto är: <br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /> <br /> Tänk på att skriva av detta för framtida bruk.';
$txt['reminder_continue'] = 'Fortsätt';

$txt['accept_agreement_title'] = 'Accept agreement';
$txt['agreement_accepted_title'] = 'Fortsätt';

$txt['current_theme'] = 'Nuvarande tema';
$txt['change'] = 'Change Theme';
$txt['theme_forum_default'] = 'Forumets eller tavlans standardtema';
$txt['theme_forum_default_desc'] = 'Detta är standardtemat, som innebär att utseendet kommer att variera utifrån administratörens inställningar och vilken tavla du besöker.';

$txt['profileConfirm'] = 'Vill du verkligen ta bort den här medlemmen?';

$txt['custom_title'] = 'Anpassad titel';

$txt['lastLoggedIn'] = 'Senast aktiv';

$txt['notify_settings'] = 'Underrättelseinställningar:';
$txt['notify_save'] = 'Spara ändringar';
$txt['notify_important_email'] = 'Bli underrättad via e-post vid nya tillkännagivanden och viktiga meddelanden.';
$txt['notify_regularity'] = 'För ämnen och tavlor jag begärt underrättelse på, meddela mig';
$txt['notify_regularity_none'] = 'Aldrig';
$txt['notify_regularity_instant'] = 'Omedelbart';
$txt['notify_regularity_first_only'] = 'Omedelbart - men bara för det första olästa svaret';
$txt['notify_regularity_daily'] = 'Dagligen';
$txt['notify_regularity_weekly'] = 'Veckovis';
$txt['auto_notify'] = 'Turn topic notification on when you post or reply to a topic.';
$txt['auto_notify_pbe_post'] = 'This is <strong>NOT</strong> recommended if you have "board" notifications enabled.';
$txt['notify_send_types'] = 'Notify me of topics and boards I\'ve requested notification on';
$txt['notify_send_type_everything'] = 'Svar och moderering';
$txt['notify_send_type_everything_own'] = 'Moderering endast om jag startade ämnet';
$txt['notify_send_type_only_replies'] = 'Endast svar';
$txt['notify_send_type_only_replies_pbe'] = 'All messages';
$txt['notify_send_type_nothing'] = 'Ingenting alls';
$txt['notify_send_body'] = 'When sending notifications of a reply to a topic, send the post in the email (but please don\'t reply to these emails.)';
$txt['notify_send_body_pbe'] = 'When sending email notifications, send the full text of the post in the email';
$txt['notify_send_body_pbe_post'] = '<strong>NOT</strong> available with Daily / Weekly summary';

$txt['notify_method'] = 'Notification and:';
$txt['notify_notification'] = 'no email (only mention/alert)';
$txt['notify_email'] = 'Immediate email';
$txt['notify_email_daily'] = 'Daily email';
$txt['notify_email_weekly'] = 'Weekly email';

$txt['notify_type_likemsg'] = 'Notify when one of your messages is liked';
$txt['notify_type_mentionmem'] = 'Notify when you are @mentioned';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Notify when someone adds you as buddy';
$txt['notify_type_quotedmem'] = 'Notify when someone quotes one of your messages';
$txt['notify_type_mailfail'] = 'Notify when email notifications are disabled (mention only)';

$txt['notifications_topics'] = 'Nuvarande ämne-underrättelser';
$txt['notifications_topics_none'] = 'Du har inte ställt in underrättelse för något ämne.';
$txt['notifications_topics_howto'] = 'To receive notifications from a specific topic, click the &quot;Notify&quot; button while viewing it.';

$txt['notifications_boards'] = 'Nuvarande tavel-underrättelser';
$txt['notifications_boards_none'] = 'Du har inte ställt in underrättelse för någon tavla.';
$txt['notifications_boards_howto'] = 'To request notifications from a specific board, either click the &quot;Notify&quot; button in the index of that board <strong>or</strong> use the checkboxes below to enable select board notifications.';
$txt['notifications_boards_current'] = 'You are receiving notifications on the boards shown in <strong>BOLD</strong>.  Use the checkboxes to turn these off or add additional boards to your notification list';
$txt['notifications_boards_update'] = 'Update';
$txt['notifications_update'] = 'Säg upp prenumerationen';

$txt['statPanel_showStats'] = 'Användarstatistik för: ';
$txt['statPanel_users_votes'] = 'Antal omröstningar personen röstat i';
$txt['statPanel_users_polls'] = 'Antal omröstningar personen skapat';
$txt['statPanel_total_time_online'] = 'Total tid som användaren varit online';
$txt['statPanel_noPosts'] = 'Det finns inga inlägg att tala om...!';
$txt['statPanel_generalStats'] = 'Allmän statistik';
$txt['statPanel_posts'] = 'inlägg';
$txt['statPanel_topics'] = 'ämnen';
$txt['statPanel_total_posts'] = 'Totalt antal skrivna inlägg';
$txt['statPanel_total_topics'] = 'Antal ämnen personen startat';
$txt['statPanel_votes'] = 'röster';
$txt['statPanel_polls'] = 'omröstningar';
$txt['statPanel_topBoards'] = 'De populäraste tavlorna utifrån antal inlägg';
$txt['statPanel_topBoards_posts'] = '%1$d inlägg av tavlans totalt %2$d inlägg (%3$01.2f%%)';
$txt['statPanel_topBoards_memberposts'] = '%1$d inlägg av medlemmens totalt %2$d inlägg (%3$01.2f%%)';
$txt['statPanel_topBoardsActivity'] = 'De populäraste tavlorna utifrån aktivitet';
$txt['statPanel_activityTime'] = 'Skrivaktivitet för olika tider';
$txt['statPanel_activityTime_posts'] = '%1$d inlägg (%2$d%%)';

$txt['deleteAccount_warning'] = 'Varning - Dessa åtgärder är permanenta, och kan inte göras ogjorda!';
$txt['deleteAccount_desc'] = 'Från denna sida kan du radera denna användarens konto och inlägg.';
$txt['deleteAccount_member'] = 'Radera den här medlemmens användarkonto';
$txt['deleteAccount_posts'] = 'Radera inlägg skrivna av den här medlemmen';
$txt['deleteAccount_none'] = 'Ingen';
$txt['deleteAccount_all_posts'] = 'Replies Only';
$txt['deleteAccount_topics'] = 'Topics and Replies';
$txt['deleteAccount_confirm'] = 'Är du helt säker på att du vill radera detta konto?';
$txt['deleteAccount_approval'] = 'Observera att forumets moderatorer måste godkänna borttagningen innan kontot verkligen kommer att tas bort.';

$txt['profile_of_username'] = 'Profilen för %1$s';
$txt['profileInfo'] = 'Profilinformation';
$txt['showPosts'] = 'Visa inlägg';
$txt['showPosts_help'] = 'Denna sektion låter dig visa alla inlägg som denna medlem har skrivit. Observera att du bara kan se inlägg i områden som du har tillgång till.';
$txt['showMessages'] = 'Meddelanden';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = 'Visa inlägg';
$txt['showUnwatched'] = 'Unwatched topics';
$txt['showAttachments'] = 'Visa bifogade filer.';
$txt['viewWarning_help'] = 'This section allows you to view all warnings issued to this member.';
$txt['statPanel'] = 'Visa statistik';
$txt['editBuddyIgnoreLists'] = 'Kompisar/Ignorerade';
$txt['editBuddies'] = 'Redigera kompislistan';
$txt['editIgnoreList'] = 'Ändra Ignorerade';
$txt['trackUser'] = 'Spåra användare';
$txt['trackActivity'] = 'Aktivitet';
$txt['trackIP'] = 'IP-adress';
$txt['trackLogins'] = 'Logins';

$txt['likes_show'] = 'Show Likes';
$txt['likes_given'] = 'Posts you liked';
$txt['likes_profile_received'] = 'received';
$txt['likes_profile_given'] = 'given';
$txt['likes_received'] = 'Your posts liked by others';
$txt['likes_none_given'] = 'You have not liked any posts';
$txt['likes_none_received'] = 'No one has liked any of your posts :\'(';
$txt['likes_confirm_delete'] = 'Remove this like?';
$txt['likes_show_who'] = 'Show the members that liked this post';
$txt['likes_by'] = 'Liked by';
$txt['likes_delete'] = 'Radera';

$txt['authentication'] = 'Autentisering';
$txt['change_authentication'] = 'Härifrån kan du ändra hur du loggar in på forumet. Du kan välja att antingen använda ett OpenID-konto för din autentisering, eller alternativt använda ett användarnamn och lösenord.';

$txt['profileEdit'] = 'Ändra i profil';
$txt['account_info'] = 'Detta är dina kontoinställningar. På denna sida finns all viktig information som identifierar dig på forumet. Av säkerhetsskäl måste du alltid ange ditt nuvarande lösenord, om du vill ändra något på denna sida.';
$txt['forumProfile_info'] = 'You can change your personal information on this page. This information will be displayed throughout {forum_name_html_safe}. If you aren\'t comfortable with sharing some information, simply skip it - nothing here is required.';
$txt['theme_info'] = 'Denna avdelning låter dig anpassa utseendet och layouten på forumet.';
$txt['notification_info'] = 'This allows you to be notified of replies to posts, newly posted topics, and forum announcements. You can change those settings here, or oversee the topics and boards you are currently receiving notifications for.';
$txt['groupmembership'] = 'Gruppmedlemskap';
$txt['groupMembership_info'] = 'I denna avdelning i din profil kan du ändra vilka grupper du tillhör.';
$txt['ignoreboards'] = 'Ignorera tavlor';
$txt['ignoreboards_info'] = 'This page lets you ignore particular boards.  When a board is ignored, the new post indicator will not show up on the board index.  New posts will not show up using the "unread post" search link (when searching it will not look in those boards). However, ignored boards will still appear on the board index and upon entering will show which topics have new posts.  When using the "unread replies" link, new posts in an ignored board will still be shown.';
$txt['contactprefs'] = 'Messaging';

$txt['profileAction'] = 'Åtgärder';
$txt['deleteAccount'] = 'Radera det här kontot';
$txt['profileSendIm'] = 'Skicka privat meddelande';
$txt['profile_sendpm_short'] = 'Skicka PM';

$txt['profileBanUser'] = 'Bannlys denna användare';

$txt['display_name'] = 'Visat namn';
$txt['enter_ip'] = 'Ange IP-adress(er)';
$txt['errors_by'] = 'Felmeddelanden från';
$txt['errors_desc'] = 'Nedan följer en lista över alla nyliga felmeddelanden som denna användare har orsakat eller upplevt.';
$txt['errors_from_ip'] = 'Felmeddelanden från IP-adress(er)';
$txt['errors_from_ip_desc'] = 'Nedan finns en lista över alla nyliga felmeddelanden som kommit från denna IP-adress.';
$txt['ip_address'] = 'IP-adress';
$txt['ips_in_errors'] = 'IP-adresser som förekommer i felmeddelanden';
$txt['ips_in_messages'] = 'IP-adresser som använts i nyliga inlägg';
$txt['members_from_ip'] = 'Medlemmar från IP-adress';
$txt['members_in_range'] = 'Medlemmar som kan ha samma IP-adress';
$txt['messages_from_ip'] = 'Meddelanden som skickats från IP-adress';
$txt['messages_from_ip_desc'] = 'Nedan finns en lista över alla inlägg som postats från denna IP-adress.';
$txt['trackLogins_desc'] = 'Below is a list of all times this account was logged into.';
$txt['most_recent_ip'] = 'Senaste IP-adressen';
$txt['why_two_ip_address'] = 'Varför står det utsatt två IP-adresser?';
$txt['no_errors_from_ip'] = 'Inga felmeddelanden från den angivna IP-adressen kunde hittas';
$txt['no_errors_from_user'] = 'Inga felmeddelanden från den angivna användaren kunde hittas';
$txt['no_members_from_ip'] = 'Inga felmeddelanden inom angiven IP-adress kunde hittas';
$txt['no_messages_from_ip'] = 'Inga meddelanden från den angivna IP-adressen kunde hittas';
$txt['trackLogins_none_found'] = 'No recent logins were found';
$txt['none'] = 'Ingen';
$txt['own_profile_confirm'] = 'Är du säker på att du verkligen vill radera ditt eget användarkonto?';
$txt['view_ips_by'] = 'Visa IP-adresser som används av';

$txt['avatar_will_upload'] = 'Ladda upp en personlig bild';

$txt['activate_changed_email_title'] = 'Epostadressen ändrad';
$txt['activate_changed_email_desc'] = 'Din epostadress har ändrats. För att validera denna adress, kommer du få ett mail. Klicka länken i mailet för att återaktivera ditt konto.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Lyckades inte att skicka påminnelsebrev.';
$txt['send_email'] = 'Skicka e-post till';
$txt['to_ask_password'] = 'för att fråga efter lösenord';

$txt['user_email'] = 'Användarnamn/e-post';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'Ett brev har skickats till din e-postadress. Klicka på länken i det meddelandet för att ange ett nytt lösenord.';
$txt['reminder_openid_sent'] = 'Din nuvarande OpenID-identitet har skickats till din e-postadress.';
$txt['reminder_set_password'] = 'Ange lösenord';
$txt['reminder_password_set'] = 'Lösenordet har ändrats utan problem';
$txt['reminder_error'] = '%1$s misslyckades med att svara på sin hemliga fråga, för att ändra ett bortglömt lösenord.';

$txt['registration_not_approved'] = 'Beklagar, det här kontot är ännu inte godkänt. Om du behöver ändra din e-postadress, klicka';
$txt['registration_not_activated'] = 'Beklagar, det här kontot har ännu inte aktiverats. Om du vill att vi ska skicka aktiveringsbrevet via e-post igen, klicka';

$txt['primary_membergroup'] = 'Primär medlemsgrupp';
$txt['additional_membergroups'] = 'Ytterligare medlemsgrupper';
$txt['additional_membergroups_show'] = 'Show additional groups';
$txt['no_primary_membergroup'] = '(ingen huvudsaklig medlemsgrupp)';
$txt['deadmin_confirm'] = 'Är du säker på att du verkligen vill ta bort din administratörsstatus? Har du väl gjort det, finns det inget sätt att få tillbaka den...';

$txt['account_activate_method_2'] = 'Kontot kräver återaktivering efter byte av e-postadress';
$txt['account_activate_method_3'] = 'Kontot är inte godkänt';
$txt['account_activate_method_4'] = 'Kontot väntar på godkännande för borttagning';
$txt['account_activate_method_5'] = 'Kontot är ett &quot;minderårigt&quot; konto, som väntar på godkännande';
$txt['account_not_activated'] = 'Användarkontot är för tillfället inte aktiverat';
$txt['account_activate'] = 'aktivera';
$txt['account_approve'] = 'godkänn';
$txt['user_is_banned'] = 'Användaren är för närvarande bannlyst';
$txt['view_ban'] = 'Visa';
$txt['user_banned_by_following'] = 'Denna användare påverkas för närvarande av följande bannlysningar';
$txt['user_cannot_due_to'] = 'Användaren kan inte %1$s på grund av bannlysningen: &quot;%2$s&quot; ';
$txt['ban_type_post'] = 'skriva inlägg';
$txt['ban_type_register'] = 'registrera';
$txt['ban_type_login'] = 'logga in';
$txt['ban_type_access'] = 'komma åt forumet';

$txt['show_online'] = 'Visa för andra min online-status';

$txt['return_to_post'] = 'Återvänd till själva ämnet efter att du skrivit svar som standard.';
$txt['no_new_reply_warning'] = 'Varna inte för nya inlägg som postats medan du skrivit egna inlägg.';
$txt['recent_pms_at_top'] = 'Visa nyaste privata meddelanden längst upp.';
$txt['wysiwyg_default'] = 'Visa WYSIWYG-editor på inläggssidan som standard.';

$txt['timeformat_default'] = '(Forumstandard)';
$txt['timeformat_easy1'] = 'Månad Dag, År, HH:MM:SS (12-timmarsklocka)';
$txt['timeformat_easy2'] = 'Månad Dag, År, HH:MM:SS (24-timmarsklocka)';
$txt['timeformat_easy3'] = 'ÅÅÅÅ-MM-DD, HH:MM:SS';
$txt['timeformat_easy4'] = 'DD Månad ÅÅÅÅ, HH:MM:SS';
$txt['timeformat_easy5'] = 'DD-MM-ÅÅÅÅ, HH:MM:SS';

$txt['poster'] = 'Författare';

$txt['use_sidebar_menu'] = 'Use sidebar menu instead of dropdowns.';
$txt['use_click_menu'] = 'Use click to open menus, instead of hover to open.';
$txt['show_no_avatars'] = 'Visa inte andra användares personliga bilder.';
$txt['show_no_signatures'] = 'Visa inte andra användares signaturer.';
$txt['show_no_censored'] = 'Visa alla inlägg ocensurerade.';
$txt['topics_per_page'] = 'Antal ämnen att visa per sida:';
$txt['messages_per_page'] = 'Antal inlägg att visa per sida:';
$txt['hide_poster_area'] = 'Hide the poster information area.';
$txt['per_page_default'] = 'Forumets standardinställning';
$txt['calendar_start_day'] = 'First day of the week on the calendar:';
$txt['display_quick_reply'] = 'Använd snabbsvar vid ämnesvisningar:';
$txt['use_editor_quick_reply'] = 'Use full editor in Quick Reply.';
$txt['display_quick_mod'] = 'Show quick-moderation as:';
$txt['display_quick_mod_none'] = 'visa inte.';
$txt['display_quick_mod_check'] = 'kryssrutor.';
$txt['display_quick_mod_image'] = 'ikoner.';

$txt['whois_title'] = 'Slå upp IP-adress hos en regional whois-server';
$txt['whois_afrinic'] = 'AfriNIC (Afrika)';
$txt['whois_apnic'] = 'APNIC (Asien och Oceanien)';
$txt['whois_arin'] = 'ARIN (Nordamerika, delar av Karibbien och delar av Afrika)';
$txt['whois_lacnic'] = 'LACNIC (Latinamerika och delar av Karibbien)';
$txt['whois_ripe'] = 'RIPE (Europa, Mellanöstern och delar av Afrika och Asien)';

$txt['moderator_why_missing'] = 'varför finns inte moderator med på listan?';
$txt['username_change'] = 'Ändra';
$txt['username_warning'] = 'För att ändra denna medlems användarnamn, måste också deras lösenord bytas ut - deras nya slumpvalda lösenord kommer att skickas via e-post tillsammans med deras nya användarnamn.';

$txt['show_member_posts'] = 'Visa medlemmens inlägg';
$txt['show_member_topics'] = 'Visa medlemmens ämnen';
$txt['show_member_attachments'] = 'Visa medlemmens bifogade filer';
$txt['show_posts_none'] = 'Inga inlägg har skrivits ännu.';
$txt['show_topics_none'] = 'Inga ämnen har gjorts ännu.';
$txt['unwatched_topics_none'] = 'You don\'t have any topic in the unwatch list.';
$txt['show_attachments_none'] = 'Inga bilagor har skickats ännu.';
$txt['show_attach_filename'] = 'Filnamn';
$txt['show_attach_downloads'] = 'Nedladdningar';
$txt['show_attach_posted'] = 'Postad';

$txt['showPermissions'] = 'Visa rättigheter';
$txt['showPermissions_status'] = 'Behörighet status';
$txt['showPermissions_help'] = 'Denna del låter dig se samtliga rättigheter för denne medlem (nekade rättigheter är <del>överstrukna</del>). ';
$txt['showPermissions_given'] = 'Givits av';
$txt['showPermissions_denied'] = 'Nekats av';
$txt['showPermissions_permission'] = 'Permission (denied permissions are shown <del>struck through</del>)';
$txt['showPermissions_none_general'] = 'Denna medlem har inga allmänna rättigheter angivna.';
$txt['showPermissions_none_board'] = 'Denna medlem har inga rättigheter för specifika tavlor angivna.';
$txt['showPermissions_all'] = 'Som administratör har denna medlem alla tänkbara rättigheter.';
$txt['showPermissions_select'] = 'Tavel-specifika rättigheter för';
$txt['showPermissions_general'] = 'Allmänna rättigheter';
$txt['showPermissions_global'] = 'Alla tavlor';
$txt['showPermissions_restricted_boards'] = 'Tavlor med begränsad behörighet';
$txt['showPermissions_restricted_boards_desc'] = 'Följande tavlor kan inte nås av denna användare';

$txt['local_time'] = 'Lokal tid';
$txt['posts_per_day'] = 'per dag';

$txt['buddy_ignore_desc'] = 'Denna avdelning tillåter dig att ändra i din kompis- och ignorera-lista för detta forum. Genom att lägga till medlemmar kommer du bland annat att kontrollera e-post- och PM-trafik beroende på dina inställningar.';

$txt['buddy_add'] = 'Add to buddy list';
$txt['buddy_remove'] = 'Remove from buddy list';
$txt['buddy_add_button'] = 'Lägg till';
$txt['no_buddies'] = 'Din kompislista är för närvarande tom';

$txt['ignore_add'] = 'Add to ignore list';
$txt['ignore_remove'] = 'Remove from ignore list';
$txt['ignore_add_button'] = 'Lägg till';
$txt['no_ignore'] = 'Din ignorera-lista är för närvarande tom';

$txt['regular_members'] = 'Registrerade medlemmar';
$txt['regular_members_desc'] = 'Alla medlemmar på forumet tillhör denna grupp.';
$txt['group_membership_msg_free'] = 'Ditt gruppmedlemskap uppdaterades utan problem.';
$txt['group_membership_msg_request'] = 'Din ansökan har skickats in, ha tålamod medan personalen överväger önskemålet.';
$txt['group_membership_msg_primary'] = 'Din huvudsakliga medlemsgrupp har uppdaterats';
$txt['current_membergroups'] = 'Nuvarande medlemsgrupper';
$txt['available_groups'] = 'Tillgängliga grupper';
$txt['join_group'] = 'Gå med i grupp';
$txt['leave_group'] = 'Lämna grupp';
$txt['request_group'] = 'Ansök om medlemskap';
$txt['approval_pending'] = 'Väntar på godkännande';
$txt['make_primary'] = 'Gör till huvudsaklig medlemsgrupp';

$txt['request_group_membership'] = 'Ansök om gruppmedlemskap';
$txt['request_group_membership_desc'] = 'Innan du kan gå med i denna medlemsgrupp, måste ansökan godkännas av en moderator. Vänligen ange orsak till varför du vill gå med i gruppen';
$txt['submit_request'] = 'Skicka in ansökan';

$txt['profile_updated_own'] = 'Din profil har uppdaterats.';
$txt['profile_updated_else'] = 'The profile for <strong>%1$s</strong> has been updated successfully.';

$txt['profile_error_signature_max_length'] = 'Din signatur kan inte vara längre än %1$d tecken';
$txt['profile_error_signature_max_lines'] = 'Din signatur får inte vara större än %1$d rader';
$txt['profile_error_signature_max_image_size'] = 'Bilder i din signatur får inte vara större än %1$dx%2$d pixels';
$txt['profile_error_signature_max_image_width'] = 'Bilder i din signatur får inte vara bredare än %1$d pixels';
$txt['profile_error_signature_max_image_height'] = 'Bilder i din signatur får inte vara högre än %1$d pixels';
$txt['profile_error_signature_max_image_count'] = 'Du får inte ha fler än %1$d bilder i din signatur';
$txt['profile_error_signature_max_font_size'] = 'Text i din signatur får inte använda större textstorlek än %1$s punkter';
$txt['profile_error_signature_allow_smileys'] = 'Du har inte rättighet att använda Smileys i din signatur';
$txt['profile_error_signature_max_smileys'] = 'Du får inte använda fler än %1$d smileys i din signatur';
$txt['profile_error_signature_disabled_bbc'] = 'Följande BBC-koder får inte användas i din signatur: %1$s';

$txt['profile_view_warnings'] = 'Visa varningar';
$txt['profile_issue_warning'] = 'Utfärda varning';
$txt['profile_warning_level'] = 'Varningsnivå';
$txt['profile_warning_desc'] = 'I denna avdelning kan du ändra medlemmens varningsnivå, och utfärda skriftliga varningar om nödvändigt. Du kan också spåra deras varningshistorik, och visa följder av deras nuvarande varningsnivå som administratören bestämt.';
$txt['profile_warning_name'] = 'Medlemsnamn';
$txt['profile_warning_impact'] = 'Åtgärd';
$txt['profile_warning_reason'] = 'Orsak till varningen';
$txt['profile_warning_reason_desc'] = 'Detta är obligatoriskt, och kommer att loggas.';
$txt['profile_warning_effect_none'] = 'Ingen.';
$txt['profile_warning_effect_watch'] = 'Användaren läggs till på moderatorernas bevakningslista.';
$txt['profile_warning_effect_own_watched'] = 'Du finns på moderatorernas bevakningslista.';
$txt['profile_warning_is_watch'] = 'användaren bevakas';
$txt['profile_warning_effect_moderate'] = 'Alla användarens inlägg måste godkännas innan de visas.';
$txt['profile_warning_effect_own_moderated'] = 'Alla dina inlägg kommer att modereras.';
$txt['profile_warning_is_moderation'] = 'inlägg är modererade';
$txt['profile_warning_effect_mute'] = 'Användaren kommer inte att kunna skriva inlägg.';
$txt['profile_warning_effect_own_muted'] = 'Du kommer inte att kunna skriva inlägg.';
$txt['profile_warning_is_muted'] = 'kan inte skriva';
$txt['profile_warning_effect_text'] = 'Nivå >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Skicka underrättelse';
$txt['profile_warning_notify_template'] = 'Välj mall:';
$txt['profile_warning_notify_subject'] = 'Rubrik på underrättelsen';
$txt['profile_warning_notify_body'] = 'Meddelande på underrättelsen';
$txt['profile_warning_notify_template_subject'] = 'Du har fått en varning';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},

You have received a warning for %1$s. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},

You have received a warning for %1$s in regards to the message:
{MESSAGE}.

Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'postande av spam/skräpinlägg';
$txt['profile_warning_notify_title_spamming'] = 'Postande av spam/skräpinlägg';
$txt['profile_warning_notify_for_offence'] = 'postande av olämpligt/förolämpande material';
$txt['profile_warning_notify_title_offence'] = 'Postande av olämpligt/förolämpande material';
$txt['profile_warning_notify_for_insulting'] = 'förolämpning av andra användare och/eller personal';
$txt['profile_warning_notify_title_insulting'] = 'Förolämpning av användare/personal';
$txt['profile_warning_issue'] = 'Utfärda varning';
$txt['profile_warning_max'] = '(Max 100)';
$txt['profile_warning_limit_attribute'] = 'Du kan inte justera denna användares nivå med mer än %1$d%% under en 24-timmarsperiod.';
$txt['profile_warning_errors_occurred'] = 'Varning har inte skickats på grund av följande fel';
$txt['profile_warning_success'] = 'Varningen har delats ut';
$txt['profile_warning_new_template'] = 'Ny mall';

$txt['profile_warning_previous'] = 'Tidigare varningar';
$txt['profile_warning_previous_none'] = 'Den här användaren har inte mottagit tidigare varningar.';
$txt['profile_warning_previous_issued'] = 'Utfärdat av';
$txt['profile_warning_previous_time'] = 'Tid';
$txt['profile_warning_previous_level'] = 'Poäng';
$txt['profile_warning_previous_reason'] = 'Orsak';
$txt['profile_warning_previous_notice'] = 'Visa meddelandet som skickats till medlemmen';

$txt['viewwarning'] = 'Visa varningar';
$txt['profile_viewwarning_for_user'] = '%1$ss varningar';
$txt['profile_viewwarning_no_warnings'] = 'No warnings have been issued.';
$txt['profile_viewwarning_desc'] = 'Nedan finns en sammanfattning av alla varningar som forumets moderatorer har delat ut. ';
$txt['profile_viewwarning_previous_warnings'] = 'Tidigare varningar';
$txt['profile_viewwarning_impact'] = 'Varningseffekt';

$txt['subscriptions'] = 'Betalda prenumerationer';

$txt['pm_settings_desc'] = 'Från denna sida kan du ändra en mängd olika inställningar för privata meddelanden, däribland hur meddelanden visas och vilka som får skicka till dig.';
$txt['email_notify'] = 'Underrätta via e-post varje gång du får privata meddelanden:';
$txt['email_notify_never'] = 'Aldrig';
$txt['email_notify_buddies'] = 'Endast från kompisar';
$txt['email_notify_always'] = 'Alltid';

$txt['receive_from'] = 'Members allowed to contact me:';
$txt['receive_from_everyone'] = 'Alla medlemmar';
$txt['receive_from_ignore'] = 'Alla medlemmar, utom de på min ignorera-lista';
$txt['receive_from_admins'] = 'Endast administratörer';
$txt['receive_from_buddies'] = 'Endast kompisar och administratörer';
$txt['receive_from_description'] = 'This setting applies to both Personal Messages and emails (if the option to email members is enabled)';

$txt['popup_messages'] = 'Visa ett popup-fönster när du får nya meddelanden?';
$txt['pm_remove_inbox_label'] = 'Remove the inbox label when applying another label.';
$txt['pm_display_mode'] = 'Visa privata meddelanden';
$txt['pm_display_mode_all'] = 'Alla samtidigt';
$txt['pm_display_mode_one'] = 'En åt gången';
$txt['pm_display_mode_linked'] = 'Som en konversation';

$txt['history'] = 'History';
$txt['history_description'] = 'This section allows you to review certain profile actions performed on this member\'s profile as well as track their IP address and login history.';

$txt['trackEdits'] = 'Profilredigeringar';
$txt['trackEdit_deleted_member'] = 'Raderad medlem';
$txt['trackEdit_no_edits'] = 'Inga redigeringar har registrerats för denna medlem.';
$txt['trackEdit_action'] = 'Fält';
$txt['trackEdit_before'] = 'Värde innan';
$txt['trackEdit_after'] = 'Värde efter';
$txt['trackEdit_applicator'] = 'Ändrad av';

$txt['trackEdit_action_real_name'] = 'Medlemsnamn';
$txt['trackEdit_action_usertitle'] = 'Anpassad titel';
$txt['trackEdit_action_member_name'] = 'Användarnamn';
$txt['trackEdit_action_email_address'] = 'E-postadress';
$txt['trackEdit_action_id_group'] = 'Primär medlemsgrupp';
$txt['trackEdit_action_additional_groups'] = 'Ytterligare medlemsgrupper';

$txt['otp_enabled_help'] = 'Enabling this will add a second factor (one-time password) for authentication.';
$txt['otp_token_help'] = 'This generates a secret token for time-based one-time password  apps such as Authy or Google Authenticator. Once the secret was generated use your favorite authenticator app and scan the qrcode.<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
