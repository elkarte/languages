<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Användaravtalet';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'Jag accepterar villkoren i användaravtalet.';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Jag accepterar villkoren i användaravtalet och jag är minst %1$d år gammal.';
$txt['agreement_agree_coppa_below'] = 'Jag accepterar villkoren i användaravtalet och jag är yngre än %1$d år.';
$txt['agree_coppa_above'] = 'I am at least %1$d years old.';
$txt['agree_coppa_below'] = 'I am younger than %1$d years old.';

// Registration form.
$txt['registration_form'] = 'Registreringsformulär';
$txt['error_too_quickly'] = 'You went through the registration process too quickly, faster than should normally be possible. Please wait a moment and try again.';
$txt['error_token_verification'] = 'Token verification failed. Please try again.';
$txt['need_username'] = 'Du måste fylla i användarnamn.';
$txt['no_password'] = 'Du har inte angett ditt lösenord';
$txt['improper_password'] = 'The supplied password is too long.';
$txt['incorrect_password'] = 'Felaktigt lösenord';
$txt['openid_not_found'] = 'Supplied OpenID identifier not found.';
$txt['maintain_mode'] = 'Underhållsläge';
$txt['registration_successful'] = 'Registreringen lyckades';
$txt['valid_email_needed'] = 'Vänligen ange en giltig e-postadress, %1$s.';
$txt['required_info'] = 'Obligatorisk information';
$txt['additional_information'] = 'Övrig information';
$txt['warning'] = 'Varning!';
$txt['only_members_can_access'] = 'Enbart registrerade medlemmar har rätt att komma åt denna avdelning.';
$txt['login_below'] = 'Please login below.';
$txt['login_below_or_register'] = 'Please login below or <a href="%1$s">register an account</a> with %2$s';
$txt['checkbox_agreement'] = 'I accept the registration agreement';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Password security has recently been upgraded.<br />Please enter your password again.';

$txt['ban_register_prohibited'] = 'Beklagar, du får inte registrera dig på detta forum';
$txt['under_age_registration_prohibited'] = 'Beklagar, men användare under %1$d års ålder får inte registrera sig på detta forum.';

$txt['activate_account'] = 'Kontoaktivering';
$txt['activate_success'] = 'Ditt konto har aktiverats utan problem. Du kan nu fortsätta med att logga in.';
$txt['activate_not_completed1'] = 'Din e-postadress måste valideras innan du kan logga in.';
$txt['activate_not_completed2'] = 'Vill du ha ett till aktiveringsmeddelande via e-post?';
$txt['activate_after_registration'] = 'Tack för att du registrerat dig. Du kommer att få ett e-post-meddelande snart, med en länk där du kan aktivera ditt konto. Om du inte fått något e-post-meddelande inom en rimlig tid, kolla då om den råkat hamna i din skräppostmapp.';
$txt['invalid_userid'] = 'Användaren finns inte';
$txt['invalid_activation_code'] = 'Ogiltig aktiveringskod';
$txt['invalid_activation_username'] = 'Användarnamn eller e-postadress';
$txt['invalid_activation_new'] = 'Om du registrerade dig med fel e-postadress, skriv en ny adress och ditt lösenord här.';
$txt['invalid_activation_new_email'] = 'Ny e-postadress';
$txt['invalid_activation_password'] = 'Gammalt lösenord';
$txt['invalid_activation_resend'] = 'Skicka aktiveringskod igen';
$txt['invalid_activation_known'] = 'Om du redan vet din aktiveringskod, skriv in den här.';
$txt['invalid_activation_retry'] = 'Aktiveringskod';
$txt['invalid_activation_submit'] = 'Aktivera';

$txt['coppa_no_concent'] = 'Administratören har fortfarande inte fått samtycke från förälder eller målsman för ditt användarkonto.';
$txt['coppa_need_more_details'] = 'Behöver du mer information?';

$txt['awaiting_delete_account'] = 'Ditt konto har markerats att tas bort!<br />Om du vill återskapa ditt konto, klicka då på &quot;Återaktivera mitt konto&quot;, och logga in igen.';
$txt['undelete_account'] = 'Återaktivera mitt konto';

$txt['in_maintain_mode'] = 'Detta forum är i underhållsläge.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Vänligen läs och acceptera villkoren innan du fortsätter.';
$txt['register_passwords_differ_js'] = 'De två lösenord du skrev in var inte samma!';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Tack för att du registrerat dig. Administratören måste godkänna dig innan du kan börja använda kontot. Du kommer inom kort att få ett e-post-meddelande, med information om vad administratören beslutat.';

$txt['admin_settings_desc'] = 'Här kan du ändra ett antal inställningar som berör registrering av nya medlemmar.';

$txt['setting_enableOpenID'] = 'Tillåt användare att registrera sig med hjälp av OpenID';

$txt['setting_registration_method'] = 'Typ av registrering för nya medlemmar';
$txt['setting_registration_disabled'] = 'Registrering avstängd';
$txt['setting_registration_standard'] = 'Omedelbar registrering';
$txt['setting_registration_activate'] = 'E-postaktiveriing';
$txt['setting_registration_approval'] = 'Administratörs godkännande';
$txt['setting_notify_new_registration'] = 'Underrätta administratörerna när en ny medlem registrerar sig';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Skicka välkomstmeddelande via e-post till nya medlemmar';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Åldersgräns för registrering utan restriktioner';
$txt['setting_coppaAge_desc'] = '(Sätt till 0 för att inaktivera)';
$txt['setting_coppaType'] = 'Åtgärd när personer under minimiåldern registrerar sig';
$txt['setting_coppaType_reject'] = 'Neka deras registrering';
$txt['setting_coppaType_approval'] = 'Kräv samtycke från förälder/målsman';
$txt['setting_coppaPost'] = 'Adress som samtyckeformulär kan skickas till';
$txt['setting_coppaPost_desc'] = 'Gäller enbart om åldersbegränsningar är i bruk';
$txt['setting_coppaFax'] = 'Faxnummer som samtyckeformulär kan faxas till';
$txt['setting_coppaPhone'] = 'Telefonnummer där föräldrar kan nå dig vid förfrågningar om åldersbegränsning';

$txt['admin_register'] = 'Registrering av ny medlem';
$txt['admin_register_desc'] = 'Här kan du registrera nya medlemmar på forumet och, om nödvändigt, skicka e-post till dem med deras kontouppgifter.';
$txt['admin_register_username'] = 'Nytt användarnamn';
$txt['admin_register_email'] = 'E-postadress';
$txt['admin_register_password'] = 'Lösenord';
$txt['admin_register_username_desc'] = 'Användarnamn för den nya medlemmen';
$txt['admin_register_email_desc'] = 'E-postadress för medlemmen<br />(nödvändigt om du väljer att skicka kontouppgifter)';
$txt['admin_register_password_desc'] = 'Den nya medlemmens lösenord';
$txt['admin_register_email_detail'] = 'E-posta lösenordet till medlemmen';
$txt['admin_register_email_detail_desc'] = 'E-postadress måste anges även om denna kryssruta avmarkerats';
$txt['admin_register_email_activate'] = 'Kräv att användaren måste aktivera kontot';
$txt['admin_register_group'] = 'Primär medlemsgrupp';
$txt['admin_register_group_desc'] = 'Den huvudsakliga (primära) medlemsgruppen som den nya medlemmen kommer att tillhöra';
$txt['admin_register_group_none'] = '(ingen huvudsaklig medlemsgrupp)';
$txt['admin_register_done'] = 'Medlem %1$s har registrerats utan problem!';

$txt['coppa_title'] = 'Åldersbegränsat forum';
$txt['coppa_after_registration'] = 'Thank you for registering with {forum_name_html_safe}.<br /><br />Because you fall under the age of {MINIMUM_AGE}, it is a legal requirement to obtain your parent or guardian\'s permission before you may begin to use your account.  To arrange for account activation please print off the form below:';
$txt['coppa_form_link_popup'] = 'Ladda formulär i nytt fönster';
$txt['coppa_form_link_download'] = 'Ladda hem formulär som textfil';
$txt['coppa_send_to_one_option'] = 'Be sedan en förälder eller vårdnadshavare att fylla i formuläret, och skicka det via:';
$txt['coppa_send_to_two_options'] = 'Be sedan en förälder eller vårdnadshavare att fylla i formuläret, och skicka det via antingen:';
$txt['coppa_send_by_post'] = 'Brev (snigelpost), till följande adress:';
$txt['coppa_send_by_fax'] = 'Fax, till följande faxnummer:';
$txt['coppa_send_by_phone'] = 'Alternativt, be dem att kontakta forumets administratör på telefon {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Permission form for registration at {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Adress';
$txt['coppa_form_date'] = 'Datum';
$txt['coppa_form_body'] = 'I {PARENT_NAME},<br /><br />give permission for {CHILD_NAME} (child name) to become a fully registered member of the forum: {forum_name_html_safe}, with the username: {USER_NAME}.<br /><br />I understand that certain personal information entered by {USER_NAME} may be shown to other users of the forum.<br /><br />Signed:<br />{PARENT_NAME} (Parent/Guardian).';

$txt['visual_verification_sound_again'] = 'Spela igen';
$txt['visual_verification_sound_close'] = 'Stäng fönstret';
$txt['visual_verification_sound_direct'] = 'Har du problem att höra ljudet? Prova då direktlänken till ljudfilen.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Användarnamnet är tillgängligt';
$txt['registration_username_unavailable'] = 'Användarnamnet är EJ tillgängligt';
$txt['registration_username_check'] = 'Se om användarnamnet är tillgängligt';
$txt['registration_password_short'] = 'Lösenordet är för kort';
$txt['registration_password_reserved'] = 'Lösenordet innehåller ditt användarnamn/din e-postadress';
$txt['registration_password_numbercase'] = 'Lösenordet måste innehålla både stora och små bokstäver samt siffror';
$txt['registration_password_no_match'] = 'Lösenorden matchar inte';
$txt['registration_password_valid'] = 'Lösenordet är korrekt';

$txt['registration_errors_occurred'] = 'Följande fel upptäcktes i din registrering. Korrigera dem för att fortsätta:';

$txt['authenticate_label'] = 'Autentiseringsmetod';
$txt['authenticate_password'] = 'Lösenord';
$txt['authenticate_openid'] = 'OpenID ';
$txt['authenticate_openid_url'] = 'OpenID verifieringsadress';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'Contact the admins';
$txt['contact_your_message'] = 'Your message';
$txt['errors_contact_form'] = 'The following errors occurred while processing your contact request';
$txt['contact_subject'] = 'A guest has sent you a message';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
