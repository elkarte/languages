<?php
// Version: 1.1; ManagePaid

// Symbols.
$txt['usd_symbol'] = '$%1.2f';
$txt['eur_symbol'] = '&euro;%1.2f';
$txt['gbp_symbol'] = '&pound;%1.2f';

$txt['usd'] = 'USD ($)';
$txt['eur'] = 'EURO (&euro;)';
$txt['gbp'] = 'GBP (&pound;)';
$txt['other'] = 'Annan';

$txt['paid_username'] = 'Användarnamn';

$txt['paid_subscriptions_desc'] = 'Från den här delen kan du lägga till, ta bort och ändra i betalda prenumerationer till ditt forum.';
$txt['paid_subs_settings'] = 'Inställningar';
$txt['paid_subs_settings_desc'] = 'Härifrån kan du redigera betalningsmetoderna som dina användare kan använda.';
$txt['paid_subs_view'] = 'Visa Prenumerationer';
$txt['paid_subs_view_desc'] = 'Från denna sektion kan du visa alla prenumerationer du ahr tillgängliga.';

// Setting type strings.
$txt['paid_enabled'] = 'Aktivera betalda prenumerationer';
$txt['paid_enabled_desc'] = 'This must be checked for the paid subscriptions to be used on the forum.';
$txt['paid_email'] = 'Skicka e-post om underättelser';
$txt['paid_email_desc'] = 'Informera  administratör när en prenumeration ändras automatiskt.';
$txt['paid_email_to'] = 'E-post för Korrespondens';
$txt['paid_email_to_desc'] = 'Comma seperated list of addresses to email notifications to in addition to forum admins.';
$txt['paidsubs_test'] = 'Aktivera testläge';
$txt['paidsubs_test_desc'] = 'This puts the paid subscriptions mod into &quot;test&quot; mode, which will, whereever possible, use sandbox payment methods in paypal etc. Do not enable unless you know what you are doing!';
$txt['paidsubs_test_confirm'] = 'Är du säker på att du vill aktivera testläge?';
$txt['paid_email_no'] = 'Skicka inga underrättelser';
$txt['paid_email_error'] = 'Informera när prenumeration misslyckas';
$txt['paid_email_all'] = 'Informera om alla ändringar automatiska prenumerationer';
$txt['paid_currency'] = 'Select Currency';
$txt['paid_currency_code'] = 'Currency Code';
$txt['paid_currency_code_desc'] = 'Kod - betalningsmetoder';
$txt['paid_currency_symbol'] = 'Symbol använd av betalningsmetod';
$txt['paid_currency_symbol_desc'] = 'Använd \'%1.2f\' för att tala om var siffrorna ska vara t.ex. $%1.2f, %1.2fKr osv';

$txt['paypal_email'] = 'Paypal e-postadress';
$txt['paypal_email_desc'] = 'Lämna blankt om du inte tänker använda paypal.';

$txt['authorize_id'] = 'Authorize.net Installations ID';
$txt['authorize_id_desc'] = 'Det installerade ID som genererats av Authorize.net. Lämnas tomt om inte Authorize.net. används.';
$txt['authorize_transid'] = 'Authorize.Net Transaktions-ID';

$txt['2co_id'] = '2checkout.com Install ID';
$txt['2co_id_desc'] = 'Det installerade ID som genererades av 2co.com. Lämnas tomt om inte 2co.com används.';
$txt['2co_password'] = '2checkout.com Secret Word';
$txt['2co_password_desc'] = 'Ditt 2checkout hemliga ord';
$txt['2co_password_wrong'] = 'Your 2checkout secret word was not accepted.';

$txt['paid_settings_save'] = 'Spara';

$txt['paid_note'] = '<strong class="alert">Note:</strong><br />For subscriptions to be automatically updated for your users, you
	will need to setup a return URL for each of your payment methods. For all payment types, this return URL should be set as:<br /><br />
	&nbsp;&nbsp;&bull;&nbsp;&nbsp;<strong>{board_url}/subscriptions.php</strong><br /><br />
	You can edit the link for PayPal directly <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ipn-notify" target="_blank">by clicking here</a>.<br />
	For the other gateways (if installed) you can normally find it in your customer panels, usually under the term &quot;Return URL&quot; or &quot;Callback URL&quot;.';

// View subscription strings.
$txt['paid_name'] = 'Namn';
$txt['paid_status'] = 'Status';
$txt['paid_cost'] = 'Cost';
$txt['paid_duration'] = 'Duration';
$txt['paid_active'] = 'Aktiv';
$txt['paid_pending'] = 'Avvaktande betalning';
$txt['paid_finished'] = 'Finished';
$txt['paid_total'] = 'Totalt';
$txt['paid_is_active'] = 'Activated';
$txt['paid_none_yet'] = 'Du har ännu inte satt upp några prenumerationer.';
$txt['paid_none_ordered'] = 'You don\'t any subscriptions.';
$txt['paid_payments_pending'] = 'Betalningar - avvaktar';
$txt['paid_order'] = 'Beställning';

$txt['yes'] = 'Ja';
$txt['no'] = 'Nej';

// Add/Edit/Delete subscription.
$txt['paid_add_subscription'] = 'Add New Subscription';
$txt['paid_edit_subscription'] = 'Ändra prenumeration';
$txt['paid_delete_subscription'] = 'Avsluta abonnemang';

$txt['paid_mod_name'] = 'Prenumerationens namn';
$txt['paid_mod_desc'] = 'Beskrivning';
$txt['paid_mod_reminder'] = 'Send Reminder Email';
$txt['paid_mod_reminder_desc'] = 'Antal dagar innan prenumerationen går ut som påminnelse skickas. (I dagar räknat. 0 för att avaktivera)';
$txt['paid_mod_email'] = 'Epost som skickas när det är färdigt';
$txt['paid_mod_email_desc'] = 'Där {NAME} är medlemmens namn; {FORUM} är forumets namn. Ämnet i mailet ska stå på första raden. Lämnas tomt för att inte skicka epostavisering';
$txt['paid_mod_cost_usd'] = 'Cost (USD)';
$txt['paid_mod_cost_eur'] = 'Cost (EUR)';
$txt['paid_mod_cost_gbp'] = 'Cost (GBP)';
$txt['paid_mod_cost_blank'] = 'Lämna tomt för att inte erbjuda denna valuta';
$txt['paid_mod_span'] = 'Prenumerationens längd';
$txt['paid_mod_span_days'] = 'Days';
$txt['paid_mod_span_weeks'] = 'Weeks';
$txt['paid_mod_span_months'] = 'Months';
$txt['paid_mod_span_years'] = 'Years';
$txt['paid_mod_active'] = 'Aktiv';
$txt['paid_mod_active_desc'] = 'En prenumeration måste vara aktiv innan nya medlemmar kan gå med.';
$txt['paid_mod_prim_group'] = 'Primär grupp för prenumeration';
$txt['paid_mod_prim_group_desc'] = 'Primär grupp att flytta nya användare till när de söker.';
$txt['paid_mod_add_groups'] = 'Ytterligare grupper vid prenumeration';
$txt['paid_mod_add_groups_desc'] = 'Ytterligare grupper att lägga till användare i, efter prenumeration.';
$txt['paid_mod_no_group'] = 'Don\'t Change';
$txt['paid_mod_edit_note'] = 'Notera att denna grupp innehåller prenumeranter och gruppinställningarna kan inte ändras.';
$txt['paid_mod_delete_warning'] = '	<strong>VARNING</strong><br /><br />Om du raderar denna prenumeration kommer samtliga medlemmar att tappa de rättigheter de fick vid prenumerationen. Är du osäker så är det bättre att avaktivera den snarare än att ta bort den.<br /> ';
$txt['paid_mod_repeatable'] = 'Tillåt användare att automatiskt förnya denna prenumeration.';
$txt['paid_mod_allow_partial'] = 'Tillåt del av prenumeration';
$txt['paid_mod_allow_partial_desc'] = 'Om detta tillval är valt och en ny användare betalar mindre än erfordrat, kommer de få prenumerationen för motsvarande den del av prenumerationen de betalt för.';
$txt['paid_mod_fixed_price'] = 'Prenumeration för fast pris och period';
$txt['paid_mod_flexible_price'] = 'Prenumerationens pris är beroende på vald tid';
$txt['paid_mod_price_breakdown'] = 'Flexibel prisfördelning';
$txt['paid_mod_price_breakdown_desc'] = 'Definiera hur mycket prenumerationen ska kosta beroende på perioden  de prenumererar på. Till exempel kan det kosta 120 kr. för en månad men bara 1000 kr. för ett år. Vill du inte ange ett pris för en period så lämna det tomt.';
$txt['flexible'] = 'Flexible';

$txt['paid_per_day'] = 'Price Per Day';
$txt['paid_per_week'] = 'Price Per Week';
$txt['paid_per_month'] = 'Price Per Month';
$txt['paid_per_year'] = 'Price Per Year';
$txt['day'] = 'Day';
$txt['week'] = 'Week';
$txt['month'] = 'Month';
$txt['year'] = 'Year';

// View subscribed users.
$txt['viewing_users_subscribed'] = 'Visar användare';
$txt['view_users_subscribed'] = 'Visar användare som prenumererar på: &quot;%1$s&quot; ';
$txt['no_subscribers'] = 'There are currently no subscribers to this subscription.';
$txt['add_subscriber'] = 'Lägg till prenumerant';
$txt['edit_subscriber'] = 'Ändra prenumerant';
$txt['delete_selected'] = 'Radera markerade';
$txt['complete_selected'] = 'Slutför markerade';

// @todo These strings are used in conjunction with JavaScript.  Use numeric entities.
$txt['delete_are_sure'] = 'Are you sure you want to delete all record of the selected subscriptions?';
$txt['complete_are_sure'] = 'Vill du verkligen slutföra de markerade prenumerationerna?';

$txt['start_date'] = 'Startdatum';
$txt['end_date'] = 'Slutdatum';
$txt['start_date_and_time'] = 'Startdatum och tid';
$txt['end_date_and_time'] = 'Slutdatum och tid';
$txt['one_username'] = 'Ange endast ett anvnädarnamn.';
$txt['minute'] = 'Minute';
$txt['error_member_not_found'] = 'Den angivna medlemmen kunde inte hittas';
$txt['member_already_subscribed'] = 'Medlemmen prenumererar redan på denna prenumeration. Ändra i deras existerande prenumeration.';
$txt['search_sub'] = 'Find User';

// Make payment.
$txt['paid_confirm_payment'] = 'Bekräfta betalning';
$txt['paid_confirm_desc'] = 'För att fortsätta till betalning, vänligen kontrollera detaljerna nedan och klicka på &quot;Order&quot; ';
$txt['paypal'] = 'PayPal';
$txt['paid_confirm_paypal'] = 'För att betala med <a href="http://www.paypal.com">PayPal</a> vänligen klicka på knappen nedanför. Du kommer skickas vidare till Paypals webbplats för betalning.';
$txt['paid_paypal_order'] = 'Beställ med PayPal';
$txt['authorize'] = 'Authorize.Net';
$txt['paid_confirm_authorize'] = 'För att betala med <a href="http://www.authorize.net">Authorize.Net</a> vänligen klicka på knappen nedan. Du kommer skickas vidare till  Authorize.Net webbplats för betalning.';
$txt['paid_authorize_order'] = 'Beställ med Authorize.Net';
$txt['2co'] = '2checkout';
$txt['paid_confirm_2co'] = 'För att betala med <a href="http://www.2co.com">2co.com</a> Vänligen klicka på knappen nedan. Du kommer skickas vidare till 2co.com webbplats för betalning';
$txt['paid_2co_order'] = 'Beställ med 2co.com';
$txt['paid_done'] = 'Payment Complete';
$txt['paid_done_desc'] = 'Tack för din betalning. Så fort din betalning bekräftats kommer din prenumeration aktiveras.';
$txt['paid_sub_return'] = 'Återvänd till prenumerationer';
$txt['paid_current_desc'] = 'Nedan är en lista på nuvarande- och avslutade prenumerationer. För att förlänga en prenumeration behöver du bara välja den i listan ovanför.';
$txt['paid_admin_add'] = 'Lägg till denna prenumeration';

$txt['paid_not_set_currency'] = 'You have not setup your currency yet. Please do so from the settings menu before continuing';
$txt['paid_no_cost_value'] = 'Du måste ange pris och prenumerationens längd.';
$txt['paid_all_freq_blank'] = 'Du måste ange ett pris för minst en av de fyra perioderna.';

// Some error strings.
$txt['paid_no_data'] = 'Ingen giltig data skickades till skriptet.';

$txt['paypal_could_not_connect'] = 'Kunde inte få kontakt med Paypals server.';
$txt['paypal_currency_unkown'] = 'The currency code from PayPal (%1$s) does not match the code in your settings (%2$s)';
$txt['paid_sub_not_active'] = 'That subscription is not taking any new users.';
$txt['paid_disabled'] = 'Paid subscriptions are currently disabled.';
$txt['paid_unknown_transaction_type'] = 'Okänd typ av transaktion för betald prenumeration.';
$txt['paid_empty_member'] = 'Betald prenumerationshanterare kunde inte återskapa medlems-ID';
$txt['paid_could_not_find_member'] = 'Betald prenumerationshanterare kunde inte hitta medlems-ID: %1$d';
$txt['paid_count_not_find_subscription'] = 'Betald prenumerationshanterare kunde inte hitta prenumeration för medlems-ID: %1$s, prenumerations-ID: %2$s ';
$txt['paid_count_not_find_subscription_log'] = 'Betald prenumerationshanterare kunde inte hitta prenumerationsloggpost för medlems-ID: %1$s, prenumerations-ID: %2$s ';
$txt['paid_count_not_find_outstanding_payment'] = 'Coud not find outstanding payment entry for member ID: %1$s, subscription ID: %2$s so ignoring';
$txt['paid_admin_not_setup_gateway'] = 'Sorry but the admin has not yet finished setting up paid subscriptions - please check back later.';
$txt['paid_make_recurring'] = 'Gör detta till en återkommande betalning';

$txt['subscriptions'] = 'Prenumerationer';
$txt['subscription'] = 'Prenumeration';
$txt['subscribers'] = 'Subscribers';
$txt['paid_subs_desc'] = 'Below is a list of all the subscriptions which are available on this site.';
$txt['paid_subs_none'] = 'There are currently no paid subscriptions available.';

$txt['paid_current'] = 'Existerande prenumerationer';
$txt['pending_payments'] = 'Väntande betalningar';
$txt['pending_payments_desc'] = 'Denna medlem har försökt betala denna prenumeration men bekräftelse har inte mottagits av forumet. Om du är säker på att betalning mottagits klicka &quot;acceptera&quot; för prenumerationen. Annars kan du klicka på &quot;Ta bort&quot; ';
$txt['pending_payments_value'] = 'Value';
$txt['pending_payments_accept'] = 'Accept';
$txt['pending_payments_remove'] = 'Ta bort';