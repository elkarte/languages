<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'ElkArte User Help';

$txt['manual_welcome'] = 'Welcome to %s, powered by ElkArte Forum software!';
$txt['manual_introduction'] = 'ElkArte is the elegant, effective, powerful and free forum software solution that this site is running. It allows users to communicate in discussion topics on a given subject in a clever and organized manner. Furthermore, it has a number of powerful features which end users can take advantage of. Help for many of ElkArte\'s features can be found by either clicking the question mark icon next to the relevant section or by selecting one of the links on this page. These links will take you to ElkArte\'s centrally-located documentation on the ElkArte official site.';
$txt['manual_docs_and_credits'] = 'For more information about how to use ElkArte, please see the <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> and check out the <a href="%2$s">credits</a> to find out who has made ElkArte what it is today.';

$txt['manual_section_registering_title'] = 'Att registrera sig';
$txt['manual_section_logging_in_title'] = 'Att logga in';
$txt['manual_section_profile_title'] = 'Profilen';
$txt['manual_section_search_title'] = 'Sök';
$txt['manual_section_posting_title'] = 'Att posta inlägg';
$txt['manual_section_bbc_title'] = 'Bulletin Board Code (BB-kod)';
$txt['manual_section_personal_messages_title'] = 'Privata meddelanden';
$txt['manual_section_memberlist_title'] = 'Medlemslista';
$txt['manual_section_calendar_title'] = 'Kalender';
$txt['manual_section_features_title'] = 'Funktioner';

$txt['manual_section_registering_desc'] = 'Många forum kräver att man registrerar sig som medlem för att få full tillgång till alla funktioner.';
$txt['manual_section_logging_in_desc'] = 'Efter att man registrerat sig måste man logga in för att komma åt sitt konto.';
$txt['manual_section_profile_desc'] = 'Varje medlem har en egen personlig profil.';
$txt['manual_section_search_desc'] = 'Sökfunktionen är ett oerhört användbart verktyg för att hitta information i inlägg och ämnen.';
$txt['manual_section_posting_desc'] = 'Hela poängen med ett forum är att låta användare posta inlägg för att uttrycka sina åsikter.';
$txt['manual_section_bbc_desc'] = 'Inlägg kan få lite extra krydda med hjälp av BB-kod.';
$txt['manual_section_personal_messages_desc'] = 'Användare kan skicka privata meddelanden till varandra.';
$txt['manual_section_memberlist_desc'] = 'Medlemslistan visar alla medlemmar i ett forum.';
$txt['manual_section_calendar_desc'] = 'Användare kan hålla koll på evenemang, högtider och födelsedagar med hjälp av kalendern.';
$txt['manual_section_features_desc'] = 'Here is a list of the most popular features in ElkArte.';