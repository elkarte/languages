<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... no idea, sorry</em>';
$txt['who_admin'] = 'Viewing the admin portal';
$txt['who_moderate'] = 'Viewing the moderator portal';
$txt['who_generic'] = 'Viewing the %1$s';
$txt['who_unknown'] = '<em>Okänd handling</em>';
$txt['who_user'] = 'Användare';
$txt['who_time'] = 'Tid';
$txt['who_action'] = 'Aktivitet';
$txt['who_show1'] = 'Visa';
$txt['who_show_members_only'] = 'Endast medlemmar';
$txt['who_show_guests_only'] = 'Endast gäster';
$txt['who_show_spiders_only'] = 'Endast sökrobotar';
$txt['who_show_all'] = 'Alla';
$txt['who_no_online_spiders'] = 'Det är inga sökrobotar online.';
$txt['who_no_online_guests'] = 'Det är inga gäster online.';
$txt['who_no_online_members'] = 'Det är inga medlemmar online.';

$txt['whospider_login'] = 'Visar inloggningssidan.';
$txt['whospider_register'] = 'Visar registreringssidan.';
$txt['whospider_reminder'] = 'Visar påminnelsesidan.';

$txt['whoall_activate'] = 'Aktiverar sitt konto.';
$txt['whoall_buddy'] = 'Ändrar sin kompislista.';
$txt['whoall_coppa'] = 'Fyller i samtyckesformuläret för vårdnadshavare.';
$txt['whoall_credits'] = 'Läser credits-sidan';
$txt['whoall_emailuser'] = 'Skickar e-post till en annan medlem.';
$txt['whoall_groups'] = 'Visar medlemsgrupp sidan.';
$txt['whoall_help'] = 'Viewing the <a href="{help_url}">help page</a>.';
$txt['whoall_quickhelp'] = 'Läser ett popup-fönster med hjälp.';
$txt['whoall_pm'] = 'Läser sina privata meddelanden.';
$txt['whoall_auth'] = 'Loggar in på forumet.';
$txt['whoall_login'] = 'Visar inloggningssidan.';
$txt['whoall_login2'] = 'Visar inloggningssidan.';
$txt['whoall_logout'] = 'Loggar ut från forumet.';
$txt['whoall_markasread'] = 'Markerar ämnen som lästa eller olästa.';
$txt['whoall_mentions'] = 'Viewing their mentions list.';
$txt['whoall_modifykarma_applaud'] = 'Applåderar en medlem.';
$txt['whoall_modifykarma_smite'] = 'Ger uttryck åt en medlem.';
$txt['whoall_news'] = 'Läser nyheterna.';
$txt['whoall_notify'] = 'Ändrar sina underrättelseinställningar.';
$txt['whoall_notifyboard'] = 'Ändrar sina underrättelseinställningar.';
$txt['whoall_openidreturn'] = 'Loggar in med hjälp av OpenID.';
$txt['whoall_quickmod'] = 'Modererar en tavla.';
$txt['whoall_recent'] = 'Viewing a <a href="{recent_url}">list of recent topics</a>.';
$txt['whoall_register'] = 'Registrerar ett konto på forumet.';
$txt['whoall_reminder'] = 'Begär påminnelse om lösenord.';
$txt['whoall_reporttm'] = 'Anmäler ett ämne till en moderator.';
$txt['whoall_spellcheck'] = 'Använder stavningskontrollen.';
$txt['whoall_unread'] = 'Tittar på olästa ämnen sedan sitt senaste besök.';
$txt['whoall_unreadreplies'] = 'Tittar på olästa svar sedan sitt senaste besök.';
$txt['whoall_who'] = 'Viewing <a href="{who_url}">Who\'s Online</a>.';

$txt['whoall_collapse_collapse'] = 'Krymper en kategori.';
$txt['whoall_collapse_expand'] = 'Utökar en kategori.';
$txt['whoall_pm_removeall'] = 'Tar bort alla sina meddelanden.';
$txt['whoall_pm_send'] = 'Skickar ett privat meddelande.';
$txt['whoall_pm_send2'] = 'Skickar ett privat meddelande.';

$txt['whotopic_announce'] = 'Announcing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Tillåter en bilaga.';
$txt['whotopic_dlattach'] = 'Tittar på en bifogad fil.';
$txt['whotopic_deletemsg'] = 'Raderar ett meddelande.';
$txt['whotopic_editpoll'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Modifying a post in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Liking a message in the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Locking the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Locking the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Merging the topic &quot;<a href="%1$s">%2$s</a>&quot; with another topic.';
$txt['whotopic_movetopic'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_movetopic2'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_post'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Printing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderating the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Removing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Removing the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Sending the topic &quot;<a href="%1$s">%2$s</a>&quot; to a friend.';
$txt['whotopic_splittopics'] = 'Splitting the topic &quot;<a href="%1$s">%2$s</a>&quot; into two topics.';
$txt['whotopic_sticky'] = 'Pinned the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Stopped watching a topic.';
$txt['whotopic_vote'] = 'Voting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Started watching a topic.';

$txt['whopost_quotefast'] = 'Quoting a post from &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Redigerar registreringsvillkoren.';
$txt['whoadmin_featuresettings'] = 'Ändrar på egenskaper och inställningar för forumet.';
$txt['whoadmin_modlog'] = 'Läser moderatorsloggen.';
$txt['whoadmin_serversettings'] = 'Ändrar foruminställningar.';
$txt['whoadmin_packageget'] = 'Hämtar paket.';
$txt['whoadmin_packages'] = 'Tittar på pakethanteraren.';
$txt['whoadmin_permissions'] = 'Ändrar forumrättigheterna.';
$txt['whoadmin_pgdownload'] = 'Laddar hem ett paket.';
$txt['whoadmin_theme'] = 'Ändrar temainställningar.';
$txt['whoadmin_trackip'] = 'Spårar en IP-adress.';

$txt['whoallow_manageboards'] = 'Ändrar på tavel- och kategoriinställningar.';
$txt['whoallow_admin'] = 'Viewing the <a href="{admin_url}">administration center</a>.';
$txt['whoallow_ban'] = 'Redigerar bannlysningslistan.';
$txt['whoallow_boardrecount'] = 'Räknar om antal inlägg och ämnen på forumet.';
$txt['whoallow_calendar'] = 'Viewing the <a href="{calendar_url}">calendar</a>.';
$txt['whoallow_editnews'] = 'Redigerar nyheterna.';
$txt['whoallow_mailing'] = 'Skickar ett e-post-meddelande på forumet.';
$txt['whoallow_maintain'] = 'Utför rutinunderhåll av forumet.';
$txt['whoallow_manageattachments'] = 'Hanterar bifogade filer.';
$txt['whoallow_moderate'] = 'Viewing the <a href="{moderate_url}">Moderation Center</a>.';
$txt['whoallow_memberlist'] = 'Viewing the <a href="{memberlist_url}">member list</a>.';
$txt['whoallow_optimizetables'] = 'Optimerar databastabellerna.';
$txt['whoallow_repairboards'] = 'Reparerar databastabellerna.';
$txt['whoallow_search'] = '<a href="{search_url}">Searching</a> the forum.';
$txt['whoallow_search_results'] = 'Tittar på resultat av en sökning.';
$txt['whoallow_setcensor'] = 'Ändrar på censurerade ord.';
$txt['whoallow_setreserve'] = 'Ändrar listan på reserverade namn.';
$txt['whoallow_stats'] = 'Viewing the <a href="{stats_url}">forum stats</a>.';
$txt['whoallow_viewErrorLog'] = 'Tittar på felloggen.';
$txt['whoallow_viewmembers'] = 'Tittar på lista över medlemmar.';

$txt['who_topic'] = 'Viewing the topic <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Viewing the board <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Viewing the board index of <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Viewing <a href="%1$s">%2$s</a>\'s profile.';
$txt['who_profile'] = 'Editing the profile of <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Posting a new topic in <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Posting a new poll in <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Email starting a new topic in <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Email posting in <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Sending a personal message by email.';

// Credits text
$txt['credits'] = 'Erkännanden';
$txt['credits_intro'] = 'ElkArte is 100% free and open-source. We encourage and support an active, open community that accepts contributions from the public.  We want to thank everyone who supported the project by providing code, feedback, bug reports, and opinions, as none of this would have been possible without you.  We also want to specially acknowledge <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, the project that ElkArte was born from.';
$txt['credits_contributors'] = 'Contributors';
$txt['credits_and'] = 'och';
$txt['credits_copyright'] = 'Copyright';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Add-ons';
$txt['credits_software_graphics'] = 'Software/Graphics';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Graphics';
$txt['credits_fonts'] = 'Fonts';
$txt['credits_groups_contrib'] = 'Contributors';
$txt['credits_contrib_list'] = 'For a complete list of the many individuals that contributed to the design and implementation of Elkarte, please refer to the official GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">list of contributors.</a>';
$txt['credits_license'] = 'License';
$txt['credits_copyright'] = 'Copyright';
$txt['credits_version'] = 'Version';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Språköversättare';
$txt['credits_translators_message'] = 'Thank you for your efforts which make it possible for people all around the world to use ElkArte.  For a complete list please refer to the offical Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">list of contributors.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';