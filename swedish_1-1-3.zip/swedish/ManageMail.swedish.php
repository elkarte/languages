<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Från denna sida kan du konfigurera dina e-postinställningar, samt visa och administrera den nuvarande e-postkön, om den funktionen har aktiverats.';
$txt['mail_settings'] = 'Mail Settings';

$txt['mail_type'] = 'Metod för e-postutskick';
$txt['mail_type_default'] = '(PHP:s standard)';
$txt['smtp_host'] = 'SMTP-server';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'SMTP-port';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'Användarnamn för SMTP';
$txt['smtp_password'] = 'Lösenord för SMTP';

$txt['mail_queue'] = 'Enable mail queue';
$txt['mail_period_limit'] = 'Max antal e-postmeddelanden att skicka per minut';
$txt['mail_period_limit_desc'] = '(Sätt till 0 för att inaktivera)';
$txt['mail_batch_size'] = 'Max antal e-postmeddelanden att skicka per sidladdning';

$txt['mailqueue_stats'] = 'Mail queue statistics';
$txt['mailqueue_oldest'] = 'Äldsta meddelandet';
$txt['mailqueue_oldest_not_available'] = 'N/A ';
$txt['mailqueue_size'] = 'Queue length';

$txt['mailqueue_age'] = 'Ålder';
$txt['mailqueue_priority'] = 'Prioritet';
$txt['mailqueue_recipient'] = 'Mottagare';
$txt['mailqueue_subject'] = 'Ämne';
$txt['mailqueue_clear_list'] = 'Send mail queue now';
$txt['mailqueue_no_items'] = 'E-postkön är för närvarande tom';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Är du säker på att du vill skicka hela e-postkön nu? Detta kommer att åsidosätta eventuella satta begränsningar.';

$txt['mq_day'] = '%1.1f dag';
$txt['mq_days'] = '%1.1f dagar';
$txt['mq_hour'] = '%1.1f timme';
$txt['mq_hours'] = '%1.1f timmar';
$txt['mq_minute'] = '%1$d minut';
$txt['mq_minutes'] = '%1$d minuter';
$txt['mq_second'] = '%1$d sekund';
$txt['mq_seconds'] = '%1$d sekunder';

$txt['mq_mpriority_5'] = 'Väldigt låg';
$txt['mq_mpriority_4'] = 'Låg';
$txt['mq_mpriority_3'] = 'Normalt';
$txt['mq_mpriority_2'] = 'Hög';
$txt['mq_mpriority_1'] = 'Väldigt hög';

$txt['birthday_email'] = 'Birthday message to use';
$txt['birthday_body'] = 'Email body';
$txt['birthday_subject'] = 'Email subject';