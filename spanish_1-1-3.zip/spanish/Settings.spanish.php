<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'El tema por defecto de ElkArte.<br /><br />Autor: Contribuidores de ElkArte';