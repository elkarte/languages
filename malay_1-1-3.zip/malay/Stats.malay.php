<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Terlama Online';

$txt['stats_center'] = 'Pusat Statistik';
$txt['general_stats'] = 'Statistik Umum';
$txt['top_posters'] = '10 Penulis Terbanyak';
$txt['top_boards'] = '10 RuanganTerhangat';
$txt['forum_history'] = 'Rekod Forum (menggunakan jarak waktu forum)';
$txt['stats_new_topics'] = 'Topik Baru';
$txt['stats_new_posts'] = 'Pos Baru';
$txt['stats_new_members'] = 'Ahli Baru';
$txt['page_views'] = 'Laman Dilihat';
$txt['top_topics_replies'] = '10 Topik Terhangat (Jawapan)';
$txt['top_topics_views'] = '10 Topik Terhangat (Dilayari)';
$txt['yearly_summary'] = 'Ringkasan Tahunan';
$txt['top_starters'] = 'Pemula Topik Terbanyak';
$txt['most_time_online'] = 'Masa Terlama Online';

$txt['average_members'] = 'Purata pendaftaran sehari';
$txt['average_posts'] = 'Purata tulisan sehari';
$txt['average_topics'] = 'Purata topik sehari';
$txt['average_online'] = 'Purata online sehari';
$txt['users_online'] = 'Pengguna Online';
$txt['emails_sent'] = 'Purata Emel sehari';
$txt['users_online_today'] = 'Online Hari Ini';
$txt['num_hits'] = 'Total laman dilayari';
$txt['average_hits'] = 'Purata laman dilayari sehari';

$txt['ssi_comment'] = 'komen';
$txt['ssi_comments'] = 'komen';
$txt['ssi_write_comment'] = 'Tulis Komen';
$txt['ssi_no_guests'] = 'Anda tidak boleh menetapkan ruangan yang tidak menerima tetamu.  Sila semak ID ruangan sebelum mencuba lagi.';
$txt['xml_rss_desc'] = 'Maklumat langsung daripada {forum_name}';