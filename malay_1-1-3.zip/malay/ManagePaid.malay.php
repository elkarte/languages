<?php
// Version: 1.1; ManagePaid

// Symbols.
$txt['usd_symbol'] = '$%1.2f';
$txt['eur_symbol'] = '&euro;%1.2f';
$txt['gbp_symbol'] = '&pound;%1.2f';

$txt['usd'] = 'USD ($)';
$txt['eur'] = 'EURO (&euro;)';
$txt['gbp'] = 'GBP (&pound;)';
$txt['other'] = 'Lainnya';

$txt['paid_username'] = 'Nama pengguna';

$txt['paid_subscriptions_desc'] = 'Dari bahagian ini anda boleh tambah, padam dan edit cara langganan ke forum anda.';
$txt['paid_subs_settings'] = 'Tetapan';
$txt['paid_subs_settings_desc'] = 'Dari sini anda boleh edit cara pembayaran yang tersedia bagi para pengguna anda.';
$txt['paid_subs_view'] = 'Lihat Langganan';
$txt['paid_subs_view_desc'] = 'Dari bahagian ini anda boleh melihat semua langganan yang tersedia.';

// Setting type strings.
$txt['paid_enabled'] = 'Aktifkan Langganan Berbayar';
$txt['paid_enabled_desc'] = 'Ini mesti ditanda langganan berbayar untuk digunakan pada forum.';
$txt['paid_email'] = 'Kirim Mesej Pemberitahuan';
$txt['paid_email_desc'] = 'Maklumkan pengurus ketika langganan secara automatik berubah.';
$txt['paid_email_to'] = 'Mesej untuk Penerima';
$txt['paid_email_to_desc'] = 'Daftar dipisahkan koma atas alamat untuk makluman mesej sebagai tambahan bagi pengurus forum.';
$txt['paidsubs_test'] = 'Aktifkan bentuk ujian';
$txt['paidsubs_test_desc'] = 'Ini menyimpan bentuk langganan berbayar ke dalam bentuk &quot;ujian&quot;, yang akan menjadi bak percubaan cara pembayaran dalam paypal dll. Jangan hidupkan kecuali anda mengetahui apa yang sedang anda kerjakan!';
$txt['paidsubs_test_confirm'] = 'Apakah anda pasti anda mahu menghidupkan mode ujian?';
$txt['paid_email_no'] = 'Jangan kirim makluman apapun';
$txt['paid_email_error'] = 'Maklumkan ketika langganan gagal';
$txt['paid_email_all'] = 'Maklumkan ketika semua langganan automatik berubah';
$txt['paid_currency'] = 'Pilih Matawang';
$txt['paid_currency_code'] = 'Kod Matawang';
$txt['paid_currency_code_desc'] = 'Kod yang dipakai oleh pembayaran';
$txt['paid_currency_symbol'] = 'Simbol yang dipakai oleh cara pembayaran';
$txt['paid_currency_symbol_desc'] = 'Gunakan \'%1.2f\' untuk menetapkan di mana angka berada, misalnya $%1.2f, %1.2fDM dll';

$txt['paypal_email'] = 'Alamat mesej Paypal';
$txt['paypal_email_desc'] = 'Biarkan kosong jika anda tidak ingin menggunakan paypal.';

$txt['authorize_id'] = 'ID Install Authorize.net';
$txt['authorize_id_desc'] = 'ID Install dibuat oleh Authorize.net. Biarkan kosong jika anda tidak menggunakan Authorize.net';
$txt['authorize_transid'] = 'ID Transaksi Authorize.Net';

$txt['2co_id'] = 'ID Install 2co.com';
$txt['2co_id_desc'] = 'ID Install dibuat oleh 2co.com. Biarkan kosong jika anda tidak menggunakan 2co.com';
$txt['2co_password'] = 'Kata Rahasia 2co.com';
$txt['2co_password_desc'] = 'Kata rahasia 2checkout anda.';
$txt['2co_password_wrong'] = 'Kata rahsia 2checkout anda tidak diterima.';

$txt['paid_settings_save'] = 'Simpan';

$txt['paid_note'] = '<strong class="alert">Nota:</strong><br />Untuk semua langganan pengguna anda dikemaskinikan secara automatik, anda⏎
⇥perlu memasang URL kembalian bagi setiap cara pembayaran anda. Untuk jenis semua  pembayaran, URL kembalian ini mesti ditetapkan sebagai:<br /><br />⏎
⇥&nbsp;&nbsp;&bull;&nbsp;&nbsp;<strong>{board_url}/subscriptions.php</strong><br /><br />⏎
⇥Anda boleh mengubah pautan PayPal <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ipn-notify" target="_blank">di sini</a> terus.<br />⏎
⇥Untuk cara lain (sekiranya dipasang) anda boleh mencarinya dalam semua panel pelanggan anda, selalunya di bawah terma &quot;URL Kembalian&quot; atau &quot;URL Panggilan&quot;.';

// View subscription strings.
$txt['paid_name'] = 'Nama';
$txt['paid_status'] = 'Status';
$txt['paid_cost'] = 'Biaya';
$txt['paid_duration'] = 'Jangkamasa';
$txt['paid_active'] = 'Aktif';
$txt['paid_pending'] = 'Pembayaran Tertunggak';
$txt['paid_finished'] = 'Selesai';
$txt['paid_total'] = 'Jumlah';
$txt['paid_is_active'] = 'Diaktifkan';
$txt['paid_none_yet'] = 'Anda belum menyiapkan langganan apapun.';
$txt['paid_none_ordered'] = 'Anda tiada langganan.';
$txt['paid_payments_pending'] = 'Pembayaran Tertunggak';
$txt['paid_order'] = 'Order';

$txt['yes'] = 'Ya';
$txt['no'] = 'Tidak';

// Add/Edit/Delete subscription.
$txt['paid_add_subscription'] = 'Tambah Langganan Baru';
$txt['paid_edit_subscription'] = 'Edit Langganan';
$txt['paid_delete_subscription'] = 'Padam Langganan';

$txt['paid_mod_name'] = 'Nama Langganan';
$txt['paid_mod_desc'] = 'Keterangan';
$txt['paid_mod_reminder'] = 'Kirim Mesej Pengingat';
$txt['paid_mod_reminder_desc'] = 'Hari sebelum langganan berakhir untuk mengirimkan pengingat. (Dalam hari, 0 untuk mematikan)';
$txt['paid_mod_email'] = 'Mesej untuk Dikirim setelah Selesai';
$txt['paid_mod_email_desc'] = 'Di mana {NAME} adalah nama ahli; {FORUM} adalah nama komuniti. Subjek mesej mesti pada baris pertama. Kosong untuk tanpa makluman mesej.';
$txt['paid_mod_cost_usd'] = 'Biaya (USD)';
$txt['paid_mod_cost_eur'] = 'Biaya (EUR)';
$txt['paid_mod_cost_gbp'] = 'Biaya (GBP)';
$txt['paid_mod_cost_blank'] = 'Biarkan ini kosong untuk tidak menawarkan kurs ini.';
$txt['paid_mod_span'] = 'Lama Langganan';
$txt['paid_mod_span_days'] = 'Hari';
$txt['paid_mod_span_weeks'] = 'Minggu';
$txt['paid_mod_span_months'] = 'Bulan';
$txt['paid_mod_span_years'] = 'Tahun';
$txt['paid_mod_active'] = 'Aktif';
$txt['paid_mod_active_desc'] = 'Langganan mesti aktif agar ahli baru boleh bergabung.';
$txt['paid_mod_prim_group'] = 'Grup Utama setelah Langganan';
$txt['paid_mod_prim_group_desc'] = 'Grup utama untuk menyimpan ahli ketika mereka berlanggan.';
$txt['paid_mod_add_groups'] = 'Grup Tambahan setelah Langganan';
$txt['paid_mod_add_groups_desc'] = 'Grup tambahan untuk menambahkan pengguna setelah langganan.';
$txt['paid_mod_no_group'] = 'Jangan Ubah';
$txt['paid_mod_edit_note'] = 'Catatan bahawa kerana grup ini mempunyai pelanggan yang telah ada, tetapan grup tidak boleh diubah!';
$txt['paid_mod_delete_warning'] = '<strong>AMARAN</strong><br /><br />Jika anda memadam langganan ini, semua ahli yang ketika ini berlanggan akan kehilangan setiap hak akses yang diberikan dengan langganan. Kecuali anda pasti ingin melakukan ini, disarankan bahawa anda cukup mematikan langganan daripada memadamnya.<br />';
$txt['paid_mod_repeatable'] = 'Izinkan pengguna untuk automatik-memperbarui langganan ini';
$txt['paid_mod_allow_partial'] = 'Izinkan langganan parsial';
$txt['paid_mod_allow_partial_desc'] = 'Jika opsi ini dihidupkan, dalam hal di mana pengguna membayar kurang dari yang diperlukan, mereka akan diberi hak langganan untuk peratusan dari jangkamasa yang telah mereka bayarkan.';
$txt['paid_mod_fixed_price'] = 'Langganan untuk harga tetap dan periodik';
$txt['paid_mod_flexible_price'] = 'Harga langganan berubah dengan urutan jangkamasa';
$txt['paid_mod_price_breakdown'] = 'Potongan Harga Fleksibel';
$txt['paid_mod_price_breakdown_desc'] = 'Tetapkan di sini seberapa banyak biaya langganan berdiri sendiri tergantung pada jangkamasa langganan mereka. Sebagai contoh, ia dikenakan 12USD untuk berlanggan satu bulan, tapi hanya 100USD untuk satu tahun. Jika anda tidak ingin menetapkan harga untuk jangka waktu tertentu, biarkan kosong.';
$txt['flexible'] = 'Fleksibel';

$txt['paid_per_day'] = 'Harga Satu Hari';
$txt['paid_per_week'] = 'Harga Satu Minggu';
$txt['paid_per_month'] = 'Harga Satu Bulan';
$txt['paid_per_year'] = 'Harga Satu Tahun';
$txt['day'] = 'Hari';
$txt['week'] = 'Minggu';
$txt['month'] = 'Bulan';
$txt['year'] = 'Tahun';

// View subscribed users.
$txt['viewing_users_subscribed'] = 'Melihat Pengguna';
$txt['view_users_subscribed'] = 'Melihat pengguna yang berlanggan ke: &quot;%1$s&quot;';
$txt['no_subscribers'] = 'Ketika ini tidak ada pelanggan ke langganan ini!';
$txt['add_subscriber'] = 'Tambah Pelanggan Baru';
$txt['edit_subscriber'] = 'Edit Pelanggan';
$txt['delete_selected'] = 'Padam Pilihan';
$txt['complete_selected'] = 'Tamatkan Pilihan';

// @todo These strings are used in conjunction with JavaScript.  Use numeric entities.
$txt['delete_are_sure'] = 'Anda pasti ingin memadam semua rekod langganan pilihan?';
$txt['complete_are_sure'] = 'Anda pasti ingin menamatkan langganan ilihan?';

$txt['start_date'] = 'Tarikh Mula';
$txt['end_date'] = 'Tarikh Akhir';
$txt['start_date_and_time'] = 'Tarikh dan Jam Mula';
$txt['end_date_and_time'] = 'Tarikh dan Jam Akhir';
$txt['one_username'] = 'Sila masukkan hanya satu nama pengguna.';
$txt['minute'] = 'Minit';
$txt['error_member_not_found'] = 'Ahli yang dimasukkan tidak boleh ditemukan';
$txt['member_already_subscribed'] = 'Ahli ini telah berlanggan ke langganan ini. Sila edit langganan yang telah ada.';
$txt['search_sub'] = 'Cari Pengguna';

// Make payment.
$txt['paid_confirm_payment'] = 'Pengesahan Pembayaran';
$txt['paid_confirm_desc'] = 'Untuk melanjutkan pembayaran, sila tanda detail di bawah ini dan tekan &quot;Pesan&quot;';
$txt['paypal'] = 'PayPal';
$txt['paid_confirm_paypal'] = 'Untuk membayar menggunakan <a href="http://www.paypal.com">PayPal</a> sila klik tombol di bawah. Anda akan dialihkan ke situs PayPal untuk pembayaran.';
$txt['paid_paypal_order'] = 'Pesan dengan PayPal';
$txt['authorize'] = 'Authorize.Net';
$txt['paid_confirm_authorize'] = 'Untuk membayar menggunakan <a href="http://www.authorize.net">Authorize.Net</a> sila klik tombol di bawah. Anda akan dialihkan ke situs Authorize.Net untuk pembayaran.';
$txt['paid_authorize_order'] = 'Pesan dengan Authorize.Net';
$txt['2co'] = '2checkout';
$txt['paid_confirm_2co'] = 'Untuk membayar menggunakan <a href="http://www.2com.com">2co.com</a> sila klik butang di bawah. Anda akan dibawa ke laman 2com.com untuk pembayaran.';
$txt['paid_2co_order'] = 'Pesan dengan 2co.com';
$txt['paid_done'] = 'Pembayaran Selesasi';
$txt['paid_done_desc'] = 'Terima kasih atas pembayaran anda. Setelah transaksi diverifikasi, langganan akan diaktifkan.';
$txt['paid_sub_return'] = 'Kembali ke Langganan';
$txt['paid_current_desc'] = 'Di bawah ini adalah senarai semua langganan anda ketika ini dan sebelumnya. Untuk memperpanjang langganan cukup pilih ia dari senarai di atas.';
$txt['paid_admin_add'] = 'Tambah Langganan Ini';

$txt['paid_not_set_currency'] = 'Anda belum menyiapkan kurs anda. Sila lakukan itu dari menu tetapan sebelum melanjutkan';
$txt['paid_no_cost_value'] = 'Anda mesti memasukkan biaya dan lamanya berlanggan.';
$txt['paid_all_freq_blank'] = 'Anda mesti memasukkan biaya untuk setidaknya satu dari empat jangkamasa.';

// Some error strings.
$txt['paid_no_data'] = 'Data tidak ada yang benar yang dikirimkan pada naskah.';

$txt['paypal_could_not_connect'] = 'Tidak boleh menghubungi server PayPal';
$txt['paypal_currency_unkown'] = 'Kod matawang daripada PayPal (%1$s) tida sepadan dengan kod dalam tetapan  (%2$s) anda';
$txt['paid_sub_not_active'] = 'Langganan itu tidak membawa pengguna baru!';
$txt['paid_disabled'] = 'Langganan berbayar ketika ini dimatikan!';
$txt['paid_unknown_transaction_type'] = 'Jenis transaksi Langganan Berbayar Tidak Dikenal.';
$txt['paid_empty_member'] = 'Pengendali langganan berbayar tidak boleh menemukan ID ahli';
$txt['paid_could_not_find_member'] = 'Pengenali langganan berbayar tidak boleh menemukan ahli dengan ID: %1$d';
$txt['paid_count_not_find_subscription'] = 'Langganan berbayar tidak boleh menemukan langganan untuk ID ahli: %1$s, ID langganan: %2$s';
$txt['paid_count_not_find_subscription_log'] = 'Pengendali langganan berbayar tidak boleh menemukan entri log langganan untuk ID ahli: %1$s, ID langganan: %2$s';
$txt['paid_count_not_find_outstanding_payment'] = 'Tidak boleh menemukan entri pembayaran tertunda untuk ID ahli: %1$s, ID langganan: %2$s maka diabaikan';
$txt['paid_admin_not_setup_gateway'] = 'Maaf tapi pengurus belum menyelesaikan tetapan langganan berbayar - sila periksa kembali nanti.';
$txt['paid_make_recurring'] = 'Jadikan ini pembayaran berulang';

$txt['subscriptions'] = 'Langganan';
$txt['subscription'] = 'Langganan';
$txt['subscribers'] = 'Pelanggan';
$txt['paid_subs_desc'] = 'Di bawah ini adalah senarai semua langganan yang tersedia pada forum ini.';
$txt['paid_subs_none'] = 'Saat ini tidak ada tersedia langganan berbayar!';

$txt['paid_current'] = 'Langganan Yang Ada';
$txt['pending_payments'] = 'Pembayaran Tertunggak';
$txt['pending_payments_desc'] = 'Ahli ini telah mencuba untuk melakukan pembayaran berikut untuk langganan ini tapi pengesahan belum diterima oleh forum. Jika anda pasti pembayaran telah diterima, klik &quot;terima&quot; untuk menindak lanjuti langganan. Alternatifnya anda boleh klik &quot;Padam&quot; untuk memadam semua rujukan terhadap pembayaran.';
$txt['pending_payments_value'] = 'Nilai';
$txt['pending_payments_accept'] = 'Terima';
$txt['pending_payments_remove'] = 'Buang';