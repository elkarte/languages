<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Indeks Mesej Peribadi';
$txt['pm_add'] = 'Tambah';
$txt['make_bcc'] = 'Tambah BCC';
$txt['pm_to'] = 'Untuk';
$txt['pm_bcc'] = 'Bcc';
$txt['inbox'] = 'Inbox';
$txt['conversation'] = 'Perbualan';
$txt['messages'] = 'Mesej';
$txt['sent_items'] = 'Item Terkirim';
$txt['new_message'] = 'Mesej Baru';
$txt['delete_message'] = 'Padam Mesej';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Padam semua mesej dalam PMBOX anda';
$txt['delete_all_confirm'] = 'Anda yakin ingin memadam semua mesej?';

$txt['delete_selected_confirm'] = 'Anda yakin ingin memadam semua mesej peribadi pilihan?';

$txt['sent_to'] = 'Kirim ke';
$txt['reply_to_all'] = 'Jawab ke Semua';
$txt['delete_conversation'] = 'Padam Perbualan';

$txt['pm_capacity'] = 'Kapasiti';
$txt['pm_currently_using'] = '%1$s mesej, %2$s%% penuh.';
$txt['pm_sent'] = 'Mesej anda telah berjaya dikirim.';

$txt['pm_error_user_not_found'] = 'Tidak boleh menemukan ahli \'%1$s\'.';
$txt['pm_error_ignored_by_user'] = 'Pengguna \'%1$s\' telah menyekat mesej peribadi anda.';
$txt['pm_error_data_limit_reached'] = 'Mesej tidak boleh dikirimkan ke \'%1$s\' karena inboxnya penuh!';
$txt['pm_error_user_cannot_read'] = 'Pengguna \'%1$s\' tidak boleh menerima mesej peribadi.';
$txt['pm_successfully_sent'] = 'Mesej sudah dikirim dengan jayanya ke \'%1$s\'.';
$txt['pm_send_report'] = 'Kirim laporan';
$txt['pm_undisclosed_recipients'] = 'Ungkap penerima';
$txt['pm_too_many_recipients'] = 'Anda tidak boleh mengirimkan mesej ke lebih dari %1$d penerima sekaligus.';

$txt['pm_read'] = 'Baca';
$txt['pm_replied'] = 'Jawab Ke';
$txt['pm_mark_unread'] = 'Tandakan sebagai Belum Dibaca';

// Message Pruning.
$txt['pm_prune'] = 'Padam Mesej';
$txt['pm_prune_desc'] = 'Padamkan mesej peribadi lebih lama daripada %1$s hari.';
$txt['pm_prune_warning'] = 'Anda yakin ingin memadam mesej peribadi anda?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Tindakan Lanjut';
$txt['pm_actions_delete_selected'] = 'Padam yang dipilih';
$txt['pm_actions_filter_by_label'] = 'Tapis Dengan Label';
$txt['pm_actions_go'] = 'Pergi';

// Manage Labels Screen.
$txt['pm_apply'] = 'Guna';
$txt['pm_manage_labels'] = 'Mengatur Label';
$txt['pm_labels_delete'] = 'Anda yakin ingin memadam label pilihan?';
$txt['pm_labels_desc'] = 'Dari sini anda boleh menambah, mengedit dan memadam label yang dipakai dalam pusat mesej peribadi anda.';
$txt['pm_label_add_new'] = 'Tambah Label Baru';
$txt['pm_label_name'] = 'Nama Label';
$txt['pm_labels_no_exist'] = 'Buat masa ini anda tidak menyediakan label!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Label';
$txt['pm_msg_label_title'] = 'Mesej Label';
$txt['pm_msg_label_apply'] = 'Tambah Label';
$txt['pm_msg_label_remove'] = 'Padam Label';
$txt['pm_msg_label_inbox'] = 'Inbox';
$txt['pm_sel_label_title'] = 'Label Dipilih';

// Sidebar Headings.
$txt['pm_labels'] = 'Label';
$txt['pm_messages'] = 'Mesej';
$txt['pm_actions'] = 'Tindakan';
$txt['pm_preferences'] = 'Keutamaan';

$txt['pm_is_replied_to'] = 'Anda telah meneruskan atau menjawab mesej ini.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Laporkan Ke Pengurus';
$txt['pm_report_title'] = 'Laporkan Mesej Peribadi';
$txt['pm_report_desc'] = 'Dari laman ini anda boleh melaporkan mesej peribadi yang anda terima ke pasukan pengurus forum. Pastikan untuk menyertakan penjelasan mengapa anda melaporkan mesej ini, karena ini akan dikirimkan bersama dengan isi dari mesej asalnya.';
$txt['pm_report_admins'] = 'Laporan dikirimkan ke pengurus';
$txt['pm_report_all_admins'] = 'Kirim ke semua pengurus forum';
$txt['pm_report_reason'] = 'Alasan mengapa anda melaporkan mesej ini';
$txt['pm_report_message'] = 'Laporkan Mesej';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[REPORT] ';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} telah melaporkan mesej peribadi di bawah ini, dikirimkan oleh {SENDER}, untuk alasan berikut:';
$txt['pm_report_pm_other_recipients'] = 'Penerima lain dari mesej ini termasuk:';
$txt['pm_report_pm_hidden'] = '%1$d penerima tersembunyi';
$txt['pm_report_pm_unedited_below'] = 'Di bawah ini adalah kandungan asal mesej peribadi yang dilaporkan:';
$txt['pm_report_pm_sent'] = 'Dikirimkan:';

$txt['pm_report_done'] = 'Terima kasih kerana mengirimkan laporan ini. Anda akan menerima jawapan dari pasukan pengurusan dalam waktu tidak lama lagi.';
$txt['pm_report_return'] = 'Kembali ke inbox';

$txt['pm_search_title'] = 'Cari Mesej Peribadi';
$txt['pm_search_bar_title'] = 'Cari Mesej';
$txt['pm_search_text'] = 'Mencari';
$txt['pm_search_go'] = 'Carian';
$txt['pm_search_advanced'] = 'Carian lengkap';
$txt['pm_search_simple'] = 'Sembunyikan pilihan canggih';
$txt['pm_search_user'] = 'Oleh pengguna';
$txt['pm_search_match_all'] = 'Padan semua perkataan';
$txt['pm_search_match_any'] = 'Padan setiap perkataan';
$txt['pm_search_options'] = 'Pilihan';
$txt['pm_search_post_age'] = 'Usia mesej';
$txt['pm_search_show_complete'] = 'Papar mesej lengkap dalam hasil.';
$txt['pm_search_subject_only'] = 'Cari hanya dengan subjek dan pembuat.';
$txt['pm_search_sent_only'] = 'Cari hanya dalam peti keluar.';
$txt['pm_search_between'] = 'antara';
$txt['pm_search_between_and'] = 'dan';
$txt['pm_search_between_days'] = 'hari';
$txt['pm_search_order'] = 'Urutan carian';
$txt['pm_search_choose_label'] = 'Pilih label untuk dicari, atau cari semua';

$txt['pm_search_results'] = 'Hasil Carian';
$txt['pm_search_none_found'] = 'Tidak Ada Mesej Ditemui';

$txt['pm_search_orderby_relevant_first'] = 'Paling berkaitan pertama';
$txt['pm_search_orderby_recent_first'] = 'Paling baru pertama';
$txt['pm_search_orderby_old_first'] = 'Terlama pertama';

$txt['pm_visual_verification_label'] = 'Pengesahan';
$txt['pm_visual_verification_desc'] = 'Sila masukkan kod dalam gambar di atas untuk mengirimkan mesej ini.';

$txt['pm_settings'] = 'Ubah Tetapan';
$txt['pm_change_view'] = 'Ubah Paparan';

$txt['pm_manage_rules'] = 'Urus Peraturan';
$txt['pm_manage_rules_desc'] = 'Peraturan mesej mengizinkan anda untuk mengurut secara automatik mesej yang datang berdiri sendiri sesuai set kriteria yang anda tetapkan. Di bawah ini adalah semua peraturan yang sekarang ini anda sediakan. Untuk mengedit peraturan cukup klik nama peraturan.';
$txt['pm_rules_none'] = 'Anda belum menyediakan peraturan mesej apapun.';
$txt['pm_rule_title'] = 'Peraturan';
$txt['pm_add_rule'] = 'Tambah Peraturan Baru';
$txt['pm_apply_rules'] = 'Terapkan Peraturan Sekarang';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Anda yakin ingin menetapkan peraturan semasa untuk semua mesej peribadi?';
$txt['pm_edit_rule'] = 'Edit Peraturan';
$txt['pm_rule_save'] = 'Simpan Peraturan';
$txt['pm_delete_selected_rule'] = 'Padam Peraturan Pilihan';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Anda yakin ingin memadam peraturan pilihan?';
$txt['pm_rule_name'] = 'Nama';
$txt['pm_rule_name_desc'] = 'Nama untuk mengingat peraturan ini';
$txt['pm_rule_name_default'] = '[NAMA]';
$txt['pm_rule_description'] = 'Keterangan';
$txt['pm_rule_not_defined'] = 'Tambah beberapa kriteria untuk mulakan membangun deskripsi peraturan ini.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>Catatan:</strong> Nampaknya anda telah mematikan javascript. Kami kuat menyarankan agar anda menghidupkan javascript untuk menggunakan ciri ini.</span>';
$txt['pm_rule_criteria'] = 'Kriteria';
$txt['pm_rule_criteria_add'] = 'Tambah Kriteria';
$txt['pm_rule_criteria_pick'] = 'Pilih Kriteria';
$txt['pm_rule_mid'] = 'Nama Pengirim';
$txt['pm_rule_gid'] = 'Grup Pengirim';
$txt['pm_rule_sub'] = 'Subjek Mesej Berisi';
$txt['pm_rule_msg'] = 'Badan Mesej Berisi';
$txt['pm_rule_bud'] = 'Pengirim adalah Teman';
$txt['pm_rule_sel_group'] = 'Pilih Grup';
$txt['pm_rule_logic'] = 'Ketika Memeriksa Kriteria';
$txt['pm_rule_logic_and'] = 'Semua kriteria mesti sesuai';
$txt['pm_rule_logic_or'] = 'Setiap kriteria boleh disesuaikan';
$txt['pm_rule_actions'] = 'Tindakan';
$txt['pm_rule_sel_action'] = 'Pilih Tindakan';
$txt['pm_rule_add_action'] = 'Tambah Tindakan';
$txt['pm_rule_label'] = 'Beri label mesej dengan';
$txt['pm_rule_sel_label'] = 'Pilih Label';
$txt['pm_rule_delete'] = 'Padam Mesej';
$txt['pm_rule_no_name'] = 'Anda lupa memasukkan nama untuk peraturan.';
$txt['pm_rule_no_criteria'] = 'Peraturan mesti mempunyai setidaknya satu kriteria dan satu set tindakan.';
$txt['pm_rule_too_complex'] = 'Peraturan yang anda buat terlalu panjang untuk disimpan SMF. Cuba pecah menjadi peraturan yang lebih pendek.';

$txt['pm_readable_and'] = '<em>dan</em>';
$txt['pm_readable_or'] = '<em>atau</em>';
$txt['pm_readable_start'] = 'Jika ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'mesej dari &quot;{MEMBER}&quot;';
$txt['pm_readable_group'] = 'pengirim dari grup &quot;{GROUP}&quot;';
$txt['pm_readable_subject'] = 'subjek mesej berisi &quot;{SUBJECT}&quot;';
$txt['pm_readable_body'] = 'badan mesej berisi &quot;{BODY}&quot;';
$txt['pm_readable_buddy'] = 'pengirim adalah teman';
$txt['pm_readable_label'] = 'terapkan label &quot;{LABEL}&quot;';
$txt['pm_readable_delete'] = 'padam mesej';
$txt['pm_readable_then'] = '<strong>kemudian</strong>';