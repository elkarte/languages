<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Ruangan';
$txt['admin_back_to'] = 'Kembali ke panel pengurus';
$txt['admin_users'] = 'Ahli';
$txt['admin_newsletters'] = 'Warkah Berita';
$txt['include_these'] = 'Ahli untuk dimasukkan';
$txt['exclude_these'] = 'Ahli untuk dikecualikan';
$txt['admin_newsletters_select_groups'] = 'Grup untuk dimasukkan';
$txt['admin_newsletters_exclude_groups'] = 'Grup untuk dikecualikan';
$txt['admin_edit_news'] = 'Berita';
$txt['admin_groups'] = 'Grup Ahli';
$txt['admin_members'] = 'Urus Ahli';
$txt['admin_members_list'] = 'Di bawah ini adalah senarai semua ahli yang sekarang ini berdaftar di forum anda.';
$txt['admin_next'] = 'Seterusnya';
$txt['admin_censored_words'] = 'Perkataan Dipotong';
$txt['admin_censored_where'] = 'Masukkan perkataan yang hendak ditapis di petak kiri, dan gantinya di petak kanan. Kemudian pilih jika anda mahu memeriksa keseluruhan perkataan dan besar/kecilnya. Setelah selesai, klik simpan. Entri berterusan boleh dibuat sebelum menyimpan dengan menekan butang \'Tambah perkataan lain\'.';
$txt['admin_censored_desc'] = 'Disebabkan dengan sifat awam forum, mungkin ada beberapa perkataan yang hendak anda larang daripada dipos oleh pengguna forum anda. Anda boleh memasukkan sebarang perkataan yang hendak ditapis di bawah ini.<br />Kosongkan petak untuk memadam perkataan.';
$txt['admin_reserved_names'] = 'Nama-nama Terpelihara';
$txt['admin_template_edit'] = 'Edit template forum anda';
$txt['admin_modifications'] = 'Tetapan Modifikasi';
$txt['admin_security_moderation'] = 'Sekuriti dan Seliaan';
$txt['admin_server_settings'] = 'Tetapan Server';
$txt['admin_reserved_set'] = 'Tetapkan Nama-nama Terpelihara';
$txt['admin_reserved_line'] = 'Satu perkataan terpelihara sebaris.';
$txt['admin_basic_settings'] = 'Laman ini membolehkan anda untuk mengubah tetapan asas forum anda. Harap berhati-hati dengan tetapan ini, kerana mereka boleh menyebabkan forum tidak berfungsi.';
$txt['admin_maintain'] = 'Aktifkan Mode Penyelenggaraan';
$txt['admin_title'] = 'Tajuk Forum';
$txt['admin_url'] = 'URL Forum';
$txt['cookie_name'] = 'Nama Cookie';
$txt['admin_webmaster_email'] = 'Alamat email webmaster';
$txt['boarddir'] = 'Direktori ElkArte';
$txt['sourcesdir'] = 'Direktori Sources';
$txt['cachedir'] = 'Direktori Cache';
$txt['admin_news'] = 'Aktifkan Berita';
$txt['admin_guest_post'] = 'Aktifkan pos tetamu';
$txt['admin_manage_members'] = 'Ahli';
$txt['admin_main'] = 'Utama';
$txt['admin_config'] = 'Tetapan';
$txt['admin_version_check'] = 'Pemeriksaan versi terperinci';
$txt['admin_elkfile'] = 'Fail ElkArte';
$txt['admin_elkpackage'] = 'Pakej ElkArte';
$txt['admin_logoff'] = 'Tamatkan sesi pengurus';
$txt['admin_maintenance'] = 'Penyelenggaraan';
$txt['admin_image_text'] = 'Paparkan butang sebagai imej, bukan teks';
$txt['admin_credits'] = 'Penghargaan';
$txt['admin_agreement'] = 'Paparkan dan minta surat perjanjian semasa mendaftar';
$txt['admin_checkbox_agreement'] = 'Paparkan peti semakan untuk perjanjian dalam borang pendaftaran, bukannya laman penuh';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Default';
$txt['admin_agreement_select_language'] = 'Bahasa untuk diedit';
$txt['admin_agreement_select_language_change'] = 'Edit';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Padam Ahli Pilihan';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Baiki semua ruangan dan topik';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Sila tempatkan satu item berita sepetak. Tag BBC, seperti <span>[b]</span>, <span>[i]</span> dan <span>[u]</span> diizinkan dalam berita, juga mimik anda. Kosongkan petak item berita untuk membuangnya.';
$txt['administrators'] = 'Pengurus Forum';
$txt['admin_reserved_desc'] = 'Nama terpelihara menghalang ahli dari mendaftar nama pengguna tertentu atau menggunakannya dalam nama paparannya. Pilih pilihan yang hendak digunakan di bawah sebelum simpan.';
$txt['admin_activation_email'] = 'Kirim emel pengaktifan ke ahli baru setelah pendaftaran';
$txt['admin_match_whole'] = 'Padankan semua nama. Jika tidak ditanda, cari di dalam nama.';
$txt['admin_match_case'] = 'Padankan huruf besar/kecil. Jika tidak ditanda, carian akan mengabaikan huruf besar/kecil.';
$txt['admin_check_user'] = 'Semak nama pengguna.';
$txt['admin_check_display'] = 'Semak nama paparan.';
$txt['admin_newsletter_send'] = 'Anda boleh emel seiapa saja dari sini. Alamat emel dari grup ahli yang dipilih akan tertera di bawah, tapi anda boleh padam atau tambah mana-mana alamat emel yang diperlukan. Pastikan setiap alamat dipisahkan dalam bentuk: \'alamat1; alamat2\'.';
$txt['admin_fader_delay'] = 'Waktu pudar antara item untuk pemudar berita';
$txt['zero_for_no_limit'] = '(0 tanpa had)';
$txt['zero_to_disable'] = '(0 untuk matikan)';

$txt['admin_backup_fail'] = 'Gagal membuat backup Settings.php - pastikan Settings_bak.php ada dan boleh ditulis.';
$txt['modSettings_info'] = 'Ubah atau tetapkan ciri am, karma, tandatangan, suka dan lain-lain pilihan yang mengawal cara forum ini beroperasi.';
$txt['database_server'] = 'Nama Server Database';
$txt['database_user'] = 'Nama Pengguna Database';
$txt['database_password'] = 'Kata Kunci Database';
$txt['database_name'] = 'Nama Database';
$txt['registration_agreement'] = 'Perjanjian Pendaftaran';
$txt['registration_agreement_desc'] = 'Perjanjian ini dipaparkan masa pengguna mendaftarkan akaun di forum ini dan mesti menerimanya sebelum pengguna boleh meneruskan pendaftaran.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Prefix Table Database';
$txt['errors_list'] = 'Senarai kesilapan forum';
$txt['errors_found'] = 'Kesilapan berikut menggagalkan forum anda';
$txt['errors_fix'] = 'Anda mahu mencuba membetulkan kesilapan ini?';
$txt['errors_do_recount'] = 'Semua kesilapan telah dibetulkan dan kawasan selamat sudah dibina. Sila klik butang di bawah untuk mengira semula beberapa statistik penting.';
$txt['errors_recount_now'] = 'Kira Semula Statistik';
$txt['errors_fixing'] = 'Membetulkan kesilapan forum';
$txt['errors_fixed'] = 'Semua kesilapan telah dibetulkan. Sila semak setiap kategori, ruangan, atau topik yang dicipta bagi menentukan apa yang perlu dilakukan dengan mereka.';
$txt['attachments_avatars'] = 'Lampiran dan Avatar';
$txt['attachments_desc'] = 'Di sini anda boleh menguruskan fail-fail lampiran pada sistem anda. Anda boleh memadam lampiran menurut saiz dan tarikh daripada sistem anda. Statistik lampiran juga dipaparkan di bawah.';
$txt['attachment_stats'] = 'Statistik fail lampiran';
$txt['attachment_integrity_check'] = 'Semakan integriti lampiran';
$txt['attachment_integrity_check_desc'] = 'Fungsi ini akan memeriksa integriti dan saiz lampiran dan nama fail yang tersenarai dalam pengkalan data dan, jika perlu, memperbaiki kesilapan yang ditemui.';
$txt['attachment_check_now'] = 'Jalankan semakan sekarang';
$txt['attachment_pruning'] = 'Penghapusan Lampiran';
$txt['attachment_pruning_message'] = 'Mesej tambahan untuk pos';
$txt['attachment_pruning_warning'] = 'Apakah anda pasti untuk memadamkan lampiran ini?\\nIni tidak boleh diundurkan!';

$txt['attachment_total'] = 'Jumlah lampiran';
$txt['attachmentdir_size'] = 'Jumlah saiz semua direktori lampiran';
$txt['attachmentdir_size_current'] = 'Jumlah saiz direktori lampiran semasa';
$txt['attachmentdir_files_current'] = 'Jumlah fail dalam direktori lampiran semasa';
$txt['attachment_space'] = 'Jumlah ruang tersedia';
$txt['attachment_files'] = 'Jumlah fail yang tinggal';

$txt['attachment_options'] = 'Pilihan Lampiran Fail';
$txt['attachment_log'] = 'Log Lampiran';
$txt['attachment_remove_old'] = 'Padam lampiran tua daripada %1$s hari';
$txt['attachment_remove_size'] = 'Padam lampiran besar daripada %1$s KiB';
$txt['attachment_name'] = 'Nama Lampiran';
$txt['attachment_file_size'] = 'Saiz Fail';
$txt['attachmentdir_size_not_set'] = 'Tiada saiz maksima direktori ditetapkan sekarang ini';
$txt['attachmentdir_files_not_set'] = 'Tiada had direktori fail ditetapkan buat masa ini';
$txt['attachment_delete_admin'] = '[lampiran dipadam oleh pengurus]';
$txt['live'] = 'Kemaskini Perisian Terkini';
$txt['remove_all'] = 'Padam semua';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(lebih terperinci)';

$txt['lfyi'] = 'Anda tidak dapat bersambung ke fail berita terbaru  ElkArte.';

$txt['manage_calendar'] = 'Kalendar';
$txt['manage_search'] = 'Carian';
$txt['viewmembers_online'] = 'Terakhir Bertalian';

$txt['smileys_manage'] = 'Mimik dan Ikon Mesej';
$txt['smileys_manage_info'] = 'Pasang set2 mimik baru, menambah mimik2 yang ada, atau urus ikon mesej anda.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Pasang, muatturun danmuatnaik pakej modifikasi; semak keizinan fail dan tetapan FTP.';
$txt['theme_admin'] = 'Pengurusan Tema';
$txt['theme_admin_info'] = 'Pasang tema baru, pilih tema yang tersedia untuk ahli anda serta set atau reset pilihan tema.';
$txt['registration_center'] = 'Pendaftaran';
$txt['member_center_info'] = 'Lihat senarai ahli, cari ahli serta urus kelulusan dan pengaktifan akaun.';
$txt['viewmembers_online'] = 'Terakhir Bertalian';

$txt['display_name'] = 'Nama paparan';
$txt['email_address'] = 'Alamat Emel';
$txt['ip_address'] = 'Alamat IP';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'tidak dikenali';
$txt['security_wrong'] = 'Percubaan log masuk pengurusan!
Perujuk: %1$s
Agen pengguna: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Kirim dalam format HTML.  (dengan ini anda boleh menggunakan HTML biasa dalam emel.)';
$txt['email_parsed_html'] = 'Tambah &lt;br /&gt;s dan &amp;nbsp;s ke mesej ini.';
$txt['email_variables'] = 'Dalam mesej ini anda boleh menggunakan beberapa &quot;pemboleh ubah&quot;. <a href="{help_emailmembers}" class="help">Klik di sini untuk maklumat</a>.';
$txt['email_force'] = 'Kirim ini ke ahli meskipun mereka memilih untuk tidak menerima pengumuman.';
$txt['email_as_pms'] = 'Kirimkan ke grup menggunakan mesej peribadi.';
$txt['email_continue'] = 'Teruskan';
$txt['email_done'] = 'selesai.';
$txt['email_members_succeeded'] = 'Anda berjaya menghantar warkah berita!';

$txt['ban_title'] = 'Senarai sekatan';
$txt['ban_ip'] = 'Sekatan IP: (misal 192.168.12.213 or 128.0.*.*) - satu entri satu baris';
$txt['ban_email'] = 'Sekatan emel: (cth. boyganas@ahrasis.com) - satu entri satu baris';
$txt['ban_username'] = 'Sekatan nama pengguna: (cth. boyganas) - satu entri satu baris';

$txt['ban_errors_detected'] = 'Kesalahan berikut berlaku semasa menyimpan atau mengedit sekatan atau pemicunya.';
$txt['ban_description'] = 'Di sini anda boleh menyekat pengguna bermasalah dengan IP, nama hos, nama pengguna, atau emel.';
$txt['ban_add_new'] = 'Tambah sekatan baru';
$txt['ban_banned_entity'] = 'Entiti disekat';
$txt['ban_on_ip'] = 'Sekatan pada IP (misal 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Sekatan pada nama hos (misal *.mil)';
$txt['ban_on_email'] = 'Sekatan pada alamat emel (cth. *@ahrasis.com)';
$txt['ban_on_username'] = 'Sekatan pada nama pengguna';
$txt['ban_notes'] = 'Catatan';
$txt['ban_restriction'] = 'Pembatasan';
$txt['ban_full_ban'] = 'Sekatan penuh';
$txt['ban_partial_ban'] = 'Sekatan sebahagian';
$txt['ban_cannot_post'] = 'Tidak boleh pos';
$txt['ban_cannot_register'] = 'Tidak boleh mendaftar';
$txt['ban_cannot_login'] = 'Tidak boleh masuk';
$txt['ban_add'] = 'Tambah';
$txt['ban_edit_list'] = 'Senarai sekatan';
$txt['ban_type'] = 'Jenis Sekatan';
$txt['ban_days'] = 'hari';
$txt['ban_will_expire_within'] = 'Sekatan akan berakhir setelah';
$txt['ban_added'] = 'Ditambahkan';
$txt['ban_expires'] = 'Berakhir';
$txt['ban_hits'] = 'Hit';
$txt['ban_actions'] = 'Tindakan';
$txt['ban_expiration'] = 'Luput';
$txt['ban_reason_desc'] = 'Alasan untuk sekatan, untuk dipaparkan ke ahli yang disekat.';
$txt['ban_notes_desc'] = 'Nota bagi membantu staf yang lain.';
$txt['ban_remove_selected'] = 'Padam pilihan';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Anda yakin mahu memadam sekatan pilihan?';
$txt['ban_modify'] = 'Ubah';
$txt['ban_name'] = 'Nama sekatan';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Edit sekatan';
$txt['ban_add_notes'] = '<strong>Catatan</strong>: setelah mencipta sekatan di atas, anda boleh menambah entri yang memicu sekatan, seperti alamat IP, nama hos dan alamat emel.';
$txt['ban_expired'] = 'Luput / dimatikan';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Tiada pembatasan dipilih.';

$txt['ban_triggers'] = 'Pemicu';
$txt['ban_add_trigger'] = 'Tambah pemicu sekatan';
$txt['ban_add_trigger_submit'] = 'Tambah';
$txt['ban_edit_trigger'] = 'Ubah';
$txt['ban_edit_trigger_title'] = 'Edit pemicu sekatan';
$txt['ban_edit_trigger_submit'] = 'Ubah';
$txt['ban_remove_selected_triggers'] = 'Padam pemicu sekatan pilihan';
$txt['ban_no_entries'] = 'Tiada kesan sekatan sekarang ini.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Anda yakin mahu memadam pemicu sekatan pilihan?';
$txt['ban_trigger_browse'] = 'Layari Pemicu Sekatan';
$txt['ban_trigger_browse_description'] = 'Layar ini memaparkan semua entiti yang disekat dengan grup alamat IP, nama, alamat emel dan nama pengguna.';

$txt['ban_log'] = 'Log Sekatan';
$txt['ban_log_description'] = 'Log sekatan memaparkan semua percubaan untuk memasuki forum oleh pengguna yang disekat (sekatan \'penuh\' dan \'tidak boleh mendaftar\' sahaja).';
$txt['ban_log_no_entries'] = 'Tiada entri log sekatan sekarang ini.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'Alamat emel';
$txt['ban_log_member'] = 'Ahli';
$txt['ban_log_date'] = 'Tarikh';
$txt['ban_log_remove_all'] = 'Padam semua';
$txt['ban_log_remove_all_confirm'] = 'Anda yakin mahu memadam semua entri log sekatan?';
$txt['ban_log_remove_selected'] = 'Padam pilihan';
$txt['ban_log_remove_selected_confirm'] = 'Anda yakin mahu memadam semua entiti log sekatan pilihan?';
$txt['ban_no_triggers'] = 'Tiada pemicu sekatan sekarang ini.';

$txt['settings_not_writable'] = 'Tetapan ini tidak boleh diubah kerana Settings.php dibaca sahaja.';

$txt['maintain_title'] = 'Penyelenggaraan Forum';
$txt['maintain_info'] = 'Asas backup forum, memeriksa kesalahan Database, membersihkan Cache, Kait Integrasi dan sebagainya.';
$txt['maintain_sub_database'] = 'Database';
$txt['maintain_sub_routine'] = 'Rutin';
$txt['maintain_sub_members'] = 'Ahli';
$txt['maintain_sub_topics'] = 'Topik';
$txt['maintain_sub_attachments'] = 'Lampiran';
$txt['maintain_done'] = 'Tugas penyelenggaraan &quot;%1$s&quot; telah berjaya dilaksanakan.';
$txt['maintain_fail'] = 'Tugas penyenggaraan \'%1$s\' gagal.';
$txt['maintain_no_errors'] = 'Tahniah, tiada kesilapan ditemui.  Terima kasih kerana menyemak.';

$txt['maintain_tasks'] = 'Jadual Tugas';
$txt['maintain_tasks_desc'] = 'Urus semua tugas berjadual.';

$txt['scheduled_log'] = 'Log Tugas';
$txt['scheduled_log_desc'] = 'Senarai log tugasan yang dijalankan.';
$txt['admin_log'] = 'Log Pengurusan';
$txt['admin_log_desc'] = 'Senarai tugas pengurusan yang sudah dilakukan oleh pengurus forum anda.';
$txt['moderation_log'] = 'Log Seliaan';
$txt['moderation_log_desc'] = 'Senarai aktiviti seliaan yang sudah dilakukan oleh penyelia forum anda.';
$txt['badbehavior_log'] = 'Log Kelakuan Buruk';
$txt['badbehavior_log_desc'] = 'Senarai permintaan yang disekat atau ditanda mencurigakan oleh kelakuan buruk. Sekiranya log masuk panjang hidup, semua permintaan HTTP akan disenaraikan.';
$txt['spider_log_desc'] = 'Semak entri berkaitan aktiviti lelabah mesin pencari di forum anda.';
$txt['pruning_log_desc'] = 'Gunakan alat ini untuk memadam entri lama pada pelbagai log.';

$txt['mailqueue_title'] = 'Surat';

$txt['db_error_send'] = 'Kirim emel kesalahan sambungan database';
$txt['db_persist'] = 'Gunakan sambungan persisten';
$txt['ssi_db_user'] = 'Nama pengguna database untuk kegunaan SSI';
$txt['ssi_db_passwd'] = 'Kata laluan database untuk untuk kegunaan SSI';

$txt['default_language'] = 'Bahasa rasmi forum';

$txt['maintenance_subject'] = 'Subjek untuk dipaparkan';
$txt['maintenance_message'] = 'Mesej untuk dipaparkan';

$txt['errlog_desc'] = 'Log kesilapan menjejaki setiap kesilapan dalam forum anda.  Untuk memadam sebarang kesilapan dari database, tandakan kotak berkenaan, dan klik butang %1$s di bawah laman ini.';
$txt['errlog_no_entries'] = 'Tiada entri log kesilapan buat masa ini.';

$txt['theme_settings'] = 'Tetapan Tema';
$txt['theme_edit_settings'] = 'Edit tetapan tema ini';
$txt['theme_current_settings'] = 'Tema Semasa';

$txt['dvc_your'] = 'Versi Anda';
$txt['dvc_current'] = 'Versi Semasa';
$txt['dvc_sources'] = 'Sumber';
$txt['dvc_admin'] = 'Pengurus';
$txt['dvc_controllers'] = 'Kontroller';
$txt['dvc_database'] = 'Database';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Template Rasmi';
$txt['dvc_templates'] = 'Template Semasa';
$txt['dvc_languages'] = 'Fail Bahasa';

$txt['smileys_default_set_for_theme'] = 'Pilih set mimik default untuk tema ini:';
$txt['smileys_no_default'] = 'Gunakan set mimik default';

$txt['censor_test'] = 'Uji Perkataan Ditapis';
$txt['censor_test_save'] = 'Uji';
$txt['censor_case'] = 'Abaikan huruf besar/kecil semasa menapis.';
$txt['censor_whole_words'] = 'Periksa keseluruhan perkataan sahaja.';
$txt['censor_allow'] = 'Benarkan ahli mematikan penapisan perkataan.';

$txt['admin_confirm_password'] = '(sahkan kata laluan)';
$txt['admin_incorrect_password'] = 'Kata Laluan Salah';

$txt['date_format'] = '(TTTT-BB-HH)';
$txt['undefined_gender'] = 'Tidak ditetapkan';
$txt['age'] = 'Usia pengguna';
$txt['activation_status'] = 'Status Pengaktifan';
$txt['activated'] = 'Diaktifkan';
$txt['not_activated'] = 'Tidak diaktifkan';
$txt['is_banned'] = 'Disekat';
$txt['primary'] = 'Utama';
$txt['additional'] = 'Tambahan';
$txt['wild_cards_allowed'] = 'karakter liar * dan ? dibolehkan';
$txt['member_part_of_these_membergroups'] = 'Ahli termasuk grup ini';
$txt['membergroups'] = 'Grup Ahli';
$txt['confirm_delete_members'] = 'Anda yakin mahu memadam ahli pilihan?';

$txt['support_credits_title'] = 'Sokongan dan Penghargaan';
$txt['support_credits_info'] = 'Pautan sokongan untuk semua isu lazim, info versi forum yang mungkin ditanya semasa anda meminta bantuan dan senarai penyumbang projek ElkArte.';
$txt['support_title'] = 'Maklumat Sokongan';
$txt['support_versions_current'] = 'Versi semasa';
$txt['support_versions_forum'] = 'Versi ini';
$txt['support_versions_db'] = 'Versi %1$s';
$txt['support_versions_server'] = 'Versi Server';
$txt['support_versions_gd'] = 'Versi GD';
$txt['support_versions_imagick'] = 'Versi Imagick';
$txt['support_versions'] = 'Maklumat Versi';
$txt['support_resources'] = 'Sumber Sokongan';
$txt['support_resources_p1'] = '<a href="%1$s" target="_blank" class="new_win">Wiki Dokumentasi</a> menyediakan dokumentasi utama ElkArte. Manual Atas Talian ElkArte ada banyak dokumen bagi membantu menjawab soalan sokongan dan menerangkan  <a href="%2$s" target="_blank" class="new_win">Ciri</a>, <a href="%3$s" target="_blank" class="new_win">Tetapan</a>, <a href="%4$s" target="_blank" class="new_win">Tema</a>, <a href="%5$s" target="_blank" class="new_win">Pakej</a>, dsb. Manual Atas Talian menyatakan setiap bahagian ElkArte secara terperinci dan boleh menjawab kebanyakan soalan dengan segera.';
$txt['support_resources_p2'] = 'Jika anda tidak menemui jawapan bagi pertanyaan anda dalam Wiki Dokumentasi, anda mungkin mahu mencari di <a href="%1$s" target="_blank" class="new_win">Komuniti Sokongan</a> kami atau meminta bantuan dalam ruangan sokongan kami. Komuniti Sokongan ElkArte boleh digunakan sebagai <a href="%2$s" target="_blank" class="new_win"> sokongan</a>, <a href="%3$s" target="_blank" class="new_win">ciptaan</a>, dan perkara lain seperti membincangkan ElkArte, mencari hos, dan membincangkan isu pengurusan dengan pengurus forum lain. ';

$txt['latest_updates'] = 'Kemaskini terbaru yang penting';
$txt['new_in_1_0_2'] = 'Perubahan terpenting dalam ElkArte 1.0.2 ialah pengurusan kebenaran avatar. Semua tetapan avatar pada masa ini adalah berasaskan keizinan, memerlukannya dihidupkan/dimatikan bagi setiap grup. Dalam 1.0.2 avatar mudah dihidupkan/dimatikan oleh ahli grup, membolehkan grup yang dizinkan menambah avatar (dengan semua cara yang ada).<br />
Satu keizinan sahaja ada iaitu keizinan am bagi membolehkan ahli menukar avatar mereka atau tidak. Sebagai tambahan, hanya ada satu tetapan bagi lebar dan tinggi maksima avatar, nilainya terpakai kepada semua avatar.<br /><br />
Disebabkan oleh bentuk perubahan, tidaklah mustahil untuk menukar tetapan sedia ada kepada format baru, untuk tujuan tersebut anda digalakkan untuk melayari laman <a href="{admin_url};area=manageattachments;sa=avatars">Tetapan Avatar</a> dan tetapkan pilihan kesukaan anda.';

$txt['edit_permissions_info'] = 'Gunakan tetapan keizinan untuk uruskan ciri ruangan global atau spesifik dan apakah tindakan yang tetamu, ahli dan penyelia boleh lakukan.';
$txt['membergroups_members'] = 'Ahli Biasa';
$txt['membergroups_guests'] = 'Tetamu';
$txt['membergroups_add_group'] = 'Tambah grup';
$txt['membergroups_permissions'] = 'Keizinan';

$txt['permitgroups_restrict'] = 'Terbatas';
$txt['permitgroups_standard'] = 'Lazim';
$txt['permitgroups_moderator'] = 'Penyelia';
$txt['permitgroups_maintenance'] = 'Penyelenggaraan';

$txt['confirm_delete_attachments'] = 'Apakah anda yakin mahu memadam lampiran pilihan?';
$txt['attachment_manager_browse_files'] = 'Layari fail';
$txt['attachment_manager_repair'] = 'Selenggara';
$txt['attachment_manager_avatars'] = 'Avatar';
$txt['attachment_manager_attachments'] = 'Lampiran';
$txt['attachment_manager_thumbs'] = 'Imej kenit';
$txt['attachment_manager_last_active'] = 'Terakhir Aktif';
$txt['attachment_manager_member'] = 'Ahli';
$txt['attachment_manager_avatars_older'] = 'Padam avatar dari ahli yang tidak aktif lebih dari %1$s hari';
$txt['attachment_manager_total_avatars'] = 'Jumlah Avatar';

$txt['attachment_manager_avatars_no_entries'] = 'Tiada avatar sekarang ini.';
$txt['attachment_manager_attachments_no_entries'] = 'Tiada lampiran sekarang ini.';
$txt['attachment_manager_thumbs_no_entries'] = 'Tiada imej kenit sekarang ini.';

$txt['attachment_manager_settings'] = 'Tetapan Lampiran';
$txt['attachment_manager_avatar_settings'] = 'Tetapan Avatar';
$txt['attachment_manager_browse'] = 'Layari fail';
$txt['attachment_manager_maintenance'] = 'Penyelenggaraan fail';
$txt['attachmentEnable'] = 'Pilihan lampiran';
$txt['attachmentEnable_deactivate'] = 'Matikan lampiran';
$txt['attachmentEnable_enable_all'] = 'Aktifkan semua lampiran';
$txt['attachmentEnable_disable_new'] = 'Matikan lampiran baru';
$txt['attachmentCheckExtensions'] = 'Periksa sambungan lampiran';
$txt['attachmentExtensions'] = 'Benarkan sambungan lampiran';
$txt['attachmentRecodeLineEndings'] = 'Kodkan semula akhiran dalam lampiran teks';
$txt['attachmentShowImages'] = 'Paparkan lampiran gambar sebagai gambar di bawah pos';
$txt['attachmentUploadDir'] = 'Direktori lampiran';
$txt['attachmentUploadDir_multiple_configure'] = 'Uruskan direktori lampiran';
$txt['attachmentDirSizeLimit'] = 'Maksima ruang folder lampiran';
$txt['attachmentPostLimit'] = 'Maksima saiz lampiran satu pos';
$txt['attachmentSizeLimit'] = 'Maksima saiz satu lampiran';
$txt['attachmentNumPerPostLimit'] = 'Maksima jumlah lampiran satu pos';
$txt['attachment_img_enc_warning'] = 'Modul GD dan ImageMagick kedua-duanya tidak dipasang. Pengenkodan semula imej tidak boleh dilakukan.';
$txt['attachment_postsize_warning'] = 'Tetapan \'post_max_size\' dalam php.ini tidak menyokong ini.';
$txt['attachment_filesize_warning'] = 'Tetapan \'upload_max_filesize\' dalam php.ini tidak menyokong.';
$txt['attachment_image_reencode'] = 'Mengenkod semula lampiran imej yang berpotensi bahaya';
$txt['attachment_image_reencode_note'] = '(perlukan modul GD atau ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Pemeriksaan keselamatan tinggi akan menyebabkan penolakan majoriti lampiran.';
$txt['attachment_image_paranoid'] = 'Laksanakan pemeriksaan keselamatan tinggi pada lampiran imej';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'Saizkan semula imej di bawah paparan pos';
$txt['attachment_thumb_png'] = 'Simpan imej kenit sebagai PNG.';
$txt['attachment_thumb_memory'] = 'Memori imej kenit adaptif';
$txt['attachment_thumb_memory_note2'] = 'Jika sistem tidak mendapat memori, tiada imej kenit akan dicipta.';
$txt['attachment_thumb_memory_note1'] = 'Biarkan tidak ditanda untuk cuba mencipta imej kenit';
$txt['attachmentThumbWidth'] = 'Maksima lebar imej kenit';
$txt['attachmentThumbHeight'] = 'Maksima tinggi imej kenit';
$txt['attachment_thumbnail_settings'] = 'Tetapan Imej Kenit';
$txt['attachment_security_settings'] = 'Tetapan2 sekuriti lampiran';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Tidak Wujud';
$txt['attach_dir_not_writable'] = 'Tidak Boleh Ditulis';
$txt['attach_dir_files_missing'] = '(<a href="{repair_url}">Baiki</a>) Fail Yang Hilang';
$txt['attach_dir_unused'] = 'Tidak Digunakan';
$txt['attach_dir_empty'] = 'Kosong';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Direktori asas';

$txt['attach_dir_desc'] = 'Cipta direktori baru atau ubah direktori semasa di bawah. Direktori2 boleh dinamakan semua selagi mana ia tidak mempunyai direktori anak. Jika direktori baru dicipta dalam struktur direktori forum, anda hanya perlu memasukkan nama direktori. Untuk membuang direktori, kosongkan petak input laluan. Direktori2 tidak boleh dipadamkan sekiranya menreka mengandungi fail2 atau direktori2 anak (dipaparkan dalam kurungan bersebelahan dengan kiraan fail).';
$txt['attach_dir_base_desc'] = 'Anda boleh menggunakan ruangan di bawah bagi mengubah direktori asas semasa atau mencipta yang baru. Direktori2 asas juga ditambahkan kepada senarai Direktori Lampiran. Anda juga boleh menetapkan direktori sedia ada menjadi satu direktori asas.';
$txt['attach_dir_save_problem'] = 'Oops, ada sedikit masalah.';
$txt['attachments_no_create'] = 'Tidak dapat mencipta satu direktori lampiran baru. Sila lakukannya menggunakan klien FTP atau pengurus fail laman anda.';
$txt['attachments_no_write'] = 'Direktori ini telah dicipta tetapi tidak dapat ditulis. Sila cuba lakukannya dengan klien FTP atau pengurs fail laman anda.';
$txt['attach_dir_reserved'] = 'Tidak dapat menambah. Direktori ini adalah direktori sistem dan tidak boleh digunakan bagi lampiran2.';
$txt['attach_dir_duplicate_msg'] = 'Tidak dapat menambah. Direktotori ini sudah ada.';
$txt['attach_dir_exists_msg'] = 'Tidak dapat mengalihkan. Satu direktori sudah ada pada laluan tersebut.';
$txt['attach_dir_base_dupe_msg'] = 'Tidak boleh menambah. Direktori asas ini telah tersedia dicipta.';
$txt['attach_dir_base_no_create'] = 'Tidak padat mencipta. Sila sahkan laluan input atau cipta direktori ini dengan klien FTP atau pengurus fail laman dan cuba semula.';
$txt['attach_dir_no_rename'] = 'Tidak dapat mengalihkan atau menamakan. Sila sahkan laluan adalah betul atau direktori ini tidak mengandungi sub-direktori yang lain.';
$txt['attach_dir_no_delete'] = 'Ia tidak kosong dan tidak boleh dipadamkan. Sila guna klien FTP atau pengurus fail laman.';
$txt['attach_dir_no_remove'] = 'Masih mengandungi fail atau ia adalah direktori asas dan tidak boleh dipadamkan.';
$txt['attach_dir_is_current'] = 'Tidak dapat dibuang sementara ia dipilih sebagai direktori semasa.';
$txt['attach_dir_is_current_bd'] = 'Tidak dapat dibuang sementara ia dipilih sebagai direktori asas semasa.';
$txt['attach_last_dir'] = 'Direktori lampiran aktif yang terakhir';
$txt['attach_current_dir'] = 'Direktori lampiran semasa';
$txt['attach_current'] = 'Semasa';
$txt['attach_path_manage'] = 'Uruskan  laluan lampiran';
$txt['attach_directories'] = 'Direktori2 Lampiran';
$txt['attach_paths'] = 'Laluan direktori lampiran';
$txt['attach_path'] = 'Laluan';
$txt['attach_current_size'] = 'Saiz (KiB)';
$txt['attach_num_files'] = 'Fail';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Tambah Laluan';
$txt['attach_path_current_bad'] = 'Laluan lampiran semasa tidak sah.';
$txt['attachmentDirFileLimit'] = 'Maksima bilangan fail satu direktori';

$txt['attach_base_paths'] = 'Laluan2 direktori asas';
$txt['attach_num_dirs'] = 'Direktori2';
$txt['max_image_width'] = 'Maksima lebar paparan imej yang dipos atau dilampirkan';
$txt['max_image_height'] = 'Maksima tinggi paparan imej yang dipos atau dilampirkan';

$txt['automanage_attachments'] = 'Pilih cara untuk menguruskan direktori2 lampiran.';
$txt['attachments_normal'] = '(Manual) perangai asas ElkArte';
$txt['attachments_auto_years'] = '(Auto) Dibahagikan dengan tahun2';
$txt['attachments_auto_months'] = '(Auto) Dibahagikan dengan tahun2 dan bulan2';
$txt['attachments_auto_days'] = '(Auto) Dibahagikan dengan tahun2, bulan2 dan hari2';
$txt['attachments_auto_16'] = '(Auto) 16 direktori2 secara rawak';
$txt['attachments_auto_16x16'] = '(Auto) 16 direktori2 secara rawak dengan 16 direktori2 anak secara rawak';
$txt['attachments_auto_space'] = '(Auto) Apabila mana2 ruangan direktori dicapai';

$txt['use_subdirectories_for_attachments'] = 'Cipta direktori2 baru dalam direktori asas';
$txt['use_subdirectories_for_attachments_note'] = 'Jika tidak semua direktori baru akan dicipta dalam direktori utama forum.';
$txt['basedirectory_for_attachments'] = 'Tetapkan direktori asas bagi lampiran2';
$txt['basedirectory_for_attachments_current'] = 'Direktori asas semasa';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Sila catatkan bahawa ada kesalahan direktori. <br />(<a href="{attach_repair_url}">Cuba untuk membaiki</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">Terdapat kesalahan pada direktori ini. <br />(<a href="{attach_repair_url}">Cuba untuk membaiki</a>)</div>';

$txt['attachment_transfer'] = 'Pemindahan Lampiran2';
$txt['attachment_transfer_desc'] = 'Pindahkan fail2 antara direktori2.';
$txt['attachment_transfer_select'] = 'Pilih direktori';
$txt['attachment_transfer_now'] = 'Pemindahan';
$txt['attachment_transfer_from'] = 'Pindahkan fail2 daripada';
$txt['attachment_transfer_auto'] = 'Alihkan mereka secara automatik dengan kiraan ruang atau fail';
$txt['attachment_transfer_auto_select'] = 'Pilih direktori asas';
$txt['attachment_transfer_to'] = 'Atau alihkan mereka ke satu direktori khusus';
$txt['attachment_transfer_empty'] = 'Alihkan semua fail daripada direktori sumber.';
$txt['attachment_transfer_no_base'] = 'Tiada direktori asas wujud.';
$txt['attachment_transfer_forum_root'] = 'Direktori akar forum.';
$txt['attachment_transfer_no_room'] = 'Had kiraan fail atau saiz direktori dicapai.';
$txt['attachment_transfer_no_find'] = 'Tiada fail ditemui untuk dipindahkan.';
$txt['attachments_transfered'] = '%1$d fail dipindahkan ke %2$s';
$txt['attachments_not_transfered'] = '%1$d fail tidak dipindahkan.';
$txt['attachment_transfer_no_dir'] = 'Sama ada direktori sumber atau salah satu pilihan sasaran tidak dipilih.';
$txt['attachment_transfer_same_dir'] = 'Anda tidak boleh memilih direktori yang sama sebagai sumber dan sasaran serentak.';
$txt['attachment_transfer_progress'] = 'Sabar. Pemindahan sedang berjalan.';

$txt['avatar_settings'] = 'Tetapan2 umum avatar';
$txt['avatar_default'] = 'Hidupkan satu avatar default bagi semua pengguna yang tiada avatar';
$txt['avatar_directory'] = 'Direktori avatar';
$txt['avatar_url'] = 'URL avatar';
$txt['avatar_max_width'] = 'Lebar maksima avatar dalam pixel (px)';
$txt['avatar_max_height'] = 'Tinggi maksima avatar dalam pixel (px)';
$txt['avatar_action_too_large'] = 'Jika avatar terlalu besar...';
$txt['option_refuse'] = 'Tolak';
$txt['option_resize'] = 'Biarkan CSS menukar saiznya';
$txt['option_download_and_resize'] = 'Muatturun dan tukar saiznya (memerlukan modul GD atau ImageMagick)';
$txt['gravatar'] = 'Gravatar2';
$txt['avatar_gravatar_enabled'] = 'Benarkan gravatar digunakan';
$txt['gravatar_rating'] = 'Kedudukan Gravatar';
$txt['avatar_download_png'] = 'Gunakan PNG untuk mengukur semula avatar';
$txt['avatar_img_enc_warning'] = 'Kedua2 modul GD dan ImageMagick tidak dipasang. Beberapa ciri avatar dimatikan.';
$txt['avatar_external'] = 'Avatar luar';
$txt['avatar_external_enabled'] = 'Benarkan avatar lain (luaran/URL) digunakan';
$txt['avatar_upload'] = 'Avatar boleh dimuatnaik';
$txt['avatar_resize_options'] = 'Pilihan simpanan server';
$txt['avatar_upload_enabled'] = 'Benarkan avatar dimuatnaik';
$txt['avatar_server_stored'] = 'Avatar tersimpan di server';
$txt['avatar_stored_enabled'] = 'Benarkan avatar simpanan server dipilih';
$txt['profile_set_avatar'] = 'Grup ahli yang dibenarkan memilih avatar';
$txt['avatar_select_permission'] = 'Pilih keizinan untuk setiap grup';
$txt['avatar_download_external'] = 'Muatturun avatar pada URL yang diberikan';
$txt['custom_avatar_enabled'] = 'Muatnaik avatar ke...';
$txt['option_attachment_dir'] = 'Direktori lampiran';
$txt['option_specified_dir'] = 'Direktori tertentu...';
$txt['custom_avatar_dir'] = 'Direktori muatnaik';
$txt['custom_avatar_dir_desc'] = 'Ini sepatutnya adalah direktori yang sah dan boleh tulis, berlainan dengan direktori simpanan-server.';
$txt['custom_avatar_url'] = 'URL Muatnaik';
$txt['custom_avatar_check_empty'] = 'Direktori avatar ciptaan yang anda tetapkan mungkin kosong atau tidak sah. Pastikan tetapan ini betul.';
$txt['avatar_reencode'] = 'Mengenkod semula avatar yang berpotensi bahaya';
$txt['avatar_reencode_note'] = '(perlukan modul GD)';
$txt['avatar_paranoid_warning'] = 'Pemeriksaan keselamatan tinggi akan menyebabkan penolakan kebanyakan besar avatar.';
$txt['avatar_paranoid'] = 'Laksanakan pemeriksaan keselamatan tinggi pada avatar yang dimuatnaik';

$txt['repair_attachments'] = 'Selenggara Lampiran';
$txt['repair_attachments_complete'] = 'Penyelenggaraan Selesai';
$txt['repair_attachments_complete_desc'] = 'Semua kesalahan pilihan sudah dibetulkan';
$txt['repair_attachments_no_errors'] = 'Tiada kesalahan ditemui';
$txt['repair_attachments_error_desc'] = 'Kesalahan berikut ditemui selama penyelenggaraan. Tandakan kotak di sebelah kesalahan yang hendak dibetulkan dan tekan teruskan.';
$txt['repair_attachments_continue'] = 'Teruskan';
$txt['repair_attachments_cancel'] = 'Batalkan';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d imej kenit kehilangan lampiran induknya';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d induk ditandakan ada imej kenit tetapi sebenarnya tidak';
$txt['attach_repair_file_missing_on_disk'] = '%1$d lampiran/avatar memiliki entri tapi tiada lagi pada disk';
$txt['attach_repair_file_wrong_size'] = '%1$d lampiran/avatar dilaporkan sebagai saiz fail yang salah';
$txt['attach_repair_file_size_of_zero'] = '%1$d lampiran/avatar memiliki saiz sifar pada disk. (Ini akan dipadamkan)';
$txt['attach_repair_attachment_no_msg'] = '%1$d lampiran tidak lagi memiliki mesej yang berkaitan dengannya';
$txt['attach_repair_avatar_no_member'] = '%1$d avatar tidak lagi memiliki ahli yang berkaitan dengannya';
$txt['attach_repair_wrong_folder'] = '%1$d lampiran berada di direktori yang salah';
$txt['attach_repair_missing_extension'] = '%1$d lampiran tidak mempunyai akhiran yang sah dan mungkin berada dalam direktori yang salah';
$txt['attach_repair_files_without_attachment'] = '%1$d fail tidak mempunyai entri berkenaan dalam database. (Kesemuanya akan dipadamkan).';

$txt['news_title'] = 'Berita dan Warkah Berita';
$txt['news_settings_desc'] = 'Di sini anda boleh mengubah tetapan dan keizinan berkaitan dengan berita dan warkah berita.';
$txt['news_mailing_desc'] = 'Di sini anda boleh mengirim mesej ke semua ahli yang berdaftar dan memasukan alamat emel mereka. Anda boleh mengedit senarai sebaran, atau mengirim mesej kepada semua. Berguna untuk kemaskini/berita penting.';
$txt['news_error_no_news'] = 'Tiada apa untuk dilihat';
$txt['groups_edit_news'] = 'Grup yang diizinkan untuk mengedit item berita';
$txt['groups_send_mail'] = 'Grup yang diizinkan untuk mengirimkan warkah berita forum';
$txt['xmlnews_enable'] = 'Aktifkan berita XML/RSS';
$txt['xmlnews_maxlen'] = 'Maksima panjang mesej';
$txt['xmlnews_limit'] = 'Had XML/RSS';
$txt['xmlnews_limit_note'] = 'Bilangan item dalam suapan berita';
$txt['xmlnews_maxlen_note'] = '(0 untuk matikan, idea kurang baik.)';
$txt['editnews_clickadd'] = 'Tambah item lain';
$txt['editnews_remove_selected'] = 'Padam pilihan';
$txt['editnews_remove_confirm'] = 'Apakah anda yakin mahu memadam item berita pilihan?';
$txt['censor_clickadd'] = 'Tambah perkataan lain';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Log';
$txt['generate_reports'] = 'Laporan';

$txt['update_available'] = 'Kemaskini Sudah Ada';
$txt['update_message'] = 'Anda menggunakan versi lapuk ElkArte, yang terdapat banyak pepijat dan sekarang ini telah diatasi.
⇥Anda disarankan agar <a href="#" id="update-link">mengemaskini forum anda</a> ke versi terkini secepat mungkin. Ia cuma mengambil masa beberapa minit sahaja!';

$txt['manageposts'] = 'Pos dan Topik';
$txt['manageposts_title'] = 'Uruskan Pos dan Topik';
$txt['manageposts_description'] = 'Di sini anda boleh uruskan semua tetapan berkaitan pos dan topik.';

$txt['manageposts_seconds'] = 'saat';
$txt['manageposts_minutes'] = 'minit';
$txt['manageposts_characters'] = 'karakter';
$txt['manageposts_days'] = 'hari';
$txt['manageposts_posts'] = 'pos';
$txt['manageposts_topics'] = 'topik';

$txt['pollMode'] = 'Hidupkan undian2';

$txt['manageposts_settings'] = 'Tetapan Pos';
$txt['manageposts_settings_description'] = 'Di sini anda boleh menetapkan apapun berkaitan dengan pos dan pengeposan.';

$txt['manageposts_bbc_settings'] = 'Kod Ruangan Buletin';
$txt['manageposts_bbc_settings_description'] = 'Kod ruangan buletin boleh dipakai untuk menambah perisa kepada mesej forum. Contoh, untuk mencerahkan perkataan \'rumah\' anda boleh menaip [b]rumah[/b]. Semua tag kod ruangan buletin dikelilingi kotak braket (\'[\' dan \']\').';
$txt['manageposts_bbc_settings_title'] = 'Tetapan Kod Ruangan Buletin';

$txt['manageposts_topic_settings'] = 'Tetapan Topik';
$txt['manageposts_topic_settings_description'] = 'Di sini anda boleh menguruskan semua tetapan topik.';

$txt['managedrafts_settings'] = 'Tetapan2 Deraf';
$txt['managedrafts_settings_description'] = 'Di sini anda boleh menguruskan tetapan2 berkenaan deraf.';
$txt['manage_drafts'] = 'Deraf';

$txt['mail_center'] = 'Pusat Persuratan';
$txt['mm_emailerror'] = 'Emel2 Yang Gagal';
$txt['mm_emailfilters'] = 'Tapisan2';
$txt['mm_emailparsers'] = 'Perungkai2';
$txt['mm_emailtemplates'] = 'Templet';
$txt['mm_emailsettings'] = 'Tetapan';

$txt['removeNestedQuotes'] = 'Buang ungkapan bersarang semasa mengungkap';
$txt['enableSpellChecking'] = 'Aktifkan semakan ejaan';
$txt['enableSpellChecking_warning'] = 'ini tidak berfungsi di semua server.';
$txt['enableSpellChecking_error'] = 'ini tidak berfugsi pada server anda.';
$txt['enableVideoEmbeding'] = 'Hidupkan penyerapan automatik pautan2 video.';
$txt['enableCodePrettify'] = 'Hidupkan pencantikkan tag2 kod.';
$txt['max_messageLength'] = 'Maksima saiz pos diizinkan';
$txt['max_messageLength_zero'] = '0 untuk tanpa had.';
$txt['convert_to_mediumtext'] = 'Setup database anda tidak menerima mesej lebih daripada 65535 aksara. Sila gunakan laman <a href="%1$s">Senggaraan Database</a> bagi menukarkan database dan kemudian kembali ke sini untuk meningkatkan saiz maksima pos yang dibenarkan.';
$txt['topicSummaryPosts'] = 'Pos untuk dipaparkan pada ringkasan topik';
$txt['spamWaitTime'] = 'Masa yang diperlukan untuk mengepos dari IP yang sama';
$txt['edit_wait_time'] = 'Masa budibicara bagi edit';
$txt['edit_disable_time'] = 'Masa maksima setelah pos untuk edit';
$txt['edit_disable_time_zero'] = '0 untuk mematikan';
$txt['preview_characters'] = 'Panjang maksima paparan awal pos yang pertama/terakhir';
$txt['preview_characters_units'] = 'karakter';
$txt['preview_characters_zero'] = '0 untuk paparkan semua mesej';
$txt['message_index_preview'] = 'Tunjukkan paparan awal pos pada indeks mesej';
$txt['message_index_preview_off'] = 'Jangan tunjukkan paparan awal';
$txt['message_index_preview_first'] = 'Paparkan teks pos pertama';
$txt['message_index_preview_last'] = 'Paparkan teks pos terakhir';

$txt['enableBBC'] = 'Hidupkan kod ruangan bulletin (BBC)';
$txt['enablePostHTML'] = 'Aktifkan HTML <em>asas</em> dalam pos';
$txt['autoLinkUrls'] = 'Pautan automatik URL yang dipos';
$txt['disabledBBC'] = 'BBC tag yang dibenarkan';
$txt['bbcTagsToUse'] = 'BBC tag yang dibenarkan';
$txt['bbcTagsToUse_select'] = 'Pilih tag yang diizinkan untuk diguna';
$txt['bbcTagsToUse_select_all'] = 'Pilih semua tag';

$txt['enableParticipation'] = 'Aktifkan ikon penyertaan';
$txt['enableFollowup'] = 'Hidupkan susulan';
$txt['enable_unwatch'] = 'Hidupkan tidak memantau topik';
$txt['oldTopicDays'] = 'Masa sebelum topik diberi amaran sebagai tua semasa menjawab';
$txt['oldTopicDays_zero'] = '0 untuk mematikan';
$txt['defaultMaxTopics'] = 'Jumlah topik satu laman dalam indeks mesej';
$txt['defaultMaxMessages'] = 'Jumlah pos satu laman dalam laman topik';
$txt['disable_print_topic'] = 'Matikan ciri mencetak topik';
$txt['hotTopicPosts'] = 'Jumlah pos untuk topik hangat';
$txt['hotTopicVeryPosts'] = 'Jumlah pos untuk topik terhangat';
$txt['useLikesNotViews'] = 'Gunakan bilangan suka menggantikan pos untuk menentukan topik2 hangat';
$txt['enableAllMessages'] = 'Maksima saiz topik untuk paparkan &quot;semua&quot; pos';
$txt['enableAllMessages_zero'] = '0 untk tidak paparkan &quot;semua&quot;';
$txt['disableCustomPerPage'] = 'Matikan kiraan topik/mesej tetapan ahli pada satu laman';
$txt['enablePreviousNext'] = 'Aktifkan link topik kembali/seterusnya';

$txt['not_done_title'] = 'Belum siap lagi';
$txt['not_done_reason'] = 'Bagi mengelakkan bebanan server anda, proses dihentikan sementara.  Ia diteruskan secara automatik dalam beberapa saat.  Jika tidak, klik teruskan di bawah ini.';
$txt['not_done_continue'] = 'Teruskan';

$txt['general_settings'] = 'Umum';
$txt['database_paths_settings'] = 'Database dan Laluan';
$txt['cookies_sessions_settings'] = 'Cookie dan Sesi';
$txt['caching_settings'] = 'Caching';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'Info PHP';
$txt['phpinfo_localsettings'] = 'Tetapan Dalaman';
$txt['phpinfo_defaultsettings'] = 'Tetapan Asas';
$txt['phpinfo_itemsettings'] = 'Tetapan';

$txt['language_configuration'] = 'Bahasa';
$txt['language_description'] = 'Bahagian ini mengizinkan anda mengedit bahasa yang dipasang di forum anda atau muatturun yang terkini dari laman ElkArte. Anda juga boleh mengedit tetapan berkaitan bahasa di sini.';
$txt['language_edit'] = 'Edit Bahasa';
$txt['language_add'] = 'Tambah Bahasa';
$txt['language_settings'] = 'Tetapan';

$txt['advanced'] = 'Terperinci';
$txt['simple'] = 'Ringkas';

$txt['admin_news_select_recipients'] = 'Pilih siapa yang patut menerima salinan warkah berita';
$txt['admin_news_select_group'] = 'Grup Ahli';
$txt['admin_news_select_group_desc'] = 'Pilih grup ahli untuk menerima warkah berita ini.';
$txt['admin_news_select_members'] = 'Ahli';
$txt['admin_news_select_members_desc'] = 'Ahli tambahan untuk menerima warkah berita.';
$txt['admin_news_select_excluded_members'] = 'Ahli Yang Dikecualikan';
$txt['admin_news_select_excluded_members_desc'] = 'Ahli yang tidak patut menerima warkah berita.';
$txt['admin_news_select_excluded_groups'] = 'Grup Dikecualikan';
$txt['admin_news_select_excluded_groups_desc'] = 'Pilih grup yang benar-benar tidak akan menerima warkah berita.';
$txt['admin_news_select_email'] = 'Alamat Emel';
$txt['admin_news_select_email_desc'] = 'Senarai alamat emel yang dipisahkan semi-kolon untuk dikirim warkah berita ini. (cth. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Atasi tetapan makluman';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Anda tidak boleh mengirimkan mesej peribadi ke alamat emel. Jika anda melanjutkan semua alamat emel yang dimasukan akan diabaikan.\\n\\nAnda yakin ingin melakukan ini?';

$txt['mailqueue_browse'] = 'Layari Giliran';
$txt['mailqueue_settings'] = 'Tetapan';

$txt['admin_search'] = 'Carian Pantas';
$txt['admin_search_type_internal'] = 'Tugas/Tetapan';
$txt['admin_search_type_member'] = 'Ahli';
$txt['admin_search_type_online'] = 'Manual Atas Talian';
$txt['admin_search_go'] = 'Pergi';
$txt['admin_search_results'] = 'Hasil Carian';
$txt['admin_search_results_desc'] = 'Hasil carian untuk: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Cari lagi';
$txt['admin_search_results_none'] = 'Tiada hasil ditemui.';

$txt['admin_search_section_sections'] = 'Bahagian';
$txt['admin_search_section_settings'] = 'Tetapan';

$txt['core_settings_title'] = 'Ciri Utama';
$txt['core_settings_desc'] = 'Laman ini membenarkan anda untuk menghidupkan atau mematikan ciri2 pilihan forum anda.';
$txt['mods_cat_features'] = 'Umum';
$txt['mods_cat_security_general'] = 'Umum';
$txt['antispam_title'] = 'Anti-Spam';
$txt['badbehavior_title'] = 'Kelakuan Buruk';
$txt['mods_cat_modifications_misc'] = 'Lain-Lain';
$txt['mods_cat_layout'] = 'Rupa';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Seliaan';
$txt['signature_settings_short'] = 'Tanda tangan';
$txt['custom_profile_shorttitle'] = 'Petak Profil';
$txt['pruning_title'] = 'Pemadaman Log';

$txt['core_settings_activation_message'] = 'Ciri {core_feature} telah dihidupkan, klik pada tajuk untuk mengkonfigurasikannya';
$txt['core_settings_deactivation_message'] = 'Ciri {core_feature} telah dimatikan';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Ubah Ruangan';
$txt['mboards_new_cat'] = 'Buat kategori baru';
$txt['manage_holidays'] = 'Uruskan Cuti';
$txt['calendar_settings'] = 'Tetapan Kalendar';
$txt['search_weights'] = 'Keutamaan';
$txt['search_method'] = 'Cara carian';
$txt['search_sphinx'] = 'Konfigurasikan Sphinx';

$txt['smiley_sets'] = 'Set2 Mimik';
$txt['smileys_add'] = 'Tambah Mimik';
$txt['smileys_edit'] = 'Edit Mimik2';
$txt['smileys_set_order'] = 'Tetapkan Urutan Mimik';
$txt['icons_edit_message_icons'] = 'Edit ikon mesej';

$txt['membergroups_new_group'] = 'Tambah Grup Ahli';
$txt['membergroups_edit_groups'] = 'Edit Grup Ahli';
$txt['permissions_groups'] = 'Keizinan Umum';
$txt['permissions_boards'] = 'Keizinan Ruangan';
$txt['permissions_profiles'] = 'Edit Profil';
$txt['permissions_post_moderation'] = 'Seliaan Pos';

$txt['browse_packages'] = 'Layari Pakej';
$txt['download_packages'] = 'Muatturun Pakej';
$txt['upload_packages'] = 'Pakej Yang Dimuatnaik';
$txt['installed_packages'] = 'Pakej Yang Dipasang';
$txt['package_file_perms'] = 'Keizinan Fail';
$txt['package_settings'] = 'Tetapan';
$txt['package_servers'] = 'Server Pakej';
$txt['themeadmin_admin_title'] = 'Urus dan Pasang';
$txt['themeadmin_list_title'] = 'Tetapan Tema';
$txt['themeadmin_reset_title'] = 'Pilihan Ahli';
$txt['themeadmin_edit_title'] = 'Edit Tema';
$txt['admin_browse_register_new'] = 'Daftarkan ahli baru';

$txt['search_engines'] = 'Mesin Pencari';
$txt['spider_logs'] = 'Log Lelabah';
$txt['spider_stats'] = 'Statistik';

$txt['paid_subscriptions'] = 'Langganan Berbayar';
$txt['paid_subs_view'] = 'Lihat Langganan';

$txt['maintain_sub_hooks_list'] = 'Kait Integrasi';
$txt['hooks_field_hook_name'] = 'Nama Kait';
$txt['hooks_field_function_name'] = 'Nama Fungsi';
$txt['hooks_field_function'] = 'Fungsi';
$txt['hooks_field_included_file'] = 'Fail yang disertakan';
$txt['hooks_field_file_name'] = 'Nama Fail';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Ada';
$txt['hooks_disabled'] = 'Dimatikan'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Tidak ditemui';
$txt['hooks_no_hooks'] = 'Tiada kait dalam sistem pada masa ini.';
$txt['hooks_disable_legend'] = 'Carta';
$txt['hooks_disable_legend_exists'] = 'kait wujud dan aktif';
$txt['hooks_disable_legend_disabled'] = 'kait wujud tapi dimatikan';
$txt['hooks_disable_legend_missing'] = 'kait itu tidak ditemui';
$txt['hooks_reset_filter'] = 'Kosongkan tapisan';

$txt['board_perms_allow'] = 'Izinkan';
$txt['board_perms_ignore'] = 'Abaikan';
$txt['board_perms_deny'] = 'Nafikan';
$txt['all_boards_in_cat'] = 'Semua ruangan dalam kategori ini';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Pemisah perkataan';

$txt['admin_order_title'] = 'Kesalahan Susunan';
$txt['admin_order_error'] = 'Kesalahan yang tidak diketahui berlaku semasa permohonan anda diproses';

// Known controllers that can work on the front page
$txt['default'] = 'Default';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
