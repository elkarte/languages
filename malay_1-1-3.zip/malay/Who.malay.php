<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>Kosong, atau tiada apa yang boleh anda lihat...</em>';
$txt['who_admin'] = 'Melihat portal pengurus';
$txt['who_moderate'] = 'Melihat portal moderator';
$txt['who_generic'] = 'Melihat %1$s';
$txt['who_unknown'] = '<em>Tindakan Tidak Diketahui</em>';
$txt['who_user'] = 'Pengguna';
$txt['who_time'] = 'Masa';
$txt['who_action'] = 'Tindakan';
$txt['who_show1'] = 'Paparkan';
$txt['who_show_members_only'] = 'Hanya Ahli';
$txt['who_show_guests_only'] = 'Hanya Tetamu';
$txt['who_show_spiders_only'] = 'Hanya Lelabah';
$txt['who_show_all'] = 'Setiap orang';
$txt['who_no_online_spiders'] = 'Sekarang ini tiada lelabah online.';
$txt['who_no_online_guests'] = 'Sekarang ini tiada tetamu online.';
$txt['who_no_online_members'] = 'Sekarang ini tiada ahli online.';

$txt['whospider_login'] = 'Masuk ke forum.';
$txt['whospider_register'] = 'Melihat laman pendaftaran.';
$txt['whospider_reminder'] = 'Melihat laman peringatan.';

$txt['whoall_activate'] = 'Mengaktifkan akaun mereka.';
$txt['whoall_buddy'] = 'Mengubahsuai senarai rakan.';
$txt['whoall_coppa'] = 'Mengisi borang kebenaran ibubapa/penjaga.';
$txt['whoall_credits'] = 'Melihat laman kredit.';
$txt['whoall_emailuser'] = 'Mengirimkan email ke ahli lain.';
$txt['whoall_groups'] = 'Melihat laman grup ahli.';
$txt['whoall_help'] = 'Melihat <a href="{help_url}">laman bantuan</a>.';
$txt['whoall_quickhelp'] = 'Melihat popup bantuan.';
$txt['whoall_pm'] = 'Melihat mesej mereka.';
$txt['whoall_auth'] = 'Log masuk ke forum.';
$txt['whoall_login'] = 'Masuk ke forum.';
$txt['whoall_login2'] = 'Masuk ke forum.';
$txt['whoall_logout'] = 'Keluar dari forum.';
$txt['whoall_markasread'] = 'Menanda topik sudah atau belum dibaca.';
$txt['whoall_mentions'] = 'Melihat senarai sebut.';
$txt['whoall_modifykarma_applaud'] = 'Memuji ahli.';
$txt['whoall_modifykarma_smite'] = 'Mengeji ahli.';
$txt['whoall_news'] = 'Melihat berita.';
$txt['whoall_notify'] = 'Mengubah tetapan makluman.';
$txt['whoall_notifyboard'] = 'Mengubah tetapan makluman.';
$txt['whoall_openidreturn'] = 'Masuk dengan OpenID.';
$txt['whoall_quickmod'] = 'Memoderasi ruangan.';
$txt['whoall_recent'] = 'Melihat <a href="{recent_url}">senarai topik terkini</a>.';
$txt['whoall_register'] = 'Mendaftarkan akaun pada forum.';
$txt['whoall_reminder'] = 'Meminta peringatan kata kunci.';
$txt['whoall_reporttm'] = 'Melaporkan topik ke moderator.';
$txt['whoall_spellcheck'] = 'Menggunakan pemeriksa ejaan';
$txt['whoall_unread'] = 'Melihat topik yang belum dibaca sejak kunjungan terakhir.';
$txt['whoall_unreadreplies'] = 'Melihat jawapan tidak dibaca sejak kunjungan terakhir.';
$txt['whoall_who'] = 'Melihat <a href="{who_url}">Siapa Online</a>.';

$txt['whoall_collapse_collapse'] = 'Menyempitkan kategori.';
$txt['whoall_collapse_expand'] = 'Melebarkan kategori.';
$txt['whoall_pm_removeall'] = 'Memadamkan semua mesej mereka.';
$txt['whoall_pm_send'] = 'Mengirimkan mesej.';
$txt['whoall_pm_send2'] = 'Mengirimkan mesej.';

$txt['whotopic_announce'] = 'Mengumumkan tajuk &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Meluluskan lampiran.';
$txt['whotopic_dlattach'] = 'Melihat lampiran.';
$txt['whotopic_deletemsg'] = 'Memadam mesej.';
$txt['whotopic_editpoll'] = 'Mengedit undian dalam &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Mengedit undian dalam &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Mengubah pos dalam &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Menyukai mesej dalam tajuk &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Mengunci tajuk &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Mengunci undian dalam &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Menggabungkan tajuk &quot;<a href="%1$s">%2$s</a>&quot; dengan tajuk lain.
';
$txt['whotopic_movetopic'] = 'Mengalihkan tajuk &quot;<a href="%1$s">%2$s</a>&quot; ke ruangan lain.';
$txt['whotopic_movetopic2'] = 'Mengalihkan tajuk &quot;<a href="%1$s">%2$s</a>&quot; ke ruangan lain.';
$txt['whotopic_post'] = 'Mengepos dalam <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Mengepos dalam <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Mencetak tajuk &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderasi tajuk <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Memadamkan undian dalam &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Memadamkan tajuk <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Mengirim tajuk &quot;<a href="%1$s">%2$s</a>&quot; kepada kawan.';
$txt['whotopic_splittopics'] = 'Memisahkan tajuk &quot;<a href="%1$s">%2$s</a>&quot; menjadi dua.';
$txt['whotopic_sticky'] = 'Memakukan tajuk &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Berhenti memantau topik.';
$txt['whotopic_vote'] = 'Mengundi dalam <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Mula memantau topik.';

$txt['whopost_quotefast'] = 'Memetik pos daripada &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Mengedit perjanjian pendaftaran.';
$txt['whoadmin_featuresettings'] = 'Mengedit ciri dan pilihan forum.';
$txt['whoadmin_modlog'] = 'Melihat log moderator.';
$txt['whoadmin_serversettings'] = 'Mengedit tetapan forum.';
$txt['whoadmin_packageget'] = 'Mendapatkan pakej.';
$txt['whoadmin_packages'] = 'Melihat pengurus pakej.';
$txt['whoadmin_permissions'] = 'Mengedit keizinan forum.';
$txt['whoadmin_pgdownload'] = 'Memuatturun pakej.';
$txt['whoadmin_theme'] = 'Mengedit tetapan tema.';
$txt['whoadmin_trackip'] = 'Mengesan alamat IP.';

$txt['whoallow_manageboards'] = 'Mengubah tetapan2 ruangan dan kategori.';
$txt['whoallow_admin'] = 'Melihat <a href="{admin_url}">Pusat Pengurusan</a>.';
$txt['whoallow_ban'] = 'Mengedit senarai sekatan.';
$txt['whoallow_boardrecount'] = 'Mengira semula jumlah forum.';
$txt['whoallow_calendar'] = 'Melihat <a href="{calendar_url}">kalendar</a>.';
$txt['whoallow_editnews'] = 'Mengedit berita.';
$txt['whoallow_mailing'] = 'Mengirimkan email forum.';
$txt['whoallow_maintain'] = 'Melakukan penyelenggaraan rutin forum.';
$txt['whoallow_manageattachments'] = 'Mengatur lampiran.';
$txt['whoallow_moderate'] = 'Melihat <a href="{moderate_url}">Pusat Moderasi</a>.';
$txt['whoallow_memberlist'] = 'Melihat <a href="{memberlist_url}">senarai ahli</a>.';
$txt['whoallow_optimizetables'] = 'Mengoptimasi table database.';
$txt['whoallow_repairboards'] = 'Membaiki table database.';
$txt['whoallow_search'] = '<a href="{search_url}">Mencari</a> dalam forum.';
$txt['whoallow_search_results'] = 'Melihat hasil carian.';
$txt['whoallow_setcensor'] = 'Mengedit teks sensor.';
$txt['whoallow_setreserve'] = 'Mengedit nama-nama terpelihara.';
$txt['whoallow_stats'] = 'Melihat <a href="{stats_url}">statistik forum</a>.';
$txt['whoallow_viewErrorLog'] = 'Melihat log kesalahan.';
$txt['whoallow_viewmembers'] = 'Melihat senarai ahli.';

$txt['who_topic'] = 'Melihat tajuk <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Melihat ruangan <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Melihat ruangan indeks <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Melihat profil <a href="%1$s">%2$s</a>.';
$txt['who_profile'] = 'Mengedit profil <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Mengepos tajuk baru dalam <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Mengepos undian baru dalam <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Memulakan emel tajuk baru dalam <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Mengepos emel dalam  <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Menhantar mesej peribadi melalui emel.';

// Credits text
$txt['credits'] = 'Penghargaan';
$txt['credits_intro'] = 'Simple Machines ingin berterima kasih kepada semua yang membantu menjadikan SMF 2.0 sepertimana ia sekarang; membentuk dan memantapkan projek kami. Ia tidak mungkin berhasil tanpa sokongan anda. Ini termasuk para pengguna kami terutamanya Charter Members - terima kasih kerana menginstall dan menggunakan software kami serta memberikan maklumbalas, laporan pepijat dan pandangan yang amat berharga.';
$txt['credits_contributors'] = 'Penyumbang';
$txt['credits_and'] = 'dan';
$txt['credits_copyright'] = 'Hakcipta';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Addons';
$txt['credits_software_graphics'] = 'Perisian/Grafik';
$txt['credits_software'] = 'Perisian';
$txt['credits_graphics'] = 'Grafik';
$txt['credits_fonts'] = 'Tulisan';
$txt['credits_groups_contrib'] = 'Penyumbang';
$txt['credits_contrib_list'] = 'Senarai lengkap mengenai semua individu yang menyumbang kepada rekacipta dan implementasi Elkarte, sila rujuk <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">senarai penyumbang</a> di GitHub rasmi.';
$txt['credits_license'] = 'Lesen';
$txt['credits_copyright'] = 'Hakcipta';
$txt['credits_version'] = 'Versi';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Penterjemah Bahasa';
$txt['credits_translators_message'] = 'Terima kasih atas usaha anda yang membolehkan manusia di seluruh dunia menggunakan SMF.';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';