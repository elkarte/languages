<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Tarikh';
$txt['modlog_member'] = 'Ahli';
$txt['modlog_position'] = 'Jawatan';
$txt['modlog_action'] = 'Tindakan';
$txt['modlog_ip'] = 'IP';
$txt['modlog_search_result'] = 'Hasil Carian';
$txt['modlog_total_entries'] = 'Total Entri';
$txt['modlog_ac_approve_topic'] = 'Setujui topik &quot;{topic}&quot; oleh &quot;{member}&quot;';
$txt['modlog_ac_unapprove_topic'] = 'Tajuk belum diluluskan &quot;{topic}&quot; oleh &quot;{member}&quot;';
$txt['modlog_ac_approve'] = 'Setujui pesan &quot;{subject}&quot; dalam &quot;{topic}&quot; oleh &quot;{member}&quot;';
$txt['modlog_ac_unapprove'] = 'Tajuk belum diluluskan &quot;{subject}&quot; dalam &quot;{topic}&quot; oleh &quot;{member}&quot;';
$txt['modlog_ac_lock'] = 'Kunci &quot;{topic}&quot;';
$txt['modlog_ac_warning'] = 'Diperingatkan {member} atas &quot;{message}&quot; ';
$txt['modlog_ac_unlock'] = 'Buka kunci &quot;{topic}&quot;';
$txt['modlog_ac_sticky'] = 'Lekitkan &quot;{topic}&quot;';
$txt['modlog_ac_unsticky'] = 'Lepaskan &quot;{topic}&quot;';
$txt['modlog_ac_delete'] = 'Dipadam &quot;{subject}&quot; oleh &quot;{member}&quot; dari &quot;{topic}&quot;';
$txt['modlog_ac_delete_member'] = 'Dipadam ahli &quot;{name}&quot;';
$txt['modlog_ac_remove'] = 'Dipadam topik &quot;{topic}&quot; dari &quot;{board}&quot;';
$txt['modlog_ac_modify'] = 'Diedit &quot;{message}&quot; oleh &quot;{member}&quot;';
$txt['modlog_ac_merge'] = 'Digabung topike untuk membuat &quot;{topic}&quot;';
$txt['modlog_ac_split'] = 'Dipisahkan &quot;{topic}&quot; untuk membuat &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = 'Dipindahkan &quot;{topic}&quot; dari &quot;{board_from}&quot; ke &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Mengedit profil &quot;{member}&quot;';
$txt['modlog_ac_pruned'] = 'Memadam beberapa pos lebih lama dari {days} hari';
$txt['modlog_ac_news'] = 'Mengedit berita';
$txt['modlog_enter_comment'] = 'Memasukkan Komen Moderasi';
$txt['modlog_moderation_log'] = 'Log Seliaan';
$txt['modlog_moderation_log_desc'] = 'Di bawah adalah senarai semua tindakan moderasi yang sudah dilakukan oleh moderator forum.<br /><strong>Perhatian:</strong> Entri tidak boleh dipadam dari log ini sampai setidaknya dua puluh empat jam lamanya.';
$txt['modlog_no_entries_found'] = 'Tidak ada entri log moderasi buat masa ini.';
$txt['modlog_remove'] = 'Padam Pilihan';
$txt['modlog_removeall'] = 'Padam semua';
$txt['modlog_remove_selected_confirm'] = 'Apakah anda pasti mahu memadamkan log pilihan?';
$txt['modlog_remove_all_confirm'] = 'Apakah anda benar2 mahu mengosongkan log?';
$txt['modlog_go'] = 'Pergi';
$txt['modlog_add'] = 'Tambah';
$txt['modlog_search'] = 'Carian Pantas';
$txt['modlog_by'] = 'Dengan';
$txt['modlog_id'] = '<em>(ID:%1$d)</em>';

$txt['modlog_ac_add_warn_template'] = 'Ditambahkan template amaran: &quot;{template}&quot;';
$txt['modlog_ac_modify_warn_template'] = 'Diedit template amaran: &quot;{template}&quot;';
$txt['modlog_ac_delete_warn_template'] = 'Dipadam template amaran: &quot;{template}&quot;';

$txt['modlog_ac_ban'] = 'Ditambahkan pemicu sekatan:';
$txt['modlog_ac_ban_update'] = 'Had sekatan yang diedit:';
$txt['modlog_ac_ban_remove'] = 'Had sekatan dibuang:';
$txt['modlog_ac_ban_trigger_member'] = ' <em>Ahli:</em> {member}';
$txt['modlog_ac_ban_trigger_email'] = ' <em>Email:</em> {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = ' <em>IP:</em> {ip_range}';
$txt['modlog_ac_ban_trigger_hostname'] = ' <em>Nama host:</em> {hostname}';

$txt['modlog_admin_log'] = 'Log Pengurusan';
$txt['modlog_admin_log_desc'] = 'Di bawah ini adalah senarai semua tindakan pengurusan yang sudah dicatat pada forum Anda.<br /><strong>Perhatian:</strong> Entri tidak boleh dipadam dari log ini sampai setidaknya dua puluh empat jam lamanya.';
$txt['modlog_admin_log_no_entries_found'] = 'Tidak ada entri log pengurusan buat masa ini.';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Dikemaskini forum ke versi {version}';
$txt['modlog_ac_install'] = 'Diinstall versi {version}';
$txt['modlog_ac_add_board'] = 'Ditambahkan board baru: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Diedit board &quot;{board}&quot;';
$txt['modlog_ac_delete_board'] = 'Dipadam board &quot;{boardname}&quot;';
$txt['modlog_ac_add_cat'] = 'Ditambahkan kategori baru, &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Diedit kategori &quot;{catname}&quot;';
$txt['modlog_ac_delete_cat'] = 'Dipadam kategori &quot;{catname}&quot;';

$txt['modlog_ac_delete_group'] = 'Dipadam grup &quot;{group}&quot;';
$txt['modlog_ac_add_group'] = 'Ditambahkan grup &quot;{group}&quot;';
$txt['modlog_ac_edited_group'] = 'Diedit grup &quot;{group}&quot;';
$txt['modlog_ac_added_to_group'] = 'Ditambahkan &quot;{member}&quot; ke grup &quot;{group}&quot;';
$txt['modlog_ac_removed_from_group'] = 'Dipadam &quot;{member}&quot; dari grup &quot;{group}&quot;';
$txt['modlog_ac_removed_all_groups'] = 'Dipadam &quot;{member}&quot; dari semua grup';

$txt['modlog_ac_remind_member'] = 'Dikirimkan pengingat ke &quot;{member}&quot; untuk mengaktifkan akaunnya';
$txt['modlog_ac_approve_member'] = 'Meluluskan/Mengaktifkan akaun &quot;{member}&quot;';
$txt['modlog_ac_newsletter'] = 'Warkah berita dikirimkan';

$txt['modlog_ac_install_package'] = 'Pakej baru diinstall: &quot;{package}&quot;, versi {version}';
$txt['modlog_ac_upgrade_package'] = 'Pakej dikemaskinikan: &quot;{package}&quot; kepada versi {version} ';
$txt['modlog_ac_uninstall_package'] = 'Pakej dibuka: &quot;{package}&quot;, versi {version}';

$txt['modlog_ac_database_backup'] = 'Backup database dibuat oleh {member}.';
$txt['modlog_ac_editing_theme'] = '{member} mengubah satu tema.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Mengembalikan topik &quot;{topic}&quot; dari &quot;{board}&quot; ke &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Mengembalikan pos dari &quot;{subject}&quot; ke topik &quot;{topic}&quot; dalam board &quot;{board}&quot;.';

$txt['modlog_parameter_guest'] = '<em>Tetamu</em>';

$txt['modlog_ac_approve_attach'] = 'Luluskan fail &quot;{filename}&quot; dalam &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Buang fail &quot;{filename}&quot; yang tidak diluluskan dalam &quot;{message}&quot;';