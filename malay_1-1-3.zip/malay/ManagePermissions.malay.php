<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Mengatur Keizinan';
$txt['permissions_modify'] = 'Ubah';
$txt['permissions_view'] = 'Lihat';
$txt['permissions_allowed'] = 'Diizinkan';
$txt['permissions_denied'] = 'Dinafikan';
$txt['permission_cannot_edit'] = '<strong>Catatan:</strong> anda tidak boleh edit profil keizinan ini kerana ia adalah profil tetapan default yang disertakan di dalam software forum secara default. Jika anda mahu mengubah keizinan profil ini anda mesti membuat salinan profil terlebih dulu. Anda dapat melakukan tugas ini dengan klik <a href="%1$s">di sini</a>.';

$txt['permissions_for_profile'] = 'Keizinan Profil';
$txt['permissions_boards_desc'] = 'Senarai berikut menunjukkan set keizinan yang telah ditempatkan pada setiap ruangan forum anda. Anda boleh mengedit profil keizinan dengan menekan klik pada nama ruangan atau memilih &quot;edit semua&quot; dari bawah laman. Untuk edit profil itu sendiri cukup sekadar klik pada nama profil.';
$txt['permissions_board_all'] = 'Edit Semua';
$txt['permission_profile'] = 'Profil Keizinan';
$txt['permission_profile_desc'] = 'Which <a target="_blank" href="%1$s">permission set</a> the board should use.';
$txt['permission_profile_inherit'] = 'Warisi daripada ruangan induk';

$txt['permissions_profile'] = 'Profil';
$txt['permissions_profiles_desc'] = 'Profil keizinan ditempatkan ke ruangan individual untuk mengizinkan anda dengan mudah mengatur tetapan keamanan. Dari area ini anda dapat membuat, edit dan memadam profil keizinan.';
$txt['permissions_profiles_change_for_board'] = 'Edit Profil Keizinan Untuk: &quot;%1$s&quot;';
$txt['permissions_profile_default'] = 'Default';
$txt['permissions_profile_no_polls'] = 'Tiada Undian';
$txt['permissions_profile_reply_only'] = 'Hanya Jawab';
$txt['permissions_profile_read_only'] = 'Hanya Baca';

$txt['permissions_profile_rename'] = 'Ganti nama';
$txt['permissions_profile_edit'] = 'Edit Profil';
$txt['permissions_profile_new'] = 'Profil Baru';
$txt['permissions_profile_new_create'] = 'Cipta';
$txt['permissions_profile_name'] = 'Nama Profil';
$txt['permissions_profile_used_by'] = 'Dipakai Oleh';
$txt['permissions_profile_used_by_one'] = '1 Ruangan';
$txt['permissions_profile_used_by_many'] = '%1$d Ruangan';
$txt['permissions_profile_used_by_none'] = 'Tiada Ruangan';
$txt['permissions_profile_do_edit'] = 'Edit';
$txt['permissions_profile_do_delete'] = 'Padam';
$txt['permissions_profile_copy_from'] = 'Salin Keizinan Dari';

$txt['permissions_includes_inherited'] = 'Warisan Grup';
$txt['permissions_includes_inherited_from'] = 'Diwarisi daripada:';

$txt['permissions_all'] = 'semua';
$txt['permissions_none'] = 'tiada';
$txt['permissions_set_permissions'] = 'Tetapkan keizinan';

$txt['permissions_advanced_options'] = 'Pilihan Lanjutan';
$txt['permissions_with_selection'] = 'Dengan pilihan';
$txt['permissions_apply_pre_defined'] = 'Terapkan set keizinan tetapan asal';
$txt['permissions_select_pre_defined'] = 'Pilih profil tetapan asal';
$txt['permissions_copy_from_board'] = 'Salin keizinan dari ruangan ini';
$txt['permissions_select_board'] = 'Pilih ruangan';
$txt['permissions_like_group'] = 'Tetapkan keizinan seperti grup ini';
$txt['permissions_select_membergroup'] = 'Pilih grup ahli';
$txt['permissions_add'] = 'Tambah keizinan';
$txt['permissions_remove'] = 'Padam keizinan';
$txt['permissions_deny'] = 'Tolak keizinan';
$txt['permissions_select_permission'] = 'Pilih keizinan';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Anda hanya boleh memilih satu aksi untuk memodifikasi keizinan';
$txt['permissions_no_action'] = 'Tindakan tidak dipilih';
$txt['permissions_deny_dangerous'] = 'Anda akan menafikan satu atau lebih keizinan.\\nIni boleh berbahaya dan menyebabkan hasil yang tidak diharapkan jika anda belum yakin tidak seorangpun \\"secara kebetulan\\" di dalam grup yang anda nafikan keizinannya.\\n\\nAnda yakin mahu teruskan?';

$txt['permissions_modify_group'] = 'Ubah Grup';
$txt['permissions_general'] = 'Keizinan Umum';
$txt['permissions_board'] = 'Keizinan Profil Ruangan Default';
$txt['permissions_board_desc'] = '<strong>Catatan</strong>: mengubah keizinan ruangan ini akan mempengaruhi semua profil keizinan &quot;Default&quot; semasa pada ruangan. Ruangan yang tidak menggunakan profil &quot;Default&quot; tidak akan dipengaruhi dengan perubahan kepada laman ini.';
$txt['permissions_commit'] = 'Simpan Perubahan';
$txt['permissions_on'] = 'dalam profil';
$txt['permissions_local_for'] = 'Keizinan untuk grup';
$txt['permissions_option_on'] = 'A';
$txt['permissions_option_off'] = 'X';
$txt['permissions_option_deny'] = 'D';
$txt['permissions_option_desc'] = 'Untuk setiap keizinan anda dapat mengambil baik \'Izinkan\' (A), \'Larang\' (X), atau <span style="color: red;">\'Tolak\' (D)</span>.<br /><br />Ingat bahawa jika anda menafikan satu keizinan, setiap ahli - apakah moderator atau bukan - yang ada dalam grup itu akan dinafikan juga.<br />Untuk alasan ini, anda semestinya menggunakan penafian dengan hati-hati, hanya bila <strong>diperlukan</strong>. Larang, pula menafikan kecuali sebaliknya diizinkan.';

$txt['permissiongroup_general'] = 'Umum';
$txt['permissionname_view_stats'] = 'Lihat statistik forum';
$txt['permissionhelp_view_stats'] = 'Statistik forum adalah sebuah laman yang meringkas semua statistik forum, seperti jumlah ahli, jumlah pos harian, dan beberapa statistik 10 teratas. Mengaktifkan keizinan ini akan menambah link di bawah indeks papan (\'[Statistik Lengkap]\').';
$txt['permissionname_view_mlist'] = 'Lihat senarai ahli dan grup';
$txt['permissionhelp_view_mlist'] = 'Senarai ahli memperlihatkan semua ahli yang telah berdaftar pada forum anda. Senarai dapat diurut dan dicari. Senarai ahli dihubungkan dari indeks papan dan laman statistik, dengan klik pada jumlah ahli. Ini juga berlaku bagi laman grup yang merupakan senarai mini ahli dalam grup tersebut.';
$txt['permissionname_who_view'] = 'Lihat Siapa Online';
$txt['permissionhelp_who_view'] = 'Siapa online memaparkan semua ahli yang ketika ini online dan apa yang mereka lakukan ketika ini. Keizinan ini hanya akan bekerja jika anda juga mengaktifkannya dalam \'Ciri dan Pilihan\'. Anda dapat mengakses layar \'Siapa Online\' dengan klik link dalam bahagian \'Pengguna Online\' dari indeks papan. Meskipun dinafikan, ahli masih akan boleh melihat siapa online, hanya tidak di mana mereka berada.';
$txt['permissionname_search_posts'] = 'Mencari pos dan topik';
$txt['permissionhelp_search_posts'] = 'Keizinan pencarian membolehkan pengguna untuk mencari semua papan di mana dia diizinkan untuk mengakses. Ketika keizinan pencarian diaktifkan, butang \'Cari\' akan ditambahkan ke bar butang forum.';
$txt['permissionname_karma_edit'] = 'Ubah karma orang lain';
$txt['permissionhelp_karma_edit'] = 'Karma adalah ciri yang memperlihatkan populariti ahli. Untuk menggunakan ciri ini, anda perlu mengaktifkannya dalam \'Ciri dan Pilihan\'. Keizinan ini akan membolehkan grup ahli untuk memberikan suara. Keizinan ini tidak berkesan pada tetamu.';
$txt['permissionname_like_posts'] = 'Suka pos ahli lain';
$txt['permissionhelp_like_posts'] = 'Suka ialah satu ciri yang memaparkan populariti satu2 pos. Bagi menggunakannya, anda perlu menghidupkannya dalam \'Ciri dan Pilihan\'. Kebenaran ini akan membolehkan ahli grup untuk suka satu2 pos atau membatalkan apa yang telah disukai. Kebenaran ini tiada kesan kepada tetamu.';
$txt['permissionname_like_posts_stats'] = 'See like posts stats';
$txt['permissionhelp_like_posts_stats'] = 'This will allow users to see stats of posts liking';
$txt['permissionname_disable_censor'] = 'Matikan larangan perkataan';
$txt['permissionhelp_disable_censor'] = 'Benarkan ahli memilih untuk mematikan larangan perkataan.';

$txt['permissiongroup_pm'] = 'Mesej Peribadi';
$txt['permissionname_pm_read'] = 'Baca mesej peribadi';
$txt['permissionhelp_pm_read'] = 'Keizinan ini membolehkan pengguna untuk mengakses bahagian Mesej Peribadi dan membaca Mesej Peribadinya. Tanpa keizinan ini pengguna tidak boleh untuk mengirimkan Mesej Peribadi.';
$txt['permissionname_pm_send'] = 'Kirim mesej peribadi';
$txt['permissionhelp_pm_send'] = 'Kirimkan mesej peribadi ke ahli berdaftar lain. Memerlukan keizinan \'Baca mesej peribadi\'.';
$txt['permissionname_send_email_to_members'] = 'Hantar emel';
$txt['permissionhelp_send_email_to_members'] = 'Hantar emel untuk ahli berdaftar yang lain.';

$txt['permissiongroup_calendar'] = 'Kalendar';
$txt['permissionname_calendar_view'] = 'Lihat kalendar';
$txt['permissionhelp_calendar_view'] = 'Kalendar memaparkan pada setiap bulan hari jadi, acara dan cuti. Keizinan ini memberikan akses kepada kalendar ini. Apabila keizinan ini diaktifkan, satu butang akan ditambahkan ke menu butang atas dan satu senarai akan dipaparkan di bawah ruangan indeks dengan hari jadi, acara dan cuti semasa dan akan datang. Kalendar perlu diaktifkan dari \'Komfigurasi - Ciri-ciri Utama\'.';
$txt['permissionname_calendar_post'] = 'Buat acara dalam kalendar';
$txt['permissionhelp_calendar_post'] = 'Sebuah acara adalah topik yang dihubungkan ke tarikh dan jangkauan tarikh tertentu. Pembuatan acara boleh dikerjakan dari kalendar. Sebuah acara hanya boleh dibuat jika pengguna yang membuat acara diizinkan untuk menulis topik baru.';
$txt['permissionname_calendar_edit'] = 'Edit acara dalam kalendar';
$txt['permissionhelp_calendar_edit'] = 'Acara adalah topik yang dihubungkan ke satu tarikh atau jangkamasa tertentu. Acara dapat diedit dengan menekan bintang merah (*) di sebelah acara dalam paparan kalendar. Untuk mengedit sebuah acara, pengguna mesti memiliki keizinan untuk mengedit mesej pertama pada topik yang dipautkan ke acara tersebut.';
$txt['permissionname_calendar_edit_own'] = 'Acara sendiri';
$txt['permissionname_calendar_edit_any'] = 'Setiap acara';

$txt['permissiongroup_maintenance'] = 'Pengurusan forum';
$txt['permissionname_admin_forum'] = 'Pengurusan forum dan database';
$txt['permissionhelp_admin_forum'] = 'Keizinan ini membolehkan pengguna untuk:<ul class="normallist"><li>mengubah forum, database dan tetapan tema</li><li>mengatur paket</li><li>menggunakan piranti forum dan pemeliharaan database</li><li>melihat kesalahan dan log moderasi</li></ul> Gunakan keizinan ini dengan hati-hati, kerana sangat penting.';
$txt['permissionname_manage_boards'] = 'Mengatur ruangan2 dan kategori2';
$txt['permissionhelp_manage_boards'] = 'Keizinan ini membolehkan penciptaan, pengubahan dan pemadaman ruangan2 dan kategori2.';
$txt['permissionname_manage_attachments'] = 'Mengatur lampiran dan avatar';
$txt['permissionhelp_manage_attachments'] = 'Keizinan ini membolehkan akses ke pusat lampiran, di mana semua lampiran forum dan avatar didaftarkan dan dapat dipadam.';
$txt['permissionname_manage_smileys'] = 'Urus mimik dan ikon mesej';
$txt['permissionhelp_manage_smileys'] = 'Ini membolehkan akses ke pusat mimik. Dalam pusat mimik anda boleh menambah, edit, dan memadam mimik dan set mimik. Jika anda telah mengaktifkan ikon mesej diubahsuai, anda juga boleh menambah dan edit ikon mesej dengan keizinan ini.';
$txt['permissionname_edit_news'] = 'Edit berita';
$txt['permissionhelp_edit_news'] = 'Fungsi berita mengizinkan baris berita acak untuk muncul pada setiap layar. Untuk menggunakan fungsi berita, aktifkan ia dalam tetapan forum.';
$txt['permissionname_access_mod_center'] = 'Akses pusat moderasi';
$txt['permissionhelp_access_mod_center'] = 'Dengan keizinan ini setiap ahli dari grup ini dapat mengakses pusat moderasi dari mana mereka mempunyai akses ke fungsi untuk memudahkan moderasi. Perhatikan bahawa ini tidak menjadikan dirinya diberi setiap hak moderasi.';

$txt['permissiongroup_member_admin'] = 'Pengurusan ahli';
$txt['permissionname_moderate_forum'] = 'Moderasi ahli forum';
$txt['permissionhelp_moderate_forum'] = 'Keizinan ini termasuk semua fungsi moderasi penting:<ul class="normallist"><li>mengakses ke pengurusan pendaftaran</li><li>akses ke layar lihat/padam ahli</li><li>info profil ekstensif, termasuk jejak IP/pengguna dan status online (sembunyi)</li><li>mengaktifkan akaun</li><li>memperoleh kelulusan makluman dan kelulusan akaun</li><li>kebal untuk mengabaikan mesej</li><li>beberapa hal kecil lainnya</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Mengatur dan menempatkan grup ahli';
$txt['permissionhelp_manage_membergroups'] = 'Keizinan ini membolehkan pengguna untuk edit grup ahli dan menempatkan grup ahli ke ahli lain.';
$txt['permissionname_manage_permissions'] = 'Mengatur keizinan';
$txt['permissionhelp_manage_permissions'] = 'Keizinan ini membolehkan pengguna untuk mengubah semua keizinan sesuatu grup ahli, secara keseluruhan atau untuk ruangan2 individu.';
$txt['permissionname_manage_bans'] = 'Mengatur senarai sekatan';
$txt['permissionhelp_manage_bans'] = 'Keizinan ini membolehkan pengguna untuk menambah atau memadam nama pengguna, alamat IP, nama host dan alamat email ke sebuah senarai pengguna yang disekat. Ia juga membolehkan pengguna untuk melihat dan memadam entri log pengguna yang disekat yang mencuba untuk masuk.';
$txt['permissionname_send_mail'] = 'Kirim email forum ke ahli';
$txt['permissionhelp_send_mail'] = 'Surat masal semua ahli forum, atau hanya beberapa grup ahli dengan email atau mesej peribadi (mesej peribadi memerlukan keizinan \'Kirim Mesej Peribadi\').';
$txt['permissionname_issue_warning'] = 'Berikan amaran kepada ahli';
$txt['permissionhelp_issue_warning'] = 'Menerbitkan amaran untuk ahli forum dan mengubah tahap amaran ahli. Memerlukan sistem amaran untuk diaktifkan.';

$txt['permissiongroup_profile'] = 'Profil Ahli';
$txt['permissionname_profile_view'] = 'Lihat ringkasan dan statistik profil';
$txt['permissionhelp_profile_view'] = 'Keizinan ini membolehkan pengguna klik pada nama pengguna untuk melihat tetapan profilnya, beberapa statistik dan semua pos pengguna.';
$txt['permissionname_profile_view_own'] = 'Profil sendiri';
$txt['permissionname_profile_view_any'] = 'Setiap profil';
$txt['permissionname_profile_identity'] = 'Edit tetapan akaun';
$txt['permissionhelp_profile_identity'] = 'Keizinan ini adalah tetapan dasar profil, seperti kata kunci, alamat email, grup ahli dan bahasa yang dimahukan.';
$txt['permissionname_profile_identity_own'] = 'Profil sendiri';
$txt['permissionname_profile_identity_any'] = 'Setiap profil';
$txt['permissionname_profile_extra'] = 'Edit tetapan profil tambahan';
$txt['permissionhelp_profile_extra'] = 'Tetapan profil tambahan termasuk tetapan avatar, keutamaan tema, makluman dan Mesej Peribadi.';
$txt['permissionname_profile_extra_own'] = 'Profil sendiri';
$txt['permissionname_profile_extra_any'] = 'Setiap profil';
$txt['permissionname_profile_title'] = 'Edit tajuk plihan';
$txt['permissionhelp_profile_title'] = 'Tajuk plihan dipaparkan pada laman paparan topik, di bawah profil setiap pengguna yang memiliki tajuk plihan.';
$txt['permissionname_profile_title_own'] = 'Profil sendiri';
$txt['permissionname_profile_title_any'] = 'Setiap profil';
$txt['permissionname_profile_remove'] = 'Padam akaun';
$txt['permissionhelp_profile_remove'] = 'Keizinan ini membolehkan pengguna untuk memadam akaunnya, ketika ditetapkan ke \'Akaun Sendiri\'.';
$txt['permissionname_profile_remove_own'] = 'Akaun sendiri';
$txt['permissionname_profile_remove_any'] = 'Setiap akaun';
$txt['permissionname_profile_set_avatar'] = 'Pilih avatar';
$txt['permissionhelp_profile_set_avatar'] = 'Jika dihidupkan akan membenarkan ahli memilih avatar.';

$txt['permissiongroup_general_board'] = 'Umum';
$txt['permissionname_moderate_board'] = 'Moderasi ruangan';
$txt['permissionhelp_moderate_board'] = 'Keizinan moderasi ruangan menambah beberapa keizinan kecil yang membuat moderator menjadi moderator sebenar. Keizinan2 termasuklah menjawab ke topik berkunci, mengubah waktu luput pengundian dan melihat hasil2 undian.';

$txt['permissiongroup_topic'] = 'Topik';
$txt['permissionname_post_new'] = 'Pos topik baru';
$txt['permissionhelp_post_new'] = 'Keizinan ini membolehkan pengguna untuk menulis topik baru. Ia tidak membolehkan untuk menulis jawapan ke topik.';
$txt['permissionname_merge_any'] = 'Gabung setiap topik';
$txt['permissionhelp_merge_any'] = 'Gabung dua atau lebih topik menjadi satu. Urutan mesej di dalam topik gabungan adalah berdasarkan kepada waktu mesej2 dicipta. Pengguna hanya boleh menggabungkan topik pada ruangan yang dibenarkan. Untuk menggabungkan pelbagai topik sekaligus, pengguna mesti mengaktifkan moderasi pantas dalam tetapan2 profilnya.';
$txt['permissionname_split_any'] = 'Pisahkan setiap topik';
$txt['permissionhelp_split_any'] = 'Pisahkan topik menjadi dua topik terpisah.';
$txt['permissionname_send_topic'] = 'Kirim topik ke teman';
$txt['permissionhelp_send_topic'] = 'Keizinan ini membolehkan pengguna untuk mengirim email topik ke temannya dengan memasukan alamat email dan diizinkan untuk menambahkan mesej.';
$txt['permissionname_make_sticky'] = 'Jadikan topik lekit';
$txt['permissionhelp_make_sticky'] = 'Topik lekit adalah topik yang selalu berada di ruangan atas. Ia berguna untuk pengumuman atau mesej penting yang lain.';
$txt['permissionname_move'] = 'Pindahkan topik';
$txt['permissionhelp_move'] = 'Pindahkan topik daripada satu ruangan kepada yang lain. Pengguna hanya boleh memilih ruangan sasaran yang mana mereka diizinkan untuk masuk.';
$txt['permissionname_move_own'] = 'Topik sendiri';
$txt['permissionname_move_any'] = 'Setiap topik';
$txt['permissionname_lock'] = 'Kunci topik';
$txt['permissionhelp_lock'] = 'Keizinan ini membolehkan pengguna untuk mengunci topik. Ini boleh dikerjakan agar memastikan tiada seorangpun boleh menjawab ke topik. Hanya pengguna dengan keizinan \'Moderasi papan\' masih boleh menulis dalam topik yang dikunci.';
$txt['permissionname_lock_own'] = 'Topik sendiri';
$txt['permissionname_lock_any'] = 'Setiap topik';
$txt['permissionname_remove'] = 'Padam topik';
$txt['permissionhelp_remove'] = 'Padam topik secara kesemuaan. Perhatikan bahawa keizinan ini tidak membolehkan untuk memadam mesej tertentu di dalam topik!';
$txt['permissionname_remove_own'] = 'Topik sendiri';
$txt['permissionname_remove_any'] = 'Setiap topik';
$txt['permissionname_post_reply'] = 'Pos jawapan ke topik';
$txt['permissionhelp_post_reply'] = 'Keizinan ini membolehkan menjawab ke topik.';
$txt['permissionname_post_reply_own'] = 'Topik sendiri';
$txt['permissionname_post_reply_any'] = 'Setiap topik';
$txt['permissionname_modify_replies'] = 'Ubah jawapan ke topik sendiri';
$txt['permissionhelp_modify_replies'] = 'Keizinan ini membolehkan pengguna yang memulai topik untuk mengubah semua jawapan ke topiknya.';
$txt['permissionname_delete_replies'] = 'Padam jawapan ke topik sendiri';
$txt['permissionhelp_delete_replies'] = 'Keizinan ini membolehkan pengguna yang memulai topik memadam semua jawapan ke topik.';
$txt['permissionname_announce_topic'] = 'Umumkan topik';
$txt['permissionhelp_announce_topic'] = 'Ini mengizinkan pengguna untuk mengirimkan email pengumuman mengenai topik ke semua ahli atau beberapa grup ahli.';

$txt['permissionname_approve_emails'] = 'Moderasi Pos melalui Kegagalan Emel';
$txt['permissionhelp_approve_emails'] = 'Benarkan moderator mengakses log Pos melalui Kegagalan Emel  untuk melaksanakan tindakan2 termasuklah meluluskan, memadam, melihat dan menolak. Nota, memandangkan sistem tidak boleh senantiasa mengesan ke mana ruangan mana satu2 pos itu ditujukan, kebenaran seharusnya diberikan kepada ahli yang mempunyai akses penuh kepada satu2 ruangan.';
$txt['permissionname_postby_email'] = 'Pos melalui Emel';
$txt['permissionhelp_postby_email'] = 'Kebenaran ini membolehkan ahli memulakan topik baru selain menjawab topik dan makluman PM melalui emel.';

$txt['permissiongroup_post'] = 'Pos';
$txt['permissionname_delete'] = 'Padam pos';
$txt['permissionhelp_delete'] = 'Padam pos. Ini tidak mengizinkan pengguna untuk memadam pos pertama pada topik.';
$txt['permissionname_delete_own'] = 'Pos sendiri';
$txt['permissionname_delete_any'] = 'Setiap pos';
$txt['permissionname_modify'] = 'Ubah pos';
$txt['permissionhelp_modify'] = 'Edit pos';
$txt['permissionname_modify_own'] = 'Pos sendiri';
$txt['permissionname_modify_any'] = 'Setiap pos';
$txt['permissionname_report_any'] = 'Laporkan pos ke moderator';
$txt['permissionhelp_report_any'] = 'Keizinan ini menambah link ke setiap mesej, mengizinkan pengguna untuk melaporkan pos ke moderator. Saat pelaporan, semua moderator pada papan itu akan menerima email dengan link ke pos yang dilaporkan dan deskripsi masalah (diberikan oleh pengguna pelapor).';

$txt['permissiongroup_poll'] = 'Undian';
$txt['permissionname_poll_view'] = 'Lihat undian';
$txt['permissionhelp_poll_view'] = 'Keizinan ini membolehkan pengguna untuk melihat undian. Tanpa keizinan ini, pengguna hanya melihat topik.';
$txt['permissionname_poll_vote'] = 'Pilih dalam undian';
$txt['permissionhelp_poll_vote'] = 'Keizinan ini membolehkan pengguna (berdaftar) untuk memberikan satu suara. Ini tidak berlaku bagi tetamu.';
$txt['permissionname_poll_post'] = 'Pos undian';
$txt['permissionhelp_poll_post'] = 'Keizinan ini mengizinkan pengguna untuk menulis undian baru. Pengguna mesti memiliki keizinan \'Pos topik baru\'.';
$txt['permissionname_poll_add'] = 'Tambah undian ke topik';
$txt['permissionhelp_poll_add'] = 'Tambah undian ke topik membolehkan pengguna untuk menambah undian setelah topik telah dibuat. Keizinan ini memerlukan hak yang cukup untuk edit pos pertama pada topik.';
$txt['permissionname_poll_add_own'] = 'Topik sendiri';
$txt['permissionname_poll_add_any'] = 'Setiap topik';
$txt['permissionname_poll_edit'] = 'Edit undian';
$txt['permissionhelp_poll_edit'] = 'Keizinan ini membolehkan pengguna untuk mengubah pilihan undian dan mengosongkan undian. Bagi membolehkannya mengubah jumlah undi dan waktu luputnya secara maksima, pengguna memerlukan mempunyai keizinan \'Moderasi ruangan\'.';
$txt['permissionname_poll_edit_own'] = 'Undian sendiri';
$txt['permissionname_poll_edit_any'] = 'Setiap undian';
$txt['permissionname_poll_lock'] = 'Kunci undian';
$txt['permissionhelp_poll_lock'] = 'Mengunci undian menghindari undian atas penerimaan suara baru.';
$txt['permissionname_poll_lock_own'] = 'Undian sendiri';
$txt['permissionname_poll_lock_any'] = 'Setiap undian';
$txt['permissionname_poll_remove'] = 'Padam undian';
$txt['permissionhelp_poll_remove'] = 'Keizinan ini membolehkan pemadaman undian.';
$txt['permissionname_poll_remove_own'] = 'Undian sendiri';
$txt['permissionname_poll_remove_any'] = 'Setiap undian';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Simpan deraf pos baru';
$txt['permissionname_simple_post_draft'] = 'Simpan deraf pos baru';
$txt['permissionhelp_post_draft'] = 'Kebenaran ini membolehkan ahli menyimpan deraf pos mereka supaya boleh disempurnakan kemudian.';
$txt['permissionhelp_simple_post_draft'] = 'Kebenaran ini membolehkan ahli menyimpan deraf pos mereka supaya boleh disempurnakan kemudian.';
$txt['permissionname_post_autosave_draft'] = 'Simpan deraf pos baru secara automatik';
$txt['permissionname_simple_post_autosave_draft'] = 'Simpan deraf pos baru secara automatik';
$txt['permissionhelp_post_autosave_draft'] = 'Kebenaran ini membolehkan ahli menyimpan pos mereka sebagai deraf secara automatik supaya mereka boleh mengelakkan kehilangan kerja mereka sekiranya masa tamat, terputus talian atau lain2 masalah. Jadual simpan automatik ditentukan dalam panel pengurusan.';
$txt['permissionhelp_simple_post_autosave_draft'] = 'Kebenaran ini membolehkan ahli menyimpan pos mereka sebagai deraf secara automatik supaya mereka boleh mengelakkan kehilangan kerja mereka sekiranya masa tamat, terputus talian atau lain2 masalah. Jadual simpan automatik ditentukan dalam panel pengurusan.';
$txt['permissionname_pm_autosave_draft'] = 'Simpan deraf PM baru secara automatik';
$txt['permissionname_simple_pm_autosave_draft'] = 'Simpan deraf PM baru secara automatik';
$txt['permissionhelp_pm_autosave_draft'] = 'Kebenaran ini membolehkan ahli menyimpan pos mereka sebagai deraf secara automatik supaya mereka boleh mengelakkan kehilangan kerja mereka sekiranya masa tamat, terputus talian atau lain2 masalah. Jadual simpan automatik ditentukan dalam panel pengurusan.';
$txt['permissionhelp_simple_post_autosave_draft'] = 'Kebenaran ini membolehkan ahli menyimpan pos mereka sebagai deraf secara automatik supaya mereka boleh mengelakkan kehilangan kerja mereka sekiranya masa tamat, terputus talian atau lain2 masalah. Jadual simpan automatik ditentukan dalam panel pengurusan.';
$txt['permissionname_pm_draft'] = 'Simpan deraf mesej peribadi';
$txt['permissionname_simple_pm_draft'] = 'Simpan deraf mesej peribadi';
$txt['permissionhelp_pm_draft'] = 'Kebenaran ini membolehkan ahli menyimpan deraf mesej peribadi mereka supaya boleh disempurnakan kemudian.';
$txt['permissionhelp_simple_pm_draft'] = 'Kebenaran ini membolehkan ahli menyimpan deraf mesej peribadi mereka supaya boleh disempurnakan kemudian.';

$txt['permissiongroup_approval'] = 'Seliaan Pos';
$txt['permissionname_approve_posts'] = 'Setujui item yang menunggu moderasi';
$txt['permissionhelp_approve_posts'] = 'Keizinan ini membolehkan pengguna untuk meluluskan semua item yang belum lulus pada sesuatu ruangan.';
$txt['permissionname_post_unapproved_replies'] = 'Pos jawapan yang belum disetujui';
$txt['permissionhelp_post_unapproved_replies'] = 'Keizinan ini membolehkan pengguna untuk mengepos jawapan ke satu-satu topik. Jawapan tidak akan dipaparkan sehingga diluluskan oleh penyelia.';
$txt['permissionname_post_unapproved_replies_own'] = 'Topik sendiri';
$txt['permissionname_post_unapproved_replies_any'] = 'Setiap topik';
$txt['permissionname_post_unapproved_topics'] = 'Pos topik yang belum disetujui';
$txt['permissionhelp_post_unapproved_topics'] = 'Keizinan ini membolehkan pengguna untuk menuliskan topik baru yang memerlukan kelulusan sebelum dipaparkan.';
$txt['permissionname_post_unapproved_attachments'] = 'Pos lampiran yang belum disetujui';
$txt['permissionhelp_post_unapproved_attachments'] = 'Keizinan ini membolehkan pengguna untuk melampirkan fail pada posnya. Fail yang dilampirkan perlu satu kelulusan sebelum ia dipaparkan kepada pengguna lain.';

$txt['permissiongroup_notification'] = 'Makluman';
$txt['permissionname_mark_any_notify'] = 'Minta makluman pada jawapan';
$txt['permissionhelp_mark_any_notify'] = 'Ciri ini mengizinkan pengguna menerima makluman apabila seseorang menjawab pada topik yang mereka langgan.';
$txt['permissionname_mark_notify'] = 'Minta makluman pada topik baru';
$txt['permissionhelp_mark_notify'] = 'Makluman pada topik baru adalah ciri yang mengizinkan pengguna untuk menerima emel setiap kali topik baru dicipta pada ruangan di mana mereka melanggan.';

$txt['permissiongroup_attachment'] = 'Lampiran';
$txt['permissionname_view_attachments'] = 'Lihat lampiran';
$txt['permissionhelp_view_attachments'] = 'Lampiran adalah fail yang dilampirkan ke mesej yang dipos. Ciri ini dapat diaktifkan dan dikonfigurasi dalam \'Lampiran dan avatar\'. Memandangkan lampiran tidak diakses secara langsung, anda dapat melindunginya daripada dimuatturun oleh pengguna yang tiada keizinan.';
$txt['permissionname_post_attachment'] = 'Pos lampiran';
$txt['permissionhelp_post_attachment'] = 'Lampiran adalah fail yang dilampirkan ke mesej yang dipos. Satu mesej dapat berisi pelbagai lampiran.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Tetapan Keizinan';
$txt['groups_manage_permissions'] = 'Grup ahli diperbolehkan untuk mengatur keizinan';
$txt['permission_enable_deny'] = 'Aktifkan pilihan untuk menafikan keizinan';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Mematikan pilihan ini akan memutakhirkan keizinan-\\\'Tolak\\\' ke \\\'Larang\\\'.';
$txt['permission_by_board_desc'] = 'Di sini anda boleh menetapkan profil keizinan bagi sesuatu ruangan. Anda boleh mencipta profil keizinan baru daripada menu &quot;Edit Profil&quot;.';
$txt['permission_settings_desc'] = 'Di sini anda dapat menetapkan siapa yang memiliki keizinan untuk mengubah keizinan, juga seberapa memuaskan sistem keizinan semestinya.';
$txt['permission_enable_postgroups'] = 'Aktifkan keizinan untuk grup berasaskan jumlah pos';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Mematikan tetapan ini akan memadam keizinan yang ketika ini ditetapkan ke grup berasaskan jumlah pos.';

$txt['permissions_post_moderation_desc'] = 'Dari laman ini anda dapat mengubah dengan mudah grup mana yang posnya dimoderasi untuk profil keizinan tertentu.';
$txt['permissions_post_moderation_deny_note'] = 'Perhatikan bahawa ketika anda mengaktifkan keizinan lanjutan, anda tidak dapat menerapkan keizinan &quot;penafian&quot; dari laman ini. Sila edit keizinan secara langsung jika anda mahu menerapkan keizinan penafian.';
$txt['permissions_post_moderation_select'] = 'Pilih Profil';
$txt['permissions_post_moderation_new_topics'] = 'Topik Baru';
$txt['permissions_post_moderation_replies_own'] = 'Jawapan Sendiri';
$txt['permissions_post_moderation_replies_any'] = 'Setiap Jawapan';
$txt['permissions_post_moderation_attachments'] = 'Lampiran';
$txt['permissions_post_moderation_legend'] = 'Carta';
$txt['permissions_post_moderation_allow'] = 'Dapat membuat';
$txt['permissions_post_moderation_moderate'] = 'Dapat membuat tapi memerlukan kelulusan';
$txt['permissions_post_moderation_disallow'] = 'Tidak boleh membuat';
$txt['permissions_post_moderation_group'] = 'Grup';

$txt['auto_approve_topics'] = 'Pos topik baru tanpa memerlukan kelulusan';
$txt['auto_approve_replies'] = 'Pos jawapan atas topik tanpa memerlukan kelulusan';
$txt['auto_approve_attachments'] = 'Pos lampiran tanpa memerlukan kelulusan';
