<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Jadual Tugas';
$txt['scheduled_tasks_header'] = 'Semua Jadual Tugas';
$txt['scheduled_tasks_name'] = 'Nama Tugas';
$txt['scheduled_tasks_next_time'] = 'Berakhir Pada';
$txt['scheduled_tasks_regularity'] = 'Biasa';
$txt['scheduled_tasks_enabled'] = 'Diaktifkan';
$txt['scheduled_tasks_run_now'] = 'Jalankan tugas sekarang';
$txt['scheduled_tasks_save_changes'] = 'Simpan Ubahan';
$txt['scheduled_tasks_time_offset'] = '<strong>Catatan:</strong> Semua waktu berikut adalah <em>waktu server</em> dan tidak mengambil kira waktu offset dalam panel pengurus.';
$txt['scheduled_tasks_were_run'] = 'Semua tugas yang dipilih selesai dilaksanakan';
$txt['scheduled_tasks_were_run_errors'] = 'Kesalahan berikut berlaku semasa menjalankan tugas yang dijadualkan:';

$txt['scheduled_tasks_na'] = 'N/A';
$txt['scheduled_task_approval_notification'] = 'Makluman Kelulusan';
$txt['scheduled_task_desc_approval_notification'] = 'Kirim email ke semua moderator, meringkaskan tulisan menunggu kelulusan.';
$txt['scheduled_task_auto_optimize'] = 'Optimasi Database';
$txt['scheduled_task_desc_auto_optimize'] = 'Mengoptimasi database untuk membaiki masalah fragmentasi.';
$txt['scheduled_task_daily_maintenance'] = 'Penyelenggaraan Harian';
$txt['scheduled_task_desc_daily_maintenance'] = 'Menjalankan penyelenggaraan harian penting pada forum - seharusnya tidak dimatikan.';
$txt['scheduled_task_daily_digest'] = 'Ringkasan Berita Harian';
$txt['scheduled_task_desc_daily_digest'] = 'Email pasukan berita harian untuk pelanggan berita.';
$txt['scheduled_task_weekly_digest'] = 'Ringkasan Berita Mingguan';
$txt['scheduled_task_desc_weekly_digest'] = 'Email pasukan berita mingguan untuk pelanggan berita.';
$txt['scheduled_task_birthdayemails'] = 'Kirim Email Hari Jadi';
$txt['scheduled_task_desc_birthdayemails'] = 'Mengirimkan email ucapan selamat hari jadi kepada anggota.';
$txt['scheduled_task_weekly_maintenance'] = 'Penyelenggaraan Mingguan';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Menjalankan penyelenggaraan mingguan pada forum - seharusnya tidak dimatikan.';
$txt['scheduled_task_paid_subscriptions'] = 'Pemeriksaan Langganan Berbayar';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Mengirimkan peringatan langganan berbayar yang diperlukan serta memadam langganan ahli yang sudah tamat tempoh.';
$txt['scheduled_task_remove_topic_redirect'] = 'Buang DIPINDAHKAN: Topik Peralihan';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Padam notifikasi topik "DIPNDAHKAN:" yang dispesifikasikan apabila notis pemindahan dicipta.';
$txt['scheduled_task_remove_temp_attachments'] = 'Buang Fail Lampiran Sementara';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Padam fail sementara yang dicipta sementara melampirkan fail pada pos yang tidak ditukar nama atau dipadamkan sebelumnya.';
$txt['scheduled_task_remove_old_drafts'] = 'Buang Deraf Lama';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Padamkan deraf lama yang melebihi jumlah hari yang ditetapkan dalam tetap deraf dalam panel pengurusan.';
$txt['scheduled_task_remove_old_followups'] = 'Buang Susulan Lama';
$txt['scheduled_task_desc_remove_old_followups'] = 'Padam entri susulan yang masih wujud dalam database, tetapi merujuk kepada topik yang sudah tiada lagi.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Ambil Emel daripada IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Ambil emel untuk ciri senarai emel daripada petak IMAP dan proses.';
$txt['scheduled_task_user_access_mentions'] = 'Akses Sebutan Ahli';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verifikasi skses pengguna kepada setiap ruangan dan tetapkan akses kepada sebutan yang berkaitan.';

$txt['scheduled_task_reg_starting'] = 'Dimulai pada %1$s';
$txt['scheduled_task_reg_repeating'] = 'berulang setiap %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minit';
$txt['scheduled_task_reg_unit_h'] = 'jam';
$txt['scheduled_task_reg_unit_d'] = 'hari';
$txt['scheduled_task_reg_unit_w'] = 'minggu';

$txt['scheduled_task_edit'] = 'Edit Jadual Tugas';
$txt['scheduled_task_edit_repeat'] = 'Ulang Setiap Tugas';
$txt['scheduled_task_edit_pick_unit'] = 'Unit Pengambilan';
$txt['scheduled_task_edit_interval'] = 'Interval';
$txt['scheduled_task_edit_start_time'] = 'Waktu Mula';
$txt['scheduled_task_edit_start_time_desc'] = 'Waktu Mula dari hari seharusnya dimulai (jam:menit)';
$txt['scheduled_task_time_offset'] = 'Catatan bahwa waktu mula harus jarak terhadap waktu server saat ini. Waktu server saat ini adalah: %1$s';

$txt['scheduled_view_log'] = 'Lihat Log';
$txt['scheduled_log_empty'] = 'Tidak ada entri log tugas untuk saat ini.';
$txt['scheduled_log_time_run'] = 'Jam dijalankan';
$txt['scheduled_log_time_taken'] = 'Jam diperlukan';
$txt['scheduled_log_time_taken_seconds'] = 'saat';
$txt['scheduled_log_completed'] = 'Tugas selesai';
$txt['scheduled_log_empty_log'] = 'Padam semua';
$txt['scheduled_log_empty_log_confirm'] = 'Apakah anda benar2 mahu mengosongkan log?';