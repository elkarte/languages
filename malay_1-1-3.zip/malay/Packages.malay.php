<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Teruskan';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Daftar fail dalam pakej';
$txt['files_archive'] = 'Fail arkib';
$txt['package_browse'] = 'Lihat';
$txt['add_server'] = 'Tambah server';
$txt['server_name'] = 'Nama server';
$txt['serverurl'] = 'URL';
$txt['no_packages'] = 'Belum ada pakej.';
$txt['download'] = 'Muatturun';
$txt['download_success'] = 'Pakej diambil dengan jaya';
$txt['package_downloaded_successfully'] = 'Pakej telah diambil dengan jaya';
$txt['package_manager'] = 'Pengurus Pakej';
$txt['install_mod'] = 'Install Ubahsuai';
$txt['uninstall_mod'] = 'NyahInstall Ubahsuai';
$txt['no_adds_installed'] = 'Tiada addon yang sudah diinstall';
$txt['uninstall'] = 'padam';
$txt['delete_list'] = 'Padam Daftar Ubahsuai';
$txt['package_delete_list_warning'] = 'Apakah anda benar2 mahu memadamkan senarai addon?';

$txt['package_manager_desc'] = 'Dari pengurus pakej anda boleh memuatturun dan menginstall ubahsuai ke forum anda dengan cara mudah menggunakan interface.';
$txt['installed_packages_desc'] = 'Anda boleh menggunakan interface di bawah untuk melihat pakej yang saat ini diinstall pada forum, dan memadam yang tidak anda perlukan lagi.';
$txt['download_packages_desc'] = 'Dari bahagian ini anda boleh memilih untuk memuatturun pakej baru dari server pakej, atau memuatnaik fail pakej terus ke forum.';
$txt['package_servers_desc'] = 'Daripada interface mudah digunakan ini, anda boleh menguruskan server pakej anda dan memuatturun arkib addon  ke forum anda.';
$txt['upload_packages_desc'] = 'Melalui bahagian ini anda boleh memuatnaik fail pakej daripada komputer anda terus ke forum.';

$txt['upload_new_package'] = 'Muatnaik pakej baru';
$txt['view_and_remove'] = 'Lihat dan Padam Pakej Diinstall';
$txt['modification_package'] = 'Pakej Ubahsuai';
$txt['avatar_package'] = 'Pakej Avatar';
$txt['language_package'] = 'Pakej Bahasa';
$txt['unknown_package'] = 'Pakej Tidak Dikenali';
$txt['smiley_package'] = 'Pakej2 mimik';
$txt['use_avatars'] = 'Guna Avatar';
$txt['add_languages'] = 'Tambah Bahasa';
$txt['list_files'] = 'Senarai Fail';
$txt['package_type'] = 'Jenis Pakej';
$txt['extracting'] = 'Menguraikan';
$txt['avatars_extracted'] = 'Avatar telah diuraikan, anda boleh menggunakannya sekarang.';
$txt['language_extracted'] = 'Pakej bahasa telah diuraikan, sekarang anda boleh menggunakannya (dengan menetapkannya dalam tetapan anda).';

$txt['mod_name'] = 'Nama Ubahsuai';
$txt['mod_version'] = 'Versi';
$txt['mod_author'] = 'Pencipta';
$txt['author_website'] = 'Laman Pencipta';
$txt['package_no_description'] = 'Tiada Keterangan';
$txt['package_description'] = 'Keterangan';
$txt['file_location'] = 'Muatturun';
$txt['bug_location'] = 'Pengesan Isu';
$txt['support_location'] = 'Sokongan';
$txt['mod_hooks'] = 'Tiada edit fail';
$txt['mod_date'] = 'Kemaskini terakhir';
$txt['mod_section_count'] = 'Lihat (%1d) addon di bahagian ini';

// Package Server strings
$txt['package_current'] = '(%s <em>Anda ada versi terkini %s</em>)';
$txt['package_update'] = '(%s <em>Kemaskini versi %s anda sudah tersedia</em>)';
$txt['package_installed'] = 'dipasang';
$txt['package_downloaded'] = 'telah dimuatturun';

$txt['package_installed_key'] = 'Ubahsuai diinstall:';
$txt['package_installed_current'] = 'versi semasa';
$txt['package_installed_old'] = 'versi lama';
$txt['package_installed_warning1'] = 'Pakej ini telah diinstall, dan tiada kemaskini yang ditemukan!';
$txt['package_installed_warning2'] = 'Anda harus membatalkan install versi lama dulu untuk mengelak masalah, atau minta pencipta untuk membuat kemaskini dari versi lama anda.';
$txt['package_installed_warning3'] = 'Sila beringat untuk kerap membuat backup untuk direktori sources dan database anda sebelum install ubahsuai, terutama versi beta.';
$txt['package_installed_extract'] = 'Uraikan Pakej';
$txt['package_installed_done'] = 'Pakej diinstall dengan jaya. Anda sekarang boleh menggunakan apapun fungsi yang ia tambah atau ubah; atau tidak boleh menggunakan fungsi yang ia buang.';
$txt['package_installed_redirecting'] = 'Mengalihkan...';
$txt['package_installed_redirect_go_now'] = 'Alihkan Sekarang';
$txt['package_installed_redirect_cancel'] = 'Kembali ke Pengurus Pakej';

$txt['package_upgrade'] = 'Kemaskini';
$txt['package_uninstall_readme'] = 'Nota NyahInstall Nota';
$txt['package_install_readme'] = 'Nota Install';
$txt['package_install_license'] = 'Lesen';
$txt['package_install_type'] = 'Jenis';
$txt['package_install_action'] = 'Tindakan';
$txt['package_install_desc'] = 'Keterangan';
$txt['install_actions'] = 'Tindakan Install';
$txt['perform_actions'] = 'Menginstall pakej ini akan melakukan tindakan berikut:';
$txt['corrupt_compatible'] = 'Pakej yang anda muatturun atau pasang rosak atau tidak sesuai dengan versi ElkArte ini.';
$txt['package_create'] = 'Cipta';
$txt['package_move'] = 'Alih';
$txt['package_delete'] = 'Padam';
$txt['package_extract'] = 'Urai';
$txt['package_file'] = 'Fail';
$txt['package_tree'] = 'Susunan';
$txt['execute_modification'] = 'Jalankan Ubahsuai';
$txt['execute_code'] = 'Jalankan Kod';
$txt['execute_database_changes'] = 'Adaptasi Database';
$txt['execute_hook_add'] = 'Tambah Hook';
$txt['execute_hook_remove'] = 'Buang Hook';
$txt['execute_hook_action'] = 'Sesuaikan hook %1$s';
$txt['package_requires'] = 'Perlukan Modifikasi';
$txt['package_check_for'] = 'Periksa installasi';
$txt['execute_credits_add'] = 'Tambah Kredit';
$txt['execute_credits_action'] = 'Pujian: %1$s';

$txt['package_install_actions'] = 'Tindakan install untuk';
$txt['package_will_fail_title'] = 'Kesilapan dalam Install Pakej';
$txt['package_will_fail_warning'] = 'Sekurang-kurangnya satu kesilapan ditemui semasa ujian install pakej ini.
	Anda <strong>kuat</strong> disarankan untuk tidak melanjutkan dengan install kecuali anda mengetahui apa yang sedang anda lakukan, dan telah membuat backup terbaru.
	Kesilapan ini mungkin berpunca daripada konflik antara pakej yang anda install dan pakej lain yang telah diinstall, kesilapan dalam pakej, pakej yang memerlukan pakej lain yang belum anda install, atau pakej dicipta untuk versi SMF yang lain.';
$txt['package_will_fail_unknown_action'] = 'Pakej cuba melaksanakan tindakan yang tidak diketahui: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Anda yakin untuk meneruskan install ubahsuai ini meskipun tidak akan berjaya?';
$txt['package_will_fail_popup_uninstall'] = 'Anda yakin ingin meneruskan nyahinstall ubahsuai ini, meskipun tidak akan berjaya?';
$txt['package_install'] = 'installasi';
$txt['package_uninstall'] = 'pembuangan';
$txt['package_install_now'] = 'Install Sekarang';
$txt['package_uninstall_now'] = 'Nyahinstall Sekarang';
$txt['package_other_themes'] = 'Install dalam Tema Lain';
$txt['package_other_themes_uninstall'] = 'Nyahinstall pada Tema Lain';
$txt['package_other_themes_desc'] = 'Untuk menggunakan ubahsuai ini dalam tema selain default, pengurus pakej perlu membuat perubahan tambahan ke tema lain. Jika anda ingin install ubahsuai ini dalam tema lain, sila pilih tema di bawah ini.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Setidaknya satu kesilapan ditemui semasa ujian install pada tema ini. Anda yakin ingin cuba install?';

$txt['package_bytes'] = 'byte';

$txt['package_action_missing'] = '<strong class="error">Fail tidak ditemui</strong>';
$txt['package_action_error'] = '<strong class="error">Kesilapan uraian ubahsuai</strong>';
$txt['package_action_failure'] = '<strong class="error">Ujian gagal</strong>';
$txt['package_action_success'] = '<strong>Ujian berjaya</strong>';
$txt['package_action_skipping'] = '<strong>Meninggalkan fail</strong>';

$txt['package_uninstall_actions'] = 'Tindakan Nyahinstall';
$txt['package_uninstall_done'] = 'Pakej telah dinyahinstall, ia tidak lagi memberi kesan.';
$txt['package_uninstall_cannot'] = 'Pakej ini tidak boleh dinyahinstall kerana tiada penyahinstall!<br /><br />Sila hubungi pencipta ubasuai untuk maklumat lanjut.';

$txt['package_install_options'] = 'Pilihan Install';
$txt['package_install_options_desc'] = 'Tetapkan pilihan mengenai cara pengurus pakej menambah addon, termasuklah backup dan akses ftp';
$txt['package_install_options_ftp_why'] = 'Menggunakan fungsi FTP pengurus pakej adalah cara termudah untuk mengelak chmod fail boleh ditulis secara manual melalui FTP anda sendiri agar pengurus pakej boleh bekerja.<br />Di sini anda boleh menetapkan nilai default untuk petak tertentu.';
$txt['package_install_options_ftp_server'] = 'FTP Server';
$txt['package_install_options_ftp_port'] = 'Port';
$txt['package_install_options_ftp_user'] = 'Nama pengguna';
$txt['package_install_options_make_backups'] = 'Buat versi backup dari fail yang diletakkan tanda ombak (~) di akhir namanya.';
$txt['package_install_options_make_full_backups'] = 'Buat satu backup menyeluruh (kecuali mimik, avatar dan lampiran) bagi pemasangan ElkArte.';

$txt['package_ftp_necessary'] = 'Maklumat FTP Diperlukan';
$txt['package_ftp_why'] = 'Fail tertentu yang diperlukan pengurus pakej untuk mengubahsuai tidak boleh ditulis. Ini perlu diubah dengan memasuki ke FTP dan menggunakannya untuk chmod atau cipta fail dan folder.  Maklumat FTP anda mungkin sementara dicache untuk operasi yang sah pada pengurus pakej. Perhatikan bahawa anda juga boleh melakukannya secara manual menggunakan klien FTP - untuk melihat senarai fail yang berkaitan sila klik <a href="#" onclick="%1$s">di sini</a>.';
$txt['package_ftp_why_file_list'] = 'Fail berikut perlu dijadikan boleh ditulis untuk meneruskan install:';
$txt['package_ftp_why_download'] = 'Untuk memuatturun pakej, direktori Packages dan fail di dalamnya perlu boleh ditulis - tetapi tidak buat masa ini.  Pengurus pakej boleh menggunakan maklumat FTP anda untuk membetulkan ini.';
$txt['package_ftp_server'] = 'FTP Server';
$txt['package_ftp_port'] = 'Port';
$txt['package_ftp_username'] = 'Nama pengguna';
$txt['package_ftp_password'] = 'Kata Kunci';
$txt['package_ftp_path'] = 'Laluan dalaman ke ElkArte';
$txt['package_ftp_test'] = 'Uji';
$txt['package_ftp_test_connection'] = 'Uji Sambungan';
$txt['package_ftp_test_success'] = 'Sambungan FTP berjaya.';
$txt['package_ftp_test_failed'] = 'Tidak boleh menghubungi server.';
$txt['package_ftp_bad_server'] = 'Tidak boleh menghubungi server.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Pakej yang akan anda padam ketika ini sedang diinstall!  Jika anda memadamnya, anda tidak boleh menyahinstall kemudian.\\n\\nAnda yakin?';

$txt['package_examine_file'] = 'Lihat fail dalam pakej';
$txt['package_file_contents'] = 'Isi fail';

$txt['package_upload_title'] = 'Muatnaik Pakej';
$txt['package_upload_select'] = 'Pakej Untuk Muatnaik';
$txt['package_upload'] = 'Muatnaik';
$txt['package_uploaded_success'] = 'Pakej dimuatnaik dengan jaya';
$txt['package_uploaded_successfully'] = 'Pakej telah dimuatnaik dengan jaya';

$txt['package_modification_malformed'] = 'Fail ubahsuai rosak atau tidak sah.';
$txt['package_modification_missing'] = 'Fail tidak boleh ditemui.';
$txt['package_no_zlib'] = 'Maaf, tetapan PHP anda tidak menyokong <strong>zlib</strong>.  Tanpanya, pengurus pakej tidak boleh berfungsi.  Sila hubungi host anda mengenai ini untuk maklumat lanjut';

$txt['package_cleanperms_title'] = 'Keizinan Pembersihan';
$txt['package_cleanperms_desc'] = 'Interface ini mengizinkan anda untuk menetapkan semula keizinan fail melalui install anda, untuk meningkatkan sekuriti atau menyelesaikan masalah sebarang keizinan yang mungkin anda temui ketika menginstall pakej.';
$txt['package_cleanperms_type'] = 'Ubah semua keizinan fail seluruh forum iaitu';
$txt['package_cleanperms_standard'] = 'Hanya fail default boleh ditulis.';
$txt['package_cleanperms_free'] = 'Semua fail boleh ditulis.';
$txt['package_cleanperms_restrictive'] = 'Fail minima boleh ditulis.';
$txt['package_cleanperms_go'] = 'Ubah keizinan fail';

$txt['package_download_by_url'] = 'Ambil pakej dengan url';
$txt['package_download_filename'] = 'Nama fail';
$txt['package_download_filename_info'] = 'Nilai pilihan.  Harus dipakai ketika url tidak diakhiri dengan nama fail.  Sebagai contoh: index.php?mod=5';

$txt['package_db_uninstall'] = 'Padam semua data berkaitan dengan ubahsuai ini.';
$txt['package_db_uninstall_details'] = 'Lengkap';
$txt['package_db_uninstall_actions'] = 'Menanda pilihan ini akan menghasilkan perubahan database berikut';
$txt['package_db_remove_table'] = 'Buang table &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Padam ruang &quot;%1$s&quot; dari &quot;%2$s&quot;';
$txt['package_db_remove_index'] = 'Padam indeks &quot;%1$s&quot; dari &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Install Menyerupai:';
$txt['package_emulate_uninstall'] = 'Uninstall Menyerupai:';

// Operations.
$txt['operation_find'] = 'Cari';
$txt['operation_replace'] = 'Ganti';
$txt['operation_after'] = 'Tambah Setelah';
$txt['operation_before'] = 'Tambah Sebelum';
$txt['operation_title'] = 'Operasi';
$txt['operation_ignore'] = 'Abaikan Kesilapan';
$txt['operation_invalid'] = 'Operasi yang anda pilih tidak sah.';

$txt['package_file_perms_desc'] = 'Anda boleh menggunakan bahagian ini untuk menyemak status fail-fail atau folder kritikal yang boleh ditulis dalam direktori forum anda. Perhatikan ini hanya mempertimbangkan folder dan fail utama forum - gunakan klien FTP untuk pilihan tambahan.';
$txt['package_file_perms_name'] = 'Nama Fail/Folder';
$txt['package_file_perms_status'] = 'Status Sekarang';
$txt['package_file_perms_new_status'] = 'Status Baru';
$txt['package_file_perms_status_read'] = 'Baca';
$txt['package_file_perms_status_write'] = 'Tulis';
$txt['package_file_perms_status_execute'] = 'Jalankan';
$txt['package_file_perms_status_custom'] = 'Pilihan';
$txt['package_file_perms_status_no_change'] = 'Tidak Berubah';
$txt['package_file_perms_writable'] = 'Dapat ditulis';
$txt['package_file_perms_not_writable'] = 'Tidak Boleh Ditulis';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Fail Selanjutnya';

$txt['package_file_perms_change'] = 'Ubah Keizinan Fail';
$txt['package_file_perms_predefined'] = 'Gunakan profil keizinan default';
$txt['package_file_perms_predefined_note'] = 'Perhatikan bahawa ini memakai profil default untuk fail dan folder utama.';
$txt['package_file_perms_apply'] = 'Terapkan tetapan keizinan fail individual yang dipilih di atas.';
$txt['package_file_perms_custom'] = 'Jika &quot;Pilihan&quot; telah dipilih, gunakan nilai chmod';
$txt['package_file_perms_pre_restricted'] = 'Terbatas - minima fail boleh ditulis';
$txt['package_file_perms_pre_standard'] = 'Default - fail utama boleh ditulis';
$txt['package_file_perms_pre_free'] = 'Bebas - semua fail boleh ditulis';
$txt['package_file_perms_ftp_details'] = 'Pada kebanyakan server, untuk mengubah keizinan fail hanya boleh menggunakan akaun FTP. Sila masukkan butiran FTP anda di bawah';
$txt['package_file_perms_ftp_retain'] = 'Perhatian, sistem akan hanya menyimpan info kata kunci untuk sementara dalam membantu operasi pengurus pakej.';
$txt['package_file_perms_go'] = 'Buat Perubahan';

$txt['package_file_perms_applying'] = 'Menerapkan Perubahan';
$txt['package_file_perms_items_done'] = '%1$d dari %2$d item selesai';
$txt['package_file_perms_skipping_ftp'] = '<strong>Amaran:</strong> Gagal menyambung ke server FTP, cuba tanpa mengubah keizinan. Ini <em>berkemungkinan</em> gagal - sila periksa hasil bila selesai dan cuba lagi dengan butiran FTP yang betul jika diperlukan.';

$txt['package_file_perms_dirs_done'] = '%1$d dari %2$d direktori selesai';
$txt['package_file_perms_files_done'] = '%1$d dari %2$d fail selesai dalam direktori semasa';

$txt['chmod_value_invalid'] = 'Anda telah cuba untuk memasukkan nilai chmod yang salah. Chmod mesti sekitar 0444 dan 0777';

$txt['package_restore_permissions'] = 'Kembalikan Keizinan Fail';
$txt['package_restore_permissions_desc'] = 'Keizinan fail berikut telah diubah untuk memasang pakej yang dipilih. Anda boleh mengembalikan fail ini ke status asal dengan menekan &quot;Pulihkan&quot; di bawah.';
$txt['package_restore_permissions_restore'] = 'Kembalikan';
$txt['package_restore_permissions_filename'] = 'Nama fail';
$txt['package_restore_permissions_orig_status'] = 'Status Awal';
$txt['package_restore_permissions_cur_status'] = 'Status Sekarang';
$txt['package_restore_permissions_result'] = 'Hasil';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - sebelumnya %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Ditinggalkan</em>';
$txt['package_restore_permissions_action_success'] = '<span style="color: green;">Berjaya</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Gagal</span>';
$txt['package_restore_permissions_action_done'] = 'SMF telah cuba mengembalikan fail-fail yang dipilih kembali ke keizinan awal, hasilnya boleh dilihat di bawah. Jika perubahan gagal, atau untuk lebih paparan lengkapnya atas keizinan fail, sila lihat bahagian <a href="%1$s">Keizinan Fail</a>.';

$txt['package_file_perms_warning'] = 'Ambil Perhatian';
$txt['package_file_perms_warning_desc'] = '	<li>Berhati-hati ketika mengubah keizinan fail dari bahagian ini - keizinan yang salah boleh mempengaruhi operasi forum anda!</li>
	<li>Pada beberapa tetapan server memilih keizinan yang salah boleh menghentikan SMF daripada beroperasi.</li>
	<li>Direktori tertentu seperti <em>lampiran</em> perlu boleh ditulis agar boleh menggunakan fungsinya.</li>
	<li>Fungsi ini berlaku terutamanya pada server berasaskan bukan Windows - ia tidak akan bekerja pada Windows berkaitan bendera keizinan.</li>
	<li>Sebelum meneruskan, pastikan anda memiliki klien FTP diinstall seandainya anda membuat kesilapan dan perlu untuk FTP ke server bagi memperbaikinya.</li>';

$txt['package_confirm_view_package_content'] = 'Anda yakin ingin menyemak isi pakej dari lokasi ini:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Teruskan';
$txt['package_confirm_go_back'] = 'Kembali';

$txt['package_readme_default'] = 'Default';
$txt['package_available_readme_language'] = 'Bahasa Nota Tersedia:';
$txt['package_license_default'] = 'Default';
$txt['package_available_license_language'] = 'Lesen Bahasa Yang Ada:';