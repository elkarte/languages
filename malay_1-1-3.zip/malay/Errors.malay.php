<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Maaf, anda tidak dibenarkan untuk mengakses bahagian ini. Kami juga tidak dapat mengesahkan samada ia wujud. Anda dialu2kan untuk ke laman utama dan memilih jalan baru anda di sana.';
$txt['not_guests'] = 'Maaf, tindakan ini tidak disediakan buat tetamu.';

$txt['mods_only'] = 'Hanya penyelia yang boleh menggunakan fungsi buang terus, sila padam mesej ini melalui ciri ubah.';
$txt['no_name'] = 'Anda tidak mengisi petak nama. Kami tidak dapat membenarkan anda teruskan tanpa nama, maaf.';
$txt['no_email'] = 'Anda tidak mengisi petak email. Kami tidak dapat membenarkan anda teruskan tanpa emel, maaf.';
$txt['topic_locked'] = 'Topik ini dikunci, anda tidak dibenarkan untuk mengepos atau mengubah mesej...';
$txt['no_password'] = 'Petak kata kunci kosong';
$txt['passwords_dont_match'] = 'Kata kunci tidak padan.';
$txt['register_to_use'] = 'Maaf, anda harus mendaftar sebelum menggunakan ciri ini.';
$txt['username_reserved'] = 'Nama pengguna yang anda pakai berisi nama simpanan \'%1$s\'. Sila cuba dengan nama pengguna lain.';
$txt['numbers_one_to_nine'] = 'Petak ini hanya menerima angka dari 0-9';
$txt['not_a_user'] = 'Pengguna yang profilnya anda cuba lihat tidak wujud.';
$txt['not_a_topic'] = 'Topik ini tidak wujud dalam ruangan ini.';
$txt['not_approved_topic'] = 'Topik ini belum diluluskan lagi.';
$txt['email_in_use'] = 'Alamat emel (%1$s) sudah digunakan oleh ahli berdaftar. Jika ini adalah satu kesilapan, pergi ke laman masuk dan gunakan pengingat kata laluan dengan alamat emel tersebut.';

$txt['didnt_select_vote'] = 'Anda tidak memilih pilihan undian.';
$txt['poll_error'] = 'Maaf, ada kesalahan berlaku: sama ada undian itu tidak wujud, sudah dikunci, atau anda cuba mengundi dua kali.';
$txt['locked_by_admin'] = 'Ini sudah dikunci oleh pengurus.  Anda tidak boleh membukanya.';
$txt['not_enough_posts_karma'] = 'Maaf, jumlah pos anda tidak mencukupi bagi mengubah karma - anda memerlukan setidaknya %1$d.';
$txt['cant_change_own_karma'] = 'Maaf, anda tidak dibenarkan untuk mengubah karma sendiri.';
$txt['karma_wait_time'] = 'Maaf, anda tidak boleh mengubah karma tanpa menunggu %1$s %2$s.';
$txt['feature_disabled'] = 'Maaf, ciri ini dimatikan.';
$txt['feature_no_exists'] = 'Maaf, ciri ini tidak wujud.';
$txt['couldnt_connect'] = 'Tidak boleh menyambung ke server atau tidak jumpa fail';
$txt['no_board'] = 'Ruangan yang anda namakan tidak wujud';
$txt['no_message'] = 'Mesej tersebut sudah tiada tiada.';
$txt['no_topic_id'] = 'Anda menetapkan ID topik yang tidak sah.';
$txt['split_first_post'] = 'Anda tidak boleh memisahkan topik di pos pertama.';
$txt['topic_one_post'] = 'Topik ini hanya berisi satu mesej dan tidak boleh dipisahkan.';
$txt['no_posts_selected'] = 'Tiada mesej yang dipilih';
$txt['selected_all_posts'] = 'Tidak boleh dipisahkan. Anda telah memilih semua mesej.';
$txt['cant_find_messages'] = 'Mesej tidak ditemui';
$txt['cant_find_user_email'] = 'Alamat emel pengguna tidak ditemui.';
$txt['cant_insert_topic'] = 'Tidak boleh menyisipkan topik';
$txt['session_timeout'] = 'Waktu sesi anda berakhir ketika mengepos. Sila kembali dan cuba lagi.';
$txt['session_timeout_file_upload'] = 'Sesi anda kehabisan masa semasa memuatnaik fail. Sila cuba lagi.';
$txt['no_files_uploaded'] = 'Tiada sebarang fail untuk dimuatnaik.';
$txt['session_verify_fail'] = 'Pengesahan sesi gagal. Sila keluar dan masuk semula, kemudian cuba lagi.';
$txt['verify_url_fail'] = 'Tidak dapat mengesahkan URL rujukan: %1$s. Sila kembali dan cuba semula.';
$txt['token_verify_fail'] = 'Token gagal disahkan. Sila kembali dan cuba lagi.';
$txt['guest_vote_disabled'] = 'Tetamu tidak boleh memilih dalam undian ini.';

$txt['cannot_access_mod_center'] = 'Anda tiada keizinan untuk mengakses pusat seliaan.';
$txt['cannot_admin_forum'] = 'Anda tidak dizinkan untuk menguruskan forum ini.';
$txt['cannot_announce_topic'] = 'Anda tidak dibenarkan untuk mengumumkan topik di ruangan ini.';
$txt['cannot_approve_posts'] = 'Anda tiada keizinan untuk meluluskan pos.';
$txt['cannot_post_unapproved_attachments'] = 'Anda tiada keizinan untuk mengepos lampiran yang belum diluluskan.';
$txt['cannot_post_unapproved_topics'] = 'Anda tiada keizinan untuk mengepos topik yang belum diluluskan.';
$txt['cannot_post_unapproved_replies_own'] = 'Anda tiada keizinan untuk mengepos jawapan yang belum diluluskan ke topik anda.';
$txt['cannot_post_unapproved_replies_any'] = 'Anda tiada keizinan untuk mengepos sebarang jawapan yang belum diluluskan ke topik pengguna lain.';
$txt['cannot_calendar_edit_any'] = 'Anda tidak boleh mengedit sebarang acara kalendar.';
$txt['cannot_calendar_edit_own'] = 'Anda tiada izin yang diperlukan untuk mengedit acara anda sendiri.';
$txt['cannot_calendar_post'] = 'Penulisan acara tidak dibenarkan - maaf.';
$txt['cannot_calendar_view'] = 'Maaf, tapi anda tidak dibenarkan untuk melihat kalendar.';
$txt['cannot_remove_any'] = 'Maaf, tapi anda tidak mempunyai keizinan untuk membuang sebarang topik. Sila pastikan sama ada topik ini sudah dipindahkan ke ruangan lain.';
$txt['cannot_remove_own'] = 'Anda tidak boleh memadam topik anda sendiri dalam ruangan ini. Sila pastikan sama ada topik ini sudah dipindahkan ke ruangan lain.';
$txt['cannot_edit_news'] = 'Anda tidak dibenarkan untuk mengedit item berita pada forum ini.';
$txt['cannot_pm_read'] = 'Maaf, anda tidak boleh membaca mesej peribadi anda.';
$txt['cannot_pm_send'] = 'Anda tidak dibenarkan untuk mengirimkan mesej peribadi.';
$txt['cannot_karma_edit'] = 'Anda tidak dibenarkan untuk mengubah karma orang lain.';
$txt['cannot_like_posts'] = 'Anda tidak dibenarkan untuk menyukai mesej2 dalam ruangan ini.';
$txt['cannot_lock_any'] = 'Anda tidak dibenarkan untuk mengunci sebarang topik di sini.';
$txt['cannot_lock_own'] = 'Mohon maaf, tapi anda tidak boleh mengunci topik anda sendiri di sini.';
$txt['cannot_make_sticky'] = 'Anda tiada keizinan untuk melekitkan topik ini.';
$txt['cannot_manage_attachments'] = 'Anda tidak diizinkan untuk menguruskan lampiran atau avatar.';
$txt['cannot_manage_bans'] = 'Anda tidak diizinkan untuk mengubah daftar sekatan.';
$txt['cannot_manage_boards'] = 'Anda tidak diizinkan untuk menguruskan ruangan dan kategori.';
$txt['cannot_manage_membergroups'] = 'Anda tiada keizinan untuk mengubah atau menempatkan grup ahli.';
$txt['cannot_manage_permissions'] = 'Anda tiada keizinan untuk mengatur keizinan.';
$txt['cannot_manage_smileys'] = 'Anda tidak dibenarkan untuk mengatur mimik dan ikon mesej.';
$txt['cannot_mark_any_notify'] = 'Anda tiada keizinan untuk mendapatkan sebarang makluman dari topik ini.';
$txt['cannot_mark_notify'] = 'Maaf, anda tidak dibenarkan untuk memohon makluman daripada ruangan ini.';
$txt['cannot_merge_any'] = 'Anda tidak dibenarkan untuk menggabungkan topik pada salah satu ruangan yang dipilih.';
$txt['cannot_moderate_forum'] = 'Anda tidak dibenarkan untuk menyelia forum ini.';
$txt['cannot_moderate_board'] = 'Anda tidak dibenarkan menyelia ruangan ini.';
$txt['cannot_modify_any'] = 'Anda tidak dibenarkan untuk mengubah sebarang pos.';
$txt['cannot_modify_own'] = 'Maaf, tapi anda tidak dibenarkan untuk mengedit pos anda sendiri.';
$txt['cannot_modify_replies'] = 'Meskipun pos ini adalah jawapan ke topik anda, anda tidak boleh mengeditnya.';
$txt['cannot_move_own'] = 'Anda tidak dibenarkan untuk memindahkan topik anda sendiri dalam ruangan ini.';
$txt['cannot_move_any'] = 'Anda tidak dibenarkan untuk memindahkan sebarang topik dalam ruangan ini.';
$txt['cannot_poll_add_own'] = 'Maaf, anda tidak dibenarkan untuk menambahkan undian ke topik anda sendiri dalam ruangan ini.';
$txt['cannot_poll_add_any'] = 'Anda tiada akses untuk menambah sebarang undian ke topik ini.';
$txt['cannot_poll_edit_own'] = 'Anda tidak boleh mengedit undian ini, meskipun ini milik anda sendiri.';
$txt['cannot_poll_edit_any'] = 'Akses anda sudah dibatalkan untuk mengedit sebarang undian dalam ruangan ini.';
$txt['cannot_poll_lock_own'] = 'Anda tidak dibenarkan untuk mengunci undian anda sendiri dalam ruangan ini.';
$txt['cannot_poll_lock_any'] = 'Maaf, tapi anda tidak dibenarkan untuk mengunci sebarang undian.';
$txt['cannot_poll_post'] = 'Anda tidak dibenarkan untuk mengepos sebarang undian dalam ruangan ini.';
$txt['cannot_poll_remove_own'] = 'Anda tidak dibenarkan untuk memadam undian ini dari topik anda.';
$txt['cannot_poll_remove_any'] = 'Anda tidak boleh membuang sebarang undian pada ruangan ini.';
$txt['cannot_poll_view'] = 'Anda tidak dibenarkan untuk melihat undian dalam ruangan ini.';
$txt['cannot_poll_vote'] = 'Maaf, anda tidak boleh mengundi dalam sebarang undian dalam ruangan ini.';
$txt['cannot_post_attachment'] = 'Anda tiada keizinan untuk mengepos lampiran di sini.';
$txt['cannot_post_new'] = 'Maaf, anda tidak boleh mengepos sebarnag topik baru dalam ruangan ini.';
$txt['cannot_post_new_board'] = 'Maaf, anda tidak boleh mengepos tajuk baru dalam ruangan %1$s ini.';
$txt['cannot_post_reply_any'] = 'Anda tidak dibenarkan untuk mengepos jawapan untuk sebarang topik pada ruangan ini.';
$txt['cannot_post_reply_own'] = 'Anda tidak dibenarkan untuk mengepos jawapan walaupun ke topik anda sendiri dalam ruangan ini.';
$txt['cannot_profile_remove_own'] = 'Maaf, tapi anda tidak dibenarkan untuk memadam akaun anda sendiri.';
$txt['cannot_profile_remove_any'] = 'Anda tiada keizinan untuk memadam sebarang akaun orang lain!';
$txt['cannot_profile_extra_any'] = 'Anda tidak dibenarkan untuk mengubah aturan profil.';
$txt['cannot_profile_identity_any'] = 'Anda tidak dibenarkan untuk mengedit sebarang aturan akaun.';
$txt['cannot_profile_title_any'] = 'Anda tidak boleh mengedit sebarang tajuk pilihan orang.';
$txt['cannot_profile_extra_own'] = 'Maaf, tapi anda tiada keizinan yang cukup untuk mengedit data profil anda.';
$txt['cannot_profile_identity_own'] = 'Anda tidak boleh mengubah identiti anda buat masa ini.';
$txt['cannot_profile_title_own'] = 'Anda tidak dibenarkan untuk mengubah tajuk pilihan anda.';
$txt['cannot_profile_set_avatar'] = 'Anda tidak dibenarkan untuk menukar avatar anda.';
$txt['cannot_profile_view_own'] = 'Mohon maaf, tapi anda tidak boleh melihat profil anda sendiri.';
$txt['cannot_profile_view_any'] = 'Mohon maaf, tapi anda tidak boleh melihat sebarang profil.';
$txt['cannot_delete_own'] = 'Oops, maaf, anda tidak boleh memadam pos anda sendiri dalam ruangan ini.';
$txt['cannot_delete_replies'] = 'Maaf, tapi anda tidak boleh memadam pos ini meskipun mereka menjawab ke topik anda sendiri.';
$txt['cannot_delete_any'] = 'Oops, maaf, anda tidak boleh memadam sebarang pos dalam ruangan ini.';
$txt['cannot_report_any'] = 'Anda tidak dibenarkan untuk melaporkan sebarang pos dalam ruangan ini.';
$txt['cannot_search_posts'] = 'Anda tidak dibenarkan untuk mencari pos dalam forum ini.';
$txt['cannot_send_mail'] = 'Anda tiada hak untuk mengirimkan email ke setiap orang.';
$txt['cannot_issue_warning'] = 'Maaf, anda tiada keizinan untuk menerbitkan peringatan untuk ahli.';
$txt['cannot_send_topic'] = 'Maaf, tapi pengurus sudah tidak mengizinkan kiriman topik pada ruangan ini.';
$txt['cannot_send_email_to_members'] = 'Maaf, tetapi pengurus tidak membenarkan penghantaran emel pada ruangan ini.';
$txt['cannot_split_any'] = 'Memisahkan sebarang topik tidak dibenarkan dalam ruangan ini.';
$txt['cannot_view_attachments'] = 'Nampaknya anda tidak dibenarkan untuk memuatturun atau melihat lampiran pada ruangan ini.';
$txt['cannot_view_mlist'] = 'Anda tidak boleh melihat daftar ahli karena anda tiada keizinan.';
$txt['cannot_view_stats'] = 'Anda tidak dibenarkan untuk melihat statistik forum.';
$txt['cannot_who_view'] = 'Maaf - anda tiada keizinan yang sah untuk melihat daftar Siapa Online.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = 'Tema itu tiada.';
$txt['theme_dir_wrong'] = 'Direktori tema default salah, sila betulkan dengan mengklik teks ini.';
$txt['registration_disabled'] = 'Maaf, pendaftaran ketika ini dimatikan.';
$txt['registration_agreement_missing'] = 'Fail perjanjian pendaftaran, perjanjian.txt, mungkin telah hilang atau memang kosong. Pendaftaran akan dimatikan sehingga ia dibaiki.';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Maaf, tiada pertanyaan rahsia yang diatur untuk ahli ini.';
$txt['poll_range_error'] = 'Maaf, undian harus dijalankan lebih dari 0 hari.';
$txt['delFirstPost'] = 'Anda tidak dibenarkan untuk memadam pos pertama dalam sebuah topik.<p>Jika anda ingin memadam topik ini, klik pada pautan padam topik atau minta penyelia/pengurus melakukannya untuk anda.</p>';
$txt['login_cookie_error'] = 'Anda tidak boleh masuk. Sila periksa aturan cookie anda.';
$txt['incorrect_answer'] = 'Maaf, tapi anda tidak menjawab pertanyaan anda dengan betul. Sila klik kembali untuk cuba lagi, atau klik kembali dua kali untuk menggunakan cara default mendapatkan kata kunci anda.';
$txt['no_mods'] = 'Penyelia tidak ditemui!';
$txt['parent_not_found'] = 'Struktur ruangan rosak: tidak dapat menemui ruangan induknya';
$txt['modify_post_time_passed'] = 'Anda tidak boleh mengubah pos ini kerana had waktu mengedit sudah berakhir.';

$txt['calendar_off'] = 'Anda tidak boleh mengakses kalendar sekarang kerana ia dimatikan.';
$txt['calendar_export_off'] = 'Anda tidak boleh mengekspot acara kalendar sebab ciri ini dimatikan.';
$txt['invalid_month'] = 'Nilai bulan tidak sah.';
$txt['invalid_year'] = 'Nilai tahun tidak sah.';
$txt['invalid_day'] = 'Nilai tarikh tidak sah.';
$txt['event_month_missing'] = 'Bulan acara tiada.';
$txt['event_year_missing'] = 'Tahun acara tiada.';
$txt['event_day_missing'] = 'Tarikh acara tiada.';
$txt['event_title_missing'] = 'Tajuk acara tiada.';
$txt['invalid_date'] = 'Tarikh tidak sah.';
$txt['no_event_title'] = 'Tiada tajuk acara dimasukkan.';
$txt['missing_board_id'] = 'ID ruangan tiada.';
$txt['missing_topic_id'] = 'ID topik hilang.';
$txt['topic_doesnt_exist'] = 'Topik tidak wujud.';
$txt['not_your_topic'] = 'Anda bukan pemilik topik ini.';
$txt['board_doesnt_exist'] = 'Ruangan tidak wujud.';
$txt['no_span'] = 'Ciri lanjutan masa telah dimatikan.';
$txt['invalid_days_numb'] = 'Jumlah hari  untuk lanjutan masa tidak sah.';

$txt['moveto_noboards'] = 'Tiada ruangan untuk memindahkan topik ini!';
$txt['topic_already_moved'] = 'Topik %1$s ini telah dialihkan ke ruangan %2$s, sila semak lokasi barunya sebelum mengalihkannya lagi.';

$txt['already_activated'] = 'Akaun anda sudah diaktifkan.';
$txt['still_awaiting_approval'] = 'Akaun anda menunggu kelulusan.';

$txt['invalid_email'] = 'Alamat email / jangkauan alamat email tidak sah.<br />Contoh alamat email yang sah: evil.user@badsite.com.<br />Contoh jangkauan alamat email yang sah: *@*.badsite.com';
$txt['invalid_expiration_date'] = 'Tarikh luput tidak sah';
$txt['invalid_hostname'] = 'Nama host / jangkauan nama host tidak sah.<br />Contoh nama host yang sah: proxy4.badhost.com<br />Contoh jangkauan nama host yang sah: *.badhost.com';
$txt['invalid_ip'] = 'IP / jangkauan IP tidak sah.<br />Contoh alamat IP yang sah: 127.0.0.1<br />Contoh jangkauan IP yang sah: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'IP / jangkauan IP tidak sah.<br />Contoh alamat IP yang sah: 127.0.0.1<br />Contoh jangkauan IP yang sah: 127.0.0-20.*';
$txt['invalid_username'] = 'Nama ahli tidak ditemui';
$txt['no_user_selected'] = 'Ahli tidak ditemui';
$txt['no_ban_admin'] = 'Anda tidak boleh menyekat seorang pengurus - anda harus menurunkan kuasanya terlebih dahulu!';
$txt['no_bantype_selected'] = 'Tiada jenis sekatan yang dipilih';
$txt['ban_not_found'] = 'Sekatan tidak ditemui';
$txt['ban_unknown_restriction_type'] = 'Jenis pembatasan tidak diketahui';
$txt['ban_name_empty'] = 'Nama sekatan dibiarkan kosong';
$txt['ban_id_empty'] = 'Aduh, maaf. Kami cuba mengesan ID sekatan, tetapi tidak ditemui.';
$txt['ban_group_id_empty'] = 'Grup yang disekat perlu satu grup ID, tetapi grup ini tiada.';
$txt['ban_no_triggers'] = 'Apakah anda terlupa untuk memilih pemicu sekatan? Kita perlukan sekurang2nya satu, tetapi kita masih belum ada apa2 lagi.';
$txt['ban_ban_item_empty'] = 'Pemicu sekatan tidak ditemui.';
$txt['impossible_insert_new_bangroup'] = 'Kesalahan berlaku semasa memasukkan sekatan baru';

$txt['like_heading_error'] = 'Kesalahan dalam Suka';
$txt['like_wait_time'] = 'Maaf, anda tidak boleh memilih suka tanpa menunggu %1$s %2$s.';
$txt['like_unlike_error'] = 'Oops, ada kesalahan semasa suka/tidak suka pos ini.';
$txt['cant_like_yourself'] = 'Suka pos sendiri ... seumpama ketawa kerana lawak jenaka sendiri apabila tiada orang lain bersama ... ketawa ... Eh? Saya sedang ketawa seorang diri kah?';

$txt['ban_name_exists'] = 'Nama sekatan ini (%1$s) sudah ada. Sila pilih satu nama lain.';
$txt['ban_trigger_already_exists'] = 'Pemicu sekatan ini (%1$s) telah ada dalam %2$s';
$txt['attach_check_nag'] = 'Tidak dapat teruskan kerana data (%1$s) tidak lengkap.';

$txt['recycle_no_valid_board'] = 'Tiada ruangan yang sah dipilih bagi topik2 kitar semula';
$txt['post_already_deleted'] = 'Topik atau mesej telah dialihkan ke ruangan kitar semula. Apakah anda pasti untuk memadamkannya sepenuhnya?<br />Jika benar2 pasti ikuti <a href="%1$s">pautan ini</a>';

$txt['login_threshold_fail'] = 'Maaf, anda kehabisan peluang login masuk. Sila kembali dan cuba lagi kemudian.';
$txt['login_threshold_brute_fail'] = 'Maaf, anda telah mencapai had maksima cubaan login masuk. Sila tunggu 30 saat dan cuba lagi.';

$txt['who_off'] = 'Kami suka membiarkan anda mengintai Siapa Online, tetapi malangnya ia sudah dimatikan.';

$txt['merge_create_topic_failed'] = 'Aduh, maaf. Penciptaan topik baru telah gagal.';
$txt['merge_need_more_topics'] = 'Menggabung topik memerlukan setidak-tidaknya dua topik untuk digabung. Sila cuba lagi.';

$txt['post_WaitTime_broken'] = 'Pos terakhir daripada IP anda adalah kurang daripada %1$d saat. Sila cuba semula kemudian.';
$txt['register_WaitTime_broken'] = 'Anda baru sahaja mendaftar beberapa %1$d saat yang lalu!';
$txt['login_WaitTime_broken'] = 'Anda perlu menunggu %1$d saat lagi untuk log masuk, maaf.';
$txt['pm_WaitTime_broken'] = 'Mesej terakhir daripada IP anda adalah kurang daripada %1$d saat. Sila cuba semula kemudian.';
$txt['reporttm_WaitTime_broken'] = 'Topik terakhir daripada IP anda adalah kurang daripada %1$d saat. Sila cuba semula kemudian.';
$txt['sendtopic_WaitTime_broken'] = 'Topik terakhir dihantar daripada IP anda adalah kurang daripada %1$d saat. Sila cuba semula kemudian.';
$txt['sendmail_WaitTime_broken'] = 'Emel terakhir dihantar daripada IP anda adalah kurang daripada %1$d saat. Sila cuba semula kemudian.';
$txt['search_WaitTime_broken'] = 'Carian terakhir anda adalah kurang daripada %1$d saat. Sila cuba semula kemudian.';
$txt['remind_WaitTime_broken'] = 'Peringatan terakhir anda adalah kurang daripada %1$d saat. Sila cuba semula kemudian.';
$txt['contact_WaitTime_broken'] = 'Kali terakhir anda menggunakan borang hubungan adalah kurang daripada %1$d saat. Sila cuba semula kemudian.';

$txt['topic_gone'] = 'Kami telah cuba dengan bersungguh2 bagi mengesan topik atau papan yang anda cari, tetapi ia tidak ditemui. Ia mungkin seudah tiada atau diluar had keizinan anda.';
$txt['theme_edit_missing'] = 'Kami telah mencuba mencari fail yang anda cuba edit, tetapi ia tidak dapat ditemui!';

$txt['no_dump_database'] = 'Maaf, hanya pengurus boleh membuat backup database!';
$txt['pm_not_yours'] = 'Mesej peribadi yang cuba anda ungkapkan bukan milik anda sendiri atau tidak wujud, sila kembali dan cuba lagi.';
$txt['mangled_post'] = 'Bentuk data kosong - sila kembali dan cuba lagi.';
$txt['too_many_groups'] = 'Maaf, anda memilih terlalu banyak grup, sila buang sebahagiannya.';
$txt['post_upload_error'] = 'Data pos tiada. Kesalahan ini boleh jadi disebabkan percubaan menghantar fail yang lebih besar daripada yang dibenarkan oleh server. Sila hubungi pengurus jika masalah ini berterusan.';
$txt['quoted_post_deleted'] = 'Pos yang cuba anda ungkapkan tidak wujud, dipadam, atau tidak lagi boleh dilihat oleh anda.';
$txt['pm_too_many_per_hour'] = 'Anda telah melebihi had %1$d mesej peribadi bagi satu jam.';
$txt['labels_too_many'] = 'Maaf, %1$s mesej sudah memiliki jumlah label maksima yang dibenarkan!';

$txt['register_only_once'] = 'Maaf, tapi anda tidak dibenarkan untuk mendaftarkan terlalu banyak akaun pada masa dan komputer yang sama.';
$txt['admin_setting_coppa_require_contact'] = 'Anda harus memasukkan alamat pos atau fax jika persetujuan ibubapa/penjaga diperlukan.';

$txt['error_long_name'] = 'Nama yang anda cuba pakai terlalu panjang.';
$txt['error_no_name'] = 'Tiada nama diberikan.';
$txt['error_bad_name'] = 'Nama yang anda masukkan tidak boleh dipakai karena berisi nama-nama terpelihara.';
$txt['error_no_email'] = 'Tiada alamat email diberikan.';
$txt['error_bad_email'] = 'Alamat email yang diberikan tidak sah.';
$txt['error_email'] = 'alamat emel';
$txt['error_message'] = 'mesej';
$txt['error_no_event'] = 'Tiada nama acara diberikan.';
$txt['error_no_subject'] = 'Tiada subjek diisi.';
$txt['error_no_question'] = 'Tiada pertanyaan diisi untuk undian ini.';
$txt['error_no_message'] = 'Badan mesej telah dibiarkan kosong.';
$txt['error_long_message'] = 'Mesej melebihi panjang maksima yang diperbolehkan (%1$d aksara).';
$txt['error_no_comment'] = 'Petak ulasan telah dibiarkan kosong.';
$txt['error_post_too_long'] = 'Mesej anda terlalu panjang. Sila gunakan maksima 255 aksara sahaja.';
$txt['error_session_timeout'] = 'Sesi anda tamat semasa mengepos. Sila cuba mengirim semula mesej anda.';
$txt['error_no_to'] = 'Tiada penerima ditetapkan.';
$txt['error_bad_to'] = 'Satu atau lebih \'kepada\'-penerima tidak ditemui.';
$txt['error_bad_bcc'] = 'Satu atau lebih \'bcc\'-penerima tidak ditemui.';
$txt['error_form_already_submitted'] = 'Anda sudah menghantar pos ini!  Anda mungkin telah terklik dua kali atau cuba menyegarkan laman.';
$txt['error_poll_few'] = 'Anda mesti ada setidak-tidaknya dua pilihan!';
$txt['error_poll_many'] = 'Anda tidak boleh mempunyai lebih daripada 256 pilihan.';
$txt['error_need_qr_verification'] = 'Sila lengkapkan bahagian pengesahan di bawah untuk melengkapkan pos anda.';
$txt['error_wrong_verification_code'] = 'Huruf yang anda masukkan tidak padan dengan huruf yang dipaparkan dalam gambar.';
$txt['error_wrong_verification_answer'] = 'Anda tidak menjawab pertanyaan pengesahan dengan benar.';
$txt['error_need_verification_code'] = 'sila masukkan kod pengesahan di bawah untuk melanjutkan hasilnya.';
$txt['error_bad_file'] = 'Maaf tapi fail yang ditetapkan tidak boleh dibuka: %1$s';
$txt['error_bad_line'] = 'Baris yang anda tetapkan tidak sah.';
$txt['error_draft_not_saved'] = 'Ada kesalahan menyimpan deraf';
$txt['error_name_in_use'] = 'Nama ini sudah dipakai oleh ahli lain.';

$txt['smiley_not_found'] = 'Mimik tidak ditemui.';
$txt['smiley_has_no_code'] = 'Kod untuk mimik ini tidak diberikan.';
$txt['smiley_has_no_filename'] = 'Nama fail mimik ini tiada.';
$txt['smiley_not_unique'] = 'Mimik dengan kod tersebut sudah ada.';
$txt['smiley_set_already_exists'] = 'Set mimik dengan URL tersebut sudah ada';
$txt['smiley_set_not_found'] = 'Set mimik tidak ditemui';
$txt['smiley_set_dir_not_found'] = 'Direktori set mimik %1$s tidak sah atau tidak boleh diakses.';
$txt['smiley_set_path_already_used'] = 'URL set mimik sudah tersebut sedang digunakan oleh set mimik yang lain.';
$txt['smiley_set_unable_to_import'] = 'Tidak dapat mengimport set mimik. Direktori tersebut tidak sah atau tidak boleh diakses.';

$txt['smileys_upload_error'] = 'Gagal memuatnaik fail.';
$txt['smileys_upload_error_blank'] = 'Semua set mimik harus mempunyai gambar!';
$txt['smileys_upload_error_name'] = 'Semua mimik mesti mempunyai nama fail yang sama.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Jenis tidak sah.';

$txt['search_invalid_weights'] = 'Keutamaan pencarian tidak ditetapkan dengan benar. Setidaknya satu keutamaan harus ditetapkan jadi tidak sifar. Sila laporkan kesalahan ini ke pengurus.';

$txt['package_no_file'] = 'Tidak jumpa fail pakej!';
$txt['packageget_unable'] = 'Tidak boleh menyambung ke server.  Sebaliknya, sila cuba menggunakan <a href="%1$s" target="_blank">URL ini</a>.';
$txt['not_valid_server'] = 'Maaf pakej hanya boleh dimuatturun seperti ini daripada server yang mula2 anda benarkan.';
$txt['package_cant_uninstall'] = 'Pakej ini tidak pernah diinstalasi atau instalasi sudah dibuang - anda tidak boleh membuangnya sekarang.';
$txt['package_cant_download'] = 'Anda tidak boleh memuatturun atau menginstalasi pakej baru karena direktori Packages atau salah satu fail di dalamnya tidak boleh dipos!';
$txt['package_upload_error_nofile'] = 'Anda tidak memilih pakej yang akan dimuatnaik.';
$txt['package_upload_error_failed'] = 'Tidak boleh memuatnaik pakej, sila periksa keizinan direktori!';
$txt['package_upload_error_exists'] = 'Fail yang anda muatnaik sudah ada di server. Sila padam itu lebih dulu kemudian cuba lagi.';
$txt['package_upload_already_exists'] = 'Pakej yang anda cuba muatnaik sudah ada pada server dengan nama: %1$s';
$txt['package_upload_error_supports'] = 'Pengurus pakej semasa hanya membenarkan Jenis fail ini: %1$s.';
$txt['package_upload_error_broken'] = 'Pakej yang anda muatnaik gagal karena kesalahan berikut:<br />&quot;%1$s&quot; ';

$txt['package_get_error_not_found'] = 'Pakej yang cuba anda instalasi tidak boleh ditempatkan. Anda mungkin ingin memuatnaik pakej secara manual ke direktori Packages.';
$txt['package_get_error_missing_xml'] = 'Pakej yang anda cuba instalasi tidak kekurangan package-info.xml yang harus ada dalam direktori pakej.';
$txt['package_get_error_is_zero'] = 'Meskipun pakej sudah dimuatturun ke server, nampaknya ia kosong. Sila periksa direktori Packages, dan sub-direktori &quot;temp&quot; keduanya harus boleh dipos. Jika anda tetap mengalami masalah ini, anda harus cuba mengurai pakej pada PC anda dan memuatnaik fail-file yang sudah diurai ke dalam subdirektori pada direktori Packages dan cuba lagi. Sebagai contoh, jika pakej bernama shout.tar.gz anda harus:<br />1) Memuatturun pakej ke lokal PC dan menguraikannya menjadi fail.<br />2) Menggunakan klien FTP untuk membuat direktori baru dalam folder &quot;Packages&quot; anda, dalam contoh ini anda boleh menamakan "shout".<br />3) Upload semua fail dari pakej yang sudah diuraikan ke direktori tersebut.<br />4) Kembali ke pengurus pakej untuk melihat laman dan pakej akan ditemukan secara automatik oleh SMF.';
$txt['package_get_error_packageinfo_corrupt'] = 'Tidak menemui info yang sah di dalam fail package-info.xml yang disertakan pada pakej. Mungkin ada kesalahan pada penambahan, atau pakej telah rosak.';
$txt['package_get_error_is_theme'] = 'Anda tidak boleh memasang tema daripada bahagian ini, sila gunakan laman <a href="{MANAGETHEMEURL}">Pengurusan Tema</a>  untuk memuatnaikkannya';

$txt['no_membergroup_selected'] = 'Grup ahli tidak dipilih';
$txt['membergroup_does_not_exist'] = 'Grup ahli tiada atau tidak sah.';

$txt['at_least_one_admin'] = 'Harus setidaknya ada satu pengurus pada forum!';

$txt['error_functionality_not_windows'] = 'Maaf, fungsi semasa tidak tersedia pada server berbasis Windows.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Lampiran Tidak Ditemui';

$txt['error_no_boards_selected'] = 'Tiada ruangan yang sah dipilih.';
$txt['error_invalid_search_string'] = 'Anda lupa masukkan sesuatu untuk dicari?';
$txt['error_invalid_search_string_blacklist'] = 'Queri carian anda mengandungi terlalu banyak perkataan. Sila cuba lagi dengan queri lain.';
$txt['error_search_string_small_words'] = 'Setiap perkataan mesti sekurang2nya dua aksara panjang.';
$txt['error_query_not_specific_enough'] = 'Kueri carian anda tidak cukup spesifik.';
$txt['error_no_messages_in_time_frame'] = 'Tiada mesej ditemukan dalam waktu yang dipilih.';
$txt['error_no_labels_selected'] = 'Label tidak dipilih!';
$txt['error_no_search_daemon'] = 'Tidak boleh mengakses daemon carian';

$txt['profile_errors_occurred'] = 'Kesalahan berikut terjadi ketika cuba menyimpan profil anda';
$txt['profile_error_bad_offset'] = 'Jarak waktu di luar jangkauan';
$txt['profile_error_no_name'] = 'Petak nama dibiarkan kosong';
$txt['profile_error_digits_only'] = 'Nombor kotak pos hanya boleh mengandungi angka.';
$txt['profile_error_name_taken'] = 'Nama pengguna/paparan yang dipilih sudah dipakai';
$txt['profile_error_name_too_long'] = 'Nama yang dipilih terlalu panjang. Ia tidak boleh lebih panjang dari 60 aksara';
$txt['profile_error_no_email'] = 'Petak email dibiarkan kosong';
$txt['profile_error_bad_email'] = 'Anda belum memasukan alamat email yang sah';
$txt['profile_error_email_taken'] = 'Pengguna lain sudah terdaftar dengan alamat email itu';
$txt['profile_error_no_password'] = 'Anda tidak memasukan kata kunci';
$txt['profile_error_bad_new_password'] = 'Kata kunci baru yang anda masukan tidak padan';
$txt['profile_error_bad_password'] = 'Kata kunci yang anda masukan tidak sah';
$txt['profile_error_bad_avatar'] = 'Avatar yang sudah anda pilih terlalu besar, atau bukan sebuah avatar';
$txt['profile_error_password_short'] = 'Kata laluan anda mesti sekurang2nya %1$s aksara panjang.';
$txt['profile_error_password_restricted_words'] = 'Kata kunci anda tidak boleh berisi nama pengguna, alamat email atau kata umum lain yang sering dipakai.';
$txt['profile_error_password_chars'] = 'Kata kunci harus berisi campuran huruf besar dan kecil, juga angka.';
$txt['profile_error_already_requested_group'] = 'Anda sudah mempunyai permintaan tertunda untuk grup ini!';
$txt['profile_error_openid_in_use'] = 'Pengguna lain sudah menggunakan URL pengesahan OpenID';
$txt['profile_error_signature_not_yet_saved'] = 'Tandatangan tidak dapat disimpan.';
$txt['profile_error_personal_text_too_long'] = 'Teks peribadi terlalu panjang.';
$txt['profile_error_user_title_too_long'] = 'Tajuk rekaan terlalu panjang.';

$txt['mysql_error_space'] = ' - periksa ruang penyimpanan database atau hubungi pengurus server.';

$txt['icon_not_found'] = 'Gambar ikon tidak boleh ditemukan dalam tema default - pastikan gambar sudah dimuatnaik dan sila cuba lagi.';
$txt['icon_after_itself'] = 'Ikon tidak boleh diposisikan setelah dirinya sendiri!';
$txt['icon_name_too_long'] = 'Panjang nama fail ikon tidak boleh lebih dari 16 aksara';

$txt['name_censored'] = 'Maaf, nama yang cuba anda pakai, %1$s, berisi kata yang sudah disensor. Sila cuba nama lain.';

$txt['poll_already_exists'] = 'Topik hanya boleh mempunyai satu undian dikaitkan dengannya!';
$txt['poll_not_found'] = 'Tiada undian yang dikaitkan dengan topik ini!';

$txt['error_while_adding_poll'] = 'Kesalahan berikut atau kesalahan terjadi semasa menambahkan undian ini';
$txt['error_while_editing_poll'] = 'Kesalahan berikut atau kesalahan terjadi semasa mengedit undian ini';

$txt['loadavg_search_disabled'] = 'Karena tingginya tekanan pada server, fungsi pencarian sementara sudah dimatikan secara automatik. Sila cuba lagi nanti dalam beberapa waktu.';
$txt['loadavg_generic_disabled'] = 'Maaf, karena tingginya beban pada server, ciri semasa tidak tersedia.';
$txt['loadavg_allunread_disabled'] = 'Sumber daya server untuk sementara terlalu tinggi guna mencari semua topik yang belum anda baca.';
$txt['loadavg_unreadreplies_disabled'] = 'Server semasa dalam tekanan tinggi. Sila cuba lagi dalam waktu dekat.';
$txt['loadavg_show_posts_disabled'] = 'Silakan cuba lagi nanti.  Pos ahli buat masa ini tidak tersedia karena tingginya beban pada server.';
$txt['loadavg_unread_disabled'] = 'Sumber daya server semasa dalam permintaan dengan beban tinggi untuk mendaftar topik yang belum anda baca.';
$txt['loadavg_userstats_disabled'] = 'Sila cuba lagi kemudian. Statistik ahli ini tidak dapat diperolehi buat masa ini kerana beban yang tinggi pada server.';

$txt['cannot_edit_permissions_inherited'] = 'Anda tidak boleh mengedit turunan perkeizinanan secara terus, anda harus mengedit grup induk atau mengedit turunan grup ahli.';

$txt['mc_no_modreport_specified'] = 'Anda perlu untuk menetapkan laporan mana yang ingin anda lihat.';
$txt['mc_no_modreport_found'] = 'Laporan yang ditetapkan tiada atau terbatas bagi anda';

$txt['st_cannot_retrieve_file'] = 'Tidak boleh mengambil fail %1$s.';
$txt['admin_file_not_found'] = 'Tidak boleh mengambil fail yang diminta: %1$s.';

$txt['themes_none_selectable'] = 'Setidaknya satu tema harus boleh dipilih.';
$txt['themes_default_selectable'] = 'Tema default forum keseluruhan harus tema yang boleh dipilih.';
$txt['ignoreboards_disallowed'] = 'Pilihan untuk mengabaikan ruangan masih belum diaktifkan.';

$txt['mboards_delete_error'] = 'Kategori tidak dipilih!';
$txt['mboards_delete_board_error'] = 'Ruangan tidak dipilih.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'Tidak boleh menjadikan ruangan induk sebagai ruangan kecilnya sendiri.';
$txt['mboards_board_own_child_error'] = 'Anda tidak boleh menjadikan satu2 ruangan sebagai anaknya sendiri.';

$txt['smileys_upload_error_notwritable'] = 'Direktori mimik berikut tidak boleh ditulis: %1$s';
$txt['smileys_upload_error_types'] = 'Imej mimik hanya boleh mempunyai akhiran berikut: %1$s.';

$txt['change_email_success'] = 'Alamat email anda sudah diubah, dan email pengaktifan sudah dikirimkan ke alamat itu.';
$txt['resend_email_success'] = 'Email pengaktifan baru telah dikirimkan dengan sukses.';

$txt['custom_option_need_name'] = 'Pilihan profil harus mempunyai nama!';
$txt['custom_option_not_unique'] = 'Nama petak tidak unik!';
$txt['custom_option_regex_error'] = 'Regex yang anda masukkan tidak sah';

$txt['warning_no_reason'] = 'Anda harus memasukan alasan untuk perubahan kondisi peringatan seorang ahli.';
$txt['warning_notify_blank'] = 'Anda memilih untuk memberitahu pengguna tapi tidak mengisi petak subjek/mesej.';

$txt['cannot_connect_doc_site'] = 'Tidak boleh menyambung ke Manual Online Simple Machines. Sila periksa tetapan server anda untuk keizinan sambungan internet luar dan cuba lagi nanti.';

$txt['movetopic_no_reason'] = 'Anda harus memasukkan alasan untuk memindahkan topik, atau jangan tanda pilihan \'pos topik peralihan\'.';
$txt['movetopic_no_board'] = 'Anda mesti memilih satu ruangan bagi mengalihkan topik.';

$txt['splittopic_no_reason'] = 'Anda mesti menyatakan sebab bagi memisahkan topi atau kosongkan pilihan untuk \'pos mesej peralihan\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Pengenal yang diminta tidak mengembalikan maklumat yang sah.';
$txt['openid_return_no_mode'] = 'Penyedia identiti tidak menjawab dengan cara Open ID.';
$txt['openid_not_resolved'] = 'Penyedia identiti tidak meluluskan permintaan anda.';
$txt['openid_no_assoc'] = 'Tidak menemukan rakan yang diminta dengan penyedia identiti.';
$txt['openid_sig_invalid'] = 'Tanda tangan dari penyedia identiti tidak sah.';
$txt['openid_load_data'] = 'Tidak dapat mengambil data dari permintaan masuk anda. Sila cuba lagi.';
$txt['openid_not_verified'] = 'Alamat OpenID yang diberikan belum dipengesahan. Sila masuk untuk pengesahan.';

$txt['error_custom_field_too_long'] = 'Panjang petak &quot;%1$s&quot; tidak boleh lebih besar dari %2$d aksara panjang.';
$txt['error_custom_field_invalid_email'] = 'Petak &quot;%1$s&quot; harus berupa alamat email yang sah.';
$txt['error_custom_field_not_number'] = 'Petak &quot;%1$s&quot; harus numerik.';
$txt['error_custom_field_inproper_format'] = 'Format petak &quot;%1$s&quot; tidak sah.';
$txt['error_custom_field_empty'] = 'Petak &quot;%1$s&quot; tidak boleh dibiarkan kosong.';

$txt['email_no_template'] = 'Template email &quot;%1$s&quot; tidak dapat ditemukan.';

$txt['search_api_missing'] = 'API pencarian tidak ditemukan! Sila hubungi admin untuk memeriksa mereka telah memuatnaik fail-fail yang sah.';
$txt['search_api_not_compatible'] = 'API pencarian yang dipilih yang sedang dipakai forum ketinggalan zaman - beralih kembali ke pencarian default. Sila periksa fail %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Anda tidak boleh mengembalikan pos pertama dalam sebuah topik.';
$txt['restored_disabled'] = 'Pengembalian topik sudah dimatikan.';
$txt['restore_not_found'] = 'Mesej kesalahan berikut tidak boleh dikembalikan; Topik asalnya mungkin sudah dipadam:<ul style="margin-top: 0px;">%1$s</ul>Anda perlu memindahkannya secara manual.';

$txt['error_invalid_dir'] = 'Direktori yang anda masukkan tidak sah.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'Sub-tindakan yang anda pohon tidak didefinasikan';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'Tiada item yang boleh disusun';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
