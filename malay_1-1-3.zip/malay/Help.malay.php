<?php
// Version: 1.1; Help

global $helptxt;

$txt['close_window'] = 'Tutup jendela';

$helptxt['manage_boards'] = '	<strong>Edit Ruangan</strong><br />
	Dalam menu ini anda boleh membuat/mengedit/membuang ruangan dan kategori di atasnya.
	Sebagai contoh, jika anda mempunyai laman berskala-luas yang menawarkan
	informasi mengenai &quot;Sukan&quot;, &quot;Kereta&quot; dan &quot;Muzik&quot;, ini
	akan menjadi Kategori tingkat-teratas yang anda buat. Di bawah setiap kategori ini
	Anda mungkin mahu membuat hirarki &quot;sub-kategori&quot; atau
	&quot;Ruangan&quot; untuk masing-masing topik di dalamnya. Hirarki sederhana, dengan struktur ini: <br />
	<ul>
		<li>
			<strong>Sukan</strong>
			&nbsp;- A &quot;kategori&quot;
		</li>
		<ul>
			<li>
				<strong>Baseball</strong>
				&nbsp;- Ruangan di bawah kategori &quot;Sukan&quot;
			</li>
			<ul>
				<li>
					<strong>Stats</strong>
					&nbsp;- Ruangan anak di bawah ruangan &quot;Baseball&quot;
				</li>
			</ul>
			<li><strong>Football</strong>
			&nbsp;- Ruangan di bawah kategori &quot;Sukan&quot;</li>
		</ul>
	</ul>
	Kategori mengizinkan anda untuk memecah ruangan menjadi topik luas (&quot;Kereta,
	Sukan&quot;), dan &quot;Ruangan&quot; di bawahnya adalah topik sebenarnya yang
	boleh dipos oleh ahli. Pengguna yang tertarik dengan Pintos akan menulis
	di bawah &quot;Cars->Pinto&quot;. Kategori mengizinkan orang untuk menemukan
	dengan cepat apa yang menarik bagi mereka: Daripada &quot;Kedai&quot; anda
	mempunyai kedai &quot;Perkakasan&quot; dan &quot;Pakaian&quot; yang boleh anda masuki. 
	Ini menyederhanakan pencarian &quot;paip sambungan kompaun&quot; kerana anda boleh pergi ke 
	&quot;Kategori&quot; Kedai Perkakasan daripada Kedai Pakaian (di mana anda tidak akan
	menemukan paip sambungan kompaun).<br />
	Seperti dinyatakan di atas, Ruangan adalah kunci topik di bawah kategori ruangan.
	Jika anda mahu membicarakan &quot;Pintos&quot; anda mesti pergi ke kategori &quot;Kereta&quot; dan
	melompat ke dalam ruangan &quot;Pinto&quot; untuk menuliskan pemikiran anda pada ruangan itu.<br />
	Fungsi Pengurusan untuk item menu ini adalah untuk membuat ruangan baru di bawah setiap
	kategori, untuk mengedit semula (memindahkan &quot;Pinto&quot; di belakang &quot;Chevy&quot;), atau
	memadam seluruh ruangan.';

$helptxt['edit_news'] = '
⇥<ul class="normallist">
⇥⇥<li>
⇥⇥⇥<strong>Berita</strong><br />
⇥⇥⇥Bahagian ini membolehkan anda menetapkan teks untuk item berita yang dipaparkan pada laman Indeks Utama. Tambah sebarang item yang anda mahukan (contoh, &quot;Jangan lupa mesyuarat hari Selasa ini&quot;). Setiap item berita dipaparkan secara rawak dan mesti ditempatkan dalam kotak berasingan.
⇥⇥</li>
⇥⇥<li>
⇥⇥⇥<strong>Suratan Berita</strong><br />
⇥⇥⇥Bahagian ini mengizinkan anda untuk mengirimkan suratan berita kepada ahli forum melalui mesej peribadi atau emel. Pertama pilih grup yang anda kehendaki untuk menerima suratan berita, dan yang tidak anda kehendaki untuk menerima suratan berita. Jika anda mahukan, anda boleh menambah ahli tambahan dan alamat emel yang akan menerima suratan berita. Akhir sekali, masukkan mesej yang hendak anda kirimkan dan pilih sama ada anda mahu ia dikirimkan kepada ahli sebagai mesej peribadi atau emel.
⇥⇥</li>
⇥⇥<li>
⇥⇥⇥<strong>Tetapan</strong><br />
⇥⇥⇥Bahagian ini mengandungi beberapa aturan yang berkaitan dengan berita dan suratan berita, termasuk memilih grup mana yang boleh mengedit berita forum atau mengirim suratan berita. Di sana terdapat juga tetapan konfigurasi sama ada anda mahu suapan berita dihidupkan pada forum, termasuk tetapan konfigurasi panjang (berapa karakter untuk dipaparkan) bagi setiap pos berita dari suapan berita. 
⇥⇥</li>
⇥</ul> ';

$helptxt['view_members'] = '	<ul>
		<li>
			<strong>Lihat seluruh Ahli</strong><br />
			Melihat seluruh ahli dalam ruangan. anda disajikan dengan hiperlink daftar nama ahli. anda 
			boleh mengklik pada salah satu nama untuk menemukan butiran ahli (homepage, umur, dll.), dan
			sebagai Pengurus anda boleh mengubah parameter ini. anda memiliki kawalan penuh atas ahli,
			termasuk kemampuan untuk memadamnya dari forum.<br /><br />
		</li>
		<li>
			<strong>Menunggu Persetujuan</strong><br />
			Bahagian ini hanya dipaparkan jika anda mengaktifkan persetujuan Pengurus atas semua pendaftaran baru. Setiap orang yang mendaftar untuk menyertai fo
			Anda hanya akan menjadi ahli penuh sekali mereka sudah disetujui oleh Pengurus. Bahagian ini mendaftar seluruh ahli yang masih
			menunggu persetujuan, bersamaan dengan alamat IP dan emailnya. anda boleh memilih untuk menerima atau menolak (memadam)
			setiap ahli pada daftar dengan menTanda kotak didekat ahli dan memilih tindakan dari kotak drop-down di layar
			bawah. Ketika menolak ahli anda boleh memilih untuk memadam ahli dengan atau tanpa memberitahukan keputusan anda.<br /><br />
		</li>
		<li>
			<strong>Menunggu Pengaktifan</strong><br />
			Bahagian ini hanya akan terlihat jika anda mengaktifkan pengaktifan akaun ahli pada forum. Bahagian ini akan mendaftar semua
			ahli yang masih belum mengaktifkan akaun barunya. Dari layar ini anda boleh memiliih untuk menerima, menolak atau mengingatkan
			ahli dengan pendaftaran yang tertunda. Seperti di atas anda juga boleh memilih untuk mengirim email kepada ahli guna memaklumkan
			tindakan yang telah anda ambil.<br /><br />
		</li>
	</ul>';

$helptxt['ban_members'] = '<strong>Menyekat Ahli</strong><br />
	ElkArte menyediakan kemampuan untuk &quot;menyekat&quot; pengguna, untuk menjaga orang yang melanggar adab ruangan
	dengan spam, troll, dsb. daripada meneruskannya. Ini membolehkan anda menyekat pengguna yang mengancam forum anda. Sebagai Pengurus,
	ketika anda melihat mesej, anda boleh melihat alamat IP setiap pengguna yang digunakan untuk mengepos pada saat itu. Dalam senarai sekatan,
	anda hanya perlu memasukkan alamat IP tersebut, simpan, dan mereka tidak boleh lagi mengepos dari lokasi itu.<br />
	Anda juga boleh menyekat orang melalui alamat emelnya.';

$helptxt['featuresettings'] = '<strong>Ciri dan Pilihan</strong><br /> Ada beberapa ciri dalam bahagian ini yang boleh diubah menurut kehendak anda.';

$helptxt['securitysettings'] = '<strong>Sekuriti dan Seliaan</strong><br />
	Bahagian ini berisi aturan berkaitan dengan sekuriti dan seliaan forum anda.';

$helptxt['addonsettings'] = '<strong>Tetapan Penambahan</strong><br />
⇥Bahagian ini mengandungi tetapan oleh penambahan yang dipasang pada forum anda.';

$helptxt['time_format'] = '<strong>Format Waktu</strong><br />
	Anda memiliki kemampuan untuk menyesuaikan bagaimana jam dan tarikh terlihat bagi anda sendiri. Ada banyak huruf kecil, tapi tidak cukup sederhana.
	Konvensi mengikuti fungsi strftime PHP dan dijelaskan di bawah ini (lebih butiran dapat ditemukan di <a href="http://www.php.net/manual/function.strftime.php" target="_blank">php.net</a>).<br />
	<br />
	Karakter berikut dikenal dalam string format: <br />
	<span class="smalltext">
	&nbsp;&nbsp;%a - singkatan nama hari<br />
	&nbsp;&nbsp;%A - nama hari lengkap<br />
	&nbsp;&nbsp;%b - singkatan nama bulan<br />
	&nbsp;&nbsp;%B - nama bulan lengkap<br />
	&nbsp;&nbsp;%d - tarikh dari sebulan (01 sampai 31) <br />
	&nbsp;&nbsp;%D<b>*</b> - sama seperti %m/%d/%y <br />
	&nbsp;&nbsp;%e<b>*</b> - tarikh dari sebulan (1 sasmpai 31) <br />
	&nbsp;&nbsp;%H - jam menggunakan waktu 24-jam (jangkauan 00 sampai 23) <br />
	&nbsp;&nbsp;%I - jam menggunakan waktu 12-jam (jangkauan 01 sampai 12) <br />
	&nbsp;&nbsp;%m - bulan sebagai angka (01 sampai 12) <br />
	&nbsp;&nbsp;%M - minit sebagai angka <br />
	&nbsp;&nbsp;%p - baik &quot;am&quot; ataupun &quot;pm&quot; tergantung jam yang diberikan<br />
	&nbsp;&nbsp;%R<b>*</b> - jam dalam notasi 24 jam <br />
	&nbsp;&nbsp;%S - saat sebagai angka desimal <br />
	&nbsp;&nbsp;%T<b>*</b> - jam sekarang, sama dengan %H:%M:%S <br />
	&nbsp;&nbsp;%y - 2 digit tahun (00 sampai 99) <br />
	&nbsp;&nbsp;%Y - 4 digit tahun<br />
	&nbsp;&nbsp;%Z - zon waktu atau nama atau singkatan <br />
	&nbsp;&nbsp;%% - literal karakter \'%\' <br />
	<br />
	<i>* Ini tidak berfungsi pada server berbasis-Windows.</i></span>';

$helptxt['deleteAccount_posts'] = 'Jawapan Sahaja: Ini akan membuang pos ahli ini sekadar menjawab pos yang lain.<br />
⇥Topik dan Jawapan: Ini akan melakukan perkara yang sama seperti di atas, dan akan membuang semua tajuk topik yang dimulakan oleh ahli ini.';

$helptxt['live_news'] = '<strong>Live announcements</strong><br />
	This box shows recently updated announcements from <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.
	You should check here every now and then for updates, new releases, and important information from ElkArte.';

$helptxt['registrations'] = '<strong>Pengurusan Pendaftaran</strong><br />
	Bahagian ini berisi semua fungsi yang diperlukan untuk mengatur pendaftaran pada forum. Ia berisi sampai empat
	bahagian yang terliht tergantung pada aturan forum anda. Ini adalah:<br /><br />
	<ul>
		<li>
			<strong>Daftarkan ahli baru</strong><br />
			Dari layar ini anda boleh memilih untuk mendaftarkan akaun bagi ahli baru atas nama mereka. Ini berguna dalam forum di mana pendaftaran ditutup bagi
			ahli baru, atau dalam hal di mana Pengurus mahu membuat akaun ujian. Jika pilihan untuk memerlukan pengaktifan dari akaun
			yang dipilih, ahli akan diberi email link pengaktifan yang mesti diklik sebelum mereka boleh menggunakan akaunnya. Hal yang serupa anda boleh
			memilih untuk mengirimkan email ke pengguna kata kunci baru ke alamat email yang dinyatakan.<br /><br />
		</li>
		<li>
			<strong>Edit Perjanjian Pendaftaran</strong><br />
			Ini mengizinkan anda untuk mengatur teks untuk perjanjian pendaftaran ketika ahli mendaftar di forum anda.
			Anda boleh menambah atau memadam apapun dari perjanjian pendaftaran default yang disertakan dalam ElkArte.<br /><br />
		</li>
		<li>
			<strong>Set Nama-Nama Terpelihara</strong><br />
			Menggunakan fungsi ini anda boleh menetapkan kata atau nama yang tidak boleh dipakai oleh pengguna anda.<br /><br />
		</li>
		<li>
			<strong>Aturan</strong><br />
			Bahagian ini hanya akan terlihat jika anda memiliki keizinan Pengurusan forum. Dari layar ini anda boleh memutuskan cara pendaftaran yang akan dipakai
			di forum anda, juga aturan berkaitan pendaftaran lainnya.
		</li>
	</ul>';

$helptxt['modlog'] = '<strong>Log Seliaan</strong><br />
	Bahagian ini mengizinkan ahli pasukan seliaan untuk menjejaki semua tindakan seliaan yang dilakukan penyelia forum. Untuk memastikan bahawa
	Penyelia tidak boleh memadam semakan atas tindakan yang sudah dilakukannya, entri tidak boleh dipadam sampai 24 jam setelah tindakan dilakukan.';
$helptxt['adminlog'] = '<strong>Log Admin</strong><br /> Bahagian ini mengizinkan ahli pasukan Pengurus untuk merekod beberapa tindakan Pengurusan yang terjadi pada forum. Guna memastikan bahawa Pengurus tidak boleh memadam semakan terhadap tindakan yang sudah dilakukan, entri tidak dipadam sampai 24 jam setelah tindakan diambil.';
$helptxt['badbehaviorlog'] = '<strong>Log Kelakuan Buruk</strong><br />
⇥Bahagian ini membenarkan ahli pasukan pengurusan untuk melihat sebahagian tindakan kelakuan buruk yang berlaku dalam forum. Log ini akan dipadamkan secara automatik oleh fungsi kelakuan buruk, jadi, ia akan hanya menyimpan aktiviti minggu yang lalu sahaja.';
$helptxt['warning_enable'] = '<strong>Sistem Peringatan Ahli</strong><br />
	Ciri ini mengizinkan ahli pasukan pengurusan dan seliaan untuk memberikan peringatan kepada ahli - dan untuk menggunakan tahap peringatan ahli bagi menentukan
	tindakan yang ada bagi mereka pada forum. Setelah menghidupkan ciri ini, keizinan akan tersedia dalam bahagian keizinan untuk ditetapkan
	grup manakah yang boleh memberikan peringatan kepada ahli. Tahap peringatan boleh disesuaikan dari profil ahli. Pilihan tambahan berikut tersedia:';
$helptxt['watch_enable'] = '<strong>Tahap Amaran bagi Pemantauan Ahli</strong><br />Tetapan ini menetapkan peratusan tahap amaran yang mesti dicapai bagi menetapkan secara automatik &quot;pemantauan&quot; kepada ahli itu. Mana-mana ahli yang sedang &quot;dipantau&quot; akan tersenarai dalam ruangannya di pusat seliaan.';
$helptxt['moderate_enable'] = '<strong>Tahap Amaran bagi Seliaan Pos</strong><br />Mana-mana ahli melepasi nilai tetapan ini akan mendapati bahawa pos mereka memerlukan kelulusan penyelia sebelum ia boleh kelihatan dalam komuniti⇥forum. Ini akan mengatasi sebarang keizinan dalaman bagi ruangan yang wujud berkaitan seliaan pos.';
$helptxt['mute_enable'] = '<strong>Warning Level for Member Muting</strong><br />If this warning level is passed by a member they will find themselves under a post ban. The member will lose all posting rights.';
$helptxt['perday_limit'] = '<strong>Maximum Member Warning Points per Day</strong><br />This setting limits the amount of points a moderator may add/remove to any particular member in a twenty four hour period. This can be used to limit what a moderator can do in a small period of time. This setting can be disabled by setting to a value of zero. Note that any member with administrator permissions are not affected by this value.';
$helptxt['error_log'] = '<strong>Log Kesalahan</strong><br />
	Log kesalahan merekod log setiap kesalahan serius yang ditemukan oleh pengguna yang menggunakan forum anda. Ia mendaftar semua kesalahan ini dengan tarikh yang boleh diedit dengan mengklik setiap tarikh. Sebagai tambahan anda boleh menapis kesalahan ini dengan mengklik gambar di sebelah statistik kesalahan. Ini
	mengizinkan anda untuk menapis, misalnya, oleh ahli. Ketika tapisan aktif hanya hasil yang akan dipaparkan yang sesuai dengan tapisan itu.';
$helptxt['theme_settings'] = '<strong>Aturan Tema</strong><br />
	Layar aturan ini mengizinkan anda untuk mengubah aturan khusus tema. Aturan ini termasuk pilihan seperti direktori tema dan informasi URL
	juga pilihan yang mempengaruhi rupa tema pada forum anda. Banyak tema akan memiliki variasi pilihan yang boleh ditetapan pengguna, mengizinkan anda untuk mengadaptasi tema
	sesuai dengan keperluan forum individual anda.';
$helptxt['smileys'] = '<strong>Pusat Mimik</strong><br />
	Di sini anda dapat menambah dan memadam mimik, dan set mimik. Catatan penting bahawa jika mimik berada dalam satu set, ia berada dalam semua set - jika tidak, ia mungkin
	mengelirukan pengguna anda dalam menggunakan set2 berbeza.<br /><br />

	Anda juga boleh mengubah ikon mesej dari sini, jika anda sudah menghidupkannya pada laman tetapan.';

$helptxt['calendar'] = '<strong>Mengatur Kalendar</strong><br />
	Di sini anda boleh mengubah aturan kalendar semasa, juga menambah dan memadam hari cuti yang muncul pada kalendar.';
$helptxt['calendar_settings'] = 'The calendar can be used for showing birthdays or for showing important moments happening in your community.<br /><br />Remember that usage of the calendar (posting events, viewing events, etc.) is controlled by permissions set on the permissions screen.';
$helptxt['cal_days_for_index'] = 'Max days in advance on board index:<br />If this is set to 7, the next week\'s worth of events will be shown.';
$helptxt['cal_showevents'] = 'Enables the highlighting of events on the Mini Calendars, Main Calendar, both places, or disable event highlighting.';
$helptxt['cal_showholidays'] = 'This setting allows you to highlight holidays on the Mini Calendars, Main Calendar, both places, or disable event highlighting.';
$helptxt['cal_showbdays'] = 'This setting allows you to highlight birthdays on the Mini Calendars, Main Calendar, both places, or disable event highlighting.';
$helptxt['cal_export'] = 'Exports a text file in the iCal format for importing into other calendar applications.';
$helptxt['cal_daysaslink'] = 'Show days as link to \'Post Event\':<br />This will allow members to post events for that day when they click on that date.';
$helptxt['cal_allow_unlinked'] = 'Allow events not linked to posts:<br />Allow members to post events without requiring it to be linked with a post in a board.';
$helptxt['cal_defaultboard'] = 'Default Board to Post In:<br />Enter the default board to post events in.';
$helptxt['cal_showInTopic'] = 'Show linked events in topic display:<br />Check to show a link to the event at the top of topic view.';
$helptxt['cal_allowspan'] = 'Allow events to span multiple days:<br />Check to allow events to span multiple days.';
$helptxt['cal_maxspan'] = 'Max number of days an event can span:<br />Enter the maximum number of days that a single event can span.';
$helptxt['cal_minyear'] = 'Minimum year:<br />Select the &quot;first&quot; year on the calendar list.';
$helptxt['cal_maxyear'] = 'Maximum year:<br />Select the &quot;last&quot; year on the calendar list<br />';

$helptxt['serversettings'] = '<strong>Aturan Server</strong><br />
	Di sini anda dapat melakukan tetapan ini untuk forum anda. Bahagian ini termasuk aturan database dan url, juga item tetapan
	penting lainnya seperti aturan surat dan caching. Fikirkan dengan hati-hati bila mengedit aturan ini kerana kesilapan boleh
	mengakibatkan forum tidak boleh diakses';
$helptxt['manage_files'] = '<ul class="normallist">  <li>  <strong>Lihat File</strong><br />  Melihat melalui semua lampiran, avatar dan thumbnail yang disimpan oleh forum.<br /><br />  </li><li>  <strong>Aturan Lampiran</strong><br />  Mengtetapan lampiran yang disimpan dan mengatur batasan pada jenis lampiran.<br /><br />  </li><li>  <strong>Aturan Avatar</strong><br />  Mengkongfigurasi di mana avatar disimpan dan mengatur ukuran avatar.<br /><br />  </li><li>  <strong>Pemeliharaan File</strong><br />  Memeriksa dan membetulkan setiap kesalahan dalam direktori lampiran dan memadam lampiran yang dipilih.<br /><br />  </li>  </ul>  ';

$helptxt['topicSummaryPosts'] = 'Ini mengizinkan anda untuk mengatur jumlah pos sebelum dipaparkan dalam ringkasan topik pada layar jawab.';
$helptxt['enableAllMessages'] = 'Aturan ini ke jumlah pos topik <em>maksima</em> yang boleh memaparkan semua link.  Aturan ini lebih rendah daripada &quot;Maksima mesej dipaparkan dalam laman topik&quot; bererti tidak pernah dipaparkan, dan aturan terlalu tinggi boleh melambatkan forum anda.';
$helptxt['allow_guestAccess'] = 'Tidak menanda petak ini akan menghalang tetamu dari melakukan sesuatu kecuali tindakan yang sangat asas - log masuk, mendaftar, pengingat kata kunci, dll. - pada forum anda.  Ianya tidak sama dengan menghalang tetamu mengakses ke sebarang ruangan.';
$helptxt['userLanguage'] = 'Mengaktifkan pilihan ini akan mengizinkan pengguna untuk memilih fail bahasa yang mereka pakai. Ini tidak akan mempengaruhi
		pemilihan default.';
$helptxt['trackStats'] = 'Statistik:<br />Ini akan mengizinkan pengguna untuk melihat pos terbaru dan topik paling popular pada forum anda.
		Ia juga akan memaparkan beberapa statistik, seperti ahli online terlama, ahli baru dan topik baru.<hr />
		laman dilihat:<br />Menambah kolum lain ke laman statistik dengn jumlah laman dilihat pada forum anda.';
$helptxt['enable_unwatch'] = 'Enabling this option will allow users to selectively turn off new reply notifications for topics in which they had previously posted.';
$helptxt['titlesEnable'] = 'Mengaktifkan Tajuk Pilihan akan mengizinkan ahli dengan keizinan yang berkaitan untuk membuat judul khusus bagi mereka sendiri.
		Ini akan dipaparkan di bawah nama.<br /><em>Sebagai contoh:</em><br />Fahim<br />Budak Baik';
$helptxt['onlineEnable'] = 'Ini akan memaparkan gambar untuk menunjukkan apakah ahli online atau offline';
$helptxt['todayMod'] = 'Ini akan memaparkan &quot;Hari ini&quot;, atau &quot;Semalam&quot;, daripada tarikh.<br /><br />  <strong>Contoh:</strong><br /><br />  <dt>  <dt>Dimatikan</dt>  <dd>Oktober 3, 2009 pada 12:59:18 am</dd>  <dt>Hanya Hari Ini</dt>  <dd>Hari ini pada 12:59:18 am</dd>  <dt>Hari ini &amp; Semalam</dt>  <dd>Semalam pada 09:36:55 pm</dd>  </dt>  ';
$helptxt['disableCustomPerPage'] = 'Tanda pilihan ini untuk menghentikan pengguna dari memilih jumlah mesej dan topik dipaparkan di laman masing-masing pada laman Indeks Mesej dan Paparan Topik.';
$helptxt['enablePreviousNext'] = 'Ini akan memaparkan link ke topik berikutnya dan sebelumnya.';
$helptxt['pollMode'] = 'Ini memilih apakah undian diaktifkan atau tidak. Jika undian dimatikan, setiap undian akan disembunyikan
		dari daftar topik. anda boleh memilih untuk melanjutkan memaparkan topik biasa tanpa undiannya dengan memilih
		&quot;Paparkan Undian yang Ada sebagai Topik&quot;.<br /><br />untuk memilih siapa yang boleh menulis undian, melihat undian, dan sebagainya, anda
		boleh mengizinkan atau menafikan keizinan itu. Ingat ini jika undian tidak berfungsi.';
$helptxt['enableVBStyleLogin'] = 'Ini akan memaparkan login masuk yang lebih ringkas pada setiap laman forum untuk tetamu.';
$helptxt['enableCompressedOutput'] = 'Pilihan ini akan mengecilkan output bagi merendahkan penggunaan bandwidth, tapi memerlukan agar
		zlib diinstal.';
$helptxt['databaseSession_enable'] = 'Pilihan ini memanfaatkan database untuk penyimpanan sesi - itu yang terbaik untuk keseimbangan capaian server, membantu semua masalah kehabolehn waktu dan membuat forum lebih cepat.';
$helptxt['databaseSession_loose'] = 'Mengaktifkan ini akan mengurangi bandwidth penggunaan forum anda, dan membuat mengklik kembali tidak akan mengambil semula laman - kerugiannya bahawa ikon (baru) tidak akan dikemaskinikan, diantara hal lainnya. (kecuali anda mengklik laman itu daripada kembali ke sana.)';
$helptxt['databaseSession_lifetime'] = 'Ini adalah jumlah saat untuk sesi berakhir setelah mereka tidak diakses.  Jika sebuah sesi tidak diakses terlalu lama, dikatakan &quot;kehabolehn waktu&quot;.  Selain itu yang lebih tinggi dari 2400 disarankan.';
$helptxt['cache_enable'] = 'ElkArte performs caching at a variety of levels. The higher the level of caching enabled the more CPU time will be spent retrieving cached information. If caching is available on your machine it is recommended that you try caching at level 1 first.';
$helptxt['cache_memcached'] = 'If you are using memcached you need to provide the server details. This should be entered as a comma separated list as shown in the example below:<br /><br/>&quot;server1,server2,server3:port,server4&quot;<br /><br />Note that if no port is specified the software will use port 11211, set this to 0 when using UNIX domain sockets.';
$helptxt['cache_cachedir'] = 'This setting is only for the filesystem based cache system. It specifies the path to the cache directory.  It is recommended that you place this in /tmp/ if you are going to use this, although it will work in any directory';
$helptxt['cache_uid'] = 'Some cache systems, for example Xcache, require a user ID and password to allow ElkArte access to clear the cache.';
$helptxt['cache_password'] = 'Some cache systems, for example Xcache, require a user ID and password to allow ElkArte access to clear the cache.';
$helptxt['enableErrorLogging'] = 'Ini akan mencatat setiap kesalahan, seperti gagal masuk, maka anda dapat melihat apa yang salah.';
$helptxt['enableErrorQueryLogging'] = 'Ini akan melampirkan laporan penuh dihantar ke database dalam log kesalahan.  Ia memerlukan log kesalahan diaktifkan.<br /><br /><strong>Catatan:  Ini akan mempengaruhi kemampuan untuk menyaring log kesalahan dengan mesej kesalahan.</strong>';
$helptxt['allow_disableAnnounce'] = 'Ini akan mengizinkan pengguna untuk mengeluarkan makluman topik yang anda umumkan dengan mengklik kotak tanda &quot;umumkan topik&quot; ketika mengepos.';
$helptxt['disallow_sendBody'] = 'Pilihan ini memadam pilihan untuk menerima teks jawapan dan pos dalam email makluman.<br /><br />Seringkali pengguna akan menjawab ke email makluman yang dalam hal ini bererti webmaster menerima jawapan.';
$helptxt['enable_contactform'] = 'This option adds a contact us button to the registration screen';
$helptxt['jquery_source'] = 'This will determine the source used to load the jQuery Library.  Auto will use the CDN first and if not available fall back to the local source.  Local will only use the local source, CDN will only load it from Google\'s Content Delivery Network';
$helptxt['jquery_default'] = 'If you want to use a version of jQuery different than the one that came with ElkArte, select this box and enter the version numer X.XX.X The local file must follow the naming conventing of jquery-X.XX.X.min.js for it to be loaded.';
$helptxt['jqueryui_default'] = 'If you want to use a version of jQueryUI different than the one that came with ElkArte, select this box and enter the version numer X.XX.X The local file must follow the naming conventing of jquery-ui-X.XX.X.min.js for it to be loaded.';
$helptxt['minify_css_js'] = 'This will combine multiple CSS or JavaScript files per page as needed.  It will also remove unnecessary whitespace and comments from the files to reduce their size.  The combined and minimized files are saved so further requests can instantly serve those files.<br />Note that the first time a compilation is needed/created, there will be a slight delay on that page load in order to create the file (this will also happen after the cache is cleared)';
$helptxt['compactTopicPagesEnable'] = 'Ini akan memaparkan pemilihan dari jumlah laman.<br /><em>Contoh:</em>
		&quot;3&quot; untuk memaparkan: 1 ... 2 [3] 4 ... 9 <br />
		&quot;5&quot; untuk memaparkan: 1 ... 3 4 [5] 6 7 ... 9';
$helptxt['timeLoadPageEnable'] = 'Ini akan memaparkan masa dalam saat yang diambil bagi mencipta laman di ruangan bawah.';
$helptxt['removeNestedQuotes'] = 'Ini akan melucutkan ungkapan bersarang daripada pos apabila menyebut pos berkenaan melalui pautan ungkapan.';
$helptxt['search_dropdown'] = 'This will show a search selection dropdown next to the quick search box.  From this you can choose to search the current site, current board (if in a board), current topic (if in a topic) or search for members.';
$helptxt['max_image_width'] = 'Ini mengizinkan anda untuk mengatur ukuran maksima untuk gambar yang dipos. Gambar lebih kecil dari maksima tidak akan dipengaruhi.';
$helptxt['mail_type'] = 'Aturan ini mengizinkan anda untuk memilih aturan default PHP, atau mengabaikan aturan itu dengan SMTP.  PHP tidak menyokong pemakaian pengesahan dengan SMTP (banyak host memerlukannya sekarang) maka jika anda mahukannya anda mesti memilih SMTP.  Ambil perhatian bahawa SMTP mungkin lebih lambat, dan beberapa server tidak akan mengambil nama pengguna dan kata kunci.<br /><br />Anda tidak perlu mengisi aturan SMTP jika ini diatur ke default PHP.';
$helptxt['mail_batch_size'] = 'This setting determines how many emails will be sent per page load and can not be set greater than the maximum allowed per minute.<br />Leaving this as 0, the system will automatically determine a batch size to evenly spread the load and fill the quota.<br />If you want to set your own values, setting this to the same value as your limit is a good option for low per minute limits, or 1/6 of the limit for higher per minute limits.';
$helptxt['smtp_client'] = 'Used to identify this client to the SMTP server.<br />The field should contain the fully-qualified domain name (FQDN) of the SMTP client. In situations in which the client system does not have a meaningful domain name you can instead use an address literal formatted as [ipv4] or [IPv6:ipv6 address].<br />If left blank the system will attempt to detect this value for you.';

$helptxt['attachmentEnable'] = 'Enable/Disable the attachment system or disable only new attachments leaving old one available.';
$helptxt['attachmentRecodeLineEndings'] = 'Enabling this will re-code line endings of text based files (txt, css, html, php, xml) based on your server (Windows, Mac or Unix).';
$helptxt['automanage_attachments'] = 'This will create a directory structure based on the selected option.  This can be post date (subdividing attachments by year, or by year and month or by year, month and day) or simply adding a new directory when the space limit is reached.  Each directory created will have the same file count and total size restrictions.  This will help prevent directories from reaching a file or size limit.';
$helptxt['use_sub-directories_for_attachments'] = 'This will create all new directories as sub-directories under the main attachment directory.';
$helptxt['attachmentDirSizeLimit'] = ' Set how large the attachment folder can be.';
$helptxt['attachmentDirFileLimit'] = 'Set the max. number of files an individual attachment directory may contain';
$helptxt['attachmentPostLimit'] = 'Specify how large a single post\'s total upload size can be (in KiB), this is the cumulative size of all attachments made in a post.';
$helptxt['attachmentSizeLimit'] = 'Specify the largest size a single attachment in a post can have.';
$helptxt['attachmentNumPerPostLimit'] = 'Select the number of attachments a member can add per post.';
$helptxt['attachmentCheckExtensions'] = 'Check this box to enable attachment filtering, which will only allow files to be uploaded with the file extensions that you have defined.';
$helptxt['attachmentExtensions'] = 'Specify what attachment types are allowed, for example: jpg,png,gif  Remember to be careful in what you allow as some file extensions can cause a security risk to your website.';
$helptxt['attachment_image_paranoid'] = 'Memilih pilihan ini membolehkan pemeriksaan sekuriti ketat pada lampiran imej. Amaran! Pemeriksaan ketat ini boleh juga gagal pada imej. Saranan kuat ialah untuk hanya menggunakan pilihan ini bersama dengan pengekodan semula imej, bagi membolehkan ElkArte cuba mengambil sampel imej yang gagal pemeriksaannya: jika berjaya, ia akan dibersihkan dan dimuatnaik. Sebaliknya, jika pengekodan semula imej tidak dihidupkan, semua lampiran yang pemeriksaannya gagal akan ditolak.';
$helptxt['attachment_autorotate'] = 'Selecting this option will allow the system to detect rotated images, typical of phone cameras, and automatically adjust the orientation such that the image top is oriented up. Requires either ImageMagick or both GD and Exif modules to be available.';
$helptxt['attachmentShowImages'] = 'If the uploaded file is a picture, this will automatically display it underneath the post.';
$helptxt['attachmentThumbnails'] = 'Enable this to show post images as a smaller thumbnail image, which when selected will expand to the full sized image.';
$helptxt['attachment_thumb_png'] = 'When creating thumbnails to display under a post, this will only create them as png files.';
$helptxt['attachmentThumbWidth'] = 'Only used with the &quot;Resize images when showing under posts&quot; option, the maximum width to resize attachments down from.  They will be resized proportionally.';
$helptxt['attachmentThumbHeight'] = 'Only used with the &quot;Resize images when showing under posts&quot; option, the maximum height to resize attachments down from.  They will be resized proportionally.';
$helptxt['attachment_image_reencode'] = 'Memilih pilihan ini akan membenarkan percubaan untuk mengekod lampiran imej yang dimuatnaik. Pengekodan imej menawarkan keselamatan yang lebih baik. Perhatikan bahawa pengekodan imej juga membolehkan semua imej beranimasi menjadi statik. <br /> Ciri ini boleh digunakan hanya jika modul GD dipasang pada server anda.';
$helptxt['attachment_thumb_memory'] = 'The larger the source image (size & width x height), the higher the memory requirements are for the system to successfully create a thumbnail image.<br />With this option checked, the system will estimate the required memory and will then request that amount.  If successful, only then will it attempt to create the thumbnail.<br />This will result in fewer white screen errors but may result in fewer thumbnails being created.  If you leave this option unchecked, the system will always try to create the thumbnail (with a fixed amount of memory).  This may result in more white screen errors.';
$helptxt['max_image_height'] = 'The maximum displayed height of an attached image.';
$helptxt['max_image_width'] = 'Ini mengizinkan anda untuk mengatur ukuran maksima untuk gambar yang dipos. Gambar lebih kecil dari maksima tidak akan dipengaruhi.';
$helptxt['attachmentUploadDir'] = 'Select where you want the files uploaded to be stored on your server. This can be located outside your public html directory for additional security.';
$helptxt['attachment_transfer_empty'] = 'Enabling this will move all the files from the source directory to the new location, otherwise only the maximum allowed number of files according to the per-directory setting will be moved.';
$helptxt['avatar_paranoid'] = 'Memilih pilihan ini akan membolehkan pemeriksaan keselamatan yang paling ketat pada avatar. Amaran! Pemeriksaan mendalam juga boleh gagal pada imej yang sah. Pilihan ini dicadangkan untuk digunakan hanya bersama pengekodan semula avatar, bagi membolehkan SMF cuba mencontohi imej yang gagal pemeriksaan keselamatan: jika berjaya, ia akan dibersihkan dan dimuatnaik. Sebaliknya, jika pengekodan semula avatar tidak diaktifkan, semua pemeriksaan avatar yang gagal akan ditolak.';
$helptxt['avatar_reencode'] = 'Memilih pilihan ini akan membolehkan percubaan mengekod semula avatar yang dimuatnaik. Pengekodan imej menawarkan keselamatan yang lebih baik. Perhatikan bahawa pengekodan imej juga menjadikan semua imej beranimasi menjadi statik. <br /> Ciri ini hanya boleh digunakan jika modul GD dipasang pada server anda.';
$helptxt['karmaMode'] = 'Karma adalah ciri yang memaparkan populariti ahli. Ahli, jika diizinkan, boleh melakukan
		\'applaud\' atau \'smite\' ahli lain, dengan cara ini populariti dihitung. anda dapat mengubah jumlah pos yang diperlukan untuk mempunyai &quot;karma&quot;, waktu antara smite atau applaud, dan jika Pengurus
		mesti menunggu waktu ini juga.<br /><br />Apakah grup ahli dapat melakukan smite yang lain di kawalan oleh
		sebuah keizinan.  Jika anda mengalami masalah agar ciri ini bekerja untuk setiap orang, klik ganda keizinan anda.';
$helptxt['localCookies'] = 'Sistem menggunakan biskut untuk menyimpan info masuk pada komputer pengguna.
	Biskut dapat disimpan secara global (ahrasis.com) atau secara lokal (ahrasis.com/laluan/ke/forum).<br />
	Tanda pilihan ini jika anda mengalami masalah boleh pengguna dikeluarkan secara automatik.<hr />
	Biskut yang disimpan secara global kurang selamat apabila diguna pada server web yang dikongsi (seperti Tripod).<hr />
	Biskut dalaman tidak berfungsi di luar folder forum, maka jika forum anda disimpan di www.ahrasis.com/forum, laman seperti www.ahrasis.com/index.php tidak boleh mengakses informasi akaun.
	Terutama ketika menggunakan SSI.php, biskut global disarankan.';
$helptxt['enableBBC'] = 'Memilih pilihan ini akan membolehkan ahli anda untuk menggunakan Kod Ruangan Buletin (BBC) pada forum, mengizinkan pengguna untuk membentuk posnya dengan gambar, jenis format dan lain-lain.';
$helptxt['time_offset'] = 'Tidak semua Pengurus forum mengmahukan forumnya menggunakan zon waktu yang sama seperti server di mana ia ditempatkan. Gunakan pilihan ini untuk menetapkan perbedaan waktu (dalam jam) di mana forum semestinya beroperasi dari waktu server. Nilai desimal negatif diperbolehkan.';
$helptxt['default_timezone'] = 'Zon waktu server memberitahu PHP di mana server anda ditempatkan. anda mesti pastikan bahawa ia diatur dengan betul, terutamanya di negara/negeri mana ia berada. anda boleh mendapatkan maklumat lanjut di <a href="http://www.php.net/manual/en/timezones.php" target="_blank">Laman PHP</a>.';
$helptxt['spamWaitTime'] = 'Di sini anda dapat memilih jumlah waktu yang mesti dilalui di antara penulisan. Ini boleh dipakai untuk menghentikan orang atas "spamming" forum anda dengan membatasi berapa kerap mereka mengepos.';

$helptxt['enablePostHTML'] = 'Ini akan membenarkan sebahagian tag HTML asas:
	<ul style="margin-bottom: 0;">
		<li>&lt;b&gt;, &lt;u&gt;, &lt;i&gt;, &lt;s&gt;, &lt;em&gt;, &lt;ins&gt;, &lt;del&gt;</li>
		<li>&lt;a href=&quot;&quot;&gt;</li>
		<li>&lt;img src=&quot;&quot; alt=&quot;&quot; /&gt;</li>
		<li>&lt;br /&gt;, &lt;hr /&gt;</li>
		<li>&lt;pre&gt;, &lt;blockquote&gt;</li>
	</ul>';

// Initial theme settings - Manage and Install
$helptxt['themes'] = 'Di sini anda dapat memilih apakah tema default dapat dipilih, tema apa yang akan dipakai tetamu,
	juga pilihan lainnya. Klik pada tema di kanan untuk mengubah setelannya.';
$helptxt['theme_install'] = 'This section permits you to install new themes. You do this by uploading an archived file for the theme from your personal computer, installing from a theme directory on the host server or by copying the default theme and renaming that copied file.<br /><br />Please remember this: the archived file or directory must have a <span class="alert">theme_info.xml</span> definition file as a part of the archive or the directory.';
$helptxt['theme_forum_theme'] = 'Changing the overall forum default does not affect members that have selected another available theme. You must also \'Reset\' all members to force them to the new forum default. You can also set a forum default theme that is seen by guests and then reset members to a different theme. <br /><br />Remember that when permitted to select their own themes, members can overide the theme set by you.';

// Theme Management and Options - Theme settings
$helptxt['themeadmin_list_reset'] = 'On rare occasions the path to the theme will be lost and your forum will not display properly. This may be due to a mistake by an Admin, database errors, failed software updates, mod installations or some other event. Resetting the themes URLs and directories will usually fix this problem.';
$helptxt['themeadmin_delete_help'] = 'The default theme cannot be deleted as doing so would break your forum and would break other themes. However, you can delete any theme that has the red \'X\' next to it by clicking on that \'X\'. <br /><br /> Remember this: Deleting a theme does not remove it from the server, it only removes the themes availability to be used on the forum. You will need to FTP into your server or use the host provided panel to remove the custom theme from the server. Do not ever delete the theme named \'default\'.';

$helptxt['enableVideoEmbeding'] = 'This allows automatic conversion of standard URLs into an embedded video when the post is viewed.  Currently only supports YouTube, Vimeo and Dailymotion video links';
$helptxt['enableCodePrettify'] = 'This will load the Prettify script which will color highlight code used in code tags.  It adds styles to code snippets so that tokens stand out and your users can more easily read the code.';
// @todo Add more information about how to use them here.
$helptxt['xmlnews_enable'] = 'Mengizinkan orang untuk menghubungkan ke <a href="%s?action=.xml;sa=news">Berita terbaru</a>
	dan data yang serupa.  anda disarankan membatasi ukuran pos/berita terbaru kerana ketika data rss
	dipaparkan dalam beberapa pengguna, seperti Trillian, ia diharapkan terpotong.';
$helptxt['hotTopicPosts'] = 'Mengubah jumlah pos untuk topik guna mencapai kondisi topik &quot;hangat&quot; atau
	&quot;panas&quot;.';
$helptxt['globalCookies'] = 'Membuat log dalam cookie tersedia menyeberangi subdomain.  Sebagai contoh, jika...<br />
	Laman anda ada di http://www.simplemachines.org/,<br />
	Dan forum anda ada di http://forum.simplemachines.org/,<br />
	Menggunakan pilihan ini akan mengizinkan anda untuk mengakses cookie forum pada laman anda.  Jangan hidupkan ini jika ada subdomain lain (seperti hacker.simplemachines.org) yang tidak dikawalan oleh anda.';
$helptxt['globalCookiesDomain'] = 'Define the main domain to be used when login cookies are available across subdomains';
$helptxt['httponlyCookies'] = 'With this setting on, cookies will not be accessible by scripting languages, such as JavaScript. This setting can help to reduce identity theft through XSS attacks. This may cause issues with some third party scripts but is recommended to be on when possible.';
$helptxt['secureCookies'] = 'Mengaktifkan pilihan ini akan memaksa membuat cookie bagi pengguna forum anda agar dikenali sebagai selamat. Aktifkan pilihan ini hanya jika anda menggunakan HTTPS pada laman anda kerana ia akan mengganggu cookie jika sebaliknya.';
$helptxt['admin_session_lifetime'] = 'This controls the length of time an admin session can remain active. Once this timer expires the session will end, requiring you to enter your admin credentials to continue accessing the admin area. The minimum value is 5 minutes, the maximum allowed value is 14400 minutes (equals a day). It is strongly recommended to use a value less than 60 minutes for security reasons.';
$helptxt['auto_admin_session'] = 'This controls whether an administrative session is activated during logon or not.';
$helptxt['securityDisable'] = 'Ini <em>mematikan</em> pemeriksaan kata kunci tambahan untuk bahagian Pengurusan. Ini tidak disarankan!';
$helptxt['securityDisable_why'] = 'Ini adalah kata kunci anda saat ini. (hal yang sama yang anda pakai untuk masuk.)<br /><br />Daripada mengetik, ini membantu meyakinkan bahawa anda mahu melakukan Pengurusan apapun yang anda kerjakan, yakni adalah <strong>Anda</strong> yang mengerjakannya.';
$helptxt['securityDisable_moderate'] = 'This <em>disables</em> the additional password check for the moderation section. This is not recommended!';
$helptxt['securityDisable_moderate_why'] = 'This is your current password. (the same one you use to login.)<br /><br />Having to type this helps ensure that you want to do whatever moderation you are doing, and that it is <strong>you</strong> doing it.';
$helptxt['enableOTP'] = 'Enabling this feature allows another layer of security for a member\'s account. Two-factor authentication, or 2FA, is a way of logging into websites that requires more than just a password. Using a password to log into a website is susceptible to security threats, because it represents a single piece of information a malicious person needs to acquire. The added security that 2FA provides is requiring additional information to sign in.<br /><br />A Time-based One-Time Password (TOTP) application such as Google Authenticator or Authy automatically generates an authentication code that changes after a certain period of time.';
$helptxt['emailmembers'] = 'Dalam mesej ini anda boleh menggunakan beberapa &quot;pembolehubah&quot;.  Ini adalah:<br />
	{$board_url} - URL ke forum anda.<br />
	{$current_time} - Waktu semasa.<br />
	{$member.email} - Email ahli semasa.<br />
	{$member.link} - Link ahli semasa.<br />
	{$member.id} - ID ahli semasa.<br />
	{$member.name} - Nama ahli semasa.  (untuk personalisasi.)<br />
	{$latest_member.link} - Link ahli mendaftar paling baru.<br />
	{$latest_member.id} - ID ahli mendaftar paling baru.<br />
	{$latest_member.name} - Nama ahli mendaftar paling baru.';
$helptxt['attachmentEncryptFilenames'] = 'Mengenkripsi nama fail lampiran mengizinkan anda untuk memiliki lebih dari satu lampiran dengan
	nama yang sama, untuk menggunakan fail .php yang aman untuk lampiran, dan tingginya sekuriti.  Akan tetapi, boleh menyulitkan
	untuk membangun semula database anda jika sesuatu yang mengejutkan berlaku.';

$helptxt['failed_login_threshold'] = 'Mengatur jumlah percubaan gagal masuk sebelum mengalihkan pengguna ke layar pengingat kata kunci.';
$helptxt['loginHistoryDays'] = 'The number of days to keep login history under user profile history. Default is 30 days.';
$helptxt['oldTopicDays'] = 'Jika pilihan ini diaktifkan, peringatan akan dipaparkan ke pengguna saat mencuba menjawab ke topik yang tidak memiliki jawapan baru dalam beberapa waktu, dalam hari, ditetapkan dengan mengatur ini. Aturan ini menjadi 0 untuk mematikan ciri.';
$helptxt['edit_wait_time'] = 'Jumlah saat diizinkan untuk pos yang diedit sebelum masuk ke tarikh edit terakhir.';
$helptxt['edit_disable_time'] = 'Jumlah minit diizinkan berlalu sebelum pengguna tidak lagi mengedit pos yang telah dibuatnya. Aturan ke 0 untuk mematikan. <br /><br /><em>Catatan: Ini tidak mempengaruhi setiap pengguna yang mempunyai keizinan untuk mengedit pos orang lain.</em>';
$helptxt['preview_characters'] = 'This option sets the number of available characters for the first and last message of the topic preview.  <strong>Note</strong> this only makes the information available to the theme, the theme must support the &quot;Show post previews on the message index&quot; setting';
$helptxt['posts_require_captcha'] = 'Tetapan ini memaksa pengguna melepasi verifikasi anti-spam setiap kali mereka mengepos pada sesuatu ruangan. Hanya pengguna dengan jumlah pos di bawah jumlah yang ditetapkan perlu memasukan kod ini - ini membantu memerangi skrip spam automatik.';
$helptxt['enableSpellChecking'] = 'Enable spell checking. You MUST have the pspell library installed on your server and your PHP configuration set up to use the pspell library. Your server ' . (function_exists('pspell_new') ? 'DOES' : 'DOES NOT') . ' appear to have this set up.';
$helptxt['lastActive'] = 'Tetapkan jumlah minit daripada aktiviti terakhir bagi memaparkan orang yang aktif dalam indeks utama. Asal ialah 15 minit.';

$helptxt['customoptions'] = 'Bahagian ini mendefinisikan pilihan yang boleh dipilih pengguna dari daftar drop down. Ada beberapa mata kunci untuk dicatat dalam bahagian ini:
	<ul>
		<li><strong>Pilihan Default:</strong> Kotak pilihan mana saja yang mempunyai &quot;butang radio&quot; di sebelahnya dipilih akan menjadi pilihan default bagi pengguna ketika mereka masuk ke profilnya.</li>
		<li><strong>Pilihan Padam:</strong> Untuk memadam sebuah pilihan cukup kosongkan kotak teks pada pilihan itu - semua pilihan pengguna dengan pilihan itu akan dipadam.</li>
		<li><strong>Pilihan Edit:</strong> anda dapat mengedit semula pilihan dengan memindahkan teks diantara kotak. Akan tetapi - catatan penting - anda mesti memastikan bahawa anda <b>tidak</b> mengubah teks ketika mengedit semula pilihan kerana data pengguna akan hilang.</li>
	</ul>';

$helptxt['autoOptDatabase'] = 'Pilihan ini mengoptimakan database setiap beberapa hari.  Aturan jadi 1 untuk optimasi harian.  anda juga boleh menetapkan jumlah maksima pengguna online agar server anda tidak terlebih beban atau mesej terlalu banyak pengguna.';
$helptxt['autoFixDatabase'] = 'Ini secara automatik akan membetulkan table yang rosak dan kembali lagi seperti tidak ada yang terjadi.  Ini berguna kerana satu-satunya cara untuk membetulkan adalah dengan membaiki table, dan cara ini forum tidak akan mati sampai anda perhatikan.  Ia mengirimkan email kepada anda ketika ini terjadi.';

$helptxt['enableParticipation'] = 'Ini memaparkan ikon kecil pada topik yang dipos pengguna.';
$helptxt['enableFollowup'] = 'This allows members to start new topics quoting the text of any message.';

$helptxt['db_persist'] = 'Memelihara sambungan aktif untuk meningkatkan persembahan.  Jika anda tidak pada server sendiri, ini boleh menyebabkan masalah dengan host anda.';
$helptxt['ssi_db_user'] = 'Aturan pilihan untuk memakai nama pengguna dan kata kunci database berbeza saat anda menggunakan SSI.php.';

$helptxt['queryless_urls'] = 'This changes the format of URLs a little so search engines will like them better.  They will look like index.php/topic,1.0.html.';
$helptxt['countChildPosts'] = 'Menanda pilihan ini bererti pos dan topik dalam ruangan anak akan dihitung jumlahnya pada laman indeks.<br /><br />Ini akan menjadikannya cukup lambat, tetapi bererti bahawa induk yang tidak berisi pos tidak akan memaparkan \'0\'.';
$helptxt['allow_ignore_boards'] = 'Menanda pilihan ini mengizinkan pengguna2 untuk memilih ruangan yang mahu diabaikan.';
$helptxt['deny_boards_access'] = 'Checking this option will allow you to deny access to certain boards based on membergroup access';

$helptxt['who_enabled'] = 'Pilihan ini mengizinkan anda untuk mengaktifkan atau mematikan kemampuan pengguna untuk melihat siapa yang sedang melihat forum dan apa yang mereka lakukan.';

$helptxt['recycle_enable'] = '&quot;Kitar Semula&quot; topik dan pos yang dipadam ke ruangan yang ditetapkan.';

$helptxt['enableReportPM'] = 'Pilihan ini mengizinkan pengguna anda untuk melaporkan mesej peribadi yang mereka terima ke pasukan Pengurusan. Ini berguna dalam membantu merekod setiap penyerangan sistem mesej peribadi.';
$helptxt['max_pm_recipients'] = 'Pilihan ini mengizinkan anda untuk mengatur jumlah penerima maksima yang diperbolehkan dalam satu mesej peribadi dikirimkan oleh ahli forum. Ini boleh dipakai untuk membantu menghentikan serangan spam pada sistem mesej. Catatan bahawa pengguna dengan keizinan untuk mengirimkan surat berkala dikecualikan dari batasan ini. Aturan sifar untuk tanpa batas.';
$helptxt['pm_posts_verification'] = 'Aturan ini akan memaksa pengguna untuk memasukan kod yang dipaparkan pada gambar pengesahan setiap kali mereka mengirimkan mesej peribadi. Hanya pengguna dengan jumlah pos di bawah angka yang diatur yang perlu memasukan kod - ini akan membantu memerangi naskhah spam automatik.';
$helptxt['pm_posts_per_hour'] = 'Ini akan membatasi jumlah mesej peribadi yang dikirimkan oleh pengguna dalam masa satu jam. Ini tidak mempengaruhi pengurus atau penyelia.';

$helptxt['default_personal_text'] = 'Mengatur teks default yang dimiliki pengguna sebagai &quot;teks peribadi.&quot;';

$helptxt['modlog_enabled'] = 'Log semua tindakan seliaan.';

$helptxt['registration_method'] = 'Pilihan ini menentukan cara apa pendaftaran dipakai untuk orang yang mahu menyertai forum anda. anda dapat memilih dari:<br /><br />
	<ul class="normallist">
		<li>
			<strong>Pendaftaran Dimatikan</strong><br />
				Mematikan proses pendaftaran, yang bererti bahawa tiada ahli baru boleh mendaftar untuk menyertai forum anda.<br />
		</li><li>
			<strong>Pendaftaran Terus</strong><br />
				Ahli baru dapat masuk dan mengepos terus setelah mendaftar dengan forum anda.<br />
		</li><li>
			<strong>Pengaktifan Emel</strong><br />
				Ketika pilihan ini diaktifkan mana-mana ahli yang mendaftar dengan forum akan menerima pautan pengaktifan dikirimkan kepada mereka yang mereka perlu klik sebelum mereka boleh menjadi ahli penuh.<br />
		</li><li>
			<strong>Kelulusan Pengurusan</strong><br />
				Pilihan ini akan menjadikan setiap ahli baru yang mendaftar dengan forum anda perlu diluluskan oleh pengurusan sebelum mereka menjadi ahli penuh.
		</li>
	</ul>';
$helptxt['register_openid'] = '<strong>Pengesahan dengan OpenID</strong><br /> OpenID bererti menggunakan satu nama pengguna untuk website yang berbeza-beza, guna menyederhanakan pengalaman online. Untuk menggunakan OpenID pertama anda perlu membuat akaun OpenID - daftar penyedia boleh ditemukan pada <a href="http://openid.net/" target="_blank">Laman Rasmi OpenID</a><br /><br /> Apabila anda memiliki akaun OpenID, cukup masukkan URL identifikasi unik anda ke dalam kotak input OpenID. Selanjutnya anda akan dibawa ke laman penyedia untuk mengesahkan identiti anda sebelum kembali ke laman ini.<br /><br /> Pada kunjungan pertama ke laman ini, anda akan ditanya untuk mengesahkan beberapa butiran sebelum anda dikenal, setelah itu anda boleh masuk ke laman ini dan mengubah aturan profil anda dengan menggunakan OpenID anda.<br /><br /> Untuk informasi lebih lengkap sila kunjungi <a href="http://openid.net/" target="_blank">Laman Rasmi OpenID</a>';

$helptxt['send_validation_onChange'] = 'Ketika pilihan ini ditanda semua ahli yang mengubah alamat emailnya dalam profilnya mesti mengaktifkan semula akaunnya dari email yang dikirimkan ke alamat itu';
$helptxt['send_welcomeEmail'] = 'Ketika pilihan ini diaktifkan semua ahli akan dikirim email penyambutan mereka pada komuniti anda';
$helptxt['password_strength'] = 'Aturan ini menentukan kekuatan kata kunci yang dipilih oleh pengguna forum anda. Semakin kuat kata kunci, semakin sulit untuk membongkar akaun ahli.
	Kemungkinan pilihannya adalah:
	<ul>
		<li><strong>Rendah:</strong> Panjang kata kunci mesti setidaknya empat karakter.</li>
		<li><strong>Medium:</strong> Panjang kata kunci mesti setidaknya delapan karakter, dan bukan bagian dari nama pengguna atau alamat email.</li>
		<li><strong>Tinggi:</strong> Seperti medium, kecuali kata kunci juga mesti berisi campuran huruf besar dan kecil, dan setidaknya satu angka.</li>
	</ul>';
$helptxt['enable_password_conversion'] = 'By enabling this setting, ElkArte will attempt to detect passwords stored in other formats and convert them for use in this software.  Typically this is used for converted forums, but may have other uses as well.  Disabling this prevents a user from logging in using their password after a conversion and would need to reset their password.';

$helptxt['coppaAge'] = 'Nilai yang ditetapkan dalam kotak ini akan menentukan usia minima di mana ahli baru diberi akses langsung ke forum.
	Semasa pendaftaran mereka akan ditanya sebagai pengesahan usia, dan jika permintaan mereka ditolak atau ditunda menunggu persetujuan ibubapa/penjaga - tergantung pada jenis batasan yang dipilih.
	Jika nilai 0 yang dipilih untuk aturan ini maka semua pembatasan usia akan diabaikan.';
$helptxt['coppaType'] = 'Jika pembatasan usia diaktifkan, maka aturan ini akan mendefinisikan jika pengguna di bawah usia minima cuba untuk mendaftar pada forum anda, ada dua kemungkinan pilihan:
	<ul>
		<li>
			<strong>Tolak Pendaftaran Mereka:</strong><br />
				Setiap ahli baru di bawah usia minima ditolak pendaftarannya secara langsung.<br />
		</li><li>
			<strong>Diperlukan Persetujuan Ibubapa/Penjaga</strong><br />
				Setiap ahli baru yang mencuba untuk mendaftar dan di bawah usia minima yang diperbolehkan memiliki tanda menunggu persetujuan, dan akan disediakan dengan satu borang setelah ibubapa/penjaganya memberi keizinan untuk menjadi ahli forum.
				Mereka juga akan disediakan dengan butiran kontak forum pada laman aturan, agar mereka dapat mengirimkan borang ke Pengurus dengan surat atau fax.
		</li>
	</ul>';
$helptxt['coppaPost'] = 'Kotak kontak diperlukan agar borang itu mendapat keizinan untuk pendaftaran di bawah umur yang boleh dikirimkan ke Pengurus forum. Butiran ini akan dipaparkan ke semua minor baru, dan diperlukan persetujuan dari ibubapa/penjaga. Setidaknya alamat pos atau nombor fax mesti disediakan.';

$helptxt['allow_hideOnline'] = 'Dengan mengaktifkan pilihan ini semua ahli boleh menyembunyikan status online mereka daripada pengguna lain (kecuali pengurus). Jika dimatikan, hanya pengguna yang menyelia forum boleh menyembunyikan statusnya. Catatan bahawa mematikan pilihan ini tidak akan mengubah status semasa setiap ahli - ia hanya menghentikan mereka dari menyembunyikan diri mereka di masa hadapan.';

$helptxt['latest_support'] = 'Panel ini memaparkan kepada anda beberapa masalah paling umum dan pertanyaan pada tetapan server anda. Jangan risau, informasi ini tidak dicatat atau apapun.<br /><br />Jika ini tetap ada seperti &quot;Mengambil informasi sokongan...&quot;, komputer anda mungkin tidak boleh menyambung ke <a href="http://www.simplemachines.org/" target="_blank">www.simplemachines.org</a>.';
$helptxt['latest_packages'] = 'Here you can see some of the most popular and some random packages, with quick and easy installations.<br /><br />If this section doesn\'t show up, your computer probably cannot connect to <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.';
$helptxt['latest_themes'] = 'This area shows a few of the latest and most popular themes from <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.  It may not show up properly if your computer can\'t find <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>, though.';

$helptxt['secret_why_blank'] = 'Untuk sekuriti anda, jawapan pertanyaan anda (juga kata kunci anda) dienkripsi dengan cara di mana hanya SMF yang boleh mengatakan kepada anda jika anda memperolehnya dengan betul, maka ia tidak pernah mengatakan kepada anda (atau orang lain, yang terpenting!) apa jawapan atau kata kunci anda.';
$helptxt['moderator_why_missing'] = 'Kerana seliaan berfungsi atas dasar ruangan, anda mesti menjadikan ahli penyelia dari <a href="%1$s?action=admin;area=manageboards" target="_blank" class="new_win">fungsi pengurusan ruangan</a>.';

$helptxt['permissions'] = 'Keizinan adalah cara anda mengizinkan untuk atau menghalang grup daripada, melakukan perkara tertentu.<br /><br />Anda boleh mengubah beberapa ruangan sekaligus dengan kotak tanda, atau melihat keizinan untuk grup tertentu dengan klik \'Ubah.\'';
$helptxt['permissions_board'] = 'Jika ruangan ditetapkan sebagai \'Global,\' itu bererti bahawa ruangan tidak akan mempunyai keizinan khusus.  \'Lokal\' bererti ia mempunyai keizinan sendiri - berbeza daripada global.  Ini membolehkan anda untuk mempunyai ruangan yang memiliki lebih atau kurang keizinan daripada yang lain, tanpa memerlukan anda menetapkannya bagi setiap satu papan.';
$helptxt['permissions_quickgroups'] = 'Ini mengizinkan anda untuk menggunakan keizinan &quot;asal&quot; - lazim bererti \'tidak ada yang khusus\', terhad bererti \'seperti tetamu\', penyelia bererti \'apa yang dimiliki penyelia\', dan yang terakhir \'penyelenggaraan\' bererti keizinan yang hampir sama dengan pengurus.';
$helptxt['permission_enable_deny'] = 'Menolak keizinan boleh membantu ketika anda mahu mengambil keizinan dari ahli tertentu. anda boleh menambah grup ahli dengan keizinan-\'tolak\' ke ahli yang mahu anda tolak keizinannya.<br /><br />Gunakan dengan hati-hati, keizinan yang ditolak akan tetap ditolak tanpa mempedulikan di grup ahli mana seorang ahli itu menyertai.';
$helptxt['permission_enable_postgroups'] = 'Mengaktifkan keizinan untuk grup berasaskan jumlah pos akan mengizinkan anda untuk memberi nilai keizinan ke ahli yang telah mengepos dalam jumlah mesej tertentu. Keizinan grup berasaskan pos <em>ditambahkan</em> ke keizinan grup ahli biasa.';
$helptxt['membergroup_guests'] = 'Grup ahli Tetamu adalah semua pengguna yang tidak login masuk.';
$helptxt['membergroup_regular_members'] = 'Grup ahli Berdaftar Biasa adalah seluruh ahli yang masuk, tapi tidak memiliki grup ahli utama yang disediakan.';
$helptxt['membergroup_administrator'] = 'Pengurus boleh, didefinasikan, melakukan apa saja dan melihat setiap ruangan. Justeru, tidak ada tetapan keizinan untuk pengurus.';
$helptxt['membergroup_moderator'] = 'Grup Penyelia adalah grup ahli khusus. Keizinan dan tetapan yang diberikan bagi grup ini diguna pada penyelia tetapi hanya <em>pada papan yang mereka moderasi</em>. Di luar ruangan ini mereka hanyalah seperti ahli lain.';
$helptxt['membergroups'] = 'Dalam SMF, ada dua jenis grup di mana ahli boleh menjadi sebahagian darinya. Ini adalah:
	<ul>
		<li><strong>Grup Biasa:</strong> Grup biasa adalah grup di mana ahli tidak secara automatik masuk ke dalamnya. Untuk menempatkan ahli ke dalam grup cukup pergi ke profilnya dan klik &quot;Aturan Akaun&quot;. Dari sini anda dapat menempatkannya ke sejumlah grup biasa di mana mereka akan menjadi bagian dari grup.</li>
		<li><strong>Grup Pos:</strong> Tidak seperti grup biasa, grup pos tidak boleh ditempatkan. Sebaliknya, ahli secara automatik ditempatkan ke grup berasaskan pos ketika mereka mencapai jumlah minima pos yang diperlukan agar berada dalam grup itu.</li>
	</ul>';

$helptxt['calendar_how_edit'] = 'Anda dapat mengedit acara ini dengan mengklik pada bintang merah (*) di sebelah namanya.';

$helptxt['maintenance_backup'] = 'kawasan ini mengizinkan anda untuk menyimpan pendua dari semua pos, aturan, ahli, dan informasi lain dalam forum anda ke fail yang sangat besar.<br /><br />Disarankan untuk selalu melakukan ini, barangkali mingguan, untuk sekuriti.';
$helptxt['maintenance_rot'] = 'Ini mengizinkan anda untuk memadam topik lama <strong>sepenuhnya</strong> dan <strong>tidak boleh dikembalikan</strong> dari forum anda.  Disarankan bahawa anda mencuba untuk membuat backup lebih dulu seandainya anda memadam sesuatu yang tidak anda maksudkan.<br /><br />Gunakan pilihan ini dengan hati-hati.';
$helptxt['maintenance_members'] = 'Ini mengizinkan anda untuk memadam akaun ahli <strong>sepenuhnya</strong> dan <strong>tidak boleh dikembalikan</strong> dari forum anda.  <strong>Sangat</strong> disarankan bahawa anda mencuba untuk membuat backup lebih dulu seandainya anda memadam sesuatu yang tidak anda maksudkan.<br /><br />Gunakan pilihan ini dengan hati-hati.';

$helptxt['avatar_default'] = 'With this option enabled, a default avatar is shown for all users without their own avatar. The file named \'default_avatar.png\' is located in the images folder inside the themes directory.';
$helptxt['avatar_server_stored'] = 'Ini mengizinkan ahli anda untuk mengambil avatar yang disimpan pada server anda sendiri.  Umumnya di tempat yang sama seperti SMF di bawah folder avatar.<br />Sebagai tips, jika anda membuat direktori dalam folder itu, anda boleh membuat &quot;kategori&quot; avatar.';
$helptxt['avatar_external'] = 'Dengan mengaktifkan ini, ahli anda dapat mengetikkan URL ke avatarnya sendiri.  Kerugiannya adalah dalam banyak hal, mereka menggunakan avatar yang sangat besar atau gambar potret yang tidak anda mahukan dalam forum anda.';
$helptxt['avatar_download_external'] = 'Dengan mengaktifkan pilihan ini, URL yang diberikan oleh pengguna diakses untuk memuatturun avatar di lokasi itu. Bila sukses, avatar akan diperlakukan sebagai avatar yang dimuatnaik.';
$helptxt['avatar_upload'] = 'Pilihan ini lebih serupa &quot;Benarkan ahli untuk memilih avatar luar&quot;, kecuali bahawa anda mempunyai kawalan lebih terhadap avatar, waktu lebih baik mengukur semula, dan ahli anda tidak harus menyimpan avatar.<br /><br />Akan tetapi kekurangannya adalah bahawa ia memerlukan banyak ruang pada server anda.';
$helptxt['avatar_resize_options'] = 'This set of options apply to any avatar loaded to the server by users, either uploaded or retrieved from an external URL.';
$helptxt['avatar_download_png'] = 'PNG lebih besar, tapi menawarkan kualiti kompresi lebih baik.  Jika ini tidak ditanda, sebaliknya JPEG akan dipakai - yang selalu lebih kecil, tapi juga kualiti kurang dan agak suram.';
$helptxt['gravatar'] = 'Gravatar (globally recognized avatar) is a service for providing globally unique avatars. For more details please visit the Gravatar <a href="http://www.gravatar.com" target="_blank"><strong>website</strong>.</a>';
$helptxt['gravatar_rating'] = 'Gravatar allows users to self-rate their images so that they can indicate if an image is appropriate for a certain audience. By default, only \'G\' rated images are displayed unless you indicate that you would like to see higher ratings. <br /><br /><ul><li><strong>g:</strong> suitable for display on all websites with any audience type.</li><li><strong>pg:</strong> may contain rude gestures, provocatively dressed individuals, the lesser swear words, or mild violence.</li><li><strong>r:</strong> may contain such things as harsh profanity, intense violence, nudity, or hard drug use.</li><li><strong>x:</strong> may contain hardcore sexual imagery or extremely disturbing violence.</li></ul>';
$helptxt['custom_avatar_enabled'] = 'It is recommended that you enable this for best performance as it will reduce both the processor load, and database load when viewing pages with avatars.<br />You must enter both a publicly accessible directory to save avatars in and the publicly accessible URL for that directory.  For example a directory of /home/yourforumname/public_html/NewAvatarDirectory and an URL of http://www.yourforumname.com/NewAvatarDirectory';
$helptxt['disableHostnameLookup'] = 'Ini mematikan pencarian nama host yang pada beberapa server sangat lambat.  Catatan bahawa ini akan membuat sekatan kurang efektif.';

$helptxt['search_weight_commonheader'] = 'Weight factors are used to determine the relevancy of a search result. Change these weight factors to match the things that are specifically important for your forum. For instance, a forum of a news site might want a relatively high value for \'age of last matching message\'. All values are relative in relation to each other and should be positive integers.';
$helptxt['search_weight_frequency'] = 'Faktor keutamaan dipakai untuk menentukan berkaitan hasil pencarian. Mengubah faktor keutamaan ini agar sesuai dengan hal yang terutama penting bagi forum anda. Sebagai contoh, forum laman berita, mungkin mengmahukan nilai relatif tinggi untuk \'usia mesej terakhir yang sama\'. Semua nilai relatif dalam hubungan satu sama lainnya dan mesti berupa integer positif.<br /><br />Faktor ini menghitung jumlah mesej yang sama dan membahaginya dengan jumlah mesej di dalam topik.';
$helptxt['search_weight_age'] = 'Faktor keutamaan dipakai untuk menentukan berkaitan hasil pencarian. Mengubah faktor keutamaan ini agar sesuai dengan hal yang terutama penting bagi forum anda. Sebagai contoh, forum laman berita, mungkin mengmahukan nilai relatif tinggi untuk \'usia mesej terakhir yang sama\'. Semua nilai relatif dalam hubungan satu sama lainnya dan mesti berupa integer positif.<br /><br />Faktor ini merata-ratkan usia mesej terakhir yang sama di dalam topik. Semakin baru mesej ini, semakin tinggi nilainya.';
$helptxt['search_weight_length'] = 'Faktor keutamaan dipakai untuk menentukan berkaitan hasil pencarian. Mengubah faktor keutamaan ini agar sesuai dengan hal yang terutama penting bagi forum anda. Sebagai contoh, forum laman berita, mungkin mengmahukan nilai relatif tinggi untuk \'usia mesej terakhir yang sama\'. Semua nilai relatif dalam hubungan satu sama lainnya dan mesti berupa integer positif.<br /><br />Faktor ini didasarkan pada ukuran topik. Semakin banyak mesej di dalam topik, semakin tinggi nilainya.';
$helptxt['search_weight_subject'] = 'Faktor keutamaan dipakai guna menguji berkaitan hasil pencarian. Ubah faktor keutamaan ini agar sesuai dengan kepentingan forum anda. Sebagai contoh, forum laman berita, mungkin mengmahukan nilai relatif lebih tinggi atas \'usia mesej yang sama\'. Semua nilai adalah relatif dalam hubungan yang satu denga  yang lain dan mesti integer positif.<br /><br />Faktor ini melihat apakah batasan pencarian boleh ditemukan di dalam subyek topik.';
$helptxt['search_weight_first_message'] = 'Faktor keutamaan dipakai untuk menentukan berkaitan hasil pencarian. Mengubah faktor keutamaan ini agar sesuai dengan hal yang terutama penting bagi forum anda. Sebagai contoh, forum laman berita, mungkin mengmahukan nilai relatif tinggi untuk \'usia mesej terakhir yang sama\'. Semua nilai relatif dalam hubungan satu sama lainnya dan mesti berupa integer positif.<br /><br />Faktor ini mencari apakah yang sama boleh ditemukan dalam mesej pertama pada topik.';
$helptxt['search_weight_sticky'] = 'Faktor keutamaan dipakai untuk menentukan berkaitan hasil pencarian. Ubah faktor keutamaan ini untuk menyesuaikan hal yang penting terutama untuk forum anda. Sebagai contoh, forum laman berita mungkin mahu memberi nilai relatif tinggi untuk \'usia mesej terakhir yang sama\'. Seluruh nilai relatif dalam hubungannya dengan yang lain dan mesti integer positif.<br /><br />Faktor ini terlihat apakah topik diLekitkan dan meningkatkan skor berkaitan jika demikian.';
$helptxt['search_weight_likes'] = 'This factor looks whether a topic has likes and increases the relevancy score based on the number.';
$helptxt['search'] = 'Menyesuaikan semua aturan untuk fungsi pencarian di sini.';
$helptxt['search_why_use_index'] = 'Indeks pencarian dapat meningkatkan perlaksanaan pencarian pada forum anda. Terutama ketika jumlah mesej pada forum semakin besar, mencari tanpa indeks memerlukan waktu lama dan meningkatkan tekanan pada database anda. Jika forum anda lebih besar dari 50,000 mesej, anda mungkin mahu mempertimbangkan indeks pencarian untuk memastikan puncak perlaksanaan forum anda.<br /><br />Catatan bahawa indeks pencarian memerlukan beberapa ruang. Indeks teks lengkap adalah indeks built-in pada MySQL. Ia relatif kecil (tepatnya mempunyai ukuran yang sama seperti table mesej), tapi banyak kata tidak diindeks dan ia boleh dalam beberapa queri pencarian berubah menjadi sangat lambat. Indeks pilihan selalu lebih besar (bergantung pada tetapan anda, ia boleh mencapai 3 kali ukuran table mesej) tapi perlaksanaannya lebih baik daripada teks lengkap dan stabil secara relatif.';

$helptxt['see_admin_ip'] = 'Alamat IP dipaparkan ke pengurus dan penyelia untuk memudahkan penyeliaan dan menjejaki mereka yang jahat. Ingat, alamat IP tidak selalu tepat, dan kebanyakannya berubah dari semasa ke semasa.<br /><br />Ahli juga diizinkan untuk melihat IP miliknya sendiri.';
$helptxt['see_member_ip'] = 'Alamat IP anda dipaparkan hanya bagi anda dan penyelia.  Ingat bahawa informasi ini tidak selalu tepat, dan kebanyakan IP berubah dari semasa ke semasa.<br /><br />Anda tidak boleh melihat alamat IP ahli lain, dan mereka tidak boleh melihat IP anda.';
$helptxt['whytwoip'] = 'SMF menggunakan berbagai cara untuk mengesan alamat IP. Biasanya dua hasil cara dalam alamat yang sama dalam beberapa kes daripada satu alamat yang dapat dikesan. Dalam hal ini SMF mencatat kedua alamat ini, dan menggunakan keduanya untuk memeriksa sekatan (dll). anda boleh mengklik baik pada alamat untuk merekod IP itu mahupun sekatan bila perlu.';

$helptxt['ban_cannot_post'] = 'Batasan \'tidak boleh mengepos\' mengubah forum menjadikannya hanya boleh dibaca untuk pengguna yang disekat. Pengguna tidak boleh membuat topik baru, atau menjawab ke topik yang sudah ada, mengirim mesej peribadi atau memilih dalam undian. Akan tetapi pengguna yang disekat masih boleh membaca mesej peribadi serta topik.<br /><br />Pesan peringatan dipaparkan ke pengguna yang disekat dengan cara ini.';

$helptxt['posts_and_topics'] = '	<ul>
		<li>
			<strong>Tetapan Pos</strong><br />
			Mengubah tetapan berkaitan penulisan mesej dan cara mesej dipaparkan. Anda juga boleh mengaktifkan semakan ejaan di sini.
		</li><li>
			<strong>Kod Ruangan Buletin</strong><br />
			Mengaktifkan kod yang memaparkan mesej forum dalam rupa yang benar. Juga mengubahsuai kod yang diizinkan dan yang tidak.
		</li><li>
			<strong>Perkataan Ditapis</strong>
			Untuk mengawal penggunaan bahasa dalam forum, anda boleh menapis perkataan tertentu. Fungsi ini mengizinkan anda untuk mengubah kata terlarang kepada kata yang elok.
		</li><li>
			<strong>TetapanTopik</strong>
			Mengubah aturan berkaitan dengan topik. Jumlah topik satu laman, apakah topik lekit diaktifkan atau tidak, jumlah mesej yang diperlukan untuk topik hangat, dll.
		</li>
	</ul>';
$helptxt['allow_no_censored'] = 'When checked, this global setting allows members to disable word censoring in their User Profile through the Look and Layout settings. The members\' ablility to disable word censoring is still limited by their permission profile.';
$helptxt['spider_mode'] = 'Sets the logging level.<br />
Standard - Logs minimal spider activity.<br />
Moderate - Provides more accurate statistics.<br />
Aggressive - As for &quot;Moderate&quot; but logs data about each page visited.';

$helptxt['spider_group'] = 'Dengan memilih grup terbatas, ketika tetamu dikesan sebagai pemungut pencarian, ia akan secara automatik ditempati keizinan tolak &quot;deny&quot; atas grup ini sebagai tambahan terhadap keizinan normal tetamu. Anda dapat menggunakan ini untuk menyediakan akses terbatas pada mesin pencari seperti yang anda mahukan pada tetamu biasa. Anda boleh misalnya mahu membuat grup baru bernama &quot;Lelabah&quot; dan memilihnya di sini. Kemudian anda dapat menafikan keizinan grup itu untuk melihat profil dan menghentikan lelabah mengindeks profil ahli anda.<br />Catatan: Pencarian lelabah tidak sempurna dan dapat disimulasikan oleh pengguna, maka ciri ini tidak dijamin untuk membatasi hanya kandungan ke mesin pencari yang telah anda tambahkan.';
$helptxt['show_spider_online'] = 'Tetapan ini membolehkan anda untuk memilih apakah lelabah mesti didaftarkan dalam senarai siapa di talian pada indeks utama dan laman &quot;Siapa Di Talian&quot;. Pilihannya adalah:
	<ul class="normallist">
		<li>
			<strong>Tidak sama sekali</strong><br />
			Lelabah akan terlihat sebagai tetamu bagi semua pengguna.
		</li><li>
			<strong>Paparkan Jumlah Lelabah</strong><br />
			Indeks Utama akan memaparkan jumlah lelabah yang saat ini mengunjungi forum.
		</li><li>
			<strong>Paparkan Nama Lelabah</strong><br />
			Setiap nama lelabah akan dimunculkan, dengan demikian pengguna dapat melihat berapa banyak lelabah yang saat ini mengunjungi forum - ini berpengaruh baik pada Indeks Utama dan laman Siapa Di Talian.
		</li><li>
			<strong>Paparkan Nama Lelabah - Hanya Pengurus</strong><br />
			Seperti di atas kecuali hanya Pengurus yang boleh melihat status lelabah - bagi pengguna lain, lelabah terlihat sebagai tetamu.
		</li>
	</ul>';

$helptxt['birthday_email'] = 'Pilih indeks mesej emel hari jadi yang akan dipakai.  Tinjauan akan dipaparkan dalam petak tajuk dan isi emel.<br /><strong>Catatan:</strong> Menetapkan pilihan ini tidak akan mengaktifkan emel hari jadi secara automatik.  Untuk mengaktifkan emel hari jadi gunakan laman <a href="%1$s?action=admin;kawasan=maintain;sa=tasks;%3$s=%2$s" target="_blank" class="new_win">Jadual Tugas</a> dan hidupkan tugas emel hari jadi.';
$helptxt['pm_bcc'] = 'Ketika mengirimkan mesej peribadi, anda dapat memilih untuk menambah penerima seperti BCC atau &quot;Blind Carbon Copy&quot;. Penerima BCC tidak memunculkan identitinya ke penerima mesej lainnya.';

$helptxt['move_topics_maintenance'] = 'Ini membolehkan anda memindahkan semua pos dari satu ruangan ke ruangan yang lain.';
$helptxt['maintain_reattribute_posts'] = 'Anda boleh menggunakan fungsi ini untuk memberikan milikan pos2 tetamu pada ruangan anda kepada mana2 ahli berdaftar. Ini berguna jika, misalnya, seorang ahli memadam akaunnya dan menukar fikirannya, serta mahu memiliki pos lamanya dikembalikan kepada akaunnya.';
$helptxt['chmod_flags'] = 'Anda dapat mengatur keizinan secara manual sesuai yang dimahukan terhadap fail-fail yang dipilih. Untuk melakukan ini, masukkan nilai chmod sebagai nilai numerik (oktet). Catatan - flag ini tidak berpengaruh pada sistem operasi Microsoft Windows.';

$helptxt['postmod'] = 'Bahagian ini mengizinkan ahli pasukan seliaan (dengan keizinan yang cukup) untuk meluluskan setiap pos atau topik sebelum dipaparkan.';

$helptxt['field_show_enclosed'] = 'Encloses the user input between some text or HTML code.  This will allow you to add more instant message providers, images or an embed, etc. For example:<br /><br />
		&lt;a href="http://website.com/{INPUT}"&gt;&lt;img src="{DEFAULT_IMAGES_URL}/icon.png" alt="{INPUT}" /&gt;&lt;/a&gt;<br /><br />
		You can use the following variables:<br />
		<ul class="normallist">
			<li>{INPUT} - The input specified by the user.</li>
			<li>{KEY} - The key specified for a certain value of select box or radio buttons in the admin panel. Usually to use in case of localization or use in CSS of Javascript elements (e.g. as class name).</li>
			<li>{SCRIPTURL} - Web address of forum.</li>
			<li>{IMAGES_URL} - URI of the images directory of the user\'s current theme.</li>
			<li>{DEFAULT_IMAGES_URL} - URI of the images directory of the default theme.</li>
		</ul>';

$helptxt['custom_mask'] = 'Lapisan input penting bagi sekuriti forum anda. Mengesahkan input dari pengguna boleh membantu memastikan bahawa data tidak dipakai dengan cara yang tidak anda kehendakki. Kami telah menyediakan beberapa sebutan mudah biasa sebagai petunjuk.<br /><br /> <span class="smalltext"> &nbsp;&nbsp;"[A-Za-z]+" - Sama semua karakter huruf besar dan kecil.<br /> &nbsp;&nbsp;"[0-9]+" - Sama semua karakter numerik.<br /> &nbsp;&nbsp;"[A-Za-z0-9]{7}" - Sama semua huruf besar dan kecil dan karakter numerik sebanyak tujuh kali.<br /> &nbsp;&nbsp;"[^0-9]?" - Larang setiap angka yang sama.<br /> &nbsp;&nbsp;"^([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$" - Hanya mengizinkan 3 atau 6 karakter kod heksa.<br /> </span><br /><br /> Tambahan, karakter meta khusus ?+*^$ dan {xx} boleh didefinisikan. <span class="smalltext"> &nbsp;&nbsp;? - Tidak ada atau satu yang sama dengan sebutan sebelumnya.<br /> &nbsp;&nbsp;+ - Satu atau lebih sebutan sebelumnya.<br /> &nbsp;&nbsp;* - Tidak ada atau lebih sebutan sebelumnya.<br /> &nbsp;&nbsp;{xx} - Angka yang sama dari sebutan sebelumnya.<br /> &nbsp;&nbsp;{xx,} - Angka yang sama atau lebih dari sebutan sebelumnya.<br /> &nbsp;&nbsp;{,xx} - Angka yang serupa atau kurang dari sebutan sebelumnya.<br /> &nbsp;&nbsp;{xx,yy} - Sama serupa antara dua angka dari sebutan sebelumnya.<br /> &nbsp;&nbsp;$ - Awal string.<br /> &nbsp;&nbsp;^ - Akhir string.<br /> &nbsp;&nbsp;\\ - Melepasi karakter berikutnya.<br /> </span><br /><br /> Informasi lebih lengkap dan teknik lebih canggih boleh ditemui di internet.';

$helptxt['badbehavior_reverse_proxy_addresses'] = 'In some server farm configurations, Bad Behavior may be unable to determine whether a remote request originated from your reverse proxy/load balancer or arrived directly. In this case you should add all of the internal IP addresses for your reverse proxy/load balancer servers as seen from the origin server. These can usually be omitted; however if you have a configuration where some requests can bypass the reverse proxy/load balancer and connect to the origin server directly, then you should use this option. You should also use this option when incoming requests pass through two or more reverse proxies before reaching the origin server.<br /><br />Enter each IP address or CIDR netblocks separated by a | (1.2.3.4|5.4.3.2/27)';
$helptxt['badbehavior_reverse_proxy_header'] = 'When a reverse proxy is in use, Bad Behavior looks at this HTTP header to determine the actual source IP address for each web request. Your reverse proxy or load balancer must add an HTTP header containing the remote IP address where the connection originated. Most do this by default; check the configuration for your reverse proxy or load balancer to ensure that this header is sent.<br /><br />If you use the CloudFlare service, you should change this option to CF-Connecting-IP.';
$helptxt['badbehavior_reverse_proxy'] = 'When enabled, Bad Behavior will assume it is receiving a connection from a reverse proxy, when a specific HTTP header is received.';
$helptxt['badbehavior_httpbl_maxage'] = 'This is the number of days since suspicious activity was last observed from an IP address by Project Honey Pot. Bad Behavior will block requests with a maximum age equal to or less than this setting.';
$helptxt['badbehavior_httpbl_threat'] = 'This number provides a measure of how suspicious an IP address is, based on activity observed at Project Honey Pot. Bad Behavior will block requests with a threat level equal or higher to this setting. Project Honey Pot has <a href="http://www.projecthoneypot.org/threat_info.php" target="_blank">more information on this parameter</a>.';
$helptxt['badbehavior_httpbl_key'] = 'Bad Behavior is capable of using data from the <a href="http://www.projecthoneypot.org/faq.php#g" target="_blank">http:BL</a> service provided by <a href="http://www.projecthoneypot.org/" target="_blank">Project Honey Pot</a> to screen requests.<br /><br />This is purely optional; however if you wish to use it, you must <a href="http://www.projecthoneypot.org/httpbl_configure.php" target="_blank">sign up for the service</a> and obtain an API key. To disable http:BL use, remove the API key from your settings.';
$helptxt['badbehavior_verbose'] = 'Enabling verbose mode causes all HTTP requests to be logged. When verbose mode is off, only blocked requests and suspicious requests are logged.<br /><br />Verbose mode is off by default. Using verbose mode is not recommended as it can significantly slow down your site; it exists to capture data from live spammers which are not being blocked.';
$helptxt['badbehavior_logging'] = 'Should Bad Behavior keep a log of requests? On by default, and it is not recommended to disable it, since it will cause additional spam to get through.';
$helptxt['badbehavior_strict'] = 'Bad Behavior operates in two blocking modes: normal and strict.<br />When strict mode is enabled, additional checks for (old) software which have been spam sources are enabled, but occasional legitimate users using the same software may be blocked as well.';
$helptxt['badbehavior_offsite_forms'] = 'Bad Behavior normally prevents your site from receiving data posted from forms on other websites. This prevents spammers from, e.g., using a Google cached version of your website to send you spam. However, some web applications such as OpenID require that your site be able to receive form data in this way. If you are running OpenID, enable this option.';
$helptxt['badbehavior_postcount_wl'] = 'This allows you to bypass bad behavior checks for users over a certain post count.<br />-1 will bypass all registered users, including those with no posts<br />0 will disable bypassing and scan everyone regardless of post count<br />Any number greater than zero sets the post count under which users will be checked.';
$helptxt['badbehavior_ip_wl'] = 'IP address ranges use the CIDR format.  To remove an address just leave it blank and then save';
$helptxt['badbehavior_useragent_wl'] = 'User agents are matched by exact match only.';
$helptxt['badbehavior_url_wl'] = 'URLs are matched from the first / after the server name up to, but not including, the ? (if any). The URL to be whitelisted is a URL on YOUR site. A partial URL match is permitted, so URL whitelist entries should be as specific as possible, but no more specific than necessary.<br />For instance, /example would match /example.php and /example/address';

$helptxt['filter_to'] = 'Replace the found text with this, leave blank to replace with found text with nothing (i.e. remove it)';
$helptxt['filter_from'] = 'Enter the text you want to find/replace.  If type is set to regex then this must be a valid regular expression, including delimiters.  If not regex it will do a simple text match and replace it with the replacement text';
$helptxt['filter_type'] = 'Standard will find the exact phrase and replace it with the text in the replace field.  Regular Expression is a wildcard option, but it must be in a valid regex format.';
$helptxt['pbe_post_enabled'] = 'Enable this to allow users to respond to email notifications and have them post as a reply.  They are still required to have posting permissions.';
$helptxt['pbe_pm_enabled'] = 'Enable this to allow users to reply by email to PM notifications.  They are still required to have PM permissions, this setting only allows them to receive and reply to notifications';
$helptxt['maillist_group_mode'] = 'If enabled outbound post/topic emails will come from the poster\'s display name, otherwise it will come from the site name.  This is simply a envelope, affecting only how the "From name" appears in the receiving mailbox, the actual from email address is unchanged.';
$helptxt['maillist_newtopic_change'] = 'This will allow a user to change the subject of a email notification and have it post as a new topic.  The new topic will be started on the same board as the reply was going to.';
$helptxt['maillist_sitename_address'] = 'This must be the address that is piped to the emailpost.php file or the address of the IMAP mailbox';
$helptxt['maillist_help_short'] = 'This feature allows users of your forum to reply to the site\'s email notifications and have those replies post on the forum.  Please visit the Wiki for full instructions';

$helptxt['frame_security'] = 'The X-Frame-Options HTTP response header can be used to indicate whether or not a browser should be allowed to render a page in a frame or an iframe. You can use this additional security restriction on your site against attempts at clickjacking attacks, by ensuring that the content of your site is not embedded into other sites.
	<br />
	More information about this header may be found on the internet.';

$helptxt['attachment_inline_title'] = '<b>Add an inline attachment</b><br />
		Example:
		<br /><b>[attach align=left width=400]123[/attach]</b>
		<br />This will show a left-aligned image resized to 400 pixels wide with the post text flowing around it. Except for the attachment tag and the attachment id all other parameters are optional
		<br /><b>[attach]123[/attach]</b>
		<br />This will show the attachment as a thumbnail if available, if no thumbnail is available it will use a full sized image. The image will be in line with the text of your post.
		<br /><br />
		<br /><b>Options:</b>
		<br />where x is the attachment id
		<br />align=left, center, right
		<br />width=### (where # is number in pixels)
		<br />height=### (where # is number in pixels)
		<br />
		<h3>Modes available</h3>
		<p>
			You can choose the inline mode you want for your attachment:
			<ul>
				<li>Thumbnail [attach]x[/attach] : Your image will be shown as a thumbnail</li>
				<li>Text Link [attachurl]x[/attachurl] : Only a link is show with size and view details. By clicking on it, the image is displayed.</li>
			</ul>
		</p><br />
		<p>
			You can choose how to align the inline image:
			<ul>
				<li>align=left : The image is aligned to the left and the text will flow around it</li>
				<li>align=right : The image is aligned to the right and the text will flow around it</li>
				<li>align=center : The image is centered and the text will be below it</li>
			</ul>
		</p><br />
		<p>
			You can choose how wide to show the image:
			<ul>
				<li>width=123 : The image is displayed 123 pixels wide</li>
				<li>If the width specified is larger than the image or larger than the forum allows the largest allowable width will be used</li>
				<li>Can be used to shrink a thumbnail as well [attach width=50]x[/attach] will display a 50px wide thumbnail</li>
			</ul>
		</p><br />
		<p>
			You can choose how tall to show the image:
			<ul>
				<li>height=123 : The image is displayed 123 pixels tall</li>
				<li>If the height specified is bigger than the image or bigger than the forum allows the biggest allowable width will be used</li>
				<li>Can be used to shrink a thumbnail as well [attach height=50]x[/attach] will display a 50px tall thumbnail</li>
			</ul>
		</p>';