<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Pos jawapan';
$txt['post_in_board'] = 'Pos dalam ruangan';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Sertakan Ungkapan';
$txt['disable_smileys'] = 'Matikan mimik2';
$txt['dont_use_smileys'] = 'Jangan pakai mimik2.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Ditulis pada';
$txt['standard'] = 'Lazim';
$txt['thumbs_up'] = 'Bagus';
$txt['thumbs_down'] = 'Tidak Bagus';
$txt['exclamation_point'] = 'Tanda seru';
$txt['question_mark'] = 'Tanda Tanya';
$txt['icon_poll'] = 'Undian';
$txt['lamp'] = 'Lampu';
$txt['add_smileys'] = 'Tambah mimik2';
$txt['topic_notify_no'] = 'Tidak ada topik dengan makluman.';

$txt['rich_edit_wont_work'] = 'Browser anda tidak menyokong pengeditan Rich Text.';
$txt['rich_edit_function_disabled'] = 'Browser anda tidak menyokong fungsi ini.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Batalkan langganan ke topik ini dengan mengklik di sini';

$txt['lock_after_post'] = 'Kunci Setelah Pos';
$txt['notify_replies'] = 'Maklumkan saya jawapan.';
$txt['lock_topic'] = 'Kunci topik ini.';
$txt['shortcuts'] = 'jalan pintas: tekan shift+alt+s untuk mengirim/pos atau shift+alt+p untuk semak';
$txt['shortcuts_drafts'] = 'pintasan: shift+alt+s hantar/pos, shift+alt+p preview atau shift+alt+d simpan deraf';
$txt['option'] = 'Pilihan';
$txt['reset_votes'] = 'Tetapkan Semula Jumlah Undian';
$txt['reset_votes_check'] = 'Tanda ini jika anda mahu menetapkan semula semua jumlah undian menjadi 0.';
$txt['votes'] = 'pilihan';
$txt['attach'] = 'Lampirkan';
$txt['clean_attach'] = 'Lampiran Bersih';
$txt['attached'] = 'Dilampirkan'; // @deprecated since 1.1
$txt['allowed_types'] = 'Jenis fail diizinkan';
$txt['cant_upload_type'] = 'Anda tidak boleh memuatnaik jenis fail itu. Sambungan yang diizinkan adalah';
$txt['uncheck_unwatchd_attach'] = 'Jangan tanda lampiran yang anda tidak lagi mahu ia dilampirkan'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Itu nama fail terlarang. Sila cuba nama fail berbeza.';
$txt['topic_locked_no_reply'] = 'Peringatan: topik sedang/akan dikunci!<br />Hanya pengurus dan moderator boleh menjawab.';
$txt['attachment_requires_approval'] = 'Perhatikan bahawa setiap fail yang dilampirkan tidak akan dipapar sehingga diluluskan oleh moderator.';
$txt['error_temp_attachments'] = 'Terdapat lampiran ditemui, yang telah anda lampirkan terdahulu tetapi tidak jadi dipos. Lampiran tersebut kini dilampirkan di pos ini. Jika anda tidak mahu melampirkannya bersama pos ini, anda boleh membuangnya <a href="#postAttachment">di sini</a>. ';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Pengingat: Pos ni tidak akan muncul sehingga diluluskan oleh moderator.';

$txt['enter_comment'] = 'Masukkan komen';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Pos dilaporkan';
$txt['reported_to_mod_by'] = 'oleh';
$txt['rtm10'] = 'Kirim';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Pos berikut, "%1$s" oleh';
$txt['reported_by'] = 'telah dilaporkan oleh';
$txt['board_moderate'] = 'pada ruangan yang anda moderasikan';
$txt['report_comment'] = 'Pelapor menambahkan komen berikut';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'jumlah saiz maksima %1$dKB ';
$txt['attach_restrict_attachmentSizeLimit'] = 'saiz individu maksima %1$dKB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d satu pos';
$txt['attach_restrictions'] = 'Had:';

$txt['post_additionalopt_attach'] = 'Pilihan lampiran dan lain2';
$txt['post_additionalopt'] = 'Lampiran dan pilihan lain...';
$txt['sticky_after'] = 'Lekitkan topik ini.';
$txt['move_after2'] = 'Pindahkan topik ini.';
$txt['back_to_topic'] = 'Kembali ke topik ini.';
$txt['approve_this_post'] = 'Luluskan Pos ini';

$txt['retrieving_quote'] = 'Mengambil ungkapan...';

$txt['post_visual_verification_label'] = 'Pengesahan';
$txt['post_visual_verification_desc'] = 'Sila masukkan kod dalam gambar di atas untuk membuat pos ini.';

$txt['poll_options'] = 'Pilihan Undian';
$txt['poll_run'] = 'Jalankan undian dalam';
$txt['poll_run_limit'] = '(Biarkan kosong untuk tanpa had.)';
$txt['poll_results_visibility'] = 'Visibiliti hasil';
$txt['poll_results_anyone'] = 'Papar keputusan undian ke setiap orang.';
$txt['poll_results_voted'] = 'Hanya papar keputusan setelah seseorang telah memilih.';
$txt['poll_results_after'] = 'Hanya paparkan keputusan selepas undian ditutup.';
$txt['poll_max_votes'] = 'Pemilihan maksima seorang pengguna.';
$txt['poll_do_change_vote'] = 'Izinkan pengguna mengubah pemilihan.';
$txt['poll_too_many_votes'] = 'Anda membuat terlalu banyak pilihan.  Untuk undian ini, anda hanya boleh membuat %1$s pilihan.';
$txt['poll_add_option'] = 'Tambah Pilihan';
$txt['poll_guest_vote'] = 'Izinkan tetamu memilih.';

$txt['spellcheck_done'] = 'Pemeriksaan ejaan selesai.';
$txt['spellcheck_change_to'] = 'Ubah Ke:';
$txt['spellcheck_suggest'] = 'Saran:';
$txt['spellcheck_change'] = 'Edit';
$txt['spellcheck_change_all'] = 'Ubah Semua';
$txt['spellcheck_ignore'] = 'Abaikan';
$txt['spellcheck_ignore_all'] = 'Abaikan Semua';

$txt['more_attachments'] = 'lebih banyak lampiran';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Maaf, anda tidak diizinkan untuk menyertakan lebih banyak lampiran lagi.';

$txt['more_smileys'] = 'selengkapnya';
$txt['more_smileys_title'] = 'Mimik2 tambahan';
$txt['more_smileys_pick'] = 'Ambil mimik';
$txt['more_smileys_close_window'] = 'Tutup Jendela';

$txt['error_new_reply'] = 'Sedang anda menulis, ada jawapan baru diposkan. Anda mungkin mahu menyemak pos anda semula.';
$txt['error_new_replies'] = 'Sedang anda menulis, ada %1$d jawapan baru diposkan. Anda mungkin mahu menyemak pos anda semula.';
$txt['error_new_reply_reading'] = 'Sedang anda membaca, ada jawapan baru diposkan. Anda mungkin mahu menyemak pos anda semula.';
$txt['error_new_replies_reading'] = 'Sedang anda membaca, ada %1$d jawapan baru diposkan. Anda mungkin mahu menyemak pos anda semula.';

$txt['announce_this_topic'] = 'Kirim pengumuman mengenai topik ini ke ahli:';
$txt['announce_title'] = 'Kirim pengumuman';
$txt['announce_desc'] = 'Borang ini mengizinkan anda untuk mengirimkan pengumuman ke grup ahli yang dipilih atas topik ini.';
$txt['announce_sending'] = 'Mengirimkan pengumuman topik';
$txt['announce_done'] = 'selesai';
$txt['announce_continue'] = 'Teruskan';
$txt['announce_topic'] = 'Umumkan topik.';
$txt['announce_regular_members'] = 'Ahli Biasa';

$txt['digest_subject_daily'] = 'Bacaan Harian';
$txt['digest_subject_weekly'] = 'Bacaan Mingguan';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'Topik berikut telah dimulakan';
$txt['digest_new_topics_line'] = '"%1$s" dalam "%2$s"';
$txt['digest_new_replies'] = 'Jawapan telah dibuat dalam topik berikut';
$txt['digest_new_replies_one'] = '1 jawapan dalam "%1$s"';
$txt['digest_new_replies_many'] = '%1$d jawapan dalam "%2$s"';
$txt['digest_mod_actions'] = 'Tindakan moderasi berikut telah dilakukan';
$txt['digest_mod_act_sticky'] = '"%1$s" telah dilekitkan';
$txt['digest_mod_act_lock'] = '"%1$s" telah dikunci';
$txt['digest_mod_act_unlock'] = '"%1$s" telah dibuka kunci';
$txt['digest_mod_act_remove'] = '"%1$s" telah dibuang';
$txt['digest_mod_act_move'] = '"%1$s" telah dipindahkan';
$txt['digest_mod_act_merge'] = '"%1$s" telah digabung';
$txt['digest_mod_act_split'] = '"%1$s" telah dipisahkan';

$txt['attach_error_title'] = 'Kesalahan memuatnaik lampiran';
$txt['attach_warning'] = 'Ada sedikit masalah semasa memuatnaik <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Maaf, anda kehabisan ruangan lampiran. Jumlah lampiran yang dibenarkan per pos ialah %1$s KB. Baki yang tinggal adalah %2$s KB.';
$txt['attach_folder_warning'] = 'Direktori lampiran tidak dapat ditemui. Sila maklumkan pengurus mengenai perkara ini.';
$txt['attach_folder_admin_warning'] = 'Laluan kepada direktori lampiran (%1$s) adaah salah. Sila betulkannya di ruangan tetapan lampiran di panel admin anda.';
$txt['attach_limit_nag'] = 'Anda telah mencapai jumlah maksima lampiran yang dibenarkan per pos.';
$txt['attach_no_upload'] = 'Ada kesalahan berlaku dan lampiran anda tidak dapat dimuatnaik.';
$txt['attach_remaining'] = '%1$d lagi';
$txt['attach_available'] = 'ada %1$s KB';
$txt['attach_kb'] = '(%1$s KB)';
$txt['attach_0_byte_file'] = 'Fail kelihatan kosong. Sila hubungi pengurus forum jika hal ini terus menjadi masalah.';
$txt['attached_files_in_session'] = '<em>Fail2 yang ditandakan di atas telah dimuatnaik tetapi tidak akan dilampirkan kepada pos ini sehinggalah ia dihantarkan.</em>';

$txt['attach_php_error'] = 'Disebabkan ada kesalahan, lampiran anda tidak dapat dimuatnaik. Sila hubungi pengurus forum jika masalah ini berlarutan.';
$txt['php_upload_error_1'] = 'Fail yang dimuatnaik melebihi arahan saiz fail maksima dalam php.ini. Sila hubungi hos anda jika anda tidak dapat memperbaiki keadaan ini.';
$txt['php_upload_error_3'] = 'Hanya sebahagian fail dapat dimuatnaikkan. Ini adalah kesalahan PHP. Sila hubungi hos anda jika masalah ini berlarutan.';
$txt['php_upload_error_4'] = 'Tiada fail dimuatnaikkan. Ini adalah kesalahan PHP. Sila hubungi hos anda jika masalah ini berterusan.';
$txt['php_upload_error_6'] = 'Tidak boleh menyimpan. Direktori sementara hilang. Sila hubungi hos anda jika anda tidak berupaya memperbaiki masalah ini.';
$txt['php_upload_error_7'] = 'Gagal menulis pada disk. Ini adalah kesalahan PHP. Sila hubungi hos anda jika masalah ini berterusan.';
$txt['php_upload_error_8'] = 'Extension PHP telah memberhentikan muatnaik fail. Ini adalah kesalahan PHP. Sila hubungi hos anda jika ia berterusan.';
$txt['error_temp_attachments_new'] = 'Ada lampiran yang anda telah lampirkan tetapi tidak mengepos. Lampiran2 ini masih ada pada pos ini. Pos ini perlu dihantar sebelum lampiran2 ini akan sama ada disimpan atau dibuang. Anda boleh lakukannya <a href="#postAttachment">di sini</a>';
$txt['error_temp_attachments_found'] = 'Lampiran berikut ditemui di mana anda telah melampirkannya pada pos lain tetapi ia tidak dihantar. Anda disarankan untuk tidak mengepos sehingga ia dibuang atau pos telah sempurna dihantar.<br /><a href="%1$s">Klik di sini</a> untuk membuang lampiran ini. Atau <a href="%2$s"> klik di sini</a> untuk kembali ke pos tersebut.%3$s';
$txt['error_temp_attachments_lost'] = 'Lampiran berikut ditemui di mana anda telah melampirkannya pada pos lain tetapi ia tidak dihantar. Anda disarankan untuk tidak memuatnaik sebarang lampiran lain sehingga ia dibuang atau pos telah sempurna dihantar.<br /><a href="%1$s">Klik di sini</a> untuk membuang lampiran ini.%2$s';
$txt['error_temp_attachments_gone'] = 'Lampiran sudah dibuang dan anda telah dipandu semula ke laman di mana anda berada sebelum ini';
$txt['error_temp_attachments_flushed'] = 'Ambil perhatian bahawa mana2 fail yang sebelum ini dilampirkan, tetapi belum diposkan, sekarang sudah dibuang.';
$txt['error_topic_already_announced'] = 'Ambil perhatian bahawa topik ini sudah diwarwarkan.';

$txt['cant_access_upload_path'] = 'Tidak dapat mengakses laluan muatnaik lampiran.';
$txt['file_too_big'] = 'Fail anda terlalu besar. Saiz maksima lampiran yang dibenarkan ialah %1$s KB.';
$txt['attach_timeout'] = 'Lampiran anda tidak dapat disimpan. ini disebabkan ia mengambil masa terlalu lama untuk memuatnaik atau fail bersaiz lebih besar daripada yang dibenarkan..<br /><br />Sila rujuk pengurus server anda untuk maklumat lanjut.';
$txt['bad_attachment'] = 'Lampiran anda gagal melepasi pemeriksaan sekuriti dan tidak boleh dimuatnaik. Sila rujuk kepada pengurus forum.';
$txt['ran_out_of_space'] = 'Direktori muatnaik sudah penuh. Sila hubungi pengurus mengenai masalah ini.';
$txt['attachments_no_write'] = 'Direktori muatnaik lampiran tidak boleh ditulis. Lampiran atau avatar anda tidak dapat disimpan.';
$txt['attachments_no_create'] = 'Tidak dapat mencipta direktori lapiran yang baru. Lampiran atau avatar anda tidak dapat disimpan.';
$txt['attachments_limit_per_post'] = 'Anda tidak boleh memuatnaik lebih daripada  %1$d lampiran satu pos';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Masukkan';
$txt['ila_opt_size'] = 'Saiz';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Tiada';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Atur Ke Tengah';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/