<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Selamat datang';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Periksa Keboleh-tulisan';
$txt['install_step_forum'] = 'Tetapan Dasar';
$txt['install_step_databaseset'] = 'Tetapan Database';
$txt['install_step_databasechange'] = 'Populasi Database';
$txt['install_step_admin'] = 'Akaun Admin';
$txt['install_step_delete'] = 'Muktamadkan Installasi';

$txt['installer'] = 'Installer ElkArte';
$txt['installer_language'] = 'Bahasa';
$txt['installer_language_set'] = 'Set';
$txt['congratulations'] = 'Tahniah, proses installasi selesai!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Direktori install anda masih boleh ditulis.  Alangkah baiknya untuk melakukan chmod agar ia tidak boleh ditulis atas alasan sekuriti.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(tidak bekerja pada semua server.)</em>';
$txt['go_to_your_forum'] = 'Sekarang anda boleh lihat <a href="%1$s">forum anda yang baru diinstall</a> dan mula menggunakannya. Anda harus terlebih dulu pastikan anda sudah log masuk, setelah itu anda  boleh mengakses pusat pengurusan.';
$txt['good_luck'] = 'Terima kasih kerana memilih ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Selamat datang';
$txt['install_welcome_desc'] = 'Selamat datang ke ElkArte. Skrip ini akan membimbing anda melalui proses installasi %1$s. Kami mengumpulkan butiran forum anda, dan setelah itu, forum anda akan tersedia untuk digunakan.';
$txt['install_all_lovely'] = 'Kami selesai dengan beberapa ujian awal pada server anda dan nampaknya semua telah sesuai. Cukup klik butang &quot;Teruskan&quot; di bawah untuk memulai.';

$txt['user_refresh_install'] = 'Forum Disegarkan';
$txt['user_refresh_install_desc'] = 'Sepanjang installasi, penginstall menemui satu atau lebih table yang sedia ada (dengan butiran yang anda berikan).<br />Setiap table yang kurang dalam installasi anda telah dibina semula dengan data default, tapi tiada data yang dipadam dari table sedia ada.';

$txt['default_topic_subject'] = 'Selamat datang ke ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Diskusi Umum';
$txt['default_board_description'] = 'Sila bicarakan apa sahaja dalam ruangan ini.';
$txt['default_category_name'] = 'Kategori Umum';
$txt['default_time_format'] = '%d %B %Y, %I:%M:%S %p';
$txt['default_news'] = 'ElkArte - Baru saja Diinstall!';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[keji]';
$txt['default_karmaApplaudLabel'] = '[puji]';
$txt['default_reserved_names'] = 'Admin\nWebmaster\nGuest\nroot';
$txt['default_smileyset_name'] = 'Set Fugue';
$txt['default_theme_name'] = 'Tema Default ElkArte';

$txt['default_administrator_group'] = 'Pengurus';
$txt['default_global_moderator_group'] = 'Global Moderator';
$txt['default_moderator_group'] = 'Penyelia';
$txt['default_newbie_group'] = 'Ahli Baru';
$txt['default_junior_group'] = 'Ahli Junior';
$txt['default_full_group'] = 'Ahli Penuh';
$txt['default_senior_group'] = 'Ahli Senior';
$txt['default_hero_group'] = 'Ahli Hero';

$txt['default_smiley_smiley'] = 'Senyum';
$txt['default_wink_smiley'] = 'Kenyit';
$txt['default_cheesy_smiley'] = 'Sinis';
$txt['default_grin_smiley'] = 'Geram';
$txt['default_angry_smiley'] = 'Marah';
$txt['default_sad_smiley'] = 'Sedih';
$txt['default_shocked_smiley'] = 'Terkejut';
$txt['default_cool_smiley'] = 'Tenang';
$txt['default_huh_smiley'] = 'Dengus';
$txt['default_roll_eyes_smiley'] = 'Pusing Mata';
$txt['default_tongue_smiley'] = 'Ejek';
$txt['default_embarrassed_smiley'] = 'Malu';
$txt['default_lips_sealed_smiley'] = 'Tutup mulut';
$txt['default_undecided_smiley'] = 'Pening';
$txt['default_kiss_smiley'] = 'Cium';
$txt['default_cry_smiley'] = 'Nangis';
$txt['default_evil_smiley'] = 'Jahat';
$txt['default_azn_smiley'] = 'Asian';
$txt['default_afro_smiley'] = 'Keriting';
$txt['default_laugh_smiley'] = 'Ketawa';
$txt['default_police_smiley'] = 'Polis';
$txt['default_angel_smiley'] = 'Malaikat';

$txt['error_message_click'] = 'Klik di sini';
$txt['error_message_try_again'] = 'untuk mencuba langkah ini lagi.';
$txt['error_message_bad_try_again'] = 'untuk tetap mencuba install, tapi perhatikan bahawa ini <em>sangat tidak</em> disarankan.';

$txt['install_settings'] = 'Tetapan Dasar';
$txt['install_settings_info'] = 'Hanya beberapa hal untuk anda sediakan ;).';
$txt['install_settings_name'] = 'Nama forum';
$txt['install_settings_name_info'] = 'Ini adalah nama forum anda, cth: &quot;Forum Ujian&quot;.';
$txt['install_settings_name_default'] = 'Komuniti Saya';
$txt['install_settings_url'] = 'URL Forum';
$txt['install_settings_url_info'] = 'Ini adalah URL ke forum anda <strong>tanpa akhiran \'/\'!</strong>.<br />Dalam banyak hal, anda boleh membiarkan nilai default dalam kotak ini - ia biasanya betul.';
$txt['install_settings_compress'] = 'Output Gzip';
$txt['install_settings_compress_title'] = 'Kompresi output untuk menghemat bandwidth.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Fungsi ini tidak bekerja dengan betul pada semua server, tapi anda boleh banyak menghemat bandwidth.<br />Klik <a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">di sini</a> untuk mengujinya. (semestinya menyatakan "LULUS".)';
$txt['install_settings_dbsession'] = 'Sesi Database';
$txt['install_settings_dbsession_title'] = 'Gunakan database untuk sesi daripada menggunakan fail.';
$txt['install_settings_dbsession_info1'] = 'Fitur ini hampir selalu jadi yang terbaik, karena menjadikan sesi lebih berdiri sendiri.';
$txt['install_settings_dbsession_info2'] = 'Fitur ini umumnya adalah ide yang baik, tapi mungkin tidak bekerja pada server ini.';
$txt['install_settings_proceed'] = 'Teruskan';

$txt['db_settings'] = 'Tetapan Server Database';
$txt['db_settings_info'] = 'Ini adalah tetapan untuk menggunakan server database anda.  Jika anda tidak mengetahui nilainya, anda mesti meminta kepada host anda.';
$txt['db_settings_type'] = 'Jenis Database';
$txt['db_settings_type_info'] = 'Pelbagai jenis database yang disokong dikesan - yang mana yang mahu anda gunakan.';
$txt['db_settings_server'] = 'Nama server';
$txt['db_settings_server_info'] = 'Ini selalunya ialah localhost - jika anda tidak tahu, cuba localhost.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Biarkan kososng sekiranya server anda mendengar pada port default, atau anda tidak pasti.';
$txt['db_settings_username'] = 'Nama pengguna';
$txt['db_settings_username_info'] = 'Isi nama pengguna yang diperlukan untuk menyambung ke database anda di sini.<br />Jika anda tidak mengetahuinya, cuba nama pengguna akaun ftp anda, umumnya selalu sama.';
$txt['db_settings_password'] = 'Kata Kunci';
$txt['db_settings_password_info'] = 'Di sini, masukkan kata kunci yang anda perlukan untuk menyambung ke database anda.<br />Jika anda tidak mengetahuinya, anda boleh mencuba kata kunci untuk akaun ftp anda.';
$txt['db_settings_database'] = 'Nama database';
$txt['db_settings_database_info'] = 'Isi nama database yang mahu digunakan untuk ElkArte menyimpan data.';
$txt['db_settings_database_info_note'] = 'Jika database ini tiada, penginstall ini akan mencuba membuatnya.';
$txt['db_settings_database_file'] = 'Nama fail database';
$txt['db_settings_database_file_info'] = 'Ini adalah nama fail yang menyimpan data ElkArte . Kami menyarankan anda menggunakan nama yang dijana secara rawak untuk tujuan ini dan menetapkan laluan fail ini di luar kawasan umum pada server web anda.';
$txt['db_settings_prefix'] = 'Prefiks table';
$txt['db_settings_prefix_info'] = 'Prefiks untuk setiap table dalam database.  <strong>Jangan install dua forum dengan prefiks yang sama!</strong><br />Nilai ini mengizinkan pelbagai install dalam satu database.';
$txt['db_populate'] = 'Database Dipopulasi';
$txt['db_populate_info'] = 'Tetapan anda sekarang telah disimpan dan database telah dipopulasikan dengan semua data yang diperlukan agar forum anda sedia dijalankan. Ringkasan populasi:';
$txt['db_populate_info2'] = 'Klik &quot;Teruskan&quot; untuk maju ke laman penciptaan akaun pengurus.';
$txt['db_populate_inserts'] = 'Disertakan %1$d baris.';
$txt['db_populate_tables'] = 'Dibuat %1$d table.';
$txt['db_populate_insert_dups'] = 'Diabaikan %1$d salinan lampiran.';
$txt['db_populate_table_dups'] = 'Diabaikan %1$d salinan table.';

$txt['user_settings'] = 'Buat Akaun Anda';
$txt['user_settings_info'] = 'Penginstall sekarang akan mencipta akaun pengurus baru bagi anda.';
$txt['user_settings_username'] = 'Nama pengguna anda';
$txt['user_settings_username_info'] = 'Pilih nama untuk anda log masuk.';
$txt['user_settings_password'] = 'Kata Kunci';
$txt['user_settings_password_info'] = 'Isi kata kunci yang dikehendaki di sini, dan ingat dengan baik!';
$txt['user_settings_again'] = 'Kata Kunci';
$txt['user_settings_again_info'] = '(hanya untuk pengesahan.)';
$txt['user_settings_email'] = 'Alamat Emel';
$txt['user_settings_email_info'] = 'Lengkapi alamat email anda juga.  <strong>Ini mesti alamat email yang sah.</strong>';
$txt['user_settings_database'] = 'Kata Kunci Database';
$txt['user_settings_database_info'] = 'Penginstall memerlukan anda untuk menyediakan kata kunci database untuk membuat akaun pengurus, untuk sebab sekuriti.';
$txt['user_settings_skip'] = 'Tinggalkan';
$txt['user_settings_skip_sure'] = 'Anda yakin mahu meninggalkan penciptaan akaun pengurus?';
$txt['user_settings_proceed'] = 'Selesai';

$txt['ftp_checking_writable'] = 'Memeriksa Fail apakah boleh Ditulis';
$txt['ftp_setup'] = 'Maklumat Koneksi FTP';
$txt['ftp_setup_info'] = 'Penginstall boleh menyambung via FTP untuk membetulkan fail yang perlu boleh ditulis atau tidak.  Jika ini tidak bekerja bagi anda, anda mesti melakukannya secara manual dan menjadikan fail boleh ditulis.  Harap dicatat bahawa ini tidak menyokong SSL buat masa ini.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'Ini mesti server dan port untuk server FTP anda.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'Nama pengguna';
$txt['ftp_username_info'] = 'Nama pengguna untuk masuk. <em>Ini tidak akan disimpan di manapun.</em>';
$txt['ftp_password'] = 'Kata Kunci';
$txt['ftp_password_info'] = 'Kata kunci untuk masuk. <em>Ini tidak akan disimpan di manapun.</em>';
$txt['ftp_path'] = 'Path Install';
$txt['ftp_path_info'] = 'Ini adalah path <em>relatif</em> yang anda pakai dalam server FTP anda.';
$txt['ftp_path_found_info'] = 'Path dalam kotak di atas secara automatik dikesan.';
$txt['ftp_connect'] = 'Sambung';
$txt['ftp_setup_why'] = 'Untuk apa langkah ini?';
$txt['ftp_setup_why_info'] = 'Beberapa fail perlu boleh ditulis agar SMF bekerja dengan betul.  Langkah ini mengizinkan anda untuk membiarkan penginstall membuatnya boleh ditulis bagi anda.  Akan tetapi, dalam hal ia tidak bekerja, sila jadikan fail berikut 777 (boleh ditulis, 755 pada beberapa host):';
$txt['ftp_setup_again'] = 'untuk menguji apakah fail ini boleh ditulis lagi.';

$txt['error_php_too_low'] = 'Amaran! Anda tiada versi PHP pada server web anda yang sesuai dengan <strong>syarat minimum install</strong>.<br />Anda perlu meminta host anda untuk meningkatkannya, atau gunakan host berbeza - sebaliknya, sila tingkatkan PHP ke versi terbaru.<br /><br />Jika anda mengetahui bahawa versi PHP anda cukup tinggi anda boleh melanjutkan, meskipun ini sangat tidak disarankan.';
$txt['error_missing_files'] = 'Tidak boleh menemukan fail install penting dalam direktori naskah ini!<br /><br />Pastikan anda memuatnaik seluruh pakej install, termasuk fail sql, dan kemudian cuba lagi.';
$txt['error_session_save_path'] = 'Sila beritahu host anda bahawa <strong>session.save_path yang ditetapkan dalam php.ini</strong> tidak benar!  Ia perlu diubah ke direktori yang <strong>ada</strong>, dan <strong>boleh ditulis</strong> oleh pengguna di mana PHP dijalankan.<br />';
$txt['error_windows_chmod'] = 'Anda pada server windows, dan beberapa fail penting tidak boleh ditulis.  Sila minta host anda untuk memberikan <strong>izin menulis</strong> ke pengguna di mana PHP dijalankan untuk fail dalam install SMF anda.  File-file atau direktori berikut perlu boleh ditulis:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Tidak boleh menyambung ke server FTP dengan kombinasi butiran.';
$txt['error_db_file'] = 'Tidak boleh menemukan naskah sumber database! Sila periksa fail %1$s di dalam direktori sumber forum anda.';
$txt['error_db_connect'] = 'Tidak boleh menyambung ke server database dengan data yang disediakan.<br /><br />Jika anda tidak yakin mengenai apa yang mesti dimasukkan, sila hubungi host anda.';
$txt['error_db_too_low'] = 'Versi server database anda terlalu tua, dan tidak sesuai dengan syarat minimum SMF.<br /><br />Sila minta host anda untuk meningkatkannya atau menyediakan yang baru, dan jika mereka tidak mahu, sila cuba host yang berbeza.';
$txt['error_db_database'] = 'Penginstall tidak boleh mengakses &quot;<em>%1$s</em>&quot; database.  Pada beberapa, anda mesti membuat database dalam panel pengurusan sebelum SMF boleh menggunakannya.  Host lainnya juga menambahkan prefiks - seperti nama pengguna anda - ke nama database anda.';
$txt['error_db_queries'] = 'Beberapa kueri tidak dijalankan dengan betul.  Ini boleh disebabkan oleh versi software database anda yang tidak disokong (pembinaan atau lama).<br /><br />Maklumat teknikal mengenai kueri:';
$txt['error_db_queries_line'] = 'Baris #';
$txt['error_db_missing'] = 'Penginstall tidak boleh mengesan setiap sokongan database dalam PHP.  Sila minta host anda untuk memastikan bahawa PHP dikompilasi dengan database yang dikehendaki, atau sambungan sah telah diterapkan.';
$txt['error_db_script_missing'] = 'Penginstall tidak boleh mengesan kegagalan skrip install untuk database yang dikesan. Sila pastikan anda telah memuatnaik kegagalan skrip install yang diperlukan ke direktori forum, contoh &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Penginstall tidak boleh mengesan sokongan sesi dalam install PHP server anda.  Sila minta host anda untuk memastikan bahawa PHP dikompilasi dengan sokongan sesi (sebenarnya, mesti dikompilasi tanpa itu secara eksplisit.)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Anda memasukkan dua kata kunci yang sama sekali berbeza!';
$txt['error_user_settings_no_password'] = 'Panjang kata kunci anda mesti setidaknya empat karakter.';
$txt['error_user_settings_taken'] = 'Maaf, seorang ahli telah terdaftar dengan nama pengguna dan/atau alamat email itu.<br /><br />Akaun baru belum dibuat.';
$txt['error_user_settings_query'] = 'Kesalahan database terjadi saat mencuba untuk membuat pengurus.  Kesalahan ini adalah:';
$txt['error_subs_missing'] = 'Tidak boleh menemukan fail Sources/Subs.php.  Pastikan itu dimuatnaik dengan betul, dan kemudian cuba lagi.';
$txt['error_db_alter_priv'] = 'Akaun database yang anda tetapkan tiada keizinan untuk ALTER, CREATE, dan/atau DROP table dalam database; ini perlu bagi SMF agar berfungsi dengan betul.';
$txt['error_versions_do_not_match'] = 'Penginstall mengesan ada versi SMF lain diinstall dengan maklumat yang ditetapkan.  Jika anda mencuba untuk meningkatkan, anda mesti menggunakan pengemaskini, bukan penginstall.<br /><br />Sebaliknya, anda mungkin mahu menggunakan maklumat berbeza, atau membuat backup dan kemudian memadam data yang ketika ini ada dalam database.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'Versi database semasa tidak menyokong pemakaian set karakter UTF-8. Anda masih boleh install SMF tanpa masalah, tapi hanya dengan sokongan UTF-8 tidak ditanda. Jika anda mahu beralih ke UTF-8 di kemudian hari (misalnya setelah server database forum anda telah ditingkatkan ke versi >= %1$s), anda boleh mengubah forum anda ke UTF-8 melalui panel pengurus.';
$txt['error_valid_email_needed'] = 'Anda tidak memasukkan alamat email yang sah.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Peringatan!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Anda mesti memasukkan nama fail database untuk SQLite.';
$txt['error_db_prefix_numeric'] = 'Jenis database yang dipilih tidak menyokong pemakaian prefiks numerik.';
$txt['error_invalid_characters_username'] = 'Pemakaian karakter tidak benar dalam Nama pengguna.';
$txt['error_username_too_long'] = 'Panjang Nama pengguna mesti kurang dari 25 karakter.';
$txt['error_username_left_empty'] = 'Field Nama pengguna dibiarkan kosong.';
$txt['error_db_filename_exists'] = 'Database yang cuba anda buat telah ada.  Sila padam fail database semasa atau masukkan nama lain.';
$txt['error_db_prefix_reserved'] = 'Prefiks yang anda masukkan adalah prefiks sedia ada.  Sila masukkan prefiks lain.';

$txt['upgrade_upgrade_utility'] = 'Utiliti Kemaskini ElkArte';
$txt['upgrade_warning'] = 'Peringatan!';
$txt['upgrade_critical_error'] = 'Kesalahan Kritikal!';
$txt['upgrade_continue'] = 'Teruskan';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Tinggalkan';
$txt['upgrade_note'] = 'Perhatian!';
$txt['upgrade_step'] = 'Maju';
$txt['upgrade_steps'] = 'Langkah';
$txt['upgrade_progress'] = 'Diproses';
$txt['upgrade_overall_progress'] = 'Progres Keseluruhan';
$txt['upgrade_step_progress'] = 'Progres Langkah';
$txt['upgrade_time_elapsed'] = 'Jam Berlalu';
$txt['upgrade_time_mins'] = 'minit';
$txt['upgrade_time_secs'] = 'saat';

$txt['upgrade_incomplete'] = 'Tidak Lengkap';
$txt['upgrade_not_quite_done'] = 'Belum selesai benar!';
$txt['upgrade_paused_overload'] = 'Kemaskini ini telah dihentikan untuk menghindari beban lebih pada server anda.  Jangan risau, tiada yang salah - cukup klik <label for="contbutt">butang lanjutkan</label> di bawah untuk melanjutkan.';

$txt['upgrade_ready_proceed'] = 'Terima kasih memilih untuk bertukar kepada ElkArte %1$s. Semua fail telah teratur, dan kita telah bersedia untuk teruskan.';

$txt['upgrade_error_script_js'] = 'Skrip kemaskini tidak dapat menemukan script.js atau ia telah lapuk. Pastikan laluan tema anda betul. Anda boleh memuatturun skrip memeriksa dan membaiki tetapan daripada <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">alatan ElkArte</a>.';

$txt['upgrade_warning_lots_data'] = 'Naskah kemaskini ini mengesan bahawa forum anda berisi banyak data yang perlu dikemaskinikan. Proses ini boleh memerlukan waktu cukup lama tergantung pada ukuran forum dan server anda, dan untuk forum yang sangat besar (~300,000 pesan) boleh mengambil masa berjam-jam untuk menyelesaikannya.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';