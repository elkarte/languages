<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Tema default ElkArte.<br /><br />Pembuat: Penyumbang ElkArte';