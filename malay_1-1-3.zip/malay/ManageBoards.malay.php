<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Mengurus Ruangan dan Kategori';
$txt['order'] = 'Order';
$txt['full_name'] = 'Nama penuh';
$txt['name_on_display'] = 'Ini adalah nama yang akan dipaparkan.';
$txt['boards_and_cats_desc'] = 'Edit semua kategori dan ruangan anda di sini. Senaraikan pelbagai moderator sebagai <em>&quot;nama pengguna&quot;, &quot;nama pengguna&quot;</em>. (ini mestilah nama pengguna *bukan* nama paparan)<br />Untuk mencipta ruangan baru, klik butang Tambah Ruangan.<br />Untuk mengalihkan ruangan anda boleh seret dan letakkannya ke lokasi baru dalam senarai (semua kategori dan lokasi anak)<br />Untuk membuat ruangan anak dari ruangan semasa, pilih "Anak dari..." dari menu jatuhan semasa mencipta ruangan tersebut.';
$txt['parent_members_only'] = 'Ahli Biasa';
$txt['parent_guests_only'] = 'Tetamu';
$txt['catConfirm'] = 'Anda ingin memadamkan kategori ini?';
$txt['boardConfirm'] = 'Adakah anda benar2 mahu memadamkan ruangan ini?';

$txt['catEdit'] = 'Edit Kategori';
$txt['collapse_enable'] = 'Boleh disempitkan';
$txt['collapse_desc'] = 'Benarkan pengguna untuk menyempitkan kategori ini';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'Setelah ';
$txt['mboards_order_first'] = 'Di tempat pertama';
$txt['mboards_board_error'] = 'Gagal untuk menukar lokasi.';

$txt['mboards_new_board'] = 'Tambah Ruangan';
$txt['mboards_new_cat_name'] = 'Kategori Baru';
$txt['mboards_add_cat_button'] = 'Tambah Kategori';
$txt['mboards_new_board_name'] = 'Ruangan Baru';

$txt['mboards_modify'] = 'Ubah';
$txt['mboards_permissions'] = 'Keizinan';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Anda yakin supaya ruangan ini ditukarkan menggunakan kebenaran dalaman?';

$txt['mboards_delete_cat'] = 'Padam Kategori';
$txt['mboards_delete_board'] = 'Padam Ruangan';

$txt['mboards_delete_cat_contains'] = 'Memadamkan kategori akan memadamkan juga ruangan di bawahnya, termasuk seluruh topik, pos dan lampiran dalam setiap ruangan';
$txt['mboards_delete_option1'] = 'Padam kategori dan semua ruangan yang ada di dalamnya.';
$txt['mboards_delete_option2'] = 'Padam kategori dan pindahkan semua ruangan dan isi di dalamnya ke';
$txt['mboards_delete_board_contains'] = 'Memadamkan ruangan akan juga memindahkan ruangan anak di bawahnya, termasuk semua topik, pos, dan lampiran dalam setiap ruangan';
$txt['mboards_delete_board_option1'] = 'Padam ruangan dan pindahkan ruangan anak beserta isinya ke tingkat kategori.';
$txt['mboards_delete_board_option2'] = 'Padam dan pindahkan semua ruangan anak ke';
$txt['mboards_delete_what_do'] = 'Sila pilih apa yang ingin anda lakukan dengan semua ruangan ini';
$txt['mboards_delete_confirm'] = 'Pasti';
$txt['mboards_delete_cancel'] = 'Batalkan';

$txt['mboards_category'] = 'Kategori';
$txt['mboards_description'] = 'Keterangan';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Grup Dibenarkan';
$txt['mboards_groups_desc'] = 'Grup yang dibenarkan untuk mengakses ruangan ini.<br /><em>Catatan: jika ahli berada dalam mana2 grup atau grup pos telah ditanda, mereka akan mempunyai akses ke ruangan ini.</em>';
$txt['mboards_groups_regular_members'] = 'Gurp ini mengandungi semua ahli yang tiada tetapan grup utama.';
$txt['mboards_groups_post_group'] = 'Grup ini adalah grup berasaskan pos.';
$txt['mboards_moderators'] = 'Moderator';
$txt['mboards_moderators_desc'] = 'Ahli-ahli tambahan yang perlu semua kelebihan moderasi pada ruangan ini.  Catatan bahawa Pengurus tidak diperlihatkan di sini.';
$txt['mboards_count_posts'] = 'Kira Pos';
$txt['mboards_count_posts_desc'] = 'Membuat jawapan dan topik baru menunjukkan jumlah pos ahli.';
$txt['mboards_unchanged'] = 'Tidak berubah';
$txt['mboards_theme'] = 'Tema Ruangan';
$txt['mboards_theme_desc'] = 'Ini membolehkan anda mengubah rupa forum anda hanya dalam ruangan ini.';
$txt['mboards_theme_default'] = '(default forum keseluruhan.)';
$txt['mboards_override_theme'] = 'Abaikan Tema Ahli';
$txt['mboards_override_theme_desc'] = 'Gunakan tema ruangan ini meskipun ahli tidak memilih menggunakan yang default.';

$txt['mboards_redirect'] = 'Alihkan ke sebuah alamat web';
$txt['mboards_redirect_desc'] = 'Hidupkan pilihan ini untuk mengalihkan setiap orang yang menekan klik pada ruangan ini ke alamat web yang lain.';
$txt['mboards_redirect_url'] = 'Alamat untuk mengalihkan pengguna kepada';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Tetapkan semula jumlah peralihan';
$txt['mboards_redirect_reset_desc'] = 'Memilih ini akan mereset kiraan peralihan untuk ruangan ini menjadi sifar.';
$txt['mboards_current_redirects'] = 'Semasa: %1$s';
$txt['mboards_redirect_disabled'] = 'Catatan: Ruangan harus kosong dari topik untuk menghidupkan pilihan ini.';
$txt['mboards_redirect_disabled_recycle'] = 'Catatan: Anda tidak boleh tetapkan ruangan kitar semula menjadi ruangan peralihan.';

$txt['mboards_order_before'] = 'Sebelum';
$txt['mboards_order_child_of'] = 'Anak dari';
$txt['mboards_order_in_category'] = 'Dalam kategori';
$txt['mboards_current_position'] = 'Posisi Semasa';
$txt['no_valid_parent'] = 'Papan %1$s tidak memiliki induk yang benar. Gunakan fungsi \'cari dan betulkan kesalahan\' untuk membetulkan ini.';

$txt['mboards_recycle_disabled_delete'] = 'Catatan: anda harus memilih papan tempat pembuangan alternatif atau matikan pembuangan sebelum anda memadamkan papan ini.';

$txt['mboards_settings_desc'] = 'Edit tetapan papan umum dan kategori.';
$txt['groups_manage_boards'] = 'Grup ahli dibenarkan untuk mengatur papan dan kategori';
$txt['recycle_enable'] = 'Aktifkan pemulihan topik yang dipadamkan';
$txt['recycle_board'] = 'Papan untuk topik yang dipadamkan';
$txt['recycle_board_unselected_notice'] = 'Anda mengaktifkan pembuangan topik tanpa menetapkan papan untuk menempatkannya.  Fitur ini tidak akan diaktifkan sampai anda menetapkan sebuah papan sebagai tempat pembuangan topik.';
$txt['countChildPosts'] = 'Jumlah pos anak dalam total induk';
$txt['allow_ignore_boards'] = 'Benarkan papan untuk diabaikan';
$txt['deny_boards_access'] = 'Hidupkan pilihan bagi menafikan akses ruangan berdasarkan grup ahli';
$txt['boardsaccess_option_desc'] = 'Untuk setiap kebenaran anda boleh pilih \'Benarkan\' (A), \'Abaikan\' (X), atau <span class="alert">\'Nafikan\' (D)</span>.<br /><br />Kalau anda nafikan akses, sebarang ahli - (termasuk moderator) - dalam grup itu akan dinafikan akses.<br />Untuk tujuan ini, anda seharusnya menafikan akses dengan berhemah, <strong>hanya bila perlu</strong>. Abaikan pula akan menafikan, melainkan, sekiranya dibenarkan..';

$txt['mboards_select_destination'] = 'Pilih destinasi untuk ruangan \'<strong>%1$s</strong>\'';
$txt['mboards_cancel_moving'] = 'Batal memindahkan';
$txt['mboards_move'] = 'Pindah';

$txt['mboards_no_cats'] = 'Tidak ada kategori2 atau ruangan2 yang dikonfigurasikan buat masa ini.';
