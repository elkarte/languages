<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Notifikasi';
$txt['my_unread_mentions'] = 'Notifikasi belum dibaca';
$txt['my_mentions_pages'] = 'laman %1$d';
$txt['no_mentions_yet'] = 'Tiada sebutan';
$txt['no_new_mentions'] = 'Tiada sebutan baru';

$txt['mentions_from'] = 'Ahli';
$txt['mentions_when'] = 'Bila';
$txt['mentions_what'] = 'Mesej';
$txt['mentions_all'] = 'Paparkan semua';
$txt['mentions_unread'] = 'Paparkan yang belum dibaca';
$txt['mentions_action'] = 'Tindakan';
$txt['mentions_delete_warning'] = 'Anda benar2 pasti untuk padamkan entri ini?';
$txt['mentions_markread'] = 'Tanda sudah dibaca';
$txt['mentions_markunread'] = 'Tanda belum dibaca';

$txt['mentions_settings'] = 'Notifications Settings';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = 'Enable site notifications';
$txt['mentions_buddy'] = 'Tambah sebutan apabila seorang ahli dimasukkan dalam senarai rakan seseorang';
$txt['mentions_dont_notify_rlike'] = 'Jangan maklumkan kepada ahli jika pos yang disukai dibuang';

$txt['mention_mentionmem'] = 'Sebut anda dalam mesej {msg_link}';
$txt['mention_likemsg'] = 'Suka mesej anda {msg_link}';
$txt['mention_rlikemsg'] = 'Tidak suka mesej anda {msg_link}';
$txt['mention_buddy'] = 'Tambah anda ke dalam senarai rakan mereka';
$txt['mention_quotedmem'] = 'Quoted a message of yours in {msg_link}';
$txt['mention_mailfail'] = 'Disabled email notification due to delivery failure';

$txt['mentions_type_all'] = 'Semua sebutan';
$txt['mentions_type_mentionmem'] = 'Disebut';
$txt['mentions_type_likemsg'] = 'Suka';
$txt['mentions_type_rlikemsg'] = 'Tidak suka';
$txt['mentions_type_buddy'] = 'Teman';
$txt['mentions_type_quotedmem'] = 'Quoted';
$txt['mentions_type_mailfail'] = 'Delivery Failure';

$txt['mentions_mark_all_read'] = 'Tanda sebutan ini sebagai sudah dibaca';

$txt['setting_notify_enable_this'] = 'Enable user notifications of this event.';

$txt['setting_buddy'] = 'Teman';
$txt['setting_likemsg'] = 'Suka';
$txt['setting_rlikemsg'] = 'Removed likes';
$txt['setting_mentionmem'] = '@mentions';
$txt['setting_quotedmem'] = 'Quoting';
$txt['setting_mailfail'] = 'Delivery Failures';