<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Dari laman ini Anda dapat mengkonfigurasi setelan surat Anda, juga melihat dan mengadministrasi Giliran surat saat ini jika ia dihidupkan.';
$txt['mail_settings'] = 'Tetapan Emel';

$txt['mail_type'] = 'Jenis Surat';
$txt['mail_type_default'] = '(Default PHP)';
$txt['smtp_host'] = 'Server SMTP';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'Port SMTP';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'Nama pengguna SMTP';
$txt['smtp_password'] = 'Kata kunci SMTP';

$txt['mail_queue'] = 'Hidupkan Giliran Surat';
$txt['mail_period_limit'] = 'Maksima emel dihantar setiap minit';
$txt['mail_period_limit_desc'] = '(Set 0 untuk mematikan)';
$txt['mail_batch_size'] = 'Maksima jumlah emel dihantar setiap muatan laman';

$txt['mailqueue_stats'] = 'Statistik Giliran Surat';
$txt['mailqueue_oldest'] = 'Surat Terlama';
$txt['mailqueue_oldest_not_available'] = 'N/A';
$txt['mailqueue_size'] = 'Panjang Giliran';

$txt['mailqueue_age'] = 'Umur';
$txt['mailqueue_priority'] = 'Keutamaan';
$txt['mailqueue_recipient'] = 'Penerima';
$txt['mailqueue_subject'] = 'Subjek';
$txt['mailqueue_clear_list'] = 'Kirim Giliran Surat Sekarang';
$txt['mailqueue_no_items'] = 'Giliran surat saat ini sifar';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Anda yakin ingin mengirimkan seluruh giliran surat sekarang? Ini akan mengabaikan setiap batasan yang telah Anda tetapkan.';

$txt['mq_day'] = '%1.1f Hari';
$txt['mq_days'] = '%1.1f Hari';
$txt['mq_hour'] = '%1.1f Jam';
$txt['mq_hours'] = '%1.1f Jam';
$txt['mq_minute'] = '%1$d Minit';
$txt['mq_minutes'] = '%1$d Menit';
$txt['mq_second'] = '%1$d Saat';
$txt['mq_seconds'] = '%1$d Saat';

$txt['mq_mpriority_5'] = 'Sangat Rendah';
$txt['mq_mpriority_4'] = 'Rendah';
$txt['mq_mpriority_3'] = 'Normal';
$txt['mq_mpriority_2'] = 'Tinggi';
$txt['mq_mpriority_1'] = 'Sangat Tinggi';

$txt['birthday_email'] = 'Pesan Hari Jadi yang dipakai';
$txt['birthday_body'] = 'Badan Email';
$txt['birthday_subject'] = 'Subjek Email';