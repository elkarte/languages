<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'Bantuan Pengguna ElkArte';

$txt['manual_welcome'] = 'Selamat datang ke %s, laman yang dijana oleh perisian forum ElkArte! ';
$txt['manual_introduction'] = 'ElkArte adalah solusi perisian forum yang anggun, efektif, berkuasa dan percuma yang sedang digunapakai laman ini. Ia membolehkan pengguna berhubung dalam topik-topik perbincangan tentang sesuatu tajuk secara pintar dan teratur. Selanjutnya, Ia mempunyai beberapa ciri-ciri hebat yang boleh dimanfaatkan oleh pengguna. Bantuan mengenai majoriti ciri-ciri ini ElkArte boleh diperolehi dengan menekan klik kepada ikon tanda soalan yang ada bersebelahan bahagian berkenaan atau memilih salah satu pautan dalam laman ini. Pautan ini akan membawa anda ke laman dokumentasi pusat ElkArte di laman rasminya.';
$txt['manual_docs_and_credits'] = 'Untuk info lanjut mengenai cara menggunakan ElkArte, sila lihat <a href="%1$s" target="_blank" class="new_win">Wiki Dokumentasi</a> dan semak <a href="%2$s">kredit</a> untuk mengetahui siapa yang menghasilkan ElkArte seperti yang ada pada hari ini.';

$txt['manual_section_registering_title'] = 'Mendaftar';
$txt['manual_section_logging_in_title'] = 'Log Masuk';
$txt['manual_section_profile_title'] = 'Profil';
$txt['manual_section_search_title'] = 'Carian';
$txt['manual_section_posting_title'] = 'Mengepos';
$txt['manual_section_bbc_title'] = 'Bulletin Board Code (BBC)';
$txt['manual_section_personal_messages_title'] = 'Mesej Peribadi';
$txt['manual_section_memberlist_title'] = 'Senarai ahli';
$txt['manual_section_calendar_title'] = 'Kalendar';
$txt['manual_section_features_title'] = 'Ciri-ciri';

$txt['manual_section_registering_desc'] = 'Kebanyakan forum mensyaratkan pengguna mendaftar sebelum memberikan akses.';
$txt['manual_section_logging_in_desc'] = 'Setelah mendaftar, ahli perlu masuk bagi mengakses akaun mereka.';
$txt['manual_section_profile_desc'] = 'Setiap ahli ada profil peribadi masing-masing.';
$txt['manual_section_search_desc'] = 'Carian adalah alat yang sangat berguna untuk mencari maklumat dalam pos dan topik.';
$txt['manual_section_posting_desc'] = 'Tujuan utama berforum ialah bagi membolehkan ahli mengekspresi diri.';
$txt['manual_section_bbc_desc'] = 'Pos boleh dicantikkan dengan sedikit BBC.';
$txt['manual_section_personal_messages_desc'] = 'Ahli boleh menghantar mesej peribadi sesama sendiri.';
$txt['manual_section_memberlist_desc'] = 'Senarai ahli memaparkan semua ahli forum.';
$txt['manual_section_calendar_desc'] = 'Ahli boleh mengimbas acara, cuti dan hari jadi dengan merujuk kalendar.';
$txt['manual_section_features_desc'] = 'Ini adalah senarai ciri-ciri yang paling popular di ElkArte.';