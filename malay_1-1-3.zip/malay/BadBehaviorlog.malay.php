<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Tarikh';
$txt['badbehaviorlog_protocol'] = 'Protokol';
$txt['badbehaviorlog_method'] = 'Cara';
$txt['badbehaviorlog_request'] = 'Permintaan';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'ID Ahli';
$txt['badbehaviorlog_username'] = 'NamaPengguna';
$txt['badbehaviorlog_headers'] = 'Kepala';
$txt['badbehaviorlog_agent'] = 'Pelayar';
$txt['badbehaviorlog_entity'] = 'Pos';
$txt['badbehaviorlog_key'] = 'Kunci';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Total Entri';
$txt['badbehaviorlog_error_valid_code'] = 'Kod Alasan';
$txt['badbehaviorlog_error_valid_response'] = 'Status HTTP';
$txt['badbehaviorlog_error_valid_explaination'] = 'Alasan HTTP';
$txt['badbehaviorlog_error_valid_log'] = 'Lengkap';
$txt['badbehaviorlog_log'] = 'Log Kelakuan Buruk';
$txt['badbehaviorlog_desc'] = 'Berikut adalah senarai semua entri kelakuan buruk yang telah dilog';
$txt['badbehaviorlog_details'] = 'Butiran Tambahan';
$txt['badbehaviorlog_no_entries_found'] = 'Tiada entri log kelakuan buruk buat masa ini.';

$txt['badbehaviorlog_remove_selection'] = 'Padam Pilihan';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Apakah anda pasti mahu memadamkan log pilihan?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Padam semua hasil tapisan';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Apakah anda pasti untuk memadamkan entri yang ditapis?';
$txt['badbehaviorlog_sure_remove'] = 'Apakah anda pasti ingin memadamkan sepenuhnya log kelakuan buruk?';

$txt['badbehaviorlog_remove'] = 'Padam Pilihan';
$txt['badbehaviorlog_removeall'] = 'Padam semua';
$txt['badbehaviorlog_clear_filter'] = 'Padam tapisan';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Gunakan tapisan jenis';
$txt['badbehaviorlog_apply_filter'] = 'Guna Tapisan';
$txt['badbehaviorlog_applying_filter'] = 'GunakanTapisan';
$txt['badbehaviorlog_filter_only_member'] = 'Hanya paparkan log kelakuan buruk ahli ini';
$txt['badbehaviorlog_filter_only_ip'] = 'Hanya paparkan log kelakuan buruk alamat IP ini';
$txt['badbehaviorlog_filter_only_session'] = 'Hanya paparkan log kelakuan buruk sesi ini';
$txt['badbehaviorlog_filter_only_headers'] = 'Hanya paparkan log kelakuan buruk URL ini';
$txt['badbehaviorlog_filter_only_agent'] = 'Hanya paparkan entri agen pengguna yang sama';

$txt['badbehaviorlog_session'] = 'Sesi';
$txt['badbehaviorlog_error_url'] = 'URL laman yang telah dilog';

$txt['badbehaviorlog_reverse_direction'] = 'Terbalikkan kronologi urutan senarai';
$txt['badbehaviorlog_filter_only_type'] = 'Hanya paparkan log dengan kod ini';