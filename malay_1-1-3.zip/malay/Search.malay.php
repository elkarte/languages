<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Tetapkan Parameter Carian';
$txt['choose_board'] = 'Pilih satu ruangan untuk carian, atau kesemuanya';
$txt['all_words'] = 'Padan semua perkataan';
$txt['any_words'] = 'Padan setiap perkataan';
$txt['by_user'] = 'Oleh pengguna';

$txt['search_post_age'] = 'Usia mesej';
$txt['search_between'] = 'antara';
$txt['search_and'] = 'dan';
$txt['search_options'] = 'Pilihan';
$txt['search_show_complete_messages'] = 'Paparkan hasil sebagai mesej';
$txt['search_subject_only'] = 'Cari dalam subjek topik sahaja';
$txt['search_relevance'] = 'Berkaitan';
$txt['search_date_posted'] = 'Tarikh Ditulis';
$txt['search_order'] = 'Urutan carian';
$txt['search_orderby_relevant_first'] = 'Hasil paling berkaitan dahulu';
$txt['search_orderby_large_first'] = 'Topik terbesar dahulu';
$txt['search_orderby_small_first'] = 'Topik terkecil dahulu';
$txt['search_orderby_recent_first'] = 'Topik terbaru dahulu';
$txt['search_orderby_old_first'] = 'Topik terlama dahulu';
$txt['search_visual_verification_label'] = 'Pengesahan';
$txt['search_visual_verification_desc'] = 'Sila masukkan kod dalam gambar di atas untuk menggunakan carian.';

$txt['search_specific_topic'] = 'Cari pos dalam topik sahaja';

$txt['groups_search_posts'] = 'Grup ahli dengan akses ke fungsi carian';
$txt['search_dropdown'] = 'Hidupkan menu jatuhan bagi Carian Pantas';
$txt['search_results_per_page'] = 'Jumlah hasil carian per laman';
$txt['search_weight_frequency'] = 'Carian relatif mengutamakan jumlah mesej yang padan dalam sebuah topik';
$txt['search_weight_age'] = 'Carian relatif mengutamakan usia mesej terakhir yang padan';
$txt['search_weight_length'] = 'Carian relatif mengutamakan panjang topik';
$txt['search_weight_subject'] = 'Carian relatif mengutamakan subjek yang padan';
$txt['search_weight_first_message'] = 'Carian relatif mengutamakan mesej pertama yang padan';
$txt['search_weight_sticky'] = 'Carian relatif mengutamakan topik lekit';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Di sini anda boleh mengubah tetapan dasar fungsi carian.';
$txt['search_settings_title'] = 'Tetapan Carian';

$txt['search_weights_desc'] = 'Di sini anda boleh mengubah komponen individu atas penilaian berkaitan. ';
$txt['search_weights_sphinx'] = 'Untuk kemaskini faktor utama dengan Sphinx, anda perlu menjana dan memasang fail baru sphinx.conf.';
$txt['search_weights_title'] = 'Carian - keutamaan';
$txt['search_weights_total'] = 'Jumlah';
$txt['search_weights_save'] = 'Simpan';

$txt['search_method_desc'] = 'Di sini anda boleh menetapkan cara carian dibuat.';
$txt['search_method_title'] = 'Carian - cara';
$txt['search_method_save'] = 'Simpan';
$txt['search_method_messages_table_space'] = 'Ruang yang digunakan oleh mesej forum dalam database';
$txt['search_method_messages_index_space'] = 'Ruang yang digunakan oleh indeks mesej dalam database';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Indeks teks lengkap';
$txt['search_method_no_index_exists'] = 'sekarang ini tidak wujud';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'tidak boleh dicipta karena maksima panjang mesej melebihi 65,535 atau jenis table bukan MyISAM';
$txt['search_method_index_already_exists'] = 'telah dicipta';
$txt['search_method_fulltext_remove'] = 'padamkan indeks teks lengkap';
$txt['search_method_index_partial'] = 'dicipta sebahagiannya';
$txt['search_index_custom_resume'] = 'teruskan';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'Bagi menggunakan carian teks lengkap, anda mesti mencipta indeks teks lengkap dahulu!';
$txt['search_index_custom_warning'] = 'Agar boleh menggunakan carian indeks pilihan, anda mesti membuat indeks pilihan dahulu!';

$txt['search_index'] = 'Indeks carian';
$txt['search_index_none'] = 'Tiada indeks';
$txt['search_index_custom'] = 'Indeks pilihan';
$txt['search_index_label'] = 'Indeks';
$txt['search_index_size'] = 'Saiz';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Paksa pemakaian indeks carian';
$txt['search_match_words'] = 'Padankan keseluruhan perkataan';
$txt['search_max_results'] = 'Hasil maksima untuk dipaparkan';
$txt['search_max_results_disable'] = '(0: tanpa batas)';
$txt['search_floodcontrol_time'] = 'Syarat waktu bagi carian dari ahli yang sama';
$txt['search_floodcontrol_time_desc'] = '(0 untuk tanpa batas, dalam saat)';

$txt['additional_search_engines'] = 'Enjin carian tambahan';
$txt['setup_search_engine_add_more'] = 'Tambah enjin carian lain';

$txt['search_create_index'] = 'Cipta indeks';
$txt['search_create_index_why'] = 'Mengapa cipta indeks carian?';
$txt['search_create_index_start'] = 'Cipta';
$txt['search_predefined'] = 'Profil pra-definisi';
$txt['search_predefined_small'] = 'Indeks ukuran kecil';
$txt['search_predefined_moderate'] = 'Indeks ukuran sedang';
$txt['search_predefined_large'] = 'Indeks ukuran besar';
$txt['search_create_index_continue'] = 'Teruskan';
$txt['search_create_index_not_ready'] = 'ElkArte sedang membuat indeks carian untuk mesej anda. Bagi mengelakkan beban lebih pada server, proses ini telah dihentikan sementara. Ia akan diteruskan secara automatik dalam beberapa saat. Jika tidak, sila klik teruskan di bawah.';
$txt['search_create_index_progress'] = 'Diproses';
$txt['search_create_index_done'] = 'Indeks carian rekaan berjaya dicipta.';
$txt['search_create_index_done_link'] = 'Teruskan';
$txt['search_double_index'] = 'Anda telah mencipta dua indeks pada table mesej. Bagi prestasi terbaik, adalah disarankan untuk memadamkan salah satu dari dua indeks tersebut.';

$txt['search_error_indexed_chars'] = 'Jumlah karakter tidak mencukupi. Setidaknya, 3 karakter diperlukan untuk carian yang berguna.';
$txt['search_error_max_percentage'] = 'Peratusan kata untuk dilangkaui tidak sah. Gunakan nilai setidaknya 5%.';
$txt['error_string_too_long'] = 'String carian mesti kurang dari %1$d karakter panjang.';

$txt['search_warning_ignored_word'] = 'Terma berikut telah diabaikan dalam carian anda';
$txt['search_warning_ignored_words'] = 'Terma-terma berikut telah diabaikan dalam carian anda';

$txt['search_adjust_query'] = 'Ubah Parameter Carian';
$txt['search_adjust_submit'] = 'Semak Carian';
$txt['search_did_you_mean'] = 'Mungkin anda mencari';

$txt['search_example'] = '<em>cth:</em> Orwell "Animal Farm" -movie';

$txt['search_engines_description'] = 'Anda boleh menetapkan butiran yang hendak dipantau dari enjin carian ketika mereka mengindeks forum anda dan menyemak log mesin carian.';
$txt['spider_mode'] = 'Tahap Pemantauan Enjin Carian';
$txt['spider_mode_note'] = 'Perhatian! Pengesan level lebih tinggi meningkatkan penggunaan sumber server.';
$txt['spider_mode_off'] = 'Dimatikan';
$txt['spider_mode_standard'] = 'Lazim';
$txt['spider_mode_high'] = 'Sederhana';
$txt['spider_mode_vhigh'] = 'Agresif';
$txt['spider_settings_desc'] = 'Anda boleh mengubah tetapan mengesan lelabah di sini. Nota, jika anda mahu <a href="%1$s">aktifkan pelupusan automatik untuk log hit anda boleh tetapkannya di sini</a>';

$txt['spider_group'] = 'Gunakan keizinan terbatas dari grup';
$txt['spider_group_note'] = 'Untuk membenarkan anda menghalang lelabah mengindeks laman.';
$txt['spider_group_none'] = 'Dimatikan';

$txt['show_spider_online'] = 'Papar lelabah dalam senarai siapa online';
$txt['show_spider_online_no'] = 'Tidak sama sekali';
$txt['show_spider_online_summary'] = 'Papar jumlah lelabah';
$txt['show_spider_online_detail'] = 'Papar nama lelabah';
$txt['show_spider_online_detail_admin'] = 'Papar nama lelabah - pengurus sahaja';

$txt['spider_name'] = 'Nama Lelabah';
$txt['spider_last_seen'] = 'Terakhir Dilihat';
$txt['spider_last_never'] = 'Tidak pernah';
$txt['spider_agent'] = 'Agen Pengguna';
$txt['spider_ip_info'] = 'Alamat IP';
$txt['spiders_add'] = 'Tambah Lelabah Baru';
$txt['spiders_edit'] = 'Edit Lelabah';
$txt['spiders_remove_selected'] = 'Padam Pilihan';
$txt['spider_remove_selected_confirm'] = 'Anda yakin mahu memadamkan lelabah ini?\\n\\nSemua statistik berkaitan juga akan dipadamkan!';
$txt['spiders_no_entries'] = 'Tiada lelabah yang ditetapkan sekarang ini.';

$txt['add_spider_desc'] = 'Di sini anda boleh mengedit parameter terhadap lelabah mana yang dikategorikan. Jika agen pengguna tetamu/alamat IP padan dengan apa yang dimasukkan di bawah, ia akan dikesan sebagai lelabah mesin pencari dan dikesan menurut pilihan forum.';
$txt['spider_name_desc'] = 'Nama yang digunakan bagi merujuk lelabah.';
$txt['spider_agent_desc'] = 'Agen pengguna berkaitan lelabah ini.';
$txt['spider_ip_info_desc'] = 'Senarai alamat IP yang dipisahkan koma berkaitan dengan lelabah ini.';

$txt['spider_time'] = 'Masa';
$txt['spider_viewing'] = 'Melihat';
$txt['spider_logs_empty'] = 'Tiada log entri lelabah sekarang ini.';
$txt['spider_logs_info'] = 'Catatkan bahawa log setiap tindakan lelabah berlaku jika mengesan ditetapkan &quot;tinggi&quot; atau &quot;sangat tinggi&quot;. Butiran dari setiap tindakan lelabah hanya dilog jika mengesan ditetapkan &quot;sangat tinggi&quot;.';
$txt['spider_disabled'] = 'Dimatikan';
$txt['spider_log_empty_log'] = 'Padam semua';
$txt['spider_log_empty_log_confirm'] = 'Anda yakin anda mahu mengosongkan log sepenuhnya';

$txt['spider_logs_delete'] = 'Padam Entri';
$txt['spider_logs_delete_older'] = 'Padam semua entri lebih lama dari';
$txt['spider_logs_delete_submit'] = 'Padam';

$txt['spider_stats_delete_older'] = 'Padam statistik lelabah daripada lelabah yang tidak kelihatan dalam masa %1$s hari.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Anda yakin mahu memadamkan semua entri log?';

$txt['spider_stats_select_month'] = 'Lompat Ke Bulan';
$txt['spider_stats_page_hits'] = 'Kunjungan Laman';
$txt['spider_stats_no_entries'] = 'Tiada statistik lelabah sekarang ini.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'Anda masih tidak memilih sama ada menggunakan Sphinx atau SphinxQL sebagai Cara Carian anda';
$txt['sphinx_test_passed'] = 'Semua ujian berjaya, sistem sudah boleh berhubung dengan enjin carian sphinx menggunakan API Sphinx.';
$txt['sphinxql_test_passed'] = 'Semua ujian berjaya, sistem sudah boleh berhubung dengan enjin carian sphinx menggunakan arahan Sphinx.';
$txt['sphinx_test_connect_failed'] = 'Tidak dapat menghubungi daemon sphinx. Pastikan ia berjalan dan ditetapkan dengan betul. Carian sphinx tidak akan berfungsi selagi masalah ini tidak anda atasi.';
$txt['sphinxql_test_connect_failed'] = 'Tidak dapat menghubungi daemon sphinx. Pastikan sphinx.conf anda ada direktif pendengaran berasingan untuk port SphinxQL. Carian SphinxQL tidak akan berfungsi selagi masalah ini tidak anda atasi.';
$txt['sphinx_test_api_missing'] = 'Fail sphinxapi.php hilang dalam direktori &quot;sources&quot; anda. Anda perlu salin fai ini daripada edaran Sphinx. carian sphinx tidak akan berfungsi selagi masalah ini tidak anda atasi.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Laluan data indeks:';
$txt['sphinx_index_data_path_desc'] = 'Ini ialah laluan yang mengandungi indeks carian fail yang digunakan oleh Sphinx.<br />Ia<strong>mesti</strong> wujud dan boleh dibaca dan ditulis oleh daemon carian dan pengindeks Sphinx.';
$txt['sphinx_log_file_path'] = 'Laluan fail log:';
$txt['sphinx_log_file_path_desc'] = 'Laluan server yang mengandungi fail log yang dicipta oleh Sphinx.<br />Direktori ini mesti wujud pada server anda dan mesti boleh ditulis oleh pengindeks dan daemon carian sphinx.';
$txt['sphinx_stop_word_path'] = 'Port hentikan perkataan:';
$txt['sphinx_stop_word_path_desc'] = 'Laluan server kepada senarai hentikan perkataan (biarkan kosong jika tiada senarai hentikan perkataan).';
$txt['sphinx_memory_limit'] = 'Had memori pengindeks Sphinx:';
$txt['sphinx_memory_limit_desc'] = 'Jumlah maksima memori (RAM) yang dibenarkan bagi pengindeks gunakan.';
$txt['sphinx_searchd_server'] = 'Server daemon carian:';
$txt['sphinx_searchd_server_desc'] = 'Alamat server yang menjalankan carian tersembunyi. Ini mestilah nama hos atau alamat IP yang sah.<br />Jika tidak, localhost akan digunakan.';
$txt['sphinx_searchd_port'] = 'Port daemon carian:';
$txt['sphinx_searchd_port_desc'] = 'Port untuk daemon carian dengari.';
$txt['sphinx_searchd_qlport'] = 'Port daemon SphinxQL:';
$txt['sphinx_searchd_qlport_desc'] = 'Port untuk daemon carian dengari bagi queri SphinxQL.';
$txt['sphinx_max_matches'] = 'Maksima # sepadan:';
$txt['sphinx_max_matches_desc'] = 'Jumlah sepadan maksima bagi carian daemon yang akan kembali.';
$txt['sphinx_create_config'] = 'Cipta tetapan Sphinx';
$txt['sphinx_test_connection'] = 'Uji sambungan ke daemon Sphinx';