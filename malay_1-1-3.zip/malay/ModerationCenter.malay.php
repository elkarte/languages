<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Pusat Moderasi';
$txt['mc_main'] = 'Utama';
$txt['mc_logs'] = 'Log';
$txt['mc_posts'] = 'Pos';
$txt['mc_groups'] = 'Grup ahli';

$txt['mc_view_groups'] = 'Lihat Grup ahli';

$txt['mc_description'] = '<strong>Selamat datang, %1$s!</strong><br />Ini ialah &quot;Pusat Moderasi&quot; anda. Di sini anda boleh melaksanakan tindakan moderasi yang telah ditetapkan. Laman utama ini mengandungi ringkasan perkara yang berlaku dalam komuniti anda. Anda boleh <a href="%2$s">mennetapkan layout peribadi di sini</a>.';
$txt['mc_group_requests'] = 'Permintaan Grup ahli';
$txt['mc_member_requests'] = 'Permohonan Ahli';
$txt['mc_unapproved_posts'] = 'Pos Tidak Disetujui';
$txt['mc_watched_users'] = 'Ahli Diawasi Terbaru';
$txt['mc_watched_topics'] = 'Topik Diawasi';
$txt['mc_scratch_board'] = 'Ruangan Coretan Moderator';
$txt['mc_latest_news'] = 'Berita Terbaru Simple Machines';
$txt['mc_recent_reports'] = 'Laporan Topik Terbaru';
$txt['mc_warnings'] = 'Amaran';
$txt['mc_notes'] = 'Catatan Moderator';
$txt['mc_required'] = 'Item Yang Memerlukan Kelulusan';
$txt['mc_attachments'] = 'Lampiran yang memerlukan kelulusan';
$txt['mc_emailmod'] = 'Pos Emel yang memerlukan kelulusan';
$txt['mc_topics'] = 'Topik yang memerlukan kelulusan';
$txt['mc_posts'] = 'Pos';
$txt['mc_groupreq'] = 'Permohon grup yang memerlukan kelulusan';
$txt['mc_memberreq'] = 'Ahli yang memerlukan kelulusan';
$txt['mc_reports'] = 'Laporan pos yang memerlukan kelulusan';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'Anda tidak dapat bersambung ke fail berita terbaru  ElkArte.';

$txt['mc_recent_reports_none'] = 'Tiada laporan tertunda';
$txt['mc_watched_users_none'] = 'Tiada yang diawasi ketika ini.';
$txt['mc_group_requests_none'] = 'Tiada permintaan untuk keahlian grup.';

$txt['mc_seen'] = '%1$s terakhir terlihat %2$s';
$txt['mc_seen_never'] = '%1$s tidak pernah dilihat.';
$txt['mc_groupr_by'] = 'oleh';

$txt['mc_reported_posts_desc'] = 'Di sini anda boleh menyemak semua laporan pos yang dipaparkan oleh ahli komuniti.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Laporan Aktif';
$txt['mc_reportedp_closed'] = 'Laporan Lama';
$txt['mc_reportedp_by'] = 'oleh';
$txt['mc_reportedp_reported_by'] = 'Dilaporkan Oleh';
$txt['mc_reportedp_last_reported'] = 'Terakhir Dilaporkan';
$txt['mc_reportedp_none_found'] = 'Tiada Laporan Ditemukan';

$txt['mc_reportedp_details'] = 'Lengkap';
$txt['mc_reportedp_close'] = 'Tutup';
$txt['mc_reportedp_open'] = 'Laporan Aktif';
$txt['mc_reportedp_ignore'] = 'Abaikan';
$txt['mc_reportedp_unignore'] = 'Perhatikan';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Anda yakin ingin mengabaikan laporan lanjut mengenai mesej ini?\\n\\nIni akan mematikan laporan lanjut untuk semua moderator forum.';
$txt['mc_reportedp_close_selected'] = 'Tutup Pilihan';

$txt['mc_groupr_group'] = 'Grup ahli';
$txt['mc_groupr_member'] = 'Ahli';
$txt['mc_groupr_reason'] = 'Alasan';
$txt['mc_groupr_none_found'] = 'Tiada permintaan grup ahli yang tertunda buat masa ini';
$txt['mc_groupr_submit'] = 'Kirim';
$txt['mc_groupr_reason_desc'] = 'Alasan untuk menolak permintaan %1$s menyertai &quot;%2$s&quot;';
$txt['mc_groups_reason_title'] = 'Alasan Penolakan';
$txt['with_selected'] = 'Dengan Pilihan';
$txt['mc_groupr_approve'] = 'Lulus Permintaan';
$txt['mc_groupr_reject'] = 'Tolak Permintaan (Tanpa Alasan)';
$txt['mc_groupr_reject_w_reason'] = 'Tolak Permintaan Dengan Alasan';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Anda yakin ingin melakukan ini?';

$txt['mc_unapproved_attachments_none_found'] = 'Tiada lampiran yang tidak diluluskan ditemui!';
$txt['mc_unapproved_attachments_desc'] = 'Daripada sini anda boleh luluskan atau padam sebarang lampiran.';
$txt['mc_unapproved_replies_none_found'] = 'Tiada pos yang tidak diluluskan ditemui!';
$txt['mc_unapproved_topics_none_found'] = 'Tiada topik yang tidak diluluskan ditemui!';
$txt['mc_unapproved_posts_desc'] = 'Di sini anda boleh meluluskan atau memadamkan setiap pos yang menunggu moderasi.';
$txt['mc_unapproved_replies'] = 'Jawapan';
$txt['mc_unapproved_topics'] = 'Topik';
$txt['mc_unapproved_by'] = 'oleh';
$txt['mc_unapproved_sure'] = 'Anda yakin ingin melakukan ini?';
$txt['mc_unapproved_attach_name'] = 'Nama Lampiran';
$txt['mc_unapproved_attach_size'] = 'Besar fail';
$txt['mc_unapproved_attach_poster'] = 'Penulis';
$txt['mc_viewmodreport'] = 'Laporan Moderasi untuk %1$s dengan %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Ahli yang melaporkan pos ini';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Tindakan diambil oleh moderator lain';
$txt['mc_modreport_mod_comments'] = 'Komen Moderator';
$txt['mc_modreport_no_mod_comment'] = 'Buat masa ini tiada komen moderator';
$txt['mc_modreport_add_mod_comment'] = 'Tambah komen';

$txt['show_notice'] = 'Teks Catatan';
$txt['show_notice_subject'] = 'Subjek';
$txt['show_notice_text'] = 'Teks';

$txt['mc_watched_users_title'] = 'Ahli Diawasi';
$txt['mc_watched_users_desc'] = 'Di sini anda boleh menyimpan jejak semua ahli yang sudah ditempatkan dalam &quot;pengawasan&quot; oleh pasukan moderasi.';
$txt['mc_watched_users_post'] = 'Lihat dengan Pos';
$txt['mc_watched_users_warning'] = 'Tingkatkan Amaran';
$txt['mc_watched_users_last_login'] = 'Terakhir Masuk';
$txt['mc_watched_users_last_post'] = 'Pos Terakhir';
$txt['mc_watched_users_no_posts'] = 'Tiada pos dari ahli yang diawasi.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Anda yakin ingin memadam pos ini?';
$txt['mc_watched_users_delete_posts'] = 'Anda yakin ingin memadam pos ini?';
$txt['mc_watched_users_posted'] = 'Dipos';
$txt['mc_watched_users_member'] = 'Ahli';

$txt['mc_warnings_description'] = 'Dari bahagian ini anda boleh melihat amaran yang sudah diberikan kepada ahli forum. Anda juga boleh menambah dan mengubahsuai template makluman yang dipakai ketika mengirimkan amaran bagi ahli.';
$txt['mc_warning_log'] = 'Log Amaran';
$txt['mc_warning_templates'] = 'Template Pilihan';
$txt['mc_warning_log_title'] = 'Melihat Log Amaran';
$txt['mc_warning_templates_title'] = 'Template Amaran Pilihan';

$txt['mc_warnings_none'] = 'Belum ada amaran yang diberikan!';
$txt['mc_warnings_recipient'] = 'Penerima';

$txt['mc_warning_templates_none'] = 'Tiada template amaran yang sudah dibuat';
$txt['mc_warning_templates_time'] = 'Jam Dibuat';
$txt['mc_warning_templates_name'] = 'Template';
$txt['mc_warning_templates_creator'] = 'Dibuat Oleh';
$txt['mc_warning_template_add'] = 'Tambah Template';
$txt['mc_warning_template_modify'] = 'Edit Template';
$txt['mc_warning_template_delete'] = 'Padam Pilihan';
$txt['mc_warning_template_delete_confirm'] = 'Anda yakin ingin memadam template pilihan?';

$txt['mc_warning_template_desc'] = 'Gunakan laman ini untuk mengisi butiran template. Perhatikan bahawa subjek email bukan bahagian dari template. Ambil perhatian kerana makluman dikirimkan menggunakan mesej, anda boleh menggunakan BBC dalam template. Jika anda menggunakan variabel {MESSAGE} maka template ini tidak akan tersedia ketika menerbitkan amaran umum (misalnya amaran yang tidak berkaitan dengan pos).';
$txt['mc_warning_template_title'] = 'Judul Template';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},⏎
⏎
Anda diberikan amaran kerana melakukan aktiviti tidak senonoh. Sila hentikan semua aktiviti tersebut dan patuhi peratuan forum, jika tidak, kami terpaksa mengambil tindakan selanjutnya.⏎
⏎
{REGARDS}';
$txt['mc_warning_template_personal'] = 'Template Pribadi';
$txt['mc_warning_template_personal_desc'] = 'Jika anda memilih opsi ini hanya anda yang boleh melihatnya, mengedit, dan menggunakan template ini. Jika tidak dipilih, semua moderator akan boleh menggunakan template ini.';
$txt['mc_warning_template_error_no_title'] = 'Anda perlu letakkan tajuk.';
$txt['mc_warning_template_error_no_body'] = 'Anda perlu letakkan isi.';

$txt['mc_settings'] = 'Ubah Tetapan';
$txt['mc_prefs_title'] = 'Keutamaan Moderasi';
$txt['mc_prefs_desc'] = 'Bahagian ini mengizinkan anda untuk menetapkan beberapa keutamaan peribadi untuk aktiviti berkaitan moderasi seperi email makluman.';
$txt['mc_prefs_homepage'] = 'Item dipaparkan pada laman moderasi';
$txt['mc_prefs_latest_news'] = 'Berita SM';
$txt['mc_prefs_show_reports'] = 'Papar jumlah laporan terbuka dalam header forum';
$txt['mc_prefs_notify_report'] = 'Beritahu laporan topik';
$txt['mc_prefs_notify_report_never'] = 'Tidak pernah';
$txt['mc_prefs_notify_report_moderator'] = 'Hanya jika ia adalah ruangan yang saya moderasikan';
$txt['mc_prefs_notify_report_always'] = 'Selalu';
$txt['mc_prefs_notify_approval'] = 'Beritahu item yang menunggu kelulusan';
$txt['mc_logoff'] = 'Tamatkan Sesi Moderator';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Tambah catatan baru';
$txt['mc_add_note'] = 'Tambah';