<?php
// Version: 1.1; ManageSmileys

$txt['smiley_sets_save'] = 'Simpan Ubahan';
$txt['smiley_sets_add'] = 'Set Mimik Baru';
$txt['smiley_sets_delete'] = 'Padam yang dipilih';
$txt['smiley_sets_confirm'] = 'Anda yakin mahu memadamkan set mimik ini?\\n\\nCatatan: Ini tidak akan memadam imej, hanya pilihannya saja.';
$txt['smiley_sets_none'] = 'Tiada set2 mimik buat masa ini.';

$txt['setting_smiley_sets_default'] = 'Set Mimik Default';
$txt['setting_smiley_sets_enable'] = 'Hidupkan pemilihan set mimik oleh ahli';
$txt['setting_smiley_enable'] = 'Hidupkan mimik2 rekaan';
$txt['setting_smileys_url'] = 'URL asas untuk semua set mimik';
$txt['setting_smileys_dir'] = 'Laluan tetap ke semua set mimik';
$txt['setting_messageIcons_enable'] = 'Aktifkan ikon mesej pilihan';
$txt['setting_messageIcons_enable_note'] = '(sebaliknya, ikon mesej default yang akan dipakai.)';
$txt['groups_manage_smileys'] = 'Grup yang diizinkan untuk mengurus mimik dan ikon mesej';

$txt['smiley_sets_name'] = 'Nama';
$txt['smiley_sets_url'] = 'URL';
$txt['smiley_sets_default'] = 'Default';

$txt['smileys_add_method'] = 'Sumber Gambar';
$txt['smileys_add_existing'] = 'Gunakan Fail Sedia Ada';
$txt['smileys_add_upload'] = 'Muatnaik mimik baru';
$txt['smileys_add_upload_choose'] = 'Fail yang dimuatnaik';
$txt['smileys_add_upload_choose_desc'] = 'Imej untuk dipakai oleh semua set mimik.';
$txt['smileys_add_upload_all'] = 'Gambar sama untuk semua set';
$txt['smileys_add_upload_for1'] = 'Gambar untuk';
$txt['smileys_add_upload_for2'] = 'set';

$txt['smileys_enable_note'] = '(sebaliknya, mimik default yang akan dipakai.)';
$txt['smileys_code'] = 'Kod';
$txt['smileys_filename'] = 'Nama fail';
$txt['smileys_description'] = 'Tip alatan atau penjelasan';
$txt['smileys_remove'] = 'Buang';
$txt['smileys_save'] = 'Simpan Ubahan';
$txt['smileys_delete'] = 'Padam Mimik';
// Don't use entities in the below string.
$txt['smileys_delete_confirm'] = 'Anda yakin ingin memadam mimik ini?';
$txt['smileys_with_selected'] = 'Dengan yang Dipilih';
$txt['smileys_make_hidden'] = 'Sembunyikan';
$txt['smileys_show_on_post'] = 'Papar pada Borang Pos';
$txt['smileys_show_on_popup'] = 'Papar pada Popup';

$txt['smiley_settings_explain'] = 'Tetapan ini mengizinkan anda untuk mengubah set mimik default, mengizinkan orang untuk memilih mimik sendiri serta menetapkan laluan dan data konfigurasi.';
$txt['smiley_editsets_explain'] = 'Set2 Mimik adalah kumpulan mimik yang boleh dipilih oleh pengguna anda.  Sebagai contoh, anda dapat memiliki mimik2 kuning dan merah.<br />Di sini anda dapat mengubah nama dan lokasi dari setiap set mimik - akan tetapi, ingat bahawa semua set berkongsi mimik yang sama.';
$txt['smiley_editsmileys_explain'] = 'Ubah mimik anda di sini dengan klik pada mimik yang ingin anda ubah. Ingat bahawa mimik ini semuanya harus ada dalam semua set jika tidak ada mimik2 yang tidak akan keluar.  Jangan lupa simpan setelah anda selesai mengedit!';
$txt['smiley_setorder_explain'] = 'Ubah urutan mimik di sini.';
$txt['smiley_addsmiley_explain'] = 'Di sini anda dapat menambah mimik baru - baik dari fail yang telah ada ataupun dengan memuatnaik yang baru.';

$txt['smiley_set_select_default'] = 'Set Mimik Default';
$txt['smiley_set_new'] = 'Buat set mimik yang baru';
$txt['smiley_set_modify_existing'] = 'Ubah set mimik sedia ada';
$txt['smiley_set_modify'] = 'Ubah';
$txt['smiley_set_import_directory'] = 'Import mimik2 yang ada dalam direktori ini';
$txt['smiley_set_import_single'] = 'Ada mimik dalam set mimik ini yang belum diimport. Klik';
$txt['smiley_set_import_multiple'] = 'Ada %1$d mimik dalam direktori yang masih belum diimport. Klik';
$txt['smiley_set_to_import_single'] = 'untuk mengimportnya sekarang.';
$txt['smiley_set_to_import_multiple'] = 'untuk mengimportnya sekarang.';

$txt['smileys_location'] = 'Lokasi';
$txt['smileys_location_form'] = 'Borang pos';
$txt['smileys_location_hidden'] = 'Sembunyi';
$txt['smileys_location_popup'] = 'Popup';
$txt['smileys_modify'] = 'Ubah';
$txt['smileys_not_found_in_set'] = 'Mimik tidak ditemukan dalam set';
$txt['smileys_default_description'] = '(Sisipkan penjelasan)';
$txt['smiley_new'] = 'Tambah mimik baru';
$txt['smiley_modify_existing'] = 'Ubah mimik';
$txt['smiley_preview'] = 'Semak';
$txt['smiley_preview_using'] = 'menggunakan set mimik';
$txt['smileys_confirm'] = 'Anda yakin ingin memadam mimik ini?\\n\\nCatatan: Ini tidak akan memadam gambar, hanya pilihan saja.';
$txt['smileys_location_form_description'] = 'Mimik2 ini akan kelihatan pada kawasan teks, ketika menulis mesej baru pada forum atau Mesej Peribadi.';
$txt['smileys_location_popup_description'] = 'Mimik ini akan dipaparkan dalam popup setelah pengguna klik \'[lagi]\'';
$txt['smileys_move_select_destination'] = 'Pilih destinasi mimik';
$txt['smileys_move_select_smiley'] = 'Pilih mimik untuk dipindahkan';
$txt['smileys_move_here'] = 'Pindahkan mimik ke lokasi ini';
$txt['smileys_no_entries'] = 'Tidak ada mimik yang ditetapkan buat masa ini.';
$txt['smileys_moved_done'] = 'Mimik telah berjaya dipindahkan';
$txt['smileys_moved_fail'] = 'Mimik tidak dapat dipindahkan';

$txt['icons_edit_icons_explain'] = 'Dari sini anda dapat mengubah ikon mesej mana yang tersedia dalam papan anda. Anda dapat menambah, mengedit dan memadam ikon, juga membatasi pemakaiannya pada papan tertentu.';
$txt['icons_edit_icons_all_boards'] = 'Tersedia Dalam Semua Papan';
$txt['icons_board'] = 'Ruangan';
$txt['icons_confirm'] = 'Anda yakin ingin memadam ikon ini?\\n\\nCatatan ini hanya akan menghentikan penulis baru dari penggunaan ikon, gambar akan tetap ada.';
$txt['icons_add_new'] = 'Tambah Ikon Baru';

$txt['icons_edit_icon'] = 'Edit Ikon Mesej';
$txt['icons_new_icon'] = 'Ikon Mesej Baru';
$txt['icons_location_first_icon'] = 'Sebagai Ikon Pertama';
$txt['icons_location_after'] = 'Setelah';
$txt['icons_filename_all_png'] = 'Semua fail mestilah fail &quot;png&quot;';
$txt['icons_no_entries'] = 'Tidak ada ikon mesej yang ditetapkan buat masa ini.';
$txt['icons_reordered'] = 'Ikon mesej berjaya disusun';
$txt['icons_reorder_note'] = 'Anda boleh mengubah aturan ikon mesej dengan seret dan letak satu2 item pada lokasi baru dalam senarai.';