<?php
// Version: 1.1; ManageMembers

$txt['groups'] = 'Grup';
$txt['viewing_groups'] = 'Melihat Grup Ahli';

$txt['membergroups_title'] = 'Urus Grup Ahli';
$txt['membergroups_description'] = 'Grup ahli adalah kumpulan ahli yang ada tetapan keizinan, rupa atau hak akses yang sama. Sebahagian grup ahli adalah berdasarkan jumlah pos yang dibuat oleh pengguna. Anda boleh menetapkan grup ahli seseorang dengan memilih profil dan mengubah tetapan akaun mereka.';
$txt['membergroups_modify'] = 'Ubah';
$txt['membergroups_modify_parent'] = 'Modify parent group';

$txt['membergroups_add_group'] = 'Tambah grup';
$txt['membergroups_regular'] = 'Grup biasa';
$txt['membergroups_post'] = 'Grup berdasarkan kiraan pos';
$txt['membergroups_guests_na'] = 'kosong';

$txt['membergroups_group_name'] = 'Nama grup ahli';
$txt['membergroups_new_board'] = 'Ruangan Yang Kelihatan';
$txt['membergroups_new_board_desc'] = 'Ruangan yang boleh dilihat grup ahli';
$txt['membergroups_new_board_post_groups'] = '<em>Catatan: Biasanya, grup pos tidak memerlukan akses kerana grup ahli akan memberikan mereka akses.</em>';
$txt['membergroups_new_as_inherit'] = 'warisi daripada';
$txt['membergroups_new_as_type'] = 'secara jenis';
$txt['membergroups_new_as_copy'] = 'based off of';
$txt['membergroups_new_copy_none'] = '(tiada)';
$txt['membergroups_can_edit_later'] = 'Anda boleh mengubahnya kemudian.';

$txt['membergroups_edit_group'] = 'Ubah Grup Ahli';
$txt['membergroups_edit_name'] = 'Nama grup';
$txt['membergroups_edit_inherit_permissions'] = 'Warisi Keizinan';
$txt['membergroups_edit_inherit_permissions_desc'] = 'Pilih &quot;Tidak&quot; untuk hidupkan grup dengan set keizinan tersendiri.';
$txt['membergroups_edit_inherit_permissions_no'] = 'Tidak - Gunakan Keizinan Unik';
$txt['membergroups_edit_inherit_permissions_from'] = 'Warisi Daripada';
$txt['membergroups_edit_hidden'] = 'Kebolehlihatan';
$txt['membergroups_edit_hidden_no'] = 'Kelihatan';
$txt['membergroups_edit_hidden_boardindex'] = 'Visible - Apart from in group key';
$txt['membergroups_edit_hidden_all'] = 'Invisible';
// Do not use numeric entities in the below string.
$txt['membergroups_edit_hidden_warning'] = 'Are you sure you want to disallow assignment of this group as a users primary group?\\n\\nDoing so will restrict assignment to additional groups only, and will update all current &quot;primary&quot; members to have it as an additional group only.';
$txt['membergroups_edit_desc'] = 'Group description';
$txt['membergroups_edit_group_type'] = 'Group type';
$txt['membergroups_edit_select_group_type'] = 'Select Group type';
$txt['membergroups_group_type_private'] = 'Private <span class="smalltext">(Membership must be assigned)</span>';
$txt['membergroups_group_type_protected'] = 'Protected <span class="smalltext">(Only administrators can manage and assign)</span>';
$txt['membergroups_group_type_request'] = 'Requestable <span class="smalltext">(User may request membership)</span>';
$txt['membergroups_group_type_free'] = 'Free <span class="smalltext">(User may leave and join group at will)</span>';
$txt['membergroups_group_type_post'] = 'Post Based <span class="smalltext">(Membership based on post count)</span>';
$txt['membergroups_min_posts'] = 'Required posts';
$txt['membergroups_online_color'] = 'Color in online list';
$txt['membergroups_icon_count'] = 'Number of icon images';
$txt['membergroups_icon_image'] = 'Icon image filename';
$txt['membergroups_icon_image_note'] = 'Upload icon images in to the default theme directory to enable selection.<br />Select the icon to change it.';
$txt['membergroups_max_messages'] = 'Max personal messages';
$txt['membergroups_max_messages_note'] = '0 = unlimited';
$txt['membergroups_max_messages_desc'] = 'Here you can set the limit of personal messages a user can keep on the server.<br />
To allow store an unlimited number of personal messages, you can set the value to 0';
$txt['membergroups_edit_save'] = 'Simpan';
$txt['membergroups_delete'] = 'Padam';
$txt['membergroups_confirm_delete'] = 'Are you sure you want to delete this group?';

$txt['membergroups_members_title'] = 'Viewing Group';
$txt['membergroups_members_group_members'] = 'Group Members';
$txt['membergroups_members_no_members'] = 'This group is currently empty';
$txt['membergroups_members_add_title'] = 'Add a member to this group';
$txt['membergroups_members_add_desc'] = 'List of Members to Add';
$txt['membergroups_members_add'] = 'Add Members';
$txt['membergroups_members_remove'] = 'Remove from Group';
$txt['membergroups_members_last_active'] = 'Terakhir Aktif';
$txt['membergroups_members_additional_only'] = 'Add as additional group only.';
$txt['membergroups_members_group_moderators'] = 'Group Moderators';
$txt['membergroups_members_description'] = 'Keterangan';
// Use javascript escaping in the below.
$txt['membergroups_members_deadmin_confirm'] = 'Are you sure you wish to remove yourself from the Administration group?';

$txt['membergroups_postgroups'] = 'Post groups';
$txt['membergroups_settings'] = 'Membergroup Settings';
$txt['groups_manage_membergroups'] = 'Groups allowed to change membergroups';
$txt['membergroups_select_permission_type'] = 'Select permission profile';
$txt['membergroups_images_url'] = '{theme URL}/images/group_icons/';
$txt['membergroups_select_visible_boards'] = 'Show boards';
$txt['membergroups_members_top'] = 'Ahli';
$txt['membergroups_name'] = 'Nama';
$txt['membergroups_icons'] = 'Ikon';

$txt['admin_browse_approve'] = 'Members whose accounts are awaiting approval';
$txt['admin_browse_approve_desc'] = 'From here you can manage all members who are waiting to have their accounts approved.';
$txt['admin_browse_activate'] = 'Members whose accounts are awaiting activation';
$txt['admin_browse_activate_desc'] = 'This screen lists all the members who have still not activated their accounts at your forum.';
$txt['admin_browse_awaiting_approval'] = 'Awaiting Approval [%1$d]';
$txt['admin_browse_awaiting_activate'] = 'Awaiting Activation [%1$d]';

$txt['admin_browse_username'] = 'Nama pengguna';
$txt['admin_browse_email'] = 'Alamat Emel';
$txt['admin_browse_ip'] = 'Alamat IP';
$txt['admin_browse_registered'] = 'Registered';
$txt['admin_browse_id'] = 'ID';
$txt['admin_browse_with_selected'] = 'Dengan yang Dipilih';
$txt['admin_browse_no_members_approval'] = 'No members currently await approval.';
$txt['admin_browse_no_members_activate'] = 'No members currently have not activated their accounts.';

// Don't use entities in the below strings, except the main ones. (lt, gt, quot.)
$txt['admin_browse_warn'] = 'all selected members?';
$txt['admin_browse_outstanding_warn'] = 'all affected members?';
$txt['admin_browse_w_approve'] = 'Luluskan';
$txt['admin_browse_w_activate'] = 'Aktifkan';
$txt['admin_browse_w_delete'] = 'Padam';
$txt['admin_browse_w_reject'] = 'Reject (Delete)';
$txt['admin_browse_w_remind'] = 'Remind';
$txt['admin_browse_w_approve_deletion'] = 'Approve (Delete Accounts)';
$txt['admin_browse_w_email'] = 'and send email';
$txt['admin_browse_w_approve_require_activate'] = 'Approve and require activation';

$txt['admin_browse_filter_by'] = 'Filter By';
$txt['admin_browse_filter_show'] = 'Displaying';
$txt['admin_browse_filter_type_0'] = 'Unactivated new accounts';
$txt['admin_browse_filter_type_2'] = 'Unactivated email changes';
$txt['admin_browse_filter_type_3'] = 'Unapproved new accounts';
$txt['admin_browse_filter_type_4'] = 'Unapproved account deletions';
$txt['admin_browse_filter_type_5'] = 'Unapproved "Under Age" Accounts';

$txt['admin_browse_outstanding'] = 'Outstanding Members';
$txt['admin_browse_outstanding_days_1'] = 'With all members who registered longer than';
$txt['admin_browse_outstanding_days_2'] = 'days ago';
$txt['admin_browse_outstanding_perform'] = 'Perform the following action';
$txt['admin_browse_outstanding_go'] = 'Perform Action';

$txt['check_for_duplicate'] = 'Check for duplicates';
$txt['dont_check_for_duplicate'] = 'Don\'t check for duplicates';
$txt['duplicates'] = 'Duplicates';

$txt['not_activated'] = 'Tidak diaktifkan';