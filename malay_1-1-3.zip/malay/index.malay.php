<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'ms_MY';
$txt['lang_dictionary'] = 'ms';
$txt['lang_spelling'] = 'melayu';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'Ahad';
$txt['monday'] = 'Isnin';
$txt['tuesday'] = 'Selasa';
$txt['wednesday'] = 'Rabu';
$txt['thursday'] = 'Khamis';
$txt['friday'] = 'Jumaat';
$txt['saturday'] = 'Sabtu';

$txt['sunday_short'] = 'Ahad';
$txt['monday_short'] = 'Isnin';
$txt['tuesday_short'] = 'Selasa';
$txt['wednesday_short'] = 'Rabu';
$txt['thursday_short'] = 'Khamis';
$txt['friday_short'] = 'Jumaat';
$txt['saturday_short'] = 'Sabtu';

$txt['january'] = 'Januari';
$txt['february'] = 'Februari';
$txt['march'] = 'Mac';
$txt['april'] = 'April';
$txt['may'] = 'Mei';
$txt['june'] = 'Jun';
$txt['july'] = 'Julai';
$txt['august'] = 'Ogos';
$txt['september'] = 'September';
$txt['october'] = 'Oktober';
$txt['november'] = 'November';
$txt['december'] = 'Disember';

$txt['january_titles'] = 'Januari';
$txt['february_titles'] = 'Februari';
$txt['march_titles'] = 'Mac';
$txt['april_titles'] = 'April';
$txt['may_titles'] = 'Mei';
$txt['june_titles'] = 'Jun';
$txt['july_titles'] = 'Julai';
$txt['august_titles'] = 'Ogos';
$txt['september_titles'] = 'September';
$txt['october_titles'] = 'Oktober';
$txt['november_titles'] = 'November';
$txt['december_titles'] = 'Disember';

$txt['january_short'] = 'Jan';
$txt['february_short'] = 'Feb';
$txt['march_short'] = 'Mac';
$txt['april_short'] = 'Apr';
$txt['may_short'] = 'Mei';
$txt['june_short'] = 'Jun';
$txt['july_short'] = 'Jul';
$txt['august_short'] = 'Ogos';
$txt['september_short'] = 'Sep';
$txt['october_short'] = 'Okt';
$txt['november_short'] = 'Nov';
$txt['december_short'] = 'Dis';

$txt['time_am'] = 'pagi';
$txt['time_pm'] = 'petang';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Home';
$txt['community'] = 'Komuniti';
// Sub menu labels
$txt['help'] = 'Bantuan';
$txt['search'] = 'Carian';
$txt['calendar'] = 'Kalendar';
$txt['members'] = 'Ahli';
$txt['recent_posts'] = 'Pos Terbaru';

$txt['admin'] = 'Pengurus';
// Sub menu labels
$txt['errlog'] = 'Log Kesalahan';
$txt['package'] = 'Pengurus Pakej';
$txt['edit_permissions'] = 'Keizinan';
$txt['modSettings_title'] = 'Ciri dan Pilihan';

$txt['moderate'] = 'Sederhana';
// Sub menu labels
$txt['modlog_view'] = 'Log Seliaan';
$txt['mc_emailerror'] = 'Emel Tidak Diluluskan';
$txt['mc_reported_posts'] = 'Pos Dilaporkan';
$txt['mc_reported_pms'] = 'Reported Personal Messages';
$txt['mc_unapproved_attachments'] = 'Lampiran Tidak Diluluskan';
$txt['mc_unapproved_poststopics'] = 'Pos dan Topik Tidak Diluluskan';

$txt['pm_short'] = 'Mesej Saya';
// Sub menu labels
$txt['pm_menu_read'] = 'Baca mesej Anda';
$txt['pm_menu_send'] = 'Kirim mesej';

$txt['account_short'] = 'Akaun';
// Sub menu labels
$txt['profile'] = 'Profil';
$txt['mydrafts'] = 'My Drafts';
$txt['summary'] = 'Ringkasan';
$txt['theme'] = 'Rupa dan Susun Atur';
$txt['account'] = 'Tetapan Akaun';
$txt['forumprofile'] = 'Profil Forum';

$txt['view_unread_category'] = 'Pos Baru';
$txt['view_replies_category'] = 'Jawapan Baru';

$txt['login'] = 'Masuk';
$txt['register'] = 'Pendaftaran';
$txt['logout'] = 'Keluar';
// End main menu strings.

$txt['save'] = 'Simpan';

$txt['modify'] = 'Ubah';
$txt['forum_index'] = '%1$s - Indeks';
$txt['board_name'] = 'Nama ruangan';
$txt['posts'] = 'Pos';

$txt['member_postcount'] = 'Pos';
$txt['no_subject'] = '(Tanpa subjek)';
$txt['view_profile'] = 'Lihat Profil';
$txt['guest_title'] = 'Tetamu';
$txt['author'] = 'Pencipta';
$txt['on'] = 'pada';
$txt['remove'] = 'Buang';
$txt['start_new_topic'] = 'Mulakan topik baru';

// Use numeric entities in the below string.
$txt['username'] = 'Nama pengguna';
$txt['password'] = 'Kata Kunci';

$txt['username_no_exist'] = 'Nama pengguna tidak ada.';
$txt['no_user_with_email'] = 'Tidak ada nama pengguna dengan email tersebut.';

$txt['board_moderator'] = 'Moderator Ruangan';
$txt['remove_topic'] = 'Buang';
$txt['topics'] = 'Topik';
$txt['modify_msg'] = 'Ubah mesej';
$txt['name'] = 'Nama';
$txt['email'] = 'Email';
$txt['user_email_address'] = 'Alamat Emel';
$txt['subject'] = 'Subjek';
$txt['message'] = 'Mesej';
$txt['redirects'] = 'Peralihan';

$txt['choose_pass'] = 'Pilih kata kunci';
$txt['verify_pass'] = 'Pengesahan kata kunci';
$txt['position'] = 'Jawatan';
$txt['notify_announcements'] = 'Sign up to receive important site news by email';

$txt['profile_of'] = 'Lihat profil';
$txt['total'] = 'Jumlah';
$txt['posts_made'] = 'Pos';
$txt['topics_made'] = 'Topik';
$txt['website'] = 'Laman Web';
$txt['contact'] = 'Hubungi Kami';
$txt['warning_status'] = 'Status Peringatan';
$txt['user_warn_watch'] = 'Pengguna ada dalam daftar pengawasan moderator';
$txt['user_warn_moderate'] = 'Pos pengguna bergabung ke giliran kelulusan';
$txt['user_warn_mute'] = 'Pengguna disekat daripada penulisan';
$txt['warn_watch'] = 'Diawasi';
$txt['warn_moderate'] = 'Dimoderasi';
$txt['warn_mute'] = 'Didiamkan';
$txt['warning_issue'] = 'Amaran';

$txt['message_index'] = 'Indeks Mesej';
$txt['news'] = 'Berita';
$txt['page'] = 'Laman';
$txt['prev'] = 'sebelumnya';
$txt['next'] = 'seterusnya';

$txt['post'] = 'Pos';
$txt['error_occurred'] = 'Kesalahan Berlaku';
$txt['send_error_occurred'] = 'Kesalahan telah berlaku, <a href="{href}">sila klik di sini untuk mencuba lagi</a>.';
$txt['require_field'] = 'Petak ini diperlukan.';
$txt['started_by'] = 'Dimulai oleh';
$txt['topic_started_by'] = 'Dimulai oleh %1$s';
$txt['topic_started_by_in'] = 'Dimulai oleh %1$s dalam %2$s';
$txt['replies'] = 'Jawapan';
$txt['last_post'] = 'Pos terakhir';
$txt['first_post'] = 'Pos pertama';
$txt['last_poster'] = 'Penulis pos terakhir';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s </span><span class="board_lastposter">oleh %1$s</span><span class="board_lasttime"><strong>Pos terakhir: </strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s Pos dalam %2$s Topik oleh %3$s Ahli';
$txt['show'] = 'Paparkan';
$txt['hide'] = 'Sembunyikan';
$txt['sort_by'] = 'Susun Secara';
$txt['sort_asc'] = 'Susun  teratur';
$txt['sort_desc'] = 'Susun terbalik';

$txt['admin_login'] = 'Login Pengurus';
// Use numeric entities in the below string.
$txt['topic'] = 'Topik';
$txt['help'] = 'Bantuan';
$txt['notify'] = 'Beritahu';
$txt['unnotify'] = 'Jangan maklumkan';
$txt['notify_request'] = 'Anda menginginkan email makluman bila seseorang menjawab topik ini?';
// Use numeric entities in the below string.
$txt['regards_team'] = "Salam,\nPengurusan {forum_name_html_unsafe}.";
$txt['notify_replies'] = 'Beritahu jawapan';
$txt['move_topic'] = 'Alih';
$txt['move_to'] = 'Pindahkan ke';
$txt['pages'] = 'Laman';
$txt['users_active'] = 'Pengguna aktif %1$d minit yang lalu';
$txt['personal_messages'] = 'Mesej Peribadi';
$txt['reply_quote'] = 'Jawab dengan ungkapan';
$txt['reply'] = 'Jawab';
$txt['reply_number'] = 'Jawapan #%1$s';
$txt['approve'] = 'Luluskan';
$txt['unapprove'] = 'Tidak diluluskan';
$txt['approve_all'] = 'Luluskan semua';
$txt['awaiting_approval'] = 'Menunggu Kelulusan';
$txt['attach_awaiting_approve'] = 'Lampiran menunggu kelulusan';
$txt['post_awaiting_approval'] = 'Catatan: Mesej ini menunggu kelulusan oleh moderator.';
$txt['there_are_unapproved_topics'] = 'Ada %1$s topik dan %2$s pos menunggu kelulusan dalam papan ini. Klik <a href="%3$s">di sini</a> untuk melihat semuanya.';
$txt['send_message'] = 'Hantar mesej';

$txt['msg_alert_no_messages'] = 'anda tiada sebarang mesej';
$txt['msg_alert_one_message'] = 'anda ada <a href="%1$s">1 mesej</a>';
$txt['msg_alert_many_message'] = 'anda ada <a href="%1$s">%2$d mesej</a>';
$txt['msg_alert_one_new'] = '1 yang baru';
$txt['msg_alert_many_new'] = '%1$d yang baru';
$txt['remove_message'] = 'Padam mesej';

$txt['topic_alert_none'] = 'Tiada mesej...';
$txt['pm_alert_none'] = 'Tiada mesej...';

$txt['online_users'] = 'Pengguna Online'; //Deprecated
$txt['online_now'] = 'Hadir Sekarang';
$txt['personal_message'] = 'Mesej Peribadi';
$txt['jump_to'] = 'Lompat ke';
$txt['go'] = 'Pergi';
$txt['are_sure_remove_topic'] = 'Anda yakin ingin memadamkan topik ini?';
$txt['yes'] = 'Ya';
$txt['no'] = 'Tidak';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'pada';

$txt['search'] = 'Carian';
$txt['all'] = 'Semua';
$txt['search_entireforum'] = 'Seluruh Forum';
$txt['search_thisbrd'] = 'Ruangan ini';
$txt['search_thistopic'] = 'Topik ini';
$txt['search_members'] = 'Ahli';

$txt['back'] = 'Kembali';
$txt['continue'] = 'Teruskan';
$txt['password_reminder'] = 'Pengingat kata kunci';
$txt['topic_started'] = 'Topik dimulai oleh';
$txt['title'] = 'Tajuk';
$txt['post_by'] = 'Dipos oleh';
$txt['welcome_newest_member'] = 'Sila alu2kan %1$s, ahli terbaru kita.';
$txt['admin_center'] = 'Pusat Pengurusan';
$txt['admin_session_active'] = 'Anda sedang aktif dalam sesi pengurusan. Kami sarankan agar anda <strong><a class="strong" href="%1$s">menamatkan sesi ini</a></strong> apabila telah selesai dengan tugas2 pengurusan.';
$txt['admin_maintenance_active'] = 'Forum ini sedang dalam mod penyenggaraan, hanya pengurus boleh log masuk. Jangan lupa untuk <strong><a class="strong" href="%1$s">keluar daripada mod penyenggaraan</a></strong> apabila telah selesai dengan tugas2 pengurusan.';
$txt['query_command_denied'] = 'Kesalahan MySQL berlaku, sila verifikasi setup anda:';
$txt['query_command_denied_guests'] = 'Nampaknya forum ini ada sedikit masalah database. Masalah ini hanya sementara, jadi sila datang kembali kemudian dan cuba semula. Sekiranya perkara ini berterusan, sila laporkan mesej ini kepada pengurus:';
$txt['query_command_denied_guests_msg'] = 'arahan %1$s dinafikan pada database';
$txt['last_edit_by'] = '<span class="lastedit">Edit Terakhir</span>: %1$s oleh %2$s';
$txt['notify_deactivate'] = 'Apakah anda ingin membatalkan makluman atas topik ini?';

$txt['date_registered'] = 'Tarikh Mendaftar';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'Lihat pos terbaru pada forum.';
$txt['is_recent_updated'] = '%1$s adalah topik terkini yang dikemaskinikan.';

$txt['male'] = 'Lelaki';
$txt['female'] = 'Wanita';

$txt['error_invalid_characters_username'] = 'Pemakaian karakter tidak benar dalam Nama pengguna.';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Salam,';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Selamat datang,';
$txt['select_destination'] = 'Sila pilih tujuan';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Dipos oleh';

$txt['icon_smiley'] = 'Senyum';
$txt['icon_angry'] = 'Marah';
$txt['icon_cheesy'] = 'Sinis';
$txt['icon_laugh'] = 'Ketawa';
$txt['icon_sad'] = 'Sedih';
$txt['icon_wink'] = 'Kenyit';
$txt['icon_grin'] = 'Geram';
$txt['icon_shocked'] = 'Terkejut';
$txt['icon_cool'] = 'Tenang';
$txt['icon_huh'] = 'Hah';
$txt['icon_rolleyes'] = 'Pusing Mata';
$txt['icon_tongue'] = 'Ejek';
$txt['icon_embarrassed'] = 'Malu';
$txt['icon_lips'] = 'Tutup mulut';
$txt['icon_undecided'] = 'Pening';
$txt['icon_kiss'] = 'Cium';
$txt['icon_cry'] = 'Nangis';
$txt['icon_angel'] = 'Tidak Bersalah';

$txt['moderator'] = 'Penyelia';
$txt['moderators'] = 'Moderator';

$txt['views'] = 'Dilihat';
$txt['new'] = 'Baru';
$txt['no_redir'] = 'Dialihkan daripada %1$s';

$txt['view_all_members'] = 'Lihat semua ahli';
$txt['view'] = 'Lihat';

$txt['viewing_members'] = 'Melihat Ahli %1$s sampai %2$s';
$txt['of_total_members'] = 'dari %1$s jumlah ahli';

$txt['forgot_your_password'] = 'Lupa kata kunci Anda?';

$txt['date'] = 'Tarikh';
// Use numeric entities in the below string.
$txt['from'] = 'Dari';
$txt['to'] = 'Untuk';

$txt['board_topics'] = 'Topik';
$txt['members_title'] = 'Ahli';
$txt['members_list'] = 'Daftar Ahli';
$txt['new_posts'] = 'Pos Baru';
$txt['old_posts'] = 'Tidak ada Pos Baru';
$txt['redirect_board'] = 'Ruangan Peralihan';
$txt['redirect_board_to'] = 'Memindahkan ke %1$s';

$txt['sendtopic_send'] = 'Kirim';
$txt['report_sent'] = 'Laporan anda telah berjaya dikirim.';
$txt['topic_sent'] = 'Emel anda telah berjaya dihantar.';

$txt['time_offset'] = 'Jarak Waktu';
$txt['or'] = 'atau';

$txt['mention'] = 'Makluman';
$txt['notifications'] = 'Makluman';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = 'Maaf %1$s, Anda disekat daripada penggunaan forum ini!';
$txt['your_ban_expires'] = 'Sekatan ini ditetapkan untuk berakhir %1$s.';
$txt['your_ban_expires_never'] = 'Sekatan ini tidak ditetapkan untuk luput.';
$txt['ban_continue_browse'] = 'Anda dapat melanjutkan untuk melihat forum sebagai tetamu.';

$txt['mark_as_read'] = 'Tanda SEMUA mesej sudah dibaca';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'Tandakan mesej INI sudah dibaca';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'Topik Dikunci';
$txt['normal_topic'] = 'Topik Normal';
$txt['participation_caption'] = 'Topik yang Anda pos';

$txt['print'] = 'Cetak';
$txt['topic_summary'] = 'Ringkasan Topik';
$txt['not_applicable'] = 'N/A';
$txt['name_in_use'] = 'Nama ini sudah dipakai oleh ahli lain.';

$txt['total_members'] = 'Jumlah Ahli';
$txt['total_posts'] = 'Total Pos';
$txt['total_topics'] = 'Jumlah Topik';

$txt['mins_logged_in'] = 'Minit untuk tetap masuk';

$txt['preview'] = 'Semak';
$txt['always_logged_in'] = 'Selalu masuk';

$txt['logged'] = 'Tercatat';
// Use numeric entities in the below string.
$txt['ip'] = 'IP';

$txt['www'] = 'WWW';
$txt['link'] = 'Pautan';

$txt['by'] = 'oleh'; //Deprecated

$txt['hours'] = 'jam';
$txt['minutes'] = 'minit';
$txt['seconds'] = 'saat';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'Jam';
$txt['days_word'] = 'hari';

$txt['newest_member'] = ', ahli terbaru kami.'; //Deprecated

$txt['search_for'] = 'Mencari';
$txt['search_match'] = 'Padan';

$txt['maintain_mode_on'] = 'Ingat, forum ini dalam \'Mode Pemeliharaan\'.';

$txt['read'] = 'Baca'; //Deprecated
$txt['times'] = 'kali'; //Deprecated
$txt['read_one_time'] = 'Dibaca 1 kali';
$txt['read_many_times'] = 'Dibaca %1$d kali';

$txt['forum_stats'] = 'Statistik Forum';
$txt['latest_member'] = 'Ahli Terbaru';
$txt['total_cats'] = 'Jumlah Kategori';
$txt['latest_post'] = 'Pos Terbaru';

$txt['here'] = 'di sini';
$txt['you_have_no_msg'] = 'Anda tiada sebarang mesej...';
$txt['you_have_one_msg'] = 'Anda ada 1 mesej... <a href="%1$s">Klik di sini untuk melihatnya</a>';
$txt['you_have_many_msgs'] = 'Anda ada %2$d mesej... <a href="%1$s">Klik di sini untuk melihatnya</a>';

$txt['total_boards'] = 'Jumlah Ruangan';

$txt['print_page'] = 'Cetak Laman';
$txt['print_page_text'] = 'Teks sahaja';
$txt['print_page_images'] = 'Teks dan Imej';

$txt['valid_email'] = 'Ini harus alamat email yang benar.';

$txt['info_center_title'] = '%1$s - Pusat Info';

$txt['send_topic'] = 'Kirim topik ini';
$txt['unwatch'] = 'Tidak Ditonton';
$txt['watch'] = 'Tonton';

$txt['sendtopic_title'] = 'Kirim topik &quot;%1$s&quot; ke teman.';
$txt['sendtopic_sender_name'] = 'Nama Anda';
$txt['sendtopic_sender_email'] = 'Alamat email Anda';
$txt['sendtopic_receiver_name'] = 'Nama penerima';
$txt['sendtopic_receiver_email'] = 'Alamat email penerima';
$txt['sendtopic_comment'] = 'Tambah komen';

$txt['allow_user_email'] = 'Benarkan pengguna mengirim email kepada Anda';

$txt['check_all'] = 'Tanda semua';

// Use numeric entities in the below string.
$txt['database_error'] = 'Kesalahan Database';
$txt['try_again'] = 'Sila cuba lagi.  Jika Anda kembali pada layar kesalahan ini, laporkan ke administrator.';
$txt['file'] = 'Fail';
$txt['line'] = 'Baris';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'ElkArte telah mengesan dan secara automatik cuba membetulkan kesalahan database anda. Jika anda terus menghadapi masalah, atau terus menerima emel ini, sila hubungi hos anda.';
$txt['database_error_versions'] = '<strong>Catatan:</strong> Nampaknya bahwa database Anda <em>mungkin</em> memerlukan peningkatan. Fail forum Anda saat ini adalah versi %1$s, sementara database Anda versi %2$s. Kesalahan di atas mungkin akan hilang jika Anda menjalankan versi upgrade.php terbaru.';
$txt['template_parse_error'] = 'Kesalahan Penguraian Template!';
$txt['template_parse_error_message'] = 'Nampaknya sesuatu telah mengacaukan forum dengan sistem template.  Masalah ini hanya bersifat sementara, sila kembali lagi nanti dan mencuba lagi.  Jika Anda terus melihat mesej ini, sila hubungi administrator.<br /><br />Anda juga boleh mencuba <a href="javascript:location.reload();">menyegarkan laman ini</a>.';
$txt['template_parse_error_details'] = 'Ada masalah memuatkan fail templet atau bahasa <span class="tt"><strong>%1$s</strong></span>. Sila semak syntaks dan cuba lagi - ingat, satu ungkapan (<span class="tt">\'</span>) biasanya perlu dilepaskan dengan sendeng terbalik (<span class="tt">\\</span>). Untuk melihat info kesalahan dengan lebih spesifik daripada PHP, cubalah <a href="%2$s%1$s">mengakses fail secara terus</a>.<br /><br />Anda mungkin perlu <a href="javascript:location.reload();">menyegarkan laman ini</a> atau <a href="%3$s">gunakan tema default</a>.';
$txt['template_parse_undefined'] = 'Kesalahan tiada definasi berlaku semasa mengurai template';

$txt['today'] = '<strong>Hari Ini</strong> jam ';
$txt['yesterday'] = '<strong>Semalam</strong> jam';

// Relative times
$txt['rt_now'] = 'baru';
$txt['rt_minute'] = 'Seminit yang lalu';
$txt['rt_minutes'] = '%s minit yang lalu';
$txt['rt_hour'] = 'Sejam yang lalu';
$txt['rt_hours'] = '%s jam yang lalu';
$txt['rt_day'] = 'Sehari yang lalu';
$txt['rt_days'] = '%s hari yang lalu';
$txt['rt_week'] = ' Seminggu yang lalu';
$txt['rt_weeks'] = '%s minggu yang lalu';
$txt['rt_month'] = 'Sebulan yang lalu';
$txt['rt_months'] = '%s bulan yang lalu';
$txt['rt_year'] = 'Setahun yang lalu';
$txt['rt_years'] = '%s tahun yang lalu';

$txt['new_poll'] = 'Undian Baru';
$txt['poll_question'] = 'Soalan';
$txt['poll_question_options'] = 'Soalan dan Pilihan';
$txt['poll_vote'] = 'Kirim Pilihan';
$txt['poll_total_voters'] = 'Jumlah Pemilih';
$txt['draft_saved_on'] = 'Deraf terakhir disimpan';
$txt['poll_results'] = 'Lihat hasil';
$txt['poll_lock'] = 'Kunci Pilihan';
$txt['poll_unlock'] = 'Buka Pilihan';
$txt['poll_edit'] = 'Edit Undian';
$txt['poll'] = 'Undian';
$txt['one_day'] = '1 Hari';
$txt['one_week'] = '1 Minggu';
$txt['two_weeks'] = '2 Minggu';
$txt['one_month'] = '1 Bulan';
$txt['two_months'] = '2 Bulan';
$txt['forever'] = 'Selamanya';
$txt['quick_login_dec'] = 'Masuk dengan nama pengguna, kata kunci dan lama sesi';
$txt['one_hour'] = '1 Jam';
$txt['moved'] = 'DIPINDAHKAN';
$txt['moved_why'] = 'Sila masukkan deskripsi singkat penyebab<br />mengapa topik ini dipindahkan.';
$txt['board'] = 'Ruangan';
$txt['in'] = 'dalam';
$txt['sticky_topic'] = 'Topik Lekit';
$txt['split'] = 'Pisah Topik';

$txt['delete'] = 'Padam';

$txt['byte'] = 'B';
$txt['kilobyte'] = 'KB';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[Statistik Lengkap]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Kod';
$txt['code_select'] = '[Pilih]';
$txt['quote_from'] = 'Ungkap daripada';
$txt['quote'] = 'Ungkap';
$txt['quote_new'] = 'Topik baru';
$txt['follow_ups'] = 'Susul';
$txt['topic_derived_from'] = 'Topik diambil daripada %1$s';
$txt['edit'] = 'Edit';
$txt['quick_edit'] = 'Edit Pantas';
$txt['post_options'] = 'Lagi...';

$txt['set_sticky'] = 'Jadikan topik lekit';
$txt['set_nonsticky'] = 'Jadikan topik tidak lekit';
$txt['set_lock'] = 'Kunci topik';
$txt['set_unlock'] = 'Buka kunci topik';

$txt['search_advanced'] = 'Carian lengkap';
$txt['search_simple'] = 'Sembunyikan pilihan canggih';

$txt['security_risk'] = 'RISIKO SEKURITI UTAMA:';
$txt['not_removed'] = 'Anda tidak memadamkan ';
$txt['not_removed_extra'] = '%1$s adalah backup dari %2$s yang tidak dibuat oleh ElkArte. Ia boleh diakses secara langsung dan dipakai untuk memperolehi akses tanpa keizinan dalam forum anda. Anda harus memadamkannya seberapa segera.';
$txt['generic_warning'] = 'Amaran';
$txt['agreement_missing'] = 'Anda menetapkan supaya pengguna baru menerima perjanjian pendaftaran, tetapi fail  (agreement.txt)  tidak wujud.';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'Anda berjaya membuat kemaskini!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Klik sini untuk melihat perkara baru dalam versi ElkArte ini!</a>!';

$txt['cache_writable'] = 'Direktori cache tidak boleh dipos - ini akan mempengaruhi pencapaian forum Anda.';

$txt['page_created_full'] = 'Laman dicipta dalam masa %1$.3f saat dengan %2$d queri.';

$txt['report_to_mod_func'] = 'Gunakan fungsi ini untuk memberitahu moderator dan administrator atas mesej yang dipos yang bersifat serangan dan salah.<br /><em>Harap dicatat bahwa alamat email Anda akan dimunculkan ke moderator jika Anda menggunakan ini.</em>';

$txt['online'] = 'Online';
$txt['member_is_online'] = '%1$s hadir';
$txt['offline'] = 'Offline';
$txt['member_is_offline'] = '%1$s tidak hadir';
$txt['pm_online'] = 'Mesej Peribadi (Online)';
$txt['pm_offline'] = 'Mesej Peribadi (Offline)';
$txt['status'] = 'Status';

$txt['skip_nav'] = 'Lompat ke kandungan utama';
$txt['go_up'] = 'Naik';
$txt['go_down'] = 'Turun';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Hari Jadi:';
$txt['events'] = 'Acara:';
$txt['birthdays_upcoming'] = 'Hari Jadi Mendatang:';
$txt['events_upcoming'] = 'Acara Mendatang:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Cuti:';
$txt['calendar_month'] = 'Bulan:';
$txt['calendar_year'] = 'Tahun:';
$txt['calendar_day'] = 'Tarikh:';
$txt['calendar_event_title'] = 'Judul Acara';
$txt['calendar_event_options'] = 'Pilihan Acara';
$txt['calendar_post_in'] = 'Pos Dalam:';
$txt['calendar_edit'] = 'Edit Acara';
$txt['event_delete_confirm'] = 'Padam acara ini?';
$txt['event_delete'] = 'Padam Acara';
$txt['calendar_post_event'] = 'Pos Acara';
$txt['calendar'] = 'Kalendar';
$txt['calendar_link'] = 'Link ke Kalendar';
$txt['calendar_upcoming'] = 'Kalendar Mendatang';
$txt['calendar_today'] = 'Kalendar Hari ini';
$txt['calendar_week'] = 'Minggu';
$txt['calendar_week_title'] = 'Minggu ke  %1$d dari %2$d ';
$txt['calendar_numb_days'] = 'Jumlah Hari:';
$txt['calendar_how_edit'] = 'bagaimana Anda mengedit acara ini?';
$txt['calendar_link_event'] = 'Link Acara';
$txt['calendar_confirm_delete'] = 'Anda yakin ingin memadamkan acara ini?';
$txt['calendar_linked_events'] = 'Acara Dikaitkan';
$txt['calendar_click_all'] = 'klik untuk melihat semua %1$s';

$txt['moveTopic1'] = 'Pos topik peralihan';
$txt['moveTopic2'] = 'Ubah subjek topik';
$txt['moveTopic3'] = 'Subjek baru';
$txt['moveTopic4'] = 'Ubah setiap subjek pesasn';
$txt['move_topic_unapproved_js'] = 'Peringatan! Topik ini belum diluluskan.\\n\\nAnda tidak disarankan membuat topik peralihan kecuali anda mahu meluluskan pos ini dengan segera selepas itu.';
$txt['movetopic_auto_board'] = '[RUANGAN]';
$txt['movetopic_auto_topic'] = '[LINK TOPIK]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Alihkan ke topik yang dipindahkan';
$txt['movetopic_expires'] = 'Buang topik peralihan secara automatik';

$txt['merge_to_topic_id'] = 'ID topik tujuan';
$txt['split_topic'] = 'Pisahkan';
$txt['merge'] = 'Gabung Topik';
$txt['subject_new_topic'] = 'Subjek untuk Topik Baru';
$txt['split_this_post'] = 'Hanya memisahkan pos ini.';
$txt['split_after_and_this_post'] = 'Pisah topik setelah dan termasuk pos ini.';
$txt['select_split_posts'] = 'Pilih pos untuk dipisahkan.';

$txt['splittopic_notification'] = 'Pos satu mesej apabila topik dipisahkan';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Pindahkan topik baru ke ruangan lain';

$txt['new_topic'] = 'Topik Baru';
$txt['split_successful'] = 'Berjaya memisahkan topik menjadi dua topik.';
$txt['origin_topic'] = 'Asal Topik';
$txt['please_select_split'] = 'Sila pilih pos mana yang ingin dipisahkan.';
$txt['merge_successful'] = 'Topik digabung dengan jaya.';
$txt['new_merged_topic'] = 'Topik yang Baru Saja Digabung';
$txt['topic_to_merge'] = 'Topik yang akan digabung';
$txt['target_board'] = 'Ruangan sasaran';
$txt['target_topic'] = 'Target topik';
$txt['merge_confirm'] = 'Anda yakin ingin menggabung';
$txt['with'] = 'dengan';
$txt['merge_desc'] = 'Fungsi ini akan menggabung mesej dari dua topik ke dalam satu topik. Mesej akan diurut berdasarkan waktu penulisan. Oleh karenanya mesej yang dipos lebih dulu akan menjadi mesej pertama dari topik yang digabung.';

$txt['theme_template_error'] = 'Tidak boleh mengambil template \'%1$s\'.';
$txt['theme_language_error'] = 'Tidak boleh mengambil fail bahasa \'%1$s\'.';

$txt['parent_boards'] = 'Ruangan anak';

$txt['smtp_no_connect'] = 'Tidak boleh menghubungi host SMTP';
$txt['smtp_port_ssl'] = 'Tetapan port SMTP tidak benar; biasanya 465 untuk server SSL.';
$txt['smtp_bad_response'] = 'Tidak boleh mendapatkan kod respon server mail';
$txt['smtp_error'] = 'Ada masalah dengan pengiriman Surat. Kesalahan: ';
$txt['mail_send_unable'] = 'Tidak boleh mengirimkan surat ke alamat email \'%1$s\'';

$txt['mlist_search'] = 'Mencari ahli';
$txt['mlist_search_again'] = 'Cari lagi'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Cari alamat email';
$txt['mlist_search_group'] = 'Cari grup';
$txt['mlist_search_name'] = 'Cari nama';
$txt['mlist_search_website'] = 'Cari laman';
$txt['mlist_search_results'] = 'Hasil pencarian untuk';
$txt['mlist_search_by'] = 'Cari dengan %1$s';

$txt['attach_downloaded'] = 'dimuatturun';
$txt['attach_viewed'] = 'dilihat';

$txt['settings'] = 'Tetapan';
$txt['never'] = 'Tidak pernah';
$txt['more'] = 'selengkapnya';

$txt['hostname'] = 'Nama host';
$txt['you_are_post_banned'] = 'Maaf %1$s, anda disekat dari mengepos dan mengirim mesej peribadi dalam forum ini.';
$txt['ban_reason'] = 'Alasan';

$txt['add_poll'] = 'Tambah undian';
$txt['poll_options6'] = 'Anda hanya boleh memilih sampai %1$s pilihan.';
$txt['poll_remove'] = 'Padam Undian';
$txt['poll_remove_warn'] = 'Anda yakin ingin memadamkan undian ini dari topik?';
$txt['poll_results_expire'] = 'Hasil akan dipaparkan saat pilihan sudah ditutup';
$txt['poll_expires_on'] = 'Penutupan pemilihan';
$txt['poll_expired_on'] = 'Pemilihan ditutup';
$txt['poll_change_vote'] = 'Padam pemilihan';
$txt['poll_return_vote'] = 'Pilihan pemilihan';
$txt['poll_cannot_see'] = 'Anda tidak boleh melihat hasil undian untuk saat ini.';

$txt['quick_mod_approve'] = 'Luluskan yang dipilih';
$txt['quick_mod_remove'] = 'Padam pilihan';
$txt['quick_mod_lock'] = 'Kunci/Buka pilihan';
$txt['quick_mod_sticky'] = 'Lekit/Nyah Lekit pilihan';
$txt['quick_mod_move'] = 'Pindahkan yang dipilih ke';
$txt['quick_mod_merge'] = 'Gabung yang dipilih';
$txt['quick_mod_markread'] = 'Tanda yang dipilih sebagai dibaca';
$txt['quick_mod_go'] = 'Pergi';
$txt['quickmod_confirm'] = 'Anda yakin ingin melakukan ini?';

$txt['spell_check'] = 'Pemeriksaan Ejaan';

$txt['quick_reply'] = 'Jawab Segera';
$txt['quick_reply_warning'] = 'Peringatan: topik saat ini dikunci! Hanya admin dan moderator yang boleh menjawab.';
$txt['quick_reply_verification'] = 'Setelah mengirimkan pos, Anda akan dialihkan ke laman pos biasa untuk mempengesahan pos Anda %1$s.';
$txt['quick_reply_verification_guests'] = '(diperlukan untuk semua tetamu)';
$txt['quick_reply_verification_posts'] = '(diperlukan untuk semua pengguna dengan kurang dari %1$d pos)';
$txt['wait_for_approval'] = 'Catatan: pos ini tidak akan dipaparkan sampai ia diluluskan oleh moderator.';

$txt['notification_enable_board'] = 'Apakah anda yakin mahu menghidupkan makluman atas topik baru bagi ruangan ini?';
$txt['notification_disable_board'] = 'Apakah anda yakin mahu mematikan makluman atas topik baru bagi ruangan ini?';
$txt['notification_enable_topic'] = 'Anda yakin ingin menghidupkan makluman atas jawapan pada topik ini?';
$txt['notification_disable_topic'] = 'Anda yakin ingin mematikan makluman atas jawapan pada topik ini?';

$txt['report_to_mod'] = 'Laporkan ke moderator';
$txt['issue_warning_post'] = 'Terbitkan peringatan atas mesej ini';

$txt['like_post'] = 'Suka';
$txt['unlike_post'] = 'Tak Suka';
$txt['likes'] = 'Suka';
$txt['liked_by'] = 'Disukai oleh:';
$txt['liked_you'] = 'Anda';
$txt['liked_more'] = 'selengkapnya';
$txt['likemsg_are_you_sure'] = 'Anda sudah menyukai mesej ini, adakah anda pasti mahu memadamkannya?';

$txt['unread_topics_visit'] = 'Topik Terbaru Belum Dibaca';
$txt['unread_topics_visit_none'] = 'Tiada topik yang belum dibaca setakat lawatan terakhir anda. <a href="{unread_all_url}" class="linkbutton">Klik di sini untuk menyemak topik yang belum dibaca keseluruhannya.</a>';
$txt['unread_topics_all'] = 'Semua Topik Belum Dibaca';
$txt['unread_replies'] = 'Semua Jawapan Belum Dibaca';

$txt['who_title'] = 'Siapa yang Online';
$txt['who_and'] = ' dan ';
$txt['who_viewing_topic'] = ' sedang melihat topik ini.';
$txt['who_viewing_board'] = ' sedang melihat ruangan ini.';
$txt['who_member'] = 'Ahli';

// Current footer strings
$txt['valid_html'] = 'Valid HTML 4.01!';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'Tetamu';
$txt['guests'] = 'Tetamu';
$txt['user'] = 'Pengguna';
$txt['users'] = 'Pengguna';
$txt['hidden'] = 'Sembunyi';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'Sembunyi';
$txt['buddy'] = 'Teman';
$txt['buddies'] = 'Teman';
$txt['most_online_ever'] = 'Terbanyak Pernah Online';
$txt['most_online_today'] = 'Terbanyak Online Hari Ini';

$txt['merge_select_target_board'] = 'Pilih ruangan sasaran untuk topik yang digabungkan';
$txt['merge_select_poll'] = 'Pilih topik mana dari gabungan topik yang harus memiliki undian';
$txt['merge_topic_list'] = 'Pilih topik untuk digabung';
$txt['merge_select_subject'] = 'Pilih subjek dari topik yang digabung';
$txt['merge_custom_subject'] = 'Subjek Pilihan';
$txt['merge_enforce_subject'] = 'Ubah subjek dari semua mesej';
$txt['merge_include_notifications'] = 'Sertakan makluman?';
$txt['merge_check'] = 'Gabung?';
$txt['merge_no_poll'] = 'Tidak ada undian';

$txt['response_prefix'] = 'Per:';
$txt['current_icon'] = 'Ikon Sekarang';
$txt['message_icon'] = 'Ikon Mesej';

$txt['smileys_current'] = 'Set Mimik Semasa';
$txt['smileys_none'] = 'Tiada Mimik';
$txt['smileys_forum_board_default'] = 'Default Forum/Ruangan';

$txt['search_results'] = 'Hasil Carian';
$txt['search_no_results'] = 'Maaf, tiada padanan ditemukan';

$txt['totalTimeLogged2'] = ' hari, ';
$txt['totalTimeLogged3'] = ' jam dan ';
$txt['totalTimeLogged4'] = ' minit.';
$txt['totalTimeLogged5'] = 'd';
$txt['totalTimeLogged6'] = 'h';
$txt['totalTimeLogged7'] = 'm';

$txt['approve_thereis'] = 'Ada'; //Deprecated
$txt['approve_thereare'] = 'Ada'; //Deprecated
$txt['approve_member'] = 'satu ahli'; //Deprecated
$txt['approve_members'] = 'ahli'; //Deprecated
$txt['approve_members_waiting'] = 'menunggu kelulusan.'; //Deprecated
$txt['approve_one_member_waiting'] = 'Ada <a href="%1$s">seorang ahli</a> menunggu kelulusan.';
$txt['approve_many_members_waiting'] = 'Ada <a href="%1$s">%2$d ahli</a> menunggu kelulusan.';

$txt['notifyboard_turnon'] = 'Apakah anda mahu email makluman apabila seseorang menulis topik baru dalam ruangan ini?';
$txt['notifyboard_turnoff'] = 'Apakah anda yakin mahu menerima makluman topik baru untuk ruangan ini?';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Cari Ahli';
$txt['find_username'] = 'Nama, nama pengguna, atau alamat email';
$txt['find_buddies'] = 'Hanya Memaparkan Teman?';
$txt['find_wildcards'] = 'Wildcard Dibenarkan: *, ?';
$txt['find_no_results'] = 'Tidak ada yang ditemukan';
$txt['find_results'] = 'Hasil';
$txt['find_close'] = 'Tutup';

$txt['quickmod_delete_selected'] = 'Padam Pilihan';
$txt['quickmod_split_selected'] = 'Pemisahan Dipilih';

$txt['show_personal_messages_heading'] = 'Mesej baru';
$txt['show_personal_messages'] = 'Anda menerima satu atau lebih mesej peribadi baru.\\nAnda ingin melihatnya sekarang?';

$txt['help_popup'] = 'Sedikit keliru? Biar saya jelaskan:';

$txt['previous_next_back'] = '&laquo; sebelumnya';
$txt['previous_next_forward'] = 'selanjutnya &raquo;';

$txt['upshrink_description'] = 'Sampaikan atau lebarkan header.';

$txt['mark_unread'] = 'Tanda belum dibaca';

$txt['ssi_not_direct'] = 'Tolong jangan akses SSI.php dengan URL secara langsung; anda boleh gunakan laluan (%1$s) atau menambahkan ?ssi_function=sesuatu.';
$txt['ssi_session_broken'] = 'SSI.php tidak dapat membuka sesi!  Ini akan menyebabkan masalah keluar dan fungsi lain - tolong pastikan SSI.php dimasukkan sebelum *semua* yang lain dalam setiap skrip anda!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Semak pos';
$txt['preview_fetch'] = 'Mendapatkan semakan...';
$txt['pm_error_while_submitting'] = 'Kesalahan berikut telah berlaku semasa menghantar mesej peribadi ini:';
$txt['warning_while_submitting'] = 'Sesuatu telah berlaku, semak di sini:';
$txt['error_while_submitting'] = 'Kesalahan berikut atau kesalahan terjadi saat menuliskan mesej ini:';
$txt['error_old_topic'] = 'Peringatan: topik ini belum diposkan setidaknya %1$d hari.<br />Kecuali Anda yakin ingin menjawabnya, harap pertimbangkan untuk memulai sebuah topik baru.';

$txt['split_selected_posts'] = 'Pos terpilih';
$txt['split_selected_posts_desc'] = 'Pos di bawah ini akan membentuk topik baru setelah pemisahan.';
$txt['split_reset_selection'] = 'reset pilihan';

$txt['modify_cancel'] = 'Batalkan';
$txt['mark_read_short'] = 'Tanda Dibaca';

$txt['hello_member_ndt'] = 'Salam';

$txt['unapproved_posts'] = 'Pos Tidak Diluluskan (Topik: %1$d, Pos: %2$d)';

$txt['ajax_in_progress'] = 'Mengambil...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = 'Saat ini ada %1$d laporan moderator terbuka.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'Klik untuk melihat pos baru dalam %1$s';
$txt['verification'] = 'Pengesahan';
$txt['visual_verification_hidden'] = 'Biarkan petak ini kosong';
$txt['visual_verification_description'] = 'Masukkan huruf yang dipaparkan pada gambar';
$txt['visual_verification_sound'] = 'Dengarkan huruf';
$txt['visual_verification_request_new'] = 'Minta gambar lain';

// @todo Send email strings - should move?
$txt['send_email'] = 'Kirim Email';
$txt['send_email_disclosed'] = 'Catatan ini akan terlihat bagi penerima.';
$txt['send_email_subject'] = 'Subjek Email';

$txt['ignoring_user'] = 'Anda mengabaikan pengguna ini.';
$txt['show_ignore_user_post'] = '<em>[Tunjukkan saya pos tersebut.]</em>';

$txt['spider'] = 'Spider';
$txt['spiders'] = 'Spider';
$txt['openid'] = 'OpenID';

$txt['downloads'] = 'Muatturun';
$txt['filesize'] = 'Besar fail';
$txt['subscribe_webslice'] = 'Berlangganan ke Webslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Kembalikan Topik';
$txt['restore_message'] = 'Kembalikan';
$txt['quick_mod_restore'] = 'Pulihkan yang Dipilih';

// Editor prompt.
$txt['prompt_text_email'] = 'Sila masukkan alamat email.';
$txt['prompt_text_ftp'] = 'Sila masukkan alamat ftp.';
$txt['prompt_text_url'] = 'Sila masukkan URL yang ingin Anda link.';
$txt['prompt_text_img'] = 'Masukkan lokasi gambar';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Padam Item';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> telah menyekat %1$s cubaan akses dalam masa 7 hari.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Template:';
$txt['debug_subtemplates'] = 'Sub template:'; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Sub template:';
$txt['debug_language_files'] = 'Fail bahasa:';
$txt['debug_sheets'] = 'Style sheets:';
$txt['debug_javascript'] = 'Skrip:';
$txt['debug_files_included'] = 'Fail disertakan:';
$txt['debug_kb'] = 'KB.';
$txt['debug_show'] = 'paparkan';
$txt['debug_cache_hits'] = 'Cache hits:';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s byte';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss untuk %2$s byte';
$txt['debug_queries_used'] = 'Queri dipakai: %1$d.';
$txt['debug_queries_used_and_warnings'] = 'Queri dipakai: %1$d, %2$d peringatan.';
$txt['debug_query_in_line'] = 'dalam <em>%1$s</em> baris <em>%2$s</em>, ';
$txt['debug_query_which_took'] = 'yang memerlukan %1$s saat. ';
$txt['debug_query_which_took_at'] = 'yang memerlukan %1$s saat untuk %2$s ke dalam permintaan.';
$txt['debug_show_queries'] = '[Paparkan Queri]';
$txt['debug_hide_queries'] = '[Sembunyikan Queri]';
$txt['debug_tokens'] = 'Token:';
$txt['debug_browser'] = 'ID Browser';
$txt['debug_hooks'] = 'Hook dipanggil:';
$txt['debug_system_type'] = 'Sistem:';
$txt['debug_server_load'] = 'Bebanan Server:';
$txt['debug_script_mem_load'] = 'Skrip Penggunaan Memori:';
$txt['debug_script_cpu_load'] = 'Skrip Masa CPU (pengguna/sistem):';

// Video embedding
$txt['preview_image'] = 'Imej Preview Video';
$txt['ctp_video'] = 'Klik untuk mainkann video, klik dua kali untuk memuatkan video';
$txt['hide_video'] = 'Papar/Sembunyi video';
$txt['youtube'] = 'Video YouTube:';
$txt['vimeo'] = 'Video Vimeo:';
$txt['dailymotion'] = 'Video Dailymotion:';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (klik untuk papar/sembunyi)';

$txt['ok_uppercase'] = 'OK';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Amaran';

$txt['via'] = 'melalui';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
