<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Perjanjian Pendaftaran';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'Saya menerima isi perjanjian.';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Saya menerima isi perjanjian dan sekurang2nya saya berusia %1$d tahun.';
$txt['agreement_agree_coppa_below'] = 'Saya menerima isi perjanjian dan saya lebih berusia muda daripada %1$d tahun.';
$txt['agree_coppa_above'] = 'Saya sekurang2nya berusia %1$d tahun.';
$txt['agree_coppa_below'] = 'Saya berusia lebih muda daripada %1$d tahun.';

// Registration form.
$txt['registration_form'] = 'Borang Pendaftaran';
$txt['error_too_quickly'] = 'Anda menjalani proses pendaftaran terlalu cepat daripada biasa. Bersabar, tunggu sebentar dan cuba sekali lagi.';
$txt['error_token_verification'] = 'Token verifikasi gagal. Sila cuba lagi.';
$txt['need_username'] = 'Anda mesti mengisi nama pengguna.';
$txt['no_password'] = 'Anda tidak memasukkan kata kunci anda.';
$txt['improper_password'] = 'Kata laluan yang diberikan terlalu panjang.';
$txt['incorrect_password'] = 'Kata kunci tidak benar';
$txt['openid_not_found'] = 'Pengesah OpenID yang diberikan tidak ditemui.';
$txt['maintain_mode'] = 'Cara Pemeliharaan';
$txt['registration_successful'] = 'Pendaftaran Berjaya';
$txt['valid_email_needed'] = 'Sila masukkan alamat email yang sah, %1$s.';
$txt['required_info'] = 'Maklumat yang Diperlukan';
$txt['additional_information'] = 'Maklumat Tambahan';
$txt['warning'] = 'Peringatan!';
$txt['only_members_can_access'] = 'Hanya ahli mendaftar dibolehkan untuk mengakses seksi ini.';
$txt['login_below'] = 'Sila masuk atau';
$txt['login_below_or_register'] = 'Sila login masuk atau <a href="%1$s">daftar sebuah akaun</a> dengan %2$s';
$txt['checkbox_agreement'] = 'Saya terima perjanjian pendaftaran tersebut';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Sekuriti kata kunci saat ini sudah dikemaskinikan.  Sila masukkan kata kunci sekali lagi.';

$txt['ban_register_prohibited'] = 'Maaf, anda tidak dibenarkan untuk mendaftar pada forum ini.';
$txt['under_age_registration_prohibited'] = 'Maaf, pengguna di bawah usia %1$d tidak dibolehkan untuk mendaftar pada forum ini.';

$txt['activate_account'] = 'Pengaktifan Akaun';
$txt['activate_success'] = 'Akaun anda sudah diaktifkan dengan jaya. Sekarang anda boleh meneruskan untuk masuk.';
$txt['activate_not_completed1'] = 'Alamat email anda perlu divalidasi sebelum anda boleh masuk.';
$txt['activate_not_completed2'] = 'Perlu email pengaktifan lain?';
$txt['activate_after_registration'] = 'Terima kasih atas pendaftarannya. Anda akan segera menerima sebuah email dengan sebuah link untuk mengaktifkan akaun anda.  Jika anda tidak menerima email setelah beberapa waktu, periksa folder spam anda.';
$txt['invalid_userid'] = 'Pengguna tidak ada';
$txt['invalid_activation_code'] = 'Kod pengaktifan tidak benar';
$txt['invalid_activation_username'] = 'Nama pengguna atau email';
$txt['invalid_activation_new'] = 'Jika anda mendaftar dengan alamat email yang salah, masukkan yang baru dan kata kunci anda di sini.';
$txt['invalid_activation_new_email'] = 'Alamat email baru';
$txt['invalid_activation_password'] = 'Kata kunci lama';
$txt['invalid_activation_resend'] = 'Kirim semula kod pengaktifan';
$txt['invalid_activation_known'] = 'Jika anda sudah mengetahui kod pengaktifan anda, sila masukkan di sini.';
$txt['invalid_activation_retry'] = 'Kod pengaktifan';
$txt['invalid_activation_submit'] = 'Aktifkan';

$txt['coppa_no_concent'] = 'Pengurus belum menerima kebenaran ibubapa/penjaga untuk akaun anda.';
$txt['coppa_need_more_details'] = 'Perlu lebih butiran?';

$txt['awaiting_delete_account'] = 'Akaun anda sudah ditanda untuk penghapusan!<br />Jika anda ingin mengembalikan akaun anda, sila tanda kotak &quot;Pengaktifan semula akaun saya&quot;, dan masuk lagi.';
$txt['undelete_account'] = 'Pengaktifan semula akaun saya';

$txt['in_maintain_mode'] = 'Ruangan ini dalam Mod Senggaraan.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Sila baca dan terima perjanjian sebelum mendaftar.';
$txt['register_passwords_differ_js'] = 'Dua kata kunci yang anda masukkan tidak padan!';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Terima kasih atas pendaftarannya. Pengurus mesti meluluskan pendaftaran anda sebelum anda mula menggunakan akaun, anda akan segera menerima email mengenai keputusan Pengurus.';

$txt['admin_settings_desc'] = 'Di sini anda dapat mengubah berbagai tetapan berkaitan dengan pendaftaran ahli baru.';

$txt['setting_enableOpenID'] = 'Benarkan pengguna mendaftar dengan OpenID';

$txt['setting_registration_method'] = 'Cara pendaftaran yang dilakukan bagi ahli baru';
$txt['setting_registration_disabled'] = 'Pendaftaran Dimatikan';
$txt['setting_registration_standard'] = 'Pendaftaran Langsung';
$txt['setting_registration_activate'] = 'Pengaktifan Email';
$txt['setting_registration_approval'] = 'Kelulusan Pengurus';
$txt['setting_notify_new_registration'] = 'Beritahu Pengurus saat ahli baru bergabung';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Kirim email sambutan bagi ahli baru';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Usia terendah untuk memlakukan pembatasan pendaftaran';
$txt['setting_coppaAge_desc'] = '(Set 0 untuk mematikan)';
$txt['setting_coppaType'] = 'Tindakan yang diambil ketika pengguna di bawah usia minima mendaftar';
$txt['setting_coppaType_reject'] = 'Tolak pendaftarannya';
$txt['setting_coppaType_approval'] = 'Perlukan kebenaran ibubapa/penjaga';
$txt['setting_coppaPost'] = 'Alamat pos ke mana borang ini mesti dikirimkan';
$txt['setting_coppaPost_desc'] = 'Hanya diterapkan jika pembatasan usia dilakukan';
$txt['setting_coppaFax'] = 'Nombor faksimili ke mana borang kebenaran di-faks';
$txt['setting_coppaPhone'] = 'Nombor kontak ibubapa dengan permintaan pembatasan usia';

$txt['admin_register'] = 'Pendaftaran ahli baru';
$txt['admin_register_desc'] = 'Dari sini anda dapat melihat pendaftaran ahli baru ke dalam forum, dan jika diperlukan, email mereka sebagai butirannya.';
$txt['admin_register_username'] = 'Nama Pengguna Baru';
$txt['admin_register_email'] = 'Alamat Emel';
$txt['admin_register_password'] = 'Kata Kunci';
$txt['admin_register_username_desc'] = 'Nama pengguna untuk ahli baru';
$txt['admin_register_email_desc'] = 'Alamat email ahli';
$txt['admin_register_password_desc'] = 'Kata kunci untuk ahli baru';
$txt['admin_register_email_detail'] = 'Email kata kunci baru ke pengguna';
$txt['admin_register_email_detail_desc'] = 'Alamat email diperlukan meskipun tidak ditanda';
$txt['admin_register_email_activate'] = 'Pengguna mesti mengaktifkan akaun';
$txt['admin_register_group'] = 'Grup Ahli Utama';
$txt['admin_register_group_desc'] = 'Grup ahli utama di mana ahli baru akan dimasukkan';
$txt['admin_register_group_none'] = '(tiada grup ahli utama)';
$txt['admin_register_done'] = 'Ahli %1$s sudah mendaftar dengan jaya!';

$txt['coppa_title'] = 'Forum Usia Terbatas';
$txt['coppa_after_registration'] = 'Terima kasih kerana mendaftar dengan {forum_name_html_safe}.<br /><br />Oleh kerana anda berusia di bawah {MINIMUM_AGE}, menurut undang2 kami memerlukan kebenaran ibubapa atau penjaga sebelum anda boleh menggunakan akaun anda. Untuk mengaturkan aktivasi akaun, sila cetak borang di bawah:';
$txt['coppa_form_link_popup'] = 'Ambil Borang Dalam Jendela Baru';
$txt['coppa_form_link_download'] = 'Download Borang sebagai Fail Teks';
$txt['coppa_send_to_one_option'] = 'Kemudian atur untuk ibubapa/penjaga anda agar mengirimkan borang lengkap dengan:';
$txt['coppa_send_to_two_options'] = 'Kemudian atur untuk ibubapa/penjaga anda agar mengirimkan borang lengkap dengan:';
$txt['coppa_send_by_post'] = 'Kirimkan, ke alamat berikut:';
$txt['coppa_send_by_fax'] = 'Fax, ke nombor berikut:';
$txt['coppa_send_by_phone'] = 'Alternatifnya, atur agar mereka menelefon Pengurus di {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Borang kebenaran bagi pendaftaran di {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Alamat';
$txt['coppa_form_date'] = 'Tarikh';
$txt['coppa_form_body'] = 'Saya {PARENT_NAME},<br /><br />memberikan kebenaran untuk {CHILD_NAME} (nama anak) untuk menjadi ahli berdaftar sepenuhnya dalam forum: {forum_name_html_safe}, dengan nama pengguna: {USER_NAME}.<br /><br />Saya faham bahawa beberapa maklumat peribadi yang dimasukkan oleh {USER_NAME} mungkin akan dipaparkan kepada pengguna forum yang.<br /><br />Ditandatangani oleh:<br />{PARENT_NAME} (Ibubapa/Penjaga).';

$txt['visual_verification_sound_again'] = 'Mainkan lagi';
$txt['visual_verification_sound_close'] = 'Tutup jendela';
$txt['visual_verification_sound_direct'] = 'Kesulitan mendengarkannya?  Cuba link terus.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Nama pengguna tersedia';
$txt['registration_username_unavailable'] = 'Nama pengguna tidak tersedia';
$txt['registration_username_check'] = 'Periksa apakah nama pengguna tersedia';
$txt['registration_password_short'] = 'Kata kunci terlalu pendek';
$txt['registration_password_reserved'] = 'Kata kunci berisi nama pengguna/email anda';
$txt['registration_password_numbercase'] = 'Kata kunci mesti berisi huruf besar dan kecil, juga nombor';
$txt['registration_password_no_match'] = 'Kata kunci tidak sama';
$txt['registration_password_valid'] = 'Kata kunci tidak sah';

$txt['registration_errors_occurred'] = 'Kesalahan berikut telah dikesan dalam pendaftaran anda. Sila betulkan dan teruskan:';

$txt['authenticate_label'] = 'Cara Pengesahan';
$txt['authenticate_password'] = 'Kata Kunci';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'URL Pengesahan OpenID';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'Hubungi pengurusan';
$txt['contact_your_message'] = 'Mesej anda';
$txt['errors_contact_form'] = 'Kesalahan berikut berlaku semasa memproses permohonan kontek anda';
$txt['contact_subject'] = 'Seorang tetamu mengirim mesej kepada anda';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
