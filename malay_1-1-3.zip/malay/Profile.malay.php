<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Anda tidak dibenarkan untuk mengubah profil orang ini.';
$txt['website_title'] = 'Tajuk laman web';
$txt['website_url'] = 'URL laman web';
$txt['signature'] = 'Tandatangan';
$txt['profile_posts'] = 'Pos';

$txt['profile_info'] = 'Butiran Lanjut';
$txt['profile_contact'] = 'Maklumat Perhubungan';
$txt['profile_moderation'] = 'Maklumat Moderasi';
$txt['profile_more'] = 'Tandatangan';
$txt['profile_attachments'] = 'Lampiran Terbaru';
$txt['profile_attachments_no'] = 'Tiada lampiran daripada ahli ini';
$txt['profile_recent_posts'] = 'Pos Terbaru';
$txt['profile_posts_no'] = 'Tiada pos daripada ahli ini';
$txt['profile_topics'] = 'Topik Terbaru';
$txt['profile_topics_no'] = 'Tiada topik daripada ahli ini';
$txt['profile_buddies_no'] = 'Anda tidak menetapkan rakan';
$txt['profile_user_info'] = 'Info Pengguna';
$txt['profile_contact_no'] = 'Tiada maklumat perhubungan untuk ahli ini';
$txt['profile_signature_no'] = 'Tiada tandatangan untuk ahli ini';
$txt['profile_additonal_no'] = 'Tiada maklumat tambahan untuk ahli ini';
$txt['profile_user_summary'] = 'Profil';
$txt['profile_action'] = 'Sekarang';
$txt['profile_recent_activity'] = 'Aktiviti Terkini';
$txt['profile_activity'] = 'Aktiviti';
$txt['profile_loadavg'] = 'Sila cuba sekali lagi. Maklumat ini tersedia sekarang kerana bebanan tinggi pada laman.';

$txt['change_profile'] = 'Ubah profil';
$txt['preview_signature'] = 'Preview tandatangan';
$txt['current_signature'] = 'Tandatangan sekarang';
$txt['signature_preview'] = 'Preview tandatangan';
$txt['personal_picture'] = 'Gambar Peribadi';
$txt['no_avatar'] = 'Tiada avatar';
$txt['choose_avatar_gallery'] = 'Pilih avatar dari galeri';
$txt['preferred_language'] = 'Bahasa Dikehendaki';
$txt['age'] = 'Umur';
$txt['no_pic'] = '(tanpa gambar)';
$txt['avatar_by_url'] = 'Tetapkan avatar anda sendiri dengna URL. (misal: <em>http://sezs123.com/mypic.gif</em>)';
$txt['my_own_pic'] = 'Tetapkan avatar dengan URL';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'Format di sini akan dipakai untuk memaparkan tarikh lewat forum ini.';
$txt['time_format'] = 'Format Jam';
$txt['display_name_desc'] = 'Ini nama paparan yang akan dilihat orang.';
$txt['personal_time_offset'] = 'Bilangan jam +/- untuk menyamakan waktu paparan dengan waktu tempatan anda.';
$txt['dob'] = 'Tarikh lahir';
$txt['dob_month'] = 'Bulan (MM)';
$txt['dob_day'] = 'Tarikh (DD)';
$txt['dob_year'] = 'Tahun (YYYY)';
$txt['password_strength'] = 'Untuk sekuriti terbaik, anda mesti mengunakan lapan atau lebih karakter dengan gabungan huruf, angka, dan simbol.';
$txt['include_website_url'] = 'Ini mesti disertakan jika anda menetapkan URL di bawah ini.';
$txt['complete_url'] = 'Ini mesti URL lengkap.';
$txt['sig_info'] = 'Tandatangan dipaparkan di bawah setiap pos atau mesej peribadi. Kod BBC dan mimik boleh digunakan dalam tandatangan anda.';
$txt['max_sig_characters'] = 'Maks karakter: %1$d; karakter tersisa:';
$txt['send_member_pm'] = 'Kirim mesej peribadi ke ahli ini';
$txt['hidden'] = 'disembunyikan';
$txt['current_time'] = 'Waktu forum semasa';

$txt['language'] = 'Bahasa';
$txt['avatar_too_big'] = 'Gambar avatar terlalu besar, sila ukur semula dan cuba lagi (maks';
$txt['invalid_registration'] = 'Nilai Tarikh Mendaftar Tidak Sah, contoh yang sah:';
$txt['current_password'] = 'Kata Kunci Semasa';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Atas sebab-sebab sekuriti, kata kunci anda sekarang diperlukan guna membuat perubahan ke akaun anda.';

$txt['timeoffset_autodetect'] = '(sedia mengesan)';

$txt['secret_question'] = 'Soalan Rahsia';
$txt['secret_desc'] = 'Untuk membantu mendapatkan kata kunci anda, masukkan soalan di sini dengan jawapan yang <strong>hanya</strong> anda tahu.';
$txt['secret_desc2'] = 'Awas memilih, anda tidak menginginkan orang lain meneka jawapan anda!';
$txt['secret_answer'] = 'Jawapan';
$txt['incorrect_answer'] = 'Maaf, tapi anda tidak menetapkan gabungan Soalan dan Jawapan Rahsia yang sah dalam profil anda.  Sila klik pada butang kembali, dan gunakan cara default mendapatkan kata kunci anda.';
$txt['enter_new_password'] = 'Sila jawab soalan anda, dan kata kunci anda yang ingin anda pakai.  Kata kunci anda akan diubah jika anda menjawab soalan dengan betul.';
$txt['secret_why_blank'] = 'mengapa ini kosong?';

$txt['authentication_reminder'] = 'Pengingat Pengesahan';
$txt['password_reminder_desc'] = 'Jika anda lupa butiran masuk anda, jangan bimbang, ia masih boleh diperolehi. Untuk memulakan proses ini sila masukkan nama pengguna atau email di bawah.';
$txt['authentication_options'] = 'Sila pilih salah satu dari dua pilihan di bawah';
$txt['authentication_openid_email'] = 'Email saya pengingat identiti OpenID saya';
$txt['authentication_openid_secret'] = 'Jawab &quot;soalan rahsia&quot; saya untuk memaparkan identiti OpenID saya';
$txt['authentication_password_email'] = 'Email saya kata kunci baru';
$txt['authentication_password_secret'] = 'Biarkan saya menetapkan kata kunci baru dengan menjawab &quot;soalan rahsia&quot; saya';
$txt['openid_secret_reminder'] = 'Sila masukkan jawapan anda ke soalan di bawah. Jika anda menjawab dengan betul, identiti OpenID anda akan dipaparkan.';
$txt['reminder_openid_is'] = 'Identiti OpenID yang dikaitkan dengan akaun anda adalah:<br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /><br />Sila berikannya perhatian untuk rujukan di kemudian hari.';
$txt['reminder_continue'] = 'Teruskan';

$txt['accept_agreement_title'] = 'Accept agreement';
$txt['agreement_accepted_title'] = 'Teruskan';

$txt['current_theme'] = 'Tema Semasa';
$txt['change'] = '(ubah)';
$txt['theme_forum_default'] = 'Default Forum atau Ruangan';
$txt['theme_forum_default_desc'] = 'Ini adalah tema default yang bererti tema anda akan berubah bersamaan dengan tetapan pengurus dan ruangan yang sedang anda lihat.';

$txt['profileConfirm'] = 'Anda yakin ingin memadam ahli ini?';

$txt['custom_title'] = 'Tajuk Pilihan';

$txt['lastLoggedIn'] = 'Terakhir Aktif';

$txt['notify_settings'] = 'Tetapan Makluman:';
$txt['notify_save'] = 'Simpan tetapan';
$txt['notify_important_email'] = 'Terima berita, pengumuman forum dan makluman penting dengan email.';
$txt['notify_regularity'] = 'Untuk topik2 dan ruangan2 yang sudah diminta maklumannya, maklumkan saya';
$txt['notify_regularity_none'] = 'Tidak pernah';
$txt['notify_regularity_instant'] = 'Segara';
$txt['notify_regularity_first_only'] = 'Segara - tapi hanya untuk jawapan pertama yang belum dibaca';
$txt['notify_regularity_daily'] = 'Harian';
$txt['notify_regularity_weekly'] = 'Mingguan';
$txt['auto_notify'] = 'Aktifkan makluman ketika anda mengepos atau menjawab topik.';
$txt['auto_notify_pbe_post'] = 'Ini <strong>TIDAK</strong> disarankan jika notifikasi "ruangan" anda dihidupkan.';
$txt['notify_send_types'] = 'Maklumkan saya topik2 dan ruangan2 yang diminta maklumannya';
$txt['notify_send_type_everything'] = 'Jawapan dan moderasi';
$txt['notify_send_type_everything_own'] = 'Hanya moderasi jika saya memulakan topik';
$txt['notify_send_type_only_replies'] = 'Hanya jawapan';
$txt['notify_send_type_only_replies_pbe'] = 'Semua mesej';
$txt['notify_send_type_nothing'] = 'Tidak sama sekali';
$txt['notify_send_body'] = 'Ketika mengirimkan makluman jawapan pada topik, kirim pos dalam email (tapi harap tidak menjawab ke email ini.)';
$txt['notify_send_body_pbe'] = 'Apabila menghantar notifikasi emel, hantar teks penuh pos dalam emel';
$txt['notify_send_body_pbe_post'] = '<strong>TIDAK</strong> ada dalam ringkasan Harian/ Mingguan';

$txt['notify_method'] = 'Notification and:';
$txt['notify_notification'] = 'no email (only mention/alert)';
$txt['notify_email'] = 'Immediate email';
$txt['notify_email_daily'] = 'Daily email';
$txt['notify_email_weekly'] = 'Weekly email';

$txt['notify_type_likemsg'] = 'Notify when one of your messages is liked';
$txt['notify_type_mentionmem'] = 'Notify when you are @mentioned';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Notify when someone adds you as buddy';
$txt['notify_type_quotedmem'] = 'Notify when someone quotes one of your messages';
$txt['notify_type_mailfail'] = 'Notify when email notifications are disabled (mention only)';

$txt['notifications_topics'] = 'Makluman Topik Semasa';
$txt['notifications_topics_none'] = 'Anda sekarang ini tidak menerima sebarang makluman topik.';
$txt['notifications_topics_howto'] = 'Untuk menerima makluman dari sebuah topik, klik butang &quot;maklumkan&quot; ketika melihatnya.';

$txt['notifications_boards'] = 'Makluman2 Ruangan Semasa';
$txt['notifications_boards_none'] = 'Anda tidak menerima makluman dari sebarang ruangan buat masa ini.';
$txt['notifications_boards_howto'] = 'Untuk meminta makluman dari ruangan tertentu, klik butang &quot;Maklumkan&quot; dalam indeks ruangan itu <strong>atau</strong> gunakan petak tanda di bawah untuk menghidupkan pilihan makluman2 ruangan.';
$txt['notifications_boards_current'] = 'Anda menerima notifikasi pada ruangan yang ditandakan <strong>TEBAL</strong>. Gunakan kotak penanda untuk mematikan atau menambahkan ruangan lain dalam senarai notifikasi anda.';
$txt['notifications_boards_update'] = 'Kemaskini';
$txt['notifications_update'] = 'Jangan maklumkan';

$txt['statPanel_showStats'] = 'Statistik pengguna untuk: ';
$txt['statPanel_users_votes'] = 'Jumlah Pilihan Diberikan';
$txt['statPanel_users_polls'] = 'Jumlah Undian Dibuat';
$txt['statPanel_total_time_online'] = 'Jumlah Waktu Online';
$txt['statPanel_noPosts'] = 'Tidak pernah pos!';
$txt['statPanel_generalStats'] = 'Statistik Umum';
$txt['statPanel_posts'] = 'pos';
$txt['statPanel_topics'] = 'topik';
$txt['statPanel_total_posts'] = 'Total Pos';
$txt['statPanel_total_topics'] = 'Total Topik Dimulakan';
$txt['statPanel_votes'] = 'pilihan';
$txt['statPanel_polls'] = 'undian';
$txt['statPanel_topBoards'] = 'Ruangan2 Terhangat Dengan Kiraan Pos';
$txt['statPanel_topBoards_posts'] = '%1$d pos daripada pos2 di ruangan %2$d (%3$01.2f%%)';
$txt['statPanel_topBoards_memberposts'] = '%1$d pos daripada %2$d pos ahli (%3$01.2f%%)';
$txt['statPanel_topBoardsActivity'] = 'Ruangan2 Terhangat Dengan Kiraan Aktiviti';
$txt['statPanel_activityTime'] = 'Aktiviti Pos Dengan Jam';
$txt['statPanel_activityTime_posts'] = '%1$d pos (%2$d%%) ';

$txt['deleteAccount_warning'] = 'Amaran - Tindakan ini tidak boleh dipulihkan!';
$txt['deleteAccount_desc'] = 'Dari laman ini anda boleh memadam akaun dan pos pengguna ini.';
$txt['deleteAccount_member'] = 'Padam akaun ahli ini';
$txt['deleteAccount_posts'] = 'Buang pos yang dibuat ahli ini';
$txt['deleteAccount_none'] = 'Tiada';
$txt['deleteAccount_all_posts'] = 'Semua Pos';
$txt['deleteAccount_topics'] = 'Topik dan Pos';
$txt['deleteAccount_confirm'] = 'Anda yakin ingin memadam akaun ini sepenuhnya?';
$txt['deleteAccount_approval'] = 'Harap dicatat bahawa moderator forum mesti meluluskan pemadaman akaun ini sebelum ia dipadam.';

$txt['profile_of_username'] = 'Profil %1$s';
$txt['profileInfo'] = 'Info Profil';
$txt['showPosts'] = 'Perlihatkan Pos';
$txt['showPosts_help'] = 'Bahagian ini mengizinkan anda untuk melihat semua pos yang dibuat oleh ahli ini. Perhatikan bahawa anda hanya boleh melihat pos yang dibuat dalam ruang di mana anda memiliki akses padanya.';
$txt['showMessages'] = 'Mesej';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = 'Topik';
$txt['showUnwatched'] = 'Topik tidak dipantau';
$txt['showAttachments'] = 'Lampiran';
$txt['viewWarning_help'] = 'Bahagian ini membolehkan anda melihat amaran yang dikeluarkan kepada ahli ini.';
$txt['statPanel'] = 'Papar Statistik';
$txt['editBuddyIgnoreLists'] = 'Senarai Teman/Pengabaian';
$txt['editBuddies'] = 'Edit Teman';
$txt['editIgnoreList'] = 'Edit Senarai Pengabaian';
$txt['trackUser'] = 'Kesan Pengguna';
$txt['trackActivity'] = 'Aktiviti';
$txt['trackIP'] = 'Alamat IP';
$txt['trackLogins'] = 'Login';

$txt['likes_show'] = 'Paparkan Suka';
$txt['likes_given'] = 'Pos yang anda suka';
$txt['likes_profile_received'] = 'diterima';
$txt['likes_profile_given'] = 'diberikan';
$txt['likes_received'] = 'Pos anda yang disukai oleh yang lain';
$txt['likes_none_given'] = 'Anda tidak suka sebarang pos';
$txt['likes_none_received'] = 'Tiada orang suka sebarang pos anda :\'(';
$txt['likes_confirm_delete'] = 'Buang suka ini?';
$txt['likes_show_who'] = 'Paparkan ahli yang suka pos ini';
$txt['likes_by'] = 'Disukai oleh';
$txt['likes_delete'] = 'Padam';

$txt['authentication'] = 'Pengesahan';
$txt['change_authentication'] = 'Dari bahagian ini anda boleh mengubah cara anda memasuki forum. Anda boleh memilih untuk menggunakan akaun OpenID untuk pengesahan anda, atau secara alternatif menggunakan nama pengguna dan kata kunci.';

$txt['profileEdit'] = 'Ubah Profil';
$txt['account_info'] = 'Ini adalah tetapan akaun anda. Laman ini menyimpan semua maklumat penting yang mengenalpasti anda di forum ini. Atas sebab-sebab sekuriti, anda perlu memasukkan kata kunci (semasa) anda untuk mengubah maklumat ini.';
$txt['forumProfile_info'] = 'Anda boleh mengubah maklumat peribadi anda di sini. Maklumat ini akan dipaparkan di keseluruhan {forum_name_html_safe}. Jika anda tidak selesa dengan berkongsi sebahagian maklumat, lompat sahaja - tiada yang diwajibkan di sini.';
$txt['theme_info'] = 'Bahagian ini mengizinkan anda untuk mengubahsuai rupa forum anda.';
$txt['notification_info'] = 'SMF mengizinkan anda untuk dimaklumkan atas jawapan yang dipos, topik baru dipos, dan pengumuman forum. Anda boleh mengubah tetapan itu di sini, atau melihat topik dan papan yang anda minta maklumannya.';
$txt['groupmembership'] = 'Keahlian Grup';
$txt['groupMembership_info'] = 'Dalam bahagian ini, profil yang boleh anda ubah adalah grup di mana anda berada.';
$txt['ignoreboards'] = 'Pilihan Pengabaian Ruangan2';
$txt['ignoreboards_info'] = 'Laman ini membolehkan anda untuk mengabaikan papan tertentu.  Ketika papan diabaikan, petunjuk pos baru tidak akan dipaparkan pada indeks papan.  Pos baru tidak akan dipaparkan menggunakan link carian "pos belum dibaca" (ketika mencari ia akan mengabaikan papan itu) akan tetapi, papan yang diabaikan masih akan terlihat pada indeks papan dan setelah memasukinya akan memaparkan topik dan pos mana yang memiliki topik dan  pos baru.  Ketika menggunakan link "jawapan belum dibaca", pos baru dalam papan yang diabaikan masih akan dipaparkan.';
$txt['contactprefs'] = 'Perutusan Mesej';

$txt['profileAction'] = 'Tindakan';
$txt['deleteAccount'] = 'Padam akaun ini';
$txt['profileSendIm'] = 'Kirim Mesej Peribadi';
$txt['profile_sendpm_short'] = 'Kirim Mesej';

$txt['profileBanUser'] = 'Sekat pengguna ini';

$txt['display_name'] = 'Nama paparan';
$txt['enter_ip'] = 'Masukkan IP (jangkauan)';
$txt['errors_by'] = 'Mesej kesalahan oleh';
$txt['errors_desc'] = 'Di bawah ini adalah senarai dari semua kesalahan terbaru yang dibuat/dialami oleh pengguna ini.';
$txt['errors_from_ip'] = 'Mesej kesalahan dari IP (jangkauan)';
$txt['errors_from_ip_desc'] = 'Di bawah ini adalah senarai semua mesej kesalahan yang dibuat oleh IP (jangkauan) ini.';
$txt['ip_address'] = 'Alamat IP';
$txt['ips_in_errors'] = 'IP yang dipakai dalam mesej kesalahan';
$txt['ips_in_messages'] = 'IP yang dipakai dalam pos baru';
$txt['members_from_ip'] = 'Ahli dari IP (jangkauan)';
$txt['members_in_range'] = 'Ahli mungkin dari jangkauan yang sama';
$txt['messages_from_ip'] = 'Mesej dipos dari IP (jangkauan)';
$txt['messages_from_ip_desc'] = 'Di bawah ini adalah senarai semua mesej yang dipos dari IP (jangkauan) ini.';
$txt['trackLogins_desc'] = 'Berikut adalah senarai waktu akaun ini dilog masuk.';
$txt['most_recent_ip'] = 'Alamat IP paling baru';
$txt['why_two_ip_address'] = 'Mengapa ada dua alamat IP didaftarkan?';
$txt['no_errors_from_ip'] = 'Tiada mesej kesalahan dari IP (jangkauan) itu dijumpai';
$txt['no_errors_from_user'] = 'Tiada mesej kesalahan dari pengguna itu dijumpai';
$txt['no_members_from_ip'] = 'Tiada ahli dari IP (jangkauan) itu dijumpai';
$txt['no_messages_from_ip'] = 'Tiada mesej dari IP (jangkauan) itu dijumpai';
$txt['trackLogins_none_found'] = 'Tiada log masuk terkini ditemui';
$txt['none'] = 'Tiada';
$txt['own_profile_confirm'] = 'Anda yakin ingin memadam akaun anda?';
$txt['view_ips_by'] = 'Lihat IP yang dipakai oleh';

$txt['avatar_will_upload'] = 'Muatnaik avatar';

$txt['activate_changed_email_title'] = 'Alamat Emel Telah Ditukar';
$txt['activate_changed_email_desc'] = 'Anda telah menukar alamat emel anda. Bagi mengesahkan alamat ini, anda akan menerima satu emel. Sila klil pautan dalam emel tersebut untuk mengaktifkan semula akaun anda.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Tidak boleh mengirimkan email pengingat.';
$txt['send_email'] = 'Kirim email ke';
$txt['to_ask_password'] = 'untuk meminta kata kunci';

$txt['user_email'] = 'Nama pengguna/Email';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'Surat sudah dikirimkan ke alamat email anda. Klik link dalam email untuk menetapkan kata kunci baru.';
$txt['reminder_openid_sent'] = 'Identiti OpenID anda sekarang sudah dikirimkan ke alamat email anda.';
$txt['reminder_set_password'] = 'Tetapkan Kata Kunci';
$txt['reminder_password_set'] = 'Kata kunci sudah ditetapkan dengan jayanya';
$txt['reminder_error'] = '%1$s gagal menjawab ke soalan rahsia mereka sendiri dengan betul ketika cuba untuk mengubah kata kunci yang terlupa.';

$txt['registration_not_approved'] = 'Maaf, akaun ini belum diluluskan. Jika anda perlu untuk mengubah alamat email sila klik';
$txt['registration_not_activated'] = 'Maaf, akaun ini belum diaktifkan. Jika anda perlu untuk mengirimkan semula email pengaktifan sila klik';

$txt['primary_membergroup'] = 'Grup Ahli Utama';
$txt['additional_membergroups'] = 'Grup Ahli Tambahan';
$txt['additional_membergroups_show'] = '[ papar grup tambahan ]';
$txt['no_primary_membergroup'] = '(tiada grup ahli utama)';
$txt['deadmin_confirm'] = 'Anda yakin ingin memadam selamanya status admin anda?';

$txt['account_activate_method_2'] = 'Akaun memerlukan pengaktifan semula setelah perubahan email';
$txt['account_activate_method_3'] = 'Akaun tidak diluluskan';
$txt['account_activate_method_4'] = 'Akaun menunggu kelulusan untuk pemadaman';
$txt['account_activate_method_5'] = 'Akaun &quot;dibawah usia&quot; menunggu kelulusan';
$txt['account_not_activated'] = 'Akaun semasa tidak diaktifkan';
$txt['account_activate'] = 'aktifkan';
$txt['account_approve'] = 'luluskan';
$txt['user_is_banned'] = 'Pengguna sedang disekat';
$txt['view_ban'] = 'Lihat';
$txt['user_banned_by_following'] = 'Pengguna sedang dipengaruhi oleh sekatan berikut';
$txt['user_cannot_due_to'] = 'Pengguna tidak boleh %1$s kerana sekatan: &quot;%2$s&quot;';
$txt['ban_type_post'] = 'mengepos';
$txt['ban_type_register'] = 'mendaftar';
$txt['ban_type_login'] = 'masuk';
$txt['ban_type_access'] = 'mengakses forum';

$txt['show_online'] = 'Papar status online saya kepada orang lain';

$txt['return_to_post'] = 'Kembali ke topik setelah mengepos secara default.';
$txt['no_new_reply_warning'] = 'Jangan peringatkan jawapan baru yang dibuat ketika mengepos.';
$txt['recent_pms_at_top'] = 'Papar mesej peribadi terbaru di atas.';
$txt['wysiwyg_default'] = 'Papar editor WYSIWYG pada laman pos secara default.';

$txt['timeformat_default'] = '(Default Forum)';
$txt['timeformat_easy1'] = 'Bulan Tarikh, Tahun, HH:MM:SS am/pm';
$txt['timeformat_easy2'] = 'Bulan Tarikh, Tahun, HH:MM:SS (24 jam)';
$txt['timeformat_easy3'] = 'YYYY-MM-DD, HH:MM:SS';
$txt['timeformat_easy4'] = 'DD Month YYYY, HH:MM:SS';
$txt['timeformat_easy5'] = 'DD-MM-YYYY, HH:MM:SS';

$txt['poster'] = 'Penulis';

$txt['use_sidebar_menu'] = 'Gunakan menu sisi daripada menu dropdown bila boleh.';
$txt['use_click_menu'] = 'Klik bagi membuka menu, menggantikan hover untuk membukanya.';
$txt['show_no_avatars'] = 'Jangan papar avatar pengguna.';
$txt['show_no_signatures'] = 'Jangan papar tandatangan pengguna.';
$txt['show_no_censored'] = 'Biarkan kata tidak disensor.';
$txt['topics_per_page'] = 'Topik dipaparkan satu laman:';
$txt['messages_per_page'] = 'Mesej dipaparkan satu laman:';
$txt['hide_poster_area'] = 'Sembunyikan ruangan info penulis.';
$txt['per_page_default'] = 'default forum';
$txt['calendar_start_day'] = 'Hari pertama dalam seminggu pada kalendar';
$txt['display_quick_reply'] = 'Gunakan jawab pantas pada paparan topik: ';
$txt['use_editor_quick_reply'] = 'Gunakan editor penuh dalam Jawapan Pantas.';
$txt['display_quick_mod'] = 'Papar moderasi pantas sebagai ';
$txt['display_quick_mod_none'] = 'jangan papar.';
$txt['display_quick_mod_check'] = 'kotak tanda.';
$txt['display_quick_mod_image'] = 'ikon.';

$txt['whois_title'] = 'Lihat IP pada server kawasan-whois';
$txt['whois_afrinic'] = 'AfriNIC (Afrika)';
$txt['whois_apnic'] = 'APNIC (kawasan Asia Pasifik)';
$txt['whois_arin'] = 'ARIN (Amerika Utara, sebahagian Caribbean dan sub-Sahara Afrika)';
$txt['whois_lacnic'] = 'LACNIC (kawasan Amerika Latin dan Caribbean)';
$txt['whois_ripe'] = 'RIPE (Eropah, Timur Tengah dan sebahagian Afrika dan Asia)';

$txt['moderator_why_missing'] = 'mengapa tiada moderator di sini?';
$txt['username_change'] = 'ubah';
$txt['username_warning'] = 'Untuk mengubah nama pengguna ahli ini, forum juga mesti menetapkan semula kata kunci mereka, yang akan diemail ke ahli dengan nama pengguna baru mereka.';

$txt['show_member_posts'] = 'Lihat Pos Ahli';
$txt['show_member_topics'] = 'Lihat Topik Ahli';
$txt['show_member_attachments'] = 'Lihat Lampiran Ahli';
$txt['show_posts_none'] = 'Belum ada pos ditulis.';
$txt['show_topics_none'] = 'Belum ada topik dipos.';
$txt['unwatched_topics_none'] = 'Anda tiada sebarang topik dalam senarai tidak dipantau.';
$txt['show_attachments_none'] = 'Belum ada lampiran dipos.';
$txt['show_attach_filename'] = 'Nama fail';
$txt['show_attach_downloads'] = 'Muatturun';
$txt['show_attach_posted'] = 'Dipos';

$txt['showPermissions'] = 'Papar Keizinan';
$txt['showPermissions_status'] = 'Status keizinan';
$txt['showPermissions_help'] = 'Bahagian ini membenarkan anda melihat semua keizinan untuk ahli ini (keizinan yang disekat adalah <del>dipotong</del>).';
$txt['showPermissions_given'] = 'Diberikan oleh';
$txt['showPermissions_denied'] = 'Dinafikan oleh';
$txt['showPermissions_permission'] = 'Keizinan (izin yang ditolak <del>dibuang</del>)';
$txt['showPermissions_none_general'] = 'Ahli ini tiada tetapan keizinan umum.';
$txt['showPermissions_none_board'] = 'Ahli ini tiada tetapan keizinan ruangan yang khusus.';
$txt['showPermissions_all'] = 'Sebagai pengurus, ahli ini memiliki semua keizinan yang ada.';
$txt['showPermissions_select'] = 'Keizinan ruangan yang khusus untuk';
$txt['showPermissions_general'] = 'Keizinan Umum';
$txt['showPermissions_global'] = 'Semua ruangan';
$txt['showPermissions_restricted_boards'] = 'Ruangan2 terbatas';
$txt['showPermissions_restricted_boards_desc'] = 'Ruangan2 berikut tidak boleh diakses oleh pengguna ini';

$txt['local_time'] = 'Waktu Tempatan';
$txt['posts_per_day'] = 'satu hari';

$txt['buddy_ignore_desc'] = 'Ruangan ini mengizinkan anda untuk menyelenggarakan senarai teman anda dan pengabaian di forum ini. Menambahkan ahli ke senarai ini akan membantu mengawal surat dan trafik mesej, bergantung kepada keutamaan anda.';

$txt['buddy_add'] = 'Tambah Ke Senarai Teman';
$txt['buddy_remove'] = 'Padam Dari Senarai Teman';
$txt['buddy_add_button'] = 'Tambah';
$txt['no_buddies'] = 'Senarai teman anda buat masa ini kosong';

$txt['ignore_add'] = 'Tambah ke Senarai Pengabaian';
$txt['ignore_remove'] = 'Padam Dari Senarai Pengabaian';
$txt['ignore_add_button'] = 'Tambah';
$txt['no_ignore'] = 'Senarai pengabaian anda buat masa ini kosong';

$txt['regular_members'] = 'Ahli Mendaftar';
$txt['regular_members_desc'] = 'Setiap ahli forum adalah ahli grup ini.';
$txt['group_membership_msg_free'] = 'Keahlian grup anda sudah dikemaskinikan dengan jayanya.';
$txt['group_membership_msg_request'] = 'Permintaan sudah dikirimkan, harap bersabar sementara permintaan dipertimbangkan.';
$txt['group_membership_msg_primary'] = 'Grup utama anda sudah dikemaskinikan';
$txt['current_membergroups'] = 'Grup Ahli Semasa';
$txt['available_groups'] = 'Grup Tersedia';
$txt['join_group'] = 'Sertai Grup';
$txt['leave_group'] = 'Tinggalkan Grup';
$txt['request_group'] = 'Minta Keahlian';
$txt['approval_pending'] = 'Menunggu Persetujuan';
$txt['make_primary'] = 'Jadikan Grup Utama';

$txt['request_group_membership'] = 'Minta Keahlian Grup';
$txt['request_group_membership_desc'] = 'Sebelum anda boleh menyertai grup ini, keahlian anda mesti diluluskan oleh moderator. Sila berikan alasan untuk menyertai grup ini';
$txt['submit_request'] = 'Kirim Permintaan';

$txt['profile_updated_own'] = 'Profil anda berjaya dikemaskinikan';
$txt['profile_updated_else'] = 'Profil %1$s berjaya dikemaskinikan';

$txt['profile_error_signature_max_length'] = 'Tandatangan anda tidak boleh lebih besar dari %1$d karakter';
$txt['profile_error_signature_max_lines'] = 'Tandatangan anda tidak boleh memanjang lebih dari %1$d baris';
$txt['profile_error_signature_max_image_size'] = 'Gambar dalam tandatangan anda mesti tidak lebih besar dari %1$dx%2$d pixel';
$txt['profile_error_signature_max_image_width'] = 'Gambar dalam tandatangan anda mesti tidak lebih lebar dari %1$d pixel';
$txt['profile_error_signature_max_image_height'] = 'Gambar dalam tandatangan anda mesti tidak lebih tinggi dari %1$d pixel';
$txt['profile_error_signature_max_image_count'] = 'Anda tidak boleh memiliki lebih dari %1$d gambar dalam tandatangan anda';
$txt['profile_error_signature_max_font_size'] = 'Teks dalam tandatangan anda saiznya tidak boleh lebih besar dari %1$s';
$txt['profile_error_signature_allow_smileys'] = 'Anda tidak dibenarkan menggunakan sebarang mimik dalam tandatangan anda';
$txt['profile_error_signature_max_smileys'] = 'Anda tidak dibenarkan menggunakan lebih daripada %1$d mimik dalam tandatangan anda';
$txt['profile_error_signature_disabled_bbc'] = 'BBC berikut tidak dibenarkan dalam tandatangan: %1$s';

$txt['profile_view_warnings'] = 'Lihat Amaran';
$txt['profile_issue_warning'] = 'Beri Amaran';
$txt['profile_warning_level'] = 'Tingkatkan Amaran';
$txt['profile_warning_desc'] = 'Dari bahagian ini anda boleh menyesuaikan tahap amaran pengguna dan memberinya dengan amaran bertulis jika diperlukan. Anda juga boleh mengesan sejarah amaran dan melihat kesan tahap amaran semasa yang ditentukan oleh pengurus.';
$txt['profile_warning_name'] = 'Nama Ahli';
$txt['profile_warning_impact'] = 'Hasil';
$txt['profile_warning_reason'] = 'Sebab untuk Amaran';
$txt['profile_warning_reason_desc'] = 'Ini diperlukan dan akan direkodkan.';
$txt['profile_warning_effect_none'] = 'Tiada.';
$txt['profile_warning_effect_watch'] = 'Pengguna akan ditambahkan ke senarai pengawasan moderator.';
$txt['profile_warning_effect_own_watched'] = 'Anda dalam senarai pengawasan moderator.';
$txt['profile_warning_is_watch'] = 'sedang diawasi';
$txt['profile_warning_effect_moderate'] = 'Semua pos pengguna akan dimoderasi.';
$txt['profile_warning_effect_own_moderated'] = 'Semua pos anda akan dimoderasi.';
$txt['profile_warning_is_moderation'] = 'pos dimoderasi';
$txt['profile_warning_effect_mute'] = 'Pengguna tidak boleh mengepos.';
$txt['profile_warning_effect_own_muted'] = 'Anda tidak boleh mengepos.';
$txt['profile_warning_is_muted'] = 'tidak boleh mengepos';
$txt['profile_warning_effect_text'] = 'Tahap >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Kirim Makluman';
$txt['profile_warning_notify_template'] = 'Pilih template:';
$txt['profile_warning_notify_subject'] = 'Subjek Makluman';
$txt['profile_warning_notify_body'] = 'Mesej Makluman';
$txt['profile_warning_notify_template_subject'] = 'Anda diberi amaran';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},⏎
⏎
Anda diberikan amaran kerana %1$s. Sila hentikan aktiviti ini dan patuhi peraturan forum atau kami akan mengambil tindakan lanjut.⏎
⏎
{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},⏎
⏎
Anda diberikan amaran kerana %1$s mengenai mesej:
{MESSAGE}.⏎
⏎Sila hentikan aktiviti ini dan patuhi peraturan forum atau kami akan mengambil tindakan lanjut.⏎
⏎
{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'spam';
$txt['profile_warning_notify_title_spamming'] = 'Spam';
$txt['profile_warning_notify_for_offence'] = 'pos bahan ofensif';
$txt['profile_warning_notify_title_offence'] = 'Pos Bahan Ofensif';
$txt['profile_warning_notify_for_insulting'] = 'menghina pengguna lain dan/atau ahli staf';
$txt['profile_warning_notify_title_insulting'] = 'Menghina Pengguna/Staf';
$txt['profile_warning_issue'] = 'Beri Amaran';
$txt['profile_warning_max'] = '(Maks 100)';
$txt['profile_warning_limit_attribute'] = 'Perhatikan bahawa anda tidak boleh mengubah tahap pengguna ini lebih dari %1$d%% dalam periode 24 jam.';
$txt['profile_warning_errors_occurred'] = 'Amaran tidak dihantar kerana kesalahan berikut';
$txt['profile_warning_success'] = 'Amaran Berjaya Diberi';
$txt['profile_warning_new_template'] = 'Template Baru';

$txt['profile_warning_previous'] = 'Amaran Sebelumnya';
$txt['profile_warning_previous_none'] = 'Pengguna ini belum pernah menerima sebarang amaran sebelumnya.';
$txt['profile_warning_previous_issued'] = 'Diterbitkan Oleh';
$txt['profile_warning_previous_time'] = 'Masa';
$txt['profile_warning_previous_level'] = 'Mata';
$txt['profile_warning_previous_reason'] = 'Alasan';
$txt['profile_warning_previous_notice'] = 'Lihat Catatan Yang Dikirimkan Kepada Ahli';

$txt['viewwarning'] = 'Lihat Amaran';
$txt['profile_viewwarning_for_user'] = 'Amaran untuk %1$s';
$txt['profile_viewwarning_no_warnings'] = 'Belum ada amaran yang diberikan!';
$txt['profile_viewwarning_desc'] = 'Di bawah ini adalah ringkasan dari semua amaran yang sudah diberi oleh kumpulan moderasi forum.';
$txt['profile_viewwarning_previous_warnings'] = 'Amaran Sebelumnya';
$txt['profile_viewwarning_impact'] = 'Kesan Amaran';

$txt['subscriptions'] = 'Langganan Berbayar';

$txt['pm_settings_desc'] = 'Dari laman ini anda boleh mengubah pelbagai pilihan mesej peribadi - termasuk cara mesej dipaparkan dan siapa yang boleh mengirimkan mesej kepada anda.';
$txt['email_notify'] = 'Maklumkan dengan email setiap kali anda menerima mesej peribadi:';
$txt['email_notify_never'] = 'Tidak pernah';
$txt['email_notify_buddies'] = 'Hanya Dari Teman';
$txt['email_notify_always'] = 'Selalu';

$txt['receive_from'] = 'Ahli dibenarkan menghubungi saya:';
$txt['receive_from_everyone'] = 'Semua ahli';
$txt['receive_from_ignore'] = 'Semu ahli, kecuali semua dalam senarai abaian saya';
$txt['receive_from_admins'] = 'Pentadbir sahaja';
$txt['receive_from_buddies'] = 'Rakan dan Pentadbir sahaja';
$txt['receive_from_description'] = 'Tetapan ini terpakai kepada kedua2 Mesej Peribadi dan emel (jika pilihan untuk emel ahli dihidupkan)';

$txt['popup_messages'] = 'Papar popup bila saya menerima mesej peribadi baru.';
$txt['pm_remove_inbox_label'] = 'Padam label inbox ketika menerapkan label lain';
$txt['pm_display_mode'] = 'Papar mesej peribadi';
$txt['pm_display_mode_all'] = 'Sekaligus';
$txt['pm_display_mode_one'] = 'Satu-persatu';
$txt['pm_display_mode_linked'] = 'Seperti bicara';

$txt['history'] = 'Sejarah';
$txt['history_description'] = 'Bahagian ini membolehkan anda menyemak beberapa tindakan profil yang dilakukan kepada profil ahli ini termasuk mengesan alamat IP dan rekod log masuk mereka.';

$txt['trackEdits'] = 'Ubahan Profil';
$txt['trackEdit_deleted_member'] = 'Ahli Dipadam';
$txt['trackEdit_no_edits'] = 'Tiada edit yang direkodkan untuk ahli setakat ini.';
$txt['trackEdit_action'] = 'Petak';
$txt['trackEdit_before'] = 'Nilai Sebelum';
$txt['trackEdit_after'] = 'Nilai Setelah';
$txt['trackEdit_applicator'] = 'Diubah Oleh';

$txt['trackEdit_action_real_name'] = 'Nama Ahli';
$txt['trackEdit_action_usertitle'] = 'Tajuk Pilihan';
$txt['trackEdit_action_member_name'] = 'Nama pengguna';
$txt['trackEdit_action_email_address'] = 'Alamat Emel';
$txt['trackEdit_action_id_group'] = 'Grup Ahli Utama';
$txt['trackEdit_action_additional_groups'] = 'Grup Ahli Tambahan';

$txt['otp_enabled_help'] = 'Enabling this will add a second factor (one-time password) for authentication.';
$txt['otp_token_help'] = 'This generates a secret token for time-based one-time password  apps such as Authy or Google Authenticator. Once the secret was generated use your favorite authenticator app and scan the qrcode.<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
