<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Paparkan Deraf';
$txt['drafts_show_desc'] = 'Ruangan ini memaparkan semua deraf yang telah disimpan. Di sini anda boleh mengeditnya sebelum mengepos, atau memadamkannya.';

// misc
$txt['drafts'] = 'Deraf';
$txt['draft_save'] = 'Simpan Deraf';
$txt['draft_save_note'] = 'Ini akan menyimpan teks pos anda, tanpa lampiran, undian atau maklumat acara.';
$txt['draft_none'] = 'Anda tiada deraf.';
$txt['draft_edit'] = 'Edit deraf';
$txt['draft_load'] = 'Keluarkan deraf';
$txt['draft_hide'] = 'Sembunyikan deraf';
$txt['draft_delete'] = 'Padam deraf';
$txt['draft_days_ago'] = '%s hari yang lalu';
$txt['draft_retain'] = 'ini akan disimpan lagi %s hari';
$txt['draft_remove'] = 'Buang deraf ini';
$txt['draft_remove_selected'] = 'Buang semua deraf pilihan?';
$txt['draft_saved'] = 'Kandungan ini telah disimpan sebagai deraf dan boleh diakses daripada <a href="%1$s">Papar Ruangan Deraf</a> dalam profil anda.';
$txt['draft_pm_saved'] = 'Kandungan ini telah disimpan sebagai deraf dan boleh diakses daripada <a href="%1$s">Papar Ruangan Deraf</a> dalam pusat mesej anda.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Hidupkan simpanan deraf secara automatik';
$txt['drafts_autosave_enabled_subnote'] = 'Ini akan menyimpan deraf ahli di belakang tabir pada masa yang ditetapkan. Ahli juga seharusnya perlu ada keizinan yang sepatutnya';
$txt['drafts_keep_days'] = 'Maksima hari untuk menyimpan deraf';
$txt['drafts_keep_days_subnote'] = 'Masukkan 0 untuk tiada had masa';
$txt['drafts_autosave_frequency'] = 'Berapa kerap deraf disimpan secara automatik?';
$txt['drafts_autosave_frequency_subnote'] = 'Nilai minima dibenarkan ialah 30 saat';
$txt['drafts_pm_enabled'] = 'Benarkan menyimpan deraf mesej peribadi';
$txt['drafts_post_enabled'] = 'Benarkan menyimpan deraf pos';
$txt['drafts_none'] = 'Tiada Subjek';
$txt['drafts_saved'] = 'Deraf telah berjaya disimpan';