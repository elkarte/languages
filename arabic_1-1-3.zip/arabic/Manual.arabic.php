<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'دليل المستخدم';

$txt['manual_welcome'] = 'مرحبا بك في %s, بدعم من  ElkArte برنامج المنتديات!';
$txt['manual_introduction'] = 'ElkArte هي حل برمجي للمنتديات أنيقة وفعالة وقوية ومجانية وان هذا الموقع قيد التشغيل بها . وهو يتيح للمستخدمين التواصل في مواضيع النقاش في مجال معين بطريقة ذكية وتنظيمها. وعلاوة على ذلك، فإنه يحتوي على عدد من الميزات القوية التي يمكن للمستخدمين النهائيين الاستفادة منه. المساعدة للعديد من ميزات ElkArte يمكن الاطلاع عليها إما بالنقر على رمز علامة استفهام بجوار القسم المختص أو عن طريق اختيار واحد من الروابط على هذه الصفحة. وهذه الروابط تقود إلى وثائق ElkArte في موقع مركزي متواجد على الموقع الرسمي ل ElkArte.';
$txt['manual_docs_and_credits'] = 'للمزيد من المعلومات عن كيفية استخدام منتدي ElkArte ، تفضل بزيارة <a href="%1$s" target="_blank" class="new_win">مركز الوثائق</a> ، شاهد أيضا  <a href="%2$s">اصحاب الفضل</a> لتتعرف على من جعل ElkArte كما هي عليه اليوم .';

$txt['manual_section_registering_title'] = 'التسجيل';
$txt['manual_section_logging_in_title'] = 'تسجيل الدخول';
$txt['manual_section_profile_title'] = 'الملف الشخصي';
$txt['manual_section_search_title'] = 'إدارة البحث';
$txt['manual_section_posting_title'] = 'الكتابة فى المنتدى';
$txt['manual_section_bbc_title'] = 'Bulletin Board Code (BBC) أكواد محرر المشاركات لتجميل وتطويع عناصر المشاركة';
$txt['manual_section_personal_messages_title'] = 'الرسائل الشخصية';
$txt['manual_section_memberlist_title'] = 'قائمة الأعضاء';
$txt['manual_section_calendar_title'] = 'إدارة التقويم';
$txt['manual_section_features_title'] = 'الميزات';

$txt['manual_section_registering_desc'] = 'الكثير من المنتديات قد تطلب منك التسجيل لديها لكى تتمكن من الحصول على صلاحيات أكثر .';
$txt['manual_section_logging_in_desc'] = 'بمجرد التسجيل , يجب على الاعضاء تسجيل الدخول للبدء فى إستخدام حساباتهم .';
$txt['manual_section_profile_desc'] = 'كل عضو فى المنتدى له الملف الشخصى الخاص به .';
$txt['manual_section_search_desc'] = 'البحث هو أداة مفيدة جدا للعثور على المعولمات التى تريدها داخل المواضيع و الردود .';
$txt['manual_section_posting_desc'] = 'إنه الهدف الرئيسي للمنتدى , الكتابة فى المنتدى تجعل الاعضاء قادرين على التعبير عن أنفسهم .';
$txt['manual_section_bbc_desc'] = 'يمكن تجميل المشاركات باستخدام اكواد BBC بمحرر المشاركات .';
$txt['manual_section_personal_messages_desc'] = 'حيث يمكن للاعضاء مراسلة بعضهم الأخر .';
$txt['manual_section_memberlist_desc'] = 'وهى قائمة يظهر بها كل أعضاء المنتدى .';
$txt['manual_section_calendar_desc'] = 'حيث يمكن اللأعضاء متابعة الأحداث, الإجازات و أعياد الميلاد عن طريق التقويم .';
$txt['manual_section_features_desc'] = 'ستجد هنا قائمة بمعظم الميزات المفضلة ببرنامج  ElkArte. للمنتديات.';