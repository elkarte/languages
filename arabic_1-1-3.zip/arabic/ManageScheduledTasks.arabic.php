<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'المهمات المجدولة';
$txt['scheduled_tasks_header'] = 'جميع المهمات المجدولة';
$txt['scheduled_tasks_name'] = 'إسم المهمة';
$txt['scheduled_tasks_next_time'] = 'موعد التشغيل التالى';
$txt['scheduled_tasks_regularity'] = 'المواعيد الثابته للتشغيل';
$txt['scheduled_tasks_enabled'] = 'تفعيل';
$txt['scheduled_tasks_run_now'] = 'قم بتشغيل المهمة الآن';
$txt['scheduled_tasks_save_changes'] = 'حفظ التغيرات';
$txt['scheduled_tasks_time_offset'] = '<strong>Note:</strong> All times given below are <em>server time</em> and do not take any time offsets setup within the admin panel into account.';
$txt['scheduled_tasks_were_run'] = 'جميع المهمات المختاره تم الانتهاء منها';
$txt['scheduled_tasks_were_run_errors'] = 'The following errors occurred while running the scheduled tasks:';

$txt['scheduled_tasks_na'] = 'غ/م';
$txt['scheduled_task_approval_notification'] = 'التنبيه بقائمة الإنتظار';
$txt['scheduled_task_desc_approval_notification'] = 'ارسل بريدا الكترونيا إلى جميع المشرفين لتلخيص المشاركات التي تتطلب الموافقة ضمن أقسامهم.';
$txt['scheduled_task_auto_optimize'] = 'تحسين قاعدة البيانات';
$txt['scheduled_task_desc_auto_optimize'] = 'يقوم بتحسين فعالية قاعدة البيانات و تصليح أى خطأ .';
$txt['scheduled_task_daily_maintenance'] = 'الصيانة اليومية';
$txt['scheduled_task_desc_daily_maintenance'] = 'يقوم بعمل صيانه يومية للمنتدى - لا يستحسن ايقافه اتركه مفعل .';
$txt['scheduled_task_daily_digest'] = 'ملخص التنبيهات اليومية';
$txt['scheduled_task_desc_daily_digest'] = 'يقوم بإرسال بريد إلكترونى بخلاصة التنبيهات اليومية التى تم الإشتراك بها .';
$txt['scheduled_task_weekly_digest'] = 'ملخص التنبيهات الإسبوعية';
$txt['scheduled_task_desc_weekly_digest'] = 'يقوم بإرسال بريد إلكترونى بخلاصة التنبيهات الإسبوعية التى تم الإشتراك بها .';
$txt['scheduled_task_birthdayemails'] = 'إرسل بريد تهنئة بأعياد الميلاد';
$txt['scheduled_task_desc_birthdayemails'] = 'إرسال بريد للأعضاء لتهنئتهم بأعياد ميلادهم .';
$txt['scheduled_task_weekly_maintenance'] = 'الصيانة الإسبوعية';
$txt['scheduled_task_desc_weekly_maintenance'] = 'يقوم بعمل صيانه إسبوعيه للمنتدى - لا يستحسن ايقافه اتركه مفعل .';
$txt['scheduled_task_paid_subscriptions'] = 'فحص الإشتراكات المدفوعه';
$txt['scheduled_task_desc_paid_subscriptions'] = 'إرسال رسائل تنبيهية للأعضاء الذين لديهم إشتراكات مدفوعه لتخبرهم متى تنتهى صلاحية إشتراكهم , و مسح الإشتراكات التى إنتهت صلاحيتها .';
$txt['scheduled_task_remove_topic_redirect'] = 'Remove MOVED: Redirection Topics';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Deletes "MOVED:" topic notifications as specified when the moved notice was created.';
$txt['scheduled_task_remove_temp_attachments'] = 'Remove Temporary Attachment Files';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Deletes temporary files created while attaching a file to a post that for any reason weren\'t renamed or deleted before.';
$txt['scheduled_task_remove_old_drafts'] = 'Remove Old Drafts';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Deletes drafts older than the number of days defined in the draft settings in the admin panel.';
$txt['scheduled_task_remove_old_followups'] = 'Remove Old Follow-ups';
$txt['scheduled_task_desc_remove_old_followups'] = 'Deletes follow-up entries still present in the database, but pointing to non-existent topics.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Fetch Emails from IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Fetches emails for the mailing list feature from an IMAP box and processes them.';
$txt['scheduled_task_user_access_mentions'] = 'Users Mentions Access';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verify users access to each board and set accessibility to related mentions accordingly.';

$txt['scheduled_task_reg_starting'] = 'سيبدأ فى %1$s ';
$txt['scheduled_task_reg_repeating'] = 'إصلاح كل  %1$d %2$s ';
$txt['scheduled_task_reg_unit_m'] = 'دقائق';
$txt['scheduled_task_reg_unit_h'] = 'ساعة';
$txt['scheduled_task_reg_unit_d'] = 'أيام';
$txt['scheduled_task_reg_unit_w'] = 'أسابيع';

$txt['scheduled_task_edit'] = 'تعديل المهمات المجدولة';
$txt['scheduled_task_edit_repeat'] = 'كرر المهمة كل';
$txt['scheduled_task_edit_pick_unit'] = 'اختر وحدة';
$txt['scheduled_task_edit_interval'] = 'الفاصل الزمنى';
$txt['scheduled_task_edit_start_time'] = 'وقت البداية';
$txt['scheduled_task_edit_start_time_desc'] = 'الوقت الذى سوف تبدأ فيه العمليه من اليوم (الساعة:الدقيقة)';
$txt['scheduled_task_time_offset'] = 'لاحظ أن وقت البدء يجب ان يكون حسب التوقيت المحلى للسرفر. التوقيت المحلى للسرفر هو: %1$s ';

$txt['scheduled_view_log'] = 'عرض السجل';
$txt['scheduled_log_empty'] = 'لا يوجد أى مهمة قد تم تسجيلها فى هذا السجل .';
$txt['scheduled_log_time_run'] = 'وقت التشغيل';
$txt['scheduled_log_time_taken'] = 'الوقت المستغرق';
$txt['scheduled_log_time_taken_seconds'] = '%1$d ثانية';
$txt['scheduled_log_completed'] = 'Task completed';
$txt['scheduled_log_empty_log'] = 'تنظيف السجل';
$txt['scheduled_log_empty_log_confirm'] = 'هل ترغب بالفعل في حذف كافة مدخلات السجل؟';