<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'الرسائل الشخصية';
$txt['pm_add'] = 'اضافة';
$txt['make_bcc'] = 'إضافة تنسيق BBC';
$txt['pm_to'] = 'إلى';
$txt['pm_bcc'] = 'Bcc';
$txt['inbox'] = 'الوارد';
$txt['conversation'] = 'محادثة';
$txt['messages'] = 'الرسائل';
$txt['sent_items'] = 'الرسائل المُرسلة';
$txt['new_message'] = 'رسالة جديدة';
$txt['delete_message'] = 'حذف رسالة ';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'حذف جميع الرسائل في PMBOX';
$txt['delete_all_confirm'] = 'هل انت متاكد من حذف جميع الرسائل؟';

$txt['delete_selected_confirm'] = 'هل انت متاكد من حذف جميع الرسائل الشخصية المختارة؟';

$txt['sent_to'] = 'ارسال الى';
$txt['reply_to_all'] = 'الرد على الكل';
$txt['delete_conversation'] = 'حذف المحادثة';

$txt['pm_capacity'] = 'السعة';
$txt['pm_currently_using'] = '%1$s رسائل, %2$s%% كاملة.';
$txt['pm_sent'] = 'تم إرسال رسالتك بنجاح .';

$txt['pm_error_user_not_found'] = 'لم نتمكن من ايجاد العضو \'%1$s\'.';
$txt['pm_error_ignored_by_user'] = 'العضو \'%1$s\'قام بحجب رسائلك الخاصة.';
$txt['pm_error_data_limit_reached'] = 'PM could not be sent to \'%1$s\' as their inbox is full.';
$txt['pm_error_user_cannot_read'] = 'العضو \'%1$s\' لا يستطيع أن يستقبل رسائل خاصة.';
$txt['pm_successfully_sent'] = 'تم ارسال الرسالة الى \'%1$s\' بنجاح.';
$txt['pm_send_report'] = 'ارسال تقرير';
$txt['pm_undisclosed_recipients'] = 'مستلمين مخفيين';
$txt['pm_too_many_recipients'] = 'لا يمكنك إرسال رسائل خاصة لأكثر من %1$d  مستقبل دفعة واحدة.';

$txt['pm_read'] = 'زيارة';
$txt['pm_replied'] = 'الرد على';
$txt['pm_mark_unread'] = 'Mark as Unread';

// Message Pruning.
$txt['pm_prune'] = 'Prune messages';
$txt['pm_prune_desc'] = 'Delete all personal messages older than %1$s days.';
$txt['pm_prune_warning'] = 'هل انت متاكد من تقليل مساحة الرسائل الشخصية؟';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Further actions';
$txt['pm_actions_delete_selected'] = 'حذف المعلم عليه';
$txt['pm_actions_filter_by_label'] = 'Filter by label';
$txt['pm_actions_go'] = 'اذهب';

// Manage Labels Screen.
$txt['pm_apply'] = 'تطبيق';
$txt['pm_manage_labels'] = 'Manage labels';
$txt['pm_labels_delete'] = 'هل تريد حذف العلامة المختارة؟';
$txt['pm_labels_desc'] = 'هنا يمكنك اضافة و تعديل و حذف العلامات المستخدمة في الرسائل الشخصية.';
$txt['pm_label_add_new'] = 'Add new label';
$txt['pm_label_name'] = 'Label name';
$txt['pm_labels_no_exist'] = 'لا يوجد اي علامات محددة!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'علامة';
$txt['pm_msg_label_title'] = 'Label message';
$txt['pm_msg_label_apply'] = 'Add label';
$txt['pm_msg_label_remove'] = 'Remove label';
$txt['pm_msg_label_inbox'] = 'الوارد';
$txt['pm_sel_label_title'] = 'Label selected';

// Sidebar Headings.
$txt['pm_labels'] = 'العلامات';
$txt['pm_messages'] = 'الرسائل';
$txt['pm_actions'] = 'إجراءات';
$txt['pm_preferences'] = 'تفضيلات';

$txt['pm_is_replied_to'] = 'لقد قمت بالرد على هذه الرسالة.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Report to admin';
$txt['pm_report_title'] = 'Report personal message';
$txt['pm_report_desc'] = 'من هذه الصفحة يمكنك إرسال تقرير للمشرف عن رسالة شخصية غير مرغوبة، و يجب اضافة سبب للتقرير و سترفق نسخة من الرسالة الى المشرف.';
$txt['pm_report_admins'] = 'الاداري المرسل اليه:';
$txt['pm_report_all_admins'] = 'الارسال الى جميع الاداريين';
$txt['pm_report_reason'] = 'سبب ارسال هذا التقرير';
$txt['pm_report_message'] = 'إرسال التقرير';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[تقرير]';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} قام بتقرير هذه الرسالة الشخصية من المرسل {SENDER}, لهذا السبب:';
$txt['pm_report_pm_other_recipients'] = 'المستقبلين الاخرين للرسالة:';
$txt['pm_report_pm_hidden'] = '%1$d المستقبلين المخفيين';
$txt['pm_report_pm_unedited_below'] = 'في الاسفل الرسالة الشخصية المقررة:';
$txt['pm_report_pm_sent'] = 'تم الارسال:';

$txt['pm_report_done'] = 'شكرا للتقرير عن الرسالة، و سيتم الرد من قبل الاداري في اسرع وقت';
$txt['pm_report_return'] = 'العودة الى صندوق الوارد';

$txt['pm_search_title'] = 'Search personal messages';
$txt['pm_search_bar_title'] = 'Search messages';
$txt['pm_search_text'] = 'بحث عن';
$txt['pm_search_go'] = 'إدارة البحث';
$txt['pm_search_advanced'] = 'عرض الخيارات المتقدمة';
$txt['pm_search_simple'] = 'اخفاء الخيارات المتقدمة';
$txt['pm_search_user'] = 'البحث بالاعضاء';
$txt['pm_search_match_all'] = 'مطابقة جميع الكلمات';
$txt['pm_search_match_any'] = 'مطابقة اي كلمة';
$txt['pm_search_options'] = 'خيارات';
$txt['pm_search_post_age'] = 'عُمر الرسالة';
$txt['pm_search_show_complete'] = 'اظهار الرسائل كاملة في النتائج.';
$txt['pm_search_subject_only'] = 'البحث في العنواين و المرسلين فقط.';
$txt['pm_search_sent_only'] = 'Search only in sent items.';
$txt['pm_search_between'] = 'بين';
$txt['pm_search_between_and'] = 'و';
$txt['pm_search_between_days'] = 'ايام';
$txt['pm_search_order'] = 'ترتيب النتائج بـ';
$txt['pm_search_choose_label'] = 'اخترعلامة للبحث فيها او البحث في الكل';

$txt['pm_search_results'] = 'Search results';
$txt['pm_search_none_found'] = 'No messages found';

$txt['pm_search_orderby_relevant_first'] = 'الاقرب الى الموضوع اولا';
$txt['pm_search_orderby_recent_first'] = 'الاحدث اولا';
$txt['pm_search_orderby_old_first'] = 'الاقدم اولا';

$txt['pm_visual_verification_label'] = 'التحقق';
$txt['pm_visual_verification_desc'] = 'Please enter the code in the image above in order to send this PM.';

$txt['pm_settings'] = 'Change settings';
$txt['pm_change_view'] = 'Change view';

$txt['pm_manage_rules'] = 'Manage rules';
$txt['pm_manage_rules_desc'] = 'قواعد الرسائل الخاصة تسمح لك بترتيب الرسائل المُستقبلة  (بشكل آلي) اعتمادا على تخصيصك . في الأسفل ستجد جميع القواعد التي فعلتها من قبل. لتعديل قاعدة ببساطة اضغط على اسم القاعدة.';
$txt['pm_rules_none'] = 'لم تقم بتثبيت أية قاعدة للرسائل.';
$txt['pm_rule_title'] = 'قاعدة';
$txt['pm_add_rule'] = 'Add new rule';
$txt['pm_apply_rules'] = 'Apply rules now';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'هل أنت متأكد من أنك تريد أن تطبق هذه القواعد على جميع الرسائل الخاصة?';
$txt['pm_edit_rule'] = 'Edit rule';
$txt['pm_rule_save'] = 'Save rule';
$txt['pm_delete_selected_rule'] = 'Delete selected rules';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'هل أنت متأكد من أنك تريد أن تحذف جميع القواعد المحددة?';
$txt['pm_rule_name'] = 'الاسم';
$txt['pm_rule_name_desc'] = 'اسم القاعدة الذي تريد أن تستخدمه لهذه القاعدة';
$txt['pm_rule_name_default'] = '[الإسم]';
$txt['pm_rule_description'] = 'الوصف';
$txt['pm_rule_not_defined'] = 'أضف معيار معين لكي تبدأ ببناء قاعدة جديدة.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>ملاحظة:</strong> جافا سكريبت لديك غير مفعلة. يجب عليك تفعيل جافا سكريبت من أجل استخدام هذه الميزة.</span>';
$txt['pm_rule_criteria'] = 'معايير';
$txt['pm_rule_criteria_add'] = 'Add criteria';
$txt['pm_rule_criteria_pick'] = 'Choose criteria';
$txt['pm_rule_mid'] = 'Sender name';
$txt['pm_rule_gid'] = 'Sender\'s group';
$txt['pm_rule_sub'] = 'Message subject contains';
$txt['pm_rule_msg'] = 'Message body contains';
$txt['pm_rule_bud'] = 'Sender is buddy';
$txt['pm_rule_sel_group'] = 'Select group';
$txt['pm_rule_logic'] = 'When checking criteria';
$txt['pm_rule_logic_and'] = 'كل المعايير يجب أن تتحقق';
$txt['pm_rule_logic_or'] = 'أية معيار ممكن أن يتحقق';
$txt['pm_rule_actions'] = 'إجراءات';
$txt['pm_rule_sel_action'] = 'Select an action';
$txt['pm_rule_add_action'] = 'Add action';
$txt['pm_rule_label'] = 'أضف علامة للرسالة';
$txt['pm_rule_sel_label'] = 'Select label';
$txt['pm_rule_delete'] = 'Delete message';
$txt['pm_rule_no_name'] = 'نسيت ادخال اسم القاعدة.';
$txt['pm_rule_no_criteria'] = 'يجب أن تكون للقاعدة معيار واحد و إجراء واحد على الأقل.';
$txt['pm_rule_too_complex'] = 'The rule you are creating is too long to save. Try breaking it up into smaller rules.';

$txt['pm_readable_and'] = '<em>و</em>';
$txt['pm_readable_or'] = '<em>أو</em>';
$txt['pm_readable_start'] = 'إذا ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'الرسالة من &quot;{MEMBER}&quot;';
$txt['pm_readable_group'] = 'المُرسِل من مجموعة الأعضاء &quot;{GROUP}&quot;';
$txt['pm_readable_subject'] = 'عنوان الرسالة يتضمن &quot;{SUBJECT}&quot;';
$txt['pm_readable_body'] = 'محتوى الرسالة يتضمن &quot;{BODY}&quot;';
$txt['pm_readable_buddy'] = 'المُرسِل صديق';
$txt['pm_readable_label'] = 'تطبيق العلامة &quot;{LABEL}&quot;';
$txt['pm_readable_delete'] = 'احذف الرسالة';
$txt['pm_readable_then'] = '<b>فــ</b>';