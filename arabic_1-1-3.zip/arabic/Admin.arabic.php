<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'معالجة المنتديات';
$txt['admin_back_to'] = 'الرجوع للوحة الإدارة ';
$txt['admin_users'] = 'تحكم الأعضاء';
$txt['admin_newsletters'] = 'إرسال بريد للأعضاء';
$txt['include_these'] = 'Members to include';
$txt['exclude_these'] = 'Members to exclude';
$txt['admin_newsletters_select_groups'] = 'Groups to include';
$txt['admin_newsletters_exclude_groups'] = 'Groups to exclude';
$txt['admin_edit_news'] = 'الأخبار';
$txt['admin_groups'] = 'Member groups';
$txt['admin_members'] = 'مشاهدة كافة الأعضاء';
$txt['admin_members_list'] = 'في الأسفل قائمة بكافة الأعضاء المسجلين في المنتدى.';
$txt['admin_next'] = 'التالي';
$txt['admin_censored_words'] = 'تحرير الكلمات المراقبة';
$txt['admin_censored_where'] = 'Enter the word to be censored into the left box and the word to change it to, into the right box. Then select if you want to check the whole word and the case. When you\'re finished with each word, click Save. Multiple entries can be made prior to saving by clicking the \'Add another word\' button.';
$txt['admin_censored_desc'] = 'Due to the public nature of forums there may be some words that you wish to prohibit being posted by users of your forum. You can enter any words below that you wish to be censored whenever used by a member.<br />Clear a box to remove that word from the censor.';
$txt['admin_reserved_names'] = 'الأسماء المحجوزة';
$txt['admin_template_edit'] = 'تحرير قالب المنتدى';
$txt['admin_modifications'] = 'إعدادات الإضافات';
$txt['admin_security_moderation'] = 'الحماية والإشراف';
$txt['admin_server_settings'] = 'تحرير إعدادات الملقم';
$txt['admin_reserved_set'] = 'ضبط الأسماء المحجوزة';
$txt['admin_reserved_line'] = 'كلمة واحدة لكل سطر.';
$txt['admin_basic_settings'] = 'في هذه الصفحة يمكنك تغيير الإعدادات الأساسية للمنتدى. كن حذراً في التعامل مع هذه الإعدادات التي قد يودي سوء استخدامها إلى تعطيل عمل المنتدى. كذلكا لاحظ أن بعض الخيارات (مثل شكل الوقت) هي خيارات افتراضية أو خاصة بالضيوف فقط.';
$txt['admin_maintain'] = 'تفعيل نمط الصيانة؟';
$txt['admin_title'] = 'اسم المنتدى';
$txt['admin_url'] = 'رابط المنتدى';
$txt['cookie_name'] = 'Cookie name';
$txt['admin_webmaster_email'] = 'Webmaster email address';
$txt['boarddir'] = 'قاموس ElkArte';
$txt['sourcesdir'] = 'Sources مجلد';
$txt['cachedir'] = 'مجلد الكاش';
$txt['admin_news'] = 'تفعيل الأخبار؟';
$txt['admin_guest_post'] = 'تمكين مشاركات الزوار';
$txt['admin_manage_members'] = 'تحكم الأعضاء';
$txt['admin_main'] = 'تحكم المنتدى';
$txt['admin_config'] = 'إعدادات المنتدى';
$txt['admin_version_check'] = 'Detailed version check';
$txt['admin_elkfile'] = 'ElkArte File';
$txt['admin_elkpackage'] = 'ElkArte Package';
$txt['admin_logoff'] = 'End Admin Session';
$txt['admin_maintenance'] = 'الصيانة';
$txt['admin_image_text'] = 'عرض الأزرار كصور بدلاً من النص';
$txt['admin_credits'] = 'فريق المبرمجين';
$txt['admin_agreement'] = 'عرض شروط الانضمام عند التسجيل وطلب الموافقة عليها';
$txt['admin_checkbox_agreement'] = 'Show a checkbox for the agreement in registration form instead of a full page';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'الافتراضي';
$txt['admin_agreement_select_language'] = 'اللغة المراد تعديلها';
$txt['admin_agreement_select_language_change'] = 'تعديل';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'حذف الأعضاء المعلمين';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'إصلاح كافة المنتديات و المواضيع';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Please place one news item per box. BBC tags, such as <span>[b]</span>, <span>[i]</span> and <span>[u]</span> are allowed in your news, as well as smileys. Clear a news item\'s text box to remove it.';
$txt['administrators'] = 'مشرفو المنتدى';
$txt['admin_reserved_desc'] = 'الأسماء المحجوزة تحول دون تسجيل الأعضاء بأسماء معينة أو استخدام هذه الكلمات في أسمائهم المعروضة.
اختر الخصائص التي ترغب في استخدامها من الأسفل قبل الإرسال.';
$txt['admin_activation_email'] = 'إرسال بريد التفعيل عند تسجيل الأعضاء الجدد؟';
$txt['admin_match_whole'] = 'مطابقة الاسم كاملاً؟ إن لم تحدد هذا الخيار فسيتم التدقيق خلال الأسماء.';
$txt['admin_match_case'] = 'مراعاة حالة الأحرف؟ إن لم تحدد هذا الخيار فلن يتم النظر إلى حالة الأحرف.';
$txt['admin_check_user'] = 'تحقق من اسم المستخدم';
$txt['admin_check_display'] = 'تحقق من اسم العرض.';
$txt['admin_newsletter_send'] = 'You can email anyone from this page. The email addresses of the selected member groups should appear below, but you may remove or add any email addresses you wish. Be sure that each address is separated in this fashion: \'address1; address2\'.';
$txt['admin_fader_delay'] = 'الوقت بالملي ثانية لعرض كل بند في الأخبار المتلاشية';
$txt['zero_for_no_limit'] = '(0 لعدم وجود حد)';
$txt['zero_to_disable'] = '(0 to disable)';

$txt['admin_backup_fail'] = 'فشلت عملية النسخ الاحتياطي للملف Settings.php - تأكد من أن الملف Settings_bak.php موجود وقابل للكتابة.';
$txt['modSettings_info'] = 'Settings for General features, Karma, Signatures, Likes and much more that control how this forum operates.';
$txt['database_server'] = 'الملقم الذي يحتوي على قاعدة البيانات';
$txt['database_user'] = 'اسم المستخدم لقاعدة البيانات';
$txt['database_password'] = 'كلمة المرور لقاعدة البيانات';
$txt['database_name'] = 'اسم قاعدة البيانات';
$txt['registration_agreement'] = 'اتفاقية التسجيل';
$txt['registration_agreement_desc'] = 'سيتم عرض هذه الاتفاقية عند تسجيل الأعضاء الجدد إذا قمت بتمكين خيار عرض اتفاقية التسجيل في إعدادات المنتدى. المشتركون الجدد يجب أن يوافقوا على الإتفاقية لكي يسمج لهم بالتسجيل في المنتدى.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'بادئة الجداول الخاصة بقاعدة البيانات';
$txt['errors_list'] = 'قائمة بالأخطاء التي حدثت في المنتدى';
$txt['errors_found'] = 'الأخطاء التالية تسبب مشاكل في المنتدى';
$txt['errors_fix'] = 'هل ترغب بالقيام بمحاولة إصلاح لهذه الأخطاء؟';
$txt['errors_do_recount'] = 'تم تصحيح كل الأخطاء و انشأت مساحة حلول فضلا أنقر على الزر أدناه لعرض بعض الإحصائيات الرئيسة.';
$txt['errors_recount_now'] = 'إعادة تعداد الإحصائيات';
$txt['errors_fixing'] = 'جاري إصلاح الأخطاء في المنتدى';
$txt['errors_fixed'] = 'All errors fixed. Please check on any categories, boards, or topics created to decide what to do with them.';
$txt['attachments_avatars'] = 'الملحقات والصور الرمزية';
$txt['attachments_desc'] = 'يمكنك هنا التحكم بالملفات التي تم إلحاقها في المنتدى من قبل الأعضاء (المرفقات)، كما ويمكنك حذف المرفقات من المنتدى بحسب حجمها أو تاريخ إلحاقها. إحصاءات عن المرفقات معروضة في الأسفل.';
$txt['attachment_stats'] = 'إحصائيات الملفات المرفقة';
$txt['attachment_integrity_check'] = 'Attachment integrity check';
$txt['attachment_integrity_check_desc'] = 'هذه الاداة تساعدك فى التأكد من سلامة المرفقات , حيث يتم التأكد من اسماء الملفات المرفقة و أحجامها فى قاعدة البيانات , و يتم إصلاح الأخطاء إن وجدت .';
$txt['attachment_check_now'] = 'إبدأ الفحص الأن';
$txt['attachment_pruning'] = 'حذف المرفقات';
$txt['attachment_pruning_message'] = 'الرسالة التى سوف تظهر فى المشاركة';
$txt['attachment_pruning_warning'] = 'هل أنت متأكد من انك تريد حذف هذا المرفق ?\\nلن يمكنك إسترجاعه مرة اخرى! ';

$txt['attachment_total'] = 'إجمالي المرفقات';
$txt['attachmentdir_size'] = 'الحجم الكلي لجميع مجلدات المرفقات';
$txt['attachmentdir_size_current'] = 'الحجم الكلي لمجلد المرفقات الحالي.';
$txt['attachmentdir_files_current'] = 'جميع الملفات في مجلد المرفقات الحالي.';
$txt['attachment_space'] = 'المساحة الإجمالية المتوفرة';
$txt['attachment_files'] = 'Total files remaining';

$txt['attachment_options'] = 'خيارات الملفات المرفقة';
$txt['attachment_log'] = 'سجل المرفقات';
$txt['attachment_remove_old'] = 'حذف المرفقات الأقدم من %1$s أيام';
$txt['attachment_remove_size'] = 'حذف المرفقات الأكبر من %1$s كيلوبايت';
$txt['attachment_name'] = 'اسم المرفق';
$txt['attachment_file_size'] = 'حجم الملف';
$txt['attachmentdir_size_not_set'] = 'لم يتم ضبط الحد الأقصى لمساحة المجلد';
$txt['attachmentdir_files_not_set'] = 'No directory file limit is currently set';
$txt['attachment_delete_admin'] = '[الملحق حذف بواسطة المشرف]';
$txt['live'] = 'Latest Software Updates';
$txt['remove_all'] = 'تنظيف السجل';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(تفاصيل أكثر)';

$txt['lfyi'] = 'يتعذر عليك الاتصال بملف الأخبار الأخيرة الخاص ب ElkArte';

$txt['manage_calendar'] = 'إدارة التقويم';
$txt['manage_search'] = 'إدارة البحث';
$txt['viewmembers_online'] = 'آخر وقت متصل';

$txt['smileys_manage'] = 'الابتسامات و مجموعة الابتسامات';
$txt['smileys_manage_info'] = 'Install new smiley sets, add smileys to existing sets or manage your message icons.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Install, download and upload Modification packages; check File Permissions and FTP settings.';
$txt['theme_admin'] = 'إدارة القوالب';
$txt['theme_admin_info'] = 'Install new themes, select themes that are available for your users and set or reset theme options.';
$txt['registration_center'] = 'معالجة التسجيل';
$txt['member_center_info'] = 'View the member list, search for members, or manage account approvals and activations.';
$txt['viewmembers_online'] = 'آخر وقت متصل';

$txt['display_name'] = 'الاسم المعروض';
$txt['email_address'] = 'عنوان البريد الإلكترونى';
$txt['ip_address'] = 'IP عنوان';
$txt['member_id'] = 'رقم العضوية';

$txt['unknown'] = 'غير معروف';
$txt['security_wrong'] = 'Administration login attempt!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'بعث على شكل HTML.  (بواسطة هذا يمكنك وضع HTML في البريد.)';
$txt['email_parsed_html'] = 'إضافة &lt;br /&gt;s و &amp;nbsp;s لهذه الرسالة.';
$txt['email_variables'] = 'In this message you can use a few &quot;variables&quot;.<a href="{help_emailmembers}" class="help"> Click here for more information</a>.';
$txt['email_force'] = 'أرسل هذا إلى العضو حتى وان اختار عدم استقبال الإعلانات.';
$txt['email_as_pms'] = 'أرسل هذا إلى هذه المجموعات باستخدام الرسائل الشخصية.';
$txt['email_continue'] = 'استمر';
$txt['email_done'] = 'تمت.';
$txt['email_members_succeeded'] = 'You have successfully sent your newsletter!';

$txt['ban_title'] = 'تحرير قائمة الحظر';
$txt['ban_ip'] = 'IP حضر: (مثال 192.168.12.213 or 128.0.*.*) - مدخل واحد لكل سطر';
$txt['ban_email'] = 'حظر بالبريد: (مثال badguy@somewhere.com) - مدخل واحد لكل سطر';
$txt['ban_username'] = 'حظر باسم المستخدم: (مثال l33tuser) - مدخل واحد لكل سطر';

$txt['ban_errors_detected'] = 'The following error or errors occurred while saving or editing the ban or the trigger';
$txt['ban_description'] = 'Here you can ban troublesome people either by IP, hostname, user name, or email.';
$txt['ban_add_new'] = 'Add new ban';
$txt['ban_banned_entity'] = 'كيان الحظر';
$txt['ban_on_ip'] = 'حظر على IP (مثال 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'حظر على اسم المستضيف (مثال *.mil)';
$txt['ban_on_email'] = 'حظر على البريد (مثال *@badsite.com)';
$txt['ban_on_username'] = 'Ban on User Name';
$txt['ban_notes'] = 'ملاحظات';
$txt['ban_restriction'] = 'تقييد';
$txt['ban_full_ban'] = 'حظر كامل';
$txt['ban_partial_ban'] = 'حظر جزئي';
$txt['ban_cannot_post'] = 'لا يمكن&nbsp;الكتابة';
$txt['ban_cannot_register'] = 'لا يمكن&nbsp;التسجيل';
$txt['ban_cannot_login'] = 'لا يمكنك الدخول';
$txt['ban_add'] = 'اضافة';
$txt['ban_edit_list'] = 'تحرير قائمة الحظر';
$txt['ban_type'] = 'نوع الحظر';
$txt['ban_days'] = 'أيام';
$txt['ban_will_expire_within'] = 'الحضر سينتهي في';
$txt['ban_added'] = 'تمت الاضافة';
$txt['ban_expires'] = 'انتهى صلاحيته';
$txt['ban_hits'] = 'ضربات';
$txt['ban_actions'] = 'إجراءات';
$txt['ban_expiration'] = 'انتهاء الصلاحية';
$txt['ban_reason_desc'] = 'سبب الحظر ، لكي يعرض للأعضاء المحظورين.';
$txt['ban_notes_desc'] = 'ملاحظات لكي تساعد الأعضاء ذوي الاختصاص.';
$txt['ban_remove_selected'] = 'حذف المعلم';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'هل أنت متأكد من أنك تريد حذف الـ bans?';
$txt['ban_modify'] = 'تعديل';
$txt['ban_name'] = 'حظر اسم';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'تعديل الحظر';
$txt['ban_add_notes'] = '<b>ملاحظة</b>: بعد إنشاء الحظر , يمكنك إضافة مدخلات إضافية لتفعيل الحظر, مثل عنوان الـ IP, اسم المستضيف و عنوان الايميل.';
$txt['ban_expired'] = 'انتهت صلاحيته او تم تعطيله';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'لم يحدد أية قيود.';

$txt['ban_triggers'] = 'مفعلات';
$txt['ban_add_trigger'] = 'إضافة مفعل حظر';
$txt['ban_add_trigger_submit'] = 'اضافة';
$txt['ban_edit_trigger'] = 'تعديل';
$txt['ban_edit_trigger_title'] = 'تعديل مفعل الحظر';
$txt['ban_edit_trigger_submit'] = 'تعديل';
$txt['ban_remove_selected_triggers'] = 'حذف المفعلات المختارة';
$txt['ban_no_entries'] = 'لا يوجد حاليا أى مدخلات فى سجل الحظر .';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'هل أنت متأكد منن أنك تريد إزالة مفعلات الحظر المختارة?';
$txt['ban_trigger_browse'] = 'عرض مفعلات الحظر';
$txt['ban_trigger_browse_description'] = 'This screen shows all banned entities grouped by IP address, hostname, email address and user name.';

$txt['ban_log'] = 'سجل الحظر';
$txt['ban_log_description'] = 'سجل الحظر يعرض كافة المحاولات للدخول للمنتدى من قبل الأعضاء المحظورين (\'كليا\' و \'لا يستطيع التسجيل\').';
$txt['ban_log_no_entries'] = 'لا يوجد مدخلات في سجل الحظر.';
$txt['ban_log_ip'] = 'عنوان IP';
$txt['ban_log_email'] = 'عنوان البريد';
$txt['ban_log_member'] = 'العضو';
$txt['ban_log_date'] = 'تاريخ';
$txt['ban_log_remove_all'] = 'تنظيف السجل';
$txt['ban_log_remove_all_confirm'] = 'هل ترغب في حذف كافة مدخلات سجل الحظر؟';
$txt['ban_log_remove_selected'] = 'حذف المعلم';
$txt['ban_log_remove_selected_confirm'] = 'هل ترغب في حذف كافة مدخلات سجل الحظر المعلم عليها؟';
$txt['ban_no_triggers'] = 'لا يوجد مفعلات حظر حالياً .';

$txt['settings_not_writable'] = 'هذه الخيارات لا يمكن تغيرها لان ملف Settings.php في وضع القراءة فقط.';

$txt['maintain_title'] = 'صيانة المنتدى';
$txt['maintain_info'] = 'Basic forum backups, Database error checking, Clearing the Cache, Integration Hooks and more.';
$txt['maintain_sub_database'] = 'قاعدة المعطيات';
$txt['maintain_sub_routine'] = 'متكرر';
$txt['maintain_sub_members'] = 'تحكم الأعضاء';
$txt['maintain_sub_topics'] = 'المواضيع';
$txt['maintain_sub_attachments'] = 'الملحقات';
$txt['maintain_done'] = 'عملية الصيانة \'%1$s\'  تمت بنجاح.';
$txt['maintain_fail'] = ' مهمة الصيانة \'%1$s\' فشلت.';
$txt['maintain_no_errors'] = 'Congratulations, no errors were found.  Thanks for checking.';

$txt['maintain_tasks'] = 'المهمات المجدولة';
$txt['maintain_tasks_desc'] = 'Manage all the scheduled tasks.';

$txt['scheduled_log'] = 'سجل المهمات';
$txt['scheduled_log_desc'] = 'Lists logs of the tasks that were run.';
$txt['admin_log'] = ' سجل لوحة التحكم';
$txt['admin_log_desc'] = 'مشاهدة المهام الإدارية التي تم تنفيدها من قبل مدير المنتدى';
$txt['moderation_log'] = 'سجل الاشراف';
$txt['moderation_log_desc'] = 'مشاهدة الأنشطة الإدارية التي تم تنفيذها من قبل المشرفيين في المنتدى';
$txt['badbehavior_log'] = 'Bad Behavior Log';
$txt['badbehavior_log_desc'] = 'Lists requests that were blocked or marked suspicious by bad behavior.  If verbose logging is on all HTTP requests are listed.';
$txt['spider_log_desc'] = 'سجل العناكب الإلكترونية يعرض لك الأنشطة التى تقوم بها العناكب الإلكترونية فى منتداك.';
$txt['pruning_log_desc'] = 'إستخدم هذه الأداة لحذف المدخلات القديمة فى السجلات المختلفة .';

$txt['mailqueue_title'] = 'بريد';

$txt['db_error_send'] = 'بعث بريد في حالة حدوث خطا في فشل الاتصال بـ MySQL';
$txt['db_persist'] = 'استعمل اتصال دائم';
$txt['ssi_db_user'] = 'Database user name to use in SSI mode';
$txt['ssi_db_passwd'] = 'كلمة سر قاعدة المعطيات في وضع SSI';

$txt['default_language'] = 'لغة المنتدى الافتراضية';

$txt['maintenance_subject'] = 'العنوان الذى سوف يتم عرضه :';
$txt['maintenance_message'] = 'الرسالة التى سوف يتم عرضها :';

$txt['errlog_desc'] = 'يتعقب سجل الأخطاء أي خطا يرد في منتداك.  هذه القائمة عبارة عن قائمة زمنية بالأخطاء التي حدثت.  لحذف أي خطا من قاعدة البيانات قم بالتعليم عليه ثم اضغط زر %s في أسفل الصفحة.';
$txt['errlog_no_entries'] = 'لا يوجد حاليا أى مدخلات فى سجل الأخطاء.';

$txt['theme_settings'] = 'إعدادات السمة';
$txt['theme_edit_settings'] = 'Edit this theme\'s settings';
$txt['theme_current_settings'] = 'إعدادات القالب الحالي';

$txt['dvc_your'] = 'إصدارتك';
$txt['dvc_current'] = 'الإصدارة الحالية';
$txt['dvc_sources'] = 'المصادر';
$txt['dvc_admin'] = 'الإدارة';
$txt['dvc_controllers'] = 'Controllers';
$txt['dvc_database'] = 'قاعدة المعطيات';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'النماذج الافتراضية';
$txt['dvc_templates'] = 'النماذج الحالية';
$txt['dvc_languages'] = 'ملفات اللغة';

$txt['smileys_default_set_for_theme'] = 'Select default smiley set for this theme:';
$txt['smileys_no_default'] = 'Use default smiley set';

$txt['censor_test'] = 'اختبار الكلمات المراقبة';
$txt['censor_test_save'] = 'تجربة';
$txt['censor_case'] = 'Ignore case when censoring.';
$txt['censor_whole_words'] = 'Check only whole words.';
$txt['censor_allow'] = 'Allow users to turn off word censoring.';

$txt['admin_confirm_password'] = '(confirm password)';
$txt['admin_incorrect_password'] = 'كلمة السر غير صحيحة';

$txt['date_format'] = 'شكل التاريخ (يوم-شهر-سنة)';
$txt['undefined_gender'] = 'غير محدد';
$txt['age'] = 'عمر المستخدم';
$txt['activation_status'] = 'حالة التنشيط';
$txt['activated'] = 'نُشط';
$txt['not_activated'] = 'لم ينشط';
$txt['is_banned'] = 'Banned';
$txt['primary'] = 'رئيس';
$txt['additional'] = 'إضافي';
$txt['wild_cards_allowed'] = 'الأقنعة * و ? مسموح بها';
$txt['member_part_of_these_membergroups'] = 'Member is part of these member groups';
$txt['membergroups'] = 'Member groups';
$txt['confirm_delete_members'] = 'هل ترغب حقا في حذف الأعضاء المعلم عليهم؟';

$txt['support_credits_title'] = 'Support &amp; Credits';
$txt['support_credits_info'] = 'Support links for most common issues, the relevant forum version information you will be asked for when you request help and a list of contributors to the ElkArte project.';
$txt['support_title'] = 'معلومات الدعم';
$txt['support_versions_current'] = 'Current version';
$txt['support_versions_forum'] = 'This version';
$txt['support_versions_db'] = 'الإصدار %1$s';
$txt['support_versions_server'] = 'إصدارة الملقم';
$txt['support_versions_gd'] = 'GD إصدارة';
$txt['support_versions_imagick'] = 'Imagick version';
$txt['support_versions'] = 'معلومات الإصدارة';
$txt['support_resources'] = 'مصادر دعم';
$txt['support_resources_p1'] = 'Our <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> provides the main documentation for ElkArte. The ElkArte Online Manual has many documents to help answer support questions and explain <a href="%2$s" target="_blank" class="new_win">Features</a>, <a href="%3$s" target="_blank" class="new_win">Settings</a>, <a href="%4$s" target="_blank" class="new_win">Themes</a>, <a href="%5$s" target="_blank" class="new_win">Packages</a>, etc. The Online Manual documents each area of ElkArte thoroughly and should answer most questions quickly.';
$txt['support_resources_p2'] = 'If you can\'t find the answers to your questions in the Documentation Wiki, you may want to search our <a href="%1$s" target="_blank" class="new_win">Support Community</a> or ask for assistance in our support boards. The ElkArte Support Community can be used for <a href="%2$s" target="_blank" class="new_win">support</a>, <a href="%3$s" target="_blank" class="new_win">customization</a>, and many other things such as discussing ElkArte, finding a host, and discussing administrative issues with other forum administrators.';

$txt['latest_updates'] = 'Latest noteworthy updates';
$txt['new_in_1_0_2'] = 'The most significant change in ElkArte 1.0.2 is avatar permission management. Currently each method of setting an avatar is permission-based, requiring the enabling/disabling of each method for each group. With 1.0.2 avatars are simply enabled/disabled by user group, this allows the enabled groups to add an avatar (by all available methods).<br />
The only permission available is a general one to allow members to change or not their avatars. Additionally there is only one setting for maximum width and height of avatars, these values apply to all avatar methods.<br /><br />
Due to the nature of the changes it was not impossible to migrate existing settings to the new format, for that reason you are encouraged to visit the <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Settings</a> page and set the options you prefer.';

$txt['edit_permissions_info'] = 'Use permission settings to manage global and specific board features and what actions that guest, members and moderators can do.';
$txt['membergroups_members'] = 'أعضاء بدون مجموعات';
$txt['membergroups_guests'] = 'ضيوف غير مسجلين';
$txt['membergroups_add_group'] = 'إضافة مجموعة';
$txt['membergroups_permissions'] = 'تعديل تصاريح';

$txt['permitgroups_restrict'] = 'تقييدي';
$txt['permitgroups_standard'] = 'قياسي';
$txt['permitgroups_moderator'] = 'مراقب';
$txt['permitgroups_maintenance'] = 'الصيانة';

$txt['confirm_delete_attachments'] = 'هل ترغب حقا في حذف الملحقات التي تم تعليمها؟';
$txt['attachment_manager_browse_files'] = 'تصفح الملفات';
$txt['attachment_manager_repair'] = 'يحافظ على';
$txt['attachment_manager_avatars'] = 'الصور الشخصية';
$txt['attachment_manager_attachments'] = 'الملحقات';
$txt['attachment_manager_thumbs'] = 'الصور المصغرة';
$txt['attachment_manager_last_active'] = 'آخر نشاط';
$txt['attachment_manager_member'] = 'العضو';
$txt['attachment_manager_avatars_older'] = 'Remove avatars from members not active for more than %1$s days';
$txt['attachment_manager_total_avatars'] = 'Total avatars';

$txt['attachment_manager_avatars_no_entries'] = 'لا يوجد صور شخصية حاليا.';
$txt['attachment_manager_attachments_no_entries'] = 'لا يوجد أى مرفقات حاليا.';
$txt['attachment_manager_thumbs_no_entries'] = 'لا يوجد صور مصغرة حاليا.';

$txt['attachment_manager_settings'] = 'اعدادات المرفقات';
$txt['attachment_manager_avatar_settings'] = 'اعدادات الصور الشخصية';
$txt['attachment_manager_browse'] = 'تصفح الملفات';
$txt['attachment_manager_maintenance'] = 'تعديل الملفات';
$txt['attachmentEnable'] = 'نمط المرفقات';
$txt['attachmentEnable_deactivate'] = 'تعطيل المرفقات';
$txt['attachmentEnable_enable_all'] = 'تفعيل جميع المرفقات';
$txt['attachmentEnable_disable_new'] = 'تعطيل المرفات الجديدة';
$txt['attachmentCheckExtensions'] = 'التحقق من نهايات المرفقات';
$txt['attachmentExtensions'] = 'النهايات المسموح بها';
$txt['attachmentRecodeLineEndings'] = 'إعادة ترميز نهايات السطور فى المرفقات النصية';
$txt['attachmentShowImages'] = 'عرض الصور المرفقة في اسفل الموضوع';
$txt['attachmentUploadDir'] = 'مجلد المرفقات';
$txt['attachmentUploadDir_multiple_configure'] = 'Manage attachment directories';
$txt['attachmentDirSizeLimit'] = 'Max attachment directory space';
$txt['attachmentPostLimit'] = 'Max attachment size per post';
$txt['attachmentSizeLimit'] = 'Max size per attachment';
$txt['attachmentNumPerPostLimit'] = 'Max number of attachments per post';
$txt['attachment_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Image re-encoding is not possible.';
$txt['attachment_postsize_warning'] = 'The current php.ini setting \'post_max_size\' may not support this.';
$txt['attachment_filesize_warning'] = 'The current php.ini setting \'upload_max_filesize\' may not support this.';
$txt['attachment_image_reencode'] = 'Re-encode potentially dangerous image attachments';
$txt['attachment_image_reencode_note'] = '(requires GD module or ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'The extensive security checks can result in a large number of rejected attachments.';
$txt['attachment_image_paranoid'] = 'تنفيذ فحص أمني شامل للصور المرفقة.';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'تعديل حجم الصور عند عرضها اسفل الموضوع';
$txt['attachment_thumb_png'] = 'حفظ الصور المُصغرة بصيغة PNG';
$txt['attachment_thumb_memory'] = 'Adaptive thumbnail memory';
$txt['attachment_thumb_memory_note2'] = 'If the system can not get the memory no thumbnail will be created.';
$txt['attachment_thumb_memory_note1'] = 'Leave this unchecked to always attempt to create a thumbnail';
$txt['attachmentThumbWidth'] = 'thumbnails اكبر عرض لل';
$txt['attachmentThumbHeight'] = 'thumbnails اكبر ارتفاع لل ';
$txt['attachment_thumbnail_settings'] = 'Thumbnail Settings';
$txt['attachment_security_settings'] = 'Attachment security settings';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'غير موجود';
$txt['attach_dir_not_writable'] = 'الكتابة غير مسموحة';
$txt['attach_dir_files_missing'] = 'Files Missing (<a href="{repair_url}">Repair</a>)';
$txt['attach_dir_unused'] = 'غير مستخدم';
$txt['attach_dir_empty'] = 'Empty';
$txt['attach_dir_ok'] = 'موافق';
$txt['attach_dir_basedir'] = 'Base directory';

$txt['attach_dir_desc'] = 'Create new directories or change the current directory below. Directories can be renamed as long as they do not contain a sub-directory. If the new directory is to be created within the forum directory structure, you\'ll just need to type the directory name. To remove a directory, blank the path input field. Directories can not be deleted if they contain either files or sub-directories (shown in brackets next to the file count).';
$txt['attach_dir_base_desc'] = 'You may use the area below to change the current base directory or create a new one. New base directories are also added to the Attachment Directory list. You may also designate an existing directory to be a base directory.';
$txt['attach_dir_save_problem'] = 'Oops, there seems to be a problem.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory. Please do so using a FTP client or your site file manager.';
$txt['attachments_no_write'] = 'This directory has been created but is not writable. Please attempt to do so using a FTP client or your site file manager.';
$txt['attach_dir_reserved'] = 'Unable to add. This directory is a system directory and cannot be used for attachments.';
$txt['attach_dir_duplicate_msg'] = 'Unable to add. This directory already exists.';
$txt['attach_dir_exists_msg'] = 'Unable to move. A directory already exists at that path.';
$txt['attach_dir_base_dupe_msg'] = 'Unable to add. This base directory has already been created.';
$txt['attach_dir_base_no_create'] = 'Unable to create. Please verify the path input or create this directory using an FTP client or site file manager and re-try.';
$txt['attach_dir_no_rename'] = 'Unable to move or rename. Please verify that the path is correct or that this directory does not contain any sub-directories.';
$txt['attach_dir_no_delete'] = 'Is not empty and can not be deleted. Please do so using a FTP client or site file manager.';
$txt['attach_dir_no_remove'] = 'Still contains files or is a base directory and can not be deleted.';
$txt['attach_dir_is_current'] = 'Unable to remove while it is selected as the current directory.';
$txt['attach_dir_is_current_bd'] = 'Unable to remove while it is selected as the current base directory.';
$txt['attach_last_dir'] = 'Last active attachment directory';
$txt['attach_current_dir'] = 'Current attachment directory';
$txt['attach_current'] = 'Current';
$txt['attach_path_manage'] = 'Manage attachment paths';
$txt['attach_directories'] = 'Attachment Directories';
$txt['attach_paths'] = 'Attachment directory paths';
$txt['attach_path'] = 'المسار';
$txt['attach_current_size'] = 'Size (KiB)';
$txt['attach_num_files'] = 'الملفات';
$txt['attach_dir_status'] = 'الحالات';
$txt['attach_add_path'] = 'إضافة مسار جديد';
$txt['attach_path_current_bad'] = 'مسار المرفق غير صحيح!';
$txt['attachmentDirFileLimit'] = 'Maximum number of files per directory';

$txt['attach_base_paths'] = 'Base directory paths';
$txt['attach_num_dirs'] = 'Directories';
$txt['max_image_width'] = 'Max display width of posted or attached images';
$txt['max_image_height'] = 'Max display height of posted or attached images';

$txt['automanage_attachments'] = 'Choose the method for the management of the attachment directories';
$txt['attachments_normal'] = '(Manual) ElkArte default behaviour';
$txt['attachments_auto_years'] = '(Auto) Subdivide by years';
$txt['attachments_auto_months'] = '(Auto) Subdivide by years and months';
$txt['attachments_auto_days'] = '(Auto) Subdivide by years, months and days';
$txt['attachments_auto_16'] = '(Auto) 16 random directories';
$txt['attachments_auto_16x16'] = '(Auto) 16 random directories with 16 random sub-directories';
$txt['attachments_auto_space'] = '(Auto) When either directory space limit is reached';

$txt['use_subdirectories_for_attachments'] = 'Create new directories within a base directory';
$txt['use_subdirectories_for_attachments_note'] = 'Otherwise any new directories will be created within the forum\'s main directory.';
$txt['basedirectory_for_attachments'] = 'Set a base directory for attachments';
$txt['basedirectory_for_attachments_current'] = 'Current base directory';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Please note that the directory is wrong. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">There seems to be a problem with this directory. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';

$txt['attachment_transfer'] = 'Transfer Attachments';
$txt['attachment_transfer_desc'] = 'Transfer files between directories.';
$txt['attachment_transfer_select'] = 'Select directory';
$txt['attachment_transfer_now'] = 'Transfer';
$txt['attachment_transfer_from'] = 'Transfer files from';
$txt['attachment_transfer_auto'] = 'Move them automatically by space or file count';
$txt['attachment_transfer_auto_select'] = 'Select base directory';
$txt['attachment_transfer_to'] = 'Or move them to a specific directory.';
$txt['attachment_transfer_empty'] = 'Move all files from the source directory.';
$txt['attachment_transfer_no_base'] = 'No base directories available.';
$txt['attachment_transfer_forum_root'] = 'Forum root directory.';
$txt['attachment_transfer_no_room'] = 'Directory size or file count limit reached.';
$txt['attachment_transfer_no_find'] = 'No files were found to transfer.';
$txt['attachments_transfered'] = '%1$d files were transferred to %2$s';
$txt['attachments_not_transfered'] = '%1$d files were not transferred.';
$txt['attachment_transfer_no_dir'] = 'Either the source directory or one of the target options were not selected.';
$txt['attachment_transfer_same_dir'] = 'You cannot select the same directory as both the source and target.';
$txt['attachment_transfer_progress'] = 'Please wait. Transfer in progress.';

$txt['avatar_settings'] = 'General avatar settings';
$txt['avatar_default'] = 'Enable a default avatar for all users without their own avatar';
$txt['avatar_directory'] = 'مجلد الصور الشخصية';
$txt['avatar_url'] = 'عنوان الصورة الشخصية';
$txt['avatar_max_width'] = 'Maximum width of avatars in pixels (px)';
$txt['avatar_max_height'] = 'Maximum height of avatars in pixels (px)';
$txt['avatar_action_too_large'] = 'اذا كانت الصورة الشخصية كبيرة جدا...';
$txt['option_refuse'] = 'قم برفضها';
$txt['option_resize'] = 'Let the CSS resize it';
$txt['option_download_and_resize'] = 'Download and resize it (requires GD module or ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Enable use of gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'تحويل الصور المعدلة إلى الإمتداد PNG';
$txt['avatar_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Some avatar features are disabled.';
$txt['avatar_external'] = 'صور شخصية اضافية';
$txt['avatar_external_enabled'] = 'Enable use of external (remote/URL) avatars';
$txt['avatar_upload'] = 'صور شخصية قابلة للتحميل';
$txt['avatar_resize_options'] = 'Server storage options';
$txt['avatar_upload_enabled'] = 'Enable the upload of avatars';
$txt['avatar_server_stored'] = 'صور شخصية مخزنة';
$txt['avatar_stored_enabled'] = 'Enable the selection of server stored avatars';
$txt['profile_set_avatar'] = 'Member groups allowed to select an avatar';
$txt['avatar_select_permission'] = 'تحديد التصاريح لكل مجموعة';
$txt['avatar_download_external'] = 'تنزيل الصور الشخصية على رابط معين';
$txt['custom_avatar_enabled'] = 'رفع الصور الشخصية الى...';
$txt['option_attachment_dir'] = 'مجلد المرفقات';
$txt['option_specified_dir'] = 'مجلد خاص...';
$txt['custom_avatar_dir'] = 'مجلد الرفع';
$txt['custom_avatar_dir_desc'] = 'This should be a valid and writable directory, different than the server-stored directory.';
$txt['custom_avatar_url'] = 'عنوان رفع ملفات';
$txt['custom_avatar_check_empty'] = 'مجلد الصور الشخصية الذى حددته ربما يكون فارغ أو غير صحيح . رجاء التأكد من أن هذه الإعدادات صحيحية .';
$txt['avatar_reencode'] = 'Re-encode potentially dangerous avatars';
$txt['avatar_reencode_note'] = 'تأكد من عمل GD Module';
$txt['avatar_paranoid_warning'] = 'تحذير: تفعيل هذا الخيار قد يؤدي إلى رفض الكثير من الصور الرمزية.';
$txt['avatar_paranoid'] = 'تنفيذ فحص شامل على الصور الرمزية المرفوعة من قبل الأعضاء';

$txt['repair_attachments'] = 'صيانة الملحقات';
$txt['repair_attachments_complete'] = 'انتهاء الصيانة';
$txt['repair_attachments_complete_desc'] = 'تم معالجة كافةالأخطاء المحددة';
$txt['repair_attachments_no_errors'] = 'No errors were found';
$txt['repair_attachments_error_desc'] = 'الأخطاء التالية قد تم إيجادها عند تطبيق الصيانة. اختر الأخطاء التي تريد أن تقوم  بإصلاحها ثم اضغط استمر.';
$txt['repair_attachments_continue'] = 'استمر';
$txt['repair_attachments_cancel'] = 'إلغاء';
$txt['attach_repair_missing_thumbnail_parent'] = 'الصور المصغرة %1$d ليس لها مقابل حيث أنه مفقود';
$txt['attach_repair_parent_missing_thumbnail'] = 'الصور %1$d معلمة على أنها تملك صورة مصغرة لكنها فعليا لا';
$txt['attach_repair_file_missing_on_disk'] = 'المرفقات/الصور الرمزية %1$d لها قيمة لكن لا توجد بشكل فعلي على قرص التخزين';
$txt['attach_repair_file_wrong_size'] = 'المرفقات/الصور الرمزية %1$d تم إرسال تقرير بها على أن حجمها خاطئ';
$txt['attach_repair_file_size_of_zero'] = 'المرفقات/الصور الرمزية %1$d  لها حجم صفري على قرص التخزين. (سوف يتم حذفها)';
$txt['attach_repair_attachment_no_msg'] = 'المرفقات %1$d ليس لها مشاركة مرتبطة معها';
$txt['attach_repair_avatar_no_member'] = 'الصورة الرمزية %1$d ليس لها عضو مقابل';
$txt['attach_repair_wrong_folder'] = '%1$d attachments are in the wrong directory';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d files do not have a corresponding entry in the database. (These will be deleted)';

$txt['news_title'] = 'تحرير الاخبار';
$txt['news_settings_desc'] = 'بامكانك تغيير الاعدادات للاخبار و الرسال البريدية';
$txt['news_mailing_desc'] = 'From this menu you can send messages to all users who\'ve registered and entered their email addresses. You may edit the distribution list, or send messages to all. Useful for important update/news information.';
$txt['news_error_no_news'] = 'Nothing to preview';
$txt['groups_edit_news'] = 'المجموعات المصرح لها بتغيير الاخبار و تحريرها';
$txt['groups_send_mail'] = 'المجموعات المصرح لها بارسال رسائل اعلانية للاعضاء في المنتدى';
$txt['xmlnews_enable'] = 'تفعيل اخبار XML/RSS';
$txt['xmlnews_maxlen'] = 'Maximum message length';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Number of items in a news feed';
$txt['xmlnews_maxlen_note'] = '(0 to disable, bad idea.)';
$txt['editnews_clickadd'] = 'Add another item';
$txt['editnews_remove_selected'] = 'حذف المعلم';
$txt['editnews_remove_confirm'] = 'هل انت متاكد انك تريد حذف الاخبار المختارة؟?';
$txt['censor_clickadd'] = 'Add another word';

$txt['layout_controls'] = 'المنتدى';
$txt['logs'] = 'السجلات';
$txt['generate_reports'] = 'تكوين التقارير';

$txt['update_available'] = 'Update Available';
$txt['update_message'] = 'You\'re using an outdated version of ElkArte, which contains some bugs which have since been fixed.
	It is recommended that you <a href="#" id="update-link">update your forum</a> to the latest version as soon as possible. It only takes a minute!';

$txt['manageposts'] = 'المواضيع و العناوين';
$txt['manageposts_title'] = 'تعديل المواضيع و العناوين';
$txt['manageposts_description'] = 'بامكانك تعديل كل الاعدادات المتعلقة بالعناوين و المواشيع.';

$txt['manageposts_seconds'] = 'ثوان';
$txt['manageposts_minutes'] = 'دقائق';
$txt['manageposts_characters'] = 'احرف';
$txt['manageposts_days'] = 'ايام';
$txt['manageposts_posts'] = 'مشاركات';
$txt['manageposts_topics'] = 'مواضيع';

$txt['pollMode'] = 'تفعيل الإستفتاءات';

$txt['manageposts_settings'] = 'اعدادات المواضيع';
$txt['manageposts_settings_description'] = 'بامكانك تعديل جميع الاعدادات المتعلقة بالمواضيع.';

$txt['manageposts_bbc_settings'] = 'كود النقاط في المنتدى';
$txt['manageposts_bbc_settings_description'] = 'تمكنك أوامر الترميز من تعديل شكل المواضيع في المنتدى، ومثال ذلك لجعل كلمة "بيت" بالخط العريض يمكنك كتابتها كـ [b]بيت[/b]. جميع أوامر الترميز للمنتديات محاطة بالأقواس المربعة (\'[\' و \']\').';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code settings';

$txt['manageposts_topic_settings'] = 'اعدادات المواضيع';
$txt['manageposts_topic_settings_description'] = 'بامكانك تعديل كل ما يتعلق باعدادات المواضيع.';

$txt['managedrafts_settings'] = 'Draft Settings';
$txt['managedrafts_settings_description'] = 'Here you can set all settings involving drafts.';
$txt['manage_drafts'] = 'المسودات';

$txt['mail_center'] = 'Maillist Center';
$txt['mm_emailerror'] = 'Failed Emails';
$txt['mm_emailfilters'] = 'Filters';
$txt['mm_emailparsers'] = 'Parsers';
$txt['mm_emailtemplates'] = 'Templates';
$txt['mm_emailsettings'] = 'الإعدادات';

$txt['removeNestedQuotes'] = 'إلغاء الاقتباسات المتداخلة عند الإرسال';
$txt['enableSpellChecking'] = 'تفعيل التصحيح الاملائي';
$txt['enableSpellChecking_warning'] = 'this does not work on all servers.';
$txt['enableSpellChecking_error'] = 'this does not work on your server.';
$txt['enableVideoEmbeding'] = 'Enable auto-embedding of video links.';
$txt['enableCodePrettify'] = 'Enable prettifying of code tags';
$txt['max_messageLength'] = 'اكبر حجم للموضوع';
$txt['max_messageLength_zero'] = '0 لغير محدد.';
$txt['convert_to_mediumtext'] = 'Your database is not setup to accept messages longer than 65535 characters. Please use the <a href="%1$s">database maintenance</a> page to convert the database and then come back to increase the maximum allowed post size.';
$txt['topicSummaryPosts'] = 'المواضيع التي ستظهر في الملخص';
$txt['spamWaitTime'] = 'الزمن المسموح لارسال المشاركات من نفس الاي بي';
$txt['edit_wait_time'] = 'وقت الانتظار';
$txt['edit_disable_time'] = 'الوقت الأعظمي بعد إرسال المشاركة للسماح بالتعديل';
$txt['edit_disable_time_zero'] = '0 للتعطيل';
$txt['preview_characters'] = 'Maximum length of last/first post preview';
$txt['preview_characters_units'] = 'احرف';
$txt['preview_characters_zero'] = '0 to show the entire message';
$txt['message_index_preview'] = 'Show post previews on the message index';
$txt['message_index_preview_off'] = 'Do not show the previews';
$txt['message_index_preview_first'] = 'Show the text of the first post';
$txt['message_index_preview_last'] = 'Show the text of the last post';

$txt['enableBBC'] = 'تفعيل bulletin board code (BBC)';
$txt['enablePostHTML'] = 'تفعيل رموز الـ HTML <i>الأساسي</i> في المشاركات';
$txt['autoLinkUrls'] = 'تحويل عناوين المواقع الى لينكات بشكل تلقائي';
$txt['disabledBBC'] = 'تفعيل BBC tags';
$txt['bbcTagsToUse'] = 'تفعيل BBC tags';
$txt['bbcTagsToUse_select'] = 'اختيار العلامات المسموحة للاستخدام';
$txt['bbcTagsToUse_select_all'] = 'اختيار جميع العلامات';

$txt['enableParticipation'] = 'تفعيل ايقونات المشاركة';
$txt['enableFollowup'] = 'Enable followups';
$txt['enable_unwatch'] = 'Enable unwatching of topics';
$txt['oldTopicDays'] = 'الزمن المحدد للمشاركة قبل تعليم الموضوع كقديم على المشاركات';
$txt['oldTopicDays_zero'] = '0 للتعطيل';
$txt['defaultMaxTopics'] = 'عدد المواضيع في الصفحة الواحدة';
$txt['defaultMaxMessages'] = 'عدد المشاركات في الصفحة في الموضوع الواحد';
$txt['disable_print_topic'] = 'Disable print topic feature';
$txt['hotTopicPosts'] = 'عدد المشاركات في الصفحة في المواضيع الساخنة';
$txt['hotTopicVeryPosts'] = 'عدد المشاركات في المواضيع الساخنة جدا';
$txt['useLikesNotViews'] = 'Use number of likes in place of posts to define hot topics';
$txt['enableAllMessages'] = 'أكبر حجم للموضوع لعرض &quot;كل&quot; المشاركات';
$txt['enableAllMessages_zero'] = '0 لعدم عرض &quot;الكل&quot;';
$txt['disableCustomPerPage'] = 'تعطيل  تخصيص المستخدم لعدد موضوع/مشاركة لكل صفحة';
$txt['enablePreviousNext'] = 'تفعيل وصلات قبل و بعد في المواضيع';

$txt['not_done_title'] = 'Not done yet';
$txt['not_done_reason'] = 'لتجنب تحميل الزائد للسيرفر, العملية ستتم على مراحل. سوف تبدأ المرحلة التالية بعد ثوان قليلة. في حال عدم حدوث ذلك اضغط على زر استمر الموجود في الأسفل.';
$txt['not_done_continue'] = 'استمر';

$txt['general_settings'] = 'عام';
$txt['database_paths_settings'] = 'قاعدة البيانات و المسارات';
$txt['cookies_sessions_settings'] = 'السكاكر و الدورات';
$txt['caching_settings'] = 'تخزين في الكاش';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Local Settings';
$txt['phpinfo_defaultsettings'] = 'Default Settings';
$txt['phpinfo_itemsettings'] = 'الإعدادات';

$txt['language_configuration'] = 'اللغات';
$txt['language_description'] = 'هنا يمكنك تعديل اللغات المثبته فى المنتدى الخاص بك ,او تحميل لغة جديده من  موقع ElkArte . يمكنك أيضا تعديل الإعدادات المتعلقة باللغات هنا .';
$txt['language_edit'] = 'تعديل اللغات';
$txt['language_add'] = 'إضافة لغه';
$txt['language_settings'] = 'الإعدادات';

$txt['advanced'] = 'متقدم';
$txt['simple'] = 'بسيط';

$txt['admin_news_select_recipients'] = 'أرجو اختيار من يجب أن يحصل على نسخة من البريد الإخباري';
$txt['admin_news_select_group'] = 'Member groups';
$txt['admin_news_select_group_desc'] = 'اختر المجموعات التي سيصلها البريد الإخباري.';
$txt['admin_news_select_members'] = 'تحكم الأعضاء';
$txt['admin_news_select_members_desc'] = 'Additional members to receive the newsletter.';
$txt['admin_news_select_excluded_members'] = 'الأعضاء المستثنين';
$txt['admin_news_select_excluded_members_desc'] = 'Members who should not receive the newsletter.';
$txt['admin_news_select_excluded_groups'] = 'المجموعات المستثنية';
$txt['admin_news_select_excluded_groups_desc'] = 'حدد المجموعات التي لا يجب أن يصلها بريد إخباري.';
$txt['admin_news_select_email'] = 'عناوين الايميل';
$txt['admin_news_select_email_desc'] = 'A semi-colon separated list of email addresses which should be sent this newsletter. (i.e. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Override notification settings';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'لا يمكنك إرسال رسائل خاصة للايميل. في حال استمريت فإن كل الايميلات المدخلة سيتم تجاهلها.\\n\\nهل أنت متأكد من أنك تريد فعل ذلك?';

$txt['mailqueue_browse'] = 'استعراض الصف';
$txt['mailqueue_settings'] = 'الإعدادات';

$txt['admin_search'] = 'بحث سريع';
$txt['admin_search_type_internal'] = 'وظيفة/خيارات';
$txt['admin_search_type_member'] = 'العضو';
$txt['admin_search_type_online'] = 'دليل الاستخدام أونلاين';
$txt['admin_search_go'] = 'اذهب';
$txt['admin_search_results'] = 'نتائج البحث';
$txt['admin_search_results_desc'] = 'نتائج البحث: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'البحث مرة أخرى';
$txt['admin_search_results_none'] = 'No results found.';

$txt['admin_search_section_sections'] = 'قسم';
$txt['admin_search_section_settings'] = 'إعدادات';

$txt['core_settings_title'] = 'الخصائص المركزية';
$txt['core_settings_desc'] = 'This page allows you to turn on or off optional features of your forum.';
$txt['mods_cat_features'] = 'عام';
$txt['mods_cat_security_general'] = 'عام';
$txt['antispam_title'] = 'مكافحة السبام';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'اخرى';
$txt['mods_cat_layout'] = 'التوزيع';
$txt['karma'] = 'الشعبية';
$txt['moderation_settings_short'] = 'الإشراف';
$txt['signature_settings_short'] = 'التوقيع';
$txt['custom_profile_shorttitle'] = 'خيارات الحساب';
$txt['pruning_title'] = 'تنظيف السجل';

$txt['core_settings_activation_message'] = 'The feature {core_feature} has been activated, click on the title to configure it';
$txt['core_settings_deactivation_message'] = 'The feature {core_feature} has been deactivated';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'تعديل المنتديات';
$txt['mboards_new_cat'] = 'Create new category';
$txt['manage_holidays'] = 'إدارة أيام العطل';
$txt['calendar_settings'] = 'إعدادات التقويم';
$txt['search_weights'] = 'الأوزان';
$txt['search_method'] = 'طريقة البحث';
$txt['search_sphinx'] = 'Configure Sphinx';

$txt['smiley_sets'] = 'مجموعات الابتسامات';
$txt['smileys_add'] = 'إضافة ابتسامة';
$txt['smileys_edit'] = 'تعديل الابتسامات';
$txt['smileys_set_order'] = 'Set Smiley order';
$txt['icons_edit_message_icons'] = 'Edit message icons';

$txt['membergroups_new_group'] = 'Add Member Group';
$txt['membergroups_edit_groups'] = 'Edit Member Groups';
$txt['permissions_groups'] = 'التصاريح عن طريق المجموعات';
$txt['permissions_boards'] = 'التصاريح عن طريق المنتديات';
$txt['permissions_profiles'] = 'تحرير الملفات الشخصية';
$txt['permissions_post_moderation'] = 'مراقبة المواضيع';

$txt['browse_packages'] = 'استعراض الرزم';
$txt['download_packages'] = 'تثبيت الرزم';
$txt['upload_packages'] = 'Upload Package';
$txt['installed_packages'] = 'الرزم المثبتة';
$txt['package_file_perms'] = 'صلاحيات الملفات';
$txt['package_settings'] = 'الإعدادات';
$txt['package_servers'] = 'Package Servers';
$txt['themeadmin_admin_title'] = 'إدارة و تثبيت';
$txt['themeadmin_list_title'] = 'إعدادات السمة';
$txt['themeadmin_reset_title'] = 'خيارات العضو';
$txt['themeadmin_edit_title'] = 'تعديل السمة (القالب)';
$txt['admin_browse_register_new'] = 'Register new member';

$txt['search_engines'] = 'محركات البحث';
$txt['spider_logs'] = 'Logs';
$txt['spider_stats'] = 'الإحصاءات';

$txt['paid_subscriptions'] = 'اشتراكات مدفوعة';
$txt['paid_subs_view'] = 'مشاهدة الإشتراكات';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks';
$txt['hooks_field_hook_name'] = 'Hook Name';
$txt['hooks_field_function_name'] = 'Function Name';
$txt['hooks_field_function'] = 'Function';
$txt['hooks_field_included_file'] = 'Included file';
$txt['hooks_field_file_name'] = 'اسم الملف';
$txt['hooks_field_hook_exists'] = 'الحالات';
$txt['hooks_active'] = 'Exists';
$txt['hooks_disabled'] = 'تعطيل'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Not found';
$txt['hooks_no_hooks'] = 'There are currently no hooks in the system.';
$txt['hooks_disable_legend'] = 'اسطورة';
$txt['hooks_disable_legend_exists'] = 'the hook exists and is active';
$txt['hooks_disable_legend_disabled'] = 'the hook exists but has been disabled';
$txt['hooks_disable_legend_missing'] = 'the hook has not been found';
$txt['hooks_reset_filter'] = 'Reset filter';

$txt['board_perms_allow'] = 'السماح';
$txt['board_perms_ignore'] = 'تجاهل';
$txt['board_perms_deny'] = 'منع';
$txt['all_boards_in_cat'] = 'All boards in this category';

$txt['url'] = 'الرابط الاكتروني';
$txt['words_sep'] = 'Words separator';

$txt['admin_order_title'] = 'Ordering Error';
$txt['admin_order_error'] = 'An unknown error occurred while processing your request';

// Known controllers that can work on the front page
$txt['default'] = 'الافتراضي';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
