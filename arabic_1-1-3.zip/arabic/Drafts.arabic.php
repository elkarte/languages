<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'عرض المسودات';
$txt['drafts_show_desc'] = 'في هذا القسم يتم عرض كل المسودات التي قمت بحفظها . هنا يمكنك تحريرها والتعديل عليها قبل الارسال ، أو يمكنك أن تقوم بحذفها';

// misc
$txt['drafts'] = 'المسودات';
$txt['draft_save'] = 'حفظ المسودة';
$txt['draft_save_note'] = 'سيتم حفظ نص المشاركة ، ولكن لن يتم حفظ المرفقات ، ولا التصويت ولا معلومات الاحداث';
$txt['draft_none'] = 'لا يوجد لديك أي مسودات';
$txt['draft_edit'] = 'تحرير المسودة';
$txt['draft_load'] = 'تحميل المسودات';
$txt['draft_hide'] = 'اخفاء المسودات';
$txt['draft_delete'] = 'حذف المسودة';
$txt['draft_days_ago'] = 'منذ %s يوم';
$txt['draft_retain'] = 'سيتم الاحتفاظ بها لمدة %s ايام اضافية';
$txt['draft_remove'] = 'ازالة هذه المسودة';
$txt['draft_remove_selected'] = 'ازالة كل المسودات المحددة؟';
$txt['draft_saved'] = 'تم الحفظ كـ مسودة ويمكن الوصول اليها في <a href="%1$s">عرض قسم المسودات</a> في ملفك الشخصي';
$txt['draft_pm_saved'] = 'تم الحفظ كـ مسودة ويمكن الوصول اليها في <a href="%1$s">عرض قسم المسودات</a> في مركز الرسائل الشخصية';

// Admin options
$txt['drafts_autosave_enabled'] = 'تفعيل الحفظ التلقائي للمسودات';
$txt['drafts_autosave_enabled_subnote'] = 'سيتم تكرار الحفظ التلقائي لمسودات المستخدم في الخلفية بمعدل يتم تحديده. كما لابد من توافر الصلاحيات المناسبة للعضو';
$txt['drafts_keep_days'] = 'أعلى عدد من الايام للاحتفاظ بمسودة';
$txt['drafts_keep_days_subnote'] = 'ادخل القيمة 0 للاحتفاظ بالمسودات الى اجل غير مسمى';
$txt['drafts_autosave_frequency'] = 'معدل الحفظ التلقائي للمسودات';
$txt['drafts_autosave_frequency_subnote'] = 'اقل قيمة مسموح بها هي 30 ثانية';
$txt['drafts_pm_enabled'] = 'تمكين الحفظ لمسودات الرسائل الشخصية';
$txt['drafts_post_enabled'] = 'تمكين الحفظ لمسودات المشاركات';
$txt['drafts_none'] = 'بدون عنوان';
$txt['drafts_saved'] = 'تم حفظ المسودة بنجاح';