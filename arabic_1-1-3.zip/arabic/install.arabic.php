<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'مرحبا بك';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'التحقق من قابلية الكتابة';
$txt['install_step_forum'] = 'الإعدادات الأساسية';
$txt['install_step_databaseset'] = 'إعدادات قاعدة البيانات';
$txt['install_step_databasechange'] = 'تطوير قاعدة البيانات';
$txt['install_step_admin'] = 'حساب المدير';
$txt['install_step_delete'] = 'Finalize Installation';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'اللغة';
$txt['installer_language_set'] = 'مجموعة';
$txt['congratulations'] = 'تهانينا ، تمت عملية التثبيت بنجاح';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'مُجلد التثبيت لا زال قابل للكتابة.  من المُستحسن أن تقوم بتغير تصاريح المجلد بحيث يُصبح غير قابل للكاتبة كناحية أمنية.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(لا تعمل على جميع السيرفرات.)</em>';
$txt['go_to_your_forum'] = 'يمكنك الآن مشاهدة <a href="%1$s">منتداك الجديد</a> و البدء في استخدامه.  تأكد من تسجيل الدخول أولا بحيث تستطيع الوصول إلى مركز الإدارة .';
$txt['good_luck'] = 'Thanks for installing ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'مرحبا بك';
$txt['install_welcome_desc'] = 'Welcome to ElkArte. This script will guide you through the process for installing %1$s. We\'ll gather a few details about your forum over the next few steps, and after a couple of minutes your forum will be ready for use.';
$txt['install_all_lovely'] = 'لقد قمنا بعمل فحص سريع على المُستَضيف الخاص بك و كل شيئ يبدو جيدا . الأن إضغط على زر &quot;إستمرار&quot; لكى تبدأ. ';

$txt['user_refresh_install'] = 'تم إعادة تحديث المنتدى';
$txt['user_refresh_install_desc'] = 'خلال التثبيت, وجد برنامج التثبيت (مع التفاصيل التي ادخلتها) أن جدول أو أكثر مطلوب إنشائه موجود مسبقا.<br />أية جداول مفقودة في تثبيتك تم إعادة إنشائها باستخدام البيانات الإفتراضية, ولكن لم يتم مسح البيانات من أي جداول موجودة.';

$txt['default_topic_subject'] = 'Welcome to ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'نقاش عام';
$txt['default_board_description'] = 'شاركنا في أي موضوع تحب أن تناقشه.';
$txt['default_category_name'] = 'التصنيف العام';
$txt['default_time_format'] = '%B %d, %Y, %I:%M:%S %p';
$txt['default_news'] = 'ElkArte - Just Installed!';
$txt['default_karmaLabel'] = 'الشعبية:';
$txt['default_karmaSmiteLabel'] = '[-1]';
$txt['default_karmaApplaudLabel'] = '[+1]';
$txt['default_reserved_names'] = 'مُدير\\nصاحب الموقع\\nزائر\\nroot\\n';
$txt['default_smileyset_name'] = 'Fugue\'s Set';
$txt['default_theme_name'] = 'ElkArte Default Theme';

$txt['default_administrator_group'] = 'المُدير';
$txt['default_global_moderator_group'] = 'مُشرف عام';
$txt['default_moderator_group'] = 'مراقب';
$txt['default_newbie_group'] = 'عضو جديد';
$txt['default_junior_group'] = 'عضو مشارك';
$txt['default_full_group'] = 'عضو فعال';
$txt['default_senior_group'] = 'عضو نشيط';
$txt['default_hero_group'] = 'عضو مميز';

$txt['default_smiley_smiley'] = 'مبتسم';
$txt['default_wink_smiley'] = 'يغمز';
$txt['default_cheesy_smiley'] = 'فرح';
$txt['default_grin_smiley'] = 'تكشيرة';
$txt['default_angry_smiley'] = 'غضبان';
$txt['default_sad_smiley'] = 'حزين';
$txt['default_shocked_smiley'] = 'مذهول';
$txt['default_cool_smiley'] = 'هادئ';
$txt['default_huh_smiley'] = 'نعم?';
$txt['default_roll_eyes_smiley'] = 'أعين متقلبة';
$txt['default_tongue_smiley'] = 'لسان';
$txt['default_embarrassed_smiley'] = 'خجول';
$txt['default_lips_sealed_smiley'] = 'مُقفل الشفتين';
$txt['default_undecided_smiley'] = 'متردد';
$txt['default_kiss_smiley'] = 'قبلة';
$txt['default_cry_smiley'] = 'باكي';
$txt['default_evil_smiley'] = 'شرير';
$txt['default_azn_smiley'] = 'Azn ';
$txt['default_afro_smiley'] = 'افريقي';
$txt['default_laugh_smiley'] = 'ضاحك';
$txt['default_police_smiley'] = 'شرطى';
$txt['default_angel_smiley'] = 'ملاك';

$txt['error_message_click'] = 'انقر هنا';
$txt['error_message_try_again'] = 'لمحاولة تنفيذ هذه الخطوة ثانية.';
$txt['error_message_bad_try_again'] = 'لمحاولة التثبيت على أية حال, ولكن تذكر بان هذا <em>غير مستحسن</em> ابدأ.';

$txt['install_settings'] = 'الإعدادات الأساسية';
$txt['install_settings_info'] = 'This page requires you to define a few key settings for your forum. ElkArte has automatically detected key settings for you.';
$txt['install_settings_name'] = 'اسم المنتدى';
$txt['install_settings_name_info'] = 'This is the name of your forum, e.g. &quot;The Testing Forum&quot;.';
$txt['install_settings_name_default'] = 'منتداي';
$txt['install_settings_url'] = 'رابط المنتدى';
$txt['install_settings_url_info'] = 'هذا هو عنوان URL للوصول إلى منتداك <strong>من دون وضع العلامة التالية في النهاية \'/\'!</strong>.<br />في أغلب الأوقات القيمة الافتراضية في هذا الصندوق لا تحتاج إلى أي تعديل.';
$txt['install_settings_compress'] = 'مُخرجات Gzip';
$txt['install_settings_compress_title'] = 'ضغط المخرجات من أجل التوفير في عرض حزمة البيانات.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'This function does not work properly on all servers, but can save you a lot of bandwidth.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Click here to test it</a>. (it should just say "PASS".)';
$txt['install_settings_dbsession'] = 'جلسات قاعدة البيانات';
$txt['install_settings_dbsession_title'] = 'استخدم قاعدة البيانات لحفظ الجلسات بدلا من الملفات.';
$txt['install_settings_dbsession_info1'] = 'هذه الميزة مُستحسنة دائما، لأنها تجعل الجلسات أكثر استقلالية.';
$txt['install_settings_dbsession_info2'] = 'يبدو أن هذه الميزة قد لا تعمل مع المُستَضيف الخاص بك ، ولكن حاول تجربتها على أية حال.';
$txt['install_settings_proceed'] = 'إستمرار';

$txt['db_settings'] = 'إعدادات قاعدة بيانات المُستضيف';
$txt['db_settings_info'] = 'هذه هي الإعدادات التي يستخدمها المُستضيف لقاعدة بياناتك. في حالة إذا كنت لا تعرف القيم المناسبة, يجب عليك سؤال مدير الإستضافه الخاص بك ما هي هذه المعلومات.';
$txt['db_settings_type'] = 'نمط قاعدة البيانات';
$txt['db_settings_type_info'] = 'Multiple supported database types were detected - which one do you wish to use?';
$txt['db_settings_server'] = 'اسم المُستضيف';
$txt['db_settings_server_info'] = 'يكون عادة localhost - لذلك في حال لا تعرف ما هو الخيار الصحيح, جرب localhost.';
$txt['db_settings_port'] = 'المنفذ';
$txt['db_settings_port_info'] = 'Leave empty if your server is listening on the default port, or you are uncertain.';
$txt['db_settings_username'] = 'User name';
$txt['db_settings_username_info'] = 'Fill in the user name you need to connect to your database here.<br />If you don\'t know what it is, try the user name of your FTP account, most of the time they are the same.';
$txt['db_settings_password'] = 'كلمة المرور';
$txt['db_settings_password_info'] = 'Here you should put the password you need to connect to your database.<br />If you don\'t know this, you should try the password to your FTP account.';
$txt['db_settings_database'] = 'اسم قاعدة بياناتك';
$txt['db_settings_database_info'] = 'Fill in the name of the database you want to use for ElkArte to store its data in.';
$txt['db_settings_database_info_note'] = 'إذا كانت قاعدة البيانات هذه غير موجودة , فسوف نحاول إنشائها .';
$txt['db_settings_database_file'] = 'Database file name';
$txt['db_settings_database_file_info'] = 'This is the name of the file in which to store the ElkArte data. We recommend you use the randomly generated name for this and set the path of this file to be outside of the public area of your webserver.';
$txt['db_settings_prefix'] = 'بادئة الجداول';
$txt['db_settings_prefix_info'] = 'هذه البادئة سوف يتم استخدامه ضمن كل جدول في قاعدة بياناتك.  <strong>لا تقم بتثبيت منتديين بنفس البادئة!</strong><br />هذه القيمة تسمح بعدة نسخ من المنتدى ضمن قاعدة بيانات واحدة.';
$txt['db_populate'] = 'قاعدة البيانات جاهزة';
$txt['db_populate_info'] = 'تم حفظ إعداداتك و قاعدة بياناتك الان أصبحت جاهزة بكل البيانات التى تحتاجها لكى يعمل منتداك بشكل جيد . ملخص : ';
$txt['db_populate_info2'] = 'إضغط &quot;إستمرار&quot; لكى تذهب الى صفحة تهيئة حساب المدير. ';
$txt['db_populate_inserts'] = 'تم إضافة %1$d صف.
';
$txt['db_populate_tables'] = 'تم إنشاء %1$d جدول.';
$txt['db_populate_insert_dups'] = 'تم تجاهل %1$d صف مكرر.';
$txt['db_populate_table_dups'] = 'تم تجاهل %1$d جدول مكرر.';

$txt['user_settings'] = 'إنشاء حسابك';
$txt['user_settings_info'] = 'سيتم إنشاء حساب المدير الخاص بك الأن.';
$txt['user_settings_username'] = 'Your user name';
$txt['user_settings_username_info'] = 'Choose the name you want to login with.';
$txt['user_settings_password'] = 'كلمة المرور';
$txt['user_settings_password_info'] = 'اكتب كلمة المرور الخاصة بك و تذكرها جيدا!';
$txt['user_settings_again'] = 'كلمة المرور';
$txt['user_settings_again_info'] = '(فقط للتأكيد.)';
$txt['user_settings_email'] = 'عنوان البريد الإلكترونى';
$txt['user_settings_email_info'] = 'اكتب عنوانك البريدي.  <strong>يجب أن يكون عنوانا صحيحا.</strong>';
$txt['user_settings_database'] = 'كلمة المرور لقاعدة البيانات';
$txt['user_settings_database_info'] = 'تحتاج إلى كتابة كلمة المرور لقاعدة البيانات لإنشاء حساب المدير ، لأغراض أمنية.';
$txt['user_settings_skip'] = 'تخطي';
$txt['user_settings_skip_sure'] = 'هل أنت متأكد من أنك تريد تجاهل الخطوه الخاصه بإنشاء حساب المدير ؟';
$txt['user_settings_proceed'] = 'انتهى';

$txt['ftp_checking_writable'] = 'Checking if files are writable';
$txt['ftp_setup'] = 'معلومات الاتصال بـ FTP';
$txt['ftp_setup_info'] = 'يمكن الاتصال بواسطة FTP لإصلاح الملفات التي من المفترض أنها قابلة للكتابة و هي ليست كذلك.  إذا لم ينجح هذا, فسيتوجب عليك فعل ذلك يدويا.  لاحظ أن هذه العملية لا تدعم SSL حاليا.';
$txt['ftp_server'] = 'الخادم';
$txt['ftp_server_info'] = 'This should be the server address and port for your FTP server.';
$txt['ftp_port'] = 'المنفذ';
$txt['ftp_username'] = 'User name';
$txt['ftp_username_info'] = 'The user name to login with. <em>This will not be saved anywhere.</em>';
$txt['ftp_password'] = 'كلمة المرور';
$txt['ftp_password_info'] = 'كلمة المرور التي تسجل الدخول بواسطتها. <em>لن يتم حفظها مطلقا.</em>';
$txt['ftp_path'] = 'مسار التثبيت';
$txt['ftp_path_info'] = 'هذا هو المسار <em>التقريبي</em> الذي تستخدمه في ملقم FTP .';
$txt['ftp_path_found_info'] = 'المسار الموجود ضمن الصندوق قد تم تحديده بشكل آلي.';
$txt['ftp_connect'] = 'اتصال';
$txt['ftp_setup_why'] = 'لماذا هذه الخطوة؟';
$txt['ftp_setup_why_info'] = 'Some files need to be writable for ElkArte to work properly.  This step allows you to let the installer make them writable for you.  However, in some cases it won\'t work - in that case, please make the following files 777 (writable, 755 on some hosts):';
$txt['ftp_setup_again'] = 'لتجربة إذا كانت هذه الملفات قابلة للكتابة مرة أخرى.';

$txt['error_php_too_low'] = 'Warning!  You do not appear to have a version of PHP installed on your webserver that meets ElkArte\'s <strong>minimum installations requirements</strong>.<br />If you are not the host, you will need to ask your host to upgrade, or use a different host - otherwise, please upgrade PHP to a recent version.<br /><br />If you know for a fact that your PHP version is high enough you may continue, although this is strongly discouraged.';
$txt['error_missing_files'] = 'لا يمكن العثور على الملفات الضرورية للتثبيت في مجلد هذا البرنامج!<br /><br />الرجاء التأكد من انك قمت بتحميل ملفات المنتدى كاملا, بما فيها ملف sql , ثم اعد المحاولة.';
$txt['error_session_save_path'] = 'الرجاء إبلاغ مستضيفك بأن <strong>session.save_path المحددة في php.ini</strong> ليست صحيحة!  يجب أن تغير إلى مجلد <strong>موجود</strong>, و يكون <strong>قابل للكتابة</strong> من قبل المستخدم الذي يستخدم PHP .<br />';
$txt['error_windows_chmod'] = 'You\'re on a windows server, and some crucial files are not writable.  Please ask your host to give <strong>write permissions</strong> to the user PHP is running under for the files in your ElkArte installation.  The following files or directories need to be writable:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'لا يمكن الاتصال بملقم FTP بواسطة البيانات المزودة.';
$txt['error_db_file'] = 'لا يمكن إيجاد مصدر قاعدة البيانات للبرنامج ! نرجو مراجعة الملف %1$s و التأكد من أنه موجود ضمن مجلد source ضمن مجلد المنتدى.';
$txt['error_db_connect'] = 'لا يمكن الاتصال بسيرفر قاعدة البيانات مع البيانات التي أدخلتها.<br /><br />في حال لم تكن متأكدا ماذا يجب عليك أن تكتب, اتصل بدعم المضيف.';
$txt['error_db_too_low'] = 'The version of your database server is very old and does not meet ElkArte\'s minimum requirements.<br /><br />Please ask your host to either upgrade it or supply a new one, and if they won\'t, please try a different host.';
$txt['error_db_database'] = 'The installer was unable to access the &quot;<em>%1$s</em>&quot; database.  With some hosts, you have to create the database in your administration panel before ElkArte can use it.  Some also add prefixes - like your username - to your database names.';
$txt['error_db_queries'] = 'بعض الاستفسارات لم يتم تنفيذها بشكل صحيح. قد يعود السبب لنسخة غير مدعومة من قبل برنامج قاعدة البيانات الخاص بك.<br /><br />المعلومات التقنية عن الاستفسارات:';
$txt['error_db_queries_line'] = 'السطر #';
$txt['error_db_missing'] = 'The installer was unable to detect database support in PHP that ElkArte can utilize.  Please ask your host to ensure that PHP was compiled with the desired database, or that the proper php extension is being loaded.  Currently ElkArte supports the:  &quot;%1$s&quot; extensions';
$txt['error_db_script_missing'] = 'ملف التثبيت غير قادر على إيجاد أى سكربت مثبت على قاعدة البيانات هذه. رجاء التأكد أنك قمت برفع ملفات التثبيت الخاصه بالسكربت الى مجلد المنتدى الصحيح, على سبيل المثال &quot;%1$s&quot;';
$txt['error_session_missing'] = 'لم يتمكن المثبت من إيجاد دعم الجلسات ضمن نسخة الـPHP المثبتة على سيرفرك.  نرجو سؤال المضيف للتأكد من أن PHP  تحتوي على دعم الجلسات ضمنها (على الأغلب, أنها لا تحوي ذلك لكن اسأل للتأكد.)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'قمت بكتابة كلمتي مرور مختلفتين!';
$txt['error_user_settings_no_password'] = 'كلمة المرور الخاصة بك يجب أن تكون  على الأقل أربعة أحرف.';
$txt['error_user_settings_taken'] = 'Sorry, a member is already registered with that user name and/or email address.<br /><br />A new account has not been created.';
$txt['error_user_settings_query'] = 'حدث خطأ في قاعدة البيانات أثناء محاولة إنشاء حساب المدير.  الخطأ هو:';
$txt['error_subs_missing'] = 'Unable to find the sources/Subs.php file.  Please make sure it was uploaded properly, and then try again.';
$txt['error_db_alter_priv'] = 'The database account you specified does not have permission to ALTER, CREATE, and/or DROP tables in the database; this is necessary for ElkArte to function properly.';
$txt['error_versions_do_not_match'] = 'The installer has detected another version of ElkArte already installed with the specified information.  If you are trying to upgrade, you should use the upgrader, not the installer.<br /><br />Otherwise, you may wish to use different information, or create a backup and then delete the data currently in the database.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'The current version of your database doesn\'t support the use of the UTF-8 character set. You can not install ElkArte';
$txt['error_valid_email_needed'] = 'لم تكتب بريدا صحيحا .';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'تحذير!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'يجب عليك إدخال إسم ملف قاعدة البيانات الخاص بـ SQLite .';
$txt['error_db_prefix_numeric'] = 'إن قاعدة البيانات التى قمت بإختيارها لا تدعم البدايات الرقميه .';
$txt['error_invalid_characters_username'] = 'لقد إستخدمت أحرف غير صالحه فى إسم المستخدم .';
$txt['error_username_too_long'] = 'User name must be less than 25 characters long.';
$txt['error_username_left_empty'] = 'User name field was left empty.';
$txt['error_db_filename_exists'] = 'قاعدة البيانات التى تحاول بنائها موجوده بالفعل . رجاء قم بحذفها او ادخل أسم أخر لقاعدة البيانات .';
$txt['error_db_prefix_reserved'] = 'هذه البادئة موجوده مسبقا . رجاء إختر بادئة جديده';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade Utility';
$txt['upgrade_warning'] = 'تحذير!';
$txt['upgrade_critical_error'] = 'خطأ فادح!';
$txt['upgrade_continue'] = 'استمر';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'تخطي';
$txt['upgrade_note'] = 'ملاحظة!';
$txt['upgrade_step'] = 'خطوة';
$txt['upgrade_steps'] = 'خطوات';
$txt['upgrade_progress'] = 'التقدم';
$txt['upgrade_overall_progress'] = 'التقدم الإجمالي';
$txt['upgrade_step_progress'] = 'تقدم الخطوة';
$txt['upgrade_time_elapsed'] = 'الوقت المنقضي';
$txt['upgrade_time_mins'] = 'دقائق';
$txt['upgrade_time_secs'] = 'ثوان';

$txt['upgrade_incomplete'] = 'غير مكتمل';
$txt['upgrade_not_quite_done'] = 'لم ينتهي بعد!';
$txt['upgrade_paused_overload'] = 'لقد تم تفعيل نمط الصيانه لمنتداك. لا تقلق, لا يوجد شيئ خطأ - فقط قم بالضغط على <label for="contbutt">زر إستمر</label> الموجود بالأسفل للمتابعه.';

$txt['upgrade_ready_proceed'] = 'Thank you for choosing to upgrade to ElkArte %1$s. All files appear to be in place, and we\'re ready to proceed.';

$txt['upgrade_error_script_js'] = 'The upgrade script cannot find script.js or it is out of date. Make sure your theme paths are correct. You can download a settings check and repair script from <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte tools</a>.';

$txt['upgrade_warning_lots_data'] = 'إن أداة الترقيه إكتشفة أن منتداك يحوى الكثير من البيانات التى يجب ترقيتها. هذه العمليه ستأخذ فترة من الوقت و هذا يتوقف على حجم منتداك و السرفر الخاص بك, و بالنسبه للمنتدات الكبيره (~300,000 مشاركه) فقد تأخذ هذه العمليه ساعات لكل تنتهى.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';