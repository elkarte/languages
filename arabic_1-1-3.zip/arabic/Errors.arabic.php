<?php
// Version: 1.1; Errors

$txt['no_access'] = 'غير مصرح لك ';
$txt['not_guests'] = 'هذه الميزة للأعضاء فقط...';

$txt['mods_only'] = 'يمكن للمراقبين فقط استخدام ميزة الحذف. الرجاء حذف هذه الرسالة من خلال ميزة التحرير.';
$txt['no_name'] = 'لم تقم بتعبئة خانة الاسم. مطلوبة.';
$txt['no_email'] = 'لم تقم بتعبئة خانة البريد الالكتروني . مطلوبة.';
$txt['topic_locked'] = 'هذا الموضوع مقفل، لا يمكنك تحرير أو كتابة رسالة...';
$txt['no_password'] = 'خانة كلمة المرور تركت خالية';
$txt['passwords_dont_match'] = 'كلمات المرور غير متطابقة.';
$txt['register_to_use'] = 'نأسف، يجب أن تسجل أولا قبل استخدام هذه الميزة.';
$txt['username_reserved'] = 'اسم المستخدم الذي تحاول استخدامه يحتوي على كلمة محجوزة مسبقا وهي \'%1$s\'. الرجاء استخدام اسما آخر.';
$txt['numbers_one_to_nine'] = 'هذا الحقل يقبل الأرقام فقط  0-9';
$txt['not_a_user'] = 'العضو الذي تحاول أن مشاهد معلوماته الشخصية غير موجود.';
$txt['not_a_topic'] = 'هذا الموضوع غير متوفر في هذا المنتدى.';
$txt['not_approved_topic'] = 'هذا الموضوع لم يتم الموافقة عليه بعد .';
$txt['email_in_use'] = 'عنوان البريد الالكتروني (%s) مستخدم من قبل عضو مسجل مسبقا. في حال كنت تشعر أن هذا خاطئ, اذهب إلى صفحة تسجيل الدخول و استخدم مذكر كلمة السر مع البريد الالكتروني السابق.';

$txt['didnt_select_vote'] = 'لم تقم بتحديد خيار التصويت.';
$txt['poll_error'] = 'أما أن يكون الاقتراع غير موجود، او مقفل أو تحاول التصويت مرتين.';
$txt['locked_by_admin'] = 'تم قفله بواسطة المشرف. لا يمكنك فتحه.';
$txt['not_enough_posts_karma'] = 'عذرا, لا تملك مشاركات كافية لتعديل الشعبية - تحتاج على الأقل %1$d.';
$txt['cant_change_own_karma'] = 'نأسف، غير مصرح لك بتعديل الشعبية .';
$txt['karma_wait_time'] = 'عذرا, لا تستطيع تكرار عملية تعديل الشعبية ذاتها يجب عليك الانتظار %1$s %2$s.';
$txt['feature_disabled'] = 'نأسف، هذه الميزة معطلة.';
$txt['feature_no_exists'] = 'نأسف، هذه الميزة غير موجودة.';
$txt['couldnt_connect'] = 'لا يمكن الاتصال بالمقلم أو إن الملف غير موجود';
$txt['no_board'] = 'المنتدى المطلوب غير موجود';
$txt['no_message'] = 'المشاركة لم تعد موجودة .';
$txt['no_topic_id'] = 'قمت بتحديد ID للموضوع خاطئ.';
$txt['split_first_post'] = 'لا يمكنك فصل موضوع في الرسالة الأولى.';
$txt['topic_one_post'] = 'هذا الموضوع يحتوي على رسالة واحدة و لا يمكن فصله.';
$txt['no_posts_selected'] = 'لم يتم تحديد رسائل';
$txt['selected_all_posts'] = 'لا يمكنك فصل الموضوع لأنك اخترت جميع المشاركات فيه!';
$txt['cant_find_messages'] = 'لا يمكن العثور على الرسائل';
$txt['cant_find_user_email'] = 'لم نسطع إيجاد عنوان بريد العضو.';
$txt['cant_insert_topic'] = 'لا يمكن إضافة موضوع';
$txt['session_timeout'] = 'مدة الجلسة انتهت خلال كتابتك. الرجاء العودة و المحاولة مجددا.';
$txt['session_timeout_file_upload'] = 'مدة الجلسة انتهت اثناء رفع الملف. الرجاء المحاولة مجددا.';
$txt['no_files_uploaded'] = 'لا يوجد ملفات للرفع';
$txt['session_verify_fail'] = 'التحقق من الجلسة فشل. الرجاء محاولة تسجيل الخروج ثم معاودة تسجيل الدخول مجددا';
$txt['verify_url_fail'] = 'لا يمكن التحقق من رابط موقع الإحالة : %1$s.  الرجاء العودة و المحاولة مرة أخرى.';
$txt['token_verify_fail'] = 'فشل في التحقق . الرجاء العودة و المحاولة مرة أخرى.';
$txt['guest_vote_disabled'] = 'الضيوف لا يستطيعون التصويت في هذا الاستطلاع.';

$txt['cannot_access_mod_center'] = 'لا تملك الصلاحيات للوصول إلى قسم الإشراف.';
$txt['cannot_admin_forum'] = 'غير مصرح لك الإشراف على هذا المنتدى.';
$txt['cannot_announce_topic'] = 'لا يمكنك وضع اعلانات في هذا القسم';
$txt['cannot_approve_posts'] = 'لا تملك الصلاحيات لكي تقوم بالموافقة على العناصر.';
$txt['cannot_post_unapproved_attachments'] = 'لا تملك الصلاحيات لإرسال مرفق لم يوافق عليه بعد.';
$txt['cannot_post_unapproved_topics'] = 'لا تملك الصلاحية لإرسال موضوع لم يوافق عليه بعد.';
$txt['cannot_post_unapproved_replies_own'] = 'لا تملك الصلاحية لإرسال رد على مواضيعك لم يوافق عليه بعد.';
$txt['cannot_post_unapproved_replies_any'] = 'لا تملك الصلاحية لإرسال رد على مواضيع باقي الأعضاء لم يوافق عليه بعد.';
$txt['cannot_calendar_edit_any'] = 'لا يمكنك تحرير أحداث التقويم.';
$txt['cannot_calendar_edit_own'] = 'لا تمتلك التصاريح الكافية التي تخوّلك بتحرير احداثك.';
$txt['cannot_calendar_post'] = 'نأسف ، كتابة الأحداث غير مصرح بها.';
$txt['cannot_calendar_view'] = 'نأسف غير مصرح لك مشاهدة التقويم.';
$txt['cannot_remove_any'] = 'حذف أي رسالة في هذا المنتدى غير مسموح.';
$txt['cannot_remove_own'] = 'غير مصرح لك في هذا المنتدى بحذف رسائلك';
$txt['cannot_edit_news'] = 'غير مصرح لك بتحرير الأخبار في هذا المنتدى.';
$txt['cannot_pm_read'] = 'نأسف، لا يمكنك قراءة رسائلك الشخصية.';
$txt['cannot_pm_send'] = 'لا يمكنك بعث الرسائل الشخصية.';
$txt['cannot_karma_edit'] = 'غير مصر لك تحرير كارما الأعضاء الآخرين.';
$txt['cannot_like_posts'] = 'لا يمكنك تسجيل اعجابك بالمشاركات في هذا المنتدى.';
$txt['cannot_lock_any'] = 'لا يمكنك قفل أي موضوع هنا.';
$txt['cannot_lock_own'] = 'نأسف، لا يمكنك قفل مواضيعك هنا.';
$txt['cannot_make_sticky'] = 'غير مصرح لك بتثبيت هذا الموضوع.';
$txt['cannot_manage_attachments'] = 'لم يتم السماح لك بمعالجة الملحقات أو صور الشخصية.';
$txt['cannot_manage_bans'] = 'ليس مخول لك تعديل قائمة الحظر.';
$txt['cannot_manage_boards'] = 'غير مخول لك معالجة التصنيفات و المنتديات.';
$txt['cannot_manage_membergroups'] = 'ليس لديك تصريح لتعديل أو ضبط مجموعة الأعضاء.';
$txt['cannot_manage_permissions'] = 'غير مخول لك تعديل التصريحات.';
$txt['cannot_manage_smileys'] = 'غير مخول لك معالجة الابتسامات.';
$txt['cannot_mark_any_notify'] = 'ليس لديك التصاريح الكافية للحصول على تنبيه للمواضيع.';
$txt['cannot_mark_notify'] = 'نأسف، لا يمكن لحصول على تنبيهات من هذا المنتدى.';
$txt['cannot_merge_any'] = 'لا يمكنك دمج المواضيع في أحد المنتديات المختارة.';
$txt['cannot_moderate_forum'] = 'لا يمكنك مراقبة هذا المنتدى.';
$txt['cannot_moderate_board'] = 'غير مسموح لك بإدراة هذا القسم.';
$txt['cannot_modify_any'] = 'لا يمكنك تعديل أي موضوع.';
$txt['cannot_modify_own'] = 'نأسف، لا يمكنك تحرير رسائلك.';
$txt['cannot_modify_replies'] = 'بالرغم من كون هذه الرسالة رد على موضوعك فلا يمكنك تحريرها.';
$txt['cannot_move_own'] = 'لا يمكنك نقل مواضيعك في هذا المنتدى.';
$txt['cannot_move_any'] = 'لا يمكنك نقل المواضيع في هذا المنتدى.';
$txt['cannot_poll_add_own'] = 'نأسف، لا يمكنك إضافة الاقتراع إلى موضوعك في هذا المنتدى.';
$txt['cannot_poll_add_any'] = 'ليس لديك حق الوصول لإضافة اقتراع إلى هذا الموضوع.';
$txt['cannot_poll_edit_own'] = 'لا يمكن تحرير هذا الاقتراع حتى و أن كان لك.';
$txt['cannot_poll_edit_any'] = 'تم رفض التصريح لك بتحرير الاقتراعات في هذا المنتدى.';
$txt['cannot_poll_lock_own'] = 'غير مصرح لك بقفل اقتراعك في هذا المنتدى.';
$txt['cannot_poll_lock_any'] = 'نأسف، غير مصرح لك قفل أي اقتراع.';
$txt['cannot_poll_post'] = 'لا يمكنك إضافة اقتراع في هذا المنتدى.';
$txt['cannot_poll_remove_own'] = 'غير مصرح لك حذف هذا الاقتراع من موضوعك.';
$txt['cannot_poll_remove_any'] = 'لا يمكنك حذف أي اقتراع من هذا المنتدى.';
$txt['cannot_poll_view'] = 'لا يمكنك مشاهدة الاقتراعات في هذا المنتدى.';
$txt['cannot_poll_vote'] = 'نأسف، لا يمكنك التصويت في هذا المنتدى.';
$txt['cannot_post_attachment'] = 'غير مصرح لك بإضافة الملحقات في هذا المنتدى.';
$txt['cannot_post_new'] = 'نأسف، لا يمكنك إضافة رسائل جديدة في هذا المنتدى.';
$txt['cannot_post_new_board'] = 'نأسف، لا يمكنك إضافة موضوعات جديدة في المنتدى %1$s.';
$txt['cannot_post_reply_any'] = 'غير مصرح لك بإضافة الردود على المواضيع في هذا المنتدى.';
$txt['cannot_post_reply_own'] = 'غير مصرح لك بإضافة الردود على حتى مواضيع في هذا المنتدى.';
$txt['cannot_profile_remove_own'] = 'نأسف ، لا يمكنك حذف حسابك.';
$txt['cannot_profile_remove_any'] = 'لا تمتلك التصريح المناسب لحذف حسابات الغير!';
$txt['cannot_profile_extra_any'] = 'لا تمتلك التصريح الكافي لتعديل الهوية.';
$txt['cannot_profile_identity_any'] = 'غير مصرح لك بتغير إعدادات الحساب.';
$txt['cannot_profile_title_any'] = 'لا يمكنك تحرير أسماء العرض للغير.';
$txt['cannot_profile_extra_own'] = 'نأسف، لا تمتلك التصريح الكافي لتحرير بيانات الهوية.';
$txt['cannot_profile_identity_own'] = 'لا يمكنك تغير هويتك في الوقت الراهن.';
$txt['cannot_profile_title_own'] = 'غير مسموح لك بتغير اسم العرض.';
$txt['cannot_profile_set_avatar'] = 'لا تملك الصلاحية لتغيير صورتك الرمزية.';
$txt['cannot_profile_view_own'] = 'نأسف، ولكن لا يمكنك مشاهدة هويتك.';
$txt['cannot_profile_view_any'] = 'نأسف، لا يمكنك مشاهدة أي هوية.';
$txt['cannot_delete_own'] = 'لا يمكنك حذف مشاركاتك من هذا المنتدى.';
$txt['cannot_delete_replies'] = 'عذرا, لكن لا يمكنك حذف هذه المشاركات, على الرغم من أنها ردود على موضوعك.';
$txt['cannot_delete_any'] = 'لا يمكنك حذف اي مشاركات من هذا المنتدى.';
$txt['cannot_report_any'] = 'غير مسموح بالتنبيه عن الرسائل في هذا المنتدى.';
$txt['cannot_search_posts'] = 'غير مسموح البحث عن الرسائل في هذا المنتدى.';
$txt['cannot_send_mail'] = 'غير مصرح لك إرسال البريد إلى الكل.';
$txt['cannot_issue_warning'] = 'عذرا, لا تملك الصلاحية لإصدار تحذير للأعضاء.';
$txt['cannot_send_topic'] = 'نأسف، و لكن المشرف منع ارسال المواضيع في هذا المنتدى.';
$txt['cannot_send_email_to_members'] = 'نأسف، و لكن المشرف منع ارسال رسائل بريدية من خلال هذا المنتدى.';
$txt['cannot_split_any'] = 'فصل أي موضوع في هذا المنتدى غير مسموح.';
$txt['cannot_view_attachments'] = 'غير مصرح بتنزيل أو مشاهدة الملحقات في هذا المنتدى.';
$txt['cannot_view_mlist'] = 'غير مصرح لك بمشاهدة قائمة الأعضاء.';
$txt['cannot_view_stats'] = 'غير مصرح لك بمشاهدة إحصاءات المنتدى.';
$txt['cannot_who_view'] = 'نأسف، لا تملك التصريحات الكافية لمشاهدة من المتصل.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = 'تعذر ايجاد هذا القالب';
$txt['theme_dir_wrong'] = 'مجلد القالب الافتراضي غير سليم ، الرجاء إصلاحه بالنقر على هذا النص.';
$txt['registration_disabled'] = 'نأسف ، التسجيل حاليا موقف.';
$txt['registration_agreement_missing'] = 'ملف شروط التسجيل agreement.txt مفقود او خالي. سيتم تعطيل التسجيل حتى يتم اصلاح الخطأ .';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'نأسف، لم يتم إعداد سؤال سري لهذا العضو.';
$txt['poll_range_error'] = 'نأسف، الاقتراع يجب أن يكون لمدة أكثر من 0 يوم.';
$txt['delFirstPost'] = 'لا يمكنك حذف أول مشاركة في الموضوع.<p>إذا رغبت في حذف هذا الموضوع فانقر على زر حذف الموضوع أو اتصل بالمراقب/المشرف ليقوم بالحذف.</p>';
$txt['login_cookie_error'] = 'لا يمكن تسجيل دخولك. الرجاء التأكد من إعدادات السكاكر.';
$txt['incorrect_answer'] = 'نأسف، و لكنك لم تقم بالإجابة على السؤال السري بشكل سليم. الرجاء العودة للوراء و المحاولة مرة أخرى، أو العودة إلى البداية لتستخدم الطريقة الافتراضية للحصول على كلمة المرور.';
$txt['no_mods'] = 'لم يتم العثور على مراقبين!';
$txt['parent_not_found'] = 'الشكل البياني للمنتدى معطوب: لا يمكن العثور على المنتدى الأب';
$txt['modify_post_time_passed'] = 'لا يمكنك تحديد تعديل هذه المشاركة لأن وقت التعديل قد تم تجاوزه.';

$txt['calendar_off'] = 'لا يمكنك الصول إلى التقويم لأنه معطل حاليا.';
$txt['calendar_export_off'] = 'لا يمكنك تصدير احداث التقويم لأن الميزة معطلة حاليا.';
$txt['invalid_month'] = 'قيمة الشهر غير صحيحة.';
$txt['invalid_year'] = 'قيمة السنة غير صحيحة.';
$txt['invalid_day'] = 'قيمة اليوم غير صالحة.';
$txt['event_month_missing'] = 'شهر الحدث مفقود.';
$txt['event_year_missing'] = 'سنة الحدث مفقودة.';
$txt['event_day_missing'] = 'يوم الحدث مفقود.';
$txt['event_title_missing'] = 'عنوان الحدث مفقود.';
$txt['invalid_date'] = 'تاريخ غير صحيح.';
$txt['no_event_title'] = 'لم يتم إدخال عنوان للحدث.';
$txt['missing_board_id'] = 'ID المنتدى مفقود.';
$txt['missing_topic_id'] = 'ID الموضوع مفقود.';
$txt['topic_doesnt_exist'] = 'الموضوع غير موجود.';
$txt['not_your_topic'] = 'أنت لست صاحب هذا الموضوع.';
$txt['board_doesnt_exist'] = 'المنتدى غير موجود.';
$txt['no_span'] = 'ميزة التكرار معطلة حاليا.';
$txt['invalid_days_numb'] = 'عدد أيام غير صحيح للتكرار.';

$txt['moveto_noboards'] = 'لا يوج أي منتديات لنقل هذا الموضوع إليها!';
$txt['topic_already_moved'] = 'هذا الموضوع %1$s تم نقله الى منتدى %2$s, فضلا تحقق من موقعه الجديد قبل ان يتم نقله مرة ثانية.';

$txt['already_activated'] = 'كنا نتمنى تنفيذ طلبك ، لكن حسابك تم تنشيطه بالفعل .';
$txt['still_awaiting_approval'] = 'حسابك مايزال ينتظر موافقة المشرف.';

$txt['invalid_email'] = 'عنوان بريد/نطاق عنوان بريد غير صحيح.<br />مثال على عنوان بريد صحيح: bill.gates@microsoft.com.<br />مثال على نطاق عنوان بريد صحيح: *@*.microsoft.com';
$txt['invalid_expiration_date'] = 'تاريخ مدة انتهاء الصلاحية غير صحيح';
$txt['invalid_hostname'] = 'اسم مستضيف/نطاق اسم مستضيف غير صحيح.<br />مثال على اسم مستضيف صحيح: proxy4.microsoft.com<br />مثال على نطاق اسم مستضيف صحيح: *.microsoft.com';
$txt['invalid_ip'] = 'IP /نطاق IP غير صحيح.<br />مثال على عنوان IP صحيح: 127.0.0.1<br />مثال على نطاق عنوان IP صحيح: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'الـIP أو مدى الـIP الذي قمت بتحديده غير صحيح.';
$txt['invalid_username'] = 'اسم العضو غير موجود';
$txt['no_user_selected'] = 'العضو غير موجود';
$txt['no_ban_admin'] = 'لا يمكنك حظر مدير ، يجب عليك أن تنزل من صلاحيته أولا!';
$txt['no_bantype_selected'] = 'لم يتم تحديد نوع للحظر';
$txt['ban_not_found'] = 'الحظر غير موجود';
$txt['ban_unknown_restriction_type'] = 'نوع التقييد غير معروف';
$txt['ban_name_empty'] = 'اسم الحظر قد ترك فارغا';
$txt['ban_id_empty'] = 'لم يتم العثور على معرف الحظر';
$txt['ban_group_id_empty'] = 'لحظر مجموعة فلابد من وجود معرف لها ، وهذه المجموعة ليس لها اي معرف';
$txt['ban_no_triggers'] = 'لم يتم ادخال اي شروط لهذا الحظر';
$txt['ban_ban_item_empty'] = 'شرط الحظر غير موجود';
$txt['impossible_insert_new_bangroup'] = 'حدثت خطأ عند ارسال هذا الحظر الجديد';

$txt['like_heading_error'] = 'خطأ في تسجيل الاعجاب';
$txt['like_wait_time'] = 'عذرا, لا تستطيع تكرار عملية تسجيل الاعجاب ذاتها ، يجب عليك الانتظار %1$s %2$s.';
$txt['like_unlike_error'] = 'حدث خطأ عند تسجيل/الغاء الاعجاب لهذه المشاركة';
$txt['cant_like_yourself'] = 'لا يمكنك تسجيل الاعجاب بمشاركاتك أنت - عيب عليك';

$txt['ban_name_exists'] = 'اسم هذا الحظر موجود مسبقا. أرجو استخدام اسم مختلف.';
$txt['ban_trigger_already_exists'] = 'This ban trigger (%1$s) already exists in %2$s.';
$txt['attach_check_nag'] = 'تعذر الاستمرار بسبب نقص البيانات (%1$s).';

$txt['recycle_no_valid_board'] = 'لم يتم اختيار منتدى صحيح للمواضيع المحذوفة';
$txt['post_already_deleted'] = 'الموضوع او المشاركة تم نقلها بالفعل الى منتدى المحذوفات ، هل تريد بالفعل حذفها نهائيا؟ <br />اذا كان الامر كذلك استخدم <a href="%1$s">هذا الرابط</a>';

$txt['login_threshold_fail'] = 'نأسف، نفذت محاولات تسجيل الدخول. الرجاء العودة و المحاولة مرة اخرى لاحقا.';
$txt['login_threshold_brute_fail'] = 'عذرا, ولكنك وصلت الى العدد الاقصى لمحاولة تسجيل الدخول. الرجاء الإنتظار 30 ثانية ثم المحاولة مرة اخرى';

$txt['who_off'] = 'غير مصرح لك';

$txt['merge_create_topic_failed'] = 'خطأ ، فشل انشاء موضوع جديد';
$txt['merge_need_more_topics'] = 'دمج المواضيع يحتاج إلى موضعين على الأقل.';

$txt['post_WaitTime_broken'] = 'المشاركة السابقة التي أرسلتها من نفس الاي بي كان أقل من %d ثانية. أرجو المحاولة مرة ثانية بعد قليل.';
$txt['register_WaitTime_broken'] = 'لقد قمت بالتسجيل منذ %d ثواني مضت!';
$txt['login_WaitTime_broken'] = 'يجب أن تنظر على الأقل %d ثانية للدخول ثانية، نأسف.';
$txt['pm_WaitTime_broken'] = 'الرسالة الشخصية الأخيرة المرسلة من نفس عنوان الاي بي الخاص بك كانت مرسلة خلال فترة أقل %d ثانية. أرجو الانتظار قليلا ثم المحاولة مرة ثانية.';
$txt['reporttm_WaitTime_broken'] = 'التقرير الأخير المرسل من قبل نفس عنوان الاي بي الخاص بك لم يتجاوز فترة %d ثانية. أرجو الانتظار قليلا ثم المحاولة مرة ثانية.';
$txt['sendtopic_WaitTime_broken'] = 'الموضوع الأخير المرسل من قبل نفس عنوان الاي بي الخاص بك لم يتجاوز فترة %d ثانية. أرجو الانتظار قليلا ثم المحاولة مرة ثانية.';
$txt['sendmail_WaitTime_broken'] = 'البريد الالكتروني الأخير المرسل من قبل نفس عنوان الاي بي الخاص بك لم يتجاوز فتر %d ثانية. أرجو الانتظار قليلا ثم المحاولة مرة ثانية.';
$txt['search_WaitTime_broken'] = 'بحثك الاخير كان منذ %d ثانية, الرجاء المحاولة لاحقا';
$txt['remind_WaitTime_broken'] = 'تذكيرك الاخير كان منذ %1$d ثانية, الرجاء المحاولة لاحقا';
$txt['contact_WaitTime_broken'] = 'اتصالك بنا الاخير كان منذ %1$d ثانية, الرجاء المحاولة لاحقا';

$txt['topic_gone'] = 'الموضوع أو المنتدى الذي تريد البحث عنه أما مفقود أو غير مصرح لك بمشاهدته.';
$txt['theme_edit_missing'] = 'الملف الذي ترغب في تحريره غير موجود!';

$txt['no_dump_database'] = 'فقط المدراء يمكنهم عمل نسخ احتياطي لقاعدة البيانات';
$txt['pm_not_yours'] = 'الرسالة الشخصية التي تحاول الاقتباس منها ليست لك أو غير موجودة، الرجاء العودة و المحاولة مرة أخرى.';
$txt['mangled_post'] = 'شكل بيانات مشوه - الرجاء العودة و المحاولة مرة أخرى.';
$txt['too_many_groups'] = 'عفوا لقد قمت بتحديد عدد كبير من المجموعات ، الرجا ازالة بعضها';
$txt['post_upload_error'] = 'بيانات المشاركة مفقودة، ربما كنت تحاول ادخال ملف اكبر من الحجم المسموح ، اذا كانت هذه مشكلة متكررة برجاء ابلاغ الادارة';
$txt['quoted_post_deleted'] = 'الاقتباس الذي تحاول أن تأخذ إما غير موجود أو تم حذفه, أو لم تعد تستطيع أن تشاهده.';
$txt['pm_too_many_per_hour'] = 'لقد تجاوزت حد عدد إرسال الرسائل الخاصة و الذي هو %d رسالة كل ساعة.';
$txt['labels_too_many'] = 'عذرا, الرسائل %s تملك الحد الأعظمي من العلامات المسموحة!';

$txt['register_only_once'] = 'عذرا, لا يمكنك التسجيل بأكثر من حساب في نفس الوقت و من نفس الجهاز.';
$txt['admin_setting_coppa_require_contact'] = 'يجب عليك أن تدخل عنوان البريد أو رقم الفاكس لكي نتمكن من الاتصال في حال موافقة الولي مطلوبة.';

$txt['error_long_name'] = 'الاسم الذي تحاول استخدامه طويل جدا.';
$txt['error_no_name'] = 'لم يتم تزويد أي اسم.';
$txt['error_bad_name'] = 'الاسم الذي قمت بكتابته لا يمكن استخدامه لأنه يحتوي على اسم محجوز مسبقا.';
$txt['error_no_email'] = 'لم يتم تزويد أي عنوان بريد.';
$txt['error_bad_email'] = 'تم كتابة بريد غير صحيح.';
$txt['error_email'] = 'عنوان البريد الإلكترونى';
$txt['error_message'] = 'رسالة';
$txt['error_no_event'] = 'لم يتم كتابة اسم الحدث.';
$txt['error_no_subject'] = 'لم يتم كتابة العنوان.';
$txt['error_no_question'] = 'لم يتم كتابة سؤال لهذا الاقتراع.';
$txt['error_no_message'] = 'الرسالة تركت خالية.';
$txt['error_long_message'] = 'الرسالة تخطت الطول المسموح به (%s حرفا).';
$txt['error_no_comment'] = 'الحق الخاص بالتعليق فارغ .';
$txt['error_post_too_long'] = 'مشاركتك طويلة جدا. الرجا الالتزام بالحد الاقصى وهو 255 حرف';
$txt['error_session_timeout'] = 'انتهت مدة الجلسة بينما أنت تكتب. الرجاء محاولة إعادة الإرسال مرة أخرى.';
$txt['error_no_to'] = 'لم يتم تحديد المستلمين.';
$txt['error_bad_to'] = 'واحد أو أكثر  \'إلى\'-المستلمين لا يمكن العثور عليه.';
$txt['error_bad_bcc'] = 'واحد أو أكثر \'نسخة\'-المستلمين لا يمكن العثور عليه.';
$txt['error_form_already_submitted'] = 'لقد قمت بالفعل بإرسال هذه المشاركة!  قد تكون حاولت الإرسال مرتين أو قمت بالتحديث.';
$txt['error_poll_few'] = 'يجب أن يكون هنالك خيارين على الأقل!';
$txt['error_poll_many'] = 'الرجا الالتزام بالحد الاقصى وهو 256 اختيار';
$txt['error_need_qr_verification'] = 'رجاءً، أكمل عملية التحقق لنشر مشاركتك.';
$txt['error_wrong_verification_code'] = 'الأحرف التي كتبتها لا تتطابق مع الأحرف الموجودة ضمن الصورة.';
$txt['error_wrong_verification_answer'] = 'لم تقم بإجابة سؤال التحقق بشكل صحيح';
$txt['error_need_verification_code'] = 'الرجاء إدخال رمز/شفرة التحقق لكي تواصل الى النتائج';
$txt['error_bad_file'] = 'عذرا لكن الملف الذي حددته لم نستطع فتحه: %1$s';
$txt['error_bad_line'] = 'السطر الذي حددته غير صالح.';
$txt['error_draft_not_saved'] = 'حدث خطأ عند حفظ المسودة';
$txt['error_name_in_use'] = 'الاسم %1$s تم إستخدامه مسبقا من عضو آخر.';

$txt['smiley_not_found'] = 'الابتسامة غير موجودة.';
$txt['smiley_has_no_code'] = 'لم يتم تزويد أي كود لهذه الابتسامة.';
$txt['smiley_has_no_filename'] = 'لم يتم تحديد اسم الملف لهذه الابتسامة.';
$txt['smiley_not_unique'] = 'ابتسامة مع ذلك الكود موجودة مسبقا.';
$txt['smiley_set_already_exists'] = 'مجموعة الابتسامات مع ذلك URL موجودة مسبقا';
$txt['smiley_set_not_found'] = 'مجموعة الابتسامات غير موجودة';
$txt['smiley_set_dir_not_found'] = 'مجلد مجموعة الابتسامات %1$s غير صحيح.او  لا يمكن الوصول إليه';
$txt['smiley_set_path_already_used'] = 'URL الخاص بالابتسامات مستخدم حاليا من قبل مجموعة ابتسامات أخرى .';
$txt['smiley_set_unable_to_import'] = 'لا يمكن جلب مجموعة الابتسامات. قد لا يمكن الوصول إلى المجلد أو يكون غير صحيح.';

$txt['smileys_upload_error'] = 'فشل في تحميل الملف.';
$txt['smileys_upload_error_blank'] = 'كل مجموعات الابتسامات يجب أن يكون لها صورة';
$txt['smileys_upload_error_name'] = 'كل الابتسامات يجب أن يكون لها نفس اسم الملف!'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'نوع غير سليم.';

$txt['search_invalid_weights'] = 'أوزان البحث لم يتم ضبطها بشكل سليم. على الأقل يجب أن يتم ضبط وزن واحد منها لقيمة غير صفرية . الرجاء إبلاغ الادارة بذلك.';

$txt['package_no_file'] = 'لا يمكن العثور على ملف الرزمة!';
$txt['packageget_unable'] = 'لا يمكن الاتصال بالملقم.  الرجاء محاولة استخدام <a href="%s" target="_blank">هذا العنوان</a> بدلا.';
$txt['not_valid_server'] = 'عفوا ، الرزم يمكن أن تنزل بهذه الطريقة فقط من السيرفرات التي سبق لك اعتمادها';
$txt['package_cant_uninstall'] = 'هذه الرزمة لم يتم تثبيتها مسبقا أو تم إزالتها - لا يمكنك إزالتها الآن';
$txt['package_cant_download'] = 'لا يمكنك تنزيل أو تثبيت رزم جديدة لأن مجلد الرزم &quot;packages&quot; او احد الملفات فيه غير قابل للكتابة.';
$txt['package_upload_error_nofile'] = 'لم تقم بإختيار رزمة لتحميلها .';
$txt['package_upload_error_failed'] = 'غير قادر على تحميل الرزمة , رجاء التأكد من تصاريح المجلد !';
$txt['package_upload_error_exists'] = 'الملف الذي تحمله موجود مسبقا على السيرفر. الرجاء حذفه أولا ثم إعادة المحاولة.';
$txt['package_upload_already_exists'] = 'الحزمة التي تحاول تحميلها ، ملفها موجود مسبقا على السيرفر تحت اسم : %1$s';
$txt['package_upload_error_supports'] = 'مدير الرزم يسمح حاليا الملفات ذات اللواحق التالية: %1$s.';
$txt['package_upload_error_broken'] = 'الرزمة التي تحاول رفعها إما هي رزمة غير صالحة أو هي رزمة معلطة.';

$txt['package_get_error_not_found'] = 'الحزمة التي تحاول تثبيتها غير موجودة. حاول القيام بتحميل الحزمة يدوياً إلى مجلد الحزمات. &quot;packages&quot; ';
$txt['package_get_error_missing_xml'] = 'الحزمة التي تحاول تثبيتها ينقصها ملف المعلومات الخاص بها.';
$txt['package_get_error_is_zero'] = 'يبدو أن الرزمة التى تم تحميلها على هذا السيرفر فارغه . رجاء قم بالتأكد من أن مجلد الرزم &quot;packages&quot; و  مجلد &quot;temp&quot;  الفرعي كلاهما قابل للكتابة. إذا واجهت هذه المشكله مرة اخرى حاول فك ضغط الرزمه على جهاز الكمبيوتر الخاص بك ثم قم برفع الملفات الناتجه بعد فك الضغط الى مجلد فرعى لمجلد الرزم &quot;packages&quot; و حاول مرة اخرى. فعلى سبيل المثال, إذا كان اسم الرزمة shout.tar.gz فيجب عليك:<br />1) تحميلها على جهاز الكمبيوتر الخاص بك ثم فك ضغطها.<br />2) إستخدم برنامج الـ FTP و قم بإنشاء مجلد جديد فى مجلد &quot;packages&quot; ,فى هذا المثال سوف تسمى المجلد الجديد "shout".<br />3) قم برفع جميع الملفات التى نتجت عن فك ضغط الرزمه الى هذا المجلد.<br />4) إذهب الى مدير الرزم و سوف يتم التعرف على الرزمه تلقائيا .';
$txt['package_get_error_packageinfo_corrupt'] = 'غير قادر على إيجاد اية معلومات صحيحه داخل الملف package-info.xml المرفق مع هذه الرزمه . ربما هذه الرزمه بها خطأ ما , او ان هذه الرزمه معطوبه .';
$txt['package_get_error_is_theme'] = 'لا يمكنك تنصيب سمة من هذا القسم ، فضلا استخدم صفحة  <a href="{MANAGETHEMEURL}">ادارة السمات</a>  لتحميلها';

$txt['no_membergroup_selected'] = 'لم يتم تحديد مجموعة الأعضاء';
$txt['membergroup_does_not_exist'] = 'المجموعة غير موجودة أو خاطئة.';

$txt['at_least_one_admin'] = 'يجب أن يكون هناك مدير واحد على الأقل في المنتدى!';

$txt['error_functionality_not_windows'] = 'عذرا , لكن هذه الوظائف غير متاحة حاليا للخوادم التى تستخدم نظام تشغيل وندوز .';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'الملحق غير موجود';

$txt['error_no_boards_selected'] = 'لم يتم تحديد منتديات صحيحة';
$txt['error_invalid_search_string'] = 'هل نسيت ادخال الشيء الذي تبحث عنه؟';
$txt['error_invalid_search_string_blacklist'] = 'عذراً لقد تضمن بحثك كلمات تافهة جداً , يرجى المحاولة مرة أخرى بكلمات مختلفة .';
$txt['error_search_string_small_words'] = 'كل كلمة يجب أن تتألف على الأقل من محرفين.';
$txt['error_query_not_specific_enough'] = 'طلبك لم يكن محدد بشكل كافي. جرب استخدام كلمات أطول, أو تعابير أقل شيوعا.';
$txt['error_no_messages_in_time_frame'] = 'لم يتم إيجاد أية مشاركة في إطار الوقت المحدد.';
$txt['error_no_labels_selected'] = 'لم يتم اختيار أية علامات';
$txt['error_no_search_daemon'] = 'عدم إمكانية الوصول إلى برنامج البحث';

$txt['profile_errors_occurred'] = 'الأخطاء التالية ظهرت عند محاول حفظ معلوماتك الشخصية';
$txt['profile_error_bad_offset'] = 'مقدار إزاحة الزمن خارج النطاق المسموح';
$txt['profile_error_no_name'] = 'خانة الاسم قد تم تركها فارغة';
$txt['profile_error_digits_only'] = 'هذه الخانة تقبل الأرقام فقط.';
$txt['profile_error_name_taken'] = 'اسم المستخدم/الشهرة المختار قد تم اختياره';
$txt['profile_error_name_too_long'] = 'الاسم المختار طويل جدا. يجب ألا يكون الاسم أطول من  60 محرف';
$txt['profile_error_no_email'] = 'خانة البريد الالكتروني قد تركت فارغة';
$txt['profile_error_bad_email'] = 'لم تدخل عنوان بريد الكتروني صالح';
$txt['profile_error_email_taken'] = 'عضو آخر مسجل بعنوان البريد الالكتروني المدخل';
$txt['profile_error_no_password'] = 'لم تقم بإدخال كلمة السر';
$txt['profile_error_bad_new_password'] = 'كلمتي المرور المدخلتين غير متطابقتين';
$txt['profile_error_bad_password'] = 'كلمة المرور المدخلة غير صحيحة';
$txt['profile_error_bad_avatar'] = 'الصورة الرمزية التي اخترتها كبيرة جدا , أو ليست صورة رمزية';
$txt['profile_error_password_short'] = 'كلمة المرور الخاصة بك يجب أن يكون طولها على الأقل %1$s حرف.';
$txt['profile_error_password_restricted_words'] = 'كلمة المرور الخاصة بك يجب ألا تحتوي على اسم المستخدم الخاص بك ولا عنوان البريد أو أية كلمات شائعة الاستخدام.';
$txt['profile_error_password_chars'] = 'كلمة المرور الخاصة بك يجب أن تحتوي على خليط من الأحرف الكبيرة و الصغيرة, بالإضافة إلى الأرقام.';
$txt['profile_error_already_requested_group'] = 'إنك فعلا قد قدمت طلبا للانتساب لهذه المجموعة لم يتم الإجابة عليه بعد!';
$txt['profile_error_openid_in_use'] = 'هناك عضو أخر يستخدم بالفعل رابط المصادقة هذا للـ OpenID';
$txt['profile_error_signature_not_yet_saved'] = 'لم يتم حفظ التوقيع';
$txt['profile_error_personal_text_too_long'] = 'النص الذي تحاول استخدامه طويل جدا.';
$txt['profile_error_user_title_too_long'] = 'العنوان الذي تحاول استخدامه طويل جدا.';

$txt['mysql_error_space'] = ' - تأكد من المساحة المتوفرة ضمن قاعدة بياناتك أو اتصل بمدير السيرفر الخاص بك.';

$txt['icon_not_found'] = 'لم نستطع إيجاد صورة الأيقون في السمة (القالب) الافتراضي - نرجو التأكد من أن الصورة قد تم تحميلها ثم حاول مرة أخرى.';
$txt['icon_after_itself'] = 'لا يمكن وضع الأيقون بعد نفسه';
$txt['icon_name_too_long'] = 'اسم ملف الأيقون لا يمكن أن يحتوي على أكثر من 16 محرف';

$txt['name_censored'] = 'عذرا, الاسم الذي تحاول استخدامه, %s, يتضمن كلمات محظورة. أرجو محاول استخدام اسم آخر.';

$txt['poll_already_exists'] = 'الموضوع لا يمكن أن يتضمن أكثر من استطلاع واحد';
$txt['poll_not_found'] = 'لا يوجد أية استطلاع مربوط مع هذا الموضوع!';

$txt['error_while_adding_poll'] = 'الخطأ أو الأخطاء التالية تحدث عند إضافة هذا الاستطلاع';
$txt['error_while_editing_poll'] = 'الخطأ أو الأخطاء التالية تحدث عند تعديل هذا الاستطلاع';

$txt['loadavg_search_disabled'] = 'نتيجة لضغط العالي على السيرفر, فإن ميزة البحث قد تم إيقافا أتوماتيكيا و بشكل مؤقت. نرجو المحاول لاحقا.';
$txt['loadavg_generic_disabled'] = 'عذرا, لكن بسبب الضغط العالي على السيرفر, فإن هذه الخاصة ليست متوفرة حاليا.';
$txt['loadavg_allunread_disabled'] = 'نأسف، هنالك ضغط على موارد الخادم. لا يمكنك حالياً عرض المواضيع غير المقروءة.';
$txt['loadavg_unreadreplies_disabled'] = 'حاليا السير تحت ضغط كبير.  نرجو المحاولة لاحقا.';
$txt['loadavg_show_posts_disabled'] = 'أرجو المحاولة مرة أخرى لاحقا. مشاركات هذا العضو غير متوفرة حاليا بسبب الضغط العالي على السيرفر.';
$txt['loadavg_unread_disabled'] = 'نأسف، هنالك ضغط على موارد الخادم. لا يمكنك حالياً عرض المواضيع غير المقروءة.';
$txt['loadavg_userstats_disabled'] = 'الرجا المحاولة مرة أخرى لاحقا. احصائيات هذا العضو غير متوفرة حاليا بسبب الضغط العالي على السيرفر.';

$txt['cannot_edit_permissions_inherited'] = 'لا يمكنك تعديل الصلاحيات الموروثة بشكل مباشر, يجب عليك إما أن تعدل صلاحيات المجموعة الأصل أو تغيير المجموعة التابع لها العضو ';

$txt['mc_no_modreport_specified'] = 'يجب عليك تحديد أية تقرير تريد أن تشاهد.';
$txt['mc_no_modreport_found'] = 'التقرير المحدد إما غير موجود أو خارج نطاق صلاحياتك';

$txt['st_cannot_retrieve_file'] = 'لم نستطع استرجاع الملف %1$s.';
$txt['admin_file_not_found'] = 'لم نتمكن من تحميل الملف المطلوب: %1$s.';

$txt['themes_none_selectable'] = 'على الأقل سمة واحد يجب أن يتم اختيارها.';
$txt['themes_default_selectable'] = 'السمة الافتراضية للمنتدى يجب أن يتم تحديدها.';
$txt['ignoreboards_disallowed'] = 'خيار تجاهل المنتديات لم يتم تفعيله.';

$txt['mboards_delete_error'] = 'لم يتم تحديد أية تصنيف';
$txt['mboards_delete_board_error'] = 'لم يتم تحديد أي منتدى';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'لا يمكنك جعل الأصل متفرع من نفسه';
$txt['mboards_board_own_child_error'] = 'لا يمكنك جعل المنتدى متفرع من نفسه';

$txt['smileys_upload_error_notwritable'] = 'مجلد الابتسامات التالي غير قابل للكتابة: %1$s';
$txt['smileys_upload_error_types'] = 'لواحق الصور المسموحة هي: %1$s.';

$txt['change_email_success'] = 'عنوان بريدك قد تغير, و بريد تفعيل جديد قد تم إرساله إلى العنوان الجديد.';
$txt['resend_email_success'] = 'بريد التفعيل الجديد قد تم إرساله بنجاح.';

$txt['custom_option_need_name'] = 'خيار الملف الشخصي يجب ان يكون له اسم';
$txt['custom_option_not_unique'] = 'اسم الخانة ليس فريد ويمكن ان يتكرر';
$txt['custom_option_regex_error'] = 'المعاملات التى قمت بادخالها غير صحيحة';

$txt['warning_no_reason'] = 'يجب أن تدخل سببا لتعديل حالة التحذير للعضو.';
$txt['warning_notify_blank'] = 'لقد اخترت لتنبيه العضو لكنك لم تملأ خانتي العنوان/الرسالة.';

$txt['cannot_connect_doc_site'] = 'تعذر الاتصال بدليل الاستخدام . تأكد من إعدادات السيرفر الخاص بك للسماح بإقامة اتصالات خارجية للانترنت ثم حاول مرة أخرى.';

$txt['movetopic_no_reason'] = 'يجب عليك كتابة سبب نقل هذا الموضوع , او قم بإلغاء التحديد من على الخيار \'كتابة موضوع إعداة توجيه\' .';
$txt['movetopic_no_board'] = 'يجب اختيار منتدى لنقل هذا الموضوع إليه!';

$txt['splittopic_no_reason'] = 'يجب عليك كتابة سبب نقل هذا الموضوع , او قم بإلغاء التحديد من على الخيار \'كتابة رسالة إعادة توجيه\' .';

// OpenID error strings
$txt['openid_server_bad_response'] = 'مزود الهوية لم يعطي المعلومات المناسبة.';
$txt['openid_return_no_mode'] = 'مزود الهوية لم يستجب مع نمط Open ID.';
$txt['openid_not_resolved'] = 'مزود الهوية لم يقبل طلبك.';
$txt['openid_no_assoc'] = 'لم نستطع إيجاد رابط المشاركة المطلوب مع مزرد الهوية.';
$txt['openid_sig_invalid'] = 'التوقيع من الطرف المرسل غير صالح.';
$txt['openid_load_data'] = 'لم نستطع تحميل المعلومان من طلب تسجيل الدخول الذي قمت به. نرجو المحاولة مرة أخرى.';
$txt['openid_not_verified'] = 'عنوان الـ OpenID المعطى لم يتم التأكد منه بعد. نرجو تسجيل الدخول من أجل التأكيد.';

$txt['error_custom_field_too_long'] = 'إن حقل &quot;%1$s&quot; لا يجب أن يكون أكثر من %1$d حرف. ';
$txt['error_custom_field_invalid_email'] = 'إن حقل &quot;%1$s&quot; يجب أن يكون بريدا صحيحا. ';
$txt['error_custom_field_not_number'] = 'إن حقل &quot;%1$s&quot; يجب أن يحوى أرقام. ';
$txt['error_custom_field_inproper_format'] = 'إن حقل &quot;%1$s&quot; به قيم غير صحيحه. ';
$txt['error_custom_field_empty'] = 'إن حقل &quot;%1$s&quot; يجب ألا يكون فارغ.';

$txt['email_no_template'] = 'قالب البريد الإلكترونى &quot;%1$s&quot; لم يتم العثور عليه. ';

$txt['search_api_missing'] = 'غير قادر على إيجاد مفتاح الـ API الخاص بالبحث ! رجاء راسل المدير للتأكد من انه قد قام برفع الملفات الصحيحة .';
$txt['search_api_not_compatible'] = 'إن مفتاح الـ API الذى تم إختياره و الذى يستخدمه هذا المنتدى قديم -تم العودة الى البحث القياسي . رجاء قم بفحص الملف %1$s. ';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'لا يمكنك استرجاع المشاركة الأولى في الموضوع';
$txt['restored_disabled'] = 'لقد تم تعطيل خاصية استرجاع المواضيع.';
$txt['restore_not_found'] = 'غير قادر على إستعادة الرسالة التاليه؛ يبدو ان الموضوع الذى كانت به هذه الرسالة تم حذفه: %1$s ستحتاج الى نقل هذه الرسالة يدويا.';

$txt['error_invalid_dir'] = 'إسم المجلد الذي أدخلته غير صحيح.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'لم يتم تعريف الإجراء الفرعي الذي طلبته';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'لا توجد عناصر قابلة للفرز';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
