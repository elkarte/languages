<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'قسم الإشراف';
$txt['mc_main'] = 'تحكم المنتدى';
$txt['mc_logs'] = 'السجلات';
$txt['mc_posts'] = 'مشاركة';
$txt['mc_groups'] = 'الأعضاء والمجموعات';

$txt['mc_view_groups'] = 'عرض مجموعات الأعضاء';

$txt['mc_description'] = '<strong>مرحبا, %1$s!</strong><br />هذا هو &quot;مركز الإشراف&quot;. من هنا يمكنك اجراء كل مهمات الإشراف الموكلة اليك من مدير المنتدى.  هذه الصفحة الرئيسية تشتمل على كل المستجدات الحادثة مؤخرا في المنتدى. يمكنك <a href="%2$s">تعديل الشكل والمظهر بالضغط هنا</a>.';
$txt['mc_group_requests'] = 'طلب الانضمام إلى أحد المجموعات';
$txt['mc_member_requests'] = 'طلب العضو';
$txt['mc_unapproved_posts'] = 'مشاركات غير موافق عليها';
$txt['mc_watched_users'] = 'الأعضاء تحت المراقبة مؤخرا';
$txt['mc_watched_topics'] = 'مواضيع تحت المراقبة';
$txt['mc_scratch_board'] = 'منتدى المشرفين';
$txt['mc_latest_news'] = 'آخر الأخبار';
$txt['mc_recent_reports'] = 'تقارير مواضيع جديدة';
$txt['mc_warnings'] = 'تحذيرات';
$txt['mc_notes'] = 'ملاحظات المشرفين';
$txt['mc_required'] = 'عناصر في إنتظار الموافقه عليها';
$txt['mc_attachments'] = 'المرفقات التي تنتظر الموافقة';
$txt['mc_emailmod'] = 'مشاركات بالبريد تنتظر الموافقة';
$txt['mc_topics'] = 'الموضوعات التي تنتظر الموافقة';
$txt['mc_posts'] = 'مشاركة';
$txt['mc_groupreq'] = 'طلب الإنضمام للمجموعات في انتظار الموافقة';
$txt['mc_memberreq'] = 'الاعضاء الذين ينتظرون الموافقة ';
$txt['mc_reports'] = 'بلاغات عن مشاركات في انتظار الموافقة';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'يتعذر عليك الاتصال بملف الأخبار الأخيرة الخاص ب ElkArte';

$txt['mc_recent_reports_none'] = 'لا يوجد أية تقارير بارزة';
$txt['mc_watched_users_none'] = 'لا يوجد حاليا أية أعضاء مراقبون.';
$txt['mc_group_requests_none'] = 'لا توجد أية طلبات إنتساب لأية مجموعة.';

$txt['mc_seen'] = '%1$s آخر مشاهدة %2$s ';
$txt['mc_seen_never'] = '%1$s لم يتم مشاهدته أبداً';
$txt['mc_groupr_by'] = 'بواسطة';

$txt['mc_reported_posts_desc'] = 'هنا تستطيع أن تشاهد كل تقارير المشاركة المرسلة من قبل أعضاء المنتدى.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'تقارير فعالة';
$txt['mc_reportedp_closed'] = 'تقارير قديمة';
$txt['mc_reportedp_by'] = 'بواسطة';
$txt['mc_reportedp_reported_by'] = 'تم التقرير بواسطة';
$txt['mc_reportedp_last_reported'] = 'تم الموافقة عليه أخيرا';
$txt['mc_reportedp_none_found'] = 'لم يتم إيجاد أية تقارير';

$txt['mc_reportedp_details'] = 'تفاصيل';
$txt['mc_reportedp_close'] = 'إغلاق';
$txt['mc_reportedp_open'] = 'فتح';
$txt['mc_reportedp_ignore'] = 'تجاهل';
$txt['mc_reportedp_unignore'] = 'اعادة فتح';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'هل أنت متأكد من أنك تريد أن تتجاهل تقارير مستقبلية عن هذه المشاركة؟

سوف يتم تعطيل التقارير المستقبلية لكل مشرفي المنتدى.';
$txt['mc_reportedp_close_selected'] = 'إغلاق';

$txt['mc_groupr_group'] = 'تحرير مجموعات الأعضاء';
$txt['mc_groupr_member'] = 'العضو';
$txt['mc_groupr_reason'] = 'السبب';
$txt['mc_groupr_none_found'] = 'لا يوجد حاليا أية طلبات للإنضمام الى أي مجموعة أعضاء بارزة';
$txt['mc_groupr_submit'] = 'أرسل';
$txt['mc_groupr_reason_desc'] = 'سبب رفض طلب العضو %sللانضمام في &quot;%s&quot;';
$txt['mc_groups_reason_title'] = 'أسباب الرفض';
$txt['with_selected'] = 'مع المختار';
$txt['mc_groupr_approve'] = 'الموافقة على الطلب';
$txt['mc_groupr_reject'] = 'رفض الطلب (بدون كتابة سبب الرفض)';
$txt['mc_groupr_reject_w_reason'] = 'رفض الطلب مع كتابة سبب الرفض';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'هل أنت متأكد من أنك تريد أن تفعل ذلك?';

$txt['mc_unapproved_attachments_none_found'] = 'لا توجد أية مرفقات غير موافق عليها!';
$txt['mc_unapproved_attachments_desc'] = 'هنا تستطيع أن تحذف أو توافق على أية مرفقات تنتظر مراجعة المشرف.';
$txt['mc_unapproved_replies_none_found'] = 'لا توجد أية مشاركات غير موافق عليها!';
$txt['mc_unapproved_topics_none_found'] = 'لا توجد أية مواضيع غير موافق عليها!';
$txt['mc_unapproved_posts_desc'] = 'هنا تستطيع أن تحذف أو توافق على أية مشاركات تنتظر مراجعة المشرف.';
$txt['mc_unapproved_replies'] = 'ردود';
$txt['mc_unapproved_topics'] = 'المواضيع';
$txt['mc_unapproved_by'] = 'بواسطة';
$txt['mc_unapproved_sure'] = 'هل أنت متأكد من فعل هذا؟';
$txt['mc_unapproved_attach_name'] = 'اسم المرفق';
$txt['mc_unapproved_attach_size'] = 'حجم الملف';
$txt['mc_unapproved_attach_poster'] = 'المرسل';
$txt['mc_viewmodreport'] = 'بلاغ للمشرف عن %1$s بواسطة %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'الأعضاء الذين كتبوا تقرير في هذه المشاركة';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'الأحداث التي قام بها المشرفون الآخرون';
$txt['mc_modreport_mod_comments'] = 'تعليقات المشرف';
$txt['mc_modreport_no_mod_comment'] = 'لا يوجد حاليا أي تعليقات للمشرفين';
$txt['mc_modreport_add_mod_comment'] = 'إضافة تعليق';

$txt['show_notice'] = 'نص الإنذار';
$txt['show_notice_subject'] = 'الموضوع';
$txt['show_notice_text'] = 'نص';

$txt['mc_watched_users_title'] = 'الأعضاء تحت المراقبة';
$txt['mc_watched_users_desc'] = 'هنا تستطيع أن تتابع كل الأعضاء الذين تم إضافتهم إلى قائمة &quot;تحت المراقبة&quot; بواسطة فريق الإشراف.';
$txt['mc_watched_users_post'] = 'عرض بواسطة المشاركات';
$txt['mc_watched_users_warning'] = 'مستوى التحذير';
$txt['mc_watched_users_last_login'] = 'المرة الأخيرة لتسجيل الدخول';
$txt['mc_watched_users_last_post'] = 'المشاركة الأخيرة';
$txt['mc_watched_users_no_posts'] = 'لا توجد أية مشاركات من الأعضاء تحت المراقبة.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'هل أنت متأكد من أنك تريد أن تقوم بحذف هذه المشاركة?';
$txt['mc_watched_users_delete_posts'] = 'هل أنت متأكد من أنك تريد حذف هذه الردود?';
$txt['mc_watched_users_posted'] = 'إرسل';
$txt['mc_watched_users_member'] = 'العضو';

$txt['mc_warnings_description'] = 'فى هذا القسم يمكنك مشاهدة التنبيهات التى قد قدمت فى أعضاء المنتدى . يمكنك أيضا إضافة و تعديل قوالب التنبيه المستخدمه فى إرسال تحذيرات للإعضاء .';
$txt['mc_warning_log'] = 'قائمة التحذير';
$txt['mc_warning_templates'] = 'قالب معدل';
$txt['mc_warning_log_title'] = 'مشاهدة سجل التحذير';
$txt['mc_warning_templates_title'] = 'تخصيص قالب للتحذيرات';

$txt['mc_warnings_none'] = 'لا يوجد أى تحذيرات .';
$txt['mc_warnings_recipient'] = 'المستقل';

$txt['mc_warning_templates_none'] = 'لم يتم إضافة أى قالب تحذيرى حتى الأن';
$txt['mc_warning_templates_time'] = 'زمن الإنشاء';
$txt['mc_warning_templates_name'] = 'القوالب';
$txt['mc_warning_templates_creator'] = 'أنشئت بواسطة';
$txt['mc_warning_template_add'] = 'إضافة قالب';
$txt['mc_warning_template_modify'] = 'تعديل قالب';
$txt['mc_warning_template_delete'] = 'حذف المختار';
$txt['mc_warning_template_delete_confirm'] = 'هل أنت متأكد من أنك تريد حذف القوالب التى قمت بإختيارها ؟';

$txt['mc_warning_template_desc'] = 'Use this page to fill in the details of the template. Note that the subject for the email is not part of the template. Note that as the notification is sent by PM you can use BBC within the template. If you use the {MESSAGE} variable then this template will not be available when issuing a generic warning (i.e. A warning not linked to a post).';
$txt['mc_warning_template_title'] = 'عنوان القالب';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'قالب خاص';
$txt['mc_warning_template_personal_desc'] = 'إذا قمت بتفعيل هذا الخيار فستكون أنت الوحيد القادر على مشاهدة,تعديل و إستخدام هذا القالب . أما إذا لم تقم بتفعيله فسوف يمكن هذا جميع المشرفين من إستخدام هذا القالب .';
$txt['mc_warning_template_error_no_title'] = 'يجب أن تكتب العنوان .';
$txt['mc_warning_template_error_no_body'] = 'يجب أن تكتب محتوى رسالة التحذير.';

$txt['mc_settings'] = 'تغير الإعدادات';
$txt['mc_prefs_title'] = 'تفضيلات الإشراف';
$txt['mc_prefs_desc'] = 'هذا القسم يسمح لك بتحديد التفضيلات الشخصية الخاصة بنشاطات الإشراف مثل تنبيهات الايميل.';
$txt['mc_prefs_homepage'] = 'العناصر التي ستظهر على صفحة الإشراف الرئيسة';
$txt['mc_prefs_latest_news'] = 'آخر أخبار ElkArte ';
$txt['mc_prefs_show_reports'] = 'أظهر عدد المواضيع المقرر عنها في اعلى صفحة المنتدى';
$txt['mc_prefs_notify_report'] = 'نبهني عن تقارير المواضيع';
$txt['mc_prefs_notify_report_never'] = 'ابدأ';
$txt['mc_prefs_notify_report_moderator'] = 'فقط في حال كنت مشرفا على المنتدى الذي يحوي الموضوع المقرر عنه';
$txt['mc_prefs_notify_report_always'] = 'دائما';
$txt['mc_prefs_notify_approval'] = 'نبهني على المواضيع التي تتطلب موافقة';
$txt['mc_logoff'] = 'انهاء جلسة الإشراف';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'إضافة ملاحظة جديدة';
$txt['mc_add_note'] = 'اضافة';