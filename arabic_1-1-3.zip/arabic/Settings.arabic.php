<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'القالب الافتراضي ElkArte.<br /><br />تصميم: مساهمو ElkArte ';