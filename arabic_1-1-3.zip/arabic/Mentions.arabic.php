<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'تنبيهاتي';
$txt['my_unread_mentions'] = 'التنبيهات الغير مقروءة';
$txt['my_mentions_pages'] = 'صفحة %1$d';
$txt['no_mentions_yet'] = 'لا يوجد اي اشارات';
$txt['no_new_mentions'] = 'لا يوجد اشارات جديدة';

$txt['mentions_from'] = 'العضو';
$txt['mentions_when'] = 'متى';
$txt['mentions_what'] = 'المشاركة';
$txt['mentions_all'] = 'اظهار الجميع';
$txt['mentions_unread'] = 'اظهار الغير مقروءة';
$txt['mentions_action'] = 'إجراءات';
$txt['mentions_delete_warning'] = 'هل أنت متأكد من أنك تريد حذف هذا السجل؟';
$txt['mentions_markread'] = 'تعليم كـ مقروء';
$txt['mentions_markunread'] = 'تعليم كـ غير مقروء';

$txt['mentions_settings'] = 'Notifications Settings';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = 'Enable site notifications';
$txt['mentions_buddy'] = 'اضف اشارة عند اضافة عضو الى قائمة اصدقاء شخص ما';
$txt['mentions_dont_notify_rlike'] = 'عدم تنبيه العضو عند حذف اعجاب من مشاركة ما';

$txt['mention_mentionmem'] = 'اشار اليك في المشاركة {msg_link}';
$txt['mention_likemsg'] = 'سجل اعجابه بمشاركتك {msg_link}';
$txt['mention_rlikemsg'] = 'حذف اعجابه بمشاركتك {msg_link}';
$txt['mention_buddy'] = 'قاموا باضافتك الى قائمة اصدقائهم';
$txt['mention_quotedmem'] = 'Quoted a message of yours in {msg_link}';
$txt['mention_mailfail'] = 'Disabled email notification due to delivery failure';

$txt['mentions_type_all'] = 'جميع الاشارات';
$txt['mentions_type_mentionmem'] = 'اشارات';
$txt['mentions_type_likemsg'] = 'اعجاب';
$txt['mentions_type_rlikemsg'] = 'حذف اعجاب';
$txt['mentions_type_buddy'] = 'صديق';
$txt['mentions_type_quotedmem'] = 'Quoted';
$txt['mentions_type_mailfail'] = 'Delivery Failure';

$txt['mentions_mark_all_read'] = 'تعليم هذه الاشارات كـ مقروءة';

$txt['setting_notify_enable_this'] = 'Enable user notifications of this event.';

$txt['setting_buddy'] = 'أصدقاء';
$txt['setting_likemsg'] = 'اعجاب';
$txt['setting_rlikemsg'] = 'Removed likes';
$txt['setting_mentionmem'] = '@mentions';
$txt['setting_quotedmem'] = 'Quoting';
$txt['setting_mailfail'] = 'Delivery Failures';