<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... no idea, sorry</em>';
$txt['who_admin'] = 'Viewing the admin portal';
$txt['who_moderate'] = 'Viewing the moderator portal';
$txt['who_generic'] = 'Viewing the %1$s';
$txt['who_unknown'] = '<em>حدث غير معروف</em>';
$txt['who_user'] = 'مستخدم';
$txt['who_time'] = 'الوقت';
$txt['who_action'] = 'الحدث';
$txt['who_show1'] = 'عرض';
$txt['who_show_members_only'] = 'الأعضاء فقط';
$txt['who_show_guests_only'] = 'الضيوف فقط';
$txt['who_show_spiders_only'] = 'عناكب الكترونية فقط';
$txt['who_show_all'] = 'الكل';
$txt['who_no_online_spiders'] = 'لا يوجد عناكب الكترونية متصلة الآن';
$txt['who_no_online_guests'] = 'لا يوجد ضيوف متصلون الآن';
$txt['who_no_online_members'] = 'لا يوجد أعضاء متصلون الآن';

$txt['whospider_login'] = 'مشاهدة صفحة تسجيل الدخول';
$txt['whospider_register'] = 'مشاهدة صفحة تسجيل حساب جديد';
$txt['whospider_reminder'] = 'مشاهدة صفحة التذكير';

$txt['whoall_activate'] = 'تنشيط حسابهم.';
$txt['whoall_buddy'] = 'يقوم بتعديل قائمة الأصدقاء الخاصة به .';
$txt['whoall_coppa'] = 'يقوم بملء نموذج موافقة ولى الأمر/الواصى .';
$txt['whoall_credits'] = 'يُشاهد صفحة الفضل .';
$txt['whoall_emailuser'] = 'إرسال بريد الكتروني إلى عضو آخر';
$txt['whoall_groups'] = 'مشاهدة صفحة مجموعات الأعضاء';
$txt['whoall_help'] = 'Viewing the <a href="{help_url}">help page</a>.';
$txt['whoall_quickhelp'] = 'مشاهدة نافذة المساعدة .';
$txt['whoall_pm'] = 'مشاهدة رسائلهم.';
$txt['whoall_auth'] = 'دخول في المنتدى.';
$txt['whoall_login'] = 'مشاهدة صفحة تسجيل الدخول';
$txt['whoall_login2'] = 'مشاهدة صفحة تسجيل الدخول';
$txt['whoall_logout'] = 'خروج من المنتدى.';
$txt['whoall_markasread'] = 'تعليم المواضيع كمقروءه او غير مقروءه.';
$txt['whoall_mentions'] = 'Viewing their mentions list.';
$txt['whoall_modifykarma_applaud'] = 'يقوم بزيادة الشعبية لعضو ما .';
$txt['whoall_modifykarma_smite'] = 'يقوم بإنقاص الشعبية الخاصة بعضو ما .';
$txt['whoall_news'] = 'مشاهدة الأخبار.';
$txt['whoall_notify'] = 'تغير إعدادات التنبيهات.';
$txt['whoall_notifyboard'] = 'تغير إعدادات التنبيهات.';
$txt['whoall_openidreturn'] = 'يقوم بتسجيل الدخول بإستخدام OpenID .';
$txt['whoall_quickmod'] = 'إدارة قسم ما .';
$txt['whoall_recent'] = 'Viewing a <a href="{recent_url}">list of recent topics</a>.';
$txt['whoall_register'] = 'تسجيل حساب جديد في المنتدى.';
$txt['whoall_reminder'] = 'طلب تذكير بكلمة المرور.';
$txt['whoall_reporttm'] = 'الإبلاغ عن موضوع للمشرف.';
$txt['whoall_spellcheck'] = 'يستخدم المدقق الإملائي';
$txt['whoall_unread'] = 'مشاهدة المواضيع الجديدة منذ آخر زيارة.';
$txt['whoall_unreadreplies'] = 'مشاهدة الردود الجديدة منذ آخر زيارة.';
$txt['whoall_who'] = 'Viewing <a href="{who_url}">Who\'s Online</a>.';

$txt['whoall_collapse_collapse'] = 'طي تصنيف.';
$txt['whoall_collapse_expand'] = 'توسيع تصنيف.';
$txt['whoall_pm_removeall'] = 'حذف كافة رسائلهم.';
$txt['whoall_pm_send'] = 'يرسل رسالة.';
$txt['whoall_pm_send2'] = 'يرسل رسالة.';

$txt['whotopic_announce'] = 'Announcing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'يقوم بالموافقة على مرفق ما .';
$txt['whotopic_dlattach'] = 'مشاهدة مرفق.';
$txt['whotopic_deletemsg'] = 'يقوم بحذف رسالة ما .';
$txt['whotopic_editpoll'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Modifying a post in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Liking a message in the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Locking the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Locking the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Merging the topic &quot;<a href="%1$s">%2$s</a>&quot; with another topic.';
$txt['whotopic_movetopic'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_movetopic2'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_post'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Printing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderating the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Removing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Removing the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Sending the topic &quot;<a href="%1$s">%2$s</a>&quot; to a friend.';
$txt['whotopic_splittopics'] = 'Splitting the topic &quot;<a href="%1$s">%2$s</a>&quot; into two topics.';
$txt['whotopic_sticky'] = 'Pinned the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Stopped watching a topic.';
$txt['whotopic_vote'] = 'Voting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Started watching a topic.';

$txt['whopost_quotefast'] = 'Quoting a post from &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'تحرير شروط التسجيل.';
$txt['whoadmin_featuresettings'] = 'تحرير خصائص و ميزات المنتدى .';
$txt['whoadmin_modlog'] = 'مشاهدة سجل المشرفين.';
$txt['whoadmin_serversettings'] = 'تحرير إعدادات المنتدى.';
$txt['whoadmin_packageget'] = 'جلب الرزم.';
$txt['whoadmin_packages'] = 'مشاهدة مدير الرزم.';
$txt['whoadmin_permissions'] = 'تحرير تصريحات المنتدى.';
$txt['whoadmin_pgdownload'] = 'تحميل رزمة.';
$txt['whoadmin_theme'] = 'تحرير إعدادات القالب.';
$txt['whoadmin_trackip'] = 'تعقب عنوان IP .';

$txt['whoallow_manageboards'] = 'تحرير إعدادات الأقسام و التصنيفات.';
$txt['whoallow_admin'] = 'Viewing the <a href="{admin_url}">administration center</a>.';
$txt['whoallow_ban'] = 'تحرير قائمة الحظر.';
$txt['whoallow_boardrecount'] = 'إعادة حساب إجمالي المنتدى.';
$txt['whoallow_calendar'] = 'Viewing the <a href="{calendar_url}">calendar</a>.';
$txt['whoallow_editnews'] = 'تحرير الأخبار.';
$txt['whoallow_mailing'] = 'بعث بريد عن طريق المنتدى.';
$txt['whoallow_maintain'] = 'صيانة المنتدى الدورية.';
$txt['whoallow_manageattachments'] = 'معالجة الملحقات.';
$txt['whoallow_moderate'] = 'Viewing the <a href="{moderate_url}">Moderation Center</a>.';
$txt['whoallow_memberlist'] = 'Viewing the <a href="{memberlist_url}">member list</a>.';
$txt['whoallow_optimizetables'] = 'تحسين فاعلية قاعدة البيانات.';
$txt['whoallow_repairboards'] = 'إصلاح جداول قاعدة البيانات.';
$txt['whoallow_search'] = '<a href="{search_url}">Searching</a> the forum.';
$txt['whoallow_search_results'] = 'مشاهدة نتائج البحث.';
$txt['whoallow_setcensor'] = 'تحرير النص المراقب.';
$txt['whoallow_setreserve'] = 'تحرير الأسماء المحجوزة.';
$txt['whoallow_stats'] = 'Viewing the <a href="{stats_url}">forum stats</a>.';
$txt['whoallow_viewErrorLog'] = 'مشاهدة سجل الأخطاء.';
$txt['whoallow_viewmembers'] = 'مشاهدة قائمة الأعضاء.';

$txt['who_topic'] = 'Viewing the topic <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Viewing the board <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Viewing the board index of <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Viewing <a href="%1$s">%2$s</a>\'s profile.';
$txt['who_profile'] = 'Editing the profile of <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Posting a new topic in <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Posting a new poll in <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Email starting a new topic in <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Email posting in <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Sending a personal message by email.';

// Credits text
$txt['credits'] = 'فريق المبرمجين';
$txt['credits_intro'] = 'ElkArte is 100% free and open-source. We encourage and support an active, open community that accepts contributions from the public.  We want to thank everyone who supported the project by providing code, feedback, bug reports, and opinions, as none of this would have been possible without you.  We also want to specially acknowledge <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, the project that ElkArte was born from.';
$txt['credits_contributors'] = 'Contributors';
$txt['credits_and'] = 'و';
$txt['credits_copyright'] = 'حقوق الملكية';
$txt['credits_forum'] = 'المنتدى';
$txt['credits_addons'] = 'Add-ons';
$txt['credits_software_graphics'] = 'Software/Graphics';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Graphics';
$txt['credits_fonts'] = 'Fonts';
$txt['credits_groups_contrib'] = 'Contributors';
$txt['credits_contrib_list'] = 'For a complete list of the many individuals that contributed to the design and implementation of Elkarte, please refer to the official GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">list of contributors.</a>';
$txt['credits_license'] = 'License';
$txt['credits_copyright'] = 'حقوق الملكية';
$txt['credits_version'] = 'الإصدار';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'مترجمي اللغات';
$txt['credits_translators_message'] = 'Thank you for your efforts which make it possible for people all around the world to use ElkArte.  For a complete list please refer to the offical Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">list of contributors.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';