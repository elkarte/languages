<?php
// Version: 1.1; Reports

$txt['generate_reports_desc'] = 'في هذا القسم تستطيع أن تولد مجموعة من التقارير التي ستساعدك في مهام إدارة المنتدى , ببساطة اتبع الخطوات الموجودة في الأسفل و اختر ماذا تريد';
$txt['generate_reports_continue'] = 'استمر';
$txt['generate_reports_type'] = 'اختر نوع التقرير';
$txt['gr_type_boards'] = 'معالجة المنتديات';
$txt['gr_type_desc_boards'] = 'تقرير يبين الإعدادات الحالية و مستويات الولوج للأقسام الموجودة في منتداك .';
$txt['gr_type_board_perms'] = 'التصاريح عن طريق المنتديات';
$txt['gr_type_desc_board_perms'] = 'يولد تقرير يبين فيه الصلاحيات التي تتمتع بها مجموعات الأعضاء في مختلف الأقسام في منتداك .';
$txt['gr_type_member_groups'] = 'تحرير مجموعات الأعضاء';
$txt['gr_type_desc_member_groups'] = 'تقرير يبين إعدادات كل مجموعة من مجموعات الأعضاء في منتداك .';
$txt['gr_type_group_perms'] = 'صلاحيات المجموعات';
$txt['gr_type_desc_group_perms'] = 'تقرير عن صلاحيات كل مجموعة من مجموعات الأعضاء في منتداك .';
$txt['gr_type_staff'] = 'الفريق';
$txt['gr_type_desc_staff'] = 'هذا التقرير هو مُلخص لكل الأعضاء الذين لهم سُلطات في منتداك .';

$txt['full_member'] = 'عضو فعال';
$txt['results'] = 'نتائج';

// Board permissions
$txt['board_perms_permission'] = 'الصلاحية';
$txt['board_perms_allow'] = 'السماح';
$txt['board_perms_deny'] = 'منع';
$txt['board_perms_name_announce_topic'] = 'موضوع الاعلان';
$txt['board_perms_name_approve_posts'] = 'الموافقة على المشاركات';
$txt['board_perms_name_delete_any'] = 'حذف أي رسالة';
$txt['board_perms_name_delete_own'] = 'حذف رسائلهم ';
$txt['board_perms_name_delete_replies'] = 'حذف الردود على المواضيع الشخصية';
$txt['board_perms_name_lock_any'] = 'إغلاق أي موضوع';
$txt['board_perms_name_lock_own'] = 'إغلاق مواضيعهم';
$txt['board_perms_name_make_sticky'] = 'تثبيت الموضوعات';
$txt['board_perms_name_mark_any_notify'] = 'طلب التنبيه لأي موضوع';
$txt['board_perms_name_mark_notify'] = 'طلب التنبيه لمواضيعهم';
$txt['board_perms_name_merge_any'] = 'دمج المواضيع';
$txt['board_perms_name_moderate_board'] = 'الإشراف على القسم';
$txt['board_perms_name_modify_any'] = 'تعديل أية رسالة';
$txt['board_perms_name_modify_own'] = 'تعديل رسائلهم';
$txt['board_perms_name_modify_replies'] = 'تعديل الردود على مواضيعك';
$txt['board_perms_name_move_any'] = 'نقل أي موضوع';
$txt['board_perms_name_move_own'] = 'نقل مواضيعهم';
$txt['board_perms_name_poll_add_any'] = 'إضافة استفتاء لأي موضوع';
$txt['board_perms_name_poll_add_own'] = 'إضافة استفتاء لمواضيعهم';
$txt['board_perms_name_poll_edit_any'] = 'تعديل أي استفتاء';
$txt['board_perms_name_poll_edit_own'] = 'تعديل استفتاءاتهم';
$txt['board_perms_name_poll_lock_any'] = 'إغلاق أي استفتاء';
$txt['board_perms_name_poll_lock_own'] = 'إغلاق استفتاءاتهم';
$txt['board_perms_name_poll_post'] = 'إرسال استفتاء جديد';
$txt['board_perms_name_poll_remove_any'] = 'حذف أي استفتاء';
$txt['board_perms_name_poll_remove_own'] = 'حذف استفتاءاتهم';
$txt['board_perms_name_poll_view'] = 'مشاهدة الإستفتاءات';
$txt['board_perms_name_poll_vote'] = 'تصويت على الإستفتاءات';
$txt['board_perms_name_post_attachment'] = 'إضافة ملحقات';
$txt['board_perms_name_post_new'] = 'كتابة مواضيع جديدة';
$txt['board_perms_name_post_reply_any'] = 'إرسال ردود لأي موضوع';
$txt['board_perms_name_post_reply_own'] = 'إرسال ردود لمواضيعهم';
$txt['board_perms_name_post_unapproved_attachments'] = 'إرسال مرفقات غير موافق عليها';
$txt['board_perms_name_post_unapproved_topics'] = 'إرسال مواضيع غير موافق عليها';
$txt['board_perms_name_post_unapproved_replies_any'] = 'إرسال ردود غير موافق عليها في أي موضوع';
$txt['board_perms_name_post_unapproved_replies_own'] = 'إرسال ردود غير موافق عليها في مواضيعهم';
$txt['board_perms_name_remove_any'] = 'حذف أي موضوع';
$txt['board_perms_name_remove_own'] = 'حذف مواضيعهم';
$txt['board_perms_name_report_any'] = 'الإبلاغ عن اى موضوع';
$txt['board_perms_name_send_topic'] = 'بعث المواضيع إلى أصدقاء';
$txt['board_perms_name_split_any'] = 'فصل أي موضوع';
$txt['board_perms_name_view_attachments'] = 'مشاهدة الملحقات';

$txt['board_perms_group_no_polls'] = 'هذا القسم لا يسمح بوجود إستفتاءات';
$txt['board_perms_group_reply_only'] = 'هذا القسم يسمح للمستخدمين بالرد على المواضيع الموجودة مسبقا فقط';
$txt['board_perms_group_read_only'] = 'هذا القسم لا يسمح بإرسال مُشاركات';

// Membergroup info!
$txt['member_group_color'] = 'لون';
$txt['member_group_min_posts'] = 'أقل عدد للرسائل';
$txt['member_group_max_messages'] = 'أكبر عدد للرسائل الشخصية';
$txt['member_group_icons'] = 'أيقونات';
$txt['member_group_settings'] = 'الإعدادات';
$txt['member_group_access'] = 'صلاحية الدخول للقسم';

// Board info.
$txt['none'] = 'لا شيء';
$txt['board_category'] = 'تصنيف';
$txt['board_parent'] = 'فرعى من';
$txt['board_num_topics'] = 'عدد المواضيع';
$txt['board_num_posts'] = 'عدد الرسائل';
$txt['board_count_posts'] = 'حساب الرسائل';
$txt['board_theme'] = 'قالب القسم';
$txt['board_override_theme'] = 'إستايل إجبارى للقسم';
$txt['board_profile'] = 'تصاريح الحساب';
$txt['board_moderators'] = 'مشرفين';
$txt['board_groups'] = 'المجموعات التي لها حق الوصول';
$txt['board_disallowed_groups'] = 'مجموعات ليس لها حق الوصول';

// Group Permissions.
$txt['group_perms_name_access_mod_center'] = 'الوصول الى مركز الإشراف';
$txt['group_perms_name_admin_forum'] = 'منتدى المشرف الرئيس';
$txt['group_perms_name_calendar_edit_any'] = 'تعديل أي حدث';
$txt['group_perms_name_calendar_edit_own'] = 'تعديل أحداثهم';
$txt['group_perms_name_calendar_post'] = 'إرسال أحداث';
$txt['group_perms_name_calendar_view'] = 'مشاهدة الأحداث';
$txt['group_perms_name_edit_news'] = 'تعديل أخبار المنتدى';
$txt['group_perms_name_issue_warning'] = 'إرسال تحذيرات';
$txt['group_perms_name_karma_edit'] = 'تعديل الشعبية للمستخدمين';
$txt['group_perms_name_manage_attachments'] = 'إدارة المرفقات';
$txt['group_perms_name_manage_bans'] = 'إدارة الحظر';
$txt['group_perms_name_manage_boards'] = 'إدارة الأقسام';
$txt['group_perms_name_manage_membergroups'] = 'ادارة المجموعات المنتسب لها العضو';
$txt['group_perms_name_manage_permissions'] = 'معالجة التصريحات';
$txt['group_perms_name_manage_smileys'] = 'معالجة الابتسامات';
$txt['group_perms_name_moderate_forum'] = 'الإشراف على المنتدى';
$txt['group_perms_name_pm_read'] = 'قراءة الرسائل الشخصية';
$txt['group_perms_name_pm_send'] = 'بعث رسائل شخصية';
$txt['group_perms_name_profile_extra_any'] = 'تعديل أية خيارات إضافية';
$txt['group_perms_name_profile_extra_own'] = 'تعديل خياراتهم الإضافية';
$txt['group_perms_name_profile_identity_any'] = 'تعديل إعدادات أي حساب';
$txt['group_perms_name_profile_identity_own'] = 'تعديل خيارات حسابهم الشخصي';
$txt['group_perms_name_profile_set_avatar'] = 'إختيار صورة شخصيه';
$txt['group_perms_name_profile_remove_any'] = 'حذف أي حساب';
$txt['group_perms_name_profile_remove_own'] = 'حذف حسابهم';
$txt['group_perms_name_profile_title_any'] = 'تعديل أي عنوان نص شخصي';
$txt['group_perms_name_profile_title_own'] = 'تعديل عنوان نصهم الشخصي';
$txt['group_perms_name_profile_view_any'] = 'مشاهدة أية حساب';
$txt['group_perms_name_profile_view_own'] = 'مشاهدة حساباتهم الشخصية';
$txt['group_perms_name_search_posts'] = 'البحث عن الرسائل';
$txt['group_perms_name_send_mail'] = 'بعث بريد إلى الأعضاء';
$txt['group_perms_name_view_mlist'] = 'مشاهدة قائمة الأعضاء.';
$txt['group_perms_name_view_stats'] = 'مشاهدة إحصائيات المنتدى';
$txt['group_perms_name_who_view'] = 'مشاهدة المُتصلين الأن';

$txt['report_error_too_many_staff'] = 'لديك عدد كبير من اعضاء طاقم العمل.التقرير لن يعمل بأكثر من 300 شخص في التقرير الواحد';
$txt['report_staff_position'] = 'المنصب';
$txt['report_staff_moderates'] = 'مشرف على';
$txt['report_staff_posts'] = 'مشاركة';
$txt['report_staff_last_login'] = 'المرة الأخيرة لتسجيل الدخول';
$txt['report_staff_all_boards'] = 'كل الأقسام';
$txt['report_staff_no_boards'] = 'لا يوجد أقسم هذا العضو مُشرف عليها';