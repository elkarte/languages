<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'إستمرار';
$txt['package_id'] = 'رقم العضوية';
$txt['list_file'] = 'عرض الملفات في الرزمة';
$txt['files_archive'] = 'الملفات في الأرشيف';
$txt['package_browse'] = 'استعرض';
$txt['add_server'] = 'إضافة ملقم';
$txt['server_name'] = 'اسم المُستضيف';
$txt['serverurl'] = 'الرابط الاكتروني';
$txt['no_packages'] = 'لا يوجد رزم حاليا.';
$txt['download'] = 'تحميل';
$txt['download_success'] = 'تم تحميل الرزمة بنجاح';
$txt['package_downloaded_successfully'] = 'تم تحميل الرزمة بنجاح';
$txt['package_manager'] = 'مدير الرزم';
$txt['install_mod'] = 'Install Add-on';
$txt['uninstall_mod'] = 'Uninstall Add-on';
$txt['no_adds_installed'] = 'No addons currently installed';
$txt['uninstall'] = 'إلغاء التثبيت';
$txt['delete_list'] = 'Delete Add-on List';
$txt['package_delete_list_warning'] = 'Are you sure you wish to clear the installed addons list?';

$txt['package_manager_desc'] = 'From this easy to use interface, you can download and install addons for use on your forum.';
$txt['installed_packages_desc'] = 'في الاسفل ستجد الرزم المُثبتة و يمكنك حذفها في حالة عدم الحاجة لها.';
$txt['download_packages_desc'] = 'From this section you can add or remove package servers, browse for packages, or download new packages from servers.';
$txt['package_servers_desc'] = 'From this easy to use interface, you can manage your package servers and download addon archives on your forum.';
$txt['upload_packages_desc'] = 'From this section you can upload a package file from your local computer directly to the forum.';

$txt['upload_new_package'] = 'Upload new package';
$txt['view_and_remove'] = 'View and remove installed packages';
$txt['modification_package'] = 'Add-on packages';
$txt['avatar_package'] = 'Avatar packages';
$txt['language_package'] = 'Language packages';
$txt['unknown_package'] = 'Other packages';
$txt['smiley_package'] = 'Smiley packages';
$txt['use_avatars'] = 'إستخدام الصور الشخصية';
$txt['add_languages'] = 'إضافة لغه';
$txt['list_files'] = 'قائمة الملفات';
$txt['package_type'] = 'نوع الرزمة';
$txt['extracting'] = 'فك ضغط';
$txt['avatars_extracted'] = 'The avatars have been installed, you should now be able to use them.';
$txt['language_extracted'] = 'The language pack has been installed, you can now enable its use in the language settings area of your admin control panel.';

$txt['mod_name'] = 'Add-on Name';
$txt['mod_version'] = 'الإصدار';
$txt['mod_author'] = 'المؤلف';
$txt['author_website'] = 'صفحة المؤلف';
$txt['package_no_description'] = 'No description given';
$txt['package_description'] = 'الوصف';
$txt['file_location'] = 'تحميل';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'No source edits';
$txt['mod_date'] = 'Last updated';
$txt['mod_section_count'] = 'Browse the (%1d) addons in this section';

// Package Server strings
$txt['package_current'] = '(%s <em>You have the Current version %s</em>)';
$txt['package_update'] = '(%s <em>An update for your %s version is available</em>)';
$txt['package_installed'] = 'installed';
$txt['package_downloaded'] = 'حمل';

$txt['package_installed_key'] = 'Installed addons:';
$txt['package_installed_current'] = 'الإصدار الحالي';
$txt['package_installed_old'] = 'إصدار قديم';
$txt['package_installed_warning1'] = 'This package is already installed, and no upgrade was found.';
$txt['package_installed_warning2'] = 'يفضل حذف النسخة الأقدم قبل تثبيت الجديدة أو الحصول على ترقية من المؤلف إذا أمكن ذلك، لتجنب المشاكل.';
$txt['package_installed_warning3'] = 'الرجاء الحرص على أخذ نسخ احتياطية لملفات النظام و قاعدة البيانات بشكل دوري قبل تثبيت أي معدل، وبالأخص إذا كان في طور التجربة.';
$txt['package_installed_extract'] = 'فك ضغط الرزمة';
$txt['package_installed_done'] = 'تم تثبيت الرزمة بنجاح.  يمكنك الآن أن تستخدم أية ميزة تم إضافتها أو حذفها بواسطة الرزمة.';
$txt['package_installed_redirecting'] = 'توجيه...';
$txt['package_installed_redirect_go_now'] = 'توجيه الآن';
$txt['package_installed_redirect_cancel'] = 'العودة إلى مدير الرزم';

$txt['package_upgrade'] = 'ترقية';
$txt['package_uninstall_readme'] = 'ملف إقرأنى الخاص بإلغاء التثبيت';
$txt['package_install_readme'] = 'ملف إقرأنى الخاص بالتثبيت';
$txt['package_install_license'] = 'License';
$txt['package_install_type'] = 'النوع';
$txt['package_install_action'] = 'الحدث';
$txt['package_install_desc'] = 'الوصف';
$txt['install_actions'] = 'أحداث التثبيت';
$txt['perform_actions'] = 'This will perform the following actions:';
$txt['corrupt_compatible'] = 'The package you are trying to download or install is either corrupt or not compatible with this version of the software.';
$txt['package_create'] = 'إنشاء';
$txt['package_move'] = 'نقل';
$txt['package_delete'] = 'حذف';
$txt['package_extract'] = 'فك الضغط';
$txt['package_file'] = 'الملف';
$txt['package_tree'] = 'شجرة';
$txt['execute_modification'] = 'تنفيذ المعدل';
$txt['execute_code'] = 'تنفيذ الكود';
$txt['execute_database_changes'] = 'Execute file';
$txt['execute_hook_add'] = 'Add Hook';
$txt['execute_hook_remove'] = 'Remove Hook';
$txt['execute_hook_action'] = 'Adapting hook %1$s';
$txt['package_requires'] = 'Requires Modification';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Add Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'تثبيت الرزمة';
$txt['package_will_fail_title'] = 'Error in package %1$s';
$txt['package_will_fail_warning'] = 'At least one error was encountered during a test %1$s of this package.<br />It is <strong>strongly</strong> recommended that you do not continue with %1$s unless you know what you are doing, and have made a backup very recently.<br /><br />This error may be caused by a conflict between the package you\'re trying to install and another package you have already installed, an error in the package, a package which requires another package that you have not installed yet, or a package designed for another version of the software.';
$txt['package_will_fail_unknown_action'] = 'The package is trying to perform an unknown action: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Are you sure you wish to continue installing this addon, even though it will not install successfully?';
$txt['package_will_fail_popup_uninstall'] = 'Are you sure you wish to continue uninstalling this addon, even though it will not uninstall successfully?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'removal';
$txt['package_install_now'] = 'Install now';
$txt['package_uninstall_now'] = 'Uninstall now';
$txt['package_other_themes'] = 'Install in other themes';
$txt['package_other_themes_uninstall'] = 'UnInstall in other themes';
$txt['package_other_themes_desc'] = 'To use this addon in themes other than the default, the package manager needs to make additional changes to the other themes. If you\'d like to install this addon in the other themes, please select these themes below.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'على الأقل خطأ واحد قد حدث خلال تجربة تثبيت هذه السمة. هل أنت متأكد من أنك تريد الاستمرار في تثبيت السمة ?';

$txt['package_bytes'] = 'بايت';

$txt['package_action_missing'] = '<strong class="error">الملف غير موجود</strong>';
$txt['package_action_error'] = '<strong class="error">خطا لمعرب المعدل</strong>';
$txt['package_action_failure'] = '<strong class="error"> فشل الإختبار</strong>';
$txt['package_action_success'] = '<strong>نجح الإختبار</strong>';
$txt['package_action_skipping'] = '<strong>تخطي الملف</strong>';

$txt['package_uninstall_actions'] = 'إجراءات إلغاء التثبيت';
$txt['package_uninstall_done'] = 'The package has been successfully uninstalled.';
$txt['package_uninstall_cannot'] = 'This package cannot be uninstalled, because there is no uninstaller.<br /><br />Please contact the addon author for more information.';

$txt['package_install_options'] = 'خيارات التثبيت';
$txt['package_install_options_desc'] = 'Set various options for how the package manager installs addons, including backups and ftp access';
$txt['package_install_options_ftp_why'] = 'استخدام FTP هي الطريقة الأسهل للتعامل مع الرزم بدلا من الطريقة اليدوية التي تحتاج إلى تغير خصائص الملفات.<br />يمكنك هنا أن تقوم بإدخال القيم لبعض الحقول.';
$txt['package_install_options_ftp_server'] = 'سيرفر FTP ';
$txt['package_install_options_ftp_port'] = 'المنفذ';
$txt['package_install_options_ftp_user'] = 'اسم المستخدم';
$txt['package_install_options_make_backups'] = 'إنشاء نسخ احتياطية للملفات التي ستستبدل مع وضع علامة (~) في نهاية الاسم.';
$txt['package_install_options_make_full_backups'] = 'Create an entire backup (excluding smileys, avatars and attachments) of the ElkArte install.';

$txt['package_ftp_necessary'] = 'FTP المعلومات مطلوبة';
$txt['package_ftp_why'] = 'Some of the files the package manager needs to modify are not writable.  This needs to be changed by logging into FTP and using it to chmod or create the files and directories.  Your FTP information may be temporarily cached for proper operation of the package manager. Note you can also do this manually using an FTP client - <a href="#" onclick="%1$s">to view a list of the affected files please click here</a>.';
$txt['package_ftp_why_file_list'] = 'الملفات التالية يجب جعلها قابلة للكتابة لكي يتم إكمال عملية التثبيت:';
$txt['package_ftp_why_download'] = 'In order to download packages, the packages directory, and any files in it, must be writable.  Currently the system does not have the needed permissions to write to this directory.  The package manager can use your FTP information to attempt to fix this problem.';
$txt['package_ftp_server'] = 'سيرفر FTP ';
$txt['package_ftp_port'] = 'المنفذ';
$txt['package_ftp_username'] = 'اسم المستخدم';
$txt['package_ftp_password'] = 'كلمة المرور';
$txt['package_ftp_path'] = 'Local path to ElkArte';
$txt['package_ftp_test'] = 'تجربة';
$txt['package_ftp_test_connection'] = 'اختبار الاتصال';
$txt['package_ftp_test_success'] = 'تم تحقيق اتصال FTP ';
$txt['package_ftp_test_failed'] = 'لم يستطع الاتصال بالسيرفر';
$txt['package_ftp_bad_server'] = 'لم يستطع الاتصال بالسيرفر';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'الرزمة التي تحاول حذفها مثبتة الآن!  إذا قمت بحذفها, قد لا تتمكن من إلغاء تثبيتها لاحقا.\\n\\nهل ترغب في ذلك حقا؟';

$txt['package_examine_file'] = 'مشاهدة الملف في الرزمة';
$txt['package_file_contents'] = 'محتويات الملف';

$txt['package_upload_title'] = 'تحميل رزمة';
$txt['package_upload_select'] = 'الرزمة التي ستحمل';
$txt['package_upload'] = 'تحميل';
$txt['package_uploaded_success'] = 'تم تحميل الرزمة بنجاح';
$txt['package_uploaded_successfully'] = 'تم تحميل الرزمة بنجاح';

$txt['package_modification_malformed'] = 'Malformed or invalid addon file.';
$txt['package_modification_missing'] = 'لا يمكن العثور على الملف.';
$txt['package_no_zlib'] = 'نأسف ولكن إعدادات PHP لا تمتلك الدعم لمكتبة <strong>zlib</strong>.  بدونها لا يمكن لمدير الرزم العمل.  الرجاء مراجعة مستضيفك لمزيد من المعلومات.';

$txt['package_cleanperms_title'] = 'تنظيف التصاريح';
$txt['package_cleanperms_desc'] = 'هنا واجهة تسمح لك لإعادة تهيئة الصلاحيات للملفات من خلال تثبيتك, لذلك من أجل أن تزيد الأمن أو من أجل حل أية مشاكل صلاحيات قد تواجهها خلال عملية تثبت الرزم.';
$txt['package_cleanperms_type'] = 'تغير كل صلاحيات الملف من خلال المنتدى مثل ذلك';
$txt['package_cleanperms_standard'] = 'فقط الملفات الأساسية قابلة للكتابة.';
$txt['package_cleanperms_free'] = 'كل الملفات قابلة للكتابة.';
$txt['package_cleanperms_restrictive'] = 'الحد الأدنى من الملفات قابلة للكتابة.';
$txt['package_cleanperms_go'] = 'تغير تصاريح الملف';

$txt['package_download_by_url'] = 'تنزيل رزمة من خلال url';
$txt['package_download_filename'] = 'اسم الملف';
$txt['package_download_filename_info'] = 'قيمة اختيارية.  يجب أن يتم استخدامها عندما لاينتهي الـ url باسم الملف. كمثال: index.php?mod=5';

$txt['package_db_uninstall'] = 'Remove all data associated with this addon.';
$txt['package_db_uninstall_details'] = 'تفاصيل';
$txt['package_db_uninstall_actions'] = 'Checking this option will result in the following actions';
$txt['package_db_remove_table'] = 'حذف الجدول &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'حذف عمود &quot;%2$s&quot; من &quot;%1$s&quot;';
$txt['package_db_remove_index'] = 'حذف فهرس &quot;%1$s&quot; من &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Install Emulating:';
$txt['package_emulate_uninstall'] = 'Uninstall Emulating:';

// Operations.
$txt['operation_find'] = 'ابحث عن';
$txt['operation_replace'] = 'استبداله بـ';
$txt['operation_after'] = 'أضف بعده';
$txt['operation_before'] = 'أضف قبله';
$txt['operation_title'] = 'عمليات';
$txt['operation_ignore'] = 'تجاهل الأخطاء';
$txt['operation_invalid'] = 'العملية التى قمت بإختارها غير صحيحه .';

$txt['package_file_perms_desc'] = 'من هنا يمكنك مشاهدة و معرفة تصريحات الملفات و المجلدات الخاصه بموقعك . لاحظ ان الملفات و المجلدات التاليه هى ملفات و مجلدات مفتاحيه/رئيسيه - قم بإستخدم حساب FTP إذا أردت خيارات إضافيه .';
$txt['package_file_perms_name'] = 'File/Directory Name';
$txt['package_file_perms_status'] = 'الوضع الحالي';
$txt['package_file_perms_new_status'] = 'الوضع الجديد';
$txt['package_file_perms_status_read'] = 'زيارة';
$txt['package_file_perms_status_write'] = 'كتابة';
$txt['package_file_perms_status_execute'] = 'تنفيذ';
$txt['package_file_perms_status_custom'] = 'مخصص';
$txt['package_file_perms_status_no_change'] = 'بلا تغيير';
$txt['package_file_perms_writable'] = 'قابل للكتابة';
$txt['package_file_perms_not_writable'] = 'الكتابة غير مسموحة';
$txt['package_file_perms_chmod'] = 'تغيير صلاحيات الملفات';
$txt['package_file_perms_more_files'] = 'مزيد من الملفات';

$txt['package_file_perms_change'] = 'تغيير صلاحيات الملف';
$txt['package_file_perms_predefined'] = 'إستخدم الصلاحيات المحددة مسبقا ';
$txt['package_file_perms_predefined_note'] = 'Note that this only applies the predefined profile to key directories and files.';
$txt['package_file_perms_apply'] = 'تطبيق الإعدادت الفردية لتصاريح الملفات المختارة أعلاه .';
$txt['package_file_perms_custom'] = 'إذا كان الخيار &quot;مخصص&quot; قد تم إختياره فقم بإستخدام قيمة التصريح ';
$txt['package_file_perms_pre_restricted'] = 'مقييد - الحد الأدنى من الملفات قابلة للكتابة ';
$txt['package_file_perms_pre_standard'] = 'قياسى - الملفات الرئيسية قابلة للكتابة ';
$txt['package_file_perms_pre_free'] = 'حر - جميع الملفات قابلة للكتابة';
$txt['package_file_perms_ftp_details'] = 'فى معظم السيرفرات يجب إستخدام حساب FTP لتغيير صلاحيات الملفات . من فضلك أكتب بيانات حساب الـ FTP بالأسفل ';
$txt['package_file_perms_ftp_retain'] = 'Note, the system will only retain the password information temporarily to aid operation of the package manager.';
$txt['package_file_perms_go'] = 'إجراء التغييرات';

$txt['package_file_perms_applying'] = 'تطبيق التغييرات';
$txt['package_file_perms_items_done'] = '%1$d من %2$d ملف تم الإنتهاء منه ';
$txt['package_file_perms_skipping_ftp'] = '<strong>تحذير:</strong> غير قادر على الاتصال بسيرفر الـ FTP , لمحاولة تغيير التصاريح. هذا <em>من المحتمل</em> ان يفشل - يرجى التأكد من ان البيانات صحيحة و حاول مرة اخرى , قم بتغيير بيانات الـ FTP إذا لذم الأمر.';

$txt['package_file_perms_dirs_done'] = '%1$d من %2$d مجلدات تم الإنتهاء منهم';
$txt['package_file_perms_files_done'] = '%1$d من %2$d ملفات تم الإنتهاء منهم فى المجلد الحالى ';

$txt['chmod_value_invalid'] = 'لقد قمت بكتاية قيمة تصريح غير صحيحه. قيمة التصريح يجب ان تكون بين الـ 0444 و 0777 ';

$txt['package_restore_permissions'] = 'Restore file permissions';
$txt['package_restore_permissions_desc'] = 'The following file permissions were changed in order to install the selected package(s). You can return these files back to their original status by clicking &quot;Restore&quot; below.';
$txt['package_restore_permissions_restore'] = 'استعادة';
$txt['package_restore_permissions_filename'] = 'اسم الملف';
$txt['package_restore_permissions_orig_status'] = 'الوصع الأصلي';
$txt['package_restore_permissions_cur_status'] = 'الوضع الحالي';
$txt['package_restore_permissions_result'] = 'النتيجة';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - كان %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>تخطى</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Success</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">فشل</span>';
$txt['package_restore_permissions_action_done'] = 'An attempt to restore the selected files back to their original permissions has been completed, the results can be seen below. If a change failed, or for a more detailed view of file permissions, please see the <a href="%1$s">File Permissions</a> section.';

$txt['package_file_perms_warning'] = 'نرجو الملاحظة';
$txt['package_file_perms_warning_desc'] = '
	Be careful when changing file permissions from this section - incorrect permissions can adversely affect the operation of your forum!<br />
	On some server configurations selecting the wrong permissions may stop the forum from operating.<br />
	Certain directories such as <em>attachments</em> need to be writable to use that functionality.<br />
	This functionality is mainly applicable on non-Windows based servers - it will not work as expected on Windows in regards to permission flags.<br />
	Before proceeding make sure you have an FTP client installed in case you do make an error and need to FTP into the server to remedy it.';

$txt['package_confirm_view_package_content'] = 'هل أنت متأكد من أنك تريد مشاهدة محتويات هذه الرزمه من هنا :<br /><br />%1$s ';
$txt['package_confirm_proceed'] = 'إستمرار';
$txt['package_confirm_go_back'] = 'العودة';

$txt['package_readme_default'] = 'الافتراضي';
$txt['package_available_readme_language'] = 'اللغة المتاحة الخاصة بملف إقرأنى :';
$txt['package_license_default'] = 'الافتراضي';
$txt['package_available_license_language'] = 'Available License Languages:';