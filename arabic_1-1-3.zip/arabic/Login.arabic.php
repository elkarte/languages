<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'اتفاقية التسجيل';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'أوافق على الشروط الموجودة فى إتفاقية التسجيل .';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'أوافق على الشروط الموجودة فى إتفاقية التسجيل و عمرى أكبر من %1$d عام.';
$txt['agreement_agree_coppa_below'] = 'أوافق على الشروط الموجودة فى إتفاقية التسجيل و عمرى أصغر من %1$d عام.';
$txt['agree_coppa_above'] = 'انا عمري  %1$d سنة على الاقل.';
$txt['agree_coppa_below'] = 'انا عمري اقل من  %1$d سنة.';

// Registration form.
$txt['registration_form'] = 'نموذج التسجيل';
$txt['error_too_quickly'] = 'لقد انهيت اجراءات تسجيل حساب جديد بسرعة مريبة ، فضلا انتظر لحظة وجاول مرة ثانية .';
$txt['error_token_verification'] = 'فشل في التحقق . الرجاء العودة و المحاولة مرة أخرى.';
$txt['need_username'] = 'يجب كتابة اسم المستخدم.';
$txt['no_password'] = 'خانة كلمة المرور خالية';
$txt['improper_password'] = 'كلمة السر التي تحاول استخدامها طويلة جدا.';
$txt['incorrect_password'] = 'كلمة المرور خاطئة';
$txt['openid_not_found'] = 'هوية OpenID التي ادخلتها غير موجودة';
$txt['maintain_mode'] = 'نمط الصيانة';
$txt['registration_successful'] = 'تم التسجيل بنجاح';
$txt['valid_email_needed'] = 'الرجاء إدخال بريد صحيح, %1$s.';
$txt['required_info'] = 'معلومات مطلوبة';
$txt['additional_information'] = 'معلومات إضافية';
$txt['warning'] = 'تحذير!';
$txt['only_members_can_access'] = 'الأعضاء المُسجَلٍيّن فقط يٌمكنهم الدخول الى هذا القسم .';
$txt['login_below'] = 'الرجاء تسجيل الدخول في الأسفل';
$txt['login_below_or_register'] = 'فضلا قم بتسجيل الدخول في الاسفل أو  <a href="%1$s">انشاء حساب جديد</a>  مع %2$s';
$txt['checkbox_agreement'] = 'أوافق على الشروط الموجودة فى إتفاقية التسجيل .';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'تم تحديث نظام كلمة السر. <br />يرجى ادخال كلمة السر مرة اخرى.';

$txt['ban_register_prohibited'] = 'عذرا، غير مسموح لك بالتسجيل في  هذا المنتدى.';
$txt['under_age_registration_prohibited'] = 'عذرا، الاعضاء تحت سن %1$d غير مسموح لهم بالتسجيل في هذا المنتدى.';

$txt['activate_account'] = 'تنشيط الحساب';
$txt['activate_success'] = 'تم تنشيط حسابك بنجاح. يمكنك الآن مواصلة تسجيل الدخول.';
$txt['activate_not_completed1'] = 'يجب عليك أولاً تأكيد بريدك الإلكترونى قبل تسجيل الدخول.';
$txt['activate_not_completed2'] = 'هل تحتاج إلى بريد التفعيل مرة أخرى؟';
$txt['activate_after_registration'] = 'شكرا على التسجيل. سيصلك بريد لتنشيط حسابك قريبا. إذا لم يصلك على صندوق الوارد فقم بالبحث عنه فى صندوق الرسائل المزعجة .';
$txt['invalid_userid'] = 'المستخدم غير موجود';
$txt['invalid_activation_code'] = 'كود التنشيط غير صحيح';
$txt['invalid_activation_username'] = 'اسم المستخدم أو البريد';
$txt['invalid_activation_new'] = 'إذا قمت بالتسجيل مستخدما بريد غير صحيح ، فاكتب البريد الصحيح و كلمة المرور هنا.';
$txt['invalid_activation_new_email'] = 'عنوان بريد جديد';
$txt['invalid_activation_password'] = 'كلمة المرور القديمة';
$txt['invalid_activation_resend'] = 'اعد إرسال كود التنشيط';
$txt['invalid_activation_known'] = 'إذا كنت تعرف كود التنشيط ، فالرجاء كتابته هنا.';
$txt['invalid_activation_retry'] = 'كود التنشيط';
$txt['invalid_activation_submit'] = 'تنشيط';

$txt['coppa_no_concent'] = 'لم يستلم المدير موافقة الأب/الواصى عليك من أجل حسابك.';
$txt['coppa_need_more_details'] = 'تحتاج المزيد من المعلومات؟';

$txt['awaiting_delete_account'] = 'تم تحديد حسابك من اجل الحذف!<br />اذا اردت اعادة حسابك، يرجى مراجعة صندوق &quot;اعادة تفعيل حسابي&quot; و اعادة الدخول ثانية.';
$txt['undelete_account'] = 'اعادة تنشيط حسابي';

$txt['in_maintain_mode'] = 'المنتدى في حالة صيانة.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'الرجاء قراءة/موافقة  بنود التسجيل.';
$txt['register_passwords_differ_js'] = 'عدم تطابق كلمتي السر. يرجى اعادة الادخال مرة اخرى!';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'شكرا على التسجيل. يجب أن يقوم المشرف بقبول التسجيل قبل أن تستطيع استخدام حسابك, ستتلقى بريد من المشرف يبين فيه قراره.';

$txt['admin_settings_desc'] = 'بامكانك تغيير العديد من اعدادات الاعضاء الجدد في هذا المكان.';

$txt['setting_enableOpenID'] = 'السماح للأعضاء بتسجيل حساب جديد باستخدام OpenID';

$txt['setting_registration_method'] = 'طريقة التسجيل المستخدمة للأعضاء الجدد';
$txt['setting_registration_disabled'] = 'التسجيل غير مفعل';
$txt['setting_registration_standard'] = 'تسجيل مباشر';
$txt['setting_registration_activate'] = 'تفعيل العضوية';
$txt['setting_registration_approval'] = 'قبول العضوية';
$txt['setting_notify_new_registration'] = 'إعلام المدير عند تسجيل عضو جديد';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'إرسال رسالة ترحيب للاعضاء الجدد';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'منع من هم أعمارهم أقل من التسجيل';
$txt['setting_coppaAge_desc'] = 'ضع صفراً لإلغاء هذه الخاصية';
$txt['setting_coppaType'] = 'ما الذي يجب أن يتم عمله عندما يحاول عضو تحت حد العمر المسموح تسجيل حساب جديد';
$txt['setting_coppaType_reject'] = 'ارفض تسجيلهم';
$txt['setting_coppaType_approval'] = 'مطلوب موافقة الوالديين';
$txt['setting_coppaPost'] = 'عنوان البريد الذي يجب استخدامه لإرسال وثيقة الموافقة';
$txt['setting_coppaPost_desc'] = 'فقط يتم تنفيذه عندما يكون حد العمر محقق';
$txt['setting_coppaFax'] = 'رقم الفاكس الذي سوف ترسل اليه طلبات القبول';
$txt['setting_coppaPhone'] = 'رقم الاتصال للأهل من أجل الاتصال عن موضوع حد العمر المسموح';

$txt['admin_register'] = 'تسجيل عضو جديد';
$txt['admin_register_desc'] = 'هنا يمكنك تسجيل اعضاء جدد في المنتدى و تستطيع ارسال بياناتهم إليهم بواسطة البريد الإكترونى إذا أردت';
$txt['admin_register_username'] = 'اسم المستخدم الجديد';
$txt['admin_register_email'] = 'عنوان البريد الإلكترونى';
$txt['admin_register_password'] = 'كلمة المرور';
$txt['admin_register_username_desc'] = 'اسم المستخد للعضو الجديد';
$txt['admin_register_email_desc'] = 'عنوان البريد الإلكترونى للعضو الجديد';
$txt['admin_register_password_desc'] = 'كلمة مرور العضو الجديد';
$txt['admin_register_email_detail'] = 'ارسال كلمة المرور الجديدة للعضو';
$txt['admin_register_email_detail_desc'] = 'البريد الإلكترونى مطلوب حتى لو تم طلب إخفاؤه';
$txt['admin_register_email_activate'] = 'طلب تفعيل الاشتراك من المستخدم';
$txt['admin_register_group'] = 'مجموعة اعضاء اولية';
$txt['admin_register_group_desc'] = 'مجموعة اعضاء اولية سينتمي العضو الجديد اليها';
$txt['admin_register_group_none'] = '(لا توجد مجموعة اعضاء اولية)';
$txt['admin_register_done'] = 'تم تسجيل العضو %1$s بنجاح!';

$txt['coppa_title'] = 'منتدى محدد بالعمر';
$txt['coppa_after_registration'] = 'شكرا على قيامك بالتسجيل لدى {forum_name_html_safe}.<br /><br /> ونظرا لان عمرك اقل من  {MINIMUM_AGE}, لابد من الحصول على موافقة ولي امرك قبل تنشيط حسابك ، فضلا قم بطبع الاستمارة اسفله :';
$txt['coppa_form_link_popup'] = 'فتح الاستمارة في صفحة جديدة';
$txt['coppa_form_link_download'] = 'تحميل على شكلك ملف .txt';
$txt['coppa_send_to_one_option'] = 'بعدها قم بجعل والدك/الواصى عليك يُرسل الطلب بعد تعبئته من خلال:';
$txt['coppa_send_to_two_options'] = 'بعدها قم بجعل والدك/الواصى عليك يُرسل الطلب بعد تعبئته من خلال إحدى الطرق التالية:';
$txt['coppa_send_by_post'] = 'البريد, على العنوان التالي:';
$txt['coppa_send_by_fax'] = 'الفاكس, على الرقم التالي:';
$txt['coppa_send_by_phone'] = 'بشكل بديل, الاتصال على الرقم التالي: {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'استمارة التصاريح للتسجيل لدى  {forum_name_html_safe}';
$txt['coppa_form_address'] = 'العنوان';
$txt['coppa_form_date'] = 'تاريخ';
$txt['coppa_form_body'] = 'انا {PARENT_NAME},<br /><br /> اصرح لـ {CHILD_NAME} (اسم القاصر) ان يصبح عضو كامل مسجل في :  {forum_name_html_safe}, باسم مستخدم هو {USER_NAME}.<br /><br /> وادرك ان بعض البيانات المدخلة بمعرفة {USER_NAME} قد يتم عرضها للأعضاء الاخرين بالمنتدى . <br /><br />توقيع:<br />{PARENT_NAME} (الاب / ولي الامر).';

$txt['visual_verification_sound_again'] = 'أعد التشغيل مرة أخرى';
$txt['visual_verification_sound_close'] = 'إغلاق النافذة';
$txt['visual_verification_sound_direct'] = 'هل تواجه بعض المشاكل في سماعها?  جرب رابط مباشر لها.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'اسم المستخدم موجود';
$txt['registration_username_unavailable'] = 'اسم المستخدم غير موجود';
$txt['registration_username_check'] = 'تأكد من أن اسم المستخدم موجود';
$txt['registration_password_short'] = 'كلمة المرور قصيرة جدا';
$txt['registration_password_reserved'] = 'كلمة المرور تتضمن اسم المستخدم/البريد الإلكترونى';
$txt['registration_password_numbercase'] = 'كلمة المرور يجب أن تتضمن كلاً من حالة الأحرف الصغير و الكبيرة, و أرقام';
$txt['registration_password_no_match'] = 'كلمات المرور غير متطابقة';
$txt['registration_password_valid'] = 'كلمة المرور صالحة';

$txt['registration_errors_occurred'] = 'تم إكتشاف الأخطاء التالية أثناء عملية تسجيلك.الرجاء تصحيحها لكي تتمكن من المتابعة:';

$txt['authenticate_label'] = 'استخدام موثوق';
$txt['authenticate_password'] = 'كلمة المرور';
$txt['authenticate_openid'] = 'خدمة الهوية المشتركة (OpenID)';
$txt['authenticate_openid_url'] = 'رابط توثيق خدمة الهوية المشتركة (OpenID)';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'اتصل بالادارة';
$txt['contact_your_message'] = 'رسالتك';
$txt['errors_contact_form'] = 'الأخطاء التالية حدثت عند محاولة حفظ معلومات الاتصال بك';
$txt['contact_subject'] = 'وصلتك رسالة من ضيف ما';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
