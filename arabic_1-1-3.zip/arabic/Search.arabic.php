<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'محرك بحث المنتدى';
$txt['choose_board'] = 'اختر قسم لكي يتم البحث فيه أو اختر تحديد الكل للبحث فى كل الأقسام';
$txt['all_words'] = 'مطابقة جميع الكلمات';
$txt['any_words'] = 'مطابقة اي كلمة';
$txt['by_user'] = 'البحث بالاعضاء';

$txt['search_post_age'] = 'عُمر الرسالة';
$txt['search_between'] = 'بين';
$txt['search_and'] = 'و';
$txt['search_options'] = 'خيارات';
$txt['search_show_complete_messages'] = 'عرض نتائج البحث كرسائل';
$txt['search_subject_only'] = 'البحث فى عنوان الموضوع فقط';
$txt['search_relevance'] = 'ذات صلة';
$txt['search_date_posted'] = 'تاريخ الإرسال';
$txt['search_order'] = 'ترتيب النتائج بـ';
$txt['search_orderby_relevant_first'] = 'المواضيع الأكثر صلة أولاً';
$txt['search_orderby_large_first'] = 'المواضيع الأكثر ردوداً أولاً';
$txt['search_orderby_small_first'] = 'المواضيع الأقل ردوداً أولاً';
$txt['search_orderby_recent_first'] = 'أحدث المواضيع أولاً';
$txt['search_orderby_old_first'] = 'أقدم المواضيع أولاً';
$txt['search_visual_verification_label'] = 'التحقق';
$txt['search_visual_verification_desc'] = 'برجاء كتابت الكود الموجود بالصورة الموجودة أعلاه للقيام بعملية البحث .';

$txt['search_specific_topic'] = 'ابحث فقط فى المشاركات الموجودة بالمواضيع';

$txt['groups_search_posts'] = 'المجموعات التي تستطيع استخدام ميزة البحث';
$txt['search_dropdown'] = 'تفعيل قائمة البحث السريع المنسدلة';
$txt['search_results_per_page'] = 'عدد النتائج في كل صفحة';
$txt['search_weight_frequency'] = 'الصلة من حيث عدد المطابقات في المواضيع';
$txt['search_weight_age'] = 'الصلة من حيث مطابقة تاريخ أقرب رسالة';
$txt['search_weight_length'] = 'الصلة من حيث طول الموضوع';
$txt['search_weight_subject'] = 'الصلة من حيث مطابقة تصنيف الموضوع';
$txt['search_weight_first_message'] = 'الصلة من حيث مطابقة مع أول رسالة في المواضيع';
$txt['search_weight_sticky'] = 'الصلة من حيث المواضيع المثبتة';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'تستطيع هنا تغيير الخصائص الأساسية لميزة البحث';
$txt['search_settings_title'] = 'إعدادات البحث';

$txt['search_weights_desc'] = 'يمكنك هنا تغيير مدى نسبة الاهمية لكل عنصر فردي مرتبط بالبحث';
$txt['search_weights_sphinx'] = 'To update weight factors with Sphinx, you must generate and install a new sphinx.conf file.';
$txt['search_weights_title'] = 'بحث - وزن';
$txt['search_weights_total'] = 'إجمالي';
$txt['search_weights_save'] = 'حفظ';

$txt['search_method_desc'] = 'هنا تستطيع اختيار طريقة البحث';
$txt['search_method_title'] = 'طريقة - البحث';
$txt['search_method_save'] = 'حفظ';
$txt['search_method_messages_table_space'] = 'المساحة المُستخدمة من قِبل رسائل المنتدى في قاعدة البيانات';
$txt['search_method_messages_index_space'] = 'المساحة المُستخدمة لفهرسة الرسائل في قاعدة البيانات';
$txt['search_method_kilobytes'] = 'كيلوبايت';
$txt['search_method_fulltext_index'] = 'فهرس نص كامل';
$txt['search_method_no_index_exists'] = 'غير موجود حاليا';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'لا يمكن إنشاءها لأن الحد الأقصى للرسالة أكبر من  65,535 أو نوع الجدول ليس MyISAM';
$txt['search_method_index_already_exists'] = 'تم إنشاءها مسبقا ';
$txt['search_method_fulltext_remove'] = 'حذف فهرس نص كامل';
$txt['search_method_index_partial'] = 'أنشئ بشكل جزئي';
$txt['search_index_custom_resume'] = 'استئناف';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'In order to be able to use fulltext search, you\\\'ll have to create a fulltext index first.';
$txt['search_index_custom_warning'] = 'من أجل استخدام فهرس بحث مخصص , يجب عليك أن تنشأ فهرس بحث أولا!';

$txt['search_index'] = 'فهرس البحث';
$txt['search_index_none'] = 'لا يوجد فهرس';
$txt['search_index_custom'] = 'فهرس خاص';
$txt['search_index_label'] = 'فهرس';
$txt['search_index_size'] = 'حجم';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'إجبار استخدام فهرس البحث';
$txt['search_match_words'] = 'مطابقة كامل الكلمة فقط';
$txt['search_max_results'] = 'الحد الأقصى للنتائج التي سوف تظهر';
$txt['search_max_results_disable'] = '(0: لا حدود)';
$txt['search_floodcontrol_time'] = 'الوقت الذى يجب على العضو إنتظاره لكى يقوم بعملية بحث اخرى ';
$txt['search_floodcontrol_time_desc'] = '(0 لـعدم وجود حد, بالثواني)';

$txt['additional_search_engines'] = 'Additional search engines';
$txt['setup_search_engine_add_more'] = 'Add another search engine';

$txt['search_create_index'] = 'إنشاء فهرس';
$txt['search_create_index_why'] = 'لماذا إنشاء فهرس بحث ؟';
$txt['search_create_index_start'] = 'إنشاء';
$txt['search_predefined'] = 'حساب معرف بشكل مسبق';
$txt['search_predefined_small'] = 'فهرس ذو حجم صغير';
$txt['search_predefined_moderate'] = 'فهرس ذو حجم متوسط';
$txt['search_predefined_large'] = 'فهرس ذو حجم كبير';
$txt['search_create_index_continue'] = 'استمر';
$txt['search_create_index_not_ready'] = 'ElkArte is currently creating a search index of your messages. To avoid overloading your server, the process has been temporarily paused. It should automatically continue in a few seconds. If it doesn\'t, please click continue below.';
$txt['search_create_index_progress'] = 'التقدم';
$txt['search_create_index_done'] = 'Custom search index successfully created.';
$txt['search_create_index_done_link'] = 'استمر';
$txt['search_double_index'] = 'لقد قمت بإنشاء فهرسين لجدول المشاركات. للأداء الأفضل قم بإزالة أحد هذه الفهارس.';

$txt['search_error_indexed_chars'] = 'عدد غير صالح من الأحرف المفهرسة. على الأقل 3 أحرف مطلوبة من أجل فهرس مفيد.';
$txt['search_error_max_percentage'] = 'نسبة غير صحيحة للكلمات التي سوف يتم تجاهلها. استخدم قيمة على الأقل 5%.';
$txt['error_string_too_long'] = 'كلمة البحث يجب أن تكون أقل من  %1$d حرف. ';

$txt['search_warning_ignored_word'] = 'The following term has been ignored in your search';
$txt['search_warning_ignored_words'] = 'The following terms have been ignored in your search';

$txt['search_adjust_query'] = 'تعديل كلمات البحث';
$txt['search_adjust_submit'] = 'تعديل البحث';
$txt['search_did_you_mean'] = 'قد يكون هدفك البحث عن ..';

$txt['search_example'] = '<em>مثال</em>  "مزرعة الحيوان" -فيلم';

$txt['search_engines_description'] = 'من هنا يمكنك تحديد الاعدادت الخاصه بمحركات البحث التى تقوم بتتبع ارتباطاط موقعك , يمكنك ايضا مشاهدة السجل الخاص بهم .';
$txt['spider_mode'] = 'Search Engine Tracking Level';
$txt['spider_mode_note'] = 'Note higher level tracking increases server resource requirement.';
$txt['spider_mode_off'] = 'تعطيل';
$txt['spider_mode_standard'] = 'قياسي';
$txt['spider_mode_high'] = 'الإشراف';
$txt['spider_mode_vhigh'] = 'Aggressive';
$txt['spider_settings_desc'] = 'You can change settings for spider tracking from this page. Note, if you wish to <a href="%1$s">enable automatic pruning of the hit logs you can set this up here</a>';

$txt['spider_group'] = 'Apply restrictive permissions from group';
$txt['spider_group_note'] = 'To enable you to stop spiders indexing some pages.';
$txt['spider_group_none'] = 'تعطيل';

$txt['show_spider_online'] = 'إظهر العناكب فى قائمة من متصل';
$txt['show_spider_online_no'] = 'أبداً';
$txt['show_spider_online_summary'] = 'أظهر عدد العناكب الالكترونية';
$txt['show_spider_online_detail'] = 'إظهر أسماء العناكب';
$txt['show_spider_online_detail_admin'] = 'إظهر أسماء العناكب - للمدير فقط';

$txt['spider_name'] = 'اسم العنكبوت الاكتروني';
$txt['spider_last_seen'] = 'آخر مرة تم رصده';
$txt['spider_last_never'] = 'ابدأ';
$txt['spider_agent'] = 'وكيل المستخدم';
$txt['spider_ip_info'] = 'عنوان الـIP ';
$txt['spiders_add'] = 'إضافة عنكبوت الكتروني جديد';
$txt['spiders_edit'] = 'تعديل عنكبوت الكتروني';
$txt['spiders_remove_selected'] = 'حذف المختار';
$txt['spider_remove_selected_confirm'] = 'Are you sure you want to remove these spiders?\\n\\nAll associated statistics will also be deleted!';
$txt['spiders_no_entries'] = 'لا يوجد حاليا أى تهيئات بخصوص العناكب الإلكترونية .';

$txt['add_spider_desc'] = 'هنا يمكنك تعديل بيانات العناكب . اذا تم ايجاد زائر بـ ip مشابه للذى مكتوب هنا فسيتم معاملته كعنكبوت و تتبعه .';
$txt['spider_name_desc'] = 'الاسم الذي سوف يستخدم للإشارة إلى العنكبوت الالكتروني';
$txt['spider_agent_desc'] = 'وكيل المستخدم المرتبط مع هذا العنكبوت الالكتروني.';
$txt['spider_ip_info_desc'] = 'الـ ip الخاص بهذا العنكبوت (عنوان لكل سطر) .';

$txt['spider_time'] = 'الوقت';
$txt['spider_viewing'] = 'مشاهدة';
$txt['spider_logs_empty'] = 'لا يوجد أي مُدخلات لسجل العناكب';
$txt['spider_logs_info'] = 'لاحظ انه يتم تتبع جميع تحركات العنكبوت اذا تم تهيئة مستوى التتبع كـ &quot;عالى&quot; أو &quot;عالى جدا&quot;. تفاصيل كل تحكات العناكب يتم تسجيلها اذا تم تهيئة مستوى التتبع كـ &quot;عالى جدا&quot;.';
$txt['spider_disabled'] = 'تعطيل';
$txt['spider_log_empty_log'] = 'تنظيف السجل';
$txt['spider_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log';

$txt['spider_logs_delete'] = 'حذف المُدخلات';
$txt['spider_logs_delete_older'] = 'Delete all entries older than %1$s days.';
$txt['spider_logs_delete_submit'] = 'حذف';

$txt['spider_stats_delete_older'] = 'Delete all spider statistics from spiders not seen in %1$s days.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'هل أنت متأكد من أنك تريد مسح جميع بيانات السجل ؟';

$txt['spider_stats_select_month'] = 'القفز إلى الشهر';
$txt['spider_stats_page_hits'] = 'عدد قراءة الصفحة';
$txt['spider_stats_no_entries'] = 'لا يوجد حاليا أى إحصائيات عن العناكب الإلكترونية .';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'You have not yet selected to use Sphinx or SphinxQL as your Search Method';
$txt['sphinx_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using the Sphinx API.';
$txt['sphinxql_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using SphinxQL commands.';
$txt['sphinx_test_connect_failed'] = 'Unable to connect to the Sphinx daemon. Make sure it is running and configured properly. Sphinx search will not work until you fix the problem.';
$txt['sphinxql_test_connect_failed'] = 'Unable to access SphinxQL. Make sure your sphinx.conf has a separate listen directive for the SphinxQL port. SphinxQL search will not work until you fix the problem';
$txt['sphinx_test_api_missing'] = 'The sphinxapi.php file is missing in your &quot;sources&quot; directory. You need to copy this file from the Sphinx distribution. Sphinx search will not work until you fix the problem.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Index data path:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Log file path:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';