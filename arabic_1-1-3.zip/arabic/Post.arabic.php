<?php
// Version: 1.1; Post

$txt['post_reply'] = 'كتابة رد';
$txt['post_in_board'] = 'مشاركة في هذا المنتدى';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'إضافة اقتباس';
$txt['disable_smileys'] = 'تعطيل الابتسامات';
$txt['dont_use_smileys'] = 'لا تستخدم الابتسامات.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'كتب في';
$txt['standard'] = 'قياسي';
$txt['thumbs_up'] = 'إبهام لفوق';
$txt['thumbs_down'] = 'إبهام لتحت';
$txt['exclamation_point'] = 'علامة تعجب';
$txt['question_mark'] = 'علامة سؤال';
$txt['icon_poll'] = 'التصويت';
$txt['lamp'] = 'مصباح';
$txt['add_smileys'] = 'إضافة ابتسامات';
$txt['topic_notify_no'] = 'لا يوجد مواضيع ذات تنبيهات.';

$txt['rich_edit_wont_work'] = 'مستعرضك لا يدعم محرر النصوص الغني';
$txt['rich_edit_function_disabled'] = 'مستعرضك لا يدعم هذه العملية';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'تعطيل الاشتراك في هذا الموضوع بالنقر هنا';

$txt['lock_after_post'] = 'قفل بعد الإرسال';
$txt['notify_replies'] = 'تنبيه على الردود.';
$txt['lock_topic'] = 'قفل هذا الموضوع.';
$txt['shortcuts'] = 'إختصارات : إضغط shift+alt+s للإضافة/الإرسال أو shift+alt+p للمعاينة';
$txt['shortcuts_drafts'] = 'إختصارات : إضغط shift+alt+s للإضافة/الإرسال أو shift+alt+p للمعاينة أو shift+alt+d للحفظ كمسودة';
$txt['option'] = 'خيارات';
$txt['reset_votes'] = 'تصفير عداد التصويت';
$txt['reset_votes_check'] = 'علم هنا إذا رغبت في تصفير العداد إلى 0.';
$txt['votes'] = 'أصوات';
$txt['attach'] = 'إلحاق';
$txt['clean_attach'] = 'حذف المرفقات';
$txt['attached'] = 'الحق'; // @deprecated since 1.1
$txt['allowed_types'] = 'أنواع الملفات المسموحة';
$txt['cant_upload_type'] = 'لا يمكنك إرفاق هذا النوع من الملفات. امتدادات الملفات المسموح بها هي %1$s.';
$txt['uncheck_unwatchd_attach'] = 'الغ التعليم عن الملحقات التي لا ترغب في إلحاقها'; // @deprecated since 1.1
$txt['restricted_filename'] = 'هذا اسم ملف ممنوع. حاول مع اسم ملف مختلف.';
$txt['topic_locked_no_reply'] = 'تحذير: الموضوع سوف يغلق أو تم إغلاقه<br />فقط المدراء و المشرفين يمكنهم الرد.';
$txt['attachment_requires_approval'] = 'لاحظ أن أي ملف مرفق لن يتم عرضه قبل أن يتم الموافقه عليه من قبل المشرف.';
$txt['error_temp_attachments'] = 'تم العثور على مرفقات, سبق لك إرفاقها من قبل لكنك لم ترسلها. هذه المرفقات هى الان مرفقة مع هذه المشاركة. إذا كنت لا تريد إرفاقها مع هذه المشاركة ، <a href="#postAttachment">يمكنك حذفها هنا</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'تذكير: هذه المشاركة لن تظهر قبل أن يتم الموافقة عليها من قبل المشرف.';

$txt['enter_comment'] = 'إضافة التعليق';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'رسالة تم الإبلاغ عنها';
$txt['reported_to_mod_by'] = 'بواسطة';
$txt['rtm10'] = 'أرسل';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'الرسالة التالية, "%1$s" بواسطة';
$txt['reported_by'] = 'تم الإبلاغ عنها بواسطة';
$txt['board_moderate'] = 'في القسم الذي تشرف عليه';
$txt['report_comment'] = 'قام المُرسل بإضافة التعليق التالي';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'الحجم الأقصى الإجمالى   %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'الحجم الأقصى للملف الواحد  %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d لكل مشاركة';
$txt['attach_restrictions'] = 'القيود :';

$txt['post_additionalopt_attach'] = 'خيارات إضافية...';
$txt['post_additionalopt'] = 'خيارات اخرى';
$txt['sticky_after'] = 'ثبت هذا الموضوع.';
$txt['move_after2'] = 'نقل هذا الموضوع.';
$txt['back_to_topic'] = 'العودة إلى هذا الموضوع.';
$txt['approve_this_post'] = 'الموافقة على هذه المشاركة';

$txt['retrieving_quote'] = 'جلب الاقتباس...';

$txt['post_visual_verification_label'] = 'التحقق';
$txt['post_visual_verification_desc'] = 'برجاء إدخال الرموز الظاهرة ضمن الصورة من أجل أن تستطيع إرسال المشاركة.';

$txt['poll_options'] = 'خيارات الإستفتاء';
$txt['poll_run'] = 'مدة الإستفتاء';
$txt['poll_run_limit'] = '(إتركها فارغة لتكون غير محدودة.) ';
$txt['poll_results_visibility'] = 'إظهر النتيجة';
$txt['poll_results_anyone'] = 'عرض نتائج الإستفتاء للكل.';
$txt['poll_results_voted'] = 'عرض النتائج فقط بعد القيام بالتصويت من أي عضو.';
$txt['poll_results_after'] = 'إظهر النتائج فقط بعد إنتهاء مدة الإستفتاء .';
$txt['poll_max_votes'] = 'الحد الأقصى للتصويت للمستخدم.';
$txt['poll_do_change_vote'] = 'السماح للعضو من بتغير تصويته.';
$txt['poll_too_many_votes'] = 'حددت خيارات عدة- الحد الأقصى للخيارات هو %1$s';
$txt['poll_add_option'] = 'إضافة خيار';
$txt['poll_guest_vote'] = 'السماح للضيف بالتصويت.';

$txt['spellcheck_done'] = 'تم الانتهاء من التدقيق الإملائي.';
$txt['spellcheck_change_to'] = 'أبدل إلى:';
$txt['spellcheck_suggest'] = 'اقتراحات:';
$txt['spellcheck_change'] = 'تعديل';
$txt['spellcheck_change_all'] = 'تغير الكل';
$txt['spellcheck_ignore'] = 'تجاهل';
$txt['spellcheck_ignore_all'] = 'تجاهل الكل';

$txt['more_attachments'] = 'ملحقات أخرى';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'نأسف, لا يمكنك إضافة ملحقات أخرى.';

$txt['more_smileys'] = 'المزيد';
$txt['more_smileys_title'] = 'ابتسامات إضافية';
$txt['more_smileys_pick'] = 'اختر ابتسامة';
$txt['more_smileys_close_window'] = 'إغلاق النافذة';

$txt['error_new_reply'] = 'تنبيه - اثناء قيامك بالكتابة تم إضافة رد جديد. ربما تريد مراجعة مشاركتك';
$txt['error_new_replies'] = 'تنبيه - اثناء قيامك بالكتابة قام %1$d  باضافة رد جديد. ربما تريد مراجعة مشاركتك';
$txt['error_new_reply_reading'] = 'تنبيه - بينما أنت تقرا تم إضافة ردود جديدة.';
$txt['error_new_replies_reading'] = 'تنبيه - اثناء قيامك بالقراءة قام %1$d  باضافة رد جديد. ربما تريد مراجعة مشاركتك';

$txt['announce_this_topic'] = 'بعث إعلان عن الموضوع للأعضاء:';
$txt['announce_title'] = 'بعث إعلان';
$txt['announce_desc'] = 'يمكنك إرسال إعلان لمجموعات الأعضاء المختارة عن هذا الموضوع.';
$txt['announce_sending'] = 'بعث إعلان للموضوع';
$txt['announce_done'] = 'تم';
$txt['announce_continue'] = 'استمر';
$txt['announce_topic'] = 'موضوع إعلاني.';
$txt['announce_regular_members'] = 'أعضاء بدون مجموعات';

$txt['digest_subject_daily'] = 'موجز يومي';
$txt['digest_subject_weekly'] = 'موجز أسبوعي';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'المواضيع التالية قد تم إنشائها ';
$txt['digest_new_topics_line'] = '"%1$s" في منتدى  %2$s ';
$txt['digest_new_replies'] = 'ردود قد تمت في المواضيع التالية';
$txt['digest_new_replies_one'] = 'رد واحد في %1$s" ';
$txt['digest_new_replies_many'] = '%1$d رد في "%2$s"';
$txt['digest_mod_actions'] = 'أحداث المشرفين التالية قد تمت';
$txt['digest_mod_act_sticky'] = '"%1$s" تم تثبيته';
$txt['digest_mod_act_lock'] = '"%1$s" تم قفله';
$txt['digest_mod_act_unlock'] = '"%1$s" تم إزالة القفل عنه';
$txt['digest_mod_act_remove'] = '"%1$s" تم حذفه';
$txt['digest_mod_act_move'] = '"%1$s" تم نقله';
$txt['digest_mod_act_merge'] = '"%1$s" تم دمجه';
$txt['digest_mod_act_split'] = '"%1$s" تم فصله';

$txt['attach_error_title'] = 'حدث خطأ عند رفع المرفقات';
$txt['attach_warning'] = 'حدثت مشكلة اثناء تحميل <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'عفوا لقد امتلأ الحجم المخصص لمرفقاتك ، الحجم الاجمالي المخصص للمرفقات لكل مشاركة هو %1$s KB. والمتبقي هو %2$s KB.';
$txt['attach_folder_warning'] = 'فولدر المرفقات بالمنتدى مفقود . فضلا قم باخطار الادارة بذلك';
$txt['attach_folder_admin_warning'] = 'مسار فولدر المرفقات (%1$s) هو غير صحيح. فضلا قم بتصحيحه من لوحة تحكم الادارة - اعدادات المرفقات';
$txt['attach_limit_nag'] = 'لقد وصلت الى الحد الاقصى من عدد المرفقات المسموح بها في المشاركة الواحدة';
$txt['attach_no_upload'] = 'حدثت مشكلة ولم يتم رفع مرفقاتك';
$txt['attach_remaining'] = '%1$d متبقي';
$txt['attach_available'] = '%1$s KB المتاح ';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'يبدو ان الملف خاليا ، اذا كانت هذه مشكلة متكررة برجاء ابلاغ الادارة';
$txt['attached_files_in_session'] = '<em>الملف او(الملفات) أعلاه والتي تحتها خط تم تحميلها لكن لن يتم ارفاقها في المشاركة حتى يتم الارسال .</em>';

$txt['attach_php_error'] = 'لم يتم رفع مرفقاتك لحدوث خطأ ، اذا كانت هذه مشكلة متكررة برجاء ابلاغ الادارة';
$txt['php_upload_error_1'] = 'حجم الملف المرفوع يتعدى الحد الاقصى المحدد بالتعليمة upload_max_filesize في ملف php.ini ، برجاء الاتصال بمسئول الاستضافة اذا لم يكن في قدرتك تصحيح هذه المسألة.';
$txt['php_upload_error_3'] = 'حجم الملف المرفوع تم تحميل جزء منه فقط، هذه مشكلة من ال PHP  ، برجاء الاتصال بمسئول الاستضافة اذا استمرت هذه المشكلة.';
$txt['php_upload_error_4'] = 'لم يتم تحميل ملفات، هذه مشكلة من ال PHP  ، برجاء الاتصال بمسئول الاستضافة اذا استمرت هذه المشكلة.';
$txt['php_upload_error_6'] = 'غير قادر على التخزين بسبب عدم تحديد فولدر العمليات المؤقتة ،  temporary directory ، برجاء الاتصال بمسئول الاستضافة اذا لم يكن في قدرتك تصحيح هذه المسألة.';
$txt['php_upload_error_7'] = 'غير قادر على الكتابة على وسيط التخزين، هذه مشكلة من ال PHP  ، برجاء الاتصال بمسئول الاستضافة اذا استمرت هذه المشكلة.';
$txt['php_upload_error_8'] = 'PHP extension قام بمنع تحميل الملف، هذه مشكلة من ال PHP  ، برجاء الاتصال بمسئول الاستضافة اذا استمرت هذه المشكلة.';
$txt['error_temp_attachments_new'] = 'توجد مرفقات, سبق لك إرفاقها من قبل لكنك لم ترسلها. هذه المرفقات هى الان مرفقة مع هذه المشاركة. هذه المشاركة تحتاج ان يتم ارسالها وبعد ذلك يمكنك حفظ او حذف المرفقات ، <a href="#postAttachment">من هنا</a>.';
$txt['error_temp_attachments_found'] = 'تم العثور على المرفقات التالية التي كنت قد قمت في السابق بارفاقها الى مشاركة أخرى ولكن لم تنشر. فمن المستحسن أن لا تقوم بارسال المشاركة الحالية حتى يتم إما إزالة تلك المرفقات أو ارسال تلك المشاركة السابقة. <br /> انقر <a href="%1$s"> هنا لإزالة </A> تلك المرفقات. أو <a href="%2$s"> هنا للعودة إلى تلك المشاركة </A>.%3$s';
$txt['error_temp_attachments_lost'] = 'تم العثور على المرفقات التالية التي كنت قد قمت في السابق بارفاقها الى مشاركة أخرى ولكن لم تنشر. فمن المستحسن أن لا تقوم برفع اي مرفقات جديدة حتى يتم إما إزالة تلك المرفقات أو ارسال تلك المشاركة السابقة. <br /> انقر <a href="%1$s"> هنا لإزالة </A> تلك المرفقات .%2$s';
$txt['error_temp_attachments_gone'] = 'تم ازالة هذه المرفقات الان وتم اعادتك الى الصفحة السابقة';
$txt['error_temp_attachments_flushed'] = 'لاحظ أن : أي ملفات سبق ارفاقها ولم يتم نشرها ، قد تم ازالتها';
$txt['error_topic_already_announced'] = 'لاحظ أن : هذا الموضوع قد سبق الاعلان عنه بالفعل';

$txt['cant_access_upload_path'] = 'لا يمكن الوصول إلى مسار التحميل للملحقات!';
$txt['file_too_big'] = 'ملفك حجمه كبير للغاية ، الحجم الاقصى للمرفق والمسموح به هو %1$s KB.';
$txt['attach_timeout'] = 'حدث خطأ في تخزين الملحق، الرجاء المحاولة مرة أخرى.';
$txt['bad_attachment'] = 'حدث خطأ ما أثناء القيام بعملية فحص الملف المرفق , لم يتم إرفاق الملف .برجاء مراسلة صاحب المنتدى .';
$txt['ran_out_of_space'] = 'فولدر الملفات المرفوعة قد امتلأ ، فضلا قم بابلاغ الادارة عن هذه المشكلة';
$txt['attachments_no_write'] = 'مسار التحميل للملحقات غير فابل للكتابة.  ملحقاتك أو صور الشخصية لا يمكن حفظها.';
$txt['attachments_no_create'] = 'غير قادر على انشاء فولدر جديد للمرفقات ، مرفقاتك وصورتك الرمزية لا يمكن حفظها.';
$txt['attachments_limit_per_post'] = 'لا يمكنك تحميل أكثر من %d ملحق لكل رسالة';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'ادراج';
$txt['ila_opt_size'] = 'حجم';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'لا شيء';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'توسيط';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/