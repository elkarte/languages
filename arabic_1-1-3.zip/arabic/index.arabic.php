<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'ar_SA.utf8';
$txt['lang_dictionary'] = 'ar';
$txt['lang_spelling'] = 'arabic';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = true;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'الأحد';
$txt['monday'] = 'الإثنين';
$txt['tuesday'] = 'الثلاثاء';
$txt['wednesday'] = 'الأربعاء';
$txt['thursday'] = 'الخميس';
$txt['friday'] = 'الجمعة';
$txt['saturday'] = 'السبت';

$txt['sunday_short'] = 'الاحد';
$txt['monday_short'] = 'الاثنين';
$txt['tuesday_short'] = 'الثلاثاء';
$txt['wednesday_short'] = 'الاربعاء';
$txt['thursday_short'] = 'الخميس';
$txt['friday_short'] = 'الجمعة';
$txt['saturday_short'] = 'السبت';

$txt['january'] = 'يناير';
$txt['february'] = 'فبراير';
$txt['march'] = 'مارس';
$txt['april'] = 'أبريل';
$txt['may'] = 'May';
$txt['june'] = 'يونيو';
$txt['july'] = 'يوليو';
$txt['august'] = 'أغسطس';
$txt['september'] = 'سبتمبر';
$txt['october'] = 'أكتوبر';
$txt['november'] = 'نوفمبر';
$txt['december'] = 'ديسمبر';

$txt['january_titles'] = 'يناير';
$txt['february_titles'] = 'فبراير';
$txt['march_titles'] = 'مارس';
$txt['april_titles'] = 'أبريل';
$txt['may_titles'] = 'May';
$txt['june_titles'] = 'يونيو';
$txt['july_titles'] = 'يوليو';
$txt['august_titles'] = 'أغسطس';
$txt['september_titles'] = 'سبتمبر';
$txt['october_titles'] = 'أكتوبر';
$txt['november_titles'] = 'نوفمبر';
$txt['december_titles'] = 'ديسمبر';

$txt['january_short'] = 'Jan';
$txt['february_short'] = 'Feb';
$txt['march_short'] = 'Mar';
$txt['april_short'] = 'Apr';
$txt['may_short'] = 'May';
$txt['june_short'] = 'Jun';
$txt['july_short'] = 'Jul';
$txt['august_short'] = 'Aug';
$txt['september_short'] = 'Sep';
$txt['october_short'] = 'Oct';
$txt['november_short'] = 'Nov';
$txt['december_short'] = 'Dec';

$txt['time_am'] = 'صباحاً';
$txt['time_pm'] = 'مساءاً';

// Let's get all the main menu strings in one place.
$txt['home'] = 'الرئيسية';
$txt['community'] = 'المنتدى';
// Sub menu labels
$txt['help'] = 'تعليمات';
$txt['search'] = 'إدارة البحث';
$txt['calendar'] = 'إدارة التقويم';
$txt['members'] = 'تحكم الأعضاء';
$txt['recent_posts'] = 'آخر المشاركات';

$txt['admin'] = 'الإدارة';
// Sub menu labels
$txt['errlog'] = 'سجل الأخطاء';
$txt['package'] = 'مدير الرزم';
$txt['edit_permissions'] = 'تعديل تصاريح';
$txt['modSettings_title'] = 'خصائص و مميزات';

$txt['moderate'] = 'الإشراف';
// Sub menu labels
$txt['modlog_view'] = 'سجل الاشراف';
$txt['mc_emailerror'] = 'بريد الكتروني غير موافق عليه';
$txt['mc_reported_posts'] = 'المشاركات التي كتب تقرير فيها';
$txt['mc_reported_pms'] = 'Reported Personal Messages';
$txt['mc_unapproved_attachments'] = 'المرفقات الغير الموافق عليها';
$txt['mc_unapproved_poststopics'] = 'المواضيع و المشاركات الغير موافق عليها';

$txt['pm_short'] = 'الرسائل الشخصية';
// Sub menu labels
$txt['pm_menu_read'] = 'اقرأ رسائلك';
$txt['pm_menu_send'] = 'إرسل رسالة';

$txt['account_short'] = 'حسابي';
// Sub menu labels
$txt['profile'] = 'الملف الشخصي';
$txt['mydrafts'] = 'My Drafts';
$txt['summary'] = 'ملخص';
$txt['theme'] = 'تفضيلات الشكل و المظهر';
$txt['account'] = 'معلومات الحساب الأساسية';
$txt['forumprofile'] = 'الملف الشخصى';

$txt['view_unread_category'] = 'مشاركات جديدة';
$txt['view_replies_category'] = 'ردود جديدة';

$txt['login'] = 'تسجيل الدخول';
$txt['register'] = 'تسجيل حساب جديد';
$txt['logout'] = 'تسجيل الخروج';
// End main menu strings.

$txt['save'] = 'حفظ';

$txt['modify'] = 'تعديل';
$txt['forum_index'] = '%1$s - فهرس';
$txt['board_name'] = 'اسم المنتدى';
$txt['posts'] = 'مشاركة';

$txt['member_postcount'] = 'مشاركة';
$txt['no_subject'] = '(بدون اسم موضوع)';
$txt['view_profile'] = 'مشاهدة الملف الشخصي';
$txt['guest_title'] = 'زائر';
$txt['author'] = 'المؤلف';
$txt['on'] = 'في';
$txt['remove'] = 'حذف';
$txt['start_new_topic'] = 'إنشاء موضوع جديد';

// Use numeric entities in the below string.
$txt['username'] = 'اسم المستخدم';
$txt['password'] = 'كلمة المرور';

$txt['username_no_exist'] = 'اسم المستخدم غير موجود.';
$txt['no_user_with_email'] = 'لايوجد اسم مستخدم مرتبط مع هذا البريد الالكتروني.';

$txt['board_moderator'] = 'مشرف المنتدى';
$txt['remove_topic'] = 'حذف';
$txt['topics'] = 'المواضيع';
$txt['modify_msg'] = 'تعديل المشاركة';
$txt['name'] = 'الاسم';
$txt['email'] = 'البريد الالكتروني';
$txt['user_email_address'] = 'عنوان البريد الإلكترونى';
$txt['subject'] = 'الموضوع';
$txt['message'] = 'المشاركة';
$txt['redirects'] = 'اعادة التوجيه';

$txt['choose_pass'] = 'اختر كلمة المرور';
$txt['verify_pass'] = 'تأكيد كلمة المرور';
$txt['position'] = 'المنصب';
$txt['notify_announcements'] = 'Sign up to receive important site news by email';

$txt['profile_of'] = 'مشاهدة الملف الشخصي لـ';
$txt['total'] = 'إجمالي';
$txt['posts_made'] = 'مشاركة';
$txt['topics_made'] = 'المواضيع';
$txt['website'] = 'موقع ويب';
$txt['contact'] = 'اتصل بنا';
$txt['warning_status'] = 'حالة التحذير';
$txt['user_warn_watch'] = 'العضو يتم مراقبته من قبل المشرف';
$txt['user_warn_moderate'] = 'مشاركات العضو تم إضافتها إلى صف الموافقة';
$txt['user_warn_mute'] = 'العضو موقوف عن المشاركة';
$txt['warn_watch'] = 'تحت المراقبة';
$txt['warn_moderate'] = 'تحت الاشراف';
$txt['warn_mute'] = 'ممنوع من المشاركة';
$txt['warning_issue'] = 'تحذير';

$txt['message_index'] = 'فهرس المشاركات';
$txt['news'] = 'الأخبار';
$txt['page'] = 'صفحة';
$txt['prev'] = 'السابق';
$txt['next'] = 'التالي';

$txt['post'] = 'إرسال';
$txt['error_occurred'] = 'لقد حدث خطأ';
$txt['send_error_occurred'] = 'لقد حدث خطأ <a href="{href}">فضلا اضغط هنا لاعادة المحاولة</a>.';
$txt['require_field'] = 'مطلوب';
$txt['started_by'] = 'بدء بواسطة';
$txt['topic_started_by'] = 'بدء بواسطة %1$s';
$txt['topic_started_by_in'] = 'بدء بواسطة %1$s في %2$s';
$txt['replies'] = 'ردود';
$txt['last_post'] = 'آخر مشاركة';
$txt['first_post'] = 'اول مشاركة';
$txt['last_poster'] = 'آخر مشاركة بواسطة ';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s </span><span class="board_lastposter">بواسطة %1$s</span><span class="board_lasttime"><strong>المشاركة الأخيرة: </strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s مشاركة في  %2$s موضوع بواسطة  %3$s عضو';
$txt['show'] = 'عرض';
$txt['hide'] = 'اخفاء';
$txt['sort_by'] = 'ترتيب بواسطة';
$txt['sort_asc'] = 'الترتيب تصاعديا';
$txt['sort_desc'] = 'الترتيب تنازليا';

$txt['admin_login'] = 'تسجيل دخول المدير';
// Use numeric entities in the below string.
$txt['topic'] = 'موضوع';
$txt['help'] = 'تعليمات';
$txt['notify'] = 'تنبيه';
$txt['unnotify'] = 'بدون تنبيه';
$txt['notify_request'] = 'هل ترغب في بريد تنبيهي في حالة الرد على هذا الموضوع؟';
// Use numeric entities in the below string.
$txt['regards_team'] = "مع تحيات,\nفريق {forum_name_html_unsafe} .";
$txt['notify_replies'] = 'التنبيه على الردود';
$txt['move_topic'] = 'نقل';
$txt['move_to'] = 'نقل إلى';
$txt['pages'] = 'صفحات';
$txt['users_active'] = 'نشيط خلال %1$d دقيقة الماضية';
$txt['personal_messages'] = 'الرسائل الشخصية';
$txt['reply_quote'] = 'رد مع الاقتباس';
$txt['reply'] = 'رد';
$txt['reply_number'] = ' رد #%1$s';
$txt['approve'] = 'موافقة';
$txt['unapprove'] = 'عدم الموافقة';
$txt['approve_all'] = 'الموافقة على الكل';
$txt['awaiting_approval'] = 'تنتظر الموافقة';
$txt['attach_awaiting_approve'] = 'المرفقات التي تنتظر الموافقة';
$txt['post_awaiting_approval'] = 'ملاحظة: هذه المشاركة تنتظر الموافقة من قبل المشرف.';
$txt['there_are_unapproved_topics'] = 'يوجد %1$s موضوع و %2$s مشاركة في انتظار الموافقة في هذا المنتدى. <a href="%3$s">انقر هنا لمعاينتها</a>.';
$txt['send_message'] = 'ارسال رسالة';

$txt['msg_alert_no_messages'] = 'لا يوجد لديك اي رسائل';
$txt['msg_alert_one_message'] = 'يوجد لديك <a href="%1$s">1 رسالة</a>';
$txt['msg_alert_many_message'] = 'يوجد لديك <a href="%1$s">%2$d رسالة</a>';
$txt['msg_alert_one_new'] = '1 رسالة جديدة';
$txt['msg_alert_many_new'] = '%1$d رسائل جديدة';
$txt['remove_message'] = 'حذف الرسالة';

$txt['topic_alert_none'] = 'لا توجد رسائل...';
$txt['pm_alert_none'] = 'لا توجد رسائل...';

$txt['online_users'] = 'الأعضاء المتواجدين الآن'; //Deprecated
$txt['online_now'] = 'متصل الآن';
$txt['personal_message'] = 'رسالة شخصية';
$txt['jump_to'] = 'انتقل إلى';
$txt['go'] = 'اذهب';
$txt['are_sure_remove_topic'] = 'هل ترغب في حذف هذا الموضوع؟';
$txt['yes'] = 'نعم';
$txt['no'] = 'لا';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'في';

$txt['search'] = 'إدارة البحث';
$txt['all'] = 'الكل';
$txt['search_entireforum'] = 'جميع المنتديات';
$txt['search_thisbrd'] = 'هذا المنتدى';
$txt['search_thistopic'] = 'هذا الموضوع';
$txt['search_members'] = 'تحكم الأعضاء';

$txt['back'] = 'للوراء';
$txt['continue'] = 'استمر';
$txt['password_reminder'] = 'تذكير بكلمة المرور';
$txt['topic_started'] = 'الموضوع حرر بواسطة';
$txt['title'] = 'العنوان';
$txt['post_by'] = 'أرسل بواسطة';
$txt['welcome_newest_member'] = 'رجاء الترحيب بالعضو الجديد %1$s';
$txt['admin_center'] = 'مركز الإدارة';
$txt['admin_session_active'] = 'أنت مسجل دخولك حاليا كمدير المنتدى. ونحن نوصي <strong><a class="strong" href="%1$s">بانهاء جلسة المدير</a></strong> بمجرد انتهاءك من عملياتك الادارية.';
$txt['admin_maintenance_active'] = 'منتداك حاليا في وضع الصيانة ، فقط المدراء يمكنهم تسجيل الدخول. تذكر ان تقوم <strong><a class="strong" href="%1$s">بانهاء وضع الصيانة</a></strong> بمجرد انتهاءك من عملياتك الادارية.';
$txt['query_command_denied'] = 'حدثت اخطاء قاعدة البيانات التالية ، فضلا تأكد من صحة تنصيب منتداك';
$txt['query_command_denied_guests'] = 'يبدو ان هناك مشكلة في المنتدى مع قاعدة البيانات. هذه مشكلة مؤقتة ، لذا يرجى العودة لاحقا والمحاولة مرة أخرى. إذا كنت لا تزال ترى هذه الرسالة، الرجا إبلاغ الادارة عن الرسالة التالية:';
$txt['query_command_denied_guests_msg'] = 'الامر %1$s تم رفضه من جانب قاعدة البيانات';
$txt['last_edit_by'] = '<span class="lastedit">آخر تعديل</span>: %1$s بواسطة %2$s';
$txt['notify_deactivate'] = 'هل ترغب في إبطال التنبيه على الردود في هذا الموضوع؟';

$txt['date_registered'] = 'تاريخ التسجيل';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'مشاهدة احدث المشاركات جميعها';
$txt['is_recent_updated'] = '%1$s هو آخر موضوع تم تحديثه';

$txt['male'] = 'ذكر';
$txt['female'] = 'أنثى';

$txt['error_invalid_characters_username'] = 'لقد إستخدمت أحرف غير صالحه فى إسم المستخدم .';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'أهلاً،';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'مرحباً،';
$txt['select_destination'] = 'الرجاء تحديد الوجهة';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'أرسلت بواسطة';

$txt['icon_smiley'] = 'مبتسم';
$txt['icon_angry'] = 'غضبان';
$txt['icon_cheesy'] = 'فرح';
$txt['icon_laugh'] = 'ضاحك';
$txt['icon_sad'] = 'حزين';
$txt['icon_wink'] = 'يغمز';
$txt['icon_grin'] = 'تكشيرة';
$txt['icon_shocked'] = 'مذهول';
$txt['icon_cool'] = 'هادئ';
$txt['icon_huh'] = 'هااا؟';
$txt['icon_rolleyes'] = 'أعين متقلبة';
$txt['icon_tongue'] = 'لسان';
$txt['icon_embarrassed'] = 'خجول';
$txt['icon_lips'] = 'مقفل الشفتين';
$txt['icon_undecided'] = 'متردد';
$txt['icon_kiss'] = 'قبلة';
$txt['icon_cry'] = 'باكي';
$txt['icon_angel'] = 'بريئ';

$txt['moderator'] = 'مراقب';
$txt['moderators'] = 'مشرفين';

$txt['views'] = 'مشاهدة';
$txt['new'] = 'جديدة';
$txt['no_redir'] = 'تم اعادة توجيهه من %1$s ';

$txt['view_all_members'] = 'مشاهدة كافة الأعضاء';
$txt['view'] = 'مشاهدة';

$txt['viewing_members'] = 'مشاهدة الأعضاء %1$s إلى  %2$s';
$txt['of_total_members'] = 'من %1$s عضو';

$txt['forgot_your_password'] = 'هل نسيت كلمة المرور؟';

$txt['date'] = 'تاريخ';
// Use numeric entities in the below string.
$txt['from'] = 'من';
$txt['to'] = 'إلى';

$txt['board_topics'] = 'المواضيع';
$txt['members_title'] = 'تحكم الأعضاء';
$txt['members_list'] = 'قائمة الأعضاء';
$txt['new_posts'] = 'مشاركات جديدة';
$txt['old_posts'] = 'لا مشاركات جديدة';
$txt['redirect_board'] = 'توجيه إلى صفحة ويب';
$txt['redirect_board_to'] = 'جاري اعادة التوجيه الى %1$s ';

$txt['sendtopic_send'] = 'إرسال';
$txt['report_sent'] = 'تم إرسال تقريرك بنجاح .';
$txt['topic_sent'] = 'تم إرسال الموضوع بنجاح .';

$txt['time_offset'] = 'فارق التوقيت';
$txt['or'] = 'أو';

$txt['mention'] = 'تنبيهات';
$txt['notifications'] = 'تنبيهات';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = 'نأسف %1$s, تم حظرك من استخدام هذا المنتدى!';
$txt['your_ban_expires'] = 'حظرك سيتنهي في %1$s';
$txt['your_ban_expires_never'] = 'حظرك ليس له تاريخ انتهاء حاليا.';
$txt['ban_continue_browse'] = 'يمكنك متابعة تصفح المنتدى كزائر';

$txt['mark_as_read'] = 'تعليم كافة المشاركات كمقروءة';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'تعليم هذه المشاركات كمقروءة';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'موضوع مغلق';
$txt['normal_topic'] = 'موضوع عادي';
$txt['participation_caption'] = 'موضوع شاركت فيه';

$txt['print'] = 'طباعة';
$txt['topic_summary'] = 'نبذة عن الموضوع';
$txt['not_applicable'] = 'غ/م';
$txt['name_in_use'] = 'الاسم %1$s تم إستخدامه مسبقا من عضو آخر.';

$txt['total_members'] = 'إجمالي الأعضاء';
$txt['total_posts'] = 'إجمالي المشاركات';
$txt['total_topics'] = 'إجمالي المواضيع';

$txt['mins_logged_in'] = 'دقائق للبقاء متصلا';

$txt['preview'] = 'معاينة';
$txt['always_logged_in'] = 'البقاء متصل دوما';

$txt['logged'] = 'سجل';
// Use numeric entities in the below string.
$txt['ip'] = 'عنوان IP';

$txt['www'] = 'الموقع';
$txt['link'] = 'رابط';

$txt['by'] = 'بواسطة'; //Deprecated

$txt['hours'] = 'ساعات';
$txt['minutes'] = 'دقائق';
$txt['seconds'] = 'ثوان';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'ساعه';
$txt['days_word'] = 'ايام';

$txt['newest_member'] = ', العضو الجديد.'; //Deprecated

$txt['search_for'] = 'بحث عن';
$txt['search_match'] = 'مطابق';

$txt['maintain_mode_on'] = 'ملاحظة: المنتدى تحت \'الصيانة\'.';

$txt['read'] = 'زيارة'; //Deprecated
$txt['times'] = 'مرات'; //Deprecated
$txt['read_one_time'] = 'عدد مرات القراءة 1 مرة';
$txt['read_many_times'] = 'عدد مرات القراءة %1$d مرة';

$txt['forum_stats'] = 'حالة المنتدى';
$txt['latest_member'] = 'آخر عضو';
$txt['total_cats'] = 'إجمالي التصنيفات';
$txt['latest_post'] = 'آخر مشاركة';

$txt['here'] = 'هنا';
$txt['you_have_no_msg'] = 'لا يوجد لديك اي رسائل ...';
$txt['you_have_one_msg'] = 'يوجد لديك 1 رسالة...<a href="%1$s">انقر هنا لمشاهدتها</a>';
$txt['you_have_many_msgs'] = 'يوجد لديك %2$d رسالة...<a href="%1$s">انقر هنا لمشاهدتها</a>';

$txt['total_boards'] = 'إجمالي المنتديات';

$txt['print_page'] = 'طباعة الصفحة';
$txt['print_page_text'] = 'النص فقط';
$txt['print_page_images'] = 'النص والصور';

$txt['valid_email'] = 'يجب أن يكون البريد صحيحا.';

$txt['info_center_title'] = '%1$s - مركز المعلومات';

$txt['send_topic'] = 'مشاركة الموضوع';
$txt['unwatch'] = 'الغاء متابعة الموضوع';
$txt['watch'] = 'متابعة الموضوع';

$txt['sendtopic_title'] = 'إرسال الموضوع &quot;%1$s&quot; إلى صديق.';
$txt['sendtopic_sender_name'] = 'الأسم';
$txt['sendtopic_sender_email'] = 'البريد الإلكتروني';
$txt['sendtopic_receiver_name'] = 'اسم المرسل إليه';
$txt['sendtopic_receiver_email'] = 'البريد الإلكتروني للمرسل إليه';
$txt['sendtopic_comment'] = 'إضافة تعليق';

$txt['allow_user_email'] = 'السماح للأعضاء بمراسلتي على البريد الإلكتروني';

$txt['check_all'] = 'تحديد الكل';

// Use numeric entities in the below string.
$txt['database_error'] = 'خطأ في قاعدة البيانات';
$txt['try_again'] = 'الرجاء المحاولة مرة أخرى. إذا عدت مرة أخرى إلى صفحة الخطأ هذه، الرجاء إبلاغ الإدارة.';
$txt['file'] = 'الملف';
$txt['line'] = 'السطر';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'تم اكتشاف خطأ في قاعدة البيانات الخاصة بك وتمت محاولة اصلاحه تلقائيا. إذا استمر حدوث مشاكل، أو استمر ظهور هذه الرسائل، يرجى الاتصال بمسئولي الاستضافة .';
$txt['database_error_versions'] = '<strong>ملاحظة:</strong> اصدار قاعدة البيانات لديك هو %1$s.';
$txt['template_parse_error'] = 'خطأ في معالجة القالب!';
$txt['template_parse_error_message'] = 'يبدو أن هنالك مشكلة في نظام القوالب. هذه المشكلة مؤقتة فالرجاء العودة لاحقا و المحاولة مرة أخرى. إذا عاودتك هذه الرسالة مرة أخرى الرجاء الاتصال بالإدارة.<br />يمكنك أن تقوم <a href="javascript:location.reload();">بإعادة تحديث الصفحة</a>.';
$txt['template_parse_error_details'] = 'حدثت مشكلة اثناء تحميل القالب او ملف اللغة <span class="tt"><strong>%1$s</strong></span>  فضلا راجع المفردات البرمجية وقم باعادة المحاولة - وتذكر أن علامات الاقتباس المفردة (<span class="tt">\'</span>) يجب ان يسبقها دائما علامة الشرطة المائلة المعكوسة (<span class="tt">\\</span>).  لمشاهدة معلومات اكثر تحديدا عن هذا الخطأ من لغة PHP, حاول <a href="%2$s%1$s">استعراض الملف مباشرة</a>.<br /><br />ربما تريد محاولة <a href="javascript:location.reload();">اعادة تحميل هذه الصفحة</a> او <a href="%3$s">استخدم القالب الافتراضي</a>.';
$txt['template_parse_undefined'] = 'حدث خطأ غير محدد اثناء محاولة عرض هذا القالب';

$txt['today'] = 'اليوم الساعة %1$s';
$txt['yesterday'] = 'أمس الساعة %1$s';

// Relative times
$txt['rt_now'] = 'الآن';
$txt['rt_minute'] = 'منذ دقيقة';
$txt['rt_minutes'] = 'منذ %s دقيقة';
$txt['rt_hour'] = 'منذ ساعة';
$txt['rt_hours'] = 'منذ %s ساعة';
$txt['rt_day'] = 'منذ يوم';
$txt['rt_days'] = 'منذ %s يوم';
$txt['rt_week'] = 'منذ أسبوع';
$txt['rt_weeks'] = 'منذ %s أسبوع';
$txt['rt_month'] = 'منذ شهر';
$txt['rt_months'] = 'منذ %s شهر';
$txt['rt_year'] = 'منذ عام';
$txt['rt_years'] = 'منذ %s عام';

$txt['new_poll'] = 'كتابة إستفتاء جديد';
$txt['poll_question'] = 'سؤال';
$txt['poll_question_options'] = 'السؤال والاختيارات';
$txt['poll_vote'] = 'إضافة تصويت';
$txt['poll_total_voters'] = 'إجمالي التصويت';
$txt['draft_saved_on'] = 'آخر حفظ للمسودة';
$txt['poll_results'] = 'عرض النتائج.';
$txt['poll_lock'] = 'إغلاق التصويت';
$txt['poll_unlock'] = 'فتح التصويت';
$txt['poll_edit'] = 'تحرير التصويت';
$txt['poll'] = 'التصويت';
$txt['one_day'] = '1 يوم';
$txt['one_week'] = '1 أسبوع';
$txt['two_weeks'] = '2 أسبوع';
$txt['one_month'] = '1 شهر';
$txt['two_months'] = '2 شهر';
$txt['forever'] = 'غير محدد';
$txt['quick_login_dec'] = 'تسجيل الدخول باسم المستخدم، كلمة المرور و الفترة الزمنية';
$txt['one_hour'] = '1 ساعة';
$txt['moved'] = 'نقل';
$txt['moved_why'] = 'الرجاء كتابة نبذة مختصرة عن السبب<br />نقل هذا الموضوع.';
$txt['board'] = 'منتدى';
$txt['in'] = 'في';
$txt['sticky_topic'] = 'موضوع مثبت';
$txt['split'] = 'تقسيم';

$txt['delete'] = 'حذف';

$txt['byte'] = 'بايت';
$txt['kilobyte'] = 'كيلوبايت';
$txt['megabyte'] = 'ميجابايت';
$txt['gigabyte'] = 'ميجابايت';

$txt['more_stats'] = '[إحصاءات أخرى]';

// Use numeric entities in the below three strings.
$txt['code'] = 'كود برمجي';
$txt['code_select'] = '[اختيار]';
$txt['quote_from'] = 'مقتبس من';
$txt['quote'] = 'اقتباس';
$txt['quote_new'] = 'موضوع جديد';
$txt['follow_ups'] = 'متابعات';
$txt['topic_derived_from'] = 'الموضوع مستلم من %1$s ';
$txt['edit'] = 'تعديل';
$txt['quick_edit'] = 'تعديل سريع';
$txt['post_options'] = 'المزيد';

$txt['set_sticky'] = 'تثبيت';
$txt['set_nonsticky'] = 'الغاء تثبيت';
$txt['set_lock'] = 'غلق';
$txt['set_unlock'] = 'إلغاء الغلق';

$txt['search_advanced'] = 'عرض الخيارات المتقدمة';
$txt['search_simple'] = 'اخفاء الخيارات المتقدمة';

$txt['security_risk'] = 'خطر أمني:';
$txt['not_removed'] = 'لم تقم بحذف %1$s';
$txt['not_removed_extra'] = '%1$s هى نسخة إحتياطية من %2$s و التى لم يتم انشائها بواسطة ElkArte. و يمكن الوصول إليها مباشرة و إستغلالها فى إختراق المنتدى . يجب عليك حذفها فورا.';
$txt['generic_warning'] = 'تحذير';
$txt['agreement_missing'] = 'الأعضاء الجدد مطالبون بقبول شروط التسجيل لكن ملف الشروط (agreement.txt) غير موجود';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'لقد قمت بتحديث';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">انقر هنا لمشاهدة ماهو الجديد في هذا الاصدار من ElkArte!</a>!';

$txt['cache_writable'] = 'مجلد الذاكرة الوسيطة غير قابل للكتابة - هذا سيؤثر سلبا على أداء منتداكم.';

$txt['page_created_full'] = 'تم انشاء الصفحة في %1$.3f ثانية باستخدام %2$d استعلام';

$txt['report_to_mod_func'] = 'استخدم هذه الميزة لتنبيه المشرف و المدير عن المشاركات الغير مناسبة، <br /><em> يرجى ملاحظة أن عنوان البريد الإلكتروني الخاص بك سيتم كشفه للمشرفين عند إستخدامك لهذه الخاصية</em>';

$txt['online'] = 'متصل';
$txt['member_is_online'] = '%1$s متصل الآن';
$txt['offline'] = 'غير متصل';
$txt['member_is_offline'] = '%1$s غير متصل الآن';
$txt['pm_online'] = 'رسالة شخصية (متصل)';
$txt['pm_offline'] = 'رسالة شخصية (غير متصل)';
$txt['status'] = 'الحالات';

$txt['skip_nav'] = 'الذهاب الى الموضوع الرئيسي';
$txt['go_up'] = 'للأعلى';
$txt['go_down'] = 'للأسفل';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'أعياد الميلاد:';
$txt['events'] = 'أحداث:';
$txt['birthdays_upcoming'] = 'أعياد الميلاد القادمة:';
$txt['events_upcoming'] = 'الأحداث القادمة:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'العطلات:';
$txt['calendar_month'] = 'شهر:';
$txt['calendar_year'] = 'سنة:';
$txt['calendar_day'] = 'يوم:';
$txt['calendar_event_title'] = 'عنوان الحدث:';
$txt['calendar_event_options'] = 'خيارات الأحداث';
$txt['calendar_post_in'] = 'حرر في:';
$txt['calendar_edit'] = 'تحرير الحدث';
$txt['event_delete_confirm'] = 'حذف هذا الحدث؟';
$txt['event_delete'] = 'حذف الحدث';
$txt['calendar_post_event'] = 'كتابة الحدث';
$txt['calendar'] = 'إدارة التقويم';
$txt['calendar_link'] = 'رابط للتقويم';
$txt['calendar_upcoming'] = 'التقويم القادم';
$txt['calendar_today'] = 'تقويم اليوم';
$txt['calendar_week'] = 'أسبوع';
$txt['calendar_week_title'] = 'الإسبوع %1$d من %2$d';
$txt['calendar_numb_days'] = 'عدد الأيام:';
$txt['calendar_how_edit'] = 'كيف تحرر هذه الأحداث؟';
$txt['calendar_link_event'] = 'رابط للحدث';
$txt['calendar_confirm_delete'] = 'هل انت متاكد من أنك تريد حذف هذه المناسبة؟';
$txt['calendar_linked_events'] = 'مناسبات مترابطة';
$txt['calendar_click_all'] = 'اضغط لمشاهدة كل %1$s';

$txt['moveTopic1'] = 'إعادة توجيه الموضوع';
$txt['moveTopic2'] = 'تغيير عنوان الموضوع';
$txt['moveTopic3'] = 'العنوان الجديد';
$txt['moveTopic4'] = 'تغيير عناوين كافة المشاركات';
$txt['move_topic_unapproved_js'] = 'تحذير! هذا الموضوع لم يتم الموافقة عليه بعد .\\n\\nغير محبذ إنشاء موضوع معاد التوجيه إلا إذا كنت تود الموافقة عليه مباشرة بعد النقل.';
$txt['movetopic_auto_board'] = '[منتدى]';
$txt['movetopic_auto_topic'] = '[رابط الموضوع]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'اعادة التوجيه الى الموضوع المنقول';
$txt['movetopic_expires'] = 'ازالة الموضوع المعاد توجيهه تلقائيا';

$txt['merge_to_topic_id'] = 'رقم الـID للموضوع الهدف';
$txt['split_topic'] = 'تقسيم';
$txt['merge'] = 'دمج';
$txt['subject_new_topic'] = 'عنوان الموضوع الجديد';
$txt['split_this_post'] = 'تجزئة هذه المشاركة فقط.';
$txt['split_after_and_this_post'] = 'تجزئة الموضوع بدء من هذه المشاركة وما يليها.';
$txt['select_split_posts'] = 'اختر المشاركات التي ستجزء.';

$txt['splittopic_notification'] = 'عرض رسالة عند تقسيم الموضوع';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'نقل الموضوع الجديد الى منتدى آخر';

$txt['new_topic'] = 'موضوع جديد';
$txt['split_successful'] = 'تم تجزئة الموضوع إلى اثنين بنجاح.';
$txt['origin_topic'] = 'أصل الموضوع';
$txt['please_select_split'] = 'الرجاء تحديد المشاركات المراد تجزءتها.';
$txt['merge_successful'] = 'تم دمج المواضيع بنجاح.';
$txt['new_merged_topic'] = 'الموضوع المدمج الجديد';
$txt['topic_to_merge'] = 'الموضوع الذي سيدمج';
$txt['target_board'] = 'المنتدى الهدف';
$txt['target_topic'] = 'الموضوع الهدف';
$txt['merge_confirm'] = 'هل ترغب حقا في دمج';
$txt['with'] = 'مع';
$txt['merge_desc'] = 'هذه الخاصية ستقوم بدمج المشاركات لموضوعين مختلفين في موضوع واحد. سيتم فرز المشاركات بحسب تاريخ الرسالة. لذا ستكون أقدم رسالة هي في الترتيب الأول في الموضوع المدمج.';

$txt['theme_template_error'] = 'لا يمكن تحميل القالب \'%1$s\' .';
$txt['theme_language_error'] = 'لا يمكن تحميل ملف اللغة \'%1$s\' .';

$txt['parent_boards'] = 'منتديات فرعية';

$txt['smtp_no_connect'] = 'لا يمكن الاتصال بمستضيف SMTP ';
$txt['smtp_port_ssl'] = 'إعدادات المنفذ للـ  SMTP غير صحيحة، يجب ان تكون 465 لخوادم الـ SSL.';
$txt['smtp_bad_response'] = 'لا يمكن الحصول على رموز ردّ خادم البريد';
$txt['smtp_error'] = 'حصل خطا عند إرسال البريد. الخطأ: ';
$txt['mail_send_unable'] = 'لا يمكن إرسال الرسالة إلى عنوان البريد الإلكتروني \'%1$s\'';

$txt['mlist_search'] = 'البحث عن الأعضاء';
$txt['mlist_search_again'] = 'البحث مرة أخرى'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'البحث بواسطة عنوان البريد الإلكتروني';
$txt['mlist_search_group'] = 'البحث بواسطة المنصب';
$txt['mlist_search_name'] = 'البحث بواسطة الاسم';
$txt['mlist_search_website'] = 'البحث بواسطة موقع الويب';
$txt['mlist_search_results'] = 'نتائج البحث لـ';
$txt['mlist_search_by'] = 'البحث من خلال %1$s';

$txt['attach_downloaded'] = 'تم تنزيله %1$d مرة';
$txt['attach_viewed'] = 'تم مشاهدته %1$d مرة';

$txt['settings'] = 'الإعدادات';
$txt['never'] = 'ابدأ';
$txt['more'] = 'المزيد';

$txt['hostname'] = 'اسم المستضيف (Hostname)';
$txt['you_are_post_banned'] = 'نأسف %1$s, لقد تم حظرك من الكتابة و إرسال الرسائل الشخصية في هذا المنتدى.';
$txt['ban_reason'] = 'السبب';

$txt['add_poll'] = 'إضافة إستفتاء';
$txt['poll_options6'] = 'يمكنك إختيار ما عدده %1$s خيار.';
$txt['poll_remove'] = 'حذف الإستفتاء';
$txt['poll_remove_warn'] = 'هل تود حذف هذا الإستفتاء من الموضوع؟';
$txt['poll_results_expire'] = 'النتائج ستعرض بعد إغلاق الاستفتاء';
$txt['poll_expires_on'] = 'التصويت مغلق';
$txt['poll_expired_on'] = 'إغلاق التصويت';
$txt['poll_change_vote'] = 'حذف التصويت';
$txt['poll_return_vote'] = 'خصائص التصويت';
$txt['poll_cannot_see'] = 'حاليا لايمكنك مشاهدة نتائج هذا الإستفتاء';

$txt['quick_mod_approve'] = 'الموافقة على الإختيارات المحددة';
$txt['quick_mod_remove'] = 'حذف المعلم';
$txt['quick_mod_lock'] = 'إغلاق/فتح المحدد';
$txt['quick_mod_sticky'] = 'اختيار تثبيت/إلغاء التثبيت';
$txt['quick_mod_move'] = 'نقل الإختيارات المحددة إلى';
$txt['quick_mod_merge'] = 'دمج الإختيارات المحددة';
$txt['quick_mod_markread'] = 'تحديد كـ مقروء';
$txt['quick_mod_go'] = 'اذهب';
$txt['quickmod_confirm'] = 'هل أنت متأكد من فعل هذا؟';

$txt['spell_check'] = 'تدقيق إملائي';

$txt['quick_reply'] = 'الرد السريع';
$txt['quick_reply_warning'] = 'تحذير! هذا الموضوع مغلق حاليا ، فقط المدراء و المشرفين يمكنهم الرد';
$txt['quick_reply_verification'] = 'بعد إرسال المشاركة سوف يتم توجيهك لصفحة إرسال المشاركة الافتراضية لكي ننأكد من مشاركتك %1$s.';
$txt['quick_reply_verification_guests'] = '(مطلوب من كل الضيوف)';
$txt['quick_reply_verification_posts'] = '(مطلوب من كل الأعضاء ذوي عدد مشاركات أقل من %1$d مشاركة)';
$txt['wait_for_approval'] = 'ملاحظة: هذه المشاركة لن يتم عرضها حتى يتم الموافقة عليها من قبل المشرف.';

$txt['notification_enable_board'] = 'هل ترغب في تمكين تنبيه المواضيع الجديدة لهذا المنتدى؟';
$txt['notification_disable_board'] = 'هل ترغب في إبطال تنبيه المواضيع الجديدة لهذا المنتدى؟';
$txt['notification_enable_topic'] = 'هل ترغب في تمكين تنبيه الردود الجديدة لهذا الموضوع؟';
$txt['notification_disable_topic'] = 'هل ترغب في إبطال تنبيه الردود الجديدة لهذا الموضوع؟';

$txt['report_to_mod'] = 'ابلاغ عن مشاركة';
$txt['issue_warning_post'] = 'إرسال تنبيه بسبب هذه المشاركة';

$txt['like_post'] = 'اعجاب';
$txt['unlike_post'] = 'الغاء الاعجاب';
$txt['likes'] = 'اعجاب';
$txt['liked_by'] = 'اعجاب بواسطة';
$txt['liked_you'] = 'أنت';
$txt['liked_more'] = 'المزيد';
$txt['likemsg_are_you_sure'] = 'لقد سجلت اعجابك بهذه المشاركة سابقا ، هل انت متأكد أنك تريد الغاء الاعجاب؟';

$txt['unread_topics_visit'] = 'آخر مواضيع غير مقروءة';
$txt['unread_topics_visit_none'] = 'لا يوجد موضوعات غير مقروءة منذ زيارتك الاخيرة <a href="{unread_all_url}" class="linkbutton">انقر هنا لمشاهدة جميع الموضوعات الغير مقروءة</a>';
$txt['unread_topics_all'] = 'كافة المواضيع غير المقروءة';
$txt['unread_replies'] = 'مواضيع محدثة';

$txt['who_title'] = 'من المتصل';
$txt['who_and'] = ' و ';
$txt['who_viewing_topic'] = ' يشاهدون هذا الموضوع.';
$txt['who_viewing_board'] = ' يشاهدون هذا المنتدى.';
$txt['who_member'] = 'العضو';

// Current footer strings
$txt['valid_html'] = 'Valid HTML 5';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'زائر';
$txt['guests'] = 'ضيوف غير مسجلين';
$txt['user'] = 'مستخدم';
$txt['users'] = 'مستخدمين';
$txt['hidden'] = 'مخفي';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'مخفي';
$txt['buddy'] = 'صديق';
$txt['buddies'] = 'أصدقاء';
$txt['most_online_ever'] = 'أعلى عدد متصلين في آن واحد';
$txt['most_online_today'] = 'أعلى عدد متصلين معا اليوم';

$txt['merge_select_target_board'] = 'اختر المنتدى الهدف للموضوع المدموج';
$txt['merge_select_poll'] = 'اختر أي اقتراع للموضوع المدموج';
$txt['merge_topic_list'] = 'اختر المواضيع التي ستدمج';
$txt['merge_select_subject'] = 'اختر العنوان للموضوع المدموج';
$txt['merge_custom_subject'] = 'عنوان جديد';
$txt['merge_enforce_subject'] = 'تغير العنوان لكافة المشاركات';
$txt['merge_include_notifications'] = 'تضمين التنبيهات؟';
$txt['merge_check'] = 'دمج؟';
$txt['merge_no_poll'] = 'لا اقتراع';

$txt['response_prefix'] = 'رد: ';
$txt['current_icon'] = 'الصورة الرمزية الحالية';
$txt['message_icon'] = 'الصورة الرمزية';

$txt['smileys_current'] = 'مجموعة الابتسامات الحالية';
$txt['smileys_none'] = 'بدون ابتسامات';
$txt['smileys_forum_board_default'] = 'افتراضي المنتدى\\الاقسام';

$txt['search_results'] = 'نتائج البحث';
$txt['search_no_results'] = 'نأسف، لم يتم العثور على نتائج';

$txt['totalTimeLogged2'] = ' أيام, ';
$txt['totalTimeLogged3'] = ' ساعة و  ';
$txt['totalTimeLogged4'] = ' دقيقة.';
$txt['totalTimeLogged5'] = 'ي ';
$txt['totalTimeLogged6'] = 'س ';
$txt['totalTimeLogged7'] = 'د';

$txt['approve_thereis'] = 'يوجد'; //Deprecated
$txt['approve_thereare'] = 'يوجد'; //Deprecated
$txt['approve_member'] = 'عضو واحد'; //Deprecated
$txt['approve_members'] = 'أعضاء'; //Deprecated
$txt['approve_members_waiting'] = 'ينتظرون الموافقة.'; //Deprecated
$txt['approve_one_member_waiting'] = 'يوجد <a href="%1$s">عضو واحد</a> في انتظار الموافقة.';
$txt['approve_many_members_waiting'] = 'يوجد <a href="%1$s">%2$d أعضاء</a> في انتظار الموافقة.';

$txt['notifyboard_turnon'] = 'هل تريد بريد إرسال تنبيه إلكتروني عندما يرسل شخص ما موضوعا جديدا في هذه المنتدى؟';
$txt['notifyboard_turnoff'] = 'هل أنت متأكّد أنك لا تريد استلام تنبيهات عن المواضيع الجديدة في هذا المنتدى؟';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'بحث الأعضاء';
$txt['find_username'] = 'الاسم، اسم المستخدم أو عنوان البريد';
$txt['find_buddies'] = 'أظهر الأصدقاء فقط ?';
$txt['find_wildcards'] = 'اللواحق المسموح بها: *, ?';
$txt['find_no_results'] = 'لم يتم العثور على نتائج';
$txt['find_results'] = 'نتائج';
$txt['find_close'] = 'إغلاق';

$txt['quickmod_delete_selected'] = 'حذف المختار';
$txt['quickmod_split_selected'] = 'تقسيم المختارة';

$txt['show_personal_messages_heading'] = 'رسالة شخصية جديدة';
$txt['show_personal_messages'] = 'يوجد لديك<strong>%1$s</strong> رسائل شخصية غير مقروءة في صندوق الوارد.<br /><br /><a href="%2$s">اذهب الى صندوق الوارد</a>';

$txt['help_popup'] = 'تشعر ببعض الارتباك؟ دعني أقوم بالتوضيح :';

$txt['previous_next_back'] = 'الموضوع السابق';
$txt['previous_next_forward'] = 'الموضوع التالي';

$txt['upshrink_description'] = 'تقليص أو توسيع الترويسه.';

$txt['mark_unread'] = 'علم كغير مقروء';

$txt['ssi_not_direct'] = 'الرجاء عدم الدخول إلى SSI.php بواسطة URL مباشر; يمكنك أن تستخدم المسار (%1$s) أو تضيف ?ssi_function=something.';
$txt['ssi_session_broken'] = 'SSI.php لم يستطع أن يحمل الجلسة! قد يسبب ذلك مشكلة في تسجيل الخروج و غيرها من التوابع - أرجو الانتباه إلى أن SSI.php مدخل من قبل *أي شيء* آخر من قبل أكوادك!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'عرض الموضوع';
$txt['preview_fetch'] = 'جلب العرض...';
$txt['pm_error_while_submitting'] = 'الخطأ أو الأخطاء التالية حدثت عند إرسال الرسالة الشخصية:';
$txt['warning_while_submitting'] = 'لقد حدث شيئ ما ، قم بمراجعته هنا:';
$txt['error_while_submitting'] = 'الرسالة تحتوي على الخطأ أو الأخطاء التالية ولابد من التصحيح قبل الاستمرار';
$txt['error_old_topic'] = 'تحذير: لم يتم المشاركة في هذا الموضوع لأكثر من %1$d يوم.<br />مالم تكن متأكدا من أنك تريد أن تشارك في هذا الموضوع, فكر في إنشاء موضوع جديد.';

$txt['split_selected_posts'] = 'مواضيع مختارة';
$txt['split_selected_posts_desc'] = 'هذه المشاركات التي في الأسفل سوف تقوم بإنشاء موضوع جديد بعد الفصل.';
$txt['split_reset_selection'] = 'الغاء تعليم الكل';

$txt['modify_cancel'] = 'إلغاء';
$txt['mark_read_short'] = 'تعليم مقروء';

$txt['hello_member_ndt'] = 'أهلا';

$txt['unapproved_posts'] = 'المشاركات التي لم يوافق عليها (المواضيع: %1$d, المشاركات: %2$d)';

$txt['ajax_in_progress'] = 'تحميل...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = 'هناك حاليا  %1$d مشرف التقرير مفتوح.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'انقر لمشاهدة المشاركات الجديدة في  %1$s';
$txt['verification'] = 'التحقق';
$txt['visual_verification_hidden'] = 'فضلا اترك هذا المربع خاليا';
$txt['visual_verification_description'] = 'الرجاء كتابة الأحرف الظاهر بالصورة';
$txt['visual_verification_sound'] = 'الاستماع إلى الأحرف';
$txt['visual_verification_request_new'] = 'طلب صورة جديدة';

// @todo Send email strings - should move?
$txt['send_email'] = 'إرسال بريد الكتروني';
$txt['send_email_disclosed'] = 'هذا القسم سيكون مرئي من قبل المستلم.';
$txt['send_email_subject'] = 'عنوان البريد الالكتروني';

$txt['ignoring_user'] = 'أنت تقوم بتجاهل هذا العضو.';
$txt['show_ignore_user_post'] = '<em>[اظهار المشاركة]</em>';

$txt['spider'] = 'عنكبوت الكتروني';
$txt['spiders'] = 'عناكب الكترونية';
$txt['openid'] = 'خدمة الهوية المشتركة (OpenID)';

$txt['downloads'] = 'تحميل';
$txt['filesize'] = 'حجم الملف';
$txt['subscribe_webslice'] = 'الاشتراك بـويب سلايس'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'استعادة موضوع';
$txt['restore_message'] = 'استعادة';
$txt['quick_mod_restore'] = 'استعادة المحدد';

// Editor prompt.
$txt['prompt_text_email'] = 'الرجاء ادخال البريد الإلكتروني';
$txt['prompt_text_ftp'] = 'فضلا قم بادخال عنوان ال FTP';
$txt['prompt_text_url'] = 'الرجاء ادخال الرابط التي تريد مشاهدته';
$txt['prompt_text_img'] = 'ادخل مكان الصورة';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'مسح العنصر';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> قام بمنع %1$s محاولات اختراق خلال 7 ايام الماضية.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'القوالب :';
$txt['debug_subtemplates'] = 'القوالب الفرعية :'; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'القوالب الفرعية :';
$txt['debug_language_files'] = 'ملفات اللغة :';
$txt['debug_sheets'] = 'ملفات style.css :';
$txt['debug_javascript'] = 'السكربتات:';
$txt['debug_files_included'] = 'الملفات :';
$txt['debug_kb'] = 'كيلو بايت .';
$txt['debug_show'] = 'إظهر';
$txt['debug_cache_hits'] = 'ضغطات ذاكرة التخزين المؤقتة :';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s بايت';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss من %2$s بايت';
$txt['debug_queries_used'] = 'الإستعلامات التى تم إستخدامها: %1$d.';
$txt['debug_queries_used_and_warnings'] = 'الإستعلامات التى تم إستخدامها: %1$d, %2$d تحذير. ';
$txt['debug_query_in_line'] = 'فى <em>%1$s</em> السطر <em>%2$s</em>, ';
$txt['debug_query_which_took'] = 'التى إستغرقت %1$s ثانية. ';
$txt['debug_query_which_took_at'] = 'التى أخذت %1$s ثانية فى %2$s الطلب. ';
$txt['debug_show_queries'] = '[إظهر الإستعلامات]';
$txt['debug_hide_queries'] = '[إخفى الإستعلامات]';
$txt['debug_tokens'] = 'المعرفات';
$txt['debug_browser'] = 'معرف المتصفح';
$txt['debug_hooks'] = 'الخطاطيف المستخدمة:';
$txt['debug_system_type'] = 'النظام:';
$txt['debug_server_load'] = 'الحمل على الملقم:';
$txt['debug_script_mem_load'] = 'الذاكرة المستخدمة للسكربت:';
$txt['debug_script_cpu_load'] = 'وقت وحدة المعالجة للسكربت (مستخدم/نظام):';

// Video embedding
$txt['preview_image'] = 'صورة المعاينة للفيديو';
$txt['ctp_video'] = 'انقر لتشغيل الفيديو، انقر مرتان لتنزيل الفيديو';
$txt['hide_video'] = 'اظهار/اخفاء الفيديو';
$txt['youtube'] = 'فيديو من موقع يوتيوب:';
$txt['vimeo'] = 'فيديو من موقع فيمو:';
$txt['dailymotion'] = 'فيديو من موقع ديلي موشن:';

// Spoiler BBC
$txt['spoiler'] = 'سبويلر (انقر للاظهار/للاخفاء)';

$txt['ok_uppercase'] = 'موافق';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'تحذير';

$txt['via'] = 'عبر';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
