<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Mitteilungen';
$txt['pm_add'] = 'Hinzufügen';
$txt['make_bcc'] = 'Bcc hinzufügen';
$txt['pm_to'] = 'An';
$txt['pm_bcc'] = 'Bcc';
$txt['inbox'] = 'Posteingang';
$txt['conversation'] = 'Gesprächsfaden';
$txt['messages'] = 'Mitteilungen';
$txt['sent_items'] = 'Postausgang';
$txt['new_message'] = 'Neue Mitteilung verfassen';
$txt['delete_message'] = 'Lösche Mitteilung';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Alle Mitteilungen in deinem Posteingang löschen';
$txt['delete_all_confirm'] = 'Bist du sicher, dass du alle Mitteilungen löschen möchtest?';

$txt['delete_selected_confirm'] = 'Bist du sicher, dass du die ausgewählte(n) Mitteilung(en) löschen möchtest?';

$txt['sent_to'] = 'Gesendet an';
$txt['reply_to_all'] = 'Allen antworten';
$txt['delete_conversation'] = 'Gesprächsfaden löschen';

$txt['pm_capacity'] = 'Kapazität';
$txt['pm_currently_using'] = '%1$s Mitteilungen, %2$s%% voll.';
$txt['pm_sent'] = 'Deine Mitteilung wurde erfolgreich versandt.';

$txt['pm_error_user_not_found'] = 'Kann Benutzer %1$s nicht finden.';
$txt['pm_error_ignored_by_user'] = 'Benutzer %1$s hat deine Mitteilungen geblockt.';
$txt['pm_error_data_limit_reached'] = 'Mitteilung konnte nicht an %1$s gesendet werden, sein Postfach ist voll.';
$txt['pm_error_user_cannot_read'] = 'Der Benutzer %1$s kann keine Mitteilungen empfangen.';
$txt['pm_successfully_sent'] = 'Mitteilung erfolgreich an %1$s gesendet.';
$txt['pm_send_report'] = 'Meldung senden';
$txt['pm_undisclosed_recipients'] = 'Verdeckter Empfänger';
$txt['pm_too_many_recipients'] = 'Dir fehlt die nötige Berechtigung, mehr als %1$d Empfänger für eine Mitteilung auf einmal auszuwählen.';

$txt['pm_read'] = 'Lesen';
$txt['pm_replied'] = 'Geantwortet an';
$txt['pm_mark_unread'] = 'Als ungelesen markieren';

// Message Pruning.
$txt['pm_prune'] = 'Bereinigen';
$txt['pm_prune_desc'] = 'Lösche alle Mitteilungen, die älter als %1$s Tage sind.';
$txt['pm_prune_warning'] = 'Bist du sicher, dass du deine Mitteilungen bereinigen möchtest?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Weitere Aktionen';
$txt['pm_actions_delete_selected'] = 'Ausgewähltes Smiley-Set löschen';
$txt['pm_actions_filter_by_label'] = 'Nach Label filtern';
$txt['pm_actions_go'] = 'Los';

// Manage Labels Screen.
$txt['pm_apply'] = 'Übernehmen';
$txt['pm_manage_labels'] = 'Labels verwalten';
$txt['pm_labels_delete'] = 'Bist du sicher, dass du die ausgewählten Labels löschen möchtest?';
$txt['pm_labels_desc'] = 'Hier kannst du Labels zu deinen Mitteilungen hinzufügen, editieren und löschen.';
$txt['pm_label_add_new'] = 'Neues Label';
$txt['pm_label_name'] = 'Label-Name';
$txt['pm_labels_no_exist'] = 'Du hast noch keine Labels erstellt';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Label';
$txt['pm_msg_label_title'] = 'Mitteilung labeln';
$txt['pm_msg_label_apply'] = 'Label anhängen';
$txt['pm_msg_label_remove'] = 'Label entfernen';
$txt['pm_msg_label_inbox'] = 'Posteingang';
$txt['pm_sel_label_title'] = 'Ausgewählte labeln';

// Sidebar Headings.
$txt['pm_labels'] = 'Label';
$txt['pm_messages'] = 'Mitteilungen';
$txt['pm_actions'] = 'Aktionen';
$txt['pm_preferences'] = 'Einstellungen';

$txt['pm_is_replied_to'] = 'Du hast diese Mitteilung schon beantwortet oder weitergeleitet.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Einem Administrator melden';
$txt['pm_report_title'] = 'Mitteilung melden';
$txt['pm_report_desc'] = 'Hier kannst du Mitteilungen den Administratoren melden. Bitte füge eine kurze Beschreibung an, warum du diese Mitteilung melden möchtest. Die Beschreibung wird mit der Originalnachricht versendet.';
$txt['pm_report_admins'] = 'An folgenden Administrator melden';
$txt['pm_report_all_admins'] = 'An alle Administratoren melden';
$txt['pm_report_reason'] = 'Grund für die Meldung der Mitteilung';
$txt['pm_report_message'] = 'Mitteilung melden';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[MELDUNG] ';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} hat die untenstehende Mitteilung, die von {SENDER} gesendet wurde, mit folgendem Grund gemeldet:';
$txt['pm_report_pm_other_recipients'] = 'Andere Empfänger der Meldung:';
$txt['pm_report_pm_hidden'] = '%1$d versteckte Empfänger';
$txt['pm_report_pm_unedited_below'] = 'Der Originaltext der gemeldeten Mitteilung lautet wie folgt:';
$txt['pm_report_pm_sent'] = 'Gesendet:';

$txt['pm_report_done'] = 'Vielen Dank für das Melden der Mitteilung. Du solltest in Kürze von den Administratoren eine Antwort erhalten.';
$txt['pm_report_return'] = 'Zurück zum Posteingang';

$txt['pm_search_title'] = 'Durchsuchen';
$txt['pm_search_bar_title'] = 'Durchsuchen';
$txt['pm_search_text'] = 'Suche nach';
$txt['pm_search_go'] = 'Suche';
$txt['pm_search_advanced'] = 'Erweiterte Optionen anzeigen';
$txt['pm_search_simple'] = 'Erweiterte Optionen verstecken';
$txt['pm_search_user'] = 'Nach Benutzer';
$txt['pm_search_match_all'] = 'Übereinstimmung aller Wörter';
$txt['pm_search_match_any'] = 'Übereinstimmung nur eines Wortes';
$txt['pm_search_options'] = 'Optionen';
$txt['pm_search_post_age'] = 'Alter der Mitteilung';
$txt['pm_search_show_complete'] = 'Vollständige Mitteilung in den Suchergebnissen anzeigen.';
$txt['pm_search_subject_only'] = 'Suche nur nach Betreff und Autor.';
$txt['pm_search_sent_only'] = 'Nur in den versendeten Mitteilungen suchen.';
$txt['pm_search_between'] = 'Zwischen';
$txt['pm_search_between_and'] = 'und';
$txt['pm_search_between_days'] = 'Tagen';
$txt['pm_search_order'] = 'Suchreihenfolge';
$txt['pm_search_choose_label'] = 'Labels zum Suchen auswählen oder alle durchsuchen';

$txt['pm_search_results'] = 'Suchergebnisse';
$txt['pm_search_none_found'] = 'Keine Mitteilungen gefunden';

$txt['pm_search_orderby_relevant_first'] = 'Größte Relevanz zuerst';
$txt['pm_search_orderby_recent_first'] = 'Neueste Mitteilungen zuerst';
$txt['pm_search_orderby_old_first'] = 'Älteste Mitteilungen zuerst';

$txt['pm_visual_verification_label'] = 'Verifizierung';
$txt['pm_visual_verification_desc'] = 'Bitte gebe den Code auf oben stehender Grafik ein, um diese Mitteilung zu versenden.';

$txt['pm_settings'] = 'Einstellungen ändern';
$txt['pm_change_view'] = 'Ansicht ändern';

$txt['pm_manage_rules'] = 'Regeln verwalten';
$txt['pm_manage_rules_desc'] = 'Hier kannst du deine eingehenden Mitteilungen automatisch nach bestimmten Kriterien sortieren. Um eine Regel zu bearbeiten, klicke den Namen der Regel an.';
$txt['pm_rules_none'] = 'Du hast keine Regeln definiert.';
$txt['pm_rule_title'] = 'Regel';
$txt['pm_add_rule'] = 'Neue Regel hinzufügen';
$txt['pm_apply_rules'] = 'Regeln jetzt anwenden';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Bist du sicher, dass du die Regeln auf alle Mitteilungen anwenden möchtest?';
$txt['pm_edit_rule'] = 'Regel ändern';
$txt['pm_rule_save'] = 'Regel speichern';
$txt['pm_delete_selected_rule'] = 'Ausgewählte Regeln löschen';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Bist du sicher, dass du die ausgewählten Regeln löschen möchtest?';
$txt['pm_rule_name'] = 'Name';
$txt['pm_rule_name_desc'] = 'Name für diese Regel';
$txt['pm_rule_name_default'] = '[NAME]';
$txt['pm_rule_description'] = 'Beschreibung';
$txt['pm_rule_not_defined'] = 'Füge Kriterien hinzu, um die Beschreibung zu erstellen.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><b>Hinweis</b> - du scheinst Javascript deaktiviert zu haben. Wir empfehlen dringend, Javascript zu aktivieren, um diese Funktion nutzen zu können.</span> ';
$txt['pm_rule_criteria'] = 'Kriterien';
$txt['pm_rule_criteria_add'] = 'Kriterien hinzufügen';
$txt['pm_rule_criteria_pick'] = 'Kriterien auswählen';
$txt['pm_rule_mid'] = 'Absendername';
$txt['pm_rule_gid'] = 'Absendergruppe';
$txt['pm_rule_sub'] = 'Betreff enthält';
$txt['pm_rule_msg'] = 'Text enthält';
$txt['pm_rule_bud'] = 'Absender ist ein Freund';
$txt['pm_rule_sel_group'] = 'Wähle eine Gruppe aus';
$txt['pm_rule_logic'] = 'Beim Überprüfen der Kriterien';
$txt['pm_rule_logic_and'] = 'Alle Kriterien müssen erfüllt werden';
$txt['pm_rule_logic_or'] = 'Ein Kriterium muss erfüllt sein';
$txt['pm_rule_actions'] = 'Aktionen';
$txt['pm_rule_sel_action'] = 'Wähle eine Aktion aus';
$txt['pm_rule_add_action'] = 'Aktion hinzufügen';
$txt['pm_rule_label'] = 'Mitteilung kennzeichnen mit';
$txt['pm_rule_sel_label'] = 'Wähle ein Label aus';
$txt['pm_rule_delete'] = 'Mitteilung löschen';
$txt['pm_rule_no_name'] = 'Du hast vergessen, einen Namen für diese Regel einzugeben.';
$txt['pm_rule_no_criteria'] = 'Eine Regel muss mindestens ein Kriterium und eine Aktion enthalten.';
$txt['pm_rule_too_complex'] = 'Die Regel, die du zu erstellen versuchst, ist zu lang. Versuche, sie in mehrere kürzere Regeln aufzuteilen.';

$txt['pm_readable_and'] = '<em>und</em>';
$txt['pm_readable_or'] = '<em>oder</em>';
$txt['pm_readable_start'] = 'Wenn ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'die Mitteilung von {MEMBER} ist';
$txt['pm_readable_group'] = 'der Absender in der Gruppe "{GROUP}" ist';
$txt['pm_readable_subject'] = 'der Betreff "{SUBJECT}" enthält';
$txt['pm_readable_body'] = 'der Text "{BODY}" enthält';
$txt['pm_readable_buddy'] = 'der Absender ein Freund ist';
$txt['pm_readable_label'] = 'wird das Label "{LABEL}" hinzugefügt';
$txt['pm_readable_delete'] = 'wird die Mitteilung gelöscht';
$txt['pm_readable_then'] = '<strong>dann</strong>';