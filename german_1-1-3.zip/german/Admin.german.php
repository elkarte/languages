<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Boards';
$txt['admin_back_to'] = 'Zurück zum Admin-Panel';
$txt['admin_users'] = 'Benutzer';
$txt['admin_newsletters'] = 'Newsletter';
$txt['include_these'] = 'Einzuschließende Benutzer';
$txt['exclude_these'] = 'Auszuschließende Benutzer';
$txt['admin_newsletters_select_groups'] = 'Gruppen, die empfangen sollen';
$txt['admin_newsletters_exclude_groups'] = 'Auszuschließende Gruppen';
$txt['admin_edit_news'] = 'Neuigkeiten';
$txt['admin_groups'] = 'Benutzergruppen';
$txt['admin_members'] = 'Benutzer verwalten';
$txt['admin_members_list'] = 'Eine Liste der Benutzer, welche im Forum registriert sind.';
$txt['admin_next'] = 'Nächster';
$txt['admin_censored_words'] = 'Zensierte Wörter';
$txt['admin_censored_where'] = 'Gib das zu zensierende Wort in das linke Feld und das stattdessen anzuzeigende Wort in das rechte Feld ein. Wähle dann, ob das zu zensierende Wort teilweise oder komplett vorkommen darf.';
$txt['admin_censored_desc'] = 'Aufgrund der Öffentlichkeit eines Forums hast du die Möglichkeit, einige Wörter zu verbieten. Auf dieser Seite kannst du die Wörter eintragen, welche nicht von den Benutzern benutzt werden dürfen.<br />Lösche den Inhalt eines Textfeldes, um das Wort zu entfernen.';
$txt['admin_reserved_names'] = 'Reservierte Namen';
$txt['admin_template_edit'] = 'Editiere das Forum-Template';
$txt['admin_modifications'] = 'Addon-Einstellungen';
$txt['admin_security_moderation'] = 'Sicherheit & Moderation';
$txt['admin_server_settings'] = 'Servereinstellungen';
$txt['admin_reserved_set'] = 'Setze reservierte Namen';
$txt['admin_reserved_line'] = 'Ein Wort pro Zeile.';
$txt['admin_basic_settings'] = 'Hier kannst du die Angaben zu deinem Server ändern. Sei aber sehr vorsichtig mit diesen Angaben, da sie das Forum unter Umständen funktionsuntüchtig machen können.';
$txt['admin_maintain'] = 'Wartungsmodus aktivieren';
$txt['admin_title'] = 'Name des Forums';
$txt['admin_url'] = 'Forum-URL';
$txt['cookie_name'] = 'Name des Cookies';
$txt['admin_webmaster_email'] = 'E-Mail-Adresse des Webmasters';
$txt['boarddir'] = 'ElkArte-Verzeichnis';
$txt['sourcesdir'] = 'Sources-Verzeichnis';
$txt['cachedir'] = 'Cache-Verzeichnis';
$txt['admin_news'] = 'Neuigkeiten aktivieren';
$txt['admin_guest_post'] = 'Erlaube Gast-Beiträge';
$txt['admin_manage_members'] = 'Benutzer';
$txt['admin_main'] = 'Hauptseite';
$txt['admin_config'] = 'Konfiguration';
$txt['admin_version_check'] = 'Detaillierter Versions-Check';
$txt['admin_elkfile'] = 'ElkArte-Datei';
$txt['admin_elkpackage'] = 'ElkArte-Paket';
$txt['admin_logoff'] = 'Beende Admin-Sitzung';
$txt['admin_maintenance'] = 'Wartungsmodus';
$txt['admin_image_text'] = 'Buttons bzw. Links im Theme als Grafik (statt Text) anzeigen';
$txt['admin_credits'] = 'Danksagung';
$txt['admin_agreement'] = 'Nutzungsbedingungen anzeigen und bei der Registrierung die Zustimmung des Benutzers verlangen?';
$txt['admin_checkbox_agreement'] = 'Zeige eine Checkbox für die Zustimmung der Nutzungsbedingungen statt einer ganzen Seite an.';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Standard';
$txt['admin_agreement_select_language'] = 'Sprache zum Bearbeiten';
$txt['admin_agreement_select_language_change'] = 'Ändern';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Ausgewählte Benutzer löschen';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Repariere alle Boards und Themen';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Hier kannst du Neuigkeiten hinzufügen oder löschen. Bitte benutze pro Neuigkeit nur ein Textfeld. Einige BBC-Tags wie z.B. [b], [i] und [u] sind erlaubt, ebenso wie Smileys. Entferne den Inhalt eines Textfeldes, um die Neuigkeit zu löschen.';
$txt['administrators'] = 'Administratoren';
$txt['admin_reserved_desc'] = 'Reservierte Namen hindern Benutzer daran, sich unter diesen Namen zu registrieren oder diese als angezeigten Namen zu verwenden. Wähle die gewünschten Optionen vor dem Speichern.';
$txt['admin_activation_email'] = 'Aktivierungs-E-Mail nach Registrierung zum neuen Benutzer senden';
$txt['admin_match_whole'] = 'Komplette Übereinstimmung. Falls nicht aktiviert, wird auch das teilweise Vorkommen im Namen verhindert.';
$txt['admin_match_case'] = 'Groß-/Kleinschreibung beachten. Falls nicht aktiviert, ist die Suche unabhängig von Groß-/Kleinschreibung.';
$txt['admin_check_user'] = 'Benutzernamen überprüfen.';
$txt['admin_check_display'] = 'Angezeigten Namen überprüfen.';
$txt['admin_newsletter_send'] = 'Hier kannst du den Benutzern eine E-Mail schreiben. Die E-Mail-Adressen der ausgewählten Benutzer(-gruppen) werden unten angezeigt. Du kannst beliebige E-Mail-Adressen hinzufügen oder entfernen.<br /> Mehrere Adressen wie folgt auflisten: "Adresse1; Adresse2".';
$txt['admin_fader_delay'] = 'Verzögerung zwischen Ausblendungen des Neuigkeiten-Faders';
$txt['zero_for_no_limit'] = '(0 = kein Limit)';
$txt['zero_to_disable'] = '(0 zum deaktivieren)';

$txt['admin_backup_fail'] = 'Warnung - Kopieren von "Settings.php" fehlgeschlagen - überprüfe bitte, ob die Datei "Settings_bak.php" existiert und überschreibbar ist.';
$txt['modSettings_info'] = 'Generelle Einstellungen der Funktionen des Forums, z.B. Karma, Signaturen, Gefällt mir und vieles mehr.';
$txt['database_server'] = 'Datenbank-Server';
$txt['database_user'] = 'Datenbank-Benutzer';
$txt['database_password'] = 'MySQL-Datenbank-Passwort';
$txt['database_name'] = 'Datenbank-Name';
$txt['registration_agreement'] = 'Nutzungsbedingungen';
$txt['registration_agreement_desc'] = 'Die Nutzungsbedingungen werden nur angezeigt, wenn sie bei der Registrierung akzeptiert werden müssen.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Datenbank-Tabellen-Prefix';
$txt['errors_list'] = 'Liste der Fehler';
$txt['errors_found'] = 'Folgende Fehler sind im Forum aufgetreten';
$txt['errors_fix'] = 'Möchtest du diese Fehler jetzt reparieren?';
$txt['errors_do_recount'] = 'Alle Fehler wurden bereinigt und in ein Reparatur-Forum abgelegt. Bitte klicke auf den Button unten, um die Statistiken neu zu berechnen.';
$txt['errors_recount_now'] = 'Statistiken neu berechnen';
$txt['errors_fixing'] = 'Repariere Fehler im Forum';
$txt['errors_fixed'] = 'Alle Fehler wurden bereinigt! du solltest nun die Kategorien, Boards und Themen überprüfen.';
$txt['attachments_avatars'] = 'Dateianhänge & Avatare';
$txt['attachments_desc'] = 'Hier kannst du Einstellungen für Dateianhänge und Benutzerbilder vornehmen, diese nach Datum und Größe löschen, Statistiken anschauen und die Wartung durchführen.';
$txt['attachment_stats'] = 'Dateianhang-Statistiken';
$txt['attachment_integrity_check'] = 'Integritäts-Check für Dateianhänge';
$txt['attachment_integrity_check_desc'] = 'Diese Funktion prüft die Integrität und Größe der Anhänge und Dateinamen, welche in der Datenbank gelistet sind, und behebt, falls notwendig, eventuelle Fehler.';
$txt['attachment_check_now'] = 'Prüfung jetzt starten';
$txt['attachment_pruning'] = 'Anhänge säubern';
$txt['attachment_pruning_message'] = 'Nachricht, welche zum Beitrag hinzugefügt werden soll';
$txt['attachment_pruning_warning'] = 'Bist du sicher, dass du diese Anhänge löschen möchtest?\\nDies kann nicht rückgängig gemacht werden!';

$txt['attachment_total'] = 'Dateianhänge insgesamt';
$txt['attachmentdir_size'] = 'Größe des Upload-Verzeichnisses';
$txt['attachmentdir_size_current'] = 'Größe des aktuellen Upload-Verzeichnisses';
$txt['attachmentdir_files_current'] = 'Gesamtgröße aller Dateiem im aktuellen Verzeichnis';
$txt['attachment_space'] = 'Verfügbarer Speicherplatz im Upload-Verzeichnis';
$txt['attachment_files'] = 'Dateien ausstehend';

$txt['attachment_options'] = 'Optionen für Dateianhänge';
$txt['attachment_log'] = 'Dateianhangsprotokoll';
$txt['attachment_remove_old'] = 'Entferne Anhänge älter als %1s Tage';
$txt['attachment_remove_size'] = 'Entferne Anhänge größer als als %1s KB';
$txt['attachment_name'] = 'Name des Anhangs';
$txt['attachment_file_size'] = 'Dateigröße';
$txt['attachmentdir_size_not_set'] = 'Momentan ist keine max. Verzeichnisgröße gesetzt.';
$txt['attachmentdir_files_not_set'] = 'Momentan ist kein Datei-Limit gesetzt.';
$txt['attachment_delete_admin'] = '[Anhang wurde durch Administrator gelöscht]';
$txt['live'] = 'Letzte Software-Updates';
$txt['remove_all'] = 'Alle entfernen';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(ausführlicher)';

$txt['lfyi'] = 'Verbindungsaufbau zu ElkArte gescheitert.';

$txt['manage_calendar'] = 'Kalender';
$txt['manage_search'] = 'Suche';
$txt['viewmembers_online'] = 'Letztes Mal online';

$txt['smileys_manage'] = 'Smileys & Beitragssymbole';
$txt['smileys_manage_info'] = 'Installiere neue Smiley-Sets, füge Smileys zu existierenden Sets hinzu und verwalte die Beitragssymbole.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Installiere Pakete mit Modifikationen und prüfe Dateiberechtigungen und FTP-Einstellungen.';
$txt['theme_admin'] = 'Themes-Management';
$txt['theme_admin_info'] = 'Hier kannst du Themes verwalten und die Einstellungen für das Layout anpassen. Auch kannst du Einstellungen deiner Benutzer zurücksetzen.';
$txt['registration_center'] = 'Registrierungs-Management';
$txt['member_center_info'] = 'Hier kannst du Benutzerprofile anschauen, nach Benutzern suchen und die Liste der noch nicht genehmigten bzw. aktivierten Benutzer anschauen.';
$txt['viewmembers_online'] = 'Letztes Mal online';

$txt['display_name'] = 'Angezeigter Name';
$txt['email_address'] = 'E-Mail-Adresse';
$txt['ip_address'] = 'IP-Adresse';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'unbekannt';
$txt['security_wrong'] = 'Login-Versuch als Administrator!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Sendet die Nachricht im HTML-Format (HTML-Code ist in der Nachricht möglich)';
$txt['email_parsed_html'] = 'Fügt &lt;br /&gt; und &amp;nbsp; in die Nachricht ein';
$txt['email_variables'] = 'Ermöglicht die Nutzung einiger &quot;Variablen&quot;. <a href="{help_emailmembers}" class="help">Klicke hier für weitere Informationen</a>';
$txt['email_force'] = 'Sendet die Nachricht auch zu Benutzern, welche das Empfangen von Ankündigungen deaktiviert haben.';
$txt['email_as_pms'] = 'Sendet die Nachricht als Mitteilung zu den ausgewählten Benutzern.';
$txt['email_continue'] = 'Weiter';
$txt['email_done'] = 'Fertig.';
$txt['email_members_succeeded'] = 'Dein Newsletter wurde erfolgreich versandt!';

$txt['ban_title'] = 'Bann-Liste editiern';
$txt['ban_ip'] = 'IP bannen (z.B. 192.168.12.213 oder 128.0.*.*) - ein Eintrag pro Zeile';
$txt['ban_email'] = 'E-Mail-Adresse bannen (z.B. badguy@somewhere.com) - ein Eintrag pro Zeile';
$txt['ban_username'] = 'Benutzernamen bannen (z.B. l33tuser) - ein Eintrag pro Zeile';

$txt['ban_errors_detected'] = 'Die folgenden Fehler sind während des Speicherns oder Editierens des Bans bzw. des Triggers aufgetreten';
$txt['ban_description'] = 'Hier kannst du Benutzer nach IP-Adresse, Hostnamen, Benutzernamen oder E-Mail-Adresse bannen.';
$txt['ban_add_new'] = 'Neuen Bann hinzufügen';
$txt['ban_banned_entity'] = 'Zu bannende Person';
$txt['ban_on_ip'] = 'Nach IP bannen (z.B. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Nach Hostnamen bannen (z.B. *.de)';
$txt['ban_on_email'] = 'Nach E-Mail-Adresse bannen (z.B. *@badsite.de)';
$txt['ban_on_username'] = 'Nach Benutzernamen bannen';
$txt['ban_notes'] = 'Notizen';
$txt['ban_restriction'] = 'Einschränkungen';
$txt['ban_full_ban'] = 'Vollständig gebannt';
$txt['ban_partial_ban'] = 'Teilweise gebannt';
$txt['ban_cannot_post'] = 'kann nicht schreiben';
$txt['ban_cannot_register'] = 'kann sich nicht registrieren';
$txt['ban_cannot_login'] = 'kann sich nicht anmelden';
$txt['ban_add'] = 'Hinzufügen';
$txt['ban_edit_list'] = 'Bann-Liste bearbeiten';
$txt['ban_type'] = 'Typ';
$txt['ban_days'] = 'Tag(e)';
$txt['ban_will_expire_within'] = 'Bann besteht noch';
$txt['ban_added'] = 'Hinzugefügt';
$txt['ban_expires'] = 'Ablauf';
$txt['ban_hits'] = 'Treffer';
$txt['ban_actions'] = 'Aktionen';
$txt['ban_expiration'] = 'Abgelaufen';
$txt['ban_reason_desc'] = 'Grund des Banns, welcher dem Benutzer angezeigt wird.';
$txt['ban_notes_desc'] = 'Weitere Informationen für andere Administratoren und Moderaroten.';
$txt['ban_remove_selected'] = 'Ausgewählte löschen';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Bist du sicher, dass du die ausgewählten gesperrten Mitglieder entfernen möchtest?';
$txt['ban_modify'] = 'Ändern';
$txt['ban_name'] = 'Name';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Bann bearbeiten';
$txt['ban_add_notes'] = '<strong>Achtung</strong>: Nachdem du den oben stehenden Bann erstellt hast, kannst du später weitere Merkmale hinzufügen, z.B. IP-Adressen, Hostnamen und E-Mail-Adressen.';
$txt['ban_expired'] = 'Abgelaufen bzw. deaktiviert';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Keine Einschränkungen ausgewählt!';

$txt['ban_triggers'] = 'Merkmale';
$txt['ban_add_trigger'] = 'Merkmal hinzufügen';
$txt['ban_add_trigger_submit'] = 'Hinzufügen';
$txt['ban_edit_trigger'] = 'Ändern';
$txt['ban_edit_trigger_title'] = 'Merkmal ändern';
$txt['ban_edit_trigger_submit'] = 'Ändern';
$txt['ban_remove_selected_triggers'] = 'Ausgewählte Merkmale entfernen';
$txt['ban_no_entries'] = 'Es sind momentan keine aktiven Banns vorhanden.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Bist du sicher, dass du die ausgewählten Bann-Merkmale entfernen möchtest?';
$txt['ban_trigger_browse'] = 'Bann-Merkmale anzeigen';
$txt['ban_trigger_browse_description'] = 'Diese Seite zeigt alle Bann-Merkmale, sortiert nach IP-Adresse, Hostname, E-Mail-Adresse und Benutzername, an.';

$txt['ban_log'] = 'Bann-Protokoll';
$txt['ban_log_description'] = 'Das Bann-Protokoll zeigt alle Versuche gebannter Benutzer, sich im Forum anzumelden (zeigt nur "Vollständiger Bann" und "Kann sich nicht registrieren"), an.';
$txt['ban_log_no_entries'] = 'Es gibt keine Einträge im Bann-Protokoll.';
$txt['ban_log_ip'] = 'IP-Adresse';
$txt['ban_log_email'] = 'E-Mail-Adresse';
$txt['ban_log_member'] = 'Benutzer';
$txt['ban_log_date'] = 'Datum';
$txt['ban_log_remove_all'] = 'Alle löschen';
$txt['ban_log_remove_all_confirm'] = 'Bist du sicher, dass du alle Einträge löschen möchtest?';
$txt['ban_log_remove_selected'] = 'Ausgewählte löschen';
$txt['ban_log_remove_selected_confirm'] = 'Bist du sicher, dass du die ausgewählten Einträge löschen möchtest?';
$txt['ban_no_triggers'] = 'Keine Bann-Merkmale';

$txt['settings_not_writable'] = 'Warnung - Die Datei "Settings.php" ist nicht überschreibbar, die Änderungen werden nicht gespeichert.';

$txt['maintain_title'] = 'Wartung des Forums';
$txt['maintain_info'] = 'Erstelle Backups deines Forums, untersuche die Datenbank auf Fehler, leere den Cache und mehr.';
$txt['maintain_sub_database'] = 'Datenbank';
$txt['maintain_sub_routine'] = 'Regelmäßige Wartung';
$txt['maintain_sub_members'] = 'Benutzer';
$txt['maintain_sub_topics'] = 'Themen';
$txt['maintain_sub_attachments'] = 'Dateianhänge';
$txt['maintain_done'] = 'Die Wartungsaufgabe "%1$s" wurde erfolgreich ausgeführt.';
$txt['maintain_fail'] = 'Die Wartungsaufgabe "%1$s" ist fehlgeschlagen.';
$txt['maintain_no_errors'] = 'Glückwunsch, es wurden keine Fehler gefunden!';

$txt['maintain_tasks'] = 'Geplante Wartungsaufgaben';
$txt['maintain_tasks_desc'] = 'Hier kannst du alle geplanten Wartungsaufgaben verwalten.';

$txt['scheduled_log'] = 'Aufgaben-Protokoll';
$txt['scheduled_log_desc'] = 'Hier werden alle Aufgaben aufgelistet, die regelmäßig durchgeführt wurden.';
$txt['admin_log'] = 'Administrator-Protokoll';
$txt['admin_log_desc'] = 'Hier werden alle Aktionen aufgelistet, die im Forum von den Administratoren durchgeführt wurden.';
$txt['moderation_log'] = 'Moderator-Protokoll';
$txt['moderation_log_desc'] = 'Hier werden alle Aktionen aufgelistet, die im Forum von den Moderatoren durchgeführt wurden.';
$txt['badbehavior_log'] = 'BadBehaviour-Protokoll';
$txt['badbehavior_log_desc'] = 'Requests anzeigen, die von BadBehaviour als verdächtig markiert wurden. Wenn das detaillierte Protokollieren aktiviert ist, werden alle HTTP-Requests gespeichert.';
$txt['spider_log_desc'] = 'Prüfe die Einträge, die sich auf Search-Engine-Spider-Aktivitäten beziehen.';
$txt['pruning_log_desc'] = 'Verwende diese Werkzeuge, um ältere Einträge in verschiedenen Protokollen zu entfernen.';

$txt['mailqueue_title'] = 'E-Mail';

$txt['db_error_send'] = 'Sendet eine E-Mail bei einem MySQL-Verbindungsfehler';
$txt['db_persist'] = 'Dauerhafte Datenbankverbindung benutzen';
$txt['ssi_db_user'] = 'Datenbank-Benutzername für SSI-Modus';
$txt['ssi_db_passwd'] = 'Datenbank-Passwort für SSI-Modus';

$txt['default_language'] = 'Standardsprache des Forums';

$txt['maintenance_subject'] = 'Betreff der Wartungsmeldung';
$txt['maintenance_message'] = 'Inhalt der Wartungsmeldung';

$txt['errlog_desc'] = 'Hier werden alle Fehler im Forum aufgelistet. Um die Fehler aus der Datenbank zu löschen, markiere die betreffende Checkbox und klicke auf den Auswahl entfernen-Button am unteren Bildschirmrand.';
$txt['errlog_no_entries'] = 'Es sind momentan keine Einträge im Fehlerprotokoll vorhanden.';

$txt['theme_settings'] = 'Theme-Einstellungen';
$txt['theme_edit_settings'] = 'Ändere die Einstellungen dieses Themes.';
$txt['theme_current_settings'] = 'Aktuelles Theme';

$txt['dvc_your'] = 'Deine Version';
$txt['dvc_current'] = 'Aktuelle Version';
$txt['dvc_sources'] = 'Quellen';
$txt['dvc_admin'] = 'Administrator';
$txt['dvc_controllers'] = 'Controller';
$txt['dvc_database'] = 'Datenbanken';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Standard-Theme';
$txt['dvc_templates'] = 'Aktuelles Theme';
$txt['dvc_languages'] = 'Sprachdateien';

$txt['smileys_default_set_for_theme'] = 'Standard-Smiley-Set für dieses Theme wählen:';
$txt['smileys_no_default'] = 'Benutze Standard-Smiley-Set';

$txt['censor_test'] = 'Zensierte Wörter testen';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Ignoriere Groß/-Kleinschreibung beim Test.';
$txt['censor_whole_words'] = 'Nur ganze Wörter testen.';
$txt['censor_allow'] = 'Erlaube Benutzern, die Zensur abzuschalten.';

$txt['admin_confirm_password'] = '(Bestätigen)';
$txt['admin_incorrect_password'] = 'Das Passwort ist ungültig!';

$txt['date_format'] = '(JJJJ-MM-TT)';
$txt['undefined_gender'] = 'Undefiniert';
$txt['age'] = 'Alter des Benutzers';
$txt['activation_status'] = 'Aktivierungsstatus';
$txt['activated'] = 'Aktiviert';
$txt['not_activated'] = 'Deaktiviert';
$txt['is_banned'] = 'Verbannt';
$txt['primary'] = 'Primär';
$txt['additional'] = 'Zusätzlich';
$txt['wild_cards_allowed'] = 'Wildcard-Zeichen * und ? sind erlaubt';
$txt['member_part_of_these_membergroups'] = 'Benutzer ist in folgenden Benutzergruppen';
$txt['membergroups'] = 'Benutzergruppen';
$txt['confirm_delete_members'] = 'Bist du sicher, dass du die ausgewählten Benutzer löschen möchtest?';

$txt['support_credits_title'] = 'Support & Danksagung';
$txt['support_credits_info'] = 'Supportlinks zu den häufigsten Fragen; Versionsnummern, nach welchen du im Falle einer Supportanfrage gefragt wirst; Liste von Mitwirkenden beim ElkArte-Projekt.';
$txt['support_title'] = 'Support-Informationen';
$txt['support_versions_current'] = 'Aktuelle Version';
$txt['support_versions_forum'] = 'Forum-Version';
$txt['support_versions_db'] = '%1$s-Version';
$txt['support_versions_server'] = 'Server-Version';
$txt['support_versions_gd'] = 'GD-Version';
$txt['support_versions_imagick'] = 'Imagick-Version';
$txt['support_versions'] = 'Versionsinformation';
$txt['support_resources'] = 'Support-Ressourcen';
$txt['support_resources_p1'] = 'In unserem <a href="%1$s" target="_blank" class="new_win">Wiki</a> findest du die grundlegende Dokumentation zu ElkArte. Das Online-Handbuch hilft bei vielen Fragen und erklärt dir die <a href="%2$s" target="_blank" class="new_win">Funktionen</a>, <a href="%3$s" target="_blank" class="new_win">Einstellungen</a>, <a href="%4$s" target="_blank" class="new_win">Themes</a>, <a href="%5$s" target="_blank" class="new_win">Pakete</a>, etc. Das Online-Handbuch erklärt dir jeden Bestandteil von ElkArte ausführlich, es sollte aufkommende Fragen schnellstmöglich beantworten.';
$txt['support_resources_p2'] = 'Findest du in unserem Wiki keine Antwort auf deine Frage, schau doch mal in unserem <a href="%1$s" target="_blank" class="new_win">Supportforum</a> vorbei. Dort finden sich Threads zum <a href="%2$s" target="_blank" class="new_win">Support</a>, der <a href="%3$s" target="_blank" class="new_win">Individualisierung</a> und viele andere Themen, zum Beispiel ElkArte selbst und auch administrative Themen.';

$txt['latest_updates'] = 'Letzte Updates';
$txt['new_in_1_0_2'] = 'Die augenscheinlichste Neuerung in ElkArte 1.0.2 ist das neue Avatar-Management. Bisher gab es für jede Möglichkeit, einen Avatar auszuwählen, eine eigene Berechtigung je nach Benutzergruppe. Mit 1.0.2 wurde dies geändert. Nun muss jeder Benutzergruppe nur noch die Möglichkeit gegeben werden, einen Avatar auszuwählen. Diese Gruppe hat dann die Berechtigung, jede mögliche Auwwahlmethode zu nutzen.<br />
Die einzige vorhandene Berechtigung ist, ob eine Benutzergruppe einen Avatar auswählen darf oder nicht. Es gibt nur einen Wert für die maximale Höhe und Breite eines Avatars - dieser gilt für alle Auswahlmethoden.<br /><br />
Leider können bisherige Einstellungen nicht migriert werden. Besuche die <a href="{admin_url};area=manageattachments;sa=avatars">Avatar-Einstellungen</a> und stelle sie nach deinen Wünschen ein.';

$txt['edit_permissions_info'] = 'Benutze die Berechtigungen, um festzulegen, welche Funktionen deinen Gästen, Benutzern und Moderatoren zur Verfügung stehen.';
$txt['membergroups_members'] = 'Normale Benutzer';
$txt['membergroups_guests'] = 'Gäste';
$txt['membergroups_add_group'] = 'Gruppe hinzufügen';
$txt['membergroups_permissions'] = 'Berechtigungen';

$txt['permitgroups_restrict'] = 'Eingeschränkt';
$txt['permitgroups_standard'] = 'Standard';
$txt['permitgroups_moderator'] = 'Moderator';
$txt['permitgroups_maintenance'] = 'Wartungsmodus';

$txt['confirm_delete_attachments'] = 'Bist du sicher, dass du den ausgewählten Dateianhang entfernen möchtest?';
$txt['attachment_manager_browse_files'] = 'Dateien durchsuchen';
$txt['attachment_manager_repair'] = 'Wartung';
$txt['attachment_manager_avatars'] = 'Avatare';
$txt['attachment_manager_attachments'] = 'Dateianhänge';
$txt['attachment_manager_thumbs'] = 'Vorschaubilder';
$txt['attachment_manager_last_active'] = 'Letzter Besuch';
$txt['attachment_manager_member'] = 'Benutzer';
$txt['attachment_manager_avatars_older'] = 'Entferne Avatare von Benutzern, die länger als %1$s Tage nicht mehr angemeldet waren';
$txt['attachment_manager_total_avatars'] = 'Avatare insgesamt';

$txt['attachment_manager_avatars_no_entries'] = 'Es sind momentan keine Avatare vorhanden.';
$txt['attachment_manager_attachments_no_entries'] = 'Es sind momentan keine Dateianhänge vorhanden.';
$txt['attachment_manager_thumbs_no_entries'] = 'Es sind momentan keine Vorschaubilder vorhanden.';

$txt['attachment_manager_settings'] = 'Einstellungen der Dateianhänge';
$txt['attachment_manager_avatar_settings'] = 'Avatar-Einstellungen';
$txt['attachment_manager_browse'] = 'Dateien durchsuchen';
$txt['attachment_manager_maintenance'] = 'Dateien warten';
$txt['attachmentEnable'] = 'Einstellung der Dateianhänge';
$txt['attachmentEnable_deactivate'] = 'Dateianhänge deaktivieren';
$txt['attachmentEnable_enable_all'] = 'Alle Dateianhänge aktivieren';
$txt['attachmentEnable_disable_new'] = 'Neue Dateianhänge deaktivieren';
$txt['attachmentCheckExtensions'] = 'Dateitypen prüfen';
$txt['attachmentExtensions'] = 'Erlaubte Dateitypen';
$txt['attachmentRecodeLineEndings'] = 'Zeilenendungen in Text-Anhängen umwandeln';
$txt['attachmentShowImages'] = 'Dateianhang als Bild innerhalb des Beitrages anzeigen';
$txt['attachmentUploadDir'] = 'Upload-Verzeichnis für Dateianhänge';
$txt['attachmentUploadDir_multiple_configure'] = 'Verwalte Upload-Verzeichnisse';
$txt['attachmentDirSizeLimit'] = 'Max. Speicherplatz für Dateianlagen-Verzeichnisse';
$txt['attachmentPostLimit'] = 'Kombinierte max. Größe der Dateianhänge pro Beitrag ';
$txt['attachmentSizeLimit'] = 'Max. Größe pro Dateianhang';
$txt['attachmentNumPerPostLimit'] = 'Max. Anzahl der Dateianhänge pro Beitrag';
$txt['attachment_img_enc_warning'] = 'Weder das GD-Modul noch ImageMagick sind zur Zeit installiert. Image-Re-Encoding ist deshalb nicht möglich.';
$txt['attachment_postsize_warning'] = 'Die aktuellen php.ini-Einstellungen zu "post_max_size" erlauben das möglicherweise nicht. ';
$txt['attachment_filesize_warning'] = 'Die aktuellen php.ini-Einstellungen zu "post_max_size" erlauben das möglicherweise nicht. ';
$txt['attachment_image_reencode'] = 'Bild-Neukodierung potenziell gefährlicher Bild-Anhänge';
$txt['attachment_image_reencode_note'] = '(Benötigt das GD-Modul oder ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Diese umfangreichen Sicherheitskontrollen können eine große Zahl von abgelehnten Datei-Anhängen verursachen.';
$txt['attachment_image_paranoid'] = 'Durchführen von umfangreichen Sicherheitskontrollen auf hoch geladene Bild-Anhänge';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'Bilder verkleinern, wenn sie im Beitrag angezeigt werden';
$txt['attachment_thumb_png'] = 'Vorschaubilder im PNG-Format speichern';
$txt['attachment_thumb_memory'] = 'Speicher zuzüglich der Vorschaubilder.';
$txt['attachment_thumb_memory_note2'] = 'Wenn das System über keinen freien Speicher verfügt, werden keine Vorschaubilder erstellt.';
$txt['attachment_thumb_memory_note1'] = 'Leer lassen, wenn stest versucht werden soll, Vorschaubilder  zu erstellen.';
$txt['attachmentThumbWidth'] = 'Max. Breite der Vorschaubilder';
$txt['attachmentThumbHeight'] = 'Max. Höhe der Vorschaubilder';
$txt['attachment_thumbnail_settings'] = 'Vorschaubild-Einstellungen';
$txt['attachment_security_settings'] = 'Sicherheits-Einstellungen für Dateianhänge';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Existiert nicht';
$txt['attach_dir_not_writable'] = 'Nicht beschreibbar';
$txt['attach_dir_files_missing'] = 'Fehlende Dateien (<a href="{repair_url}">Reparieren</a>)';
$txt['attach_dir_unused'] = 'Unbenutzt';
$txt['attach_dir_empty'] = 'Leeren';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Basis-Verzeichnis';

$txt['attach_dir_desc'] = 'Erstelle neue Verzeichnisse oder ändere das aktuelle Verzeichnis. Verzeichnisse können umbenannt werden, solange sie keine Unterverzeichnisse enthalten. Wenn das Verzeichnis innerhalb der Foren-Struktur erstellt wird, reicht es, den Verzeichnis-Namen anzugeben. Um ein Verzeichnis zu löschen, lösche den Inhalt im Feld Pfad. Verzeichnisse können nicht gelöscht werden, solange sie Dateien oder Unterverzeichnisse enthalten (ist an dem Zähler in den eckigen Klammern zu erkennen).';
$txt['attach_dir_base_desc'] = 'Du kannst im unteren Bereich das aktuelle Verzeichnis ändern oder ein neues Verzeichnis erstellen. Neue Basis-Verzeichnisse werden ebenfalls zur Liste der Anlagen-Verzeichnisse hinzugefügt. Du kannst außerdem ein existierendes Verzeichnis in ein Basis-Verzeichnis umfunktionieren.';
$txt['attach_dir_save_problem'] = 'Oops, es scheint ein Problem zu bestehen.';
$txt['attachments_no_create'] = 'Erstellen des neuen Verzeichnisses nicht möglich. Bitte benutze einen FTP-Client, um das Verzeichnis zu erstellen.';
$txt['attachments_no_write'] = 'Das Verzeichnis wurde erstellt, aber ist nicht beschreibbar. Bitte benutze einen FTP-Client, um die Berechtigungen entsprechend zu setzen.';
$txt['attach_dir_reserved'] = 'Kann nicht hinzugefügt werden. Das Verzeichnis ist ein Systemverzeichnis und kann nicht für Dateianlagen benutzt werden';
$txt['attach_dir_duplicate_msg'] = 'Kann das Verzeichnis nicht erstellen. Es existiert bereits.';
$txt['attach_dir_exists_msg'] = 'Kann das Verzeichnis nicht verschieben. In dem Pfad ist bereits ein Verzeichnis mit gleichem Namen vorhanden.';
$txt['attach_dir_base_dupe_msg'] = 'Kann das Verzeichnis nicht erstellen. Das Basis-Verzeichnis wurde bereits erstellt.';
$txt['attach_dir_base_no_create'] = 'Erstellen nicht möglich. Bitte den Pfad im Eingabe-Feld mit Hilfe eines FTP-Clients kontrollieren.';
$txt['attach_dir_no_rename'] = 'Verschieben oder Umbenennen nicht möglich. Bitte überprüfe, ob der Pfad korrekt ist und ob das Verzeichnis keine Unterverzeichnisse enthält.';
$txt['attach_dir_no_delete'] = 'Ist nicht leer und kann nicht gelöscht werden. Bitte überprüfe das mittels FTP-Client.';
$txt['attach_dir_no_remove'] = 'Enthält aktuell noch Dateien oder ist als Basis-Verzeichnis eingestellt und kann deshalb nicht gelöscht werden.';
$txt['attach_dir_is_current'] = 'Kann nicht gelöscht werden, solange es als aktuelles Verzeichnis eingestellt ist.';
$txt['attach_dir_is_current_bd'] = 'Kann nicht gelöscht werden, solange es als aktuelles Basis-Verzeichnis eingestellt ist.';
$txt['attach_last_dir'] = 'Letztes aktives Dateianlagen-Verzeichnis';
$txt['attach_current_dir'] = 'Aktuelles Verzeichnis für Dateianhänge';
$txt['attach_current'] = 'Akutell';
$txt['attach_path_manage'] = 'Pfade für Dateianhänge verwalten';
$txt['attach_directories'] = 'Dateianhänge-Verzeichnisse';
$txt['attach_paths'] = 'Pfade für Dateianhänge-Verzeichnisse';
$txt['attach_path'] = 'Pfad';
$txt['attach_current_size'] = 'Größe (in KB)';
$txt['attach_num_files'] = 'Dateien';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Pfad hinzufügen';
$txt['attach_path_current_bad'] = 'Ungültiger Pfad für Dateianhänge.';
$txt['attachmentDirFileLimit'] = 'Max. Anzahl an Dateien pro Verzeichnis';

$txt['attach_base_paths'] = 'Pfad für das Basis-Verzeichnis';
$txt['attach_num_dirs'] = 'Verzeichnisse';
$txt['max_image_width'] = 'Max. Breite für Bilder in Beiträgen oder Dateianhängen';
$txt['max_image_height'] = 'Max. Höhe für Bilder in Beiträgen oder Dateianhängen';

$txt['automanage_attachments'] = 'Methode für das automatische Verwalten von Dateianhängen einstellen';
$txt['attachments_normal'] = '(Manuell) ElkArtes Standard-Einstellung';
$txt['attachments_auto_years'] = '(Auto) Nach Jahren sortiert';
$txt['attachments_auto_months'] = '(Auto) Nach Jahren und Monaten sortiert';
$txt['attachments_auto_days'] = '(Auto) Nach Jahren, Monaten und Tagen sortiert';
$txt['attachments_auto_16'] = '(Auto) 16 zufällige Verzeichnisse';
$txt['attachments_auto_16x16'] = '(Auto) 16 zufällige Verzeichnisse mit 16 zufälligen Unterverzeichnissen';
$txt['attachments_auto_space'] = '(Auto) Wenn Speicherplatz-Limit erreicht wurde';

$txt['use_subdirectories_for_attachments'] = 'Neue Verzeichnisse innerhalb des Basis-Verzeichnisses erstellen';
$txt['use_subdirectories_for_attachments_note'] = 'Andernfalls werden neue Verzeichnisse innerhalb des Haupt-Verzeichnisses des Forums erstellt.';
$txt['basedirectory_for_attachments'] = 'Basis-Verzeichnis für Dateianlagen setzen';
$txt['basedirectory_for_attachments_current'] = 'Aktuelles Basis-Verzeichnis';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Falsches Verzeichnis ausgewählt. <br />(<a href="{attach_repair_url}">Reparieren</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">Es scheint ein Problem mit diesem Verzeichnis zu geben. <br />(<a href="{attach_repair_url}">Reparieren</a>)</div>';

$txt['attachment_transfer'] = 'Dateianhänge verschieben';
$txt['attachment_transfer_desc'] = 'Dateianhänge zwischen Verzeichnissen verschieben';
$txt['attachment_transfer_select'] = 'Wähle Verzeichnis';
$txt['attachment_transfer_now'] = 'Verschieben';
$txt['attachment_transfer_from'] = 'Verschiebe Dateien von';
$txt['attachment_transfer_auto'] = 'Automatisch, basierend auf Speicherplatz oder Anzahl';
$txt['attachment_transfer_auto_select'] = 'Wähle Basis-Verzeichnis';
$txt['attachment_transfer_to'] = 'Oder  zu einem spezifischen Verzeichnis verschieben.';
$txt['attachment_transfer_empty'] = 'Alle Dateien vom Quellverzeichnis verschieben.';
$txt['attachment_transfer_no_base'] = 'Kein Basis-Verzeichnis verfügbar.';
$txt['attachment_transfer_forum_root'] = 'Hauptverzeichnis des Forums.';
$txt['attachment_transfer_no_room'] = 'Speicherplatz-Limit oder max. Anzahl der Dateien erreicht.';
$txt['attachment_transfer_no_find'] = 'Keine Dateien zum Verschieben gefunden.';
$txt['attachments_transfered'] = '%1$d Dateien wurden verschoben nach %2$s';
$txt['attachments_not_transfered'] = '%1$d Dateien wurden nicht verschoben.';
$txt['attachment_transfer_no_dir'] = 'Es wurden die Quell- oder Ziel-Einstellungen nicht korrekt gesetzt.';
$txt['attachment_transfer_same_dir'] = 'Du kannst das gleiche Verzeichnis nicht als Quelle UND Ziel angeben.';
$txt['attachment_transfer_progress'] = 'Bitte warten. Es wird verschoben...';

$txt['avatar_settings'] = 'Avatar-Einstellungen';
$txt['avatar_default'] = 'Standard-Avatar für alle Benutzer ohne eigenen Avatar aktivieren';
$txt['avatar_directory'] = 'Avatar-Verzeichnis';
$txt['avatar_url'] = 'Avatar-URL';
$txt['avatar_max_width'] = 'Maximale Breite des Avatars in Pixeln (px)';
$txt['avatar_max_height'] = 'Maximale Höhe des Avatars in Pixeln (px)';
$txt['avatar_action_too_large'] = 'Wenn der Avatar zu groß ist:';
$txt['option_refuse'] = 'Ablehnen';
$txt['option_resize'] = 'Über CSS die Größe ändern';
$txt['option_download_and_resize'] = 'Download und anschließende Größenänderung (benötigt GD-Modul oder ImageMagick)';
$txt['gravatar'] = 'Gravatare';
$txt['avatar_gravatar_enabled'] = 'Aktiviere Gravatare';
$txt['gravatar_rating'] = 'Gravatar-Rating';
$txt['avatar_download_png'] = 'PNG-Format für in der Größe geänderte Avatare benutzen';
$txt['avatar_img_enc_warning'] = 'Weder das GD-Modul noch ImageMagick sind zur Zeit installiert. Image-Re-Encoding ist deshalb nicht möglich.';
$txt['avatar_external'] = 'Externe Avatare';
$txt['avatar_external_enabled'] = 'Aktiviere externe Avatare über eine URL';
$txt['avatar_upload'] = 'Hochzuladende Avatare';
$txt['avatar_resize_options'] = 'Serverspeicher-Einstellungen';
$txt['avatar_upload_enabled'] = 'Aktiviere das Hochladen von Avataren';
$txt['avatar_server_stored'] = 'Server-gespeicherte Avatare';
$txt['avatar_stored_enabled'] = 'Aktiviere die Auswahl servergespeicherter Avatare';
$txt['profile_set_avatar'] = 'Benutzergruppen, welche einen Avatar wählen dürfen';
$txt['avatar_select_permission'] = 'Wähle Berechtigungen für jede Benutzergruppe';
$txt['avatar_download_external'] = 'Avatar von angegebener URL herunterladen';
$txt['custom_avatar_enabled'] = 'Avatar hochladen in...';
$txt['option_attachment_dir'] = 'Avatar-Verzeichnis';
$txt['option_specified_dir'] = 'Verzeichnis auswählen...';
$txt['custom_avatar_dir'] = 'Upload-Verzeichnis';
$txt['custom_avatar_dir_desc'] = 'Es sollte nicht das gleiche Verzeichnis wie für die Server-gespeicherten Avatare ausgewählt werden!';
$txt['custom_avatar_url'] = 'Upload-URL';
$txt['custom_avatar_check_empty'] = 'Der benutzerdefinierte Avatar-Ordner, den du angegeben hast, könnte leer oder falsch sein. Bitte prüfe, ob die Einstellungen korrekt sind.';
$txt['avatar_reencode'] = 'Neukodierung potenziell gefährlicher Avatare';
$txt['avatar_reencode_note'] = 'Benötigt das GD-Modul';
$txt['avatar_paranoid_warning'] = 'Diese umfangreichen Sicherheitskontrollen können zu einer großen Zahl abgelehnter Avatare führen.';
$txt['avatar_paranoid'] = 'Umfangreiche Sicherheitskontrollen bei hoch geladenen Avataren durchführen';

$txt['repair_attachments'] = 'Wartung der Dateianhänge';
$txt['repair_attachments_complete'] = 'Die Wartung ist beendet...';
$txt['repair_attachments_complete_desc'] = 'Alle gewählten Fehler wurden beseitigt';
$txt['repair_attachments_no_errors'] = 'Keine Fehler gefunden!';
$txt['repair_attachments_error_desc'] = 'Folgende Fehler wurden während der Wartung gefunden. Markiere den Fehler, der behoben werden soll, und klicke auf Weiter.';
$txt['repair_attachments_continue'] = 'Weiter';
$txt['repair_attachments_cancel'] = 'Abbrechen';
$txt['attach_repair_missing_thumbnail_parent'] = 'Für %1$d Vorschaubilder fehlen die Verknüpfungen.';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d Anhänge müssten Vorschaubilder haben, welche jedoch nicht existieren.';
$txt['attach_repair_file_missing_on_disk'] = '%1$d Dateianhänge und/oder Avatare sind in der Datenbank eingetragen, existieren aber nicht mehr auf dem Server.';
$txt['attach_repair_file_wrong_size'] = '%1$d Dateianhänge und/oder Avatare haben eine falsch angegebene Dateigröße.';
$txt['attach_repair_file_size_of_zero'] = '%1$d Dateianhänge und/oder Avatare haben eine Dateigröße von Null (sie werden gelöscht).';
$txt['attach_repair_attachment_no_msg'] = '%1$d Dateianhänge sind keinen Beiträgen mehr zugeordnet.';
$txt['attach_repair_avatar_no_member'] = '%1$d Avatare sind keinen Benutzern mehr zugeordnet.';
$txt['attach_repair_wrong_folder'] = '%1$d Dateianlagen befinden sich im falschen Verzeichnis';
$txt['attach_repair_missing_extension'] = '%1$d Dateianhänge haben eine falsche Datei-Endung und liegen möglicherweise im falschen Verzeichnis';
$txt['attach_repair_files_without_attachment'] = 'Von %1$d Dateianhängen fehlt der entsprechende Datenbank-Eintrag (sie werden gelöscht).';

$txt['news_title'] = 'Neuigkeiten & Newsletter';
$txt['news_settings_desc'] = 'Hier kannst du die Einstellungen und Berechtigungen der Neuigkeiten bzw. des Newsletters vornehmen.';
$txt['news_mailing_desc'] = 'Hier kannst du bei wichtigen Neuigkeiten allen registrierten Benutzern eine Mitteilung oder eine E-Mail schreiben. Du solltest die Funktion jedoch nicht zu oft benutzen, damit die Benutzer nicht das Gefühl bekommen, ungewollte Neuigkeiten bzw. Spam zu erhalten.';
$txt['news_error_no_news'] = 'Keine Daten für die Vorschau verfügbar';
$txt['groups_edit_news'] = 'Benutzergruppen, die Neuigkeiten anlegen dürfen';
$txt['groups_send_mail'] = 'Benutzergruppen, die Newsletter verschicken dürfen';
$txt['xmlnews_enable'] = 'XML-/RSS-Neuigkeiten aktivieren?';
$txt['xmlnews_maxlen'] = 'Max. Länge von Beitragen';
$txt['xmlnews_limit'] = 'XML-/RSS-Begrenzung';
$txt['xmlnews_limit_note'] = 'Anzahl von Beiträgen in den News-Feeds';
$txt['xmlnews_maxlen_note'] = '(0 zum Deaktivieren, keine gute Idee)';
$txt['editnews_clickadd'] = 'Weiteren Beitrag hinzufügen';
$txt['editnews_remove_selected'] = 'Ausgewählte Beiträge löschen';
$txt['editnews_remove_confirm'] = 'Bist du sicher, dass du die ausgewählten Beiträge entfernen möchtest?';
$txt['censor_clickadd'] = 'Weiteres Wort hinzufügen';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Protokolle';
$txt['generate_reports'] = 'Bericht erstellen';

$txt['update_available'] = 'Update verfügbar';
$txt['update_message'] = 'Du benutzt eine veraltete Version von ElkArte, welche unter Umständen Fehler enthält, die bei der aktuellen Version schon behoben sind.
Es wird empfohlen, sobald wie möglich <a href="#" id="update-link">das Forum zu aktualisieren</a>!';

$txt['manageposts'] = 'Beiträge & Themen';
$txt['manageposts_title'] = 'Beiträge & Themen verwalten';
$txt['manageposts_description'] = 'Hier kannst du alle Einstellungen zu den Themen und Beiträgen vornehmen.';

$txt['manageposts_seconds'] = 'Sekunden';
$txt['manageposts_minutes'] = 'Minuten';
$txt['manageposts_characters'] = 'Zeichen';
$txt['manageposts_days'] = 'Tagen';
$txt['manageposts_posts'] = 'Beiträge';
$txt['manageposts_topics'] = 'Themen';

$txt['pollMode'] = 'Umfragen aktivieren';

$txt['manageposts_settings'] = 'Beitragseinstellungen';
$txt['manageposts_settings_description'] = 'Hier kannst du alle Einstellungen, die sich auf Beiträge beziehen, vornehmen.';

$txt['manageposts_bbc_settings'] = 'Bulletin Board Code';
$txt['manageposts_bbc_settings_description'] = 'Bulletin Board Code kann zum Formatieren des Beitrages genutzt werden. Um das Wort Haus im Text fett hervorzuheben, schreiben Sie einfach "[b]Haus[/b]". Alle Bulletin Board Code-Tags sind von eckigen Klammern umgeben: "[" und "]".';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code-Einstellungen';

$txt['manageposts_topic_settings'] = 'Themen-Einstellungen';
$txt['manageposts_topic_settings_description'] = 'Hier kannst du alle Einstellungen, die sich auf Themen beziehen, vornehmen.';

$txt['managedrafts_settings'] = 'Einstellungen für Entwürfe';
$txt['managedrafts_settings_description'] = 'Hier kannst du alle Einstellungen, die sich auf Entwürfe beziehen, vornehmen.';
$txt['manage_drafts'] = 'Entwürfe';

$txt['mail_center'] = 'Mailinglisten-Übersicht';
$txt['mm_emailerror'] = 'Nicht versandte E-Mails';
$txt['mm_emailfilters'] = 'Filter';
$txt['mm_emailparsers'] = 'Parser-Regeln';
$txt['mm_emailtemplates'] = 'Vorlagen';
$txt['mm_emailsettings'] = 'Einstellungen';

$txt['removeNestedQuotes'] = 'Entfernen von verschachtelten Zitaten aktivieren';
$txt['enableSpellChecking'] = 'Rechtschreibprüfung aktivieren';
$txt['enableSpellChecking_warning'] = 'Dies funktioniert nicht auf allen Servern!';
$txt['enableSpellChecking_error'] = 'Dies funktioniert nicht auf deinem Server!';
$txt['enableVideoEmbeding'] = 'Automatisches Einbetten von Videos aktivieren.';
$txt['enableCodePrettify'] = 'Syntax-Highlightning für CODE-Tags benutzen';
$txt['max_messageLength'] = 'Max. Zeichen pro Beitrag';
$txt['max_messageLength_zero'] = '0 = kein Limit';
$txt['convert_to_mediumtext'] = 'Deine Datenbank akzeptiert derzeit keine Beiträge mit mehr als 65.535 Zeichen.  Bitte konvertiere mittels der <a href="%1$s">Wartung</a> zunächst die Datenbank, um dann die maximale Anzahl der Zeichen erneut zu konfigurieren.';
$txt['topicSummaryPosts'] = 'Anzahl der Beiträge in der Zusammenfassung';
$txt['spamWaitTime'] = 'Min. Zeitabstand zwischen zwei Beiträgen derselben IP-Adresse';
$txt['edit_wait_time'] = 'Wartezeit für Änderungsdatum';
$txt['edit_disable_time'] = 'Max. erlaubte Zeit zum Editieren eines Beitrages nach dem Schreiben';
$txt['edit_disable_time_zero'] = '0 = deaktiviert';
$txt['preview_characters'] = 'Max. Länge der Vorschau vom ersten bzw. letzten Beitrag';
$txt['preview_characters_units'] = 'Zeichen';
$txt['preview_characters_zero'] = '0 = gesamten Beitrag zeigen';
$txt['message_index_preview'] = 'Vorschau von Beiträgen auf dem Beitragsindex.';
$txt['message_index_preview_off'] = 'Keine Vorschau anzeigen';
$txt['message_index_preview_first'] = 'Vorschau vom ersten Beitrag benutzen';
$txt['message_index_preview_last'] = 'Vorschau vom letzten Beitrag benutzen.';

$txt['enableBBC'] = 'Bulletin Board Code aktivieren';
$txt['enablePostHTML'] = 'Verwenden von geläufigen HTML-Tags aktivieren';
$txt['autoLinkUrls'] = 'Automatischen Link für URLs erzeugen';
$txt['disabledBBC'] = 'Aktivierte BBC-Tags';
$txt['bbcTagsToUse'] = 'Aktivierte BBC-Tags';
$txt['bbcTagsToUse_select'] = 'Wähle die erlaubten Tags aus';
$txt['bbcTagsToUse_select_all'] = 'Wähle alle Tags';

$txt['enableParticipation'] = 'Teilnahmesymbol aktivieren';
$txt['enableFollowup'] = 'Follow-ups aktivieren';
$txt['enable_unwatch'] = 'Themen nicht länger beobachten aktivieren';
$txt['oldTopicDays'] = 'Anzahl der Tage, nach denen das Thema als veraltet gekennzeichnet wird';
$txt['oldTopicDays_zero'] = '0 = deaktiviert';
$txt['defaultMaxTopics'] = 'Anzahl der Themen pro Seite im Themenindex';
$txt['defaultMaxMessages'] = 'Anzahl der Beiträge pro Seite innerhalb des Themas';
$txt['disable_print_topic'] = 'Deaktiviere das Drucken von Themen';
$txt['hotTopicPosts'] = 'Anzahl der Beiträge für die Kennzeichnung als heißes Thema';
$txt['hotTopicVeryPosts'] = 'Anzahl der Beiträge für die Kennzeichnung als sehr heißes Thema';
$txt['useLikesNotViews'] = 'Benutze Anzahl der Gefällt mir anstelle von Anzahl der Antworten, um zu bestimmen, ob ein Thema als heißes Thema gekennzeichnet wird.';
$txt['enableAllMessages'] = 'Max. Antworten in einem Thema, um alle Antworten anzeigen zu lassen';
$txt['enableAllMessages_zero'] = '0 = deaktiviert';
$txt['disableCustomPerPage'] = 'Benutzerdefinierte Anzahl von Themen bzw. Beiträgen pro Seite deaktivieren';
$txt['enablePreviousNext'] = 'Vorwärts- bzw. Rückwärtsblättern von Themen aktivieren';

$txt['not_done_title'] = 'Ich bin noch nicht fertig!';
$txt['not_done_reason'] = 'Um das Überlasten des Servers zu verhindern, wurde der Prozess kurzzeitig pausiert. Er sollte in ein paar Sekunden automatisch weiterlaufen und die Anzeige sollte aktualisiert werden. Sollte dies nicht geschehen, klicke bitte auf \'Weiter\'.';
$txt['not_done_continue'] = 'Weiter';

$txt['general_settings'] = 'Generell';
$txt['database_paths_settings'] = 'Datenbank & Pfade';
$txt['cookies_sessions_settings'] = 'Cookies & Sitzungen';
$txt['caching_settings'] = 'Cache';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP-Info';
$txt['phpinfo_localsettings'] = 'Lokale Einstellungen';
$txt['phpinfo_defaultsettings'] = 'Standard-Einstellungen';
$txt['phpinfo_itemsettings'] = 'Einstellungen';

$txt['language_configuration'] = 'Sprachen';
$txt['language_description'] = 'Diese Sektion erlaubt dir das Verwalten von Sprachdateien deines Forums, das Herunterladen von neuen Sprachen von ElkArte und das Vornehmen von sprachspezifischen Einstellungen.';
$txt['language_edit'] = 'Sprachdateien editieren';
$txt['language_add'] = 'Sprachen hinzufügen';
$txt['language_settings'] = 'Einstellungen';

$txt['advanced'] = 'Erweitert';
$txt['simple'] = 'Einfach';

$txt['admin_news_select_recipients'] = 'Bitte wähle aus, wer den Newsletter erhalten soll.';
$txt['admin_news_select_group'] = 'Benutzergruppen';
$txt['admin_news_select_group_desc'] = 'Wähle die Gruppen, die den Newsletter erhalten sollen.';
$txt['admin_news_select_members'] = 'Benutzer';
$txt['admin_news_select_members_desc'] = 'Weitere einzelne Benutzer, die den Newsletter erhalten sollen.';
$txt['admin_news_select_excluded_members'] = 'Ausgeschlossene Benutzer';
$txt['admin_news_select_excluded_members_desc'] = 'Benutzer, die den Newsletter nicht erhalten sollen.';
$txt['admin_news_select_excluded_groups'] = 'Ausgeschlossene Benutzergruppen';
$txt['admin_news_select_excluded_groups_desc'] = 'Wähle die Gruppen, die den Newsletter nicht erhalten sollen.';
$txt['admin_news_select_email'] = 'E-Mail-Adressen';
$txt['admin_news_select_email_desc'] = 'Eine Liste der E-Mail-Adressen, an welche der Newsletter geschickt werden soll (getrennt durch Semikolon: Adresse1; Adresse2).';
$txt['admin_news_select_override_notify'] = 'Überschreibe aktuelle Benachrichtigungseinstellungen der Benutzer';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Du kannst keine Mitteilung an eine E-Mail-Adresse senden. Solltest du fortfahren, werden alle E-Mail-Adressen ignoriert.\\n\\nBist du sicher, dass du das tun möchtest?';

$txt['mailqueue_browse'] = 'Warteschlange durchsuchen';
$txt['mailqueue_settings'] = 'Einstellungen';

$txt['admin_search'] = 'Schnellsuche';
$txt['admin_search_type_internal'] = 'Aufgaben & Einstellung';
$txt['admin_search_type_member'] = 'Benutzer';
$txt['admin_search_type_online'] = 'Online-Handbuch';
$txt['admin_search_go'] = 'Los';
$txt['admin_search_results'] = 'Suchresultate';
$txt['admin_search_results_desc'] = 'Ergebnisse der Suche: "%1$s"';
$txt['admin_search_results_again'] = 'Erneut suchen';
$txt['admin_search_results_none'] = 'Keine Ergebnisse gefunden!';

$txt['admin_search_section_sections'] = 'Bereich';
$txt['admin_search_section_settings'] = 'Einstellung';

$txt['core_settings_title'] = 'Zentrale Funktionen';
$txt['core_settings_desc'] = 'Auf dieser Seite kannst du zusätzliche Funktionen deines Forums ein- oder ausschalten.';
$txt['mods_cat_features'] = 'Funktionen';
$txt['mods_cat_security_general'] = 'Generell';
$txt['antispam_title'] = 'Antispam';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Verschiedenes';
$txt['mods_cat_layout'] = 'Layout';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderation';
$txt['signature_settings_short'] = 'Signaturen';
$txt['custom_profile_shorttitle'] = 'Profilfelder';
$txt['pruning_title'] = 'Protokolle bereinigen';

$txt['core_settings_activation_message'] = 'Die Funktion {core_feature} wurde aktiviert. Klicke auf den Titel der Funktion, um diese zu konfigurieren.';
$txt['core_settings_deactivation_message'] = 'Die Funktion {core_feature} wurde deaktiviert.';
$txt['core_settings_generic_error'] = 'Ein unbekannter Fehler ist aufgetreten, bitte lade die Seite neu und versuche es erneut.';

$txt['boardsEdit'] = 'Boards verwalten';
$txt['mboards_new_cat'] = 'Neue Kategorie erstellen';
$txt['manage_holidays'] = 'Feiertage verwalten';
$txt['calendar_settings'] = 'Kalendereinstellungen';
$txt['search_weights'] = 'Gewichtung';
$txt['search_method'] = 'Suchmethode';
$txt['search_sphinx'] = 'Sphinx einstellen';

$txt['smiley_sets'] = 'Smiley-Sets';
$txt['smileys_add'] = 'Smiley hinzufügen';
$txt['smileys_edit'] = 'Smileys ändern';
$txt['smileys_set_order'] = 'Smiley-Reihenfolge ändern';
$txt['icons_edit_message_icons'] = 'Beitragssymbole verwalten';

$txt['membergroups_new_group'] = 'Benutzergruppe hinzufügen';
$txt['membergroups_edit_groups'] = 'Benutzergruppen editieren';
$txt['permissions_groups'] = 'Gruppen-Berechtigungen';
$txt['permissions_boards'] = 'Board-Berechtigungen';
$txt['permissions_profiles'] = 'Profile ändern';
$txt['permissions_post_moderation'] = 'Beitragsmoderation';

$txt['browse_packages'] = 'Pakete durchsuchen';
$txt['download_packages'] = 'Pakete herunterladen';
$txt['upload_packages'] = 'Paket hochladen';
$txt['installed_packages'] = 'Installierte Pakete';
$txt['package_file_perms'] = 'Dateiberechtigungen';
$txt['package_settings'] = 'Einstellungen';
$txt['package_servers'] = 'Paketserver';
$txt['themeadmin_admin_title'] = 'Verwalten & Installieren';
$txt['themeadmin_list_title'] = 'Theme-Einstellungen';
$txt['themeadmin_reset_title'] = 'Optionen zurücksetzen';
$txt['themeadmin_edit_title'] = 'Themes editieren';
$txt['admin_browse_register_new'] = 'Neuen Benutzer anlegen';

$txt['search_engines'] = 'Suchmaschinen';
$txt['spider_logs'] = 'Protokolle';
$txt['spider_stats'] = 'Statistiken';

$txt['paid_subscriptions'] = 'Bezahlte Abonnements';
$txt['paid_subs_view'] = 'Abonnements anschauen';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks / Sprungmarken';
$txt['hooks_field_hook_name'] = 'Sprungmarken-Name';
$txt['hooks_field_function_name'] = 'Name der Funktion';
$txt['hooks_field_function'] = 'Funktion';
$txt['hooks_field_included_file'] = 'Geladende Datei';
$txt['hooks_field_file_name'] = 'Dateiname';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Aktiviert';
$txt['hooks_disabled'] = 'Deaktiviert'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Nicht gefunden';
$txt['hooks_no_hooks'] = 'Zur Zeit sind keine Sprungmarken im System registriert.';
$txt['hooks_disable_legend'] = 'Legende';
$txt['hooks_disable_legend_exists'] = 'Die Sprungmarke existiert und ist aktiviert.';
$txt['hooks_disable_legend_disabled'] = 'Die Sprungmarke existiert, ist aber deaktiviert.';
$txt['hooks_disable_legend_missing'] = 'Die Sprungmarke konnte nicht gefunden werden.';
$txt['hooks_reset_filter'] = 'Filter zurücksetzen';

$txt['board_perms_allow'] = 'Erlaubt';
$txt['board_perms_ignore'] = 'Ignorieren';
$txt['board_perms_deny'] = 'Verboten';
$txt['all_boards_in_cat'] = 'Alle Boards in dieser Kategorie';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Wort-Separator';

$txt['admin_order_title'] = 'Fehler beim Sortieren';
$txt['admin_order_error'] = 'Ein unbekannter Fehler ist während der Verarbeitung aufgetreten';

// Known controllers that can work on the front page
$txt['default'] = 'Standard';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
