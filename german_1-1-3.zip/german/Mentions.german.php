<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Meine Benachrichtigungen';
$txt['my_unread_mentions'] = 'Meine ungelesenen Benachrichtungen';
$txt['my_mentions_pages'] = 'Seite %1$d';
$txt['no_mentions_yet'] = 'Keine Benachrichtigungen';
$txt['no_new_mentions'] = 'Keine neuen Benachrichtigungen';

$txt['mentions_from'] = 'Benutzer';
$txt['mentions_when'] = 'Wann';
$txt['mentions_what'] = 'Beitrag';
$txt['mentions_all'] = 'Alle anzeigen';
$txt['mentions_unread'] = 'Ungelesene anzeigen';
$txt['mentions_action'] = 'Aktionen';
$txt['mentions_delete_warning'] = 'Bist du sicher, dass du diese Benachrichtigung(en) löschen möchtest?';
$txt['mentions_markread'] = 'Als gelesen markieren';
$txt['mentions_markunread'] = 'Als ungelesen markieren';

$txt['mentions_settings'] = 'Benachrichtigungseinstellungen';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = 'Benachrichtigungen aktivieren';
$txt['mentions_buddy'] = 'Benutzer benachrichtigen, wenn du sie zu Freundeslisten hinzufügst';
$txt['mentions_dont_notify_rlike'] = 'Benutzer nicht benachrichtigen, wenn ein Gefällt mir wieder entfernt wird';

$txt['mention_mentionmem'] = 'Hat dich im Beitrag "{msg_link}" erwähnt';
$txt['mention_likemsg'] = 'Gefällt dein Beitrag "{msg_link}"';
$txt['mention_rlikemsg'] = 'Gefällt dein Beitrag "{msg_link}" nicht mehr';
$txt['mention_buddy'] = 'Hat dich zur Freundesliste hinzugefügt.';
$txt['mention_quotedmem'] = 'Quoted a message of yours in {msg_link}';
$txt['mention_mailfail'] = 'Disabled email notification due to delivery failure';

$txt['mentions_type_all'] = 'Alle';
$txt['mentions_type_mentionmem'] = 'Erwähnungen';
$txt['mentions_type_likemsg'] = 'Gefällt mir';
$txt['mentions_type_rlikemsg'] = 'Gefällt mir nicht mehr';
$txt['mentions_type_buddy'] = 'Freunde';
$txt['mentions_type_quotedmem'] = 'Quoted';
$txt['mentions_type_mailfail'] = 'Delivery Failure';

$txt['mentions_mark_all_read'] = 'Alle als gelesen markieren';

$txt['setting_notify_enable_this'] = 'Enable user notifications of this event.';

$txt['setting_buddy'] = 'Freunde';
$txt['setting_likemsg'] = 'Gefällt mir';
$txt['setting_rlikemsg'] = 'Removed likes';
$txt['setting_mentionmem'] = '@mentions';
$txt['setting_quotedmem'] = 'Zitiere';
$txt['setting_mailfail'] = 'Delivery Failures';