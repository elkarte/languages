<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Datum';
$txt['badbehaviorlog_protocol'] = 'Protokoll';
$txt['badbehaviorlog_method'] = 'Methode';
$txt['badbehaviorlog_request'] = 'Request';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'Benutzer-ID';
$txt['badbehaviorlog_username'] = 'Benutzername';
$txt['badbehaviorlog_headers'] = 'Header';
$txt['badbehaviorlog_agent'] = 'Browser';
$txt['badbehaviorlog_entity'] = 'Schreiben';
$txt['badbehaviorlog_key'] = 'Schlüssel';
$txt['badbehaviorlog_ip'] = 'IP-Adresse';
$txt['badbehaviorlog_total_entries'] = 'Gesamtanzahl';
$txt['badbehaviorlog_error_valid_code'] = 'Grund';
$txt['badbehaviorlog_error_valid_response'] = 'HTTP-Status';
$txt['badbehaviorlog_error_valid_explaination'] = 'HTTP-Grund';
$txt['badbehaviorlog_error_valid_log'] = 'Details';
$txt['badbehaviorlog_log'] = 'BadBehavior-Protokoll';
$txt['badbehaviorlog_desc'] = 'Anschließend eine List aller BadBehaviour-Einträge, die protokolliert wurden.';
$txt['badbehaviorlog_details'] = 'Zusätzliche Details';
$txt['badbehaviorlog_no_entries_found'] = 'Es sind momentan keine Protokolleinträge vorhanden.';

$txt['badbehaviorlog_remove_selection'] = 'Ausgewählte entfernen';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Bist du dir sicher, dass du die ausgewählten Einträge entfernen möchtest?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Alle gefilterten Einträge entfernen';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Bist du dir sicher, dass du die ausgewählten Einträge entfernen möchtest?';
$txt['badbehaviorlog_sure_remove'] = 'Bist du dir sicher, dass das Protokoll komplett geleert werden soll?';

$txt['badbehaviorlog_remove'] = 'Ausgewählte entfernen';
$txt['badbehaviorlog_removeall'] = 'Alle entfernen';
$txt['badbehaviorlog_clear_filter'] = 'Filter löschen';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Filter hinzufügen';
$txt['badbehaviorlog_apply_filter'] = 'Filter hinzufügen';
$txt['badbehaviorlog_applying_filter'] = 'Hinzufügen des Filters';
$txt['badbehaviorlog_filter_only_member'] = 'Nur Meldungen dieses Benutzers anzeigen';
$txt['badbehaviorlog_filter_only_ip'] = 'Nur Meldungen dieser IP-Adresse anzeigen';
$txt['badbehaviorlog_filter_only_session'] = 'Nur Meldungen dieser Sitzung anzeigen';
$txt['badbehaviorlog_filter_only_headers'] = 'Nur Meldungen dieser URL anzeigen';
$txt['badbehaviorlog_filter_only_agent'] = 'Nur Meldungen mit dem gleichem User-Agent anzeigen';

$txt['badbehaviorlog_session'] = 'Sitzung';
$txt['badbehaviorlog_error_url'] = 'URL der Seite, die protokolliert wurde';

$txt['badbehaviorlog_reverse_direction'] = 'Chronologische Reihenfolge der Liste ändern';
$txt['badbehaviorlog_filter_only_type'] = 'Zeige nur Einträge mit diesem Kennzeichen';