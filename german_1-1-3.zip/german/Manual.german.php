<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'ElkArte-Benutzerhilfe';

$txt['manual_welcome'] = 'Willkommen bei %s, erstellt mit Hilfe der ElkArte-Forensoftware!';
$txt['manual_introduction'] = 'ElkArte ist eine elegante, effiziente, umfangreiche und freie Forensoftware. Sie erlaubt es Benutzern auf sichere und komfortable Art, sich in Diskussionen über ein bestimmtes Thema zu unterhalten. Des Weiteren hat sie eine Vielzahl an Funktionen, die die Benutzer zu ihrem Vorteil nutzen können. Hilfe zu vielen von ElkArtes Funktionen kannst du entweder per Klick auf das Fragezeichensymbol neben dem relevanten Abschnitt oder per Auswahl eines der Verweise auf dieser Seite erhalten. Diese Verweise führen auf ElkArtes zentrale Dokumentation auf der offiziellen ElkArte-Website.';
$txt['manual_docs_and_credits'] = 'Für weitere Informationen über die Benutzung von ElkArte ziehe bitte auch das <a href="%1$s" target="_blank" class="new_win">Dokumentationswiki</a> zu Rate und lese die <a href="%2$s">Danksagungen</a>, um herauszufinden, wer ElkArte zu dem gemacht hat, was es heute ist.';

$txt['manual_section_registering_title'] = 'Registrierung';
$txt['manual_section_logging_in_title'] = 'Anmelden';
$txt['manual_section_profile_title'] = 'Profil';
$txt['manual_section_search_title'] = 'Suche';
$txt['manual_section_posting_title'] = 'Beiträge';
$txt['manual_section_bbc_title'] = 'Bulletin Board Code (BBC)';
$txt['manual_section_personal_messages_title'] = 'Private Mitteilungen';
$txt['manual_section_memberlist_title'] = 'Benutzerliste';
$txt['manual_section_calendar_title'] = 'Kalender';
$txt['manual_section_features_title'] = 'Funktionen';

$txt['manual_section_registering_desc'] = 'Bei vielen Foren muss sich der Benutzer registrieren, um vollen Zugriff zu erhalten.';
$txt['manual_section_logging_in_desc'] = 'Nach der Registrierung muss der Benutzer sich anmelden, um auf sein Konto zugreifen zu können.';
$txt['manual_section_profile_desc'] = 'Jeder Benutzer hat sein eigenes Benutzerprofil.';
$txt['manual_section_search_desc'] = 'Die Suche ist ein äußerst hilfreiches Werkzeug zum Auffinden von Informationen in Beiträgen und Themen.';
$txt['manual_section_posting_desc'] = 'Der ganze Sinn eines Forums ist, das Benutzer Beiträge schreiben, um sich selbst auszudrücken.';
$txt['manual_section_bbc_desc'] = 'Beiträge können mit ein wenig BBC aufgewertet werden.';
$txt['manual_section_personal_messages_desc'] = 'Benutzer können Mitteilungen untereinander versenden.';
$txt['manual_section_memberlist_desc'] = 'Die Benutzerliste zeigt alle Mitglieder eines Forums.';
$txt['manual_section_calendar_desc'] = 'Benutzer können Veranstaltungen, Feiertage und Geburtstage mit dem Kalender im Auge behalten.';
$txt['manual_section_features_desc'] = 'Hier findest du eine Liste ausgewählter ElkArte-Funktionen.';