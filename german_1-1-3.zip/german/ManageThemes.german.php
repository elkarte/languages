<?php
// Version: 1.1; ManageThemes

$txt['themeadmin_explain'] = 'Themes regeln das optische Erscheinungsbild deines Forums. Hier kannst du ein Standard-Theme für dein Forum festlegen, welches für alle Benutzer sichtbar ist. Du kannst auch weitere Themes installieren und deinen Benutzern erlauben, eines dieser weiteren Themes zu benutzen (statt dem Standard-Theme).';
$txt['themeadmin_manage'] = 'Verwalten & Installieren';
$txt['theme_forum_theme'] = 'Globale Theme-Einstellungen';
$txt['theme_allow'] = 'Benutzern erlauben, eigene Themes zu wählen?';
$txt['theme_guests'] = 'Standard-Theme:';
$txt['theme_select'] = 'wähle...';
$txt['theme_reset'] = 'Alle Benutzer auf folgendes Theme zurücksetzen:';
$txt['theme_nochange'] = 'Kein Wechsel';
$txt['theme_forum_default'] = 'Forumstandard';

$txt['theme_remove'] = 'Deinstallieren';
$txt['theme_remove_confirm'] = 'Bist du sicher, dass du dieses Theme deinstallieren möchtest?';

$txt['theme_install'] = 'Installiert ein neues Theme';
$txt['theme_install_file'] = 'Von einem Archiv (z.B. *.zip, *.tar.gz)';
$txt['theme_install_dir'] = 'Aus einem Verzeichnis:';
$txt['theme_install_error'] = 'Das Verzeichnis existiert nicht oder enthält kein Theme.';
$txt['theme_install_write_error'] = 'Das Verzeichnis muss beschreibbar sein.';
$txt['theme_install_go'] = 'Installieren';
$txt['theme_install_new'] = 'Eine Kopie des Default-Themes erstellen:';
$txt['theme_install_new_confirm'] = 'Bist du sicher, dass du dieses Theme installieren möchtest?';
$txt['theme_install_writable'] = 'Warnung - du kannst kein neues Theme installieren oder erstellen, weil das Verzeichnis nicht beschreibbar ist!';
$txt['theme_install_general'] = 'Das Theme ist nicht dort, wo es vermutet wird. Bitte überprüfe die eingegebenen Informationen.';
$txt['theme_installed'] = 'Installation erfolgreich';
$txt['theme_installed_message'] = 'ist erfolgreich installiert.';

$txt['theme_pick'] = 'Wähle ein Theme...';
$txt['theme_preview'] = 'Theme-Vorschau';
$txt['theme_set'] = 'Benutze dieses Theme';
$txt['theme_user'] = 'Benutzer nutzt dieses Theme.';
$txt['theme_users'] = 'Benutzer nutzen dieses Theme.';
$txt['theme_pick_variant'] = 'Variante auswählen:';

$txt['theme_edit'] = 'Editiere das Theme';
$txt['theme_edit_style'] = 'Editiere die Stylesheet-Dateien (Farben, Schriften, etc.)';
$txt['theme_edit_index'] = 'Editiere das Index-Template (das Haupt-Template)';
$txt['theme_edit_no_save'] = 'Diese Datei kann nicht gespeichert werden, weil sie schreibgeschützt ist! Bitte kontrolliere die Berechtigungen auf dem FTP-Server, sie sollten auf 0777 stehen!';
$txt['theme_edit_save'] = 'Speichere Änderungen';
$txt['theme_edit_not_writable'] = 'Nicht beschreibbar';

$txt['theme_global_description'] = 'Das ist das Standard-Theme, d.h. Dein Theme wechselt mit den Einstellungen des Administrators und dem Board, welches du anschaust.';

$txt['theme_url_config'] = 'Theme-URLs und -Konfiguration';
$txt['theme_variants'] = 'Theme-Varianten';
$txt['theme_options'] = 'Theme-Einstellungen';
$txt['actual_theme_name'] = 'Name des Themes: ';
$txt['actual_theme_dir'] = 'Theme-Verzeichnis: ';
$txt['actual_theme_url'] = 'URL des Themes: ';
$txt['actual_images_url'] = 'Bilder-URL des Themes: ';

$txt['theme_variants_default'] = 'voreingestellte Theme-Variante:';
$txt['theme_variants_user_disable'] = 'Deaktiviere das Auswählen von Varianten.';

$txt['site_slogan'] = 'Slogan der Seite:';
$txt['site_slogan_desc'] = '(Add your own text for a slogan here.)';
$txt['header_layout'] = 'Layout des Kopfbereichs:';
$txt['header_layout_desc'] = '(Diese Einstellungen erlaubt es, eines der folgenden drei Layouts zu wählen.)';
$txt['header_layout_default_name'] = 'Standard:';
$txt['header_layout_default_desc'] = 'Das Logo wird auf der rechten Seite angezeigt, der Name des Forums auf der linken.';
$txt['header_layout_logo_only_name'] = 'Nur Logo';
$txt['header_layout_logo_only_desc'] = 'Nur das Logo wird angezeigt, zentriert im Kopfbereich des Forums.';
$txt['header_layout_inverted_name'] = 'Logo links';
$txt['header_layout_inverted_desc'] = 'Wie beim Standard, Logo und Name sind aber vertauscht (Name auf der rechten Seite, Logo auf der linken).';
$txt['header_layout_default'] = 'Standard';
$txt['header_layout_logo_only'] = 'Nur Logo';
$txt['header_layout_inverted'] = 'Logo links';
$txt['forum_width'] = 'Breite des Forums:';
$txt['forum_width_desc'] = '(Festlegen der Breite des Forums. Beispiele: 950px, 80%, 1240px)';

$txt['enable_news'] = 'News im Kopfbereich anzeigen:';
$txt['enable_news_off'] = 'Aus';
$txt['enable_news_random'] = 'Zufällig';
$txt['enable_news_fader'] = 'Fader';
$txt['enable_news_off_name'] = 'Aus:';
$txt['enable_news_off_desc'] = 'Es werden keine News-Einträge angezeigt.';
$txt['enable_news_random_name'] = 'Zufällig:';
$txt['enable_news_random_desc'] = 'Es wird nur ein zufälliger News-Eintrag angezeigt.';
$txt['enable_news_fader_name'] = 'Fader:';
$txt['enable_news_fader_desc'] = 'Alle News-Einträge werden abwechselnd angezeigt.';

$txt['show_group_key'] = 'Benutzergruppennamen im Info-Center des Forums anzeigen.';
$txt['additional_options_collapsible'] = 'Erweiterte Schreiboptionen zunächst minimiert anzeigen?';
$txt['who_display_viewing'] = '"Wer schaut den Board-Index bzw. die Beiträge an" anzeigen:';
$txt['who_display_viewing_off'] = 'Nicht anzeigen';
$txt['who_display_viewing_numbers'] = 'Nur Zahlen anzeigen';
$txt['who_display_viewing_names'] = 'Benutzernamen anzeigen';
$txt['show_stats_index'] = 'Statistiken im Info-Center anzeigen.';
$txt['latest_members'] = 'Neuesten Benutzer im Info-Center anzeigen?';
$txt['last_modification'] = 'Änderungsdatum in Beiträgen anzeigen?';
$txt['user_avatars'] = 'Avatar im Beitrag anzeigen?';
$txt['member_list_bar'] = 'Benutzerliste anzeigen';
$txt['current_pos_text_img'] = 'Aktuelle Position im Forum als Link statt Text anzeigen.';
$txt['show_view_profile_button'] = 'Profil-Button unter dem Beitrag anzeigen.';
$txt['enable_mark_as_read'] = '"Als gelesen markieren"-Buttons aktivieren.';
$txt['header_logo_url'] = 'URL zum Forum-Logo:';
$txt['header_logo_url_desc'] = '(leer lassen für Standard-Logo.)';

$txt['recent_post_topics'] = 'Show recent posts or recent topics on board index.';
$txt['show_recent_topics'] = 'Show recent topics';
$txt['show_recent_posts'] = 'Show recent posts';
$txt['number_recent_posts'] = 'Anzahl der neuesten Themen im Forum-Index:';
$txt['number_recent_posts_desc'] = '(0 = keine Anzeige)';
$txt['hide_post_group'] = 'Titel der beitragsabhängigen Benutzergruppe verstecken.';
$txt['hide_post_group_desc'] = 'Versteckt den Titel der beitragsabhängigen Benutzergruppe, wenn der Benutzer in einer anderen, nicht beitragsabhängigen Gruppe eingestuft wurde (z.B. Globaler Moderator).';

$txt['theme_options_defaults'] = 'Das sind die Standardoptionen für einige Einstellungen in den Profilen der Benutzer. Änderst du diese hier, betrifft das <b>nur neue Benutzer und neue Gäste</b>.';
$txt['theme_options_title'] = 'Ändert Standardoptionen oder stellt Einstellungen zurück';

$txt['themeadmin_title'] = 'Themes-Management';
$txt['themeadmin_description'] = 'Hier kannst du die Einstellungen für deine Themes verändern, die Themeauswahl bestimmen und Standardoptionen zurückstellen.';
$txt['themeadmin_admin_desc'] = 'Themes ermöglichen ein anderes Look&Feel. Hier kannst du weitere Themes installieren, das Standard-Theme festlegen, alle Benutzer auf ein bestimmtes Theme zurückstellen und weitere Einstellungen vornehmen. Denke daran, die Einstellungen des aktuellen Themes zu prüfen, wenn du ein neues Theme aktiviert hast.';
$txt['themeadmin_list_desc'] = 'Hier kannst du eine Liste der installierten Themes anschauen, die Pfade und Einstellungen ändern oder Themes deinstallieren.';
$txt['themeadmin_reset_desc'] = 'Hier kannst du Theme-relevante Einstellungen vornehmen, die alle Benutzer betreffen, die dieses Theme nutzen.';
$txt['themeadmin_edit_desc'] = 'Hier kannst du das Stylesheet und die Template-Dateien des Themes bearbeiten. Bitte beachte, dass du schon wissen solltest, was du tust, wenn du hier Änderungen vornimmst. Du könntest sonst dein Forum beschädigen!';
$txt['themeadmin_modify_styles'] = 'Changing a themes style is risky so be certain of what you are doing. Always have a backup copy of the theme directory that you are working in to use to recover from an error with. For help with this before you start, visit the <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">ElkArte Community</a>.';

$txt['themeadmin_list_heading'] = 'Theme-Einstellungen';
$txt['themeadmin_list_tip'] = 'Layout-Einstellungen können je nach installiertem Theme variieren. Editiere die installierten Themes, um ihre individuellen Möglichkeiten zu nutzen, oder ändere deren Installationsverzeichnis und deren URL-Einstellungen.';
$txt['themeadmin_list_theme_dir'] = 'Theme-Verzeichnis: (Templates)';
$txt['themeadmin_list_invalid'] = '(Achtung - Dieser Pfad ist nicht korrekt!)';
$txt['themeadmin_list_theme_url'] = 'URL zum Verzeichnis:';
$txt['themeadmin_list_images_url'] = 'URL zum Bilder-Verzeichnis:';
$txt['themeadmin_list_reset'] = 'Theme-URLs und -Verzeichnis zurückstellen';
$txt['themeadmin_list_reset_dir'] = 'Basispfad zum Theme-Verzeichnis:';
$txt['themeadmin_list_reset_url'] = 'Basis-URL zum Theme-Verzeichnis:';
$txt['themeadmin_list_reset_go'] = 'Versuche, alle Themes zugleich zurückzustellen';

$txt['themeadmin_reset_tip'] = 'Jedes Theme kann andere Einstellungen beherbergen, die deine Benutzer wählen können. Dazu zählen z.B. die Schnellantwort, Avatare, Signaturen, Layout-Optionen und ähnliches. Hier kannst du diese Einstellungen global festlegen oder die Einstellungen deiner Benutzer zurücksetzen.<br /><br />Bitte beachte, dass manche Themes feste Funktionen und Einstellungen haben können, die nicht zu verändern sind. Diese werden hier nicht aufgeführt.';
$txt['themeadmin_reset_defaults'] = 'Standardoptionen (Gäste) für dieses Theme zurückstellen';
$txt['themeadmin_reset_defaults_current'] = 'Option(en) zurückgesetzt.';
$txt['themeadmin_reset_members'] = 'Stelle alle aktuellen Benutzeroptionen für dieses Theme zurück';
$txt['themeadmin_reset_remove'] = 'Entferne alle Benutzeroptionen und benutze die Standardwerte';
$txt['themeadmin_reset_remove_current'] = 'Benutzer verwenden eigene Optionen.';
// Don't use entities in the below string.
$txt['themeadmin_reset_remove_confirm'] = 'Bist du sicher, dass du alle Theme-Optionen entfernen möchtest?\\nDies kann manche Profilfelder ebenfalls zurückstellen.';
$txt['themeadmin_reset_options_info'] = 'Die folgenden Einstellungen stellen die Optionen für <em>jeden</em> zurück. Um eine Option zu verändern, wähle "Ändern" im Drop-Down-Feld und stelle die Option entsprechend deiner Vorlieben ein. Um den Standardwert zu benutzen, wähle "Entfernen" oder "Nicht ändern", um die betreffende Option nicht zu ändern.';
$txt['themeadmin_reset_options_change'] = 'Ändern';
$txt['themeadmin_reset_options_none'] = 'Nicht ändern';
$txt['themeadmin_reset_options_default'] = 'Standard';

$txt['themeadmin_edit_browse'] = 'Durchsuche die Templates und Dateien des Themes';
$txt['themeadmin_edit_style'] = 'Editiere das Stylesheet des Themes';
$txt['themeadmin_edit_copy_template'] = 'Eine Kopie dieses Templates erstellen';
$txt['themeadmin_edit_exists'] = 'existiert bereits';
$txt['themeadmin_edit_do_copy'] = 'kopieren';
$txt['themeadmin_edit_copy_warning'] = 'Wenn das System eine Template- oder Sprachdatei nicht finden sollte, schaut es bei dem Theme nach, auf welchem es basiert (bzw. beim Default-Theme).<br />Wenn du ein Template nicht editieren möchtest, solltest du es auch nicht kopieren.';
$txt['themeadmin_edit_copy_confirm'] = 'Bist du sicher, dass du dieses Theme kopieren möchtest?';
$txt['themeadmin_edit_overwrite_confirm'] = 'Bist du sicher, dass du dieses Theme über das vorhandene kopieren möchtest?\\nEs werden ALLE Änderungen überschrieben, die du bisher gemacht hast!';
$txt['themeadmin_edit_no_copy'] = '<em>(lässt sich nicht kopieren)</em>';
$txt['themeadmin_edit_filename'] = 'Dateiname';
$txt['themeadmin_edit_modified'] = 'Letzte Aktualisierung';
$txt['themeadmin_edit_size'] = 'Größe';
$txt['themeadmin_edit_error'] = 'Die Datei, die du speichern möchtest, hat folgenden Fehler ausgegeben:';
$txt['themeadmin_edit_on_line'] = 'Beginnt in Zeile:';
$txt['themeadmin_edit_preview'] = 'Vorschau';
$txt['themeadmin_selectable'] = 'Themes, die Benutzer nicht auswählen können:';
$txt['themeadmin_themelist_link'] = 'Liste der installierten Themes anzeigen';

// Strings for the variants
$txt['variant_light'] = 'ElkArte Light';
$txt['variant_besocial'] = 'ElkArte Be Social!';
