<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>Versteckt</em>';
$txt['who_admin'] = 'Betrachtet das Administrations-Center';
$txt['who_moderate'] = 'Betrachtet das Moderations-Center';
$txt['who_generic'] = 'Ach, kaum der Rede wert.';
$txt['who_unknown'] = '<em>Unbekannte Aktion</em>';
$txt['who_user'] = 'Benutzername';
$txt['who_time'] = 'Zeit';
$txt['who_action'] = 'Aktion';
$txt['who_show1'] = 'Zeige ';
$txt['who_show_members_only'] = 'nur Benutzer';
$txt['who_show_guests_only'] = 'nur Gäste';
$txt['who_show_spiders_only'] = 'nur Bots';
$txt['who_show_all'] = 'alle';
$txt['who_no_online_spiders'] = 'Es sind momentan keine Bots online.';
$txt['who_no_online_guests'] = 'Es sind momentan keine Gäste online.';
$txt['who_no_online_members'] = 'Es sind momentan keine Benutzer online.';

$txt['whospider_login'] = 'Schaut sich die Anmeldung an.';
$txt['whospider_register'] = 'Schaut sich die Registrierung an.';
$txt['whospider_reminder'] = 'Hat scheinbar sein Passwort vergessen.';

$txt['whoall_activate'] = 'Aktiviert gerade das Benutzerkonto. Bald gibt es einen Benutzer mehr, juchu!';
$txt['whoall_buddy'] = 'Ändert momentan die Freundesliste.';
$txt['whoall_coppa'] = 'Füllt die Einverständniserklärung für Eltern und Erziehungsberechtigte aus.';
$txt['whoall_credits'] = 'Schaut sich derzeit die Danksagung von ElkArte an.';
$txt['whoall_emailuser'] = 'Sendet eine E-Mail zu einem anderen Benutzer.';
$txt['whoall_groups'] = 'Schaut sich die Benutzergruppen an.';
$txt['whoall_help'] = 'Hofft auf <a href="{help_url}">Hilfe</a>.';
$txt['whoall_quickhelp'] = 'Schaut sich die Administrator-Hilfeseiten an.';
$txt['whoall_pm'] = 'Schaut sich die Mitteilungen an.';
$txt['whoall_auth'] = 'Meldet sich gerade im Forum an.';
$txt['whoall_login'] = 'Hängt wohl in der Anmeldung fest.';
$txt['whoall_login2'] = 'Befindet sich mitten in der Anmeldung.';
$txt['whoall_logout'] = 'Meldet sich gerade aus dem Forum ab. Bis bald!';
$txt['whoall_markasread'] = 'Markiert Themen als gelesen.';
$txt['whoall_mentions'] = 'Schaut sich die Benachrichtigungen an.';
$txt['whoall_modifykarma_applaud'] = 'Hinterlässt eine positive Bewertung.';
$txt['whoall_modifykarma_smite'] = 'Hinterlässt eine negative Bewertung. Pfui!';
$txt['whoall_news'] = 'Schaut sich die Neuigkeiten an.';
$txt['whoall_notify'] = 'Ändert die Benachrichtigungs-Einstellungen.';
$txt['whoall_notifyboard'] = 'Ändert die Benachrichtigungs-Einstellungen.';
$txt['whoall_openidreturn'] = 'Meldet sich gerade mittels OpenID an.';
$txt['whoall_quickmod'] = 'Moderiert ein Board. Psst, besser nicht stören.';
$txt['whoall_recent'] = 'Schaut sich die <a href="{recent_url}">neuesten Themen</a> an.';
$txt['whoall_register'] = 'Registriert ein neues Benutzerkonto im Forum.';
$txt['whoall_reminder'] = 'Fordert eine Passworterinnerung an.';
$txt['whoall_reporttm'] = 'Meldet ein Thema einem Moderator.';
$txt['whoall_spellcheck'] = 'Benutzt die Rechtschreibprüfung.';
$txt['whoall_unread'] = 'Schaut sich ungelesene Themen seit dem letzten Besuch an.';
$txt['whoall_unreadreplies'] = 'Schaut sich ungelesene Antworten seit dem letzten Besuch an.';
$txt['whoall_who'] = 'Ist neugierig, wer <a href="{who_url}">gerade online</a> ist.';

$txt['whoall_collapse_collapse'] = 'Klappt eine Kategorie ein.';
$txt['whoall_collapse_expand'] = 'Klappt eine Kategorie aus.';
$txt['whoall_pm_removeall'] = 'Räumt bei den Mitteilungen auf.';
$txt['whoall_pm_send'] = 'Verfasst eine Mitteilung.';
$txt['whoall_pm_send2'] = 'Verfasst eine Mitteilung.';

$txt['whotopic_announce'] = 'Erstellt die Ankündigung "<a href="%1$s">%2$s</a>".';
$txt['whotopic_attachapprove'] = 'Gibt einen Dateianhang frei.';
$txt['whotopic_dlattach'] = 'Schaut sich einen Dateianhang an.';
$txt['whotopic_deletemsg'] = 'Löscht einen Beitrag.';
$txt['whotopic_editpoll'] = 'Editiert die Umfrage im Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_editpoll2'] = 'Editiert die Umfrage im Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_jsmodify'] = 'Bearbeitet das Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_likes'] = 'Findet einen Beitrag im Thema "<a href="%1$s">%2$s</a>" wahnsinnig toll und kennzeichnet ihn mit Gefällt mir.';
$txt['whotopic_lock'] = 'Schließt das Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_lockvoting'] = 'Schließt die Umfrage im Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_mergetopics'] = 'Führt das Thema "<a href="%1$s">%2$s</a>" mit einem anderen zusammen.';
$txt['whotopic_movetopic'] = 'Verschiebt das Thema "<a href="%1$s">%2$s</a>" in ein anderes Board.';
$txt['whotopic_movetopic2'] = 'Verschiebt das Thema "<a href="%1$s">%2$s</a>" in ein anderes Board.';
$txt['whotopic_post'] = 'Antwortet im Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_post2'] = 'Antwortet im Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_printpage'] = 'Druckt das Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_quickmod2'] = 'Moderiert das Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_poll_remove'] = 'Entfernt die Umfrage im Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_removetopic2'] = 'Löscht das Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_sendtopic'] = 'Sendet das Thema "<a href="%1$s">%2$s</a>" an einen Freund.';
$txt['whotopic_splittopics'] = 'Teilt das Thema "<a href="%1$s">%2$s</a>" in zwei neue.';
$txt['whotopic_sticky'] = 'Fixiert das Thema "<a href="%1$s">%2$s</a>".';
$txt['whotopic_unwatch'] = 'Bestellt ein bisher beobachtetes Thema ab.';
$txt['whotopic_vote'] = 'Stimmt in der Umfrage "<a href="%1$s">%2$s</a>" ab.';
$txt['whotopic_watch'] = 'Beobachtet ab jetzt ein neues Thema.';

$txt['whopost_quotefast'] = 'Zitiert einen Beitrag des Themas "<a href="%1$s">%2$s</a>".';

$txt['whoadmin_editagreement'] = 'Editiert die Nutzungsbedingungen.';
$txt['whoadmin_featuresettings'] = 'Verändert die Forumeinstellungen.';
$txt['whoadmin_modlog'] = 'Schaut sich das Moderatoren-Protokoll an.';
$txt['whoadmin_serversettings'] = 'Verändert die Servereinstellungen des Forums.';
$txt['whoadmin_packageget'] = 'Lädt Pakete herunter.';
$txt['whoadmin_packages'] = 'Schaut sich den Paketmanager an.';
$txt['whoadmin_permissions'] = 'Ändert die Berechtigungen des Forums.';
$txt['whoadmin_pgdownload'] = 'Lädt ein Paket herunter.';
$txt['whoadmin_theme'] = 'Ändert die Theme-Einstellungen.';
$txt['whoadmin_trackip'] = 'Beobachtet eine IP-Adresse.';

$txt['whoallow_manageboards'] = 'Verwaltet die Boards und Kategorien.';
$txt['whoallow_admin'] = 'Schaut sich das <a href="{admin_url}">Administrations-Center</a> an.';
$txt['whoallow_ban'] = 'Editiert die Bann-Liste.';
$txt['whoallow_boardrecount'] = 'Berechnet die Statistiken neu. Puh!';
$txt['whoallow_calendar'] = 'Schaut in den <a href="{calendar_url}">Kalender</a>.';
$txt['whoallow_editnews'] = 'Editiert die Neuigkeiten.';
$txt['whoallow_mailing'] = 'Sendet eine E-Mail.';
$txt['whoallow_maintain'] = 'Führt Wartungsarbeiten durch. Nun wird alles besser!';
$txt['whoallow_manageattachments'] = 'Verwaltet die Dateianhänge.';
$txt['whoallow_moderate'] = 'Schaut sich das <a href="{moderate_url}">Moderations-Center</a> an.';
$txt['whoallow_memberlist'] = 'Ist neugierig und schaut sich die <a href="{memberlist_url}">Benutzerliste</a> an.';
$txt['whoallow_optimizetables'] = 'Optimiert die Datenbanktabellen.';
$txt['whoallow_repairboards'] = 'Repariert die Datenbanktabellen. War das wirklich notwendig?';
$txt['whoallow_search'] = '<a href="{search_url}">Sucht</a> im Forum nach dem Glück.';
$txt['whoallow_search_results'] = 'Schaut sich seine Suchresultate an.';
$txt['whoallow_setcensor'] = 'Editiert die zensierten Wörter.';
$txt['whoallow_setreserve'] = 'Editiert die reservierten Benutzernamen.';
$txt['whoallow_stats'] = 'Schaut sich die <a href="{stats_url}">Statistiken</a> des Forums an.';
$txt['whoallow_viewErrorLog'] = 'Schaut sich das Fehlerprotokoll an.';
$txt['whoallow_viewmembers'] = 'Schaut sich die Benutzerliste an.';

$txt['who_topic'] = 'Schaut sich das Thema "<a href="%1$s">%2$s</a>" an.';
$txt['who_board'] = 'Ist im Board "<a href="%1$s">%2$s</a>" unterwegs.';
$txt['who_index'] = 'Schaut sich den Index von <a href="{script_url}">{forum_name}</a> an.';
$txt['who_viewprofile'] = 'Besucht das Profil von <a href="%1$s">%2$s</a>.';
$txt['who_profile'] = 'Editiert das Profil von <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Erstellt ein neues Thema im Board "<a href="%1$s">%2$s</a>".';
$txt['who_poll'] = 'Erstellt eine neue Umfrage im Board "<a href="%1$s">%2$s</a>".';
$txt['who_topicbyemail'] = 'Startet mittels einer E-Mail ein neues Thema im Board "<a href="%1$s">%2$s</a>".';

$txt['whotopic_postbyemail'] = 'Schreibt im Thema "<a href="%1$s">%2$s</a>" mittels E-Mail-Funktion.';
$txt['whoall_pm_byemail'] = 'Versendet eine Mitteilung per E-Mail.';

// Credits text
$txt['credits'] = 'Danksagung';
$txt['credits_intro'] = 'ElkArte ist 100% kostenlos und open-source. Wir begrüßen und unterstützen eine konstruktive, offene Gemeinschaft und das Arbeiten miteinander. Wir danken Allen, die uns beim Programmieren geholfen haben, die uns Feedback haben zukommen lassen, Fehler und Bugs gemeldet haben und Vorschläge unterbreitet haben, wie wir ElkArte noch anwenderfreundlicher gestalten können. Ein besonderer Gruß geht an <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, aus welchem ElkArte entstand.';
$txt['credits_contributors'] = 'Mitwirkende';
$txt['credits_and'] = 'und';
$txt['credits_copyright'] = 'Copyright';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Erweiterungen';
$txt['credits_software_graphics'] = 'Software/Grafiken';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Grafiken';
$txt['credits_fonts'] = 'Schriftarten';
$txt['credits_groups_contrib'] = 'Mitwirkende';
$txt['credits_contrib_list'] = 'Um dir eine komplette Liste aller Mitwirkenden an Elkarte anzuschauen, besuche bitte unsere <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">Liste von Mitwirkenden</a>.';
$txt['credits_license'] = 'Lizenz';
$txt['credits_copyright'] = 'Copyright';
$txt['credits_version'] = 'Version';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Übersetzer';
$txt['credits_translators_message'] = 'Danke für eure Mühen, die es Benutzern auf der ganzen Welt ermöglichen, ElkArte zu verwenden.';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';