<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Willkommen';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Installationsprüfung';
$txt['install_step_forum'] = 'Einstellungen';
$txt['install_step_databaseset'] = 'Datenbank-Einstellungen';
$txt['install_step_databasechange'] = 'Datenbank-Inhalte';
$txt['install_step_admin'] = 'Benutzerkonto Administrator';
$txt['install_step_delete'] = 'Installation fertigstellen';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'Sprache';
$txt['installer_language_set'] = 'Speichern';
$txt['congratulations'] = 'Glückwunsch, die Installation ist abgeschlossen!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Dein Installationsverzeichnis ist noch beschreibbar! Es ist aus Sicherheitsgründen sinnvoll, die CHMOD-Berechtigungen zu ändern, sodass es schreibgeschützt ist.';
$txt['delete_installer'] = 'Klicke hier, um die Datei \'install.php\' jetzt zu löschen.';
$txt['delete_installer_maybe'] = '<em>(funktioniert nicht auf allen Servern)</em>';
$txt['go_to_your_forum'] = 'Jetzt kannst du <a href="%1$s">Dein neues Forum</a> aufrufen und benutzen. Bitte achte darauf, dass du eingeloggt bist, bevor du versuchst, in das Administrator-Center zu gelangen.';
$txt['good_luck'] = 'Danke für die Installation von ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Willkommen';
$txt['install_welcome_desc'] = 'Willkommen bei ElkArte. Dieses Skript wird dich durch den Installationsprozess von %1$s führen. Im folgenden werden ein paar Daten über dein Forum abgefragt. Die Installation wird nur ein paar Minuten dauern.';
$txt['install_all_lovely'] = 'Ein paar Eingangstests wurden durchgeführt, und alles scheint in Ordnung zu sein. Betätige den \'Fortfahren\'-Button unten, um mit der eigentlichen Installation jetzt zu beginnen.';

$txt['user_refresh_install'] = 'Forum wurde aktualisiert';
$txt['user_refresh_install_desc'] = 'Während der Installation hat das Installationsprogramm eine oder mehrere Datenbanktabellen gefunden, welche schon existiert haben.<br />Alle fehlenden Tabellen deiner Installation wurden mit den Standard-Inhalten erstellt, vorhandene Daten wurden nicht gelöscht.';

$txt['default_topic_subject'] = 'Willkommen zu ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Allgemeine Diskussionen';
$txt['default_board_description'] = 'Diskutiere in diesem Board über alles, was dir einfällt.';
$txt['default_category_name'] = 'Kategorie';
$txt['default_time_format'] = '%d. %B %Y, %H:%M:%S';
$txt['default_news'] = 'ElkArte - Soeben installiert!';
$txt['default_karmaLabel'] = 'Karma';
$txt['default_karmaSmiteLabel'] = '[negativ]';
$txt['default_karmaApplaudLabel'] = '[positiv]';
$txt['default_reserved_names'] = 'Administrator\\nAdmin\\nWebmaster\\nGast\\nroot';
$txt['default_smileyset_name'] = 'Fugue\'s Set';
$txt['default_theme_name'] = 'ElkArte Standard-Theme';

$txt['default_administrator_group'] = 'Administrator';
$txt['default_global_moderator_group'] = 'Globaler Moderator';
$txt['default_moderator_group'] = 'Moderator';
$txt['default_newbie_group'] = 'Neuling';
$txt['default_junior_group'] = 'Junior Mitglied';
$txt['default_full_group'] = 'Vollständige Benutzer';
$txt['default_senior_group'] = 'Senior Mitglied';
$txt['default_hero_group'] = 'Held';

$txt['default_smiley_smiley'] = 'Smiley';
$txt['default_wink_smiley'] = 'Zwinkernd';
$txt['default_cheesy_smiley'] = 'Lächelnd';
$txt['default_grin_smiley'] = 'Grinsend';
$txt['default_angry_smiley'] = 'Ärgerlich';
$txt['default_sad_smiley'] = 'Traurig';
$txt['default_shocked_smiley'] = 'Schockiert';
$txt['default_cool_smiley'] = 'Cool!';
$txt['default_huh_smiley'] = 'Huch!';
$txt['default_roll_eyes_smiley'] = 'Mit den Augen rollend';
$txt['default_tongue_smiley'] = 'Zunge';
$txt['default_embarrassed_smiley'] = 'Verlegen sein';
$txt['default_lips_sealed_smiley'] = 'Schweigend';
$txt['default_undecided_smiley'] = 'Unentschlossen';
$txt['default_kiss_smiley'] = 'Küsschen!';
$txt['default_cry_smiley'] = 'Weinend';
$txt['default_evil_smiley'] = 'Teuflisch';
$txt['default_azn_smiley'] = 'Azn';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Lachend';
$txt['default_police_smiley'] = 'Polizei';
$txt['default_angel_smiley'] = 'Engel';

$txt['error_message_click'] = 'Klicke hier,';
$txt['error_message_try_again'] = 'um diesen Schritt erneut zu versuchen.';
$txt['error_message_bad_try_again'] = 'um trotzdem zu installieren. Beachte bitte, dass dies <em>nicht</em> empfehlenswert ist.';

$txt['install_settings'] = 'Einstellungen';
$txt['install_settings_info'] = 'Nur ein paar Einstellungen... ElkArte hat die meisten Einstellungen bereits für dich erkannt.';
$txt['install_settings_name'] = 'Name des Forums';
$txt['install_settings_name_info'] = 'Das ist der Name deines Forums, z.B. "Mein Forum".';
$txt['install_settings_name_default'] = 'Mein Forum';
$txt['install_settings_url'] = 'Forum-URL';
$txt['install_settings_url_info'] = 'Das ist die URL deines Forums <strong>ohne den abschließenden \'/\'!</strong>.<br />In den meisten Fällen kannst du den voreingestellten Wert übernehmen.';
$txt['install_settings_compress'] = 'Gzip-Ausgabe';
$txt['install_settings_compress_title'] = 'Komprimiere Datenausgabe, um Bandbreite zu sparen.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Diese Option funktioniert nicht auf allen Servern, kann aber eine Menge Bandbreite sparen.<br />Klicke <a href="install.php?obgz=1&amp;pass_string=Erfolgreich" onclick="return reqWin(this.href, 200, 60);" target="_blank">hier</a>, um es zu testen (der Test sollte "Erfolgreich" zurückmelden).';
$txt['install_settings_dbsession'] = 'Datenbanksitzungen';
$txt['install_settings_dbsession_title'] = 'Benutze die Datenbank (statt Dateien) für Sitzungen.';
$txt['install_settings_dbsession_info1'] = 'Diese Option ist grundsätzlich die beste Wahl, da sie Sitzungen zuverlässiger macht.';
$txt['install_settings_dbsession_info2'] = 'Diese Option wird wahrscheinlich nicht fehlerfrei auf diesem Server funktionieren.';
$txt['install_settings_proceed'] = 'Fortsetzen';

$txt['db_settings'] = 'Datenbankservereinstellungen';
$txt['db_settings_info'] = 'Gebe hier die Einstellungen für deinen Datenbankserver ein. Solltest du die Einstellungen nicht wissen, frage deinen Hoster.';
$txt['db_settings_type'] = 'Datenbanktyp';
$txt['db_settings_type_info'] = 'Mehrere unterstützte Datenbank-Systeme gefunden. Bitte das gewünschte System auswählen.';
$txt['db_settings_server'] = 'Name des Servers';
$txt['db_settings_server_info'] = 'Der Servername ist sehr häufig "localhost". Solltest du ihn nicht wissen, versuche zunächst "localhost" oder wende dich an deinen Hoster.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Leer lassen, wenn dein Server auf den Default-Port hört oder du unsicher bist.';
$txt['db_settings_username'] = 'Benutzername';
$txt['db_settings_username_info'] = 'Trage hier den Benutzernamen ein, den du zum Verbinden zu deiner Datenbank benötigst.<br />Solltest du ihn nicht wissen, versuche den Benutzernamen deines FTP-Zugangs, da diese oft übereinstimmen.';
$txt['db_settings_password'] = 'Passwort';
$txt['db_settings_password_info'] = 'Trage hier das Passwort ein, das du zum Verbinden zu deiner Datenbank benötigst.<br />Solltest du es nicht wissen, versuche das Passwort deines FTP-Zugangs, da diese oft übereinstimmen.';
$txt['db_settings_database'] = 'Datenbankname';
$txt['db_settings_database_info'] = 'Trage hier den Namen der Datenbank ein, welche du für die Speicherung der ElkArte-Daten benutzen möchtest.';
$txt['db_settings_database_info_note'] = 'Falls diese Datenbank nicht existiert, wird dieses Installationsskript versuchen, sie selbst zu erstellen.';
$txt['db_settings_database_file'] = 'Dateiname der Datenbank';
$txt['db_settings_database_file_info'] = 'Dies ist der Dateiname, in welchen die ElkArte-Daten gespeichert werden. Wir empfehlen, einen zufällig ausgewählten Namen zu benutzen und den Pfad der Datei auf einen nicht öffentlichen Bereichs deines Servers einzustellen.';
$txt['db_settings_prefix'] = 'Tabellenpräfix';
$txt['db_settings_prefix_info'] = 'Das Präfix (Vorsilbe) für jede Tabelle in der Datenbank. <strong>Installiere nie zwei Foren mit dem gleichen Präfix!</strong><br />Diese Option erlaubt mehrere Installationen des SMF in einer einzigen Datenbank.';
$txt['db_populate'] = 'Datenbank wurde initialisiert';
$txt['db_populate_info'] = 'Deine Einstellungen wurden nun gespeichert und deine Datenbank mit den nötigen Werten initialisiert, um dein Forum funktionstüchtig zu machen. Zusammenfassung der Initialisierung:';
$txt['db_populate_info2'] = 'Klicke "Fortfahren", um mit dem nächsten Schritt fortzufahren.';
$txt['db_populate_inserts'] = '%1$d Zeilen eingefügt.';
$txt['db_populate_tables'] = '%1$d Tabellen erstellt.';
$txt['db_populate_insert_dups'] = '%1$d doppelte Einträge ignoriert.';
$txt['db_populate_table_dups'] = '%1$d doppelte Tabellen ignoriert.';

$txt['user_settings'] = 'Benutzerkonto erstellen';
$txt['user_settings_info'] = 'Die Installation wird nun ein Administrator-Benutzerkonto für dich erstellen.';
$txt['user_settings_username'] = 'Dien Benutzername';
$txt['user_settings_username_info'] = 'Trage hier den Namen ein, mit dem du dich später einloggen möchtest.<br />Dieser Name kann - im Gegensatz zum angezeigten Namen - später nicht mehr geändert werden!';
$txt['user_settings_password'] = 'Passwort';
$txt['user_settings_password_info'] = 'Trage hier das gewünschte Passwort ein und behalte es gut im Kopf!';
$txt['user_settings_again'] = 'Passwort';
$txt['user_settings_again_info'] = '(Bestätigung.)';
$txt['user_settings_email'] = 'E-Mail-Adresse';
$txt['user_settings_email_info'] = 'Trage hier deine E-Mail-Adresse ein. <strong>Es muss eine gültige E-Mail-Adresse sein.</strong>';
$txt['user_settings_database'] = 'MySQL-Datenbank-Passwort';
$txt['user_settings_database_info'] = 'Das Installationsskript erfordert aus Sicherheitsgründen ein gültiges Datenbank-Passwort, um dein Administrator-Benutzerkonto erstellen zu können.';
$txt['user_settings_skip'] = 'Überspringen';
$txt['user_settings_skip_sure'] = 'Bist du sicher, dass du die Erstellung des Administrator-Benutzerkontos überspringen möchtest?';
$txt['user_settings_proceed'] = 'Fertig';

$txt['ftp_checking_writable'] = 'Überprüfung auf beschreibbare Dateien';
$txt['ftp_setup'] = 'FTP-Verbindungsinformationen';
$txt['ftp_setup_info'] = 'Die Installation kann via FTP zum Server verbinden und die Dateien überschreibbar machen, wenn die Installation dies erfordern. Sollte dies nicht funktionieren, musst du dies manuell machen. Bitte beachte, dass der SSL-Übertragungsmodus im Moment nicht unterstützt wird.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'Trage hier den Server und den Port für den FTP-Transfer ein.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'Benutzername';
$txt['ftp_username_info'] = 'Der Benutzername zum Einloggen. <em>Er wird nicht gespeichert.</em>';
$txt['ftp_password'] = 'Passwort';
$txt['ftp_password_info'] = 'Das Passwort zum Einloggen. <em>Es wird nicht gespeichert.</em>';
$txt['ftp_path'] = 'Installationspfad';
$txt['ftp_path_info'] = 'Der <em>relative</em> Pfad, den du auf dem FTP-Server benutzt.';
$txt['ftp_path_found_info'] = 'Der Pfad im obigen Textfeld wurde automatisch ausgelesen.';
$txt['ftp_connect'] = 'Verbinden';
$txt['ftp_setup_why'] = 'Was bewirkt dieser Schritt?';
$txt['ftp_setup_why_info'] = 'Einige Dateien müssen überschreibbar sein, damit ElkArte korrekt funktioniert. Dieser Schritt ermöglicht der Installation, dies selbst zu ändern. In manchen Fällen kann es vorkommen, dass dies nicht funktioniert - Ändere dann bitte bei folgenden Dateien das Attribut mittels CHMOD auf 777 (beschreibbar, 755 auf einigen Servern)';
$txt['ftp_setup_again'] = 'Erneut testen, ob die Dateien überschreibbar sind.';

$txt['error_php_too_low'] = 'Warnung - Der Server scheint mit einer PHP-Version zu laufen, welche nicht den <strong>minimalen Anforderungen</strong> von ElkArte entspricht.<br />Wenn du den Server nicht selbst betreibst, solltest du deinen Hoster fragen, ob er die Version aktualisiert, einen anderen Anbieter wählen oder sie selbst aktualisieren, wenn du der Betreiber bist.<br /><br />Solltest du sicher sein, dass die PHP-Version aktuell genug ist, kannst du fortfahren, was jedoch nicht empfehlenswert ist.';
$txt['error_missing_files'] = 'Die Installationsdateien konnten nicht im Verzeichnis des Skriptes gefunden werden!<br /><br />Bitten vergewissere Dich, dass du alle Dateien, inklusive der ".sql"-Datei, hochgeladen hast, und versuche es erneut.';
$txt['error_session_save_path'] = 'Bitte informiere deinen Hoster, dass der <strong>"session.save_path" der Datei "php.ini"</strong> ungültig ist! Der Pfad sollte auf ein Verzeichnis verweisen, welches <strong>existiert</strong> und vom Benutzer <strong>beschreibbar</strong> ist.<br />';
$txt['error_windows_chmod'] = 'Du benutzt einen Windows-Server und einige Dateien sind nicht überschreibbar. Frage deinen Hoster nach <strong>Schreibberechtigungen</strong> für die Dateien deiner SMF-Installation. Die folgenden Dateien müssen überschreibbar sein:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Die Verbindung zum FTP-Server ist mit den aktuellen Daten nicht möglich.';
$txt['error_db_file'] = 'Das Datenbankskript kann nicht gefunden werden! Bitte prüfe, ob sich die Datei "%1$s" im Stammverzeichnis des Forums befindet.';
$txt['error_db_connect'] = 'Die Verbindung zum Datenbankserver kann mit den eingegebenen Daten nicht aufgebaut werden.<br /><br />Wenn du nicht sicher bist, welche Daten du eingeben musst, kontaktiere deinen Hoster.';
$txt['error_db_too_low'] = 'Die Version deiner Datenbank ist zu alt und stimmt nicht mit den minimalen Anforderungen von ElkArte überein.<br /><br />Bitte frage deinen Hoster nach einer Aktualisierung der Datenbank oder versuche einen anderen Anbieter.';
$txt['error_db_database'] = 'Das Installationsprogramm konnte nicht auf die Datenbank "<em>%1$s</em>" zugreifen. Bei manchen Hostern musst du die Datenbank zuerst im Administratorbereich erstellen, bevor du diese nutzen kannst. Andere Hoster fügen auch einen Präfix - z.B. Deinen Benutzernamen - zu dem Datenbanknamen hinzu.';
$txt['error_db_queries'] = 'Manche der Anfragen konnten nicht vollständig ausgeführt werden. Dies kann durch eine nicht unterstützte Version der Datenbanksoftware (Entwicklerversion, oder einfach zu alt) kommen. <br /><br />Weitere Informationen zu den Abfragen:';
$txt['error_db_queries_line'] = 'Zeile #';
$txt['error_db_missing'] = 'Das Installationsprogramm konnte keine Datenbankunterstützung in deiner PHP-Umgebung finden. Bitte frage deinen Hoster, ob PHP richtig kompiliert bzw. die richtige Erweiterung geladen ist. ElkArte unterstützt folgende Erweiterungen: %1$s';
$txt['error_db_script_missing'] = 'Das Installationsskript konnte keine Installationsskriptdateien für den gewählten Datenbanktyp finden. Bitte prüfe, dass alle benötigten Installationsskriptdateien in das Forumverzeichnis hochgeladen wurden, z.B. "%1$s"';
$txt['error_session_missing'] = 'Das Installationsprogramm konnte die Unterstützung für Sitzungen in deiner PHP-Umgebung nicht ermitteln. Bitte frage deinen Hoster, um sicher zu gehen, dass PHP mit der Unterstützung für Sitzungen kompiliert wurde (andererseits sollte es explizit ohne die Unterstützung erstellt werden).'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Du hast zwei verschiedene Passwörter eingegeben!';
$txt['error_user_settings_no_password'] = 'Dein Passwort muss mind. vier Buchstaben enthalten.';
$txt['error_user_settings_taken'] = 'Ein anderer Benutzer hat sich schon mit diesem Benutzernamen bzw. Passwort registriert.<br /><br />Ein neues Benutzerkonto wurde daher nicht erstellt.';
$txt['error_user_settings_query'] = 'Ein Datenbankfehler ist beim Erstellen des Administrator-Benutzerkontos aufgetreten. Der Fehler lautet:';
$txt['error_subs_missing'] = 'Es ist nicht möglich, die Datei /Sources/Subs.php zu finden. Bitte vergewissere Dich, dass du diese hochgeladen hast und versuche es dann erneut.';
$txt['error_db_alter_priv'] = 'Der Datenbankzugang, den du angegeben hast, hat keine Berechtigung zum Ändern, Erstellen oder Löschen von Tabellen in der Datenbank. Das ist jedoch für eine reibungslose Funktion von ElkArte erforderlich.';
$txt['error_versions_do_not_match'] = 'Das Installationsprogramm hat eine andere Version von ElkArte gefunden. Wenn du das bestehende Forum nur aktualisieren möchtest, solltest du das Update- oder Upgrade-Paket benutzen, nicht das normale Installationsprogramm.<br /><br />Du kannst auch andere Daten benutzen, um ein weitere ElkArte-Instanz zu installieren, oder ein Backup erstellen und die vorhandenen Daten dann in der Datenbank löschen.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'Die Version der Datenbank ist zu alt und unterstützt keinen UTF-8 Zeichensatz. ElkArte kann nicht installiert werden.';
$txt['error_valid_email_needed'] = 'Du hast keine gültige E-Mail-Adresse eingegeben.';
$txt['error_already_installed'] = 'Das Installationsprogramm hat erkannt, dass du ElkArte bereits installiert hast. Es wird empfohlen, dass du die vorhandene Installation <strong>nicht</strong> überschreibst! Solltest du fortfahren, <strong>kann dies zum Verlust von momentan existierenden Daten führen</strong>.<br /><br />Solltest du dein Forum aktualisieren wollen, besuche bitte die<a href="http://www.elkarte.net/">ElkArte Community Website</a> und lade dir das neueste <em>Upgrade</em>-Paket herunter.<br /><br />Möchtest du die momentan vorhandene Installation inklusive aller Daten trotzdem überschreiben, lösche vorher alle Datenbanktabellen, ersetze die Datei "Settings.php" und versuche es dann erneut.';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Warnung!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Du musst einen Namen für die SQLite-Datenbank-Datei angeben.';
$txt['error_db_prefix_numeric'] = 'Der gewählte Datenbanktyp unterstützt keine numerischen Präfixe.';
$txt['error_invalid_characters_username'] = 'Ungültiges Zeichen in Benutzername';
$txt['error_username_too_long'] = 'Benutzername darf maximal 25 Zeichen lang sein.';
$txt['error_username_left_empty'] = 'Das Benutzernamensfeld wurde leer gelassen.';
$txt['error_db_filename_exists'] = 'Die Datenbank, die du zu erstellen versuchst, existiert bereits. Bitte lösche die aktuelle Datenbank oder wähle eine anderen Datenbank.';
$txt['error_db_prefix_reserved'] = 'Das Präfix, dass du eingegeben hast, ist reserviert. Bitte gebe ein anderes ein.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade-Utility';
$txt['upgrade_warning'] = 'Warnung!';
$txt['upgrade_critical_error'] = 'Kritischer Fehler!';
$txt['upgrade_continue'] = 'Weiter';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Überspringen';
$txt['upgrade_note'] = 'Hinweis!';
$txt['upgrade_step'] = 'Schritt';
$txt['upgrade_steps'] = 'Schritte';
$txt['upgrade_progress'] = 'Fortschritt';
$txt['upgrade_overall_progress'] = 'Gesamt-Fortschritt';
$txt['upgrade_step_progress'] = 'Schritt-Fortschritt';
$txt['upgrade_time_elapsed'] = 'Zeit verstrichen';
$txt['upgrade_time_mins'] = 'Minuten';
$txt['upgrade_time_secs'] = 'Sekunden';

$txt['upgrade_incomplete'] = 'Unvollständig';
$txt['upgrade_not_quite_done'] = 'Noch nicht ganz fertig!';
$txt['upgrade_paused_overload'] = 'Diese Aktualisierung wurde pausiert, um eine Überbeanspruchung des Servers zu vermeiden. Keine Sorge, es passiert nichts - Klicke einfach den <label for="contbutt">\'Fortfahren\'-Button</label>, um fortzufahren.';

$txt['upgrade_ready_proceed'] = 'Danke, dass du dich entschieden hast, auf ElkArte %1$s zu aktualisieren. Alle Dateien scheinen am richtigen Ort zu sein und wir sind bereit.';

$txt['upgrade_error_script_js'] = 'Das Aktualisierungsskript kann die Datei "script.js" nicht finden oder sie existiert in einer älteren Version. Stelle sicher, dass die Theme-Pfade korrekt sind. Du kannst ein Dienstprogramm zum Prüfen der Einstellungen von der <a href="https://github.com/elkarte/tools/downloads">ElkArte tools</a> herunterladen.';

$txt['upgrade_warning_lots_data'] = 'Dieses Aktualisierungsskript hat festgestellt, dass viele der Daten deines Forums einer Aktualisierung bedürfen. Dieser Prozess kann einige Zeit in Anspruch nehmen, je nach Größe deiner Datenbank und des Forums. Für sehr große Foren (mit mehr als 300.000 Beiträgen) kann dies bis zu einigen Stunden dauern.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';