<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Antworten';
$txt['post_in_board'] = 'In diesem Board schreiben';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Zitat einfügen';
$txt['disable_smileys'] = 'Smileys deaktivieren';
$txt['dont_use_smileys'] = 'Keine Smileys benutzen';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Geschrieben am';
$txt['standard'] = 'Standard';
$txt['thumbs_up'] = 'Daumen hoch';
$txt['thumbs_down'] = 'Daumen runter';
$txt['exclamation_point'] = 'Ausrufezeichen';
$txt['question_mark'] = 'Fragezeichen';
$txt['icon_poll'] = 'Umfrage';
$txt['lamp'] = 'Lampe';
$txt['add_smileys'] = 'Smiley hinzufügen';
$txt['topic_notify_no'] = 'Es sind keine Themen mit Benachrichtigung vorhanden.';

$txt['rich_edit_wont_work'] = 'Dein Browser unterstützt das Editieren mit Rich-Text-Format nicht.';
$txt['rich_edit_function_disabled'] = 'Dein Browser unterstützt diese Funktion nicht.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Klicke hier, um das Thema abzubestellen';

$txt['lock_after_post'] = 'Thema sofort schließen';
$txt['notify_replies'] = 'Bei neuen Antworten benachrichtigen';
$txt['lock_topic'] = 'Thema schließen';
$txt['shortcuts'] = 'Tastenkürzel: Umschalt+Alt+S zum Schreiben, Umschalt+Alt+P für die Vorschau.';
$txt['shortcuts_drafts'] = 'Tastenkürzel: Umschalt+Alt+S zum Schreiben, Umschalt+Alt+P für die Vorschau, Umschalt+Alt+D zum Speichern.';
$txt['option'] = 'Antwort';
$txt['reset_votes'] = 'Abstimmungsergebnisse löschen';
$txt['reset_votes_check'] = 'Checkbox auswählen, um sämtliche Stimmen zurückzusetzen.';
$txt['votes'] = 'Stimmen';
$txt['attach'] = 'Datei anhängen';
$txt['clean_attach'] = 'Anhang löschen';
$txt['attached'] = 'Datei angehängt'; // @deprecated since 1.1
$txt['allowed_types'] = 'Erlaubte Dateitypen';
$txt['cant_upload_type'] = 'Die Datei kann nicht angehängt werden. Die folgenden Dateiendungen sind erlaubt: %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Deaktiviere die Dateianhänge, die gelöscht werden sollen'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Dieser Dateiname ist gesperrt. Bitte benutze einen anderen.';
$txt['topic_locked_no_reply'] = 'Warnung: Das Thema ist zur Zeit gesperrt. <br /> Nur Administratoren und Moderatoren können antworten.';
$txt['attachment_requires_approval'] = 'Bitte beachte, dass keine Datei ohne Genehmigung eines Moderators angehängt wird.';
$txt['error_temp_attachments'] = 'Es wurden Dateianhänge gefunden, die du angefügt, aber nicht abgesendet hast. Diese Anhänge werden nun an diesen Beitrag angehängt. Wenn du nicht möchtest, dass sie diesem Beitrag angefügt werden, kannst du die Anhänge <a href="#postAttachment">hier< a> vom Beitrag entfernen.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Erinnerung: Dieser Beitrag wird nicht angezeigt, bevor er nicht durch einen Moderator genehmigt wurde.';

$txt['enter_comment'] = 'Kommentar eingeben';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Gemeldeter Beitrag';
$txt['reported_to_mod_by'] = 'von';
$txt['rtm10'] = 'Senden';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Der folgende Beitrag, \'%1$s\' von';
$txt['reported_by'] = 'wurde gemeldet von';
$txt['board_moderate'] = 'in einem von dir moderierten Board.';
$txt['report_comment'] = 'Der Einsender hat folgende Bemerkung dazu geschrieben';

$txt['attach_drop_files'] = 'Dateien durch Drag&Drop hinzufügen oder <a class="drop_area_fileselect_text" href="#">hier klicken</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximale Gesamtgröße %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximale Individualgröße %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d pro Antwort';
$txt['attach_restrictions'] = 'Einschränkungen:';

$txt['post_additionalopt_attach'] = 'Anhänge und andere Optionen';
$txt['post_additionalopt'] = 'andere Optionen';
$txt['sticky_after'] = 'Thema fixieren';
$txt['move_after2'] = 'Thema verschieben';
$txt['back_to_topic'] = 'Zum Thema zurückkehren';
$txt['approve_this_post'] = 'Beitrag genehmigen';

$txt['retrieving_quote'] = 'Zitat laden...';

$txt['post_visual_verification_label'] = 'Verifizierung';
$txt['post_visual_verification_desc'] = 'Bitte gebe den Code aus dem Bild ein, um den Beitrag zu erstellen.';

$txt['poll_options'] = 'Umfrageoptionen';
$txt['poll_run'] = 'Umfrage öffnen für';
$txt['poll_run_limit'] = '(leer = kein Limit)';
$txt['poll_results_visibility'] = 'Sichtbarkeit des Ergebnisses';
$txt['poll_results_anyone'] = 'Ergebnisse jedem anzeigen';
$txt['poll_results_voted'] = 'Ergebnisse nur nach Abstimmung anzeigen';
$txt['poll_results_after'] = 'Zeige die Ergebnisse erst dann, wenn die Umfrage abgelaufen ist.';
$txt['poll_max_votes'] = 'Max. Stimmen pro Benutzer';
$txt['poll_do_change_vote'] = 'Benutzer dürfen die Abstimmung verändern';
$txt['poll_too_many_votes'] = 'Du hast zu viele Stimmen abgegeben - Max. sind %1$s erlaubt.';
$txt['poll_add_option'] = 'Antwort hinzufügen';
$txt['poll_guest_vote'] = 'Gäste dürfen abstimmen';

$txt['spellcheck_done'] = 'Die Rechtschreibprüfung ist fertig.';
$txt['spellcheck_change_to'] = 'Ändern zu:';
$txt['spellcheck_suggest'] = 'Vorschläge:';
$txt['spellcheck_change'] = 'Ändern';
$txt['spellcheck_change_all'] = 'Alle ändern';
$txt['spellcheck_ignore'] = 'Ignorieren';
$txt['spellcheck_ignore_all'] = 'Alle ignorieren';

$txt['more_attachments'] = 'Weitere Dateianhänge';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Du darfst keine weiteren Dateianhänge hinzufügen.';

$txt['more_smileys'] = 'Weitere Smileys...';
$txt['more_smileys_title'] = 'Weitere Smileys';
$txt['more_smileys_pick'] = 'Wähle einen Smiley';
$txt['more_smileys_close_window'] = 'Fenster schließen';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = 'Sende eine Ankündigung über dieses Thema an die Benutzer:';
$txt['announce_title'] = 'Ankündigung senden';
$txt['announce_desc'] = 'Dieses Formular erlaubt dir das Senden einer Ankündigung über dieses Thema an die ausgewählten Benutzergruppen.';
$txt['announce_sending'] = 'Sende Ankündigung des Themas';
$txt['announce_done'] = 'Fertig';
$txt['announce_continue'] = 'Weiter';
$txt['announce_topic'] = 'Ankündigungsthema';
$txt['announce_regular_members'] = 'Normale Benutzer';

$txt['digest_subject_daily'] = 'Tägliche Übersicht';
$txt['digest_subject_weekly'] = 'Wöchentliche Übersicht';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'Die folgenden Themen wurden gestartet';
$txt['digest_new_topics_line'] = '"%1$s" im %2$s Forum';
$txt['digest_new_replies'] = 'Neue Antworten wurden in den folgenden Themen geschrieben';
$txt['digest_new_replies_one'] = '1 Antwort in "%1$s"';
$txt['digest_new_replies_many'] = '%1$d Antworten in "%2$s"';
$txt['digest_mod_actions'] = 'Die folgenden Moderator-Aktionen wurden durchgeführt';
$txt['digest_mod_act_sticky'] = '"%1$s" wurde fixiert';
$txt['digest_mod_act_lock'] = '\'%1$s\' wurde geschlossen';
$txt['digest_mod_act_unlock'] = '"%1$s" wurde wieder geöffnet';
$txt['digest_mod_act_remove'] = '"%1$s" wurde gelöscht';
$txt['digest_mod_act_move'] = '"%1$s" wurde verschoben';
$txt['digest_mod_act_merge'] = '"%1$s" wurde zusammengeführt';
$txt['digest_mod_act_split'] = '"%1$s" wurde geteilt';

$txt['attach_error_title'] = 'Fehler beim Upload der Dateianhänge.';
$txt['attach_warning'] = 'Es gab ein Problem während des Hochladens von <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Entschuldige, aber du hast die max. Größe für Dateianhänge überschritten. Die Dateianhänge dürfen insgesamt %1$s KB haben. Übrig sind %2$s KB.';
$txt['attach_folder_warning'] = 'Das Upload-Verzeichnis kann nicht gefunden werden. Bitte versuche es mit einer kleineren Datei oder kontaktiere den Administrator.';
$txt['attach_folder_admin_warning'] = 'Der Pfad zum Dateianhangsverzeichnis (%1$s) ist fehlerhaft. Bitte korrigiere das in den Einstellungen im Admin-Center.';
$txt['attach_limit_nag'] = 'Du hast die max. Anzahl an Dateianhängen pro Beitrag erreicht.';
$txt['attach_no_upload'] = 'Es gab ein Problem, die Anhänge konnte nicht hochgeladen werden';
$txt['attach_remaining'] = '%1$d verbleibend';
$txt['attach_available'] = '%1$s KB verfügbar';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'Die Datei scheint leer zu sein. Bitte kontaktiere einen Administrator, wenn der Fehler weiterhin besteht.';
$txt['attached_files_in_session'] = '<em>Die oben genannten Datei(en) wurden hochgeladen, werden aber erst angefügt, wenn der Beitrag übermittelt wird</em>';

$txt['attach_php_error'] = 'Wegen eines Fehlers konnte der Dateianhang nicht hochgeladen werden. Bitte kontaktiere einen Administrator, wenn das Problem weiterhin besteht.';
$txt['php_upload_error_1'] = 'Die hochgeladene Datei überschreitet die Einstellung upload_max_fileszize der php.ini. Bitte kontaktiere einen Administrator, wenn das Problem weiterhin besteht.';
$txt['php_upload_error_3'] = 'Die Hochgeladene Datei wurde nicht vollständig übertragen. Das ist ein PHP-spezifischer Fehler. Bitte kontaktiere den Server-Betreiber, wenn der Fehler weiterhin besteht.';
$txt['php_upload_error_4'] = 'Es wurde keine Datei übertragen. Das ist ein PHP-spezifischer Fehler. Bitte kontaktiere den Server-Betreiber, wenn der Fehler weiterhin besteht.';
$txt['php_upload_error_6'] = 'Die Hochgeladene Datei konnte nicht gepeichert werden. Das temporäre Verzeichnis fehlt. Das ist ein PHP-spezifischer Fehler. Bitte korrigiere den Fehler oder kontaktiere den Server-Betreiber, wenn der Fehler weiterhin besteht.';
$txt['php_upload_error_7'] = 'Datei konnte nicht auf das Dateisystem geschrieben werden. Das ist ein PHP-spezifischer Fehler. Bitte kontaktiere den Server-Betreiber, wenn der Fehler weiterhin besteht.';
$txt['php_upload_error_8'] = 'Eine PHP-Erweiterung hat verhindert, dass die Datei hochgeladen werden konnte. Das ist ein PHP-spezifischer Fehler. Bitte kontaktiere den Server-Betreiber, wenn der Fehler weiterhin besteht.';
$txt['error_temp_attachments_new'] = 'Es wurden Dateianhänge gefunden, die du angefügt, aber nicht abgesendet hast. Diese Anhänge werden nun an diesen Beitrag angehängt. Wenn du nicht möchtest, dass sie diesem Beitrag angefügt werden, kannst du die Anhänge <a href="#postAttachment">hier< a> vom Beitrag entfernen.';
$txt['error_temp_attachments_found'] = 'Es wurden Dateianhänge gefunden, die du angefügt, aber nicht abgesendet hast. Diese Anhänge werden nun an diesen Beitrag angehängt. .<br /><a href="%1$s">Bitte hier klicken</a>, um diese zu entfernen oder <a href="%2$s">zum Beitrag zurückkehren</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'Die folgenden Dateianhänge wurden gefunden und gehören zu einem vorherigen Beitrag, der aber nicht fertig gestellt wurde. Es wird empfohlen, keine weiteren Dateianhänge hochzuladen, bevor diese hier entweder gelöscht wurden oder der Beitrag fertig gestellt wurde. <br /><a href="%1$s">Bitte hier klicken, um die Anhänge zu entfernen</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Die Anhänge wurden entfernt und du wurdest zurück auf die vorherige Seite geleitet.';
$txt['error_temp_attachments_flushed'] = 'Bitte beachte, dass alle alten Dateianhänge, die bisher hochgeladen, aber noch nicht veröffentlich wurden, gelöscht wurden.';
$txt['error_topic_already_announced'] = 'Achtung, das Thema wurde bereits als Ankündigung benutzt.';

$txt['cant_access_upload_path'] = 'Es kann auf den Upload-Pfad der Dateianhänge nicht zugegriffen werden.';
$txt['file_too_big'] = 'Die Datei ist zu groß. Das Maximum für Dateianlagen ist %1$s KB.';
$txt['attach_timeout'] = 'Fehler beim Speichern der Datei, bitte versuche es noch einmal.';
$txt['bad_attachment'] = 'Der Anhang verstößt gegen sicherheitsrelevante Einstellungen. Bitte kontaktiere den Administrator.';
$txt['ran_out_of_space'] = 'Das Upload-Verzeichnis ist voll. Bitte versuche es mit einer kleineren Datei oder kontaktiere den Administrator.';
$txt['attachments_no_write'] = 'Das Dateianhangsverzeichnis ist nicht beschreibbar. Dein Dateianhang oder Avatar kann nicht gespeichert werden!';
$txt['attachments_no_create'] = 'Das Dateianhangsverzeichnis ist nicht beschreibbar. Dein Dateianhang oder Avatar kann nicht gespeichert werden!';
$txt['attachments_limit_per_post'] = 'Du kannst nicht mehr als %1$d Anhänge zum Beitrag hinzufügen';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Einfügen';
$txt['ila_opt_size'] = 'Größe';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Keine';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Zentriert';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/