<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Entschuldige, aber der Zugriff auf diese Seite ist nicht möglich. Bitte von der Startseite aus navigieren.';
$txt['not_guests'] = 'Entschuldige, aber dieser Bereich ist für Gäste nicht verfügbar.';

$txt['mods_only'] = 'Nur Moderatoren können die direkte Löschfunktion benutzen, bitte lösche diesen Eintrag mit der \'Editieren\'-Funktion.';
$txt['no_name'] = 'Du hast das Feld für den Benutzernamen nicht ausgefüllt. Ohne Benutzernamen funktioniert hier leider gar nichts.';
$txt['no_email'] = 'Du hast das erforderliche Feld für die E-Mail-Adresse nicht ausgefüllt.';
$txt['topic_locked'] = 'Das Thema ist geschlossen. Änderungen oder neue Einträge sind nicht erlaubt.';
$txt['no_password'] = 'Du hast das Passwortfeld nicht ausgefüllt.';
$txt['passwords_dont_match'] = 'Die Passwörter stimmen nicht überein.';
$txt['register_to_use'] = 'Du musst dich zuerst registrieren, bevor du diese Funktion nutzen kannst.';
$txt['username_reserved'] = 'Der Benutzername, den du registrieren möchtest, enthält einen reservierten Namen. Bitte versuche einen anderen Namen. Reservierte Namen sind: %1$s.';
$txt['numbers_one_to_nine'] = 'Dieses Feld akzeptiert nur Zahlen von 0 bis 9.';
$txt['not_a_user'] = 'Der Benutzer, dessen Profil du anschauen möchtest, existiert nicht mehr.';
$txt['not_a_topic'] = 'Dieses Thema ist im Forum nicht mehr vorhanden.';
$txt['not_approved_topic'] = 'Dieser Beitrag wurde noch nicht genehmigt.';
$txt['email_in_use'] = 'Diese E-Mail-Adresse (%1$s) wird schon von einem registrierten Benutzer verwendet. Solltest du das für einen Fehler halten, gehe auf die Login-Seite und benutze die Funktion \'Passworterinnerung\' mit dieser Adresse.';

$txt['didnt_select_vote'] = 'Keine Umfrageoption ausgewählt.';
$txt['poll_error'] = 'Die Umfrage ist nicht vorhanden, bereits geschlossen, oder du hast versucht, zweimal abzustimmen, und das ist nicht erlaubt.';
$txt['locked_by_admin'] = 'Dieses Thema wurde von einem Administrator geschlossen. Du kannst es nicht öffnen.';
$txt['not_enough_posts_karma'] = 'Du hast zu wenige Beiträge, um das Karma zu ändern. Du brauchst mind. %1$d Beiträge.';
$txt['cant_change_own_karma'] = 'Du darfst dein eigenes Karma nicht ändern.';
$txt['karma_wait_time'] = 'Du kannst diese Aktion nicht erneut ausführen, ohne %1$s %2$s zu warten.';
$txt['feature_disabled'] = 'Diese Funktion ist deaktiviert.';
$txt['feature_no_exists'] = 'Entschuldige, aber diese Funktion existiert nicht.';
$txt['couldnt_connect'] = 'Es konnte keine Verbindung zum Server hergestellt werden oder die Datei ist nicht vorhanden.';
$txt['no_board'] = 'Das angegebene Board existiert nicht.';
$txt['no_message'] = 'Der Beitrag ist nicht länger verfügbar';
$txt['no_topic_id'] = 'Ungültige Themen-ID.';
$txt['split_first_post'] = 'Du kannst ein Thema nicht beim ersten Beitrag teilen.';
$txt['topic_one_post'] = 'Themen mit nur einem Beitrag können nicht geteilt werden.';
$txt['no_posts_selected'] = 'Es wurden keine Beiträge ausgewählt.';
$txt['selected_all_posts'] = 'Teilen nicht möglich, da du alle Beiträge ausgewählt hast.';
$txt['cant_find_messages'] = 'Beiträge konnten nicht gefunden werden.';
$txt['cant_find_user_email'] = 'Die E-Mail-Adresse konnte nicht gefunden werden.';
$txt['cant_insert_topic'] = 'Kann das Thema nicht einfügen.';
$txt['session_timeout'] = 'Deine Sitzung ist während des Schreibens abgelaufen. Bitte gehe einen Schritt zurück und versuche es erneut.';
$txt['session_timeout_file_upload'] = 'Deine Sitzung ist während des Dateiuploads abgelaufen. Bitte versuche es noch erneut.';
$txt['no_files_uploaded'] = 'Keinen Dateien für den Upload gefunden.';
$txt['session_verify_fail'] = 'Kann deine Session nicht verifizieren. Bitte melde dich zunächst ab, melde dich dann wieder an und versuche es dann erneut.';
$txt['verify_url_fail'] = 'Unable to verify referring URL: %1$s. Please go back and try again.';
$txt['token_verify_fail'] = 'Token-Validierung fehlgeschlagen. Bitte gehe einen Schritt zurück und versuche es erneut.';
$txt['guest_vote_disabled'] = 'Gäste können in dieser Umfrage nicht abstimmen.';

$txt['cannot_access_mod_center'] = 'Du besitzt nicht die nötige Berechtigung, auf das Moderations-Center zuzugreifen.';
$txt['cannot_admin_forum'] = 'Du hast keine Administrator-Rechte.';
$txt['cannot_announce_topic'] = 'Du besitzt nicht die nötige Berechtigung, in diesem Board Themen anzukündigen.';
$txt['cannot_approve_posts'] = 'Du besitzt nicht die nötige Berechtigung, Genehmigungen zu erteilen.';
$txt['cannot_post_unapproved_attachments'] = 'Du besitzt nicht die nötige Berechtigung, nicht genehmigte Dateianhänge zu erstellen.';
$txt['cannot_post_unapproved_topics'] = 'Du besitzt nicht die nötige Berechtigung, nicht genehmigte Themen zu erstellen.';
$txt['cannot_post_unapproved_replies_own'] = 'Du besitzt nicht die nötige Berechtigung, nicht genehmigte Antworten zu deinen Themen zu schreiben.';
$txt['cannot_post_unapproved_replies_any'] = 'Du besitzt nicht die nötige Berechtigung, nicht genehmigte Antworten zu Themen anderer Benutzer zu schreiben.';
$txt['cannot_calendar_edit_any'] = 'Du besitzt nicht die nötige Berechtigung, Kalenderereignisse zu editieren.';
$txt['cannot_calendar_edit_own'] = 'Du besitzt nicht die nötige Berechtigung, deine eigenen Kalenderereignisse zu editieren.';
$txt['cannot_calendar_post'] = 'Du besitzt nicht die nötige Berechtigung, neue Kalenderereignisse zu erstellen.';
$txt['cannot_calendar_view'] = 'Du besitzt nicht die nötige Berechtigung, den Kalender anzuschauen.';
$txt['cannot_remove_any'] = 'Du besitzt nicht die nötige Berechtigung, Beiträge anderer Benutzer zu löschen.';
$txt['cannot_remove_own'] = 'Du besitzt nicht die nötige Berechtigung, deine Beiträge in diesem Board zu löschen.';
$txt['cannot_edit_news'] = 'Du besitzt nicht die nötige Berechtigung, Neuigkeiten zu editieren.';
$txt['cannot_pm_read'] = 'Du besitzt nicht die nötige Berechtigung, deine Privaten Mitteilungen zu lesen.';
$txt['cannot_pm_send'] = 'Du besitzt nicht die nötige Berechtigung, Private Mitteilungen zu versenden.';
$txt['cannot_karma_edit'] = 'Du besitzt nicht die nötige Berechtigung, andere Benutzer zu bewerten.';
$txt['cannot_like_posts'] = 'Du besitzt nicht die nötige Berechtigung, um Beiträge in diesem Board mir Gefällt mir zu kennzeichnen.';
$txt['cannot_lock_any'] = 'Du besitzt nicht die nötige Berechtigung, Themen zu schließen.';
$txt['cannot_lock_own'] = 'Du besitzt nicht die nötige Berechtigung, deine eigenen Themen zu schließen.';
$txt['cannot_make_sticky'] = 'Du besitzt nicht die nötige Berechtigung, dieses Thema zu fixieren.';
$txt['cannot_manage_attachments'] = 'Du besitzt nicht die nötige Berechtigung, Dateien zu verwalten.';
$txt['cannot_manage_bans'] = 'Du besitzt nicht die nötige Berechtigung, die Bann-Liste zu editieren.';
$txt['cannot_manage_boards'] = 'Du besitzt nicht die nötige Berechtigung, Boards und Kategorien zu verwalten.';
$txt['cannot_manage_membergroups'] = 'Du besitzt nicht die nötige Berechtigung, Benutzergruppen zu verwalten.';
$txt['cannot_manage_permissions'] = 'Du besitzt nicht die nötige Berechtigung, die Berechtigungen zu verwalten.';
$txt['cannot_manage_smileys'] = 'Du besitzt nicht die nötige Berechtigung, Smileys oder Themen-Icons zu verwalten.';
$txt['cannot_mark_any_notify'] = 'Du besitzt nicht die nötige Berechtigung, Benachrichtigungen über dieses Thema zu empfangen.';
$txt['cannot_mark_notify'] = 'Du besitzt nicht die nötige Berechtigung, Benachrichtigungen über dieses Board zu empfangen.';
$txt['cannot_merge_any'] = 'Du besitzt nicht die nötige Berechtigung, Themen zusammenzuführen.';
$txt['cannot_moderate_forum'] = 'Du besitzt nicht die nötige Berechtigung, dieses Forum zu moderieren.';
$txt['cannot_moderate_board'] = 'Du besitzt nicht die nötige Berechtigung, dieses Board zu moderieren.';
$txt['cannot_modify_any'] = 'Du besitzt nicht die nötige Berechtigung, Beiträge anderer Benutzer zu editieren.';
$txt['cannot_modify_own'] = 'Du besitzt nicht die nötige Berechtigung, deine eigenen Beiträge zu editieren.';
$txt['cannot_modify_replies'] = 'Du besitzt nicht die nötige Berechtigung, diese Antwort zu editieren, obwohl es eine Antwort auf deinen Beitrag ist.';
$txt['cannot_move_own'] = 'Du besitzt nicht die nötige Berechtigung, deine Beiträge in dieses Board zu verschieben.';
$txt['cannot_move_any'] = 'Du besitzt nicht die nötige Berechtigung, in diesem Board Themen zu verschieben.';
$txt['cannot_poll_add_own'] = 'Du besitzt nicht die nötige Berechtigung, Umfragen zu deinen Beiträgen hinzuzufügen.';
$txt['cannot_poll_add_any'] = 'Du besitzt nicht die nötige Berechtigung, Umfragen zu diesem Thema hinzuzufügen.';
$txt['cannot_poll_edit_own'] = 'Du besitzt nicht die nötige Berechtigung, deine Umfrage zu editieren.';
$txt['cannot_poll_edit_any'] = 'Du besitzt nicht die nötige Berechtigung, Umfragen anderer Benutzer zu editieren.';
$txt['cannot_poll_lock_own'] = 'Du besitzt nicht die nötige Berechtigung, deine eigenen Umfragen zu schließen.';
$txt['cannot_poll_lock_any'] = 'Du besitzt nicht die nötige Berechtigung, Umfragen anderer Benutzer zu schließen.';
$txt['cannot_poll_post'] = 'Du besitzt nicht die nötige Berechtigung, Umfragen zu starten.';
$txt['cannot_poll_remove_own'] = 'Du besitzt nicht die nötige Berechtigung, die Umfrage von deinem Thema zu entfernen.';
$txt['cannot_poll_remove_any'] = 'Du besitzt nicht die nötige Berechtigung, in diesem Board Umfragen zu entfernen.';
$txt['cannot_poll_view'] = 'Du besitzt nicht die nötige Berechtigung, Umfragen anzuschauen.';
$txt['cannot_poll_vote'] = 'Du besitzt nicht die nötige Berechtigung, in Umfragen abzustimmen.';
$txt['cannot_post_attachment'] = 'Du besitzt nicht die nötige Berechtigung, Dateianhänge zu speichern.';
$txt['cannot_post_new'] = 'Du besitzt nicht die nötige Berechtigung, neue Themen zu erstellen.';
$txt['cannot_post_new_board'] = 'Entschuldige, aber du darfst im Board %1$s keinen Beitrag schreiben.';
$txt['cannot_post_reply_any'] = 'Du besitzt nicht die nötige Berechtigung, auf Beiträge anderer Benutzer zu antworten.';
$txt['cannot_post_reply_own'] = 'Du besitzt nicht die nötige Berechtigung, auf deine eigenen Beiträge zu antworten.';
$txt['cannot_profile_remove_own'] = 'Du besitzt nicht die nötige Berechtigung, dein eigenes Benutzerkonto zu löschen.';
$txt['cannot_profile_remove_any'] = 'Du besitzt nicht die nötige Berechtigung, um Benutzerkonten zu löschen.';
$txt['cannot_profile_extra_any'] = 'Du besitzt nicht die nötige Berechtigung, das Profil zu editieren.';
$txt['cannot_profile_identity_any'] = 'Du besitzt nicht die nötige Berechtigung, Kontoeinstellungen zu editieren.';
$txt['cannot_profile_title_any'] = 'Du besitzt nicht die nötige Berechtigung, die persönlichen Titel anderer Benutzer zu ändern.';
$txt['cannot_profile_extra_own'] = 'Du besitzt nicht die nötige Berechtigung, deine Profildaten zu editieren.';
$txt['cannot_profile_identity_own'] = 'Du besitzt nicht die nötige Berechtigung, deine Identität zu ändern.';
$txt['cannot_profile_title_own'] = 'Du besitzt nicht die nötige Berechtigung, deinen persönlichen Titel zu ändern.';
$txt['cannot_profile_set_avatar'] = 'Du darfst deinen Avatar nicht ändern.';
$txt['cannot_profile_view_own'] = 'Du besitzt nicht die nötige Berechtigung, dein Profil anzuschauen.';
$txt['cannot_profile_view_any'] = 'Du besitzt nicht die nötige Berechtigung, Profile anzuschauen.';
$txt['cannot_delete_own'] = 'Entschuldige, aber du darfst deine Beiträge in diesem Board nicht löschen.';
$txt['cannot_delete_replies'] = 'Du besitzt nicht die nötige Berechtigung, Beiträge zu löschen, obwohl es Antworten auf deinen Beitrag sind.';
$txt['cannot_delete_any'] = 'Entschuldige, aber du darfst in diesem Board keine Beiträge anderer Benutzer löschen.';
$txt['cannot_report_any'] = 'Du besitzt nicht die nötige Berechtigung, Beiträge zu melden.';
$txt['cannot_search_posts'] = 'Du besitzt nicht die nötige Berechtigung, in diesem Forum in Beiträgen zu suchen.';
$txt['cannot_send_mail'] = 'Du besitzt nicht die nötige Berechtigung, E-Mails an alle zu senden.';
$txt['cannot_issue_warning'] = 'Du besitzt nicht die nötige Berechtigung, Verwarnungen zu erteilen.';
$txt['cannot_send_topic'] = 'Du besitzt nicht die nötige Berechtigung, Themen zu senden.';
$txt['cannot_send_email_to_members'] = 'Du besitzt nicht die nötige Berechtigung, anderen Benutzern eine E-Mail zu senden.';
$txt['cannot_split_any'] = 'Du besitzt nicht die nötige Berechtigung, Themen anderer Benutzer zu teilen.';
$txt['cannot_view_attachments'] = 'Du besitzt nicht die nötige Berechtigung, Dateianhänge herunterzuladen oder anzusschauen.';
$txt['cannot_view_mlist'] = 'Du besitzt nicht die nötige Berechtigung, die Mitgliederliste anzuschauen.';
$txt['cannot_view_stats'] = 'Du besitzt nicht die nötige Berechtigung, die Statistiken des Forums anzuschauen.';
$txt['cannot_who_view'] = 'Du besitzt nicht die nötige Berechtigung, die Wer ist online-Liste anzuschauen.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = 'Das Theme kann nicht gefunden werden.';
$txt['theme_dir_wrong'] = 'Das Standard-Theme-Verzeichnis ist falsch. Bitte korrigiere es, indem du auf diesen Link klickst:';
$txt['registration_disabled'] = 'Die Registrierung ist momentan deaktiviert.';
$txt['registration_agreement_missing'] = 'Die Datei mit den Registrierungsbedingungen, Agreement.txt, ist entweder leer oder fehlt. Registrierungen sind deaktiviert, bis dieser Fehler korrigiert wurde.';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Es ist keine geheime Frage für diesen Benutzer gespeichert.';
$txt['poll_range_error'] = 'Die Umfrage muss für mehr als 0 Tage geöffnet sein.';
$txt['delFirstPost'] = 'Du darfst den ersten Beitrag eines Themas nicht löschen.<p>Wenn du dieses Thema löschen möchtest, klicke auf den "Thema löschen"-Button oder bitte einen Moderator bzw. Administrator, dies für dich zu tun.</p>';
$txt['login_cookie_error'] = 'Du kannst dich nicht einloggen. Bitte überprüfe deine Cookie-Einstellungen.';
$txt['incorrect_answer'] = 'Du hast die Frage nicht richtig beantwortet. Bitte gehe einen Schritt zurück und versuche es noch einmal oder gehe zwei Schritte zurück und lasse dir ein neues Passwort zuschicken.';
$txt['no_mods'] = 'Keine Moderatoren gefunden.';
$txt['parent_not_found'] = 'Die Boardstruktur scheint defekt und ein übergeordnetes Board kann nicht mehr gefunden werden. Bitte melde dies dem Administrator.';
$txt['modify_post_time_passed'] = 'Du kannst diesen Beitrag nicht editieren, da das Zeitlimit abgelaufen ist.';

$txt['calendar_off'] = 'Du kannst den Kalender nicht aufrufen, weil er deaktiviert ist.';
$txt['calendar_export_off'] = 'Du kannst den Kalender nicht aufrufen, weil er deaktiviert ist.';
$txt['invalid_month'] = 'Ungültiger Monatswert.';
$txt['invalid_year'] = 'Ungültiger Jahreswert.';
$txt['invalid_day'] = 'Ungültiger Tageswert.';
$txt['event_month_missing'] = 'Monatsangabe fehlt.';
$txt['event_year_missing'] = 'Jahresangabe fehlt.';
$txt['event_day_missing'] = 'Tagesangabe fehlt.';
$txt['event_title_missing'] = 'Ereignistitel fehlt.';
$txt['invalid_date'] = 'Ungültiges Datum.';
$txt['no_event_title'] = 'Der Ereignistitel wurde nicht angegeben.';
$txt['missing_board_id'] = 'Board-ID fehlt.';
$txt['missing_topic_id'] = 'Themen-ID fehlt.';
$txt['topic_doesnt_exist'] = 'Das Thema existiert nicht.';
$txt['not_your_topic'] = 'Du hast das Thema nicht erstellt.';
$txt['board_doesnt_exist'] = 'Das Board existiert nicht.';
$txt['no_span'] = 'Die Mehrere Tage-Funktion ist nicht aktiviert.';
$txt['invalid_days_numb'] = 'Die Anzahl der Tage ist ungültig.';

$txt['moveto_noboards'] = 'Es sind keine Boards vorhanden, in welche das Thema verschoben werden könnte.';
$txt['topic_already_moved'] = 'Das Thema %1$s wurde bereits in das Board %2$s verschoben.';

$txt['already_activated'] = 'Dein Benutzerkonto wurde schon aktiviert.';
$txt['still_awaiting_approval'] = 'Dein Benutzerkonto wartet noch auf die Genehmigung des Administrators.';

$txt['invalid_email'] = 'Ungültige E-Mail-Adresse bzw. E-Mail-Adressenbereich.<br />Beispiel einer gültigen E-Mail-Adresse: evil.user@badsite.com.<br />Beispiel eines gültigen E-Mail-Adressenbereiches: *@*.badsite.com';
$txt['invalid_expiration_date'] = 'Das Ablaufdatum ist ungültig';
$txt['invalid_hostname'] = 'Ungültiger Hostname bzw. Hostnamensbereich.<br />Beispiel eines gültigen Hostnamens: proxy4.badhost.com<br />Beispiel eines gültigen Hostnamensbereiches: *.badhost.com';
$txt['invalid_ip'] = 'Ungültige IP-Adresse bzw. IP-Bereich.<br />Beispiel einer gültigen IP-Adresse: 127.0.0.1<br />Beispiel eines gültigen IP-Bereiches: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Falsche IP-Adresse bzw. IP-Adressbereich. <br />Beispiel einer korrekten IP-Adresse: 127.0.0.1 <br />Beispiel eines korrekten IP-Adressbereiches: 127.0.0.*';
$txt['invalid_username'] = 'Benutzername nicht gefunden.';
$txt['no_user_selected'] = 'Benutzer nicht gefunden.';
$txt['no_ban_admin'] = 'Du kannst keinen Administrator bannen - du musst ihn erst degradieren.';
$txt['no_bantype_selected'] = 'Kein Bann-Typ ausgewählt.';
$txt['ban_not_found'] = 'Bann nicht gefunden.';
$txt['ban_unknown_restriction_type'] = 'Einschränkung nicht bekannt.';
$txt['ban_name_empty'] = 'Bitte gebe einen Namen für den Bann ein';
$txt['ban_id_empty'] = 'Entschuldige, aber die ID des Bans konnte nicht gefunden werden.';
$txt['ban_group_id_empty'] = 'Ein Bann benötigt eine Gruppen-ID, dieser Bann hat aber keine.';
$txt['ban_no_triggers'] = 'Hast du vergessen, einen Ban-Trigger auszuwählen? Es wird mindestens ein Trigger benötigt.';
$txt['ban_ban_item_empty'] = 'Ban-Trigger nicht gefunden,';
$txt['impossible_insert_new_bangroup'] = 'Ein unbekannter Fehler ist während des Erstellens des neuen Bann\'s aufgetreten.';

$txt['like_heading_error'] = 'Fehler in den Gefällt mir-Angaben';
$txt['like_wait_time'] = 'Du musst mindestens %1$s %2$s warten, bis du einen Beitrag erneut mit Gefällt mir kennzeichnen kannst.';
$txt['like_unlike_error'] = 'Es ist ein Fehler beim Markieren eines Beitrags mit Gefällt mir aufgetreten.';
$txt['cant_like_yourself'] = 'Deine eigenen Beiträge mit Gefällt mir markieren? Das ist so, als würde man über seine eigenen Witze lachen, weil niemand anderes in der Nähe ist...';

$txt['ban_name_exists'] = 'Der Name des Banns ("%1$s") existiert schon. Bitte wähle einen anderen Namen.';
$txt['ban_trigger_already_exists'] = 'Dieser Bann-Auslöser: ("%1$s") existiert bereits im Bann: "%2$s".';
$txt['attach_check_nag'] = 'Die Daten sind unvollständig ("%1$s")';

$txt['recycle_no_valid_board'] = 'Kein gültiges Board für wiederherzustellende Themen gewählt.';
$txt['post_already_deleted'] = 'Das Thema wurde bereits in den Papierkorb verschoben. Willst du es permanent löschen?<br />Falls ja, bitte <a href="%1$s">hier klicken.</a>.';

$txt['login_threshold_fail'] = 'Du hast alle Versuche aufgebraucht. Bitte versuche es später noch einmal.';
$txt['login_threshold_brute_fail'] = 'Du hast die maximale Anzahl an Login-Versuchen verbraucht. Bitte warte mindestens 30 Sekunden, bevor du es erneut versuchst.';

$txt['who_off'] = 'Entschuldige, aber diese Funktion wurde deaktiviert.';

$txt['merge_create_topic_failed'] = 'Entschuldige, aber das Erstellen eines neuen Themas ist fehlgeschlagen.';
$txt['merge_need_more_topics'] = 'Das Zusammenführen von Themen benötigt mind. zwei Themen.';

$txt['post_WaitTime_broken'] = 'Der letzte Beitrag deiner IP-Adresse ist weniger als %1$d Sekunden her. Bitte versuche es später noch einmal.';
$txt['register_WaitTime_broken'] = 'Du hast dich erst vor %1$d Sekunden registriert!';
$txt['login_WaitTime_broken'] = 'Du musst %1$d Sekunden warten, bevor du dich wieder anmelden kannst.';
$txt['pm_WaitTime_broken'] = 'Die letzte Private Mitteilung deiner IP-Adresse ist weniger als %1$d Sekunden her. Bitte versuche es später noch einmal.';
$txt['reporttm_WaitTime_broken'] = 'Das letzte Thema deiner IP-Adresse wurde vor weniger als %1$d Sekunden gemeldet. Bitte versuche es später noch einmal.';
$txt['sendtopic_WaitTime_broken'] = 'Das letzte Thema deiner IP-Adresse wurde vor weniger als %1$d Sekunden gesendet. Bitte versuche es später noch einmal.';
$txt['sendmail_WaitTime_broken'] = 'Die letzte E-Mail deiner IP-Adresse wurde vor weniger %1$d Sekunden versendet. Bitte versuche es später noch einmal.';
$txt['search_WaitTime_broken'] = 'Deine letzte Suchanfrage wurde vor weniger als %1$d Sekunden gestartet. Bitte versuche es später noch einmal.';
$txt['remind_WaitTime_broken'] = 'Deine letzte Erinnerung ist weniger als %1$d Sekunde her. Bitte versuche es später noch einmal.';
$txt['contact_WaitTime_broken'] = 'Du hast das Kontakt-Formular erst vor %1$d aufgerufen. Bitte versuche es später nochmal.';

$txt['topic_gone'] = 'Das Thema, welches du anschauen möchtest, existiert nicht mehr oder ist für dich nicht mehr einsehbar.';
$txt['theme_edit_missing'] = 'Die Datei, die du editieren möchtest, kann nicht mehr gefunden werden.';

$txt['no_dump_database'] = 'Entschuldige, aber diese Funktion ist Administratoren vorbehalten.';
$txt['pm_not_yours'] = 'Die Private Mitteilung, die du zitieren möchtest, ist nicht deine eigene bzw. exisitiert nicht mehr. Bitte gehe einen Schritt zurück und versuche es noch einmal.';
$txt['mangled_post'] = 'Fehlende Formulardaten - Bitte gehe einen Schritt zurück und versuche es noch einmal.';
$txt['too_many_groups'] = 'Entschuldige, du hast zu viele Benutzergruppen ausgewählt. Bitte einige abwählen.';
$txt['post_upload_error'] = 'Beitragsdaten fehlen. Der Fehler tritt auf, wenn mehr Daten übermittelt werden als vom Server zugelassen sind. Bitte bei einem Administrator melden, wenn der Fehler weiterhin auftritt.';
$txt['quoted_post_deleted'] = 'Der Beitrag, den du zitieren möchtest, existiert nicht mehr, wurde inzwischen gelöscht oder ist für dich nicht mehr einsehbar.';
$txt['pm_too_many_per_hour'] = 'Du hast das Limit von %1$d Privaten Mitteilungen pro Stunde erreicht.';
$txt['labels_too_many'] = '%1$s Mitteilungen haben schon das Limit der Labels erreicht.';

$txt['register_only_once'] = 'Du darfst mehrere Benutzerkonten nicht zur gleichen Zeit für den gleichen Computer registrieren.';
$txt['admin_setting_coppa_require_contact'] = 'Du musst eine Postadresse oder Faxnummer eingeben, wenn die Genehmigung durch Eltern oder Erziehungsberechtigte erfordert wird.';

$txt['error_long_name'] = 'Der Benutzername, den du verwenden möchtest, ist zu lang.';
$txt['error_no_name'] = 'Kein Benutzername vorhanden.';
$txt['error_bad_name'] = 'Dieser Benutzername kann nicht verwendet werden, weil er reserviert ist.';
$txt['error_no_email'] = 'Keine E-Mail-Adresse angegeben.';
$txt['error_bad_email'] = 'Ungültige E-Mail-Adresse angegeben.';
$txt['error_email'] = 'E-Mail-Adresse';
$txt['error_message'] = 'Nachricht';
$txt['error_no_event'] = 'Kein Ereignistitel angegeben.';
$txt['error_no_subject'] = 'Kein Betreff angegeben.';
$txt['error_no_question'] = 'Frage wurde nicht angegeben.';
$txt['error_no_message'] = 'Textfeld wurde nicht ausgefüllt.';
$txt['error_long_message'] = 'Der Beitrag hat die max. Länge erreicht (%s Zeichen).';
$txt['error_no_comment'] = 'Das Kommentarfeld wurde nicht ausgefüllt.';
$txt['error_post_too_long'] = 'Dein Beitrag ist zu lang - max. sind 255 Zeichen erlaubt. ';
$txt['error_session_timeout'] = 'Deine Sitzung ist abgelaufen. Bitte sende deinen Beitrag erneut ab.';
$txt['error_no_to'] = 'Kein Empfänger angegeben.';
$txt['error_bad_to'] = 'Ein oder mehrere Empfänger können nicht gefunden werden.';
$txt['error_bad_bcc'] = 'Ein oder mehrere Bcc-Empfänger können nicht gefunden werden.';
$txt['error_form_already_submitted'] = 'Du hast den Beitrag bereits gesendet. Vielleicht hast du ihn aus Versehen zweimal abgesendet oder die Seite neu geladen?';
$txt['error_poll_few'] = 'Du musst mind. zwei Möglichkeiten auswählen.';
$txt['error_poll_many'] = 'Es sind max. 256 Antworten erlaubt.';
$txt['error_need_qr_verification'] = 'Bitte fülle die Verifizierung unten aus, um deinen Beitrag zu speichern.';
$txt['error_wrong_verification_code'] = 'Die eingegebenen Buchstaben stimmen nicht mit denen im Bild überein.';
$txt['error_wrong_verification_answer'] = 'Du hast die Verifizierungsfrage nicht korrekt beantwortet.';
$txt['error_need_verification_code'] = 'Bitte gebe den Verifizierungscode ein, um zu den Resultaten zu gelangen.';
$txt['error_bad_file'] = 'Die ausgewählte Datei konnte nicht geöffnet werden: %1$s.';
$txt['error_bad_line'] = 'Die angegebene Zeile ist ungültig.';
$txt['error_draft_not_saved'] = 'Fehler beim Speichern des Entwurfs';
$txt['error_name_in_use'] = 'Der Benutzername %1$s wird bereits von einem anderen Mitglied verwendet.';

$txt['smiley_not_found'] = 'Smiley nicht gefunden.';
$txt['smiley_has_no_code'] = 'Für dieses Smiley wurde kein Code gefunden.';
$txt['smiley_has_no_filename'] = 'Für dieses Smiley wurde kein Dateiname gefunden.';
$txt['smiley_not_unique'] = 'Ein Smiley mit diesem Code existiert bereits.';
$txt['smiley_set_already_exists'] = 'Ein Smiley-Set mit dieser URL existiert bereits.';
$txt['smiley_set_not_found'] = 'Smiley-Set nicht gefunden.';
$txt['smiley_set_dir_not_found'] = 'Das Smiley-Set kann nicht importiert werden. Das Verzeichnis %1$s ist ungültig oder es kann nicht darauf zugegriffen werden.';
$txt['smiley_set_path_already_used'] = 'Die URL von diesem Smiley-Set wird bereits von einem anderen Set benutzt.';
$txt['smiley_set_unable_to_import'] = 'Das Smiley-Set kann nicht importiert werden. Das Verzeichnis ist ungültig oder es kann nicht darauf zugegriffen werden.';

$txt['smileys_upload_error'] = 'Die Datei konnte nicht hochgeladen werden.';
$txt['smileys_upload_error_blank'] = 'Alle Smiley-Sets müssen mind. ein Bild haben!';
$txt['smileys_upload_error_name'] = 'Alle Smileys müssen den gleichen Dateinamen haben!'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Ungültiger Typ.';

$txt['search_invalid_weights'] = 'Die Gewichtungen der Suchergebnisse sind nicht richtig eingestellt. Mindestens ein Wert sollte nicht auf "Null" eingestellt sein. Bitte informiere den Administrator.';

$txt['package_no_file'] = 'Die Datei konnte nicht gefunden werden!';
$txt['packageget_unable'] = 'Der Server wurde nicht gefunden. Bitte benutze stattdessen <a href="%1$s" target="_blank">diesen Link</a>.';
$txt['not_valid_server'] = 'Pakete können nur von autorisierten Servern heruntergeladen werden.';
$txt['package_cant_uninstall'] = 'Dieses Paket war noch nie installiert oder wurde bereits deinstalliert. Deshalb kannst du es nicht noch einmal deinstallieren.';
$txt['package_cant_download'] = 'Du kannst keine Pakete herunterladen bzw. installieren, da das Paket-Verzeichnis oder enthaltene Dateien nicht überschreibbar sind!';
$txt['package_upload_error_nofile'] = 'Du hast kein Paket zum Hochladen ausgewählt.';
$txt['package_upload_error_failed'] = 'Das Paket konnte nicht hochgeladen werden. Bitte prüfe die Verzeichnisrechte.';
$txt['package_upload_error_exists'] = 'Die Datei, die du hochladen möchtest, existiert schon auf dem Server. Bitte lösche diese zuerst und versuche es dann erneut.';
$txt['package_upload_already_exists'] = 'Das Paket, welches du hochladen möchtest, existiert bereits unter dem Namen %1$s auf dem Server.';
$txt['package_upload_error_supports'] = 'Der Paketmanager erlaubt momentan nur folgende Dateitypen: %1$s.';
$txt['package_upload_error_broken'] = 'Das Hochladen des Paketes ist aufgrund des folgenden Fehlers fehlgeschlagen:<br />"%1$s"';

$txt['package_get_error_not_found'] = 'Das Paket, welches du zu installieren versuchst, konnte nicht gefunden werden. Vielleicht möchtest du das Packet manuell in dein "/packages"-Verzeichnis hochladen?';
$txt['package_get_error_missing_xml'] = 'Das Paket, welches du zu installieren versuchst, hat keine "package-info.xml" in dessen Hauptverzeichnis.';
$txt['package_get_error_is_zero'] = 'Auch wenn das Paket auf den Server kopiert wurde, scheint es leer zu sein. Bitte überprüfe, dass der "/packages"-Ordner und das "/temp"-Unterverzeichnis beschreibbar sind. Solltest du dieses Problem weiterhin haben, solltest du versuchen, das Paket auf deinem eigenen Computer zu entpacken und in ein neues Unterverzeichnis in das "/packages"-Verzeichnis auf den Server zu kopieren. Wenn das Paket zum Beispiel "shout.tar.gt" heißt, solltest Du:<br/>1) Das Paket auf deinen PC herunterladen und entpacken.<br/>2) Mit einem FTP-Programm ein neues Verzeichnis im "/packages"-Ordner erstellen und dieses, in unserem Beispiel, "shout" nennen.<br/>3) Lade alle entpackten Dateien in dieses Verzeichnis.<br/>4) Gehe zurück zum Paketmanager und prüfe, ob das Paket automatisch gefunden wurde (dies sollte nun der Fall sein).';
$txt['package_get_error_packageinfo_corrupt'] = 'Es konnte keine gültige Information in der "package-info.xml" des Paketes gefunden werden. Die Modifikation könnte fehlerhaft sein oder das gewählte Paket ist fehlerhaft.';
$txt['package_get_error_is_theme'] = 'Du kannst von diesem Bereich aus kein Theme installieren, bitte benutze die <a href="{MANAGETHEMEURL}">Themes und Layouts</a>-Seite, um es hochzuladen.';

$txt['no_membergroup_selected'] = 'Benutzergruppen';
$txt['membergroup_does_not_exist'] = 'Diese Benutzergruppe existiert nicht oder ist ungültig.';

$txt['at_least_one_admin'] = 'Es muss mindestens ein Administrator im Forum exisitieren!';

$txt['error_functionality_not_windows'] = 'Diese Funktion steht momentan auf Windows-Betriebssystemen nicht zur Verfügung.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Dateianhang nicht gefunden.';

$txt['error_no_boards_selected'] = 'Du hast kein gültiges Board ausgewählt.';
$txt['error_invalid_search_string'] = 'Du hast keinen Suchbegriff eingegeben.';
$txt['error_invalid_search_string_blacklist'] = 'Deine Suchanfrage enthielt zu triviale Suchbegriffe. Bitte versuche es mit anderen Suchbegriffen erneut.';
$txt['error_search_string_small_words'] = 'Jedes Wort muss aus mindestens zwei Buchstaben bestehen.';
$txt['error_query_not_specific_enough'] = 'Deine Suchanfrage ergab keine Ergebnisse.';
$txt['error_no_messages_in_time_frame'] = 'Keine Beiträge im gewählten Zeitrahmen gefunden.';
$txt['error_no_labels_selected'] = 'Du hast keine Labels ausgewählt.';
$txt['error_no_search_daemon'] = 'Auf die Suchfunktion konnte nicht zugegriffen werden.';

$txt['profile_errors_occurred'] = 'Die folgenden Fehler sind während des Speicherns des Profils aufgetreten:';
$txt['profile_error_bad_offset'] = 'Die Zeitverschiebung ist außerhalb des erlaubten Bereichs.';
$txt['profile_error_no_name'] = 'Das Namensfeld wurde nicht ausgefüllt.';
$txt['profile_error_digits_only'] = 'Die \'Beiträge\'-Box darf nur Zahlen enthalten.';
$txt['profile_error_name_taken'] = 'Der ausgewählte Benutzername bzw. Anzeigename existiert schon.';
$txt['profile_error_name_too_long'] = 'Der ausgewählte Benutzername ist zu lang. Er sollte nicht länger als 60 Zeichen sein.';
$txt['profile_error_no_email'] = 'Das E-Mail-Feld wurde nicht ausgefüllt.';
$txt['profile_error_bad_email'] = 'Du hast keine gültige E-Mail-Adresse eingegeben.';
$txt['profile_error_email_taken'] = 'Ein anderer Benutzer hat sich schon mit dieser E-Mail-Adresse registriert.';
$txt['profile_error_no_password'] = 'Du hast dein Passwort nicht eingegeben.';
$txt['profile_error_bad_new_password'] = 'Die neuen Passwörter stimmen nicht überein.';
$txt['profile_error_bad_password'] = 'Das eingegebene Passwort ist nicht korrekt.';
$txt['profile_error_bad_avatar'] = 'Der ausgewählte Avatar ist zu groß.';
$txt['profile_error_password_short'] = 'Dein Passwort ist zu kurz. Es muss mind. %1$s Zeichen lang sein.';
$txt['profile_error_password_restricted_words'] = 'Dein Passwort darf deinen Benutzernamen, deine E-Mail-Adresse oder andere häufig genutzte Wörter nicht enthalten.';
$txt['profile_error_password_chars'] = 'Dein Passwort muss Groß- und Kleinbuchstaben sowie Zahlen enthalten.';
$txt['profile_error_already_requested_group'] = 'Du hast bereits eine Anfrage für diese Gruppe gestartet.';
$txt['profile_error_openid_in_use'] = 'Ein anderer Benutzer verwendet diese OpenID-URL bereits.';
$txt['profile_error_signature_not_yet_saved'] = 'Die Signatur konnte nicht gespeichert werden.';
$txt['profile_error_personal_text_too_long'] = 'Der persönliche Text ist zu lang.';
$txt['profile_error_user_title_too_long'] = 'Der persönliche Titel ist zu lang.';

$txt['mysql_error_space'] = ' - Kontrolliere den Speicherplatz für die Datenbank oder kontaktiere den Server Administrator.';

$txt['icon_not_found'] = 'Das Symbol konnte nicht im Standard-Theme gefunden werden. Stelle sicher, dass es hochgeladen wurde und versuche es erneut.';
$txt['icon_after_itself'] = 'Das Symbol kann nicht hinter sich selbst positioniert werden!';
$txt['icon_name_too_long'] = 'Die Dateinamen von Symbolen dürfen nicht länger als 16 Zeichen sein.';

$txt['name_censored'] = 'Der Name, den du benutzen möchtest - "%1$s" - enthält Wörter bzw. Buchstabenkombinationen, welche zensiert werden. Bitte gebe einen anderen Namen ein.';

$txt['poll_already_exists'] = 'Einem Thema kann nur eine Umfrage zugeordnet sein.';
$txt['poll_not_found'] = 'Diesem Thema ist keine Umfrage zugeordnet.';

$txt['error_while_adding_poll'] = 'Die folgenden Fehler sind aufgetreten, während die Umfrage hinzugefügt wurde:';
$txt['error_while_editing_poll'] = 'Die folgenden Fehler sind aufgetreten, während die Umfrage editiert wurde:';

$txt['loadavg_search_disabled'] = 'Aufgrund der hohen Auslastung des Servers wurde die Suchfunktion deaktiviert.';
$txt['loadavg_generic_disabled'] = 'Aufgrund der hohen Auslastung des Servers ist diese Funktion momentan nicht verfügbar.';
$txt['loadavg_allunread_disabled'] = 'Aufgrund der hohen Auslastung des Servers konnten nicht alle ungelesenen Themen gefunden werden.';
$txt['loadavg_unreadreplies_disabled'] = 'Die Auslastung des Servers ist momentan zu hoch. Bitte versuche es später noch einmal.';
$txt['loadavg_show_posts_disabled'] = 'Aufgrund der hohen Auslastung des Servers konnten die Benutzerbeiträge nicht geladen werden. Bitte versuche es später noch einmal.';
$txt['loadavg_unread_disabled'] = 'Die Serverbelastung ist momentan zu hoch, um die ungelesenen Themen anzuzeigen.';
$txt['loadavg_userstats_disabled'] = 'Aufgrund der hohen Auslastung des Servers konnten die Benutzer-Statistiken nicht geladen werden. Bitte versuche es später noch einmal.';

$txt['cannot_edit_permissions_inherited'] = 'Du kannst vererbte Berechtigungen nicht direkt verändern. Du musst entweder die übergeordneten Berechtigungen oder die Berechtigungen der Benutzergruppe editieren.';

$txt['mc_no_modreport_specified'] = 'Du musst den gewünschten Report auswählen.';
$txt['mc_no_modreport_found'] = 'Der gewünschte Report existiert nicht oder darf von dir nicht erstellt werden.';

$txt['st_cannot_retrieve_file'] = 'Die Datei "%1$s" konnte nicht abgerufen werden.';
$txt['admin_file_not_found'] = 'Die angeforderte Datei konnte nicht geladen werden: "%1$s".';

$txt['themes_none_selectable'] = 'Es muss mindestens ein Theme zur Auswahl stehen.';
$txt['themes_default_selectable'] = 'Das Standard-Theme muss zur Auswahl stehen.';
$txt['ignoreboards_disallowed'] = 'Die Option für das Ignorieren von Boards ist nicht aktiviert.';

$txt['mboards_delete_error'] = 'Keine Kategorie ausgewählt.';
$txt['mboards_delete_board_error'] = 'Kein Board ausgewählt.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'Du kannst aus einem übergeordneten Board kein untergeordnetes erstellen.';
$txt['mboards_board_own_child_error'] = 'Du kannst das Board nicht auf sich selbst kopieren.';

$txt['smileys_upload_error_notwritable'] = 'Die folgenden Smiley-Verzeichnisse sind nicht überschreibbar: "%1$s".';
$txt['smileys_upload_error_types'] = 'Bilder dürfen nur die folgenden Endungen haben: "%1$s".';

$txt['change_email_success'] = 'Deine E-Mail-Adresse hat sich geändert. Es wurde dir eine neue Aktivierungs-E-Mail zugeschickt.';
$txt['resend_email_success'] = 'Eine neue Ankündigungs-E-Mail wurde erfolgreich versendet.';

$txt['custom_option_need_name'] = 'Die Profil-Option muss einen Namen erhalten.';
$txt['custom_option_not_unique'] = 'Der Name des Feldes ist nicht eindeutig.';
$txt['custom_option_regex_error'] = 'Die eingegebene Regular Expression ist ungültig.';

$txt['warning_no_reason'] = 'Du musst einen Grund für die Veränderung des Verwarnungslevels angeben.';
$txt['warning_notify_blank'] = 'Du hast das Senden einer Benachrichtigung ausgewählt, aber keinen Betreff bzw. Inhalt eingegeben.';

$txt['cannot_connect_doc_site'] = 'Das Online-Handbuch konnte nicht geladen werden. Bitte überprüfe die Serverkonfiguration. Externe Verbindungen müssen erlaubt sein.';

$txt['movetopic_no_reason'] = 'Du musst einen Grund für das Verschieben des Themas angeben, oder die Option eines Weiterleitungs-Themas deaktivieren.';
$txt['movetopic_no_board'] = 'Es muss ein Board ausgewählt werden, in welches das Thema verschoben werden soll.';

$txt['splittopic_no_reason'] = 'Du musst einen Grund für das Verschieben des Themas angeben, oder die Option eines Weiterleitungs-Themas deaktivieren.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Der angeforderte Identifizierungsserver hat nicht die richtigen Informationen geliefert.';
$txt['openid_return_no_mode'] = 'Der Identitätsprovider hat nicht im OpenID-Modus geantwortet.';
$txt['openid_not_resolved'] = 'Der Identitätsprovider konnte deine Anfrage nicht genehmigen.';
$txt['openid_no_assoc'] = 'Die angeforderte Zuordnung konnte mit dem Identitätsprovider nicht gefunden werden.';
$txt['openid_sig_invalid'] = 'Die Signatur des Identitätsproviders ist ungültig.';
$txt['openid_load_data'] = 'Die Daten konnten nicht geladen werden. Bitte versuche es noch einmal.';
$txt['openid_not_verified'] = 'Die eingegebene OpenID-Adresse ist noch nicht verifiziert worden. Bitte logge dich ein, um sie zu verifizieren.';

$txt['error_custom_field_too_long'] = 'Das "%1$s"-Feld darf nicht länger als %2$d Zeichen sein.';
$txt['error_custom_field_invalid_email'] = 'Das "%1$s"-Feld muss eine gültige E-Mail-Adresse enthalten.';
$txt['error_custom_field_not_number'] = 'Das "%1$s"-Feld muss nummerisch sein.';
$txt['error_custom_field_inproper_format'] = 'Das "%1$s"-Feld hat ein ungültiges Format.';
$txt['error_custom_field_empty'] = 'Das "%1$s"-Feld darf nicht leer sein.';

$txt['email_no_template'] = 'Das E-Mail-Template "%1$s" konnte nicht gefunden werden.';

$txt['search_api_missing'] = 'Die Such-API konnte nicht gefunden werden. Bitte kontaktiere den Administrator mit der Bitte, zu prüfen, ob die richtigen Dateien hochgeladen wurden.';
$txt['search_api_not_compatible'] = 'Die gewählte Such-API des Forums ist nicht mehr aktuell. Es wird die Standard-Suche verwendet. Bitte prüfe die Datei "%1$s".';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Du kannst den ersten Beitrag eines Themas nicht wiederherstellen.';
$txt['restored_disabled'] = 'Das Wiederherstellen von Themen wurde deaktiviert.';
$txt['restore_not_found'] = 'Die folgenden Beiträge konnten nicht wiederhergestellt werden, weil das ursprüngliche Thema "1$s" nicht mehr existiert. Du musst diese Beiträge in ein anderes Thema verschieben.';

$txt['error_invalid_dir'] = 'Das angegebene Verzeichnis ist ungültig.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'Die angeforderte Sub-Aktion ist nicht definiert.';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'Keine sortierbaren Elemente gefunden.';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
