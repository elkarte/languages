<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Moderatoren-Center';
$txt['mc_main'] = 'Hauptseite';
$txt['mc_logs'] = 'Protokolle';
$txt['mc_posts'] = 'Beiträge';
$txt['mc_groups'] = 'Benutzer und Gruppen';

$txt['mc_view_groups'] = 'Benutzergruppen anzeigen';

$txt['mc_description'] = '<strong>Willkommen %1$s!</strong><br />Dies ist dein &quot;Moderatoren-Center&quot;. Von hier aus kannst du deinen moderativen Tätigkeiten nachgehen. Die Hauptseite enthält eine Zusammenfassung der letzten Geschehnisse im Forum. Du kannst das Layout deinem eigenen Geschmack anpassen, indem du <a href="%2$s">hier klickst</a>.';
$txt['mc_group_requests'] = 'Gruppenanfragen';
$txt['mc_member_requests'] = 'Benutzeranfragen';
$txt['mc_unapproved_posts'] = 'Ungenehmigte Beiträge';
$txt['mc_watched_users'] = 'Beobachtete Benutzer';
$txt['mc_watched_topics'] = 'Beobachtete Themen';
$txt['mc_scratch_board'] = 'Moderatoren-Schmierzettel';
$txt['mc_latest_news'] = 'Neueste Nachrichten';
$txt['mc_recent_reports'] = 'Neu gemeldete Themen';
$txt['mc_warnings'] = 'Verwarnungen';
$txt['mc_notes'] = 'Moderator-Notizen';
$txt['mc_required'] = 'Objekte, die auf Überprüfung warten';
$txt['mc_attachments'] = 'Zu überprüfende Anhänge';
$txt['mc_emailmod'] = 'Zu überprüfende E-Mail-Beiträge';
$txt['mc_topics'] = 'Zu überprüfende Themen';
$txt['mc_posts'] = 'Beiträge';
$txt['mc_groupreq'] = 'Zu überprüfende Gruppenanfragen';
$txt['mc_memberreq'] = 'Zu überprüfende Benutzer';
$txt['mc_reports'] = 'Zu überprüfende Beitragsmeldungen';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'Verbindungsaufbau zum Abruf der News von ElkArte gescheitert.';

$txt['mc_recent_reports_none'] = 'Es sind keine ausstehenden Meldungen vorhanden.';
$txt['mc_watched_users_none'] = 'Es werden momentan keine Benutzer beobachtet.';
$txt['mc_group_requests_none'] = 'Es sind keine Gruppenanfragen vorhanden.';

$txt['mc_seen'] = '%1$s zuletzt gesehen %2$s';
$txt['mc_seen_never'] = '%1$s nie gesehen';
$txt['mc_groupr_by'] = 'von';

$txt['mc_reported_posts_desc'] = 'Hier kannst du Beträge anschauen, die von den Benutzern gemeldet wurden.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Aktive Meldungen';
$txt['mc_reportedp_closed'] = 'Alte Meldungen';
$txt['mc_reportedp_by'] = 'von';
$txt['mc_reportedp_reported_by'] = 'Gemeldet von';
$txt['mc_reportedp_last_reported'] = 'Zuletzt gemeldet';
$txt['mc_reportedp_none_found'] = 'Keine Meldungen gefunden';

$txt['mc_reportedp_details'] = 'Details';
$txt['mc_reportedp_close'] = 'Schließen';
$txt['mc_reportedp_open'] = 'Aktive Meldungen';
$txt['mc_reportedp_ignore'] = 'Ablehnen';
$txt['mc_reportedp_unignore'] = 'Wieder öffnen';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Bist du sicher, dass du weitere Meldungen zu dieser Nachricht ignorieren möchtest?

Dies wird für alle Moderatoren dieses Forums gelten.';
$txt['mc_reportedp_close_selected'] = 'Ausgewählte schließen';

$txt['mc_groupr_group'] = 'Benutzergruppen';
$txt['mc_groupr_member'] = 'Benutzer';
$txt['mc_groupr_reason'] = 'Grund';
$txt['mc_groupr_none_found'] = 'Es sind momentan keine Gruppenanfragen vorhanden.';
$txt['mc_groupr_submit'] = 'Senden';
$txt['mc_groupr_reason_desc'] = 'Grund für die Ablehnung von %1$s, der Gruppe "%2$s" beizutreten';
$txt['mc_groups_reason_title'] = 'Grund für die Zurückweisung';
$txt['with_selected'] = 'Mit ausgewählten';
$txt['mc_groupr_approve'] = 'Anfrage annehmen';
$txt['mc_groupr_reject'] = 'Anfrage ablehnen (ohne Begründung)';
$txt['mc_groupr_reject_w_reason'] = 'Anfrage begründet ablehnen';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Bist du sicher, dass du das tun möchtest?';

$txt['mc_unapproved_attachments_none_found'] = 'Keine ungenehmigten Dateianhänge gefunden.';
$txt['mc_unapproved_attachments_desc'] = 'Von hier aus kannst du Anhänge, die auf Moderation warten, freigeben oder löschen.';
$txt['mc_unapproved_replies_none_found'] = 'Keine ungenehmigten Beiträge gefunden.';
$txt['mc_unapproved_topics_none_found'] = 'Keine ungenehmigten Themen gefunden.';
$txt['mc_unapproved_posts_desc'] = 'Hier kannst du alle Beiträge genehmigen oder ablehnen, die moderiert werden müssen.';
$txt['mc_unapproved_replies'] = 'Antworten';
$txt['mc_unapproved_topics'] = 'Themen';
$txt['mc_unapproved_by'] = 'von';
$txt['mc_unapproved_sure'] = 'Bist du sicher, dass du das tun möchtest?';
$txt['mc_unapproved_attach_name'] = 'Name des Anhangs';
$txt['mc_unapproved_attach_size'] = 'Dateigröße';
$txt['mc_unapproved_attach_poster'] = 'Autor';
$txt['mc_viewmodreport'] = 'Moderationsbericht für %1$s von %2$s';
$txt['mc_modreport_summary'] = 'Es sind %1$d Meldungen für diesen Beitrag vorhanden. Die letzte Meldung war %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Benutzer, die diesen Beitrag gemeldet haben';
$txt['mc_modreport_whoreported_data'] = 'Gemeldet von %1$s am %2$s. Es wurde folgende Bemerkung hinterlassen:';
$txt['mc_modreport_modactions'] = 'Aktionen von anderen Moderatoren';
$txt['mc_modreport_mod_comments'] = 'Moderator-Kommentare';
$txt['mc_modreport_no_mod_comment'] = 'Es gibt momentan keine Moderator-Kommentare.';
$txt['mc_modreport_add_mod_comment'] = 'Kommentar hinzufügen';

$txt['show_notice'] = 'Notiz';
$txt['show_notice_subject'] = 'Betreff';
$txt['show_notice_text'] = 'Text';

$txt['mc_watched_users_title'] = 'Beobachtete Benutzer';
$txt['mc_watched_users_desc'] = 'Hier sind alle Benutzer aufgelistet, die von den Moderatoren derzeit beobachtet werden.';
$txt['mc_watched_users_post'] = 'Nach Beitrag anzeigen';
$txt['mc_watched_users_warning'] = 'Verwarnungslevel';
$txt['mc_watched_users_last_login'] = 'Letzte Anmeldung';
$txt['mc_watched_users_last_post'] = 'Letzter Beitrag';
$txt['mc_watched_users_no_posts'] = 'Es gibt keine Beiträge von beobachteten Benutzern.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Bist du sicher, dass du diesen Beitrag löschen möchtest?';
$txt['mc_watched_users_delete_posts'] = 'Bist du sicher, dass du diese Beiträge löschen möchtest?';
$txt['mc_watched_users_posted'] = 'Erstellt';
$txt['mc_watched_users_member'] = 'Benutzer';

$txt['mc_warnings_description'] = 'In dieser Sektion kannst du sehen, welche Warnungen an welche Benutzer ausgesprochen wurden. Du kannst außerdem Vorlagen hinzufügen und bearbeiten, welche beim Verwarnen eines Benutzers an diesen versandt werden.';
$txt['mc_warning_log'] = 'Verwarnungsprotokoll';
$txt['mc_warning_templates'] = 'Benutzerdefinierte Templates';
$txt['mc_warning_log_title'] = 'Betrachtet das Verwarnprotokoll';
$txt['mc_warning_templates_title'] = 'Eigene Verwarnvorlagen';

$txt['mc_warnings_none'] = 'Es wurden keine Verwarnungen ausgesprochen.';
$txt['mc_warnings_recipient'] = 'Empfänger';

$txt['mc_warning_templates_none'] = 'Bisher wurden noch keine Verwarnvorlagen erstellt.';
$txt['mc_warning_templates_time'] = 'Erstellungszeitpunkt';
$txt['mc_warning_templates_name'] = 'Vorlage';
$txt['mc_warning_templates_creator'] = 'Erstellt von';
$txt['mc_warning_template_add'] = 'Vorlage hinzufügen';
$txt['mc_warning_template_modify'] = 'Vorlage ändern';
$txt['mc_warning_template_delete'] = 'Ausgewählte löschen';
$txt['mc_warning_template_delete_confirm'] = 'Bist du sicher, dass du die ausgewählten Vorlagen löschen möchtest?';

$txt['mc_warning_template_desc'] = 'Benutze diese Seite, um die Details der Vorlage auszufüllen. Bitte beachte, dass der Betreff der Nachricht kein Teil der Vorlage ist. Beachte außerdem, dass, da die Benachrichtigung per PM versandt wird, du Bulletin Board Codes innerhalb der Vorlage nutzen kannst.  Falls du die {MESSAGE}-Variable nutzt, wird diese Vorlage nicht verfügbar sein, wenn du eine generische Verwarnung (zum Beispiel eine Verwarnung, die nicht mit einem Beitrag zusammenhängt) aussprichst.';
$txt['mc_warning_template_title'] = 'Vorlagen-Titel';
$txt['mc_warning_template_body_desc'] = 'Der Inhalt der Benachrichtigung. Bitte beachte, dass du folgende Kürzel in dieser Vorlage nutzen kannst:<ul style="margin-top: 0px;"><li>{MEMBER} - Benutzername.</li><li>{MESSAGE} - Verweis auf beanstandeten Beitrag (falls zutreffend).</li><li>{FORUMNAME} - Name des Forums.</li><li>{SCRIPTURL} - URL des Forums.</li><li>{REGARDS} - Standard-E-Mail-Signatur.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Persönliche Vorlage';
$txt['mc_warning_template_personal_desc'] = 'Wenn du diese Option wählst, kannst nur du diese Vorlage sehen, ändern und verwenden. Ist die Vorlage nicht ausgewählt, können sie alle Moderatoren verwenden. ';
$txt['mc_warning_template_error_no_title'] = 'Du musst den Titel festlegen.';
$txt['mc_warning_template_error_no_body'] = 'Du musst den Benachrichtigungstext festlegen.';

$txt['mc_settings'] = 'Einstellungen ändern';
$txt['mc_prefs_title'] = 'Moderator-Einstellungen';
$txt['mc_prefs_desc'] = 'Hier kannst du ein paar Einstellungen bezüglich der Moderation (z.B. wegen der Benachrichtigungen) vornehmen.';
$txt['mc_prefs_homepage'] = 'Bereiche, welche auf der Startseite des Moderatoren-Centers angezeigt werden sollen';
$txt['mc_prefs_latest_news'] = 'ElkArte-Neuigkeiten';
$txt['mc_prefs_show_reports'] = 'Offene Meldungen im Kopfbereich des Forums anzeigen';
$txt['mc_prefs_notify_report'] = 'Bei Meldungen benachrichtigen';
$txt['mc_prefs_notify_report_never'] = 'Nie';
$txt['mc_prefs_notify_report_moderator'] = 'Nur, wenn ich das Board moderiere';
$txt['mc_prefs_notify_report_always'] = 'Immer';
$txt['mc_prefs_notify_approval'] = 'Bei ausstehenden Genehmigungen benachrichtigen';
$txt['mc_logoff'] = 'Moderationssitzung beenden';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Eine neue Notiz hinzufügen';
$txt['mc_add_note'] = 'Hinzufügen';