<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Gleichzeitig online';

$txt['stats_center'] = 'Statistiken';
$txt['general_stats'] = 'Allgemeine Statistiken';
$txt['top_posters'] = 'Top 10 - Autoren - Anzahl ihrer Beiträge';
$txt['top_boards'] = 'Top 10 - Boards - Anzahl der Beiträge';
$txt['forum_history'] = 'Historie';
$txt['stats_new_topics'] = 'Neue Themen';
$txt['stats_new_posts'] = 'Neue Beiträge';
$txt['stats_new_members'] = 'Neue Benutzer';
$txt['page_views'] = 'Seitenaufrufe';
$txt['top_topics_replies'] = 'Top 10 - Themen - Anzahl der Beiträge';
$txt['top_topics_views'] = 'Top 10 - Themen - Anzahl der Aufrufe';
$txt['yearly_summary'] = 'Zeitraum';
$txt['top_starters'] = 'Top 10 - Themenstarter - Anzahl ihrer Themen';
$txt['most_time_online'] = 'Online-Dauer';

$txt['average_members'] = 'Registrierungen pro Tag (durchschn.)';
$txt['average_posts'] = 'Beiträge pro Tag (durchschn.)';
$txt['average_topics'] = 'Themen pro Tag (durchschn.)';
$txt['average_online'] = 'Online pro Tag (durchschn.)';
$txt['users_online'] = 'Gerade online';
$txt['emails_sent'] = 'E-Mails pro Tag (durchschn.)';
$txt['users_online_today'] = 'Heute online';
$txt['num_hits'] = 'Seitenaufrufe insgesamt';
$txt['average_hits'] = 'Seitenaufrufe pro Tag (durchschn.)';

$txt['ssi_comment'] = 'Kommentar';
$txt['ssi_comments'] = 'Kommentare';
$txt['ssi_write_comment'] = 'Kommentar schreiben';
$txt['ssi_no_guests'] = 'Du kannst kein Board angeben, welches für Gäste nicht sichtbar ist. Bitte überprüfe die Board-ID, bevor du es erneut versuchst.';
$txt['xml_rss_desc'] = 'Gesendet von {forum_name}';