<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Das Default-ElkArte-Theme.<br /><br />Autoren: Die Mitwirkenden bei ElkArte';