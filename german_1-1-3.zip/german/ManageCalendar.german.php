<?php
// Version: 1.1; ManageCalendar

$txt['calendar_desc'] = 'Hier kannst du alle Einstellungen des Kalenders verwalten.';

// Calendar Settings
$txt['calendar_settings_desc'] = 'Hier kannst du den Kalender und die gewünschten Funktionen aktivieren bzw. deaktvieren.';
$txt['groups_calendar_view'] = 'Benutzergruppen, die den Kalender anschauen dürfen';
$txt['groups_calendar_post'] = 'Benutzergruppen, die neue Kalenderereignisse erstellen dürfen';
$txt['groups_calendar_edit_own'] = 'Benutzergruppen, die ihre Kalenderereignisse editieren dürfen';
$txt['groups_calendar_edit_any'] = 'Benutzergruppen, die alle Kalenderereignisse editieren dürfen';
$txt['setting_cal_enabled'] = 'Aktiviere Kalender';
$txt['setting_cal_daysaslink'] = 'Datum als Link für neues Ereignis';
$txt['setting_cal_days_for_index'] = 'Max. Anzahl der Tage für zukünftige Ereignisse im Info-Center';
$txt['setting_cal_showholidays'] = 'Feiertage anzeigen';
$txt['setting_cal_showbdays'] = 'Geburtstage anzeigen';
$txt['setting_cal_showevents'] = 'Ereignisse anzeigen';
$txt['setting_cal_export'] = 'Export von Ereignissen in das iCal-Format erlauben';
$txt['setting_cal_show_never'] = 'Nie';
$txt['setting_cal_show_cal'] = 'Nur im Kalender anzeigen';
$txt['setting_cal_show_index'] = 'Nur im Info-Center anzeigen';
$txt['setting_cal_show_all'] = 'Im Kalender und Info-Center anzeigen';
$txt['setting_cal_defaultboard'] = 'Board für Kalenderereignisse';
$txt['setting_cal_allow_unlinked'] = 'Ereignisse auch ohne Link zu einem Thema erlauben';
$txt['setting_cal_minyear'] = 'Von (Jahr)';
$txt['setting_cal_maxyear'] = 'Bis (Jahr)';
$txt['setting_cal_allowspan'] = 'Ereignisse über mehrere Tage erlauben';
$txt['setting_cal_maxspan'] = 'Max. Ereignisdauer (in Tagen)';
$txt['setting_cal_showInTopic'] = 'Link zum Kalenderereignis im Thema anzeigen';

// Adding/Editing/Viewing Holidays
$txt['manage_holidays_desc'] = 'Hier kannst du Feiertage im Kalender hinzufügen oder entfernen.';
$txt['current_holidays'] = 'Aktuelle Feiertage';
$txt['holidays_title'] = 'Feiertage';
$txt['holidays_title_label'] = 'Titel';
$txt['holidays_delete_confirm'] = 'Bist du sicher, dass du diese Feiertage entfernen möchtest?';
$txt['holidays_add'] = 'Neuen Feiertag hinzufügen';
$txt['holidays_edit'] = 'Vorhandenen Feiertag ändern';
$txt['holidays_button_add'] = 'Hinzufügen';
$txt['holidays_button_edit'] = 'Editieren';
$txt['holidays_button_remove'] = 'Entfernen';
$txt['holidays_no_entries'] = 'Es sind im Moment keine Feiertage hinterlegt.';
$txt['every_year'] = 'Wiederholend (jedes Jahr)';