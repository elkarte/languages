<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Entwürfe anzeigen';
$txt['drafts_show_desc'] = 'Dieser Bereich zeigt alle Entwürfe an, die derzeit gespeichert sind. Hier kannst du sie vor dem Veröffentlichen ändern oder löschen';

// misc
$txt['drafts'] = 'Entwürfe';
$txt['draft_save'] = 'Entwurf speichern';
$txt['draft_save_note'] = 'Speichert den Text deines Beitrages, nicht jedoch Dateianhänge, Umfragen oder Ereignisinformationen.';
$txt['draft_none'] = 'Du hast derzeit keine Entwürfe gespeichert.';
$txt['draft_edit'] = 'Entwurf ändern';
$txt['draft_load'] = 'Entwürfe laden';
$txt['draft_hide'] = 'Entwürfe verstecken';
$txt['draft_delete'] = 'Entwurf löschen';
$txt['draft_days_ago'] = 'vor %s Tagen';
$txt['draft_retain'] = 'dieser wird noch %s Tage vorgehalten';
$txt['draft_remove'] = 'Diesen Entwurf löschen';
$txt['draft_remove_selected'] = 'Ausgewählte löschen';
$txt['draft_saved'] = 'Der Inhalt wurde als Entwurf gespeichert und ist zukünftig im <a href="%1$s">Entwurfsbereich</a> deines Profils abrufbar.';
$txt['draft_pm_saved'] = 'Der Inhalt wurde als Entwurf gespeichert und ist zukünftig im <a href="%1$s">Entwurfsbereich</a> deines Nachrichtenzentrums abrufbar.';

// Admin options
$txt['drafts_autosave_enabled'] = 'Automatisches Speichern von Entwürfen aktivieren';
$txt['drafts_autosave_enabled_subnote'] = 'Entwürfe werden im einstellbaren Intervall automatisch im Hintergrund gesichert. Der Benutzer muss außerdem passende Befugnisse besitzen.';
$txt['drafts_keep_days'] = 'Höchstzahl an Tagen, die ein Entwurf gespeichert werden soll';
$txt['drafts_keep_days_subnote'] = '0 eingeben, um Entwürfe unendlich lange zu speichern.';
$txt['drafts_autosave_frequency'] = 'Wie oft sollen Entwürfe gespeichert werden?';
$txt['drafts_autosave_frequency_subnote'] = 'Der Mindestwert beträgt 30 Sekunden.';
$txt['drafts_pm_enabled'] = 'Speicherung von Mitteilungs-Entwürfen aktivieren';
$txt['drafts_post_enabled'] = 'Speicherung von Beitragsentwürfen aktivieren';
$txt['drafts_none'] = 'Kein Betreff';
$txt['drafts_saved'] = 'Entwurf erfolgreich gespeichert';