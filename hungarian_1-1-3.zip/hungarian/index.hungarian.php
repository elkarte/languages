<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'en_US';
$txt['lang_dictionary'] = 'en';
$txt['lang_spelling'] = 'amerikai';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'Vasárnap';
$txt['monday'] = 'Hétfő';
$txt['tuesday'] = 'Kedd';
$txt['wednesday'] = 'Szerda';
$txt['thursday'] = 'Csütörtök';
$txt['friday'] = 'Péntek';
$txt['saturday'] = 'Szombat';

$txt['sunday_short'] = 'Vas';
$txt['monday_short'] = 'Hétf';
$txt['tuesday_short'] = 'Ke';
$txt['wednesday_short'] = 'Sz';
$txt['thursday_short'] = 'Csüt';
$txt['friday_short'] = 'Pén';
$txt['saturday_short'] = 'Szo';

$txt['january'] = 'Január';
$txt['february'] = 'Február';
$txt['march'] = 'Március';
$txt['april'] = 'Április';
$txt['may'] = 'Május';
$txt['june'] = 'Június';
$txt['july'] = 'Július';
$txt['august'] = 'Augusztus';
$txt['september'] = 'Szeptember';
$txt['october'] = 'Október';
$txt['november'] = 'November';
$txt['december'] = 'December';

$txt['january_titles'] = 'Január';
$txt['february_titles'] = 'Február';
$txt['march_titles'] = 'Március';
$txt['april_titles'] = 'Április';
$txt['may_titles'] = 'Május';
$txt['june_titles'] = 'Június';
$txt['july_titles'] = 'Július';
$txt['august_titles'] = 'Augusztus';
$txt['september_titles'] = 'Szeptember';
$txt['october_titles'] = 'Október';
$txt['november_titles'] = 'November';
$txt['december_titles'] = 'December';

$txt['january_short'] = 'Jan';
$txt['february_short'] = 'Febr';
$txt['march_short'] = 'Márc';
$txt['april_short'] = 'Ápr';
$txt['may_short'] = 'Máj';
$txt['june_short'] = 'Jún';
$txt['july_short'] = 'Júl';
$txt['august_short'] = 'Aug';
$txt['september_short'] = 'Szept';
$txt['october_short'] = 'Okt';
$txt['november_short'] = 'Nov';
$txt['december_short'] = 'Dec';

$txt['time_am'] = 'am';
$txt['time_pm'] = 'pm';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Főoldal';
$txt['community'] = 'Közösség';
// Sub menu labels
$txt['help'] = 'Segítség';
$txt['search'] = 'Keresés';
$txt['calendar'] = 'Naptár';
$txt['members'] = 'Tagok';
$txt['recent_posts'] = 'Friss hozzászólások';

$txt['admin'] = 'Admin';
// Sub menu labels
$txt['errlog'] = 'Hiba napló';
$txt['package'] = 'Csomag-kezelő';
$txt['edit_permissions'] = 'Jogosultságok';
$txt['modSettings_title'] = 'Funkciók és beállítások';

$txt['moderate'] = 'Moderáció';
// Sub menu labels
$txt['modlog_view'] = 'Moderációs napló';
$txt['mc_emailerror'] = 'Jóváhagyatlan e-mailek';
$txt['mc_reported_posts'] = 'Jelentett hozzászólások';
$txt['mc_reported_pms'] = 'Jelentett személyes üzenetek';
$txt['mc_unapproved_attachments'] = 'Jóváhagyatlan csatolmányok';
$txt['mc_unapproved_poststopics'] = 'Jóváhagyatlan hozzászólások és témák';

$txt['pm_short'] = 'Üzeneteim';
// Sub menu labels
$txt['pm_menu_read'] = 'Olvasd el az üzeneteidet';
$txt['pm_menu_send'] = 'Küldj üzenetet';

$txt['account_short'] = 'Fiókom';
// Sub menu labels
$txt['profile'] = 'Profil';
$txt['mydrafts'] = 'Vázlatjaim';
$txt['summary'] = 'Összesítés';
$txt['theme'] = 'Kinézet és elrendezés';
$txt['account'] = 'Fiók beállítások';
$txt['forumprofile'] = 'Fórum profil';

$txt['view_unread_category'] = 'Új hozzászólások';
$txt['view_replies_category'] = 'Új válaszok';

$txt['login'] = 'Belépés';
$txt['register'] = 'Regisztráció';
$txt['logout'] = 'Kilépés';
// End main menu strings.

$txt['save'] = 'Mentés';

$txt['modify'] = 'Módosítás';
$txt['forum_index'] = '%1$s - Index';
$txt['board_name'] = 'Fórum név';
$txt['posts'] = 'Hozzászólások';

$txt['member_postcount'] = 'Hozzászólások';
$txt['no_subject'] = '(nincs tárgy)';
$txt['view_profile'] = 'Profil megnézése';
$txt['guest_title'] = 'Vendég';
$txt['author'] = 'Szerző';
$txt['on'] = 'on';
$txt['remove'] = 'Eltávolítás';
$txt['start_new_topic'] = 'Új téma nyitása';

// Use numeric entities in the below string.
$txt['username'] = 'Felhasználónév';
$txt['password'] = 'Jelszó';

$txt['username_no_exist'] = 'Ez a felhasználónév nem létezik.';
$txt['no_user_with_email'] = 'Ez a felhasználónév nincs egy e-mail címhez sem kötve.';

$txt['board_moderator'] = 'Fórum moderátor';
$txt['remove_topic'] = 'Eltávolítás';
$txt['topics'] = 'Téma';
$txt['modify_msg'] = 'Üzenet módosítása';
$txt['name'] = 'Név';
$txt['email'] = 'E-mail';
$txt['user_email_address'] = 'Email Address';
$txt['subject'] = 'Tárgy';
$txt['message'] = 'Üzenet';
$txt['redirects'] = 'Átirányítások';

$txt['choose_pass'] = 'Válassz jelszót';
$txt['verify_pass'] = 'Erősítsd meg a jelszót';
$txt['position'] = 'Pozíció';
$txt['notify_announcements'] = 'Iratkozz fel, hogy értesüld a friss hírekről';

$txt['profile_of'] = 'Profil megtekintése:';
$txt['total'] = 'Összes';
$txt['posts_made'] = 'Hozzászólások';
$txt['topics_made'] = 'Téma';
$txt['website'] = 'Weboldal';
$txt['contact'] = 'Kapcsolat';
$txt['warning_status'] = 'Figyelmeztetési állapot';
$txt['user_warn_watch'] = 'Felhasználó van a moderátori figyelőlistán';
$txt['user_warn_moderate'] = 'Felhasználói hozzászólás van a jőváhagyási listán';
$txt['user_warn_mute'] = 'Felhasználó eltiltva a posztolástól';
$txt['warn_watch'] = 'Figyelt';
$txt['warn_moderate'] = 'Moderált';
$txt['warn_mute'] = 'Némított';
$txt['warning_issue'] = 'Figyelmeztetés';

$txt['message_index'] = 'Üzenet index';
$txt['news'] = 'Hírek';
$txt['page'] = 'Oldal';
$txt['prev'] = 'előző';
$txt['next'] = 'következő';

$txt['post'] = 'Hozzászólás';
$txt['error_occurred'] = 'Hiba történt';
$txt['send_error_occurred'] = 'Hiba történt. <a href="{href}">Kérlet kattints ide az újrapróbálkozáshoz</a>';
$txt['require_field'] = 'Ez egy szükséges mező';
$txt['started_by'] = 'Szerző';
$txt['topic_started_by'] = '%1$s indította';
$txt['topic_started_by_in'] = '%1$s indította %2$s-kor';
$txt['replies'] = 'Válaszok';
$txt['last_post'] = 'Utolsó hozzászólás';
$txt['first_post'] = 'Első hozzászólás';
$txt['last_poster'] = 'Utolsó hozzászólás szerző';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s</span><span class="board_lastposter">írta %1$s</span><span class="board_lasttime"><strong>Utolsó hozzászólás:</strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s hozzászólás %2$s témában , %3$s tag által';
$txt['show'] = 'Mutasd';
$txt['hide'] = 'Elrejt';
$txt['sort_by'] = 'Rendezés';
$txt['sort_asc'] = 'Emelkedő rend';
$txt['sort_desc'] = 'Csökkenő rend.';

$txt['admin_login'] = 'Adminisztrációs belépés';
// Use numeric entities in the below string.
$txt['topic'] = 'Téma';
$txt['help'] = 'Segítség';
$txt['notify'] = 'Értesítés';
$txt['unnotify'] = 'Nem érdekel';
$txt['notify_request'] = 'Szeretnél értesítő e-mailt kapni ha valaki válaszol?';
// Use numeric entities in the below string.
$txt['regards_team'] = "Üdvözlet, \nA {forum_name_html_unsafe} Csapata";
$txt['notify_replies'] = 'Válaszok értesítései';
$txt['move_topic'] = 'Mozgatás';
$txt['move_to'] = 'Mozgatás ide:';
$txt['pages'] = 'Oldalak';
$txt['users_active'] = 'Aktív az utolsó %1$d percben';
$txt['personal_messages'] = 'Személyes üzenetek';
$txt['reply_quote'] = 'Válasz idézettel';
$txt['reply'] = 'Válasz';
$txt['reply_number'] = 'Válasz #%1$s-nak';
$txt['approve'] = 'Elfogadás';
$txt['unapprove'] = 'Elutasítás';
$txt['approve_all'] = 'összes elfogadása';
$txt['awaiting_approval'] = 'Elfogadásra várnak';
$txt['attach_awaiting_approve'] = 'Csatolmányok várnak elfogadásra';
$txt['post_awaiting_approval'] = 'Megjegyzés: Ez az üzenet moderátori jóváhagyásra vár.';
$txt['there_are_unapproved_topics'] = '%1$s téma és %2$s hozzászólás vár jóváhagyásra. <a href="%3$s">Kattints ide a megtekintéshez.</a>';
$txt['send_message'] = 'Üzenet küldése';

$txt['msg_alert_no_messages'] = 'nincs üzeneted';
$txt['msg_alert_one_message'] = '<a href="%1$s">egy</a> üzeneted van';
$txt['msg_alert_many_message'] = '<a href="%1$s">üzeneteid ( %2$d ) </a> vannak';
$txt['msg_alert_one_new'] = '1 új';
$txt['msg_alert_many_new'] = '%1$d új';
$txt['remove_message'] = 'Távolítsd el ezt az üzenetet';

$txt['topic_alert_none'] = 'Nincs üzenet...';
$txt['pm_alert_none'] = 'Nincs üzenet...';

$txt['online_users'] = 'Online felhasználók'; //Deprecated
$txt['online_now'] = 'Most online';
$txt['personal_message'] = 'Személyes üzenet';
$txt['jump_to'] = 'Ugrás';
$txt['go'] = 'Go';
$txt['are_sure_remove_topic'] = 'Biztosan el akarod távolítani ezt a témát?';
$txt['yes'] = 'Igen';
$txt['no'] = 'Nem';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'on';

$txt['search'] = 'Keresés';
$txt['all'] = 'Mindegyik';
$txt['search_entireforum'] = 'Egész fórum';
$txt['search_thisbrd'] = 'Ez a fórum';
$txt['search_thistopic'] = 'Ez a téma';
$txt['search_members'] = 'Tagok';

$txt['back'] = 'Vissza';
$txt['continue'] = 'Folytatás';
$txt['password_reminder'] = 'Jelszó emlékeztető';
$txt['topic_started'] = 'Témát indította:';
$txt['title'] = 'Cím';
$txt['post_by'] = 'Kiírta:';
$txt['welcome_newest_member'] = 'Üdvözöld %1$s-t, legújabb tagunkat.';
$txt['admin_center'] = 'Adminisztrációs központ';
$txt['admin_session_active'] = 'Adminisztratív munkamenet folyamatban. Ajánljuk, <strong><a class="strong" href="%1$s">hogy lépj ki</a></strong>, amikor készen vagy adminisztratív feladataiddal.';
$txt['admin_maintenance_active'] = 'Karbantartás a fórumon. Csak adminisztrátorok tudnak belépni, ne felejtsd el <strong><a class="strong" href="%1$s">kikapcsolni</a></strong> mikor végeztél.';
$txt['query_command_denied'] = 'A következő MySQL hibák léptek fel, ellenőrizze a konfigurációt:';
$txt['query_command_denied_guests'] = 'It seems something has gone sour on the forum with the database. This problem should only be temporary, so please come back later and try again.  If you continue to see this message, please report the following message to the administrator:';
$txt['query_command_denied_guests_msg'] = '%1$s parancs tiltva az adatbázison';
$txt['last_edit_by'] = '<span class="lastedit">Utolsó módosítás</span>: %1$s, %2$s';
$txt['notify_deactivate'] = 'Szeretnéd deaktiválni a téma értesítéseit?';

$txt['date_registered'] = 'Regisztráció dátuma';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'Nézd meg s friss hozzászólásokat.';
$txt['is_recent_updated'] = '%1$s a legnépszerűbb téma.';

$txt['male'] = 'Férfi';
$txt['female'] = 'Nő';

$txt['error_invalid_characters_username'] = 'Érvénytelen karakter a felhasználó névben.';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Szia,';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Üdvözöllek,';
$txt['select_destination'] = 'Válassz irányt';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Írta ';

$txt['icon_smiley'] = 'Szmájli';
$txt['icon_angry'] = 'Mérges';
$txt['icon_cheesy'] = 'Sajtos';
$txt['icon_laugh'] = 'Nevetés';
$txt['icon_sad'] = 'Szomorú';
$txt['icon_wink'] = 'Kaccsintás';
$txt['icon_grin'] = 'Vigyorog';
$txt['icon_shocked'] = 'Sokk';
$txt['icon_cool'] = 'Menő';
$txt['icon_huh'] = 'Hú';
$txt['icon_rolleyes'] = 'Szemforgatás';
$txt['icon_tongue'] = 'Nyelv';
$txt['icon_embarrassed'] = 'Embarrassed';
$txt['icon_lips'] = 'Lips sealed';
$txt['icon_undecided'] = 'Undecided';
$txt['icon_kiss'] = 'Kiss';
$txt['icon_cry'] = 'Sírás';
$txt['icon_angel'] = 'Ártatlan';

$txt['moderator'] = 'Moderator';
$txt['moderators'] = 'Moderátorok';

$txt['views'] = 'Megtekintések';
$txt['new'] = 'Új';
$txt['no_redir'] = 'Átírányítva innen: %1$s';

$txt['view_all_members'] = 'Összes tag';
$txt['view'] = 'Megtekintés';

$txt['viewing_members'] = 'Tagok megtekintése %1$s-től %2$s-ig';
$txt['of_total_members'] = 'a %1$s tag közül';

$txt['forgot_your_password'] = 'Elfejeljtetted a jelszavadat?';

$txt['date'] = 'Date';
// Use numeric entities in the below string.
$txt['from'] = 'Tőle';
$txt['to'] = 'Neki';

$txt['board_topics'] = 'Topics';
$txt['members_title'] = 'Members';
$txt['members_list'] = 'Taglista';
$txt['new_posts'] = 'Új hozzászólások';
$txt['old_posts'] = 'Nincs új hozzászólás:(';
$txt['redirect_board'] = 'Átirányítás';
$txt['redirect_board_to'] = 'Átirányítunk ide: %1$s';

$txt['sendtopic_send'] = 'Küldés';
$txt['report_sent'] = 'Sikeres jelentés.';
$txt['topic_sent'] = 'Az e-mail sikeresen elküldve.';

$txt['time_offset'] = 'Időeltolódás';
$txt['or'] = 'vagy';

$txt['mention'] = 'Értesítések';
$txt['notifications'] = 'Értesítések';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = 'Sajnáljuk, %1$s, ki lettél tiltva!';
$txt['your_ban_expires'] = 'Ez a kitiltás lejár: %1$s.';
$txt['your_ban_expires_never'] = 'Ez a kitiltás nem jár le.';
$txt['ban_continue_browse'] = 'Folytathatod a fórum böngészését vendégként.';

$txt['mark_as_read'] = 'Minden üzenet megjellölése OLVASOTTKÉNT';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'Jelöld EZEKET az üzeneteket olvasottra';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'Lezárt téma';
$txt['normal_topic'] = 'Normál téma';
$txt['participation_caption'] = 'Ebbe a témába hozzászóltál';

$txt['print'] = 'Nyomtatás';
$txt['topic_summary'] = 'Téma összegítés';
$txt['not_applicable'] = 'N/A';
$txt['name_in_use'] = 'A név már foglalt (%1$s)';

$txt['total_members'] = 'Összes tag';
$txt['total_posts'] = 'Összes hozzászólás';
$txt['total_topics'] = 'Összes téma';

$txt['mins_logged_in'] = 'Eddig maradj belépve:';

$txt['preview'] = 'előnézet';
$txt['always_logged_in'] = 'mindig maradjon belépve';

$txt['logged'] = 'Belépve';
// Use numeric entities in the below string.
$txt['ip'] = 'IP';

$txt['www'] = 'WWW';
$txt['link'] = 'link';

$txt['by'] = 'írta:'; //Deprecated

$txt['hours'] = 'órák';
$txt['minutes'] = 'minutes';
$txt['seconds'] = 'seconds';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'óra';
$txt['days_word'] = 'days';

$txt['newest_member'] = ', a legújabb tagunk.'; //Deprecated

$txt['search_for'] = 'Keresés';
$txt['search_match'] = 'Illik';

$txt['maintain_mode_on'] = 'Ne felejtsd el, a fórum karbantartási módban van.';

$txt['read'] = 'Olvasás'; //Deprecated
$txt['times'] = 'times'; //Deprecated
$txt['read_one_time'] = 'Egyszer olvasva';
$txt['read_many_times'] = '%1$dx olvasva';

$txt['forum_stats'] = 'fórum statisztika';
$txt['latest_member'] = 'Legújabb tag';
$txt['total_cats'] = 'Összes kategória';
$txt['latest_post'] = 'Legújabb hozzászólás';

$txt['here'] = 'itt';
$txt['you_have_no_msg'] = 'Nincsen üzeneted...';
$txt['you_have_one_msg'] = 'Üzeneted van (1)... <a href="%1$s">Kattints ide a megtekintéshez</a>';
$txt['you_have_many_msgs'] = '%2$düzeneted van... <a href="%1$s">Kattints ide a megtekintéshez</a>';

$txt['total_boards'] = 'Összeg fórum';

$txt['print_page'] = 'Oldal nyomtatása';
$txt['print_page_text'] = 'Csak szöveg';
$txt['print_page_images'] = 'Szöveg képekkel';

$txt['valid_email'] = 'Érvényes e-mail címnek kell lennie.';

$txt['info_center_title'] = '%1$s- Info Központ';

$txt['send_topic'] = 'Megosztás';
$txt['unwatch'] = 'Nem figyelés';
$txt['watch'] = 'Figyelés';

$txt['sendtopic_title'] = 'Send the topic &quot;%1$s&quot; to a friend.';
$txt['sendtopic_sender_name'] = 'Neved';
$txt['sendtopic_sender_email'] = 'E-mail címed';
$txt['sendtopic_receiver_name'] = 'Recipient\'s name';
$txt['sendtopic_receiver_email'] = 'Recipient\'s email address';
$txt['sendtopic_comment'] = 'Kommentelés';

$txt['allow_user_email'] = 'Küldhezzenek a felhasználók e-mailt?';

$txt['check_all'] = 'Összeg kifelőlése';

// Use numeric entities in the below string.
$txt['database_error'] = 'Adatbázis hiba';
$txt['try_again'] = 'Kérlek, próbáld újra. Ha újra jelentkezik a hiba, jelentsd egy adminisztrátornak.';
$txt['file'] = 'Fájl';
$txt['line'] = 'Vonal';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'ElkArte has detected and automatically tried to repair an error in your database.  If you continue to have problems, or continue to receive these emails, please contact your host.';
$txt['database_error_versions'] = '<strong>Megjegyzés:</strong> Az adatbázis verzió %1$s.';
$txt['template_parse_error'] = 'Template összeillesztési hiba!';
$txt['template_parse_error_message'] = 'It seems something has gone sour on the forum with the template system.  This problem should only be temporary, so please come back later and try again.  If you continue to see this message, please contact the administrator.<br /><br />You can also try <a href="javascript:location.reload();">refreshing this page</a>.';
$txt['template_parse_error_details'] = 'There was a problem loading the <span class="tt"><strong>%1$s</strong></span> template or language file.  Please check the syntax and try again - remember, single quotes (<span class="tt">\'</span>) often have to be escaped with a backslash (<span class="tt">\\</span>).  To see more specific error information from PHP, try <a href="%2$s%1$s">accessing the file directly</a>.<br /><br />You may want to try to <a href="javascript:location.reload();">refresh this page</a> or <a href="%3$s">use the default theme</a>.';
$txt['template_parse_undefined'] = 'An undefined error occurred during the parsing of this template';

$txt['today'] = 'Ma %1$s-kor';
$txt['yesterday'] = 'Tegnap %1$s-kor';

// Relative times
$txt['rt_now'] = 'most';
$txt['rt_minute'] = 'Egy perce';
$txt['rt_minutes'] = '%s perce';
$txt['rt_hour'] = 'Egy órája';
$txt['rt_hours'] = '%s órája';
$txt['rt_day'] = 'Egy napja';
$txt['rt_days'] = '%s napja';
$txt['rt_week'] = 'Egy hete';
$txt['rt_weeks'] = '%s hete';
$txt['rt_month'] = 'Egy hónapja';
$txt['rt_months'] = '%s hónapja';
$txt['rt_year'] = 'Egy éve';
$txt['rt_years'] = '%s éve';

$txt['new_poll'] = 'Új szavazás';
$txt['poll_question'] = 'Kérdés';
$txt['poll_question_options'] = 'Kérdés és opciók';
$txt['poll_vote'] = 'Szavazat leadása';
$txt['poll_total_voters'] = 'Ennyien szavaztak:';
$txt['draft_saved_on'] = 'Draft last saved';
$txt['poll_results'] = 'Eredmények megtekintése';
$txt['poll_lock'] = 'Szavazás lezárása';
$txt['poll_unlock'] = 'Szavazás feloldása';
$txt['poll_edit'] = 'Szavazás módosítása';
$txt['poll'] = 'Szavazás';
$txt['one_day'] = '1 Day';
$txt['one_week'] = '1 Week';
$txt['two_weeks'] = '2 Weeks';
$txt['one_month'] = '1 Month';
$txt['two_months'] = '2 Months';
$txt['forever'] = 'Forever';
$txt['quick_login_dec'] = 'Login with username, password and session length';
$txt['one_hour'] = '1 Hour';
$txt['moved'] = 'ÁTMOZGATVA';
$txt['moved_why'] = 'Please enter a brief description as to<br />why this topic is being moved.';
$txt['board'] = 'Board';
$txt['in'] = 'in';
$txt['sticky_topic'] = 'Pinned Topic';
$txt['split'] = 'SPLIT';

$txt['delete'] = 'Delete';

$txt['byte'] = 'B';
$txt['kilobyte'] = 'KB';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[More Stats]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Forráskód';
$txt['code_select'] = '[Select]';
$txt['quote_from'] = 'Quote from';
$txt['quote'] = 'Quote';
$txt['quote_new'] = 'New topic';
$txt['follow_ups'] = 'Follow-ups';
$txt['topic_derived_from'] = 'Topic derived from %1$s';
$txt['edit'] = 'Módosítás';
$txt['quick_edit'] = 'Gyors módosítás';
$txt['post_options'] = 'Több';

$txt['set_sticky'] = 'Kitűzés';
$txt['set_nonsticky'] = 'Unpin';
$txt['set_lock'] = 'Lezárás';
$txt['set_unlock'] = 'Feloldás';

$txt['search_advanced'] = 'Show advanced options';
$txt['search_simple'] = 'Hide advanced options';

$txt['security_risk'] = 'MAJOR SECURITY RISK:';
$txt['not_removed'] = 'You have not removed %1$s';
$txt['not_removed_extra'] = '%1$s is a backup of %2$s that was not generated by ElkArte. It can be accessed directly and used to gain unauthorised access to your forum. You should delete it immediately.';
$txt['generic_warning'] = 'Warning';
$txt['agreement_missing'] = 'You are requiring new users to accept a registration agreement, however the file (agreement.txt) doesn\'t exist.';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'You have just updated!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Click here to see what\'s new in this version of ElkArte!</a>!';

$txt['cache_writable'] = 'The cache directory is not writable - this will adversely affect the performance of your forum.';

$txt['page_created_full'] = 'Page created in %1$.3f seconds with %2$d queries.';

$txt['report_to_mod_func'] = 'Use this function to inform the moderators and administrators of an abusive or wrongly posted message.<br /><em>Please note that your email address will be revealed to the moderators if you use this.</em>';

$txt['online'] = 'Online';
$txt['member_is_online'] = '%1$s is online';
$txt['offline'] = 'Offline';
$txt['member_is_offline'] = '%1$s is offline';
$txt['pm_online'] = 'Personal Message (Online)';
$txt['pm_offline'] = 'Personal Message (Offline)';
$txt['status'] = 'Status';

$txt['skip_nav'] = 'Skip to main content';
$txt['go_up'] = 'Go Up';
$txt['go_down'] = 'Go Down';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Birthdays:';
$txt['events'] = 'Events:';
$txt['birthdays_upcoming'] = 'Upcoming Birthdays:';
$txt['events_upcoming'] = 'Upcoming Events:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Holidays:';
$txt['calendar_month'] = 'Month:';
$txt['calendar_year'] = 'Year:';
$txt['calendar_day'] = 'Day:';
$txt['calendar_event_title'] = 'Event Title';
$txt['calendar_event_options'] = 'Event Options';
$txt['calendar_post_in'] = 'Post In:';
$txt['calendar_edit'] = 'Edit Event';
$txt['event_delete_confirm'] = 'Delete this event?';
$txt['event_delete'] = 'Delete Event';
$txt['calendar_post_event'] = 'Post Event';
$txt['calendar'] = 'Naptár';
$txt['calendar_link'] = 'Link to Calendar';
$txt['calendar_upcoming'] = 'Upcoming Calendar';
$txt['calendar_today'] = 'Today\'s Calendar';
$txt['calendar_week'] = 'Week';
$txt['calendar_week_title'] = 'Week %1$d of %2$d';
$txt['calendar_numb_days'] = 'Number of Days:';
$txt['calendar_how_edit'] = 'how do you edit these events?';
$txt['calendar_link_event'] = 'Link Event To Post:';
$txt['calendar_confirm_delete'] = 'Are you sure you want to delete this event?';
$txt['calendar_linked_events'] = 'Linked Events';
$txt['calendar_click_all'] = 'click to see all %1$s';

$txt['moveTopic1'] = 'Post a redirection topic';
$txt['moveTopic2'] = 'Change the topic\'s subject';
$txt['moveTopic3'] = 'New subject';
$txt['moveTopic4'] = 'Change every message\'s subject';
$txt['move_topic_unapproved_js'] = 'Warning! This topic has not yet been approved.\\n\\nIt is not recommended that you create a redirection topic unless you intend to approve the post immediately following the move.';
$txt['movetopic_auto_board'] = '[BOARD]';
$txt['movetopic_auto_topic'] = '[TOPIC LINK]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Redirect to the moved topic';
$txt['movetopic_expires'] = 'Automatically remove the redirection topic';

$txt['merge_to_topic_id'] = 'ID of target topic';
$txt['split_topic'] = 'Split';
$txt['merge'] = 'Merge';
$txt['subject_new_topic'] = 'Subject For New Topic';
$txt['split_this_post'] = 'Only split this post.';
$txt['split_after_and_this_post'] = 'Split topic after and including this post.';
$txt['select_split_posts'] = 'Select posts to split.';

$txt['splittopic_notification'] = 'Post a message when the topic is split';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Move the new topic to another board';

$txt['new_topic'] = 'New Topic';
$txt['split_successful'] = 'Topic successfully split into two topics.';
$txt['origin_topic'] = 'Origin Topic';
$txt['please_select_split'] = 'Please select which posts you wish to split.';
$txt['merge_successful'] = 'Topics successfully merged.';
$txt['new_merged_topic'] = 'Newly Merged Topic';
$txt['topic_to_merge'] = 'Topic to be merged';
$txt['target_board'] = 'Target board';
$txt['target_topic'] = 'Target topic';
$txt['merge_confirm'] = 'Are you sure you want to merge';
$txt['with'] = 'with';
$txt['merge_desc'] = 'This function will merge the messages of two topics into one topic. The messages will be sorted according to the time of posting. Therefore the earliest posted message will be the first message of the merged topic.';

$txt['theme_template_error'] = 'Unable to load the \'%1$s\' template.';
$txt['theme_language_error'] = 'Unable to load the \'%1$s\' language file.';

$txt['parent_boards'] = 'Sub-boards';

$txt['smtp_no_connect'] = 'Could not connect to SMTP host';
$txt['smtp_port_ssl'] = 'SMTP port setting incorrect; it should be 465 for SSL servers.';
$txt['smtp_bad_response'] = 'Couldn\'t get mail server response codes';
$txt['smtp_error'] = 'Ran into problems sending Mail. Error: ';
$txt['mail_send_unable'] = 'Unable to send mail to the email address \'%1$s\'';

$txt['mlist_search'] = 'Search For Members';
$txt['mlist_search_again'] = 'Search again'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Search by email address';
$txt['mlist_search_group'] = 'Search by position';
$txt['mlist_search_name'] = 'Search by name';
$txt['mlist_search_website'] = 'Search by website';
$txt['mlist_search_results'] = 'Search results for';
$txt['mlist_search_by'] = 'Search by %1$s';

$txt['attach_downloaded'] = 'downloaded %1$d times';
$txt['attach_viewed'] = 'viewed %1$d times';

$txt['settings'] = 'Settings';
$txt['never'] = 'Never';
$txt['more'] = 'more';

$txt['hostname'] = 'Hostname';
$txt['you_are_post_banned'] = 'Sorry %1$s, you are banned from posting and sending personal messages on this forum.';
$txt['ban_reason'] = 'Reason';

$txt['add_poll'] = 'Add poll';
$txt['poll_options6'] = 'You may only select up to %1$s options.';
$txt['poll_remove'] = 'Remove Poll';
$txt['poll_remove_warn'] = 'Are you sure you want to remove this poll from the topic?';
$txt['poll_results_expire'] = 'Results will be shown when voting has closed';
$txt['poll_expires_on'] = 'Voting closes';
$txt['poll_expired_on'] = 'Voting closed';
$txt['poll_change_vote'] = 'Remove Vote';
$txt['poll_return_vote'] = 'Voting options';
$txt['poll_cannot_see'] = 'You cannot see the results of this poll at the moment.';

$txt['quick_mod_approve'] = 'Approve selected';
$txt['quick_mod_remove'] = 'Remove selected';
$txt['quick_mod_lock'] = 'Lock/Unlock selected';
$txt['quick_mod_sticky'] = 'Pin/Unpin selected';
$txt['quick_mod_move'] = 'Move selected to';
$txt['quick_mod_merge'] = 'Merge selected';
$txt['quick_mod_markread'] = 'Mark selected read';
$txt['quick_mod_go'] = 'Go';
$txt['quickmod_confirm'] = 'Are you sure you want to do this?';

$txt['spell_check'] = 'Spell Check';

$txt['quick_reply'] = 'Quick Reply';
$txt['quick_reply_warning'] = 'Warning! This topic is currently locked, only admins and moderators can reply.';
$txt['quick_reply_verification'] = 'After submitting your post you will be directed to the regular post page to verify your post %1$s.';
$txt['quick_reply_verification_guests'] = '(required for all guests)';
$txt['quick_reply_verification_posts'] = '(required for all users with less than %1$d posts)';
$txt['wait_for_approval'] = 'Note: this post will not display until it\'s been approved by a moderator.';

$txt['notification_enable_board'] = 'Are you sure you wish to enable notification of new topics for this board?';
$txt['notification_disable_board'] = 'Are you sure you wish to disable notification of new topics for this board?';
$txt['notification_enable_topic'] = 'Are you sure you wish to enable notification of new replies for this topic?';
$txt['notification_disable_topic'] = 'Are you sure you wish to disable notification of new replies for this topic?';

$txt['report_to_mod'] = 'Report Post';
$txt['issue_warning_post'] = 'Issue a warning because of this message';

$txt['like_post'] = 'Like';
$txt['unlike_post'] = 'Unlike';
$txt['likes'] = 'Likes';
$txt['liked_by'] = 'Liked by:';
$txt['liked_you'] = 'You';
$txt['liked_more'] = 'more';
$txt['likemsg_are_you_sure'] = 'You already liked this message, are you sure you want to remove your like?';

$txt['unread_topics_visit'] = 'Recent Unread Topics';
$txt['unread_topics_visit_none'] = 'No unread topics found since your last visit. <a href="{unread_all_url}" class="linkbutton">Click here to try all unread topics</a>';
$txt['unread_topics_all'] = 'All Unread Topics';
$txt['unread_replies'] = 'Updated Topics';

$txt['who_title'] = 'Who\'s Online';
$txt['who_and'] = ' and ';
$txt['who_viewing_topic'] = ' are viewing this topic.';
$txt['who_viewing_board'] = ' are viewing this board.';
$txt['who_member'] = 'Member';

// Current footer strings
$txt['valid_html'] = 'Valid HTML 5';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'Vendég';
$txt['guests'] = 'Guests';
$txt['user'] = 'User';
$txt['users'] = 'Users';
$txt['hidden'] = 'Hidden';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'Hidden';
$txt['buddy'] = 'Buddy';
$txt['buddies'] = 'Buddies';
$txt['most_online_ever'] = 'Most Online Ever';
$txt['most_online_today'] = 'Most Online Today';

$txt['merge_select_target_board'] = 'Select the target board of the merged topic';
$txt['merge_select_poll'] = 'Select which poll the merged topic should have';
$txt['merge_topic_list'] = 'Select topics to be merged';
$txt['merge_select_subject'] = 'Select subject of merged topic';
$txt['merge_custom_subject'] = 'Custom subject';
$txt['merge_enforce_subject'] = 'Change the subject of all the messages';
$txt['merge_include_notifications'] = 'Include notifications?';
$txt['merge_check'] = 'Merge?';
$txt['merge_no_poll'] = 'No poll';

$txt['response_prefix'] = 'Re: ';
$txt['current_icon'] = 'Current icon';
$txt['message_icon'] = 'Message icon';

$txt['smileys_current'] = 'Current Smiley Set';
$txt['smileys_none'] = 'No Smileys';
$txt['smileys_forum_board_default'] = 'Forum/Board Default';

$txt['search_results'] = 'Search Results';
$txt['search_no_results'] = 'Sorry, no matches were found';

$txt['totalTimeLogged2'] = ' days, ';
$txt['totalTimeLogged3'] = ' hours and ';
$txt['totalTimeLogged4'] = ' minutes.';
$txt['totalTimeLogged5'] = 'd ';
$txt['totalTimeLogged6'] = 'h ';
$txt['totalTimeLogged7'] = 'm';

$txt['approve_thereis'] = 'There is'; //Deprecated
$txt['approve_thereare'] = 'There are'; //Deprecated
$txt['approve_member'] = 'one member'; //Deprecated
$txt['approve_members'] = 'members'; //Deprecated
$txt['approve_members_waiting'] = 'awaiting approval.'; //Deprecated
$txt['approve_one_member_waiting'] = 'There is <a href="%1$s">one member</a> awaiting approval.';
$txt['approve_many_members_waiting'] = 'There are <a href="%1$s">%2$d members</a> awaiting approval.';

$txt['notifyboard_turnon'] = 'Do you want a notification email when someone posts a new topic in this board?';
$txt['notifyboard_turnoff'] = 'Are you sure you do not want to receive new topic notifications for this board?';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Find Members';
$txt['find_username'] = 'Name, username, or email address';
$txt['find_buddies'] = 'Show Buddies Only?';
$txt['find_wildcards'] = 'Allowed Wildcards: *, ?';
$txt['find_no_results'] = 'No results found';
$txt['find_results'] = 'Results';
$txt['find_close'] = 'Bezárás';

$txt['quickmod_delete_selected'] = 'Kiválasztott eltávolítása';
$txt['quickmod_split_selected'] = 'Split Selected';

$txt['show_personal_messages_heading'] = 'New messages';
$txt['show_personal_messages'] = 'You have <strong>%1$s</strong> unread personal messages in your inbox.<br /><br /><a href="%2$s">Go to your inbox</a>';

$txt['help_popup'] = 'A little lost? Let me explain:';

$txt['previous_next_back'] = 'previous topic';
$txt['previous_next_forward'] = 'next topic';

$txt['upshrink_description'] = 'Shrink or expand the header.';

$txt['mark_unread'] = 'Mark unread';

$txt['ssi_not_direct'] = 'Please don\'t access SSI.php by URL directly; you may want to use the path (%1$s) or add ?ssi_function=something.';
$txt['ssi_session_broken'] = 'SSI.php was unable to load a session!  This may cause problems with logout and other functions - please make sure SSI.php is included before *anything* else in all your scripts!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Preview post';
$txt['preview_fetch'] = 'Fetching preview...';
$txt['pm_error_while_submitting'] = 'The following error or errors occurred while sending this personal message:';
$txt['warning_while_submitting'] = 'Something happened, review it here:';
$txt['error_while_submitting'] = 'The message has the following error or errors that must be corrected before continuing:';
$txt['error_old_topic'] = 'Warning: this topic has not been posted in for at least %1$d days.<br />Unless you\'re sure you want to reply, please consider starting a new topic.';

$txt['split_selected_posts'] = 'Selected posts';
$txt['split_selected_posts_desc'] = 'The posts below will form a new topic after splitting.';
$txt['split_reset_selection'] = 'reset selection';

$txt['modify_cancel'] = 'Cancel';
$txt['mark_read_short'] = 'Mark Read';

$txt['hello_member_ndt'] = 'Hello';

$txt['unapproved_posts'] = 'Unapproved Posts (Topics: %1$d, Posts: %2$d)';

$txt['ajax_in_progress'] = 'Loading...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = 'There are currently %1$d moderator reports open.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'Click to see the new posts in %1$s';
$txt['verification'] = 'Verification';
$txt['visual_verification_hidden'] = 'Please leave this box empty';
$txt['visual_verification_description'] = 'Type the letters shown in the picture';
$txt['visual_verification_sound'] = 'Listen to the letters';
$txt['visual_verification_request_new'] = 'Request another image';

// @todo Send email strings - should move?
$txt['send_email'] = 'Send email';
$txt['send_email_disclosed'] = 'Note this will be visible to the recipient.';
$txt['send_email_subject'] = 'Email Subject';

$txt['ignoring_user'] = 'You are ignoring this user.';
$txt['show_ignore_user_post'] = '<em>[Show me the post.]</em>';

$txt['spider'] = 'Spider';
$txt['spiders'] = 'Spiders';
$txt['openid'] = 'OpenID';

$txt['downloads'] = 'Downloads';
$txt['filesize'] = 'File size';
$txt['subscribe_webslice'] = 'Subscribe to Webslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Restore Topic';
$txt['restore_message'] = 'Restore';
$txt['quick_mod_restore'] = 'Restore Selected';

// Editor prompt.
$txt['prompt_text_email'] = 'Please enter the email address.';
$txt['prompt_text_ftp'] = 'Please enter the FTP address.';
$txt['prompt_text_url'] = 'Please enter the URL you wish to link to.';
$txt['prompt_text_img'] = 'Enter image location';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Delete Item';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> has blocked %1$s access attempts in the last 7 days.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Templates: ';
$txt['debug_subtemplates'] = 'Sub templates: '; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Sub templates: ';
$txt['debug_language_files'] = 'Language files: ';
$txt['debug_sheets'] = 'Style sheets: ';
$txt['debug_javascript'] = 'Scripts: ';
$txt['debug_files_included'] = 'Files included: ';
$txt['debug_kb'] = 'KB.';
$txt['debug_show'] = 'show';
$txt['debug_cache_hits'] = 'Cache hits: ';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s bytes';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss for %2$s bytes';
$txt['debug_queries_used'] = 'Queries used: %1$d.';
$txt['debug_queries_used_and_warnings'] = 'Queries used: %1$d, %2$d warnings.';
$txt['debug_query_in_line'] = 'in <em>%1$s</em> line <em>%2$s</em>, ';
$txt['debug_query_which_took'] = 'which took %1$s seconds.';
$txt['debug_query_which_took_at'] = 'which took %1$s seconds at %2$s into request.';
$txt['debug_show_queries'] = '[Show Queries]';
$txt['debug_hide_queries'] = '[Hide Queries]';
$txt['debug_tokens'] = 'Tokens: ';
$txt['debug_browser'] = 'Browser ID: ';
$txt['debug_hooks'] = 'Hooks called: ';
$txt['debug_system_type'] = 'System: ';
$txt['debug_server_load'] = 'Server Load: ';
$txt['debug_script_mem_load'] = 'Script Memory Usage: ';
$txt['debug_script_cpu_load'] = 'Script CPU Time (user/system): ';

// Video embedding
$txt['preview_image'] = 'Video Preview Image';
$txt['ctp_video'] = 'Click to play video, double click to load video';
$txt['hide_video'] = 'Show/Hide video';
$txt['youtube'] = 'YouTube video:';
$txt['vimeo'] = 'Vimeo video:';
$txt['dailymotion'] = 'Dailymotion video:';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (click to show/hide)';

$txt['ok_uppercase'] = 'OK';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Warning';

$txt['via'] = 'via';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
