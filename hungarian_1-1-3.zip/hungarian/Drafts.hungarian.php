<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Vázlatok mutatása';
$txt['drafts_show_desc'] = 'Itt megtekintheted a vázlatjaidat. Innen tudod őket módosítani vagy törölni.';

// misc
$txt['drafts'] = 'Drafts';
$txt['draft_save'] = 'Vázlat mentése';
$txt['draft_save_note'] = 'Ez a hozzászólásod szövegét fogja mentetni, de a csatolmányokat, szavazásokat, eseményeket nem.';
$txt['draft_none'] = 'Nincs vázlatod';
$txt['draft_edit'] = 'Vázlat módosítása';
$txt['draft_load'] = 'Vázlatok betöltése';
$txt['draft_hide'] = 'Vázlatok elrejtése';
$txt['draft_delete'] = 'Vázlat törlése';
$txt['draft_days_ago'] = '%s napja';
$txt['draft_retain'] = 'Vissza lesz tartva még %s napig';
$txt['draft_remove'] = 'Távolítsd el ezt a vázlatot';
$txt['draft_remove_selected'] = 'Eltávolítód az összes kijelőlt vázlatot?';
$txt['draft_saved'] = 'A tartalom mentve lett, és elérhető lesz a <a href="%1$s">Vázlatok Mutatása</a> menüből.';
$txt['draft_pm_saved'] = 'A tartalom mentve lett, és elérhető lesz a <a href="%1$s">Vázlatok Mutatása</a> menüből.';

// Admin options
$txt['drafts_autosave_enabled'] = 'automatikus vázlat-mentés engedélyezése';
$txt['drafts_autosave_enabled_subnote'] = 'Autómatikusan menteni fogja a felhasználói vázlatokat megadott időnként. A felhasználónak rendelkezni kell a jogusoltsággal is.';
$txt['drafts_keep_days'] = 'Vázlatok megőrzésének ideje napokban';
$txt['drafts_keep_days_subnote'] = 'Írj be nullát hogy a végtelenségig megtartsd a vázlatokat';
$txt['drafts_autosave_frequency'] = 'Milyen gyakran legyenek mentve a vázlatok?';
$txt['drafts_autosave_frequency_subnote'] = 'A minimum érték 30 másodperc';
$txt['drafts_pm_enabled'] = 'Privát üzenet vázlatok mentésének engedélyezése';
$txt['drafts_post_enabled'] = 'Vázlatok mentésének engedélyezése';
$txt['drafts_none'] = 'Nincs tárgy';
$txt['drafts_saved'] = 'Vázlat sikeresen mentve';