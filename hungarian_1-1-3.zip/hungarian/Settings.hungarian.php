<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Alapértelmezett ElkArte téma. <br /><br /> Készítő ElkArte contributors';