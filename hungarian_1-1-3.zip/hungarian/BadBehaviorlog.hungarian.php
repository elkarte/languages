<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Date';
$txt['badbehaviorlog_protocol'] = 'Protokoll';
$txt['badbehaviorlog_method'] = 'Metódus';
$txt['badbehaviorlog_request'] = 'Kérés';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'Tag ID';
$txt['badbehaviorlog_username'] = 'FelhasználóNév';
$txt['badbehaviorlog_headers'] = 'Fejlécek';
$txt['badbehaviorlog_agent'] = 'Böngésző';
$txt['badbehaviorlog_entity'] = 'Hozzászólás';
$txt['badbehaviorlog_key'] = 'Kulcs';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Összes bejegyzés';
$txt['badbehaviorlog_error_valid_code'] = 'Indok kód';
$txt['badbehaviorlog_error_valid_response'] = 'HTTP Státusz';
$txt['badbehaviorlog_error_valid_explaination'] = 'HTTP Ok';
$txt['badbehaviorlog_error_valid_log'] = 'Részletek';
$txt['badbehaviorlog_log'] = 'RosszMagatartás napló';
$txt['badbehaviorlog_desc'] = 'A rossz magatartás bejegyzések itt találhatóak meg';
$txt['badbehaviorlog_details'] = 'További részletek';
$txt['badbehaviorlog_no_entries_found'] = 'Jelenleg nincs rossz magatartás bejegyzés';

$txt['badbehaviorlog_remove_selection'] = 'Kiválasztott eltávolítása';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Biztosan törölni szeretnéd a kiválasztott napló-bejegyzéseket?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Minden szűrt eredmény eltávolítása';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Biztosan törölni szeretnéd a kiválasztott szűrt eredményeket?';
$txt['badbehaviorlog_sure_remove'] = 'Biztosan teljesen ki akarod üríteni a rossz magatartás naplót?';

$txt['badbehaviorlog_remove'] = 'Kiválasztott törlése';
$txt['badbehaviorlog_removeall'] = 'Clear Log';
$txt['badbehaviorlog_clear_filter'] = 'Szűrő kitisztítása';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Típus filter alkalmazása';
$txt['badbehaviorlog_apply_filter'] = 'Filter alkalmazása';
$txt['badbehaviorlog_applying_filter'] = 'Filter alkalmazása';
$txt['badbehaviorlog_filter_only_member'] = 'Ennek a felhasználónak a rossz magatartás bejegyzéseit mutassa';
$txt['badbehaviorlog_filter_only_ip'] = 'Ennek az IP címnek a rossz magatartás bejegyzéseit mutassa';
$txt['badbehaviorlog_filter_only_session'] = 'Ennek a munkamenetnek a rossz magatartás bejegyzéseit mutassa';
$txt['badbehaviorlog_filter_only_headers'] = 'Ennek a címnek a rossz magatartás bejegyzéseit mutassa';
$txt['badbehaviorlog_filter_only_agent'] = 'Only show the entries with the same user agent';

$txt['badbehaviorlog_session'] = 'Munkamanet';
$txt['badbehaviorlog_error_url'] = 'A jegyzett oldal címe';

$txt['badbehaviorlog_reverse_direction'] = 'Reverse chronological order of list';
$txt['badbehaviorlog_filter_only_type'] = 'Only show the logs with this code';