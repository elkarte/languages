<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Carta de Aceptación';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'Acepto los terminos y condiciones';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Acepto los terminos y condiciones y tengo al menos %1$d de edad.';
$txt['agreement_agree_coppa_below'] = 'Acepto los terminos y condiciones y tengo menos de %1$d de edad.';
$txt['agree_coppa_above'] = 'I am at least %1$d years old.';
$txt['agree_coppa_below'] = 'I am younger than %1$d years old.';

// Registration form.
$txt['registration_form'] = 'Formulario de registro';
$txt['error_too_quickly'] = 'You went through the registration process too quickly, faster than should normally be possible. Please wait a moment and try again.';
$txt['error_token_verification'] = 'Token verification failed. Please try again.';
$txt['need_username'] = 'Debes escribir un nombre de usuario.';
$txt['no_password'] = 'No proporcionaste tu contraseña.';
$txt['improper_password'] = 'The supplied password is too long.';
$txt['incorrect_password'] = 'Contraseña incorrecta';
$txt['openid_not_found'] = 'Supplied OpenID identifier not found.';
$txt['maintain_mode'] = 'Modo de Mantenimiento';
$txt['registration_successful'] = 'Registro realizado con éxito';
$txt['valid_email_needed'] = 'Por favor introduce una dirección de correo válida, %1$s';
$txt['required_info'] = 'Información Requerida';
$txt['additional_information'] = 'Informacion Adicional';
$txt['warning'] = '¡Advertencia!';
$txt['only_members_can_access'] = 'Solamente usuarios registrados tienen acceso a esta sección.';
$txt['login_below'] = 'Please login below.';
$txt['login_below_or_register'] = 'Please login below or <a href="%1$s">register an account</a> with %2$s';
$txt['checkbox_agreement'] = 'I accept the registration agreement';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Password security has recently been upgraded.<br />Please enter your password again.';

$txt['ban_register_prohibited'] = 'Lo siento, no estás autorizado para registrarte en este foro';
$txt['under_age_registration_prohibited'] = 'Lo sentimos, pero no se permite el registro en este foro a personas menores de %1$d años de edad';

$txt['activate_account'] = 'Activación de la cuenta';
$txt['activate_success'] = 'Tu cuenta ha sido activada satisfactoriamente. Ahora puedes proceder a ingresar al foro.';
$txt['activate_not_completed1'] = 'Tu cuenta de email necesita ser validada antes de que puedas ingresar.';
$txt['activate_not_completed2'] = '¿Necesitas otro email de activación?';
$txt['activate_after_registration'] = 'Gracias por registrarte. Recibirás en breve un email con un enlace para activar tu cuenta.  Si despues de algunos minutos no recibes un email, revisa tu carpeta de correo no deseado (spam).';
$txt['invalid_userid'] = 'El usuario no existe';
$txt['invalid_activation_code'] = 'Código de activación inválido';
$txt['invalid_activation_username'] = 'Nombre de usuario o email';
$txt['invalid_activation_new'] = 'Si te registraste con una dirección de email incorrecta, escribe aquí una nueva junto con tu contraseña.';
$txt['invalid_activation_new_email'] = 'Nueva dirección de email';
$txt['invalid_activation_password'] = 'Contraseña anterior';
$txt['invalid_activation_resend'] = 'Reenviar código de activación';
$txt['invalid_activation_known'] = 'Si ya conoces tu código de activación, escríbelo aquí.';
$txt['invalid_activation_retry'] = 'Código de activación';
$txt['invalid_activation_submit'] = 'Activar';

$txt['coppa_no_concent'] = 'El administrador no ha recibido aún el consentimiento de tus padres/tutor para tu cuenta.';
$txt['coppa_need_more_details'] = '¿Necesitas más detalles?';

$txt['awaiting_delete_account'] = '¡Tu cuenta ha sido marcada para borrarse!<br />Si deseas restaurar tu cuenta, por favor selecciona la casilla "Reactivar mi cuenta", e ingresa nuevamente.';
$txt['undelete_account'] = 'Reactivar mi cuenta';

$txt['in_maintain_mode'] = 'Este foro está en modo de mantenimiento.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Por favor, lee/acepta los términos para poder enviar el formulario.';
$txt['register_passwords_differ_js'] = 'No coinciden las contraseñas.';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Gracias por registrarte. El administrador debe aprobar tu registro antes de que puedas empezar a usar tu cuenta, recibirás un email a la brevedad posible notificándote de la decisión del administrador.';

$txt['admin_settings_desc'] = 'Aquí puedes cambiar varios parámetros relacionados con el registro de nuevos usuarios.';

$txt['setting_enableOpenID'] = 'Permitir a los usuarios registrarse usando OpenID';

$txt['setting_registration_method'] = 'Metodo de registro empleado para miembros nuevos.';
$txt['setting_registration_disabled'] = 'Registro deshabilitado';
$txt['setting_registration_standard'] = 'Registro inmediato';
$txt['setting_registration_activate'] = 'Correo de activación';
$txt['setting_registration_approval'] = 'Aprobación de Miembro';
$txt['setting_notify_new_registration'] = 'Notificar a los administradores cuando un nuevo miembro se suscriba';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Enviar email de bienvenida a los nuevos miembros';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Limite de edad al cual aplicar restriciones de registro';
$txt['setting_coppaAge_desc'] = '(Ingresa 0 para desahabilitar)';
$txt['setting_coppaType'] = 'Acción a seguir cuando se registre un miembro por debajo de la edad mínima';
$txt['setting_coppaType_reject'] = 'Rechazar registro';
$txt['setting_coppaType_approval'] = 'Requerír aprobación de los padres/tutores';
$txt['setting_coppaPost'] = 'Dirección postal a donde se enviarán los formularios de aprobación';
$txt['setting_coppaPost_desc'] = 'Solo se aplica si la restricción de edad se cumple';
$txt['setting_coppaFax'] = 'Numero de fax a donde se enviarán los formularios de aprobación';
$txt['setting_coppaPhone'] = 'Número de contacto de los padres para consultar sobre la restricción de edad';

$txt['admin_register'] = 'Registro de un nuevo usuario';
$txt['admin_register_desc'] = 'Desde aquí puedes registrar en el foro nuevos usuarios y, de así desearlo, enviarles sus detalles por email.';
$txt['admin_register_username'] = 'Nuevo Nombre de usuario';
$txt['admin_register_email'] = 'Dirección Email';
$txt['admin_register_password'] = 'Contraseña';
$txt['admin_register_username_desc'] = 'Nombre de usuario para el nuevo usuario';
$txt['admin_register_email_desc'] = 'Dirección email del usuario<br />(requerida si seleccionaste la opción de enviarles por email sus detalles)';
$txt['admin_register_password_desc'] = 'Nueva contraseña para el usuario';
$txt['admin_register_email_detail'] = 'Enviar por email la nueva contraseña al usuario';
$txt['admin_register_email_detail_desc'] = 'Es necesaria la dirección email, aún si no está seleccionado';
$txt['admin_register_email_activate'] = 'Pedirle al usuario que active la cuenta';
$txt['admin_register_group'] = 'Grupo de usuario Primario';
$txt['admin_register_group_desc'] = 'Grupo de usuario primario al que el nuevo usuario pertenecerá';
$txt['admin_register_group_none'] = '(sin grupo primario)';
$txt['admin_register_done'] = '¡El usuario %1$s se ha registrado con éxito!';

$txt['coppa_title'] = 'Foro con restricción de edad';
$txt['coppa_after_registration'] = 'Thank you for registering with {forum_name_html_safe}.<br /><br />Because you fall under the age of {MINIMUM_AGE}, it is a legal requirement to obtain your parent or guardian\'s permission before you may begin to use your account.  To arrange for account activation please print off the form below:';
$txt['coppa_form_link_popup'] = 'Cargar la forma en una ventana nueva';
$txt['coppa_form_link_download'] = 'Descargar forma';
$txt['coppa_send_to_one_option'] = 'Entonces solicítale a tus padres/tutor que envíen la forma propiamente llenada por:';
$txt['coppa_send_to_two_options'] = 'Entonces solicítale a tus padres/tutor que envíen la forma propiamente llenada por cualquiera de estas dos opciones:';
$txt['coppa_send_by_post'] = 'Correo, a la siguiente dirección:';
$txt['coppa_send_by_fax'] = 'Fax, al siguiente número:';
$txt['coppa_send_by_phone'] = 'Alternativamente, haz que le hablen al administrador al número {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Permission form for registration at {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Dirección';
$txt['coppa_form_date'] = 'Fecha';
$txt['coppa_form_body'] = 'I {PARENT_NAME},<br /><br />give permission for {CHILD_NAME} (child name) to become a fully registered member of the forum: {forum_name_html_safe}, with the username: {USER_NAME}.<br /><br />I understand that certain personal information entered by {USER_NAME} may be shown to other users of the forum.<br /><br />Signed:<br />{PARENT_NAME} (Parent/Guardian).';

$txt['visual_verification_sound_again'] = 'Volver a escuchar';
$txt['visual_verification_sound_close'] = 'Cerrar ventana';
$txt['visual_verification_sound_direct'] = '¿Tienes problemas para oírlo?  Intenta un enlace directo.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Nombre de usuario disponible';
$txt['registration_username_unavailable'] = 'Nombre de usuario no disponible';
$txt['registration_username_check'] = 'Comprobar si el nombre de usuario está disponible';
$txt['registration_password_short'] = 'La contraseña es muy corta';
$txt['registration_password_reserved'] = 'La contraseña contiene tu nombre de usuario/email';
$txt['registration_password_numbercase'] = 'La contraseña debe contener minúsculas y mayúsculas, y números';
$txt['registration_password_no_match'] = 'Las contraseñas no concuerdan';
$txt['registration_password_valid'] = 'La contraseña es válida';

$txt['registration_errors_occurred'] = 'Los siguientes errores fueron detectados en tu registro. Por favor corrígelos y luego continúa:';

$txt['authenticate_label'] = 'Método para autentificarse';
$txt['authenticate_password'] = 'Contraseña';
$txt['authenticate_openid'] = 'OpenID';
$txt['authenticate_openid_url'] = 'URL de autenticación para OpenID';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'Contact the admins';
$txt['contact_your_message'] = 'Your message';
$txt['errors_contact_form'] = 'The following errors occurred while processing your contact request';
$txt['contact_subject'] = 'A guest has sent you a message';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
