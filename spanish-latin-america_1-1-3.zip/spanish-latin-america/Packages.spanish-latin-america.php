<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Proceder';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Listar archivos en el paquete (package)';
$txt['files_archive'] = 'Archivos en el archivo';
$txt['package_browse'] = 'Examinar';
$txt['add_server'] = 'Agregar servidor';
$txt['server_name'] = 'Nombre del servidor';
$txt['serverurl'] = 'URL';
$txt['no_packages'] = 'No hay paquetes';
$txt['download'] = 'Descargar';
$txt['download_success'] = 'Paquete descargado exitosamente';
$txt['package_downloaded_successfully'] = 'El paquete ha sido descargado exitosamente';
$txt['package_manager'] = 'Instalador de Paquetes';
$txt['install_mod'] = 'Install Add-on';
$txt['uninstall_mod'] = 'Uninstall Add-on';
$txt['no_adds_installed'] = 'No addons currently installed';
$txt['uninstall'] = 'Desinstalar';
$txt['delete_list'] = 'Delete Add-on List';
$txt['package_delete_list_warning'] = 'Are you sure you wish to clear the installed addons list?';

$txt['package_manager_desc'] = 'From this easy to use interface, you can download and install addons for use on your forum.';
$txt['installed_packages_desc'] = 'Puedes usar la siguiente interfaz para ver los paquetes instalados en tu foro actualmente, y eliminar los que ya no necesites.';
$txt['download_packages_desc'] = 'From this section you can add or remove package servers, browse for packages, or download new packages from servers.';
$txt['package_servers_desc'] = 'From this easy to use interface, you can manage your package servers and download addon archives on your forum.';
$txt['upload_packages_desc'] = 'From this section you can upload a package file from your local computer directly to the forum.';

$txt['upload_new_package'] = 'Upload new package';
$txt['view_and_remove'] = 'View and remove installed packages';
$txt['modification_package'] = 'Add-on packages';
$txt['avatar_package'] = 'Avatar packages';
$txt['language_package'] = 'Language packages';
$txt['unknown_package'] = 'Other packages';
$txt['smiley_package'] = 'Smiley packages';
$txt['use_avatars'] = 'Usar Avatars';
$txt['add_languages'] = 'Agregar idioma';
$txt['list_files'] = 'Listar archivos';
$txt['package_type'] = 'Tipo del Paquete';
$txt['extracting'] = 'Extrayendo';
$txt['avatars_extracted'] = 'The avatars have been installed, you should now be able to use them.';
$txt['language_extracted'] = 'The language pack has been installed, you can now enable its use in the language settings area of your admin control panel.';

$txt['mod_name'] = 'Add-on Name';
$txt['mod_version'] = 'Versión del Mod';
$txt['mod_author'] = 'Autor del Mod';
$txt['author_website'] = 'Sitio Web del autor';
$txt['package_no_description'] = 'No description given';
$txt['package_description'] = 'Descripción';
$txt['file_location'] = 'Descargar';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'No source edits';
$txt['mod_date'] = 'Last updated';
$txt['mod_section_count'] = 'Browse the (%1d) addons in this section';

// Package Server strings
$txt['package_current'] = '(%s <em>You have the Current version %s</em>)';
$txt['package_update'] = '(%s <em>An update for your %s version is available</em>)';
$txt['package_installed'] = 'installed';
$txt['package_downloaded'] = 'descargado';

$txt['package_installed_key'] = 'Installed addons:';
$txt['package_installed_current'] = 'versión actual';
$txt['package_installed_old'] = 'versión más vieja';
$txt['package_installed_warning1'] = 'This package is already installed, and no upgrade was found.';
$txt['package_installed_warning2'] = 'Debes desinstalar la versión anterior primero para evitar problemas, o favor de preguntar al autor del mod para crear una actualización desde la versión anterior.';
$txt['package_installed_warning3'] = 'Recuerda siempre hacer respaldos regulares de tus archivos fuente y de la base de datos antes de instalar algún mod, especialmente las versiones beta.';
$txt['package_installed_extract'] = 'Extrayendo Paquete';
$txt['package_installed_done'] = 'El paquete se ha instalado satisfactoriamente.  Ahora debes poder usar la funcionalidad que le agrega o cambia a tu foro; o de no poder usar la funcionalidad que elimina.';
$txt['package_installed_redirecting'] = 'Redireccionando...';
$txt['package_installed_redirect_go_now'] = 'Redireccionar Ahora';
$txt['package_installed_redirect_cancel'] = 'Volver al Manejador de Paquetes';

$txt['package_upgrade'] = 'Actualizar';
$txt['package_uninstall_readme'] = 'Leéme de la desinstalación';
$txt['package_install_readme'] = 'Léeme de la instalación';
$txt['package_install_license'] = 'License';
$txt['package_install_type'] = 'Tipo';
$txt['package_install_action'] = 'Acción';
$txt['package_install_desc'] = 'Descripción';
$txt['install_actions'] = 'Acciones de la Instalación';
$txt['perform_actions'] = 'This will perform the following actions:';
$txt['corrupt_compatible'] = 'The package you are trying to download or install is either corrupt or not compatible with this version of the software.';
$txt['package_create'] = 'Crear';
$txt['package_move'] = 'Mover';
$txt['package_delete'] = 'Eliminar';
$txt['package_extract'] = 'Extraer';
$txt['package_file'] = 'Archivo';
$txt['package_tree'] = 'Árbol';
$txt['execute_modification'] = 'Ejecutar Modificación';
$txt['execute_code'] = 'Ejecutar Código';
$txt['execute_database_changes'] = 'Execute file';
$txt['execute_hook_add'] = 'Add Hook';
$txt['execute_hook_remove'] = 'Remove Hook';
$txt['execute_hook_action'] = 'Adapting hook %1$s';
$txt['package_requires'] = 'Requires Modification';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Add Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'Acciones de Instalaciones para';
$txt['package_will_fail_title'] = 'Error in package %1$s';
$txt['package_will_fail_warning'] = 'At least one error was encountered during a test %1$s of this package.<br />It is <strong>strongly</strong> recommended that you do not continue with %1$s unless you know what you are doing, and have made a backup very recently.<br /><br />This error may be caused by a conflict between the package you\'re trying to install and another package you have already installed, an error in the package, a package which requires another package that you have not installed yet, or a package designed for another version of the software.';
$txt['package_will_fail_unknown_action'] = 'The package is trying to perform an unknown action: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Are you sure you wish to continue installing this addon, even though it will not install successfully?';
$txt['package_will_fail_popup_uninstall'] = 'Are you sure you wish to continue uninstalling this addon, even though it will not uninstall successfully?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'removal';
$txt['package_install_now'] = 'Install now';
$txt['package_uninstall_now'] = 'Uninstall now';
$txt['package_other_themes'] = 'Install in other themes';
$txt['package_other_themes_uninstall'] = 'UnInstall in other themes';
$txt['package_other_themes_desc'] = 'To use this addon in themes other than the default, the package manager needs to make additional changes to the other themes. If you\'d like to install this addon in the other themes, please select these themes below.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Al menos un error ha sido encontrado mientras se instalaba este tema. Estás seguro que deseas intentar la instalación?';

$txt['package_bytes'] = 'bytes';

$txt['package_action_missing'] = '<b class="error">Archivo no encontrado</b>  ';
$txt['package_action_error'] = '<b class="error">Error al parsear la modificación</b>';
$txt['package_action_failure'] = '<b class="error">Prueba fallida</b>';
$txt['package_action_success'] = '<b>Éxito</b>';
$txt['package_action_skipping'] = '<b>Omitiendo archivo</b>';

$txt['package_uninstall_actions'] = 'Desinstalar Acciones';
$txt['package_uninstall_done'] = 'The package has been successfully uninstalled.';
$txt['package_uninstall_cannot'] = 'This package cannot be uninstalled, because there is no uninstaller.<br /><br />Please contact the addon author for more information.';

$txt['package_install_options'] = 'Opciones de Instalación';
$txt['package_install_options_desc'] = 'Set various options for how the package manager installs addons, including backups and ftp access';
$txt['package_install_options_ftp_why'] = 'Usando FTP es la manera más fácil para chmod los archivos a escribibles para que el gestor de paquetes funcione correctamente y no lo tengas que hacer manualmente.<br />Aquí puedes especificar los valores de default para algunos campos.';
$txt['package_install_options_ftp_server'] = 'Servidor de FTP';
$txt['package_install_options_ftp_port'] = 'Puerto';
$txt['package_install_options_ftp_user'] = 'Nombre de Usuario';
$txt['package_install_options_make_backups'] = 'Crear versiones de respaldo de los archivos reemplazados con un tilde (~) al final de sus nombres.';
$txt['package_install_options_make_full_backups'] = 'Create an entire backup (excluding smileys, avatars and attachments) of the ElkArte install.';

$txt['package_ftp_necessary'] = 'Información requerida de FTP';
$txt['package_ftp_why'] = 'Some of the files the package manager needs to modify are not writable.  This needs to be changed by logging into FTP and using it to chmod or create the files and directories.  Your FTP information may be temporarily cached for proper operation of the package manager. Note you can also do this manually using an FTP client - <a href="#" onclick="%1$s">to view a list of the affected files please click here</a>.';
$txt['package_ftp_why_file_list'] = 'Los siguientes archivos deben hacerse modificables para continuar con la instalación:';
$txt['package_ftp_why_download'] = 'In order to download packages, the packages directory, and any files in it, must be writable.  Currently the system does not have the needed permissions to write to this directory.  The package manager can use your FTP information to attempt to fix this problem.';
$txt['package_ftp_server'] = 'Servidor de FTP';
$txt['package_ftp_port'] = 'Puerto';
$txt['package_ftp_username'] = 'Nombre de Usuario';
$txt['package_ftp_password'] = 'Contraseña';
$txt['package_ftp_path'] = 'Local path to ElkArte';
$txt['package_ftp_test'] = 'Probar';
$txt['package_ftp_test_connection'] = 'Prueba de Conexión';
$txt['package_ftp_test_success'] = 'Conección FTO establecida.';
$txt['package_ftp_test_failed'] = 'No se puede contactar al servidor.';
$txt['package_ftp_bad_server'] = 'No se puede contactar al servidor.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = '¡El paquete que estás a punto de borrar está instalado actualmente!  Si lo borras, no podrás desistalarlo después.\\n\\n¿Estás seguro?';

$txt['package_examine_file'] = 'Ver archivos del paquete';
$txt['package_file_contents'] = 'Contenido del archivo';

$txt['package_upload_title'] = 'Subir un paquete';
$txt['package_upload_select'] = 'Paquete a subir';
$txt['package_upload'] = 'Subir';
$txt['package_uploaded_success'] = 'Paquete subido satisfactoriamente';
$txt['package_uploaded_successfully'] = 'El paquete ha sido subido satisfactoriamente';

$txt['package_modification_malformed'] = 'Malformed or invalid addon file.';
$txt['package_modification_missing'] = 'No se encontró el archivo.';
$txt['package_no_zlib'] = 'Lo sentimos, tu configuración PHP no tiene soporte para <b>zlib</b>.  Sin esto, el gestor de paquetes no puede funcionar.  Por favor, contacta a tu provedor de alojamiento para mayor información.';

$txt['package_cleanperms_title'] = 'Restaurar Permisos';
$txt['package_cleanperms_desc'] = 'Este interfaz te permite restaurar los permisos para los archivos de tu instalación, para incrementar la seguridad o solventar cualquier problema de permisos que puedas encontrar al instalar paquetes.';
$txt['package_cleanperms_type'] = 'Establecer todos los permisos de archivos de toda la instalación del foro para que';
$txt['package_cleanperms_standard'] = 'Sólo los archivos estándar tengan permisos de escritura.';
$txt['package_cleanperms_free'] = 'Todos los archivos tengan permisos de escritura.';
$txt['package_cleanperms_restrictive'] = 'El mínimo de archivos tengan permisos de escritura.';
$txt['package_cleanperms_go'] = 'Ir';

$txt['package_download_by_url'] = 'Descargar un paquete por url';
$txt['package_download_filename'] = 'Nombre del archivo';
$txt['package_download_filename_info'] = 'Valor opcional. Debe usarse cuando la URL no termina en el nombre de archivo. Por ejemplo: index.php?mod=5';

$txt['package_db_uninstall'] = 'Remove all data associated with this addon.';
$txt['package_db_uninstall_details'] = 'Detalles';
$txt['package_db_uninstall_actions'] = 'Checking this option will result in the following actions';
$txt['package_db_remove_table'] = 'Borrar tabla "%1$s" ';
$txt['package_db_remove_column'] = 'Remove column "%1$s" from "%2$s"';
$txt['package_db_remove_index'] = 'Remover índice "%1$s" de "%2$s" ';

$txt['package_emulate_install'] = 'Install Emulating:';
$txt['package_emulate_uninstall'] = 'Uninstall Emulating:';

// Operations.
$txt['operation_find'] = 'Encontrar';
$txt['operation_replace'] = 'Reemplazar';
$txt['operation_after'] = 'Agregar Despues';
$txt['operation_before'] = 'Agregar Antes';
$txt['operation_title'] = 'Operaciones';
$txt['operation_ignore'] = 'Ignorar Errores';
$txt['operation_invalid'] = 'La opereacion que seleccionaste es invalida.';

$txt['package_file_perms_desc'] = 'Puedes usar esta sección para revisar el estado modificable de los archivos y carpetas críticos dentro del directorio de tu foro. Ten en cuenta que esto solo considera carpetas y archivos clave - usa un cliente de FTP para opciones adicionales.';
$txt['package_file_perms_name'] = 'File/Directory Name';
$txt['package_file_perms_status'] = 'Estado Actual';
$txt['package_file_perms_new_status'] = 'Nuevo Estado';
$txt['package_file_perms_status_read'] = 'Leer';
$txt['package_file_perms_status_write'] = 'Escribir';
$txt['package_file_perms_status_execute'] = 'Ejecutar';
$txt['package_file_perms_status_custom'] = 'Personalizados';
$txt['package_file_perms_status_no_change'] = 'Sin Cambio';
$txt['package_file_perms_writable'] = 'Escribible';
$txt['package_file_perms_not_writable'] = 'Escritura no permitida';
$txt['package_file_perms_chmod'] = 'chmod ';
$txt['package_file_perms_more_files'] = 'Más Archivos';

$txt['package_file_perms_change'] = 'Cambiar los Permisos de Archivo';
$txt['package_file_perms_predefined'] = 'Usar el perfíl de permisos predefinido';
$txt['package_file_perms_predefined_note'] = 'Note that this only applies the predefined profile to key directories and files.';
$txt['package_file_perms_apply'] = 'Aplicar permisos de archivo inidividuales seleccionado arriba.';
$txt['package_file_perms_custom'] = 'Si "Personalizado" ha sido seleccionado usa el valor chmod';
$txt['package_file_perms_pre_restricted'] = 'Restringido - minimos archivos escribibles';
$txt['package_file_perms_pre_standard'] = 'Estándar - archivos clave modificables';
$txt['package_file_perms_pre_free'] = 'Libre - todos los archivos modificables';
$txt['package_file_perms_ftp_details'] = 'En algunos servidores unicamente es posible cambiar los permisos de archivo usando una cuenta de FTP. Por favor ingresa los detalles de tu cuenta de FTP a continuación';
$txt['package_file_perms_ftp_retain'] = 'Note, the system will only retain the password information temporarily to aid operation of the package manager.';
$txt['package_file_perms_go'] = 'Hacer Cambios';

$txt['package_file_perms_applying'] = 'Aplicando Cambios';
$txt['package_file_perms_items_done'] = '%1$d de %2$d items completados ';
$txt['package_file_perms_skipping_ftp'] = '<strong>Atención:</strong> Falló la conexión al servidor FTP, intentando cambiar permisos. Esto es <em>propenso</em> a fallar - por favor revisa los resultados una vez terminado e intenta nuevamente con los detalles correctos de FTP si fuera necesario.';

$txt['package_file_perms_dirs_done'] = '%1$d de %2$d directorios completados ';
$txt['package_file_perms_files_done'] = '%1$d de %2$d archivos completados en el directorio actual ';

$txt['chmod_value_invalid'] = 'As intentado ingresar un valor de chmod incorrecto. Chmod debe ser entre 0444 y 0777';

$txt['package_restore_permissions'] = 'Restore file permissions';
$txt['package_restore_permissions_desc'] = 'The following file permissions were changed in order to install the selected package(s). You can return these files back to their original status by clicking &quot;Restore&quot; below.';
$txt['package_restore_permissions_restore'] = 'Restaurar';
$txt['package_restore_permissions_filename'] = 'Nombre del archivo';
$txt['package_restore_permissions_orig_status'] = 'Estado Original';
$txt['package_restore_permissions_cur_status'] = 'Estado Actual';
$txt['package_restore_permissions_result'] = 'Resultado';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s) ';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - fue %2$s) ';
$txt['package_restore_permissions_action_skipped'] = '<em>Saltado</em>  ';
$txt['package_restore_permissions_action_success'] = '<span class="success">Success</span>';
$txt['package_restore_permissions_action_failure'] = '<span class="error">Fallido</span>';
$txt['package_restore_permissions_action_done'] = 'An attempt to restore the selected files back to their original permissions has been completed, the results can be seen below. If a change failed, or for a more detailed view of file permissions, please see the <a href="%1$s">File Permissions</a> section.';

$txt['package_file_perms_warning'] = 'Por favor Nota';
$txt['package_file_perms_warning_desc'] = '
	Be careful when changing file permissions from this section - incorrect permissions can adversely affect the operation of your forum!<br />
	On some server configurations selecting the wrong permissions may stop the forum from operating.<br />
	Certain directories such as <em>attachments</em> need to be writable to use that functionality.<br />
	This functionality is mainly applicable on non-Windows based servers - it will not work as expected on Windows in regards to permission flags.<br />
	Before proceeding make sure you have an FTP client installed in case you do make an error and need to FTP into the server to remedy it.';

$txt['package_confirm_view_package_content'] = 'Estás seguro que deseas ver el contenido del paquete desde esta ubicación:<br /><br />%1$s ';
$txt['package_confirm_proceed'] = 'Proceder';
$txt['package_confirm_go_back'] = 'Ir atrás';

$txt['package_readme_default'] = 'En forma predeterminada';
$txt['package_available_readme_language'] = 'Leéme disponible en otros lenguajes:';
$txt['package_license_default'] = 'En forma predeterminada';
$txt['package_available_license_language'] = 'Available License Languages:';