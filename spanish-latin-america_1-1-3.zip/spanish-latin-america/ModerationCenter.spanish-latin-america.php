<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Centro de Moderación';
$txt['mc_main'] = 'Controles del Foro';
$txt['mc_logs'] = 'Registros';
$txt['mc_posts'] = 'Mensajes';
$txt['mc_groups'] = 'Members and groups';

$txt['mc_view_groups'] = 'Ver Grupos de usuario';

$txt['mc_description'] = '<strong>Welcome, %1$s!</strong><br />This is your &quot;Moderation Center&quot;. From here you can perform all the moderation actions assigned to yourself by the Administrator. This home page contains a summary of all the latest happenings in your community. You can <a href="%2$s">personalize the layout by clicking here</a>.';
$txt['mc_group_requests'] = 'Solicitud de Grupo';
$txt['mc_member_requests'] = 'Member Requests';
$txt['mc_unapproved_posts'] = 'Mensajes no aprobados';
$txt['mc_watched_users'] = 'Recently Watched Members';
$txt['mc_watched_topics'] = 'Temas Vigilados';
$txt['mc_scratch_board'] = 'Marcar moderador de foro';
$txt['mc_latest_news'] = 'Latest News';
$txt['mc_recent_reports'] = 'Informes de tema recientes';
$txt['mc_warnings'] = 'Advertencias';
$txt['mc_notes'] = 'Notas de Moderador';
$txt['mc_required'] = 'Items Requiring Approval';
$txt['mc_attachments'] = 'Attachments needing approval';
$txt['mc_emailmod'] = 'Email Postings needing approval';
$txt['mc_topics'] = 'Topics needing approval';
$txt['mc_posts'] = 'Mensajes';
$txt['mc_groupreq'] = 'Group requests needing approval';
$txt['mc_memberreq'] = 'Members needing approval';
$txt['mc_reports'] = 'Report posts needing approval';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['mc_recent_reports_none'] = 'No hay informes pendientes';
$txt['mc_watched_users_none'] = 'Actualmente no hay ninguno.';
$txt['mc_group_requests_none'] = 'No hay solicitudes de pertenencia a grupos.';

$txt['mc_seen'] = '%1$s visto por última vez %2$s';
$txt['mc_seen_never'] = '%1$s nunca visto';
$txt['mc_groupr_by'] = 'por';

$txt['mc_reported_posts_desc'] = 'Aquí usted puede revisar todos los mensajes reportados por los usuarios de la comunidad.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Reportes actuales';
$txt['mc_reportedp_closed'] = 'Reportes Antiguos';
$txt['mc_reportedp_by'] = 'por';
$txt['mc_reportedp_reported_by'] = 'Reportado por';
$txt['mc_reportedp_last_reported'] = 'último Reporte';
$txt['mc_reportedp_none_found'] = 'No se encontraron Reportes ';

$txt['mc_reportedp_details'] = 'Detalles';
$txt['mc_reportedp_close'] = 'Cerrar';
$txt['mc_reportedp_open'] = 'Abrir';
$txt['mc_reportedp_ignore'] = 'Dismiss';
$txt['mc_reportedp_unignore'] = 'Reopen';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Are you sure you wish to dismiss and ignore further reports about this message?

This will turn off further reports for all moderators of the forum.';
$txt['mc_reportedp_close_selected'] = 'Cerrar seleccionados';

$txt['mc_groupr_group'] = 'Grupos de Usuarios';
$txt['mc_groupr_member'] = 'Miembro';
$txt['mc_groupr_reason'] = 'Razón';
$txt['mc_groupr_none_found'] = 'Actualmente no hay solicitudes pendientes a grupos de Usuario.';
$txt['mc_groupr_submit'] = 'Enviar';
$txt['mc_groupr_reason_desc'] = 'Razón para rechazar %1$s\'s solicitud de adhesión "%2$s"';
$txt['mc_groups_reason_title'] = 'Reasons for rejection';
$txt['with_selected'] = 'With selected';
$txt['mc_groupr_approve'] = 'Approve request';
$txt['mc_groupr_reject'] = 'Reject request (No Reason)';
$txt['mc_groupr_reject_w_reason'] = 'Reject request with reason';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = '¿Está seguro que desea hacer esto?';

$txt['mc_unapproved_attachments_none_found'] = 'No hay adjuntos no aprobados!';
$txt['mc_unapproved_attachments_desc'] = 'From here you can approve or delete any attachments awaiting moderation.';
$txt['mc_unapproved_replies_none_found'] = 'No hay mensajes no aprobados!';
$txt['mc_unapproved_topics_none_found'] = 'No hay temas no aprobados!';
$txt['mc_unapproved_posts_desc'] = 'Desde aquí se puede aprobar o eliminar cualquier mensaje en espera de moderación.';
$txt['mc_unapproved_replies'] = 'Respuestas';
$txt['mc_unapproved_topics'] = 'Temas';
$txt['mc_unapproved_by'] = 'por';
$txt['mc_unapproved_sure'] = '¿Estás seguro que quieres hacer esto?';
$txt['mc_unapproved_attach_name'] = 'Attachment name';
$txt['mc_unapproved_attach_size'] = 'File size';
$txt['mc_unapproved_attach_poster'] = 'Usuario que publica';
$txt['mc_viewmodreport'] = 'Moderation report for %1$s by %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Los usuarios que han informado de este Mensaje';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Las medidas adoptadas por otros moderadores';
$txt['mc_modreport_mod_comments'] = 'Comentarios de moderador';
$txt['mc_modreport_no_mod_comment'] = 'Actualmente no hay ningún comentarios de moderador';
$txt['mc_modreport_add_mod_comment'] = 'Añadir comentario';

$txt['show_notice'] = 'Texto de noticias';
$txt['show_notice_subject'] = 'Tema';
$txt['show_notice_text'] = 'Texto';

$txt['mc_watched_users_title'] = 'Usuarios Vigilados';
$txt['mc_watched_users_desc'] = 'Aquí puede mantener un seguimiento de todos los usuarios a los que se le han asignado una "vigilancia" por el equipo de moderación.';
$txt['mc_watched_users_post'] = 'Ver por Mensaje';
$txt['mc_watched_users_warning'] = 'Nivel de advertencia';
$txt['mc_watched_users_last_login'] = 'Último ingreso';
$txt['mc_watched_users_last_post'] = 'Último mensaje';
$txt['mc_watched_users_no_posts'] = 'No hay mensajes de Usuario vistos.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = '¿Estás seguro que quieres eliminar este mensaje?';
$txt['mc_watched_users_delete_posts'] = '¿Estás seguro que quieres eliminar estos mensajes?';
$txt['mc_watched_users_posted'] = 'Publicado';
$txt['mc_watched_users_member'] = 'Miembro';

$txt['mc_warnings_description'] = 'Desde esta sección puede ver qué advertencias han sido expedidas a los usuarios del foro. También puede agregar y modificar las plantillas de notificación que utilizan al enviar un aviso.';
$txt['mc_warning_log'] = 'Registro de advertencia';
$txt['mc_warning_templates'] = 'Plantillas personalizadas';
$txt['mc_warning_log_title'] = 'Viewing warning log';
$txt['mc_warning_templates_title'] = 'Custom warning templates';

$txt['mc_warnings_none'] = 'No warnings have been issued.';
$txt['mc_warnings_recipient'] = 'Destinatario';

$txt['mc_warning_templates_none'] = 'No se han creado plantillas de avisos';
$txt['mc_warning_templates_time'] = 'Hora de creación';
$txt['mc_warning_templates_name'] = 'Plantilla';
$txt['mc_warning_templates_creator'] = 'Creada por';
$txt['mc_warning_template_add'] = 'Añadir plantilla';
$txt['mc_warning_template_modify'] = 'Editar plantilla';
$txt['mc_warning_template_delete'] = 'Borrar seleccionados';
$txt['mc_warning_template_delete_confirm'] = '¿Está seguro que desea eliminar las plantillas seleccionadas?';

$txt['mc_warning_template_desc'] = 'Use this page to fill in the details of the template. Note that the subject for the email is not part of the template. Note that as the notification is sent by PM you can use BBC within the template. If you use the {MESSAGE} variable then this template will not be available when issuing a generic warning (i.e. A warning not linked to a post).';
$txt['mc_warning_template_title'] = 'Titulo de la plantilla';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Plantilla Personal';
$txt['mc_warning_template_personal_desc'] = 'Si selecciona esta opción sólo podrás ver, editar y utilizar esta plantilla. Si no se selecciona todos los moderadores serán capaces de usar esta plantilla.';
$txt['mc_warning_template_error_no_title'] = 'You must set the title.';
$txt['mc_warning_template_error_no_body'] = 'You must set the notification body.';

$txt['mc_settings'] = 'Cambiar configuraciones';
$txt['mc_prefs_title'] = 'Preferencias de moderación';
$txt['mc_prefs_desc'] = 'Esta sección le permite establecer algunas preferencias personales a la moderación tales como notificaciones por correo electrónico.';
$txt['mc_prefs_homepage'] = 'Elementos que mostrara la página de inicio de moderación ';
$txt['mc_prefs_latest_news'] = 'ElkArte News';
$txt['mc_prefs_show_reports'] = 'Mostrar recuento de informe abierto en el foro de cabecera';
$txt['mc_prefs_notify_report'] = 'Notificaciones de los temas reportados';
$txt['mc_prefs_notify_report_never'] = 'Nunca';
$txt['mc_prefs_notify_report_moderator'] = 'Sólo si se trata de un foro que moderada';
$txt['mc_prefs_notify_report_always'] = 'Siempre';
$txt['mc_prefs_notify_approval'] = 'Notificaciones de los temas pendientes de aprobación';
$txt['mc_logoff'] = 'End Moderator Session';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Añadir una nueva nota';
$txt['mc_add_note'] = 'Añadir';