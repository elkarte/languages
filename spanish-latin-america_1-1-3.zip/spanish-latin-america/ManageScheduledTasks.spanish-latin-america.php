<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Tareas programadas';
$txt['scheduled_tasks_header'] = 'Todas las tareas programadas';
$txt['scheduled_tasks_name'] = 'Nombre de la tarea';
$txt['scheduled_tasks_next_time'] = 'Siguiente';
$txt['scheduled_tasks_regularity'] = 'Regularidad';
$txt['scheduled_tasks_enabled'] = 'Activado';
$txt['scheduled_tasks_run_now'] = 'Ejecutar';
$txt['scheduled_tasks_save_changes'] = 'Guardar Cambios';
$txt['scheduled_tasks_time_offset'] = '<strong>Note:</strong> All times given below are <em>server time</em> and do not take any time offsets setup within the admin panel into account.';
$txt['scheduled_tasks_were_run'] = 'Todas las tareas seleccionadas se completaron';
$txt['scheduled_tasks_were_run_errors'] = 'The following errors occurred while running the scheduled tasks:';

$txt['scheduled_tasks_na'] = ' N/A';
$txt['scheduled_task_approval_notification'] = 'Notificaciones de aprobación';
$txt['scheduled_task_desc_approval_notification'] = 'Enviar por email un resumen de los mensajes pendientes de aprobación a todos los moderadores.';
$txt['scheduled_task_auto_optimize'] = 'Optimizar la base de datos';
$txt['scheduled_task_desc_auto_optimize'] = 'Optimizar la base de datos para resolver problemas de fragmentación.';
$txt['scheduled_task_daily_maintenance'] = 'Mantenimiento diario';
$txt['scheduled_task_desc_daily_maintenance'] = 'Ejecuta mantenimiento diario esencial en el foro "no debe ser desactivada".';
$txt['scheduled_task_daily_digest'] = 'Resumen de notificación diaria';
$txt['scheduled_task_desc_daily_digest'] = 'Mensajes de email con resumen diario para los suscriptores de notificación.';
$txt['scheduled_task_weekly_digest'] = 'Resumen de notificación semanal';
$txt['scheduled_task_desc_weekly_digest'] = 'Mensajes de email con resumen semanal para los suscriptores de notificación.';
$txt['scheduled_task_birthdayemails'] = 'Enviar mensajes de Cumpleaños por email';
$txt['scheduled_task_desc_birthdayemails'] = 'Envía mensajes de email de feliz cumpleaños que los usuarios deseen.';
$txt['scheduled_task_weekly_maintenance'] = 'Mantenimiento semanal';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Ejecuta mantenimiento semanal esencial en el foro "no debe ser desactivada".';
$txt['scheduled_task_paid_subscriptions'] = 'Verificar Suscripción de pago';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Enviar recordatorios de pago en la suscripción y eliminar suscripciones de usuarios que hayan expirado.';
$txt['scheduled_task_remove_topic_redirect'] = 'Remove MOVED: Redirection Topics';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Deletes "MOVED:" topic notifications as specified when the moved notice was created.';
$txt['scheduled_task_remove_temp_attachments'] = 'Remove Temporary Attachment Files';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Deletes temporary files created while attaching a file to a post that for any reason weren\'t renamed or deleted before.';
$txt['scheduled_task_remove_old_drafts'] = 'Remove Old Drafts';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Deletes drafts older than the number of days defined in the draft settings in the admin panel.';
$txt['scheduled_task_remove_old_followups'] = 'Remove Old Follow-ups';
$txt['scheduled_task_desc_remove_old_followups'] = 'Deletes follow-up entries still present in the database, but pointing to non-existent topics.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Fetch Emails from IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Fetches emails for the mailing list feature from an IMAP box and processes them.';
$txt['scheduled_task_user_access_mentions'] = 'Users Mentions Access';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verify users access to each board and set accessibility to related mentions accordingly.';

$txt['scheduled_task_reg_starting'] = 'A partir de las %1$s';
$txt['scheduled_task_reg_repeating'] = 'Repetir cada %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minuto(s)';
$txt['scheduled_task_reg_unit_h'] = 'hora(s)';
$txt['scheduled_task_reg_unit_d'] = 'día(s)';
$txt['scheduled_task_reg_unit_w'] = 'semana(s)';

$txt['scheduled_task_edit'] = 'Editar tarea programada';
$txt['scheduled_task_edit_repeat'] = 'Repetir la tarea cada';
$txt['scheduled_task_edit_pick_unit'] = 'Elija la unidad';
$txt['scheduled_task_edit_interval'] = 'Intervalo';
$txt['scheduled_task_edit_start_time'] = 'Hora de inicio';
$txt['scheduled_task_edit_start_time_desc'] = 'El tiempo de primera instancia debe comenzar (horas: minutos)';
$txt['scheduled_task_time_offset'] = 'Nota: La hora de inicio debe ser con respecto a la del servidor. La hora del servidor actual es: %1$s';

$txt['scheduled_view_log'] = 'Ver registro';
$txt['scheduled_log_empty'] = 'Actualmente no hay entradas de registro de tareas.';
$txt['scheduled_log_time_run'] = 'Tiempo de ejecución';
$txt['scheduled_log_time_taken'] = 'Duración';
$txt['scheduled_log_time_taken_seconds'] = 'segundos';
$txt['scheduled_log_completed'] = 'Task completed';
$txt['scheduled_log_empty_log'] = 'Clear Log';
$txt['scheduled_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log?';