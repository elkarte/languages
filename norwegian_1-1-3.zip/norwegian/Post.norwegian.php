<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Skriv svar';
$txt['post_in_board'] = 'Post in the board';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Sett inn sitat';
$txt['disable_smileys'] = 'Disable smileys';
$txt['dont_use_smileys'] = 'Ikke bruk smilefjes.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Skrevet:';
$txt['standard'] = 'Standard';
$txt['thumbs_up'] = 'Tommel opp';
$txt['thumbs_down'] = 'Tommel ned';
$txt['exclamation_point'] = 'Utropstegn';
$txt['question_mark'] = 'Spørsmåltegn';
$txt['icon_poll'] = 'avstemning';
$txt['lamp'] = 'Lampe';
$txt['add_smileys'] = 'Add smileys';
$txt['topic_notify_no'] = 'There are no topics with notification.';

$txt['rich_edit_wont_work'] = 'Din nettleser støtter ikke Rich Text redigering.';
$txt['rich_edit_function_disabled'] = 'Din nettleser støtter ikke denne funksjonen.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Deaktiver varsling på dette emnet ved å klikke her';

$txt['lock_after_post'] = 'Steng emnet etter dette innlegget';
$txt['notify_replies'] = 'Varsle meg ved svar.';
$txt['lock_topic'] = 'Steng dette emnet.';
$txt['shortcuts'] = 'shortcuts: shift+alt+s submit/post or shift+alt+p preview';
$txt['shortcuts_drafts'] = 'shortcuts: shift+alt+s submit/post, shift+alt+p preview or shift+alt+d save draft';
$txt['option'] = 'Alternativ';
$txt['reset_votes'] = 'Reset vote count';
$txt['reset_votes_check'] = 'Klikk på dette for å tilbakestille alle stemmene til 0.';
$txt['votes'] = 'stemmer';
$txt['attach'] = 'Legg ved';
$txt['clean_attach'] = 'Clear attachment';
$txt['attached'] = 'Vedlegg'; // @deprecated since 1.1
$txt['allowed_types'] = 'Tillatte filtyper';
$txt['cant_upload_type'] = 'You cannot upload that type of file. The only allowed extensions are %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Fjern avkryssingen ved de vedleggene du vil slette.'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Det er et begrenset filnavn. Vennligst prøv et annet filnavn.';
$txt['topic_locked_no_reply'] = 'Warning! This topic is currently/will be locked<br />Only admins and moderators can reply.';
$txt['attachment_requires_approval'] = 'Merk at alle filer som er lagt til, vil ikke vises før etter godkjennelse av en moderator.';
$txt['error_temp_attachments'] = 'There are attachments found, which you have attached before but not posted. These attachments are now attached to this post. If you do not want to include them in this post, <a href="#postAttachment">you can remove them here</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Påminnelse: Dette innlegget vil ikke vises før det er godkjent av en moderator.';

$txt['enter_comment'] = 'Skriv kommentar';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Rapportert innlegg';
$txt['reported_to_mod_by'] = 'av';
$txt['rtm10'] = 'Send';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Følgende innlegg, "%1$s" av';
$txt['reported_by'] = 'har blitt rapportert';
$txt['board_moderate'] = 'på et forum hvor du er modererator';
$txt['report_comment'] = 'Den som rapporterte har vedlagt følgende kommentar';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximum total size %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximum individual size %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d pr innlegg';
$txt['attach_restrictions'] = 'Restriksjoner:';

$txt['post_additionalopt_attach'] = 'Vedlegg og andre alternativer';
$txt['post_additionalopt'] = 'Other options';
$txt['sticky_after'] = 'Pin this topic.';
$txt['move_after2'] = 'Flytt emnet.';
$txt['back_to_topic'] = 'Gå tilbake til emnet.';
$txt['approve_this_post'] = 'Approve this post';

$txt['retrieving_quote'] = 'Retrieving quote...';

$txt['post_visual_verification_label'] = 'Bekreftelse';
$txt['post_visual_verification_desc'] = 'Tast inn koden i bildet over for å legge til dette innlegget.';

$txt['poll_options'] = 'Avstemningsinnstillinger';
$txt['poll_run'] = 'La avstemningen vare i';
$txt['poll_run_limit'] = '(La stå tomt for ubegrenset.)';
$txt['poll_results_visibility'] = 'Resultat';
$txt['poll_results_anyone'] = 'Vis resultater til alle.';
$txt['poll_results_voted'] = 'Vis resultater bare etter at noen har stemt.';
$txt['poll_results_after'] = 'Vis resultater etter at avstemningen er avsluttet.';
$txt['poll_max_votes'] = 'Maksimalt antall stemmer per bruker';
$txt['poll_do_change_vote'] = 'Tillat brukere å endre stemme';
$txt['poll_too_many_votes'] = 'Du valgte for mange alternativer - for denne avstemning er antall maks %1$s';
$txt['poll_add_option'] = 'Legg til alternativ';
$txt['poll_guest_vote'] = 'Tillat gjester å stemme';

$txt['spellcheck_done'] = 'Stavekontrollen er fullført.';
$txt['spellcheck_change_to'] = 'Endre til:';
$txt['spellcheck_suggest'] = 'Forslag:';
$txt['spellcheck_change'] = 'Endre';
$txt['spellcheck_change_all'] = 'Endre alle';
$txt['spellcheck_ignore'] = 'Ignorer';
$txt['spellcheck_ignore_all'] = 'Ignorer alle';

$txt['more_attachments'] = 'flere vedlegg';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Beklager, men du har ikke tilgang til ta med flere vedlegg.';

$txt['more_smileys'] = 'flere';
$txt['more_smileys_title'] = 'Ekstra smilefjes';
$txt['more_smileys_pick'] = 'Velg et smilefjes';
$txt['more_smileys_close_window'] = 'Steng vindu';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = 'Send en kunngjøring om dette emnet til medlemmene:';
$txt['announce_title'] = 'Send en kunngjøring';
$txt['announce_desc'] = 'Dette skjemaet lar deg sende en kunngjøring om dette emnet til utvalgte medlemsgrupper.';
$txt['announce_sending'] = 'Sender kunngjøring om emnet';
$txt['announce_done'] = 'Ferdig';
$txt['announce_continue'] = 'Fortsett';
$txt['announce_topic'] = 'Kunngjør emnet.';
$txt['announce_regular_members'] = 'Vanlige medlemmer';

$txt['digest_subject_daily'] = 'Daglig oppsummering';
$txt['digest_subject_weekly'] = 'Ukentlig oppsummering';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'The following topics were started';
$txt['digest_new_topics_line'] = '"%1$s" in the %2$s board';
$txt['digest_new_replies'] = 'Svar har blitt gjort i følgende emner';
$txt['digest_new_replies_one'] = '1 svar i "%1$s"';
$txt['digest_new_replies_many'] = '%1$d svar i "%2$s"';
$txt['digest_mod_actions'] = 'Følgende moderatorhandlinger har funnet sted';
$txt['digest_mod_act_sticky'] = '"%1$s" was pinned';
$txt['digest_mod_act_lock'] = '"%1$s" ble låst';
$txt['digest_mod_act_unlock'] = '"%1$s" ble åpnet';
$txt['digest_mod_act_remove'] = '"%1$s" ble fjernet';
$txt['digest_mod_act_move'] = '"%1$s" ble flyttet';
$txt['digest_mod_act_merge'] = '"%1$s" ble slått sammen';
$txt['digest_mod_act_split'] = '"%1$s" ble delt';

$txt['attach_error_title'] = 'Error uploading attachments.';
$txt['attach_warning'] = 'There was a problem during the uploading of <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Sorry, you are out of attachment space. The total attachment size allowed per post is %1$s KB. Space remaining is %2$s KB.';
$txt['attach_folder_warning'] = 'The attachments directory can not be located. Please notify an administrator of this problem.';
$txt['attach_folder_admin_warning'] = 'The path to the attachments directory (%1$s) is incorrect. Please correct it in the attachment settings area of your admin panel.';
$txt['attach_limit_nag'] = 'You have reached the maximum number of attachments allowed per post.';
$txt['attach_no_upload'] = 'There was a problem and your attachments could not be uploaded';
$txt['attach_remaining'] = '%1$d remaining';
$txt['attach_available'] = '%1$s KB available';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'The file appears to be empty. Please contact your forum administrator if this continues to be a problem';
$txt['attached_files_in_session'] = '<em>The above underlined file(s) have been uploaded but will not be attached to this post until it is submitted.</em>';

$txt['attach_php_error'] = 'Due to an error, your attachment could not be uploaded. Please contact the forum administrator if this problem continues.';
$txt['php_upload_error_1'] = 'The uploaded file exceeds the upload_max_filesize directive in php.ini. Please contact your host if you are unable to correct this issue.';
$txt['php_upload_error_3'] = 'The uploaded file was only partially uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_4'] = 'No file was uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_6'] = 'Unable to save. Missing a temporary directory. Please contact your host if you are unable to correct this problem.';
$txt['php_upload_error_7'] = 'Failed to write file to disk. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_8'] = 'A PHP extension stopped the file upload. This is a PHP related error. Please contact your host if this problem continues.';
$txt['error_temp_attachments_new'] = 'There are attachments which you had previously attached but not posted. These attachments are still attached to this post. This post does need to be submitted before these attachments are either saved or removed. You <a href="#postAttachment">can do that here</a>';
$txt['error_temp_attachments_found'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not post until these are either removed or that post has been submitted.<br />Click <a href="%1$s">here to remove </a>those attachments. Or <a href="%2$s">here to return to that post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not upload any more attachments until these are removed or that post has been submitted.<br />Click <a href="%1$s">here to remove these attachments</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Those attachments have now been removed and you have been returned to the page you were previously on';
$txt['error_temp_attachments_flushed'] = 'Please note that any files which had been previously attached, but not posted, have now been removed.';
$txt['error_topic_already_announced'] = 'Please note that this topic has already been announced.';

$txt['cant_access_upload_path'] = 'Fikk ikke tilgang til mappen hvor vedleggene lagres!';
$txt['file_too_big'] = 'Your file is too large. The maximum attachment size allowed is %1$s KB.';
$txt['attach_timeout'] = 'Vedlegget kunne ikke lagres. Dette kan være fordi opplastningshastigheten er for treg eller at filen er større en det serveren tillater. Ta kontakt med administrator for mer informasjon.';
$txt['bad_attachment'] = 'Ditt vedlegg ble ikke godkjent i  sikkerhetssjekken og kan ikke lastes opp. Ta kontakt med forumets administrator.';
$txt['ran_out_of_space'] = 'The upload directory is full. Please contact an administrator about this problem.';
$txt['attachments_no_write'] = 'Lagringsområdet for opplastinger er ikke skrivbart. Ditt vedlegg eller din avatar kan ikke lagres.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory.  Your attachment or avatar cannot be saved.';
$txt['attachments_limit_per_post'] = 'Du kan ikke laste opp mer enn %1$d vedlegg per innlegg';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Insert';
$txt['ila_opt_size'] = 'Størrelse';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Ingen';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Center';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/