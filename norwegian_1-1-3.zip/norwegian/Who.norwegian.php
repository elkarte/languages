<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... no idea, sorry</em>';
$txt['who_admin'] = 'Viewing the admin portal';
$txt['who_moderate'] = 'Viewing the moderator portal';
$txt['who_generic'] = 'Viewing the %1$s';
$txt['who_unknown'] = '<em>Ukjent handling</em>';
$txt['who_user'] = 'Bruker';
$txt['who_time'] = 'Tid';
$txt['who_action'] = 'Handling';
$txt['who_show1'] = 'Vis ';
$txt['who_show_members_only'] = 'Kun medlemmer';
$txt['who_show_guests_only'] = 'Kun gjester';
$txt['who_show_spiders_only'] = 'Kun indekseringsrobot';
$txt['who_show_all'] = 'Alle';
$txt['who_no_online_spiders'] = 'Det er ingen indekseringsrobot på siden.';
$txt['who_no_online_guests'] = 'Det er ingen gjester på siden.';
$txt['who_no_online_members'] = 'Det er ingen brukere på siden.';

$txt['whospider_login'] = 'Leser innloggingssiden.';
$txt['whospider_register'] = 'Leser registreringssiden.';
$txt['whospider_reminder'] = 'Leser påminnelsessiden.';

$txt['whoall_activate'] = 'Aktiverer medlemskontoen sin.';
$txt['whoall_buddy'] = 'Endrer vennelisten sin.';
$txt['whoall_coppa'] = 'Fylle ut foreldre/foresatte skjema.';
$txt['whoall_credits'] = 'Leser side for medvirkende.';
$txt['whoall_emailuser'] = 'Sender e-post til et annet medlem.';
$txt['whoall_groups'] = 'Viser medlemsgruppesiden.';
$txt['whoall_help'] = 'Viewing the <a href="{help_url}">help page</a>.';
$txt['whoall_quickhelp'] = 'Leser en hjelpe-popup.';
$txt['whoall_pm'] = 'Sjekker sine private meldinger.';
$txt['whoall_auth'] = 'Logger inn på forumet.';
$txt['whoall_login'] = 'Leser innloggingssiden.';
$txt['whoall_login2'] = 'Leser innloggingssiden.';
$txt['whoall_logout'] = 'Logger ut fra forumet.';
$txt['whoall_markasread'] = 'Markerer emner som lest.';
$txt['whoall_mentions'] = 'Viewing their mentions list.';
$txt['whoall_modifykarma_applaud'] = 'Gir ett medlem positiv karma.';
$txt['whoall_modifykarma_smite'] = 'Gir ett medlem negativ karma.';
$txt['whoall_news'] = 'Leser nyhetene.';
$txt['whoall_notify'] = 'Redigerer sine varslingsinnstillinger.';
$txt['whoall_notifyboard'] = 'Redigerer sine varslingsinnstillinger.';
$txt['whoall_openidreturn'] = 'Logger inn ved bruk av OpenID.';
$txt['whoall_quickmod'] = 'Modeerer ett Forum.';
$txt['whoall_recent'] = 'Viewing a <a href="{recent_url}">list of recent topics</a>.';
$txt['whoall_register'] = 'Registrerer seg på forumet.';
$txt['whoall_reminder'] = 'Ber om en passordpåminnelse.';
$txt['whoall_reporttm'] = 'Rapporterer et emne til en moderator.';
$txt['whoall_spellcheck'] = 'Bruker stavekontrollen';
$txt['whoall_unread'] = 'Viser uleste emner siden siste besøk.';
$txt['whoall_unreadreplies'] = 'Viser uleste svar siden siste besøk.';
$txt['whoall_who'] = 'Viewing <a href="{who_url}">Who\'s Online</a>.';

$txt['whoall_collapse_collapse'] = 'Sammenfolde en kategori.';
$txt['whoall_collapse_expand'] = 'Utvider en kategori.';
$txt['whoall_pm_removeall'] = 'Sletter alle sine private meldinger.';
$txt['whoall_pm_send'] = 'Sender en PM.';
$txt['whoall_pm_send2'] = 'Sender en PM.';

$txt['whotopic_announce'] = 'Announcing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Godkjenne et vedlegg.';
$txt['whotopic_dlattach'] = 'Viser et vedlegg.';
$txt['whotopic_deletemsg'] = 'Sletter en melding.';
$txt['whotopic_editpoll'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Editing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Modifying a post in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Liking a message in the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Locking the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Locking the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Merging the topic &quot;<a href="%1$s">%2$s</a>&quot; with another topic.';
$txt['whotopic_movetopic'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_movetopic2'] = 'Moving the topic &quot;<a href="%1$s">%2$s</a>&quot; to another board.';
$txt['whotopic_post'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Posting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Printing the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderating the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Removing the poll in &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Removing the topic <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Sending the topic &quot;<a href="%1$s">%2$s</a>&quot; to a friend.';
$txt['whotopic_splittopics'] = 'Splitting the topic &quot;<a href="%1$s">%2$s</a>&quot; into two topics.';
$txt['whotopic_sticky'] = 'Pinned the topic &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Stopped watching a topic.';
$txt['whotopic_vote'] = 'Voting in <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Started watching a topic.';

$txt['whopost_quotefast'] = 'Quoting a post from &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Redigerer registreringsavtalen.';
$txt['whoadmin_featuresettings'] = 'Endrer forumets innstillinger og alternativer.';
$txt['whoadmin_modlog'] = 'Leser moderatorloggen.';
$txt['whoadmin_serversettings'] = 'Endrer forumets serverinnstillinger.';
$txt['whoadmin_packageget'] = 'Henter pakker.';
$txt['whoadmin_packages'] = 'Viser pakkebehandleren.';
$txt['whoadmin_permissions'] = 'Redigerer forumets rettigheter.';
$txt['whoadmin_pgdownload'] = 'Laster ned en pakke.';
$txt['whoadmin_theme'] = 'Redigerer designinnstillingene.';
$txt['whoadmin_trackip'] = 'Sporer en IP-adresse.';

$txt['whoallow_manageboards'] = 'Redigerer innstillingene for forum og kategorier.';
$txt['whoallow_admin'] = 'Viewing the <a href="{admin_url}">administration center</a>.';
$txt['whoallow_ban'] = 'Redigerer lista over utestengte.';
$txt['whoallow_boardrecount'] = 'Teller på nytt alle forumets totaler.';
$txt['whoallow_calendar'] = 'Viewing the <a href="{calendar_url}">calendar</a>.';
$txt['whoallow_editnews'] = 'Redigerer nyhetene.';
$txt['whoallow_mailing'] = 'Sender en e-post fra forumet.';
$txt['whoallow_maintain'] = 'Utfører rutinemessig vedlikehold på forumet.';
$txt['whoallow_manageattachments'] = 'Behandler vedleggene.';
$txt['whoallow_moderate'] = 'Viewing the <a href="{moderate_url}">Moderation Center</a>.';
$txt['whoallow_memberlist'] = 'Viewing the <a href="{memberlist_url}">member list</a>.';
$txt['whoallow_optimizetables'] = 'Optimaliserer databasens tabeller.';
$txt['whoallow_repairboards'] = 'Reparerer databasetabellene.';
$txt['whoallow_search'] = '<a href="{search_url}">Searching</a> the forum.';
$txt['whoallow_search_results'] = 'Viser resultater etter et søk.';
$txt['whoallow_setcensor'] = 'Redigerer sensurteksten.';
$txt['whoallow_setreserve'] = 'Redigerer de reserverte navnene.';
$txt['whoallow_stats'] = 'Viewing the <a href="{stats_url}">forum stats</a>.';
$txt['whoallow_viewErrorLog'] = 'Leser forumets logg over feil.';
$txt['whoallow_viewmembers'] = 'Viser en liste over medlemmer.';

$txt['who_topic'] = 'Viewing the topic <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Viewing the board <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Viewing the board index of <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Viewing <a href="%1$s">%2$s</a>\'s profile.';
$txt['who_profile'] = 'Editing the profile of <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Posting a new topic in <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Posting a new poll in <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Email starting a new topic in <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Email posting in <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Sending a personal message by email.';

// Credits text
$txt['credits'] = 'Medvirkende';
$txt['credits_intro'] = 'ElkArte is 100% free and open-source. We encourage and support an active, open community that accepts contributions from the public.  We want to thank everyone who supported the project by providing code, feedback, bug reports, and opinions, as none of this would have been possible without you.  We also want to specially acknowledge <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, the project that ElkArte was born from.';
$txt['credits_contributors'] = 'Contributors';
$txt['credits_and'] = 'og';
$txt['credits_copyright'] = 'Opphavsrett';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Add-ons';
$txt['credits_software_graphics'] = 'Software/Graphics';
$txt['credits_software'] = 'Software';
$txt['credits_graphics'] = 'Graphics';
$txt['credits_fonts'] = 'Fonts';
$txt['credits_groups_contrib'] = 'Contributors';
$txt['credits_contrib_list'] = 'For a complete list of the many individuals that contributed to the design and implementation of Elkarte, please refer to the official GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">list of contributors.</a>';
$txt['credits_license'] = 'License';
$txt['credits_copyright'] = 'Opphavsrett';
$txt['credits_version'] = 'Versjon';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Oversettere';
$txt['credits_translators_message'] = 'Thank you for your efforts which make it possible for people all around the world to use ElkArte.  For a complete list please refer to the offical Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">list of contributors.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';