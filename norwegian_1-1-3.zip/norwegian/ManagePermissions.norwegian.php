<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Endre rettigheter';
$txt['permissions_modify'] = 'Rediger';
$txt['permissions_view'] = 'Vis';
$txt['permissions_allowed'] = 'Tillat';
$txt['permissions_denied'] = 'Nektet';
$txt['permission_cannot_edit'] = '<strong>Note:</strong> You cannot edit this permission profile as it is a predefined profile included within the forum software by default. If you wish to change the permissions of this profile you must first create a duplicate profile. You can <a href="%1$s">carry out this task by clicking here</a>.';

$txt['permissions_for_profile'] = 'Rettigheter for profilen';
$txt['permissions_boards_desc'] = 'Listen nedenfor viser hvilke sett av rettigheter som er tildelt hver kategori på forumet ditt. Du kan redigere tildelt profilrettigheter ved enten å klikke på navnet eller velg &quot;rediger alle&quot; fra bunnen av siden. Hvis du vil redigere selve profilen er det bare å klikke på profilnavnet.';
$txt['permissions_board_all'] = 'Rediger alle';
$txt['permission_profile'] = 'Rettighetsprofil';
$txt['permission_profile_desc'] = 'Which <a target="_blank" href="%1$s">permission set</a> the board should use.';
$txt['permission_profile_inherit'] = 'Arve fra overordnet forum';

$txt['permissions_profile'] = 'Profiler';
$txt['permissions_profiles_desc'] = 'Rettighetsprofiler er tildelt den enkelte kategorier som lar deg enkelt administrere dine sikkerhetsinnstillinger. Fra dette området kan du opprette, redigere og slette rettighetsprofiler.';
$txt['permissions_profiles_change_for_board'] = 'Rediger Rettighetsprofil for: &quot;%1$s&quot;';
$txt['permissions_profile_default'] = 'Standard';
$txt['permissions_profile_no_polls'] = 'Ingen avstemninger';
$txt['permissions_profile_reply_only'] = 'Kun svar';
$txt['permissions_profile_read_only'] = 'Kun lesbar';

$txt['permissions_profile_rename'] = 'Rename all';
$txt['permissions_profile_edit'] = 'Rediger profiler';
$txt['permissions_profile_new'] = 'Ny profil';
$txt['permissions_profile_new_create'] = 'Opprett';
$txt['permissions_profile_name'] = 'Profilnavn';
$txt['permissions_profile_used_by'] = 'Brukt av';
$txt['permissions_profile_used_by_one'] = '1 Forum';
$txt['permissions_profile_used_by_many'] = '%1$d Forumer';
$txt['permissions_profile_used_by_none'] = 'Ingen fora';
$txt['permissions_profile_do_edit'] = 'Rediger';
$txt['permissions_profile_do_delete'] = 'Slett';
$txt['permissions_profile_copy_from'] = 'Kopier rettigheter fra';

$txt['permissions_includes_inherited'] = 'Arvet gruppe';
$txt['permissions_includes_inherited_from'] = 'Inherited from: ';

$txt['permissions_all'] = 'alle';
$txt['permissions_none'] = 'ingen';
$txt['permissions_set_permissions'] = 'Aktiver rettigheter';

$txt['permissions_advanced_options'] = 'Avanserte alternativer';
$txt['permissions_with_selection'] = 'Med valgte';
$txt['permissions_apply_pre_defined'] = 'Bruk den forhåndsdefinerte rettighetsprofilen';
$txt['permissions_select_pre_defined'] = 'Velg en forhåndsdefinert profil';
$txt['permissions_copy_from_board'] = 'Kopier rettigheter fra denne seksjonen';
$txt['permissions_select_board'] = 'Velg seksjon';
$txt['permissions_like_group'] = 'Sett rettigheter som denne gruppa';
$txt['permissions_select_membergroup'] = 'Select a member group';
$txt['permissions_add'] = 'Legg til rettighet';
$txt['permissions_remove'] = 'Slett rettighet';
$txt['permissions_deny'] = 'Ikke tillat rettighet';
$txt['permissions_select_permission'] = 'Velg en rettighet';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Du kan bare velge et alternativ for å redigere rettighetene';
$txt['permissions_no_action'] = 'Ingenting valgt';
$txt['permissions_deny_dangerous'] = 'Du er nå iferd med å nekte en eller flere rettigheter.\\nDette kan v&ære farlig og gi uventede resultater om du ikke er helt sikker på at ingen er <i>tilfeldigvis</i> i den gruppa eller de gruppene du prøver å nekte tilgang til.\\n\\nEr du sikker på at du vil fortsette?';

$txt['permissions_modify_group'] = 'Endre gruppe';
$txt['permissions_general'] = 'Generelle rettigheter';
$txt['permissions_board'] = 'Globale seksjonbaserte rettigheter';
$txt['permissions_board_desc'] = '<strong>Merk</strong>: Å endre disse forumrettighetene vil påvirke alle kategorier tildelt rettighetsprofil &quot;Standard&quot;. Kategorier som ikke bruker &quot;Standard&quot; profilen vil ikke bli påvirket av endringer på denne siden';
$txt['permissions_commit'] = 'Lagre endringer';
$txt['permissions_on'] = 'på seksjonen';
$txt['permissions_local_for'] = 'Lokale rettigheter for gruppe';
$txt['permissions_option_on'] = 'N';
$txt['permissions_option_off'] = 'I';
$txt['permissions_option_deny'] = 'N';
$txt['permissions_option_desc'] = 'For each permission you can pick either \'Allow\' (A), \'Disallow\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />Remember that if you deny a permission, any member - whether moderator or otherwise - that is in that group will be denied that as well.<br />For this reason, you should use deny carefully, only when <strong>necessary</strong>. Disallow, on the other hand, denies unless otherwise granted.';

$txt['permissiongroup_general'] = 'Generelt';
$txt['permissionname_view_stats'] = 'Vis forumstatistikk';
$txt['permissionhelp_view_stats'] = 'Forumstatistikk er en side som oppsummerer all statistikk på forumet, som antall medlemmer, antall innlegg til dagen og en hel rekke topp 10-lister. Ved å aktivere denne rettigheten vil denne linken komme frem: ([Mer statistikk]).';
$txt['permissionname_view_mlist'] = 'View the member list and groups';
$txt['permissionhelp_view_mlist'] = 'The member list shows all members that have registered on your forum. The list can be sorted and searched. The member list is linked from both the board index and the stats page, by clicking on the number of members. It also applies to the groups page which is a mini memberlist of people in that group.';
$txt['permissionname_who_view'] = 'Vis Hvem er pålogget';
$txt['permissionhelp_who_view'] = 'Hvem er pålogget viser alle medlemmene som er innlogget og hva de driver med. Denne rettigheten vil kun fungere om du har aktivert alternativet i &quot;Installerte modifikasjoner innstillinger og alternativer&quot;. Du kan få tilgang til &quot;Hvem er pålogget&quot; ved å klikke på linken i seksjonen Brukere pålogget på forumets hovedside.';
$txt['permissionname_search_posts'] = 'Søke etter innlegg';
$txt['permissionhelp_search_posts'] = 'Søkerettigheten gir brukeren tilgang til å søke i alle seksjoner han/hun har tilgang til. Når søkerettigheten er aktivert vil en &quot;Søk&quot; knapp være synlig på forumets meny.';
$txt['permissionname_karma_edit'] = 'Redigere andres karma';
$txt['permissionhelp_karma_edit'] = 'Karma is a feature that shows the popularity of a member. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to cast a vote. This permission has no effect on guests.';
$txt['permissionname_like_posts'] = 'Like other users\' posts';
$txt['permissionhelp_like_posts'] = 'Likes is a feature that shows the popularity of a post. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to like a post or unlike one they previously liked.  This permission has no effect on guests.';
$txt['permissionname_like_posts_stats'] = 'See like posts stats';
$txt['permissionhelp_like_posts_stats'] = 'This will allow users to see stats of posts liking';
$txt['permissionname_disable_censor'] = 'Disable word censor';
$txt['permissionhelp_disable_censor'] = 'Allows members the option to disable the word censor.';

$txt['permissiongroup_pm'] = 'Personlige meldinger';
$txt['permissionname_pm_read'] = 'Lese PM\'er';
$txt['permissionhelp_pm_read'] = 'Denne rettigheten gir brukeren tilgang til menyen for Personlige meldinger og å lese sine personlige meldinger. Uten denne rettigheten er brukeren ikke istand til å sende private meldinger.';
$txt['permissionname_pm_send'] = 'Sende PM\'er';
$txt['permissionhelp_pm_send'] = 'Sende personlige meldinger til registrerte medlemmer. Krever at brukeren har tilgang til å &quot;Lese personlige meldinger&quot;.';
$txt['permissionname_send_email_to_members'] = 'Send emails';
$txt['permissionhelp_send_email_to_members'] = 'Send emails to other registered members.';

$txt['permissiongroup_calendar'] = 'Kalender';
$txt['permissionname_calendar_view'] = 'Vise kalenderen';
$txt['permissionhelp_calendar_view'] = 'Kalenderen viser for hver måned fødselsdager, hendelser og ferier. Denne rettigheten gir tilgang til denne kalenderen. Når denne rettigheten er aktivert, vil en kalenderknapp bli vist på forumets meny øverst og ikke minst vil kommende fødselsdager og hendelser bli vist nederst på forumets hovedside. Kalenderen må være aktivert fra &quot;Installerte modifikasjoner innstillinger og alternativer&quot;.';
$txt['permissionname_calendar_post'] = 'Opprette hendelser i kalenderen';
$txt['permissionhelp_calendar_post'] = 'En hendelse er et emnet koblet til en spesiell dato eller datoer. Opprettelse av hendelser kan skje fra kalenderen. En hendelse kan kun bli opprettet om brukeren som oppretter hendelsen har tilgang til å lage nye emner.';
$txt['permissionname_calendar_edit'] = 'Redigere hendelser i kalenderen';
$txt['permissionhelp_calendar_edit'] = 'En hendelse er et tema knyttet til en bestemt dato eller datointervall. Hendelsen kan redigeres ved å klikke på den røde stjernen (*) ved siden hendelsen i kalendervisning. For å kunne redigere en hendelse, må brukeren ha tilstrekkelige rettigheter til å redigere den første meldingen om emnet som er knyttet til hendelsen.';
$txt['permissionname_calendar_edit_own'] = 'Egne hendelser';
$txt['permissionname_calendar_edit_any'] = 'Alle hendelser';

$txt['permissiongroup_maintenance'] = 'Forumadministrasjon';
$txt['permissionname_admin_forum'] = 'Administrere forumet og databasen';
$txt['permissionhelp_admin_forum'] = 'Denne rettigheten gir medlemmet tilgang til å redigere forumets innstillinger, design innstillinger, behandle pakker og bruke forumets database og vedlikeholdsverktøy. Bruk denne rettigheten med omtanke, ettersom den er veldig sårbar for forumet.';
$txt['permissionname_manage_boards'] = 'Administrere forumer og kategorier';
$txt['permissionhelp_manage_boards'] = 'Denne rettigheten gir medlemmet tilgang til å opprette, redigere og fjerne fora og kategorier.';
$txt['permissionname_manage_attachments'] = 'Administrere vedlegg og avatarer';
$txt['permissionhelp_manage_attachments'] = 'Denne rettigheten gir medlemmet tilgang til administrasjon av vedlegg, hvor avatarer og vedlegg kan bli fjernet.';
$txt['permissionname_manage_smileys'] = 'Behandle smilefjes og innleggs-symboler';
$txt['permissionhelp_manage_smileys'] = 'Dette gir tilgang til å administrere smilefjes. Her kan du legge til, redigere og fjerne smilefjes og sett med smilefjes. Hvis du har aktivert tilpasset meldingsikoner du kan også legge til og redigere meldingsikoner med denne tillatelsen.';
$txt['permissionname_edit_news'] = 'Redigere nyheter';
$txt['permissionhelp_edit_news'] = 'The news function allows a random news line to appear on each screen. In order to use the news function, enable it in the forum settings.';
$txt['permissionname_access_mod_center'] = 'Åpne moderatorsentret';
$txt['permissionhelp_access_mod_center'] = 'Med denne rettigheten kan alle medlemmer av denne gruppen få tilgang til modereringssenteret, hvor de vil ha tilgang til funksjonalitet for å lette moderering. Merk at dette gir ikke i seg selv noen modereringsprivilegier.';

$txt['permissiongroup_member_admin'] = 'Administrasjon av medlemmer';
$txt['permissionname_moderate_forum'] = 'Redigere på forumets medlemmer';
$txt['permissionhelp_moderate_forum'] = 'Denne rettigheten inkluderer alle viktige moderatorfunksjoner:<ul class="normallist"><li>tilgang til å vise registeringserklæring</li><li>tilgang til å vise/slette medlemsbildet</li><li>utvidet profilinformasjon som å kunne spore IP/bruker og (skjult) innlogging</li><li>aktivere kontoer</li><li>motta godkjennelsesvarsler og godkjenne kontoer</li><li>immun mot ignorerte PMer</li><li>andre småting</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Administrere medlemsgrupper';
$txt['permissionhelp_manage_membergroups'] = 'Denne rettigheten gir medlemmet tilgang til å redigere medlemsgrupper og tildele disse til medlemmer.';
$txt['permissionname_manage_permissions'] = 'Behandle rettigheter';
$txt['permissionhelp_manage_permissions'] = 'Denne rettigheten gir medlemmet tilgang til å redigere alle rettigheter til en medlemsgruppe, globalt eller for enkelt-forumer.';
$txt['permissionname_manage_bans'] = 'Administrere utestengelser ';
$txt['permissionhelp_manage_bans'] = 'This permission allows a user to add or remove user names, IP addresses, hostnames and email addresses to or from a list of banned users. It also allows a user to view and remove log entries of banned users that attempted to login.';
$txt['permissionname_send_mail'] = 'Broadcast to multiple members';
$txt['permissionhelp_send_mail'] = 'Mass mail all forum members or just a few member groups by email or personal message (the latter requires the \'Send Personal Message\' permission).';
$txt['permissionname_issue_warning'] = 'Gi advarsler til medlemmer';
$txt['permissionhelp_issue_warning'] = 'Gi en advarsel til medlemmer av forumet og endre medlemmets advarselnivå. Krever at advarselssystem må være aktivert.';

$txt['permissiongroup_profile'] = 'Medlemsprofiler';
$txt['permissionname_profile_view'] = 'Vise profilen og statistikk for medlemmet';
$txt['permissionhelp_profile_view'] = 'This permission allows users clicking on a user name to see a summary of profile settings, some statistics and all posts of the user.';
$txt['permissionname_profile_view_own'] = 'Egen profil';
$txt['permissionname_profile_view_any'] = 'Alle profiler';
$txt['permissionname_profile_identity'] = 'Redigere innstillinger for konto';
$txt['permissionhelp_profile_identity'] = 'Account settings are the basic settings of a profile, like password, email address, member group and preferred language.';
$txt['permissionname_profile_identity_own'] = 'Egen profil';
$txt['permissionname_profile_identity_any'] = 'Alle profiler';
$txt['permissionname_profile_extra'] = 'Redigere ekstrainnstillinger for profil';
$txt['permissionhelp_profile_extra'] = 'Ekstrainntillingene for profilen inkluderer innstillinger for avatar, alternativer for design, varsling og personlige meldinger.';
$txt['permissionname_profile_extra_own'] = 'Egen profil';
$txt['permissionname_profile_extra_any'] = 'Alle profiler';
$txt['permissionname_profile_title'] = 'Redigere egendefinert tittel';
$txt['permissionhelp_profile_title'] = 'Den egendefinerte tittelen blir vist på emnesidene under brukernavnet på den som har en egendefinert tittel.';
$txt['permissionname_profile_title_own'] = 'Egen profil';
$txt['permissionname_profile_title_any'] = 'Alle profiler';
$txt['permissionname_profile_remove'] = 'Slett konto';
$txt['permissionhelp_profile_remove'] = 'Denne rettigheten gir medlemmet tilgang til å slette sin egen konto om det er satt til &quot;Egen konto&quot;.';
$txt['permissionname_profile_remove_own'] = 'Egen konto';
$txt['permissionname_profile_remove_any'] = 'Alle kontoer';
$txt['permissionname_profile_set_avatar'] = 'Velg en avatar';
$txt['permissionhelp_profile_set_avatar'] = 'If enabled this will allow a user to select an avatar.';

$txt['permissiongroup_general_board'] = 'Generelt';
$txt['permissionname_moderate_board'] = 'Forum-moderator';
$txt['permissionhelp_moderate_board'] = 'Ved å være forum-moderator vil noen småknapper komme frem. Rettighetene inkluderer å svare til stengte emner, redigere når en avstemning skal utløpe og vise resultater i en avstemning selv om den ikke er utløpt. ';

$txt['permissiongroup_topic'] = 'Emner';
$txt['permissionname_post_new'] = 'Opprett nye emner';
$txt['permissionhelp_post_new'] = 'Denne rettigheten gjør slik at medlemmene kan opprette nye emner, men ikke å svare på emnene.';
$txt['permissionname_merge_any'] = 'Slå sammen alle emner';
$txt['permissionhelp_merge_any'] = 'Merge two or more topics into one. The order of messages within the merged topic will be based on the time the messages were created. A user can only merge topics on those boards a user is allowed to merge. In order to merge multiple topics at once, a user has to enable quick moderation in their profile settings.';
$txt['permissionname_split_any'] = 'Dele opp alle emner';
$txt['permissionhelp_split_any'] = 'Dele et emne til to ulike emner.';
$txt['permissionname_send_topic'] = 'Tipse emner til venner';
$txt['permissionhelp_send_topic'] = 'Denne rettigheten gir medlemmet muligheten til å sende en e-post med et tips til emnet ved å skrive inn mottakerens e-postadresse og legge til en kommentar.';
$txt['permissionname_make_sticky'] = 'Fest emner';
$txt['permissionhelp_make_sticky'] = 'Pinned topics are topics that always remain on top of a board. They can be useful for announcements or other important messages.';
$txt['permissionname_move'] = 'Move topics';
$txt['permissionhelp_move'] = 'Flytte emner fra en forum til en annen. Medlemmene kan bare velge forumer de har tilgang til.';
$txt['permissionname_move_own'] = 'Egne emner';
$txt['permissionname_move_any'] = 'Alle emner';
$txt['permissionname_lock'] = 'Stenge emner';
$txt['permissionhelp_lock'] = 'This permission allows a user to lock a topic. This can be done in order to make sure no one can reply to a topic. Only users with a \'Moderate board\' permission can still post in locked topics.';
$txt['permissionname_lock_own'] = 'Egne emner';
$txt['permissionname_lock_any'] = 'Alle emner';
$txt['permissionname_remove'] = 'Slette emner';
$txt['permissionhelp_remove'] = 'Sletter hele emner fra forumet. Merk at denne rettigheten ikke gir tilgang til kun å slette innlegg fra et emne!';
$txt['permissionname_remove_own'] = 'Egne emner';
$txt['permissionname_remove_any'] = 'Alle emner';
$txt['permissionname_post_reply'] = 'Svare på emner';
$txt['permissionhelp_post_reply'] = 'Denne rettigheten tillater medlemmet å svare på emner.';
$txt['permissionname_post_reply_own'] = 'Egne emner';
$txt['permissionname_post_reply_any'] = 'Alle emner';
$txt['permissionname_modify_replies'] = 'Redigere svar til egne emner';
$txt['permissionhelp_modify_replies'] = 'Denne rettigheten gir medlemmet som startet et emne til å redigere alle svarene i sitt emne.';
$txt['permissionname_delete_replies'] = 'Slette svar til egne emner';
$txt['permissionhelp_delete_replies'] = 'Denne rettigheten gir medlemmet som startet et emne til å slette alle svarene i sitt emne.';
$txt['permissionname_announce_topic'] = 'Kunngjøre emner';
$txt['permissionhelp_announce_topic'] = 'This allows a user to send an announcement email about a topic to all members or to a few member groups.';

$txt['permissionname_approve_emails'] = 'Moderate Post by Email Failures';
$txt['permissionhelp_approve_emails'] = 'Allow moderators to access the Post by Email failure log to perform actions including approve, delete, view and bounce.  Note, since the system may not always know what board a post goes to, this permission should be only be given to members with full board access';
$txt['permissionname_postby_email'] = 'Post by Email';
$txt['permissionhelp_postby_email'] = 'This permission allows users to start new topics as well as reply to topic and PM notifications by email.';

$txt['permissiongroup_post'] = 'Innlegg';
$txt['permissionname_delete'] = 'Slette innlegg';
$txt['permissionhelp_delete'] = 'Sletter innlegg. Dette gir ikke tilgang til å slette det første innlegget i et emne.';
$txt['permissionname_delete_own'] = 'Egne innlegg';
$txt['permissionname_delete_any'] = 'Alle innlegg';
$txt['permissionname_modify'] = 'Redigere innlegg';
$txt['permissionhelp_modify'] = 'Redigerer innlegg';
$txt['permissionname_modify_own'] = 'Egne innlegg';
$txt['permissionname_modify_any'] = 'Alle innlegg';
$txt['permissionname_report_any'] = 'Rapportere innlegg til moderator';
$txt['permissionhelp_report_any'] = 'Denne rettigheten legger til en link til hvert innlegg som gir medlemmene tilgang til å rapportere innlegg til moderator. Ved rapportering blir alle moderatorer for det forumet tilsendt en e-post med en link til det rapporterte innlegget og en kommentar fra medlemmet som rapporterte.';

$txt['permissiongroup_poll'] = 'Avstemninger';
$txt['permissionname_poll_view'] = 'Vise avstemninger';
$txt['permissionhelp_poll_view'] = 'Denne rettigheten gir medlemmet tilgang til å vise avstemninger. Without this permission, the user will only see the topic.';
$txt['permissionname_poll_vote'] = 'Avgi stemme i avstemninger';
$txt['permissionhelp_poll_vote'] = 'Denne rettigheten gir et registrert medlem til å avgi stemme i avstemninger. Denne gjelder ikke for gjester.';
$txt['permissionname_poll_post'] = 'Lage avstemninger';
$txt['permissionhelp_poll_post'] = 'Denne rettigheten gir et medlem å lage nye avstemninger. Siden avstemninger er en spesiell type emner kan den ikke brukes uten at medlemmet har tilgang til rettigheten \'Opprette nye emner\'.';
$txt['permissionname_poll_add'] = 'Legge til avstemninger til emner';
$txt['permissionhelp_poll_add'] = 'Denne rettigheten gir medlemmer tilgang til å legge til en avstemning til et emne som allerede eksisterer. Denne rettigheten krever at medlemmet har tilgang til å redigere det første innlegget i et emne.';
$txt['permissionname_poll_add_own'] = 'Egne emner';
$txt['permissionname_poll_add_any'] = 'Alle emner';
$txt['permissionname_poll_edit'] = 'Redigere avstemninger';
$txt['permissionhelp_poll_edit'] = 'Denne rettigheten gir medlemmer tilgang til å redigere alternativene for en avstemning og nullstille antall stemmer. For å kunne redigere maks antall stemmer og varighet må medlemmet også ha rettigheten &quot;forummoderator&quot;.';
$txt['permissionname_poll_edit_own'] = 'Egne avstemninger';
$txt['permissionname_poll_edit_any'] = 'Alle avstemninger';
$txt['permissionname_poll_lock'] = 'Stenge avstemninger';
$txt['permissionhelp_poll_lock'] = 'Stengte avstemninger kan ikke motta flere stemmer.';
$txt['permissionname_poll_lock_own'] = 'Egne avstemninger';
$txt['permissionname_poll_lock_any'] = 'Alle avstemninger';
$txt['permissionname_poll_remove'] = 'Slette avstemninger';
$txt['permissionhelp_poll_remove'] = 'Denne rettigheten tillater sletting av avstemninger.';
$txt['permissionname_poll_remove_own'] = 'Egne avstemninger';
$txt['permissionname_poll_remove_any'] = 'Alle avstemninger';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Save drafts of new posts';
$txt['permissionname_simple_post_draft'] = 'Save drafts of new posts';
$txt['permissionhelp_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionhelp_simple_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionname_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionname_simple_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionhelp_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionname_simple_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionhelp_pm_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid losing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionname_simple_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionhelp_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';
$txt['permissionhelp_simple_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';

$txt['permissiongroup_approval'] = 'Innleggsmoderering';
$txt['permissionname_approve_posts'] = 'Godkjenne elementer som venter på moderering';
$txt['permissionhelp_approve_posts'] = 'Denne rettigheten lar brukeren godkjenne alle ikke-godkjente elementer på et forum.';
$txt['permissionname_post_unapproved_replies'] = 'Legge til svar på emner, men ikke vis før godkjent';
$txt['permissionhelp_post_unapproved_replies'] = 'Denne tillatelsen lar brukeren svar på emner. Svarene vil ikke bli vist før den er godkjent av en moderator.';
$txt['permissionname_post_unapproved_replies_own'] = 'Egne emner';
$txt['permissionname_post_unapproved_replies_any'] = 'Alle emner';
$txt['permissionname_post_unapproved_topics'] = 'Legge til nye emner, men ikke vis før godkjent';
$txt['permissionhelp_post_unapproved_topics'] = 'Denne rettigheten lar brukeren starte et nytt tema som vil kreve godkjenning før de blir vist.';
$txt['permissionname_post_unapproved_attachments'] = 'Legge til vedlegg, men skjules til godkjent';
$txt['permissionhelp_post_unapproved_attachments'] = 'Denne tillatelsen lar brukeren legge ved filer til innlegg. Vedlagte filer vil da kreve godkjenning før den vises for andre brukere.';

$txt['permissiongroup_notification'] = 'Varsling og e-post';
$txt['permissionname_mark_any_notify'] = 'Be om varsling ved svar';
$txt['permissionhelp_mark_any_notify'] = 'Denne funksjonen gir medlemmer tilgang til å få varsel på e-post når noen svarer til et emne de har abonnert på.';
$txt['permissionname_mark_notify'] = 'Be om varsling ved nye emner';
$txt['permissionhelp_mark_notify'] = 'Varsling ved nye emner er en funksjon som lar medlemmer få varsel på e-post om noen lager nye emner i forumer de har abonnert på.';

$txt['permissiongroup_attachment'] = 'Vedlegg';
$txt['permissionname_view_attachments'] = 'Vise vedlegg';
$txt['permissionhelp_view_attachments'] = 'Vedlegg er filer som er vedlagt til skrevne innlegg. Denne funksjonen kan aktiveres og konfigureres i &quot;Rediger installerte modifikasjoner&quot;. Siden vedlegg ikke blir hentet fra direkte, kan du beskytte dem fra å bli nedlastet fra medlemmer som ikke har denne rettigheten.';
$txt['permissionname_post_attachment'] = 'Bruke vedlegg';
$txt['permissionhelp_post_attachment'] = 'Vedlegg er filer som er vedlagt til skrevne innlegg. Et innlegg kan inneholde flere vedlegg.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Rettighetsinnstillinger';
$txt['groups_manage_permissions'] = 'Member groups allowed to manage permissions';
$txt['permission_enable_deny'] = 'Aktivere funksjonen til å nekte rettigheter';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Ved å slå av denne funksjonen vil &quot;Nektet&quot;-rettigheter bli endret til &quot;Ikke tillatt&quot;.';
$txt['permission_by_board_desc'] = 'Here you can set which permission profile a board uses. You can create new permission profiles from the &quot;Edit Profiles&quot; menu.';
$txt['permission_settings_desc'] = 'Her kan du stille inn hvem som har tilgang til å endre rettigheter og hvor avansert rettighetssysteme skal være.';
$txt['permission_enable_postgroups'] = 'Aktivere rettigheter for innleggsbaserte grupper';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Deaktivering av denne innstillingen vil fjerne rettighetene som er satt for innleggsbaserte grupper.';

$txt['permissions_post_moderation_desc'] = 'From this page you can easily change which groups have their posts moderated for a particular permission profile.';
$txt['permissions_post_moderation_deny_note'] = 'Merk: Selv om du har avanserte rettigheter aktivert kan du ikke bruke &quot;nekte&quot; rettigheter fra denne siden. Vennligst rediger rettighetene direkte hvis du ønsker å bruke en nekte-rettighet.';
$txt['permissions_post_moderation_select'] = 'Velg profil';
$txt['permissions_post_moderation_new_topics'] = 'Nye emner';
$txt['permissions_post_moderation_replies_own'] = 'Egne svar';
$txt['permissions_post_moderation_replies_any'] = 'Alle svar';
$txt['permissions_post_moderation_attachments'] = 'Vedlegg';
$txt['permissions_post_moderation_legend'] = 'Forklaring';
$txt['permissions_post_moderation_allow'] = 'Kan opprette';
$txt['permissions_post_moderation_moderate'] = 'Kan opprette, men krever godkjenning';
$txt['permissions_post_moderation_disallow'] = 'Kan ikke opprette';
$txt['permissions_post_moderation_group'] = 'Gruppe';

$txt['auto_approve_topics'] = 'Post new topics without requiring approval';
$txt['auto_approve_replies'] = 'Post replies to topics without requiring approval';
$txt['auto_approve_attachments'] = 'Post attachments without requiring approval';
