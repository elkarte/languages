<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Beklager, denne seksjonen er ikke tilgjengelig. Vi kan faktisk ikke si noe om den eksisterer. Du er velkommen til å besøke hovedsiden og velge ditt mål derfra.';
$txt['not_guests'] = 'Beklager, denne handlingen er ikke tilgjengelig for gjester.';

$txt['mods_only'] = 'Bare moderatorer kan fjerne innlegg direkte, vennligst bruk den normale funksjonen for å endre innlegg.';
$txt['no_name'] = 'Du fylte ikke ut et navn. Vi kan ikke la deg fortsette uten et navn dessverre.';
$txt['no_email'] = 'You didn\'t fill the email field out. We can\'t let you continue without an email, sorry.';
$txt['topic_locked'] = 'Emnet er låst. Du har ikke tilgang til å skrive eller redigere innlegg...';
$txt['no_password'] = 'Passordfeltet er tomt';
$txt['passwords_dont_match'] = 'Passordene er ikke identiske.';
$txt['register_to_use'] = 'Beklager, men du må registrere deg før du kan bruke denne funksjonen.';
$txt['username_reserved'] = 'The user name you tried to use contains the reserved name \'%1$s\'. Please try another user name.';
$txt['numbers_one_to_nine'] = 'Dette feltet godtar kun tall mellom 0 og 9.';
$txt['not_a_user'] = 'Den brukeren du prøver å vise finnes ikke.';
$txt['not_a_topic'] = 'Det emnet du prøver å lese, eksisterer ikke på forumet.';
$txt['not_approved_topic'] = 'Dette emnet er ikke godkjent ennå.';
$txt['email_in_use'] = 'Den e-postadressen (%1$s) brukes av et registrert medlem allerede. Hvis du føler dette er en feil, gå til logg inn siden og bruke passordet påminnelse med den adressen.';

$txt['didnt_select_vote'] = 'Du valgte ikke et alternativ i avstemninga.';
$txt['poll_error'] = 'Something isn\'t working, sorry: either that poll doesn\'t exist, the poll has been locked, or you tried to vote twice.';
$txt['locked_by_admin'] = 'Dette emnet ble låst av en administrator. Du kan ikke åpne det.';
$txt['not_enough_posts_karma'] = 'Beklager, du har ikke nok innlegg til å endre karma - du trenger minst %1$d.';
$txt['cant_change_own_karma'] = 'Beklager, men du har ikke tilgang til å redigere din egen karma.';
$txt['karma_wait_time'] = 'Beklager, du kan ikke gjenta en karma handling uten å vente %1$s %2$s.';
$txt['feature_disabled'] = 'Beklager, denne funksjonen er deaktivert.';
$txt['feature_no_exists'] = 'Sorry, this feature doesn\'t exist.';
$txt['couldnt_connect'] = 'Kunne ikke koble til serveren eller kunne ikke finne filen';
$txt['no_board'] = 'Forumet du spesifiserte eksisterer ikke';
$txt['no_message'] = 'The message is no longer available';
$txt['no_topic_id'] = 'Du skrev inn en ugyldig emne-ID.';
$txt['split_first_post'] = 'Du kan ikke splitte et emne fra det første innlegget.';
$txt['topic_one_post'] = 'Dette emnet inneholder kun ett innlegg og kan ikke splittes';
$txt['no_posts_selected'] = 'ingen innlegg ble valgt';
$txt['selected_all_posts'] = 'Kan ikke splitte emnet. Du har valgt alle innleggene.';
$txt['cant_find_messages'] = 'Kunne ikke finne innlegg';
$txt['cant_find_user_email'] = 'Kan ikke finne brukerens e-postadresse.';
$txt['cant_insert_topic'] = 'Kunne ikke sette inn emnet';
$txt['session_timeout'] = 'Your session timed out while posting. Please go back and try again.';
$txt['session_timeout_file_upload'] = 'Your session timed out while uploading the file. Please try again.';
$txt['no_files_uploaded'] = 'There are no files to upload.';
$txt['session_verify_fail'] = 'Session verification failed. Please try logging out and back in again, and then try again.';
$txt['verify_url_fail'] = 'Unable to verify referring URL: %1$s. Please go back and try again.';
$txt['token_verify_fail'] = 'Token verification failed. Please go back and try again.';
$txt['guest_vote_disabled'] = 'Gjester kan ikke stemme i denne avstemningen.';

$txt['cannot_access_mod_center'] = 'Du har ikke adgang til moderatorsenteret.';
$txt['cannot_admin_forum'] = 'Du har ikke tilgang til å administrere forumet.';
$txt['cannot_announce_topic'] = 'Du har ikke tilgang til å kunngjøre emner i dette forumet.';
$txt['cannot_approve_posts'] = 'Du har ikke tillatelse til å godkjenne elementer.';
$txt['cannot_post_unapproved_attachments'] = 'Du har ikke tillatelse til å poste vedlegg som ikke er godkjent.';
$txt['cannot_post_unapproved_topics'] = 'Du har ikke tillatelse til å poste emner som ikke er godkjent.';
$txt['cannot_post_unapproved_replies_own'] = 'Du har ikke tillatelse til å poste svar til dine emner som ikke er godkjent.';
$txt['cannot_post_unapproved_replies_any'] = 'Du har ikke tillatelse til å poste svar til andre brukeres emner som ikke er godkjent.';
$txt['cannot_calendar_edit_any'] = 'Du kan ikke redigere kalender-hendelse.';
$txt['cannot_calendar_edit_own'] = 'Du har ikke nødvendige rettigheter til å redigere dine egne hendelser.';
$txt['cannot_calendar_post'] = 'Beklager, men det går ikke an å opprette hendelser.';
$txt['cannot_calendar_view'] = 'Beklager, men du har ikke tilgang til å vise kalenderen.';
$txt['cannot_remove_any'] = 'Beklager, men du har ikke rettigheter til å fjerne emner.';
$txt['cannot_remove_own'] = 'Beklager, men du kan ikke fjerne dine egne emner i dette forumet.';
$txt['cannot_edit_news'] = 'Du har ikke tilgang til å redigere nyhetene på dette forumet.';
$txt['cannot_pm_read'] = 'Beklager, men du kan ikke lese dine personlige meldinger.';
$txt['cannot_pm_send'] = 'Beklager, men du har ikke tilgang til å sende personlige meldinger.';
$txt['cannot_karma_edit'] = 'Du har ikke tilgang til å redigere andre medlemmers karma.';
$txt['cannot_like_posts'] = 'You are not allowed to like messages in this board.';
$txt['cannot_lock_any'] = 'Du har ikke tilgang til å stenge emner her.';
$txt['cannot_lock_own'] = 'Beklager, men du har ikke tilgang til å stenge dine egne emner her.';
$txt['cannot_make_sticky'] = 'You don\'t have permission to pin this topic.';
$txt['cannot_manage_attachments'] = 'Du har ikke tilgang til å administrere vedlegg eller avatarer.';
$txt['cannot_manage_bans'] = 'Du har ikke tilgang til å forandre lista over utestengte medlemmer.';
$txt['cannot_manage_boards'] = 'Du har ikke tilgang til å administrere forum og kategorier.';
$txt['cannot_manage_membergroups'] = 'You don\'t have permission to modify or assign member groups.';
$txt['cannot_manage_permissions'] = 'Du har ikke tilgang til å administrere rettigheter.';
$txt['cannot_manage_smileys'] = 'Du har ikke tilgang til å administrere smilefjes.';
$txt['cannot_mark_any_notify'] = 'Du har ikke den nødvendige tilgang til å motta varsling på dette emnet.';
$txt['cannot_mark_notify'] = 'Beklager, men du har ikke tilgang til å motta varsling fra denne seksjonen.';
$txt['cannot_merge_any'] = 'Du har ikke tilgang til å slå sammen emner i ett av de valgte forumene.';
$txt['cannot_moderate_forum'] = 'Du har ikke tilgang til å moderere dette forumet.';
$txt['cannot_moderate_board'] = 'Du har ikke tilgang til å moderere dette forumet';
$txt['cannot_modify_any'] = 'Du har ikke tilgang til å redigere innlegg.';
$txt['cannot_modify_own'] = 'Beklager, men du har ikke tilgang til å redigere dine egne innlegg.';
$txt['cannot_modify_replies'] = 'Selv om det er et svar til ditt emne, kan du ikke redigere det.';
$txt['cannot_move_own'] = 'Du har ikke tilgang til å flytte dine egne emner i dette forumet.';
$txt['cannot_move_any'] = 'Du har ikke tilgang til å flytte emner i dette forumet.';
$txt['cannot_poll_add_own'] = 'Beklager, men du har ikke tilgang til å legge til avstemning til dine egne emner i dette forumet.';
$txt['cannot_poll_add_any'] = 'Du har ikke tilgang til å legge til avstemning til dette emnet.';
$txt['cannot_poll_edit_own'] = 'Du kan ikke redigere denne avstemninga, selv om det er din egen.';
$txt['cannot_poll_edit_any'] = 'Du har blitt nektet tilgang til å redigere avstemninger i dette forumet.';
$txt['cannot_poll_lock_own'] = 'Du har ikke tilgang til å stenge dine egne avstemninger i dette forumet.';
$txt['cannot_poll_lock_any'] = 'Beklager, men du har ikke tilgang til å stenge avstemninger.';
$txt['cannot_poll_post'] = 'Du har ikke tilgang til å lage avstemninger i denne seksjonen.';
$txt['cannot_poll_remove_own'] = 'Du har ikke tilgang til å fjerne avstemningen fra ditt emne.';
$txt['cannot_poll_remove_any'] = 'Du har ikke tilgang til å fjerne avstemninger i dette forumet.';
$txt['cannot_poll_view'] = 'Du har ikke tilgang til å vise avstemninger i dette forumet.';
$txt['cannot_poll_vote'] = 'Beklager, men du kan ikke stemme i avstemninger i dette forumet.';
$txt['cannot_post_attachment'] = 'Du har ikke tilgang til å legge til vedlegg her.';
$txt['cannot_post_new'] = 'Beklager, men du kan ikke lage nye emner i dette forumet.';
$txt['cannot_post_new_board'] = 'Sorry, you cannot post new topics in the board %1$s.';
$txt['cannot_post_reply_any'] = 'Du har ikke tilgang til å skrive svar på emner i dette forumet.';
$txt['cannot_post_reply_own'] = 'Du har ikke tilgang til å lage svar til dine egne emner i dette forumet.';
$txt['cannot_profile_remove_own'] = 'Beklager, men du har ikke tilgang til å slette din egen medlemskonto.';
$txt['cannot_profile_remove_any'] = 'You don\'t have the appropriate permissions to remove accounts.';
$txt['cannot_profile_extra_any'] = 'Beklager, men du har ikke de nødvendige rettighetene til å redigere din egen profil.';
$txt['cannot_profile_identity_any'] = 'Du har ikke tilgang til å redigere kontoinnstillinger.';
$txt['cannot_profile_title_any'] = 'Du kan ikke redigere medlemmers egendefinerte titler.';
$txt['cannot_profile_extra_own'] = 'Beklager , men du har ikke de nødvendige rettighetene til å redigere data i din profil.';
$txt['cannot_profile_identity_own'] = 'Du kan ikke endre din identitet på det nåværende tidspunkt.';
$txt['cannot_profile_title_own'] = 'Du har ikke tilgang til å endre din egendefinerte tittel.';
$txt['cannot_profile_set_avatar'] = 'You are not permitted to change your avatar.';
$txt['cannot_profile_view_own'] = 'Beklager så mye, men du kan ikke vise din egen profil.';
$txt['cannot_profile_view_any'] = 'Beklager så mye, men du kan ikke vise profiler.';
$txt['cannot_delete_own'] = 'Ouch, sorry, you cannot delete your posts on this board.';
$txt['cannot_delete_replies'] = 'Beklager, men du kan ikke fjerne disse innleggene, selv om de er svar på ditt eget emne.';
$txt['cannot_delete_any'] = 'Ouch, sorry, you cannot delete posts in this board.';
$txt['cannot_report_any'] = 'Du har ikke tilgang til å rapportere innlegg i dette forumet.';
$txt['cannot_search_posts'] = 'Beklager, men du kan ikke søke etter innlegg i dette forumet.';
$txt['cannot_send_mail'] = 'Du har ikke de nødvendige rettighetene til å sende ut e-post til alle.';
$txt['cannot_issue_warning'] = 'Beklager, du har ikke de nødvendige rettighetene til å utstede advarsler til medlemmer.';
$txt['cannot_send_topic'] = 'Beklager, administratoren har deaktivert at du kan sende emner i dette forumet.';
$txt['cannot_send_email_to_members'] = 'Sorry, but the administrator has disallowed sending emails on this board.';
$txt['cannot_split_any'] = 'Å dele opp emner er ikke tillatt på dette forumet.';
$txt['cannot_view_attachments'] = 'Det virker som du ikke har tilgang til å laste ned eller vise vedlegg i dette forumet.';
$txt['cannot_view_mlist'] = 'You can\'t view the member list because you don\'t have permission to.';
$txt['cannot_view_stats'] = 'Du har ikke tilgang til å vise forumstatistikk.';
$txt['cannot_who_view'] = 'Beklager, du har ikke de nødvendige rettighetene til å vise hvem som er pålogget.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = ' We can\'t find that theme.';
$txt['theme_dir_wrong'] = 'Det er noe feil ved mappen til standarddesignet, vennligst klikk denne teksten for å korrigere.';
$txt['registration_disabled'] = 'Beklager, men registrering er for øyeblikket deaktivert.';
$txt['registration_agreement_missing'] = 'The registration agreement file, agreement.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Beklager , det er ikke satt opp noe hemmelig spørsmål for dette medlemmet.';
$txt['poll_range_error'] = 'Beklager, men avstemningen må vare mer enn 0 dager.';
$txt['delFirstPost'] = 'You are not allowed to delete the first post in a topic.<p>If you want to delete this topic, click on the Remove link, or ask a moderator/administrator to do it for you.</p>';
$txt['login_cookie_error'] = 'Du kunne ikke logge inn. Kontroller dine informasjonskapsel-innstillinger (cookies).';
$txt['incorrect_answer'] = 'Beklager, men du svarte ikke korrekt på spørsmålet. Klikk på tilbakeknappen og prøv på nytt, eller klikk tilbake to ganger for å bruke den vanlige metoden for å få tilbake ditt passord.';
$txt['no_mods'] = 'Fant ingen moderatorer!';
$txt['parent_not_found'] = 'Feil i forumstrukturen: Kunne ikke finne overliggende forum';
$txt['modify_post_time_passed'] = 'Du kan ikke redigere dette innlegget fordi tidsfristen for redigering er utløpt.';

$txt['calendar_off'] = 'Du kan ikke gå inn på kalenderen fordi den er deaktivert.';
$txt['calendar_export_off'] = 'You cannot export calendar events because that feature is currently disabled.';
$txt['invalid_month'] = 'Ugyldig verdi i måned.';
$txt['invalid_year'] = 'Ugyldig verdi i årstall.';
$txt['invalid_day'] = 'Ugyldig dagenz verdi.';
$txt['event_month_missing'] = 'Måneden for hendelsen mangler.';
$txt['event_year_missing'] = 'Året for hendelsen mangler.';
$txt['event_day_missing'] = 'Dagen for hendelsen mangler.';
$txt['event_title_missing'] = 'Tittelen på hendelsen mangler.';
$txt['invalid_date'] = 'Ugyldig dato.';
$txt['no_event_title'] = 'Ingen tittel på hendelsen ble skrevet inn.';
$txt['missing_board_id'] = 'ID på forumet mangler.';
$txt['missing_topic_id'] = 'ID på emnet mangler.';
$txt['topic_doesnt_exist'] = 'Emnet eksisterer ikke.';
$txt['not_your_topic'] = 'Det er ikke du som har startet dette emnet.';
$txt['board_doesnt_exist'] = 'Det forumet eksisterer ikke.';
$txt['no_span'] = 'En hendelse kan ikke strekke seg over flere dager.';
$txt['invalid_days_numb'] = 'Ugyldig antall dager for hendelsen.';

$txt['moveto_noboards'] = 'Det finnes ingen forum du kan flytte emnet til!';
$txt['topic_already_moved'] = 'This topic %1$s has been moved to the board %2$s, please check its new location before moving it again.';

$txt['already_activated'] = 'We\'d love to process your request, but your account has already been activated.';
$txt['still_awaiting_approval'] = 'Din medlemskonto venter fremdeles på godkjennelse fra administrator.';

$txt['invalid_email'] = 'Ugyldig e-postadresse / e-postområde.<br />Eksempel på en gyldig adresse: slem.slemmesen@uskikkelig.com.<br />Eksempel på et gyldig e-postområde: *@*.uskikkelig.com';
$txt['invalid_expiration_date'] = 'Utløpsdatoen er ugyldig';
$txt['invalid_hostname'] = 'Ugyldig vert / vertområde.<br />Eksempel på en gyldig vert: proxy4.uskikkelig.com<br />Eksempel på et gyldig vertområde: *.uskikkelig.com';
$txt['invalid_ip'] = 'Ugyldig IP-adresse / IP-område.<br />Eksempel på en gyldig IP-adresse: 127.0.0.1<br />Eksempel på gyldig IP-område: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'Ugyldig IP-adresse / IP-område.<br />Eksempel på en gyldig IP-adresse: 127.0.0.1<br />Eksempel på gyldig IP-område: 127.0.0.*';
$txt['invalid_username'] = 'Medlemsnavnet ble ikke funnet';
$txt['no_user_selected'] = 'Member not found';
$txt['no_ban_admin'] = 'Hey! We can\'t let you ban an admin. If you are certain about this, demote them first!';
$txt['no_bantype_selected'] = 'Ingen utestengingstype ble valgt';
$txt['ban_not_found'] = 'Utestenging ble ikke funnet';
$txt['ban_unknown_restriction_type'] = 'Type utestenging er ukjent';
$txt['ban_name_empty'] = 'Navnet på utestengningen er tom';
$txt['ban_id_empty'] = 'Dang, sorry. We tried to find this ban ID, but it can\'t be found.';
$txt['ban_group_id_empty'] = 'A ban group needs a group ID, and this group didn\'t have any.';
$txt['ban_no_triggers'] = 'Did you forget to select ban triggers? We need at least one, and we haven\'t got any.';
$txt['ban_ban_item_empty'] = 'Ban trigger not found';
$txt['impossible_insert_new_bangroup'] = 'An error occurred while inserting the new ban';

$txt['like_heading_error'] = 'Error in Likes';
$txt['like_wait_time'] = 'Sorry, you can\'t repeat a like action without waiting %1$s %2$s.';
$txt['like_unlike_error'] = 'Oops, there was an error while liking/unliking the post';
$txt['cant_like_yourself'] = 'Liking your own posts ... it\'s like laughing at your own jokes when there is no one else around  ... lol ... Wait did I just lol myself?';

$txt['ban_name_exists'] = 'Navnet på denne utestengningen  (%1$s) finnes allerede. Vennligst velg et annet navn.';
$txt['ban_trigger_already_exists'] = 'Denne utestengningstrigger (%1$s) finnes allerede i %2$s.';
$txt['attach_check_nag'] = 'Unable to continue due to incomplete data (%1$s).';

$txt['recycle_no_valid_board'] = 'Det er ikke valgt et gyldig forum som papirkurv for emner';
$txt['post_already_deleted'] = 'The topic or message has already been moved to the recycle board. Are you sure you want to delete it completely?<br />If so follow <a href="%1$s">this link</a>';

$txt['login_threshold_fail'] = 'Beklager, du har brukt opp dine innloggingsforsøk. Vennligst prøv igjen senere.';
$txt['login_threshold_brute_fail'] = 'Sorry, but you\'ve reached your login attempts threshold.  Please wait 30 seconds and try again.';

$txt['who_off'] = 'We would love to let you peek at Who\'s Online, but unfortunately right now it\'s disabled.';

$txt['merge_create_topic_failed'] = 'Dang, sorry. We tried, we really did, but creating a new topic failed.';
$txt['merge_need_more_topics'] = 'Merge topics requires at least two topics to merge, but we didn\'t get two. Please try again.';

$txt['post_WaitTime_broken'] = 'Det siste innlegget fra din IP var mindre enn %1$d sekunder siden. Vennligst prøv igjen senere.';
$txt['register_WaitTime_broken'] = 'Du registrerte deg jo allerede for %1$d sekunder siden!';
$txt['login_WaitTime_broken'] = 'Du må vente cirka %1$d sekunder før du kan logge inn igjen, beklager.';
$txt['pm_WaitTime_broken'] = 'Den siste personlig meldingen fra din IP var mindre enn %1$d sekunder siden. Vennligst prøv igjen senere.';
$txt['reporttm_WaitTime_broken'] = 'Det siste emne skrevet fra din IP var mindre enn %1$d sekunder siden. Vennligst prøv igjen senere.';
$txt['sendtopic_WaitTime_broken'] = 'Det siste innlegget som sendtes fra din IP var mindre enn %1$d sekunder siden. Vennligst prøv igjen senere.';
$txt['sendmail_WaitTime_broken'] = 'Den siste e-post sendt fra din IP var mindre enn %1$d sekunder siden. Vennligst prøv igjen senere.';
$txt['search_WaitTime_broken'] = 'Din siste søk var mindre enn %1$d sekunder siden. Vennligst prøv igjen senere.';
$txt['remind_WaitTime_broken'] = 'Your last reminder was less than %1$d seconds ago. Please try again later.';
$txt['contact_WaitTime_broken'] = 'The last time you tried to use the contact form was less than %1$d seconds ago. Please try again later.';

$txt['topic_gone'] = 'We tried very hard to find the topic or board you are looking for, but it\'s nowhere to be found. It appears to be either missing or off limits to you.';
$txt['theme_edit_missing'] = 'We tried very hard to find the file you are trying to edit, but it can\'t be found.';

$txt['no_dump_database'] = 'Sorry, we can\'t let you make database backups. Only administrators can.';
$txt['pm_not_yours'] = 'Den personlige meldingen du prøver å sitere fra er ikke din egen, eller eksisterer ikke. Gå tilbake og prøv på nytt.';
$txt['mangled_post'] = 'En feil oppstod under behanding av inndata, vennligst gå tilbake og prøv på nytt.';
$txt['too_many_groups'] = 'Sorry, you selected too many groups, please remove some.';
$txt['post_upload_error'] = 'The post data is missing. This error could be caused by trying to submit a file larger than allowed by the server.  Please contact your administrator if this problem continues.';
$txt['quoted_post_deleted'] = 'Innlegget du prøver å hente et sitat fra, eksisterer ikke, ble slettet eller er ikke lenger tilgjengelig for deg.';
$txt['pm_too_many_per_hour'] = 'Du har overskredet grensen på %1$d personlige meldinger per time.';
$txt['labels_too_many'] = 'Beklager, men %1$s meldinger har allerede det maksimale antall etiketter som er tillatt!';

$txt['register_only_once'] = 'Beklager, men du kan ikke registrere flere medlemskontoer samtidig fra samme PC.';
$txt['admin_setting_coppa_require_contact'] = 'Du må enten angi en postadresse eller ett faksnummer hvis det kreves godkjennelse av foreldre/foresatte.';

$txt['error_long_name'] = 'Navnet du prøvde å bruke var for langt.';
$txt['error_no_name'] = 'Du sendte ikke med noe navn.';
$txt['error_bad_name'] = 'Navnet du sendte med kan ikke brukes, fordi det er identisk med eller inneholder deler av et reservert navn.';
$txt['error_no_email'] = 'Du sendte ikke med noen epost-adresse.';
$txt['error_bad_email'] = 'Epost-adressen du sendte med er ugyldig.';
$txt['error_email'] = 'email address';
$txt['error_message'] = 'melding';
$txt['error_no_event'] = 'Du sendte ikke med noe navn på hendelsen.';
$txt['error_no_subject'] = 'Emne ble ikke fylt ut.';
$txt['error_no_question'] = 'Ingen spørsmål er fylt inn for denne avstemningen.';
$txt['error_no_message'] = 'Meldingen inneholder ingen tekst.';
$txt['error_long_message'] = 'Din tekst er lengre enn maksimum tillatt lengde (%1$d tegn ).';
$txt['error_no_comment'] = 'Kommentarfeltet er tomt.';
$txt['error_post_too_long'] = 'Your message is too long. Please enter a maximum of 255 characters.';
$txt['error_session_timeout'] = 'Du ble automatisk logget ut i mellomtiden. Prøv å sende på nytt.';
$txt['error_no_to'] = 'Du har ikke spesifisert noen mottakere.';
$txt['error_bad_to'] = 'En eller flere mottakere i "til"-feltet ble ikke funnet.';
$txt['error_bad_bcc'] = 'En eller flere mottakere i "bcc"-feltet ble ikke funnet.';
$txt['error_form_already_submitted'] = 'You already submitted this post!  You might have accidentally double clicked or refreshed the page.';
$txt['error_poll_few'] = 'Du må ha minst to valg-muligheter!';
$txt['error_poll_many'] = 'You must have no more than 256 choices.';
$txt['error_need_qr_verification'] = 'Vennligst fyll ut bekreftelsesfeltet nedenfor for å fullføre innlegget.';
$txt['error_wrong_verification_code'] = 'Bokstavene du skrev inn stemmer ikke med bokstavene som ble vist i bildet.';
$txt['error_wrong_verification_answer'] = 'Du svarte ikke riktig på verifiseringsspørsmålene.';
$txt['error_need_verification_code'] = 'Vennligst skriv inn bekreftelseskoden nedenfor for å fortsette til resultatene.';
$txt['error_bad_file'] = 'Sorry, but the file specified could not be opened: %1$s';
$txt['error_bad_line'] = 'Linjen som er angitt er ugyldig.';
$txt['error_draft_not_saved'] = 'There was an error saving the draft';
$txt['error_name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['smiley_not_found'] = 'Smilefjes ble ikke funnet.';
$txt['smiley_has_no_code'] = 'Det ble ikke gitt noen kode for dette smilefjeset.';
$txt['smiley_has_no_filename'] = 'No file name for this smiley was given.';
$txt['smiley_not_unique'] = 'Et smilefjes med det navnet finnes allerede.';
$txt['smiley_set_already_exists'] = 'Et smilefjes med den adressen finnes allerede';
$txt['smiley_set_not_found'] = 'Smilefjes-sett ble ikke funnet';
$txt['smiley_set_dir_not_found'] = 'The directory of the smiley set %1$s is either invalid or cannot be accessed';
$txt['smiley_set_path_already_used'] = 'Adressen til smilefjes-settet er allerede brukt av et annet sett.';
$txt['smiley_set_unable_to_import'] = 'Kan ikke importere smilefjes-sett. Mappen er enten ugyldig eller ikke tilgjengelig.';

$txt['smileys_upload_error'] = 'Opplasting av fil mislyktes.';
$txt['smileys_upload_error_blank'] = 'All smiley sets must have an image.';
$txt['smileys_upload_error_name'] = 'All smileys must have the same file name.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Ikke tillatt format.';

$txt['search_invalid_weights'] = 'Search weights are not configured properly. At least one weight should be configured to be non-zero. Please report this error to an administrator.';

$txt['package_no_file'] = 'Kunne ikke finne filen!';
$txt['packageget_unable'] = 'Kunne ikke koble til serveren. Prøv <a href="%1$s" target="_blank" class="new_win">denne nettadressen</a> istedet.';
$txt['not_valid_server'] = 'Sorry, packages can only be downloaded like this from servers you have first authorized.';
$txt['package_cant_uninstall'] = 'Denne pakka er enten aldri blitt innstallert eller er avinnstallert allerede - du kan ikke avinnstallere den nå.';
$txt['package_cant_download'] = 'You cannot download or install new packages because the &quot;packages&quot; directory or one of the files in it are not writable!';
$txt['package_upload_error_nofile'] = 'Du har ikke valgt en pakke å laste opp.';
$txt['package_upload_error_failed'] = 'Kunne ikke laste opp pakken, sjekk mapperettighetene!';
$txt['package_upload_error_exists'] = 'The file you are uploading already exists on the server. Please delete it first, then try again.';
$txt['package_upload_already_exists'] = 'The package you are trying to upload already exists on the server under file name: %1$s';
$txt['package_upload_error_supports'] = 'Pakkebehandleren tillater foreløpig kun disse filtypene: %1$s.';
$txt['package_upload_error_broken'] = 'Opplasting av pakken mislyktes på grunn av følgende feil:<br />&quot;%1$s&quot;';

$txt['package_get_error_not_found'] = 'The package you are trying to install cannot be located. You may want to manually upload the package to your &quot;packages&quot; directory.';
$txt['package_get_error_missing_xml'] = 'Pakken du prøver å installere mangler filen package-info.xml, som må være i rotmappen i pakken.';
$txt['package_get_error_is_zero'] = 'Although the package was downloaded to the server it appears to be empty. Please check the &quot;packages&quot; directory, and the &quot;temp&quot; sub-directory are both writable. If you continue to experience this problem you should try extracting the package on your PC and uploading the extracted files into a subdirectory in your &quot;packages&quot; directory and try again. For example, if the package was called shout.tar.gz you should:<br />1) Download the package to your local PC and extract its files.<br />2) Create a new directory in your &quot;packages&quot; folder using an FTP client, in this example you may call it "shout".<br />3) Upload all the files from the extracted package to this directory.<br />4) Go back to the package manager browse page. The package will be automatically found.';
$txt['package_get_error_packageinfo_corrupt'] = 'Unable to find any valid information within the package-info.xml file included within the package. There may be an error in the add-on, or the package may be corrupt.';
$txt['package_get_error_is_theme'] = 'You can\'t install a theme from this section, please use the <a href="{MANAGETHEMEURL}">Theme Management</a> page to upload it';

$txt['no_membergroup_selected'] = 'No member group selected';
$txt['membergroup_does_not_exist'] = 'The member group doesn\'t exist or is invalid.';

$txt['at_least_one_admin'] = 'Det må være minst én administrator på Forumet!';

$txt['error_functionality_not_windows'] = 'Beklager, denne funksjonaliteten er for øyeblikket ikke tilgjengelig for servere som kjører Windows.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Vedlegget ble ikke funnet';

$txt['error_no_boards_selected'] = 'No valid boards were selected.';
$txt['error_invalid_search_string'] = 'Did you forget to enter something to search for?';
$txt['error_invalid_search_string_blacklist'] = 'Your search query contained trivial words. Please try again with a different query.';
$txt['error_search_string_small_words'] = 'Hvert ord må være minst to tegn.';
$txt['error_query_not_specific_enough'] = 'Søket var ikke spesifikt nok. Forsøk med litt lengre søkeord.';
$txt['error_no_messages_in_time_frame'] = 'Fant ingen innlegg i valgt tidsrom.';
$txt['error_no_labels_selected'] = 'No labels were selected.';
$txt['error_no_search_daemon'] = 'Kan ikke få tilgang til søkefunksjon';

$txt['profile_errors_occurred'] = 'The following errors occurred when trying to update your profile';
$txt['profile_error_bad_offset'] = 'Tidsavvik er utenfor gyldig område';
$txt['profile_error_no_name'] = 'Navnefeltet var tomt';
$txt['profile_error_digits_only'] = '\'Antall innlegg\' boksen kan kun inneholde tall.';
$txt['profile_error_name_taken'] = 'The selected user name/display name has already been taken';
$txt['profile_error_name_too_long'] = 'Det valgte navnet er for langt. Det bør ikke være større enn 60 tegn langt';
$txt['profile_error_no_email'] = 'E-postfeltet var tomt';
$txt['profile_error_bad_email'] = 'Du har ikke skrevet en gyldig e-postadresse';
$txt['profile_error_email_taken'] = 'En annen bruker er allerede registrert med den e-postadressen';
$txt['profile_error_no_password'] = 'Du skrev ikke inn passordet ditt';
$txt['profile_error_bad_new_password'] = 'Passordene du skrev inn var ikke like';
$txt['profile_error_bad_password'] = 'Passordet du skrev inn var ikke korrekt';
$txt['profile_error_bad_avatar'] = 'Avataren du har valgt er for stor, eller er ikke en avatar';
$txt['profile_error_password_short'] = 'Your password must be at least %1$s characters long.';
$txt['profile_error_password_restricted_words'] = 'Your password must not contain your user name, email address or other commonly used words.';
$txt['profile_error_password_chars'] = 'Passordet ditt må inneholde en blanding av store og små bokstaver og tall.';
$txt['profile_error_already_requested_group'] = 'Du har allerede en utestående forespørsel til denne gruppen!';
$txt['profile_error_openid_in_use'] = 'Det er allerede en annen bruker med denne OpenID-autentiseringen';
$txt['profile_error_signature_not_yet_saved'] = 'The signature has not been saved.';
$txt['profile_error_personal_text_too_long'] = 'The personal text is too long.';
$txt['profile_error_user_title_too_long'] = 'The custom title is too long.';

$txt['mysql_error_space'] = ' - sjekk tilgjengelig lagringsplass i databasen, eller kontakt server-administrator.';

$txt['icon_not_found'] = 'Symbol-bildet ble ikke funnet i standarddesignet. Forsikre deg om at bildet er lastet opp, og prøv på nytt.';
$txt['icon_after_itself'] = 'The icon cannot be positioned after itself.';
$txt['icon_name_too_long'] = 'Icon file names cannot be more than 16 characters long';

$txt['name_censored'] = 'Beklager, navnet du forsøkte å benytte, %1$s, inneholder ord som er blitt sensurert. Vennligst prøv et annet navn.';

$txt['poll_already_exists'] = 'A topic can only have one poll associated with it.';
$txt['poll_not_found'] = 'Det er ingen avsteming tilknyttet dette emnet!';

$txt['error_while_adding_poll'] = 'Følgende feil oppsto da avstemningen ble forsøkt lagt til';
$txt['error_while_editing_poll'] = 'Følgende feil oppsto da avstemningen ble forsøkt redigert';

$txt['loadavg_search_disabled'] = 'På grunn av stor belastning på serveren er søkefunksjonen midlertidig utilgjengelig.';
$txt['loadavg_generic_disabled'] = 'Beklager, på grunn av stor belastning på serveren er denne funksjonen midlertidig utilgjengelig.';
$txt['loadavg_allunread_disabled'] = 'The server\'s resources are temporarily under a too high demand to find all the topics you have not read.';
$txt['loadavg_unreadreplies_disabled'] = 'Serveren er for tiden høyt belastet. Vennligst prøv igjen om kort tid.';
$txt['loadavg_show_posts_disabled'] = 'Dette medlemmets innlegg er ikke tilgjengelig på grunn av stor belastning på serveren. Vennligst prøv igjen om kort tid.';
$txt['loadavg_unread_disabled'] = 'The server\'s resources are temporarily under a too high demand to list out the topics you have not read.';
$txt['loadavg_userstats_disabled'] = 'Please try again later.  This member\'s statistics are not currently available due to high load on the server.';

$txt['cannot_edit_permissions_inherited'] = 'You cannot edit inherited permissions directly, you must either edit the parent group or edit the member group inheritance.';

$txt['mc_no_modreport_specified'] = 'Du må spesifisere hvilken rapport du vil vise.';
$txt['mc_no_modreport_found'] = 'Den angitte rapporten eksisterer enten ikke eller er ikke tilgjengelig for deg';

$txt['st_cannot_retrieve_file'] = 'Kunne ikke hente filen %1$s';
$txt['admin_file_not_found'] = 'Kunne ikke laste den forespurte filen: %1$s.';

$txt['themes_none_selectable'] = 'Minst ett tema må kunne velges.';
$txt['themes_default_selectable'] = 'Forumets standardtema må være et valgbart tema.';
$txt['ignoreboards_disallowed'] = 'Alternativet til å ignorere kategorier har ikke blitt aktivert.';

$txt['mboards_delete_error'] = 'No category selected.';
$txt['mboards_delete_board_error'] = 'No board selected.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'You can not make a parent its own child.';
$txt['mboards_board_own_child_error'] = 'You can not make a board its own child.';

$txt['smileys_upload_error_notwritable'] = 'Følgende smilefjesmapper er ikke skrivbare: %1$s';
$txt['smileys_upload_error_types'] = 'Smilefjesbilder kan kun være følgende filtyper: %1$s.';

$txt['change_email_success'] = 'Din e-postadresse har blitt endret, og en ny e-post for aktivering har blitt sendt til den.';
$txt['resend_email_success'] = 'En ny e-post med aktivering er blitt sendt.';

$txt['custom_option_need_name'] = 'The profile option must have a name.';
$txt['custom_option_not_unique'] = 'Field name is not unique.';
$txt['custom_option_regex_error'] = 'The regex you entered is not valid';

$txt['warning_no_reason'] = 'Du må oppgi en grunn for å endre status på advarselen til et medlem.';
$txt['warning_notify_blank'] = 'Du valgte å varsle brukeren, men har ikke fylt ut emne/meldingsfeltet.';

$txt['cannot_connect_doc_site'] = 'Could not connect to the documentation site. Please check that your server configuration allows external internet connections and try again later.';

$txt['movetopic_no_reason'] = 'Du må oppgi en grunn for å flytte emnet, eller må du fjern muligheten for å flytte emner';
$txt['movetopic_no_board'] = 'You must choose a board to move the topic to.';

$txt['splittopic_no_reason'] = 'You must enter a reason for splitting the topic, or uncheck the option to \'post a redirection message\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Den forespurte identifikator kom ikke tilbake med riktig informasjon.';
$txt['openid_return_no_mode'] = 'Identitetsleverandøren svarte ikke med Open ID-modus.';
$txt['openid_not_resolved'] = 'Identitetsleverandøren godkjenner ikke din forespørsel.';
$txt['openid_no_assoc'] = 'Kunne ikke finne den forespurte tilknytningen til identitetsleverandøren.';
$txt['openid_sig_invalid'] = 'Signaturen fra identitetsleverandøren er ugyldig.';
$txt['openid_load_data'] = 'Kunne ikke laste inn data fra dine innloggingsforespørsel. Vennligst prøv igjen.';
$txt['openid_not_verified'] = 'The supplied OpenID has not been verified yet.  Please log in to verify.';

$txt['error_custom_field_too_long'] = '&quot;%1$s&quot; feltet kan ikke være større enn %2$d tegn.';
$txt['error_custom_field_invalid_email'] = '&quot;%1$s&quot; feltet må være en gyldig e-postadresse.';
$txt['error_custom_field_not_number'] = '&quot;%1$s&quot; feltet må være numerisk.';
$txt['error_custom_field_inproper_format'] = '&quot;%1$s&quot; feltet er et ugyldig format.';
$txt['error_custom_field_empty'] = '&quot;%1$s&quot; feltet kan ikke være tomt.';

$txt['email_no_template'] = 'Malen for e-post &quot;%1$s&quot; ble ikke funnet.';

$txt['search_api_missing'] = 'The search API could not be found. Please contact the admin to check they have uploaded the correct files.';
$txt['search_api_not_compatible'] = 'The selected search API the forum is using is out of date - falling back to standard search. Please check the file %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Du kan ikke gjenopprette det første innlegget i et emne.';
$txt['restored_disabled'] = 'Gjenoppretting av emner har blitt deaktivert.';
$txt['restore_not_found'] = 'The following messages could not be restored; the original topic may have been removed: %1$s You will need to move these manually.';

$txt['error_invalid_dir'] = 'Mappen du skrev inn er ugyldig.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'The Sub-action you requested is not defined';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'No sortable items were found';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
