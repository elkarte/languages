<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Fora';
$txt['admin_back_to'] = 'Back to admin panel';
$txt['admin_users'] = 'Medlemmer';
$txt['admin_newsletters'] = 'Nyhetsbrev';
$txt['include_these'] = 'Members to include';
$txt['exclude_these'] = 'Members to exclude';
$txt['admin_newsletters_select_groups'] = 'Groups to include';
$txt['admin_newsletters_exclude_groups'] = 'Groups to exclude';
$txt['admin_edit_news'] = 'Nyheter';
$txt['admin_groups'] = 'Member groups';
$txt['admin_members'] = 'Behandle medlemmer';
$txt['admin_members_list'] = 'Under er en liste over alle medlemmene som er registert på forumet.';
$txt['admin_next'] = 'Neste';
$txt['admin_censored_words'] = 'Sensurerte ord';
$txt['admin_censored_where'] = 'Enter the word to be censored into the left box and the word to change it to, into the right box. Then select if you want to check the whole word and the case. When you\'re finished with each word, click Save. Multiple entries can be made prior to saving by clicking the \'Add another word\' button.';
$txt['admin_censored_desc'] = 'Due to the public nature of forums there may be some words that you wish to prohibit being posted by users of your forum. You can enter any words below that you wish to be censored whenever used by a member.<br />Clear a box to remove that word from the censor.';
$txt['admin_reserved_names'] = 'Reserverte navn';
$txt['admin_template_edit'] = 'Edit your forum template';
$txt['admin_modifications'] = 'Add-on Settings';
$txt['admin_security_moderation'] = 'Sikkerhet og moderation';
$txt['admin_server_settings'] = 'Serverinnstillinger';
$txt['admin_reserved_set'] = 'Set reserved names';
$txt['admin_reserved_line'] = 'Et reservert ord per linje.';
$txt['admin_basic_settings'] = 'Denne siden lar deg endre basisinnstillingene for forumet. Vær forsiktig med disse innstillingene, da de kan gjøre forumet ustabilt. Merk deg også at noen av innstillingene (f.eks. tidsformat) er basisinnstillinger som gjelder kun for gjester.';
$txt['admin_maintain'] = 'Aktiver vedlikeholdsmodus';
$txt['admin_title'] = 'Forumtittel';
$txt['admin_url'] = 'Nettadressen til forumet';
$txt['cookie_name'] = 'Cookie name';
$txt['admin_webmaster_email'] = 'Webmaster email address';
$txt['boarddir'] = 'ElkArte Directory';
$txt['sourcesdir'] = 'Mappe til Sources';
$txt['cachedir'] = 'Mappe for hurtiglager';
$txt['admin_news'] = 'Aktivér nyheter';
$txt['admin_guest_post'] = 'Enable guest posting';
$txt['admin_manage_members'] = 'Medlemmer';
$txt['admin_main'] = 'Hoved';
$txt['admin_config'] = 'Innstillinger';
$txt['admin_version_check'] = 'Detailed version check';
$txt['admin_elkfile'] = 'ElkArte File';
$txt['admin_elkpackage'] = 'ElkArte Package';
$txt['admin_logoff'] = 'End Admin Session';
$txt['admin_maintenance'] = 'Vedlikehold';
$txt['admin_image_text'] = 'Vise knapper som bilder istedet for tekst';
$txt['admin_credits'] = 'Medvirkende';
$txt['admin_agreement'] = 'Viser og krever registreringserklæring ved registrering';
$txt['admin_checkbox_agreement'] = 'Show a checkbox for the agreement in registration form instead of a full page';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Standard';
$txt['admin_agreement_select_language'] = 'Språk som skal redigeres';
$txt['admin_agreement_select_language_change'] = 'Endre';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Slett valgte medlemmer';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Repair All boards and topics';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Please place one news item per box. BBC tags, such as <span>[b]</span>, <span>[i]</span> and <span>[u]</span> are allowed in your news, as well as smileys. Clear a news item\'s text box to remove it.';
$txt['administrators'] = 'Administrator(er)';
$txt['admin_reserved_desc'] = 'Reserved names will keep members from registering certain user names or using these words in their displayed names. Choose the options you wish to use from the bottom before submitting.';
$txt['admin_activation_email'] = 'Send aktiverings e-post til nye medlemmer ved registrering';
$txt['admin_match_whole'] = 'Treff på hele ordet. Dersom ikke avkrysset, treff inni navn.';
$txt['admin_match_case'] = 'Treff på tegnsetting. Dersom ikke avkrysset, vil søket ikke ta hensyn til STORE eller små bokstaver.';
$txt['admin_check_user'] = 'Check user name.';
$txt['admin_check_display'] = 'Kontroller visningsnavn.';
$txt['admin_newsletter_send'] = 'You can email anyone from this page. The email addresses of the selected member groups should appear below, but you may remove or add any email addresses you wish. Be sure that each address is separated in this fashion: \'address1; address2\'.';
$txt['admin_fader_delay'] = 'Fadeforsinkelse (sekunder) mellom elementer i nyhetsfaderen';
$txt['zero_for_no_limit'] = '(0 for ingen grense)';
$txt['zero_to_disable'] = '(0 to disable)';

$txt['admin_backup_fail'] = 'Kunne ikke ta sikkerhetskopi av Settings.php - se til at Settings_bak.php er skrivbar og eksisterer.';
$txt['modSettings_info'] = 'Settings for General features, Karma, Signatures, Likes and much more that control how this forum operates.';
$txt['database_server'] = 'Serveren til databasen';
$txt['database_user'] = 'Database User';
$txt['database_password'] = 'Passord for databasen';
$txt['database_name'] = 'Navn på databasen';
$txt['registration_agreement'] = 'registreringserklæring';
$txt['registration_agreement_desc'] = 'Denne erklæringen vises når et medlem registrerer seg på forumet og må aksepteres før registreringen fortsetter.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Prefiks på tabeller i databasen';
$txt['errors_list'] = 'Feilmeldinger på forumet';
$txt['errors_found'] = 'Følgende feilmeldinger ødelegger for forumet (tomt hvis ingen)';
$txt['errors_fix'] = 'Ønsker du å forsøke å reparere disse feilene?';
$txt['errors_do_recount'] = 'All errors have been fixed and a salvage area has been created. Please click the button below to recount some key statistics.';
$txt['errors_recount_now'] = 'Telle statistikken på nytt';
$txt['errors_fixing'] = 'Reparerer feil på forumet';
$txt['errors_fixed'] = 'All errors fixed. Please check on any categories, boards, or topics created to decide what to do with them.';
$txt['attachments_avatars'] = 'Vedlegg og avatarer';
$txt['attachments_desc'] = 'Her kan du administrere og behandle vedlagte filer. Du kan slette vedlegg etter størrelse og etter dato fra siden. Statistikk for vedlegg vises også under.';
$txt['attachment_stats'] = 'File attachment statistics';
$txt['attachment_integrity_check'] = 'Attachment integrity check';
$txt['attachment_integrity_check_desc'] = 'Denne funksjonen vil sjekke integriteten og størrelser av vedlegg og filnavn oppført i databasen, og om nødvendig, fikse feilene som finnes.';
$txt['attachment_check_now'] = 'Kjør sjekk nå';
$txt['attachment_pruning'] = 'Slett vedlegg';
$txt['attachment_pruning_message'] = 'Melding å legge til innlegget';
$txt['attachment_pruning_warning'] = 'Er du sikker på at du vil slette disse vedleggene?\\nDette kan ikke angres!';

$txt['attachment_total'] = 'Total attachments';
$txt['attachmentdir_size'] = 'Total size of all attachment directories';
$txt['attachmentdir_size_current'] = 'Total size of current attachment directory';
$txt['attachmentdir_files_current'] = 'Total files in current attachment directory';
$txt['attachment_space'] = 'Total space available';
$txt['attachment_files'] = 'Total files remaining';

$txt['attachment_options'] = 'Alternativer for vedlegg';
$txt['attachment_log'] = 'Logg for vedlegg';
$txt['attachment_remove_old'] = 'Remove attachments older than %1$s days';
$txt['attachment_remove_size'] = 'Remove attachments larger than %1$s KiB';
$txt['attachment_name'] = 'Attachment name';
$txt['attachment_file_size'] = 'Størrelse';
$txt['attachmentdir_size_not_set'] = 'Ingen maksimumsgrense er satt';
$txt['attachmentdir_files_not_set'] = 'No directory file limit is currently set';
$txt['attachment_delete_admin'] = '[vedlegget ble slettet av en administrator.]';
$txt['live'] = 'Latest Software Updates';
$txt['remove_all'] = 'Clear Log';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(mer detaljert)';

$txt['lfyi'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['manage_calendar'] = 'Kalender';
$txt['manage_search'] = 'Søk';
$txt['viewmembers_online'] = 'Sist aktiv';

$txt['smileys_manage'] = 'Smilefjes og innleggs-symboler';
$txt['smileys_manage_info'] = 'Install new smiley sets, add smileys to existing sets or manage your message icons.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Install, download and upload Modification packages; check File Permissions and FTP settings.';
$txt['theme_admin'] = 'Theme Management';
$txt['theme_admin_info'] = 'Install new themes, select themes that are available for your users and set or reset theme options.';
$txt['registration_center'] = 'Registreringsbehandling';
$txt['member_center_info'] = 'View the member list, search for members, or manage account approvals and activations.';
$txt['viewmembers_online'] = 'Sist aktiv';

$txt['display_name'] = 'Visningsnavn';
$txt['email_address'] = 'E-postadresse';
$txt['ip_address'] = 'IP-adresse';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'ukjent';
$txt['security_wrong'] = 'Administration login attempt!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Send i HTML format.  (med dette aktivert kan du inkludere HTML-koder i din e-post.)';
$txt['email_parsed_html'] = 'Legg til &lt;br /&gt;s og &amp;nbsp;s til denne meldingen.';
$txt['email_variables'] = 'In this message you can use a few &quot;variables&quot;.<a href="{help_emailmembers}" class="help"> Click here for more information</a>.';
$txt['email_force'] = 'Send denne til medlemmer selv om de har sikret seg mot kunngjøringer.';
$txt['email_as_pms'] = 'Send denne til disse medlemsgruppene som PM.';
$txt['email_continue'] = 'Fortsett';
$txt['email_done'] = 'ferdig.';
$txt['email_members_succeeded'] = 'You have successfully sent your newsletter!';

$txt['ban_title'] = 'Liste over utestengelser';
$txt['ban_ip'] = 'Utesteng IP: (f.eks 192.168.12.213 or 128.0.*.*) - en oppføring per linje';
$txt['ban_email'] = 'Utesteng e-postadresse: (f.eks kjekkfyr@noen.no) - en oppføringper linje';
$txt['ban_username'] = 'Utesteng brukernavn: (f.eks tulling) - én oppføring per line';

$txt['ban_errors_detected'] = 'The following error or errors occurred while saving or editing the ban or the trigger';
$txt['ban_description'] = 'Here you can ban troublesome people either by IP, hostname, user name, or email.';
$txt['ban_add_new'] = 'Add new ban';
$txt['ban_banned_entity'] = 'Detaljer for utestengelsen';
$txt['ban_on_ip'] = 'Utesteng IP (e.g. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Utesteng vertsnavn (f.eks *.mil)';
$txt['ban_on_email'] = 'Utesteng e-postdomene (f.eks *@farligside.no)';
$txt['ban_on_username'] = 'Ban on User Name';
$txt['ban_notes'] = 'Notater';
$txt['ban_restriction'] = 'Begrensning';
$txt['ban_full_ban'] = 'Full utestengelse';
$txt['ban_partial_ban'] = 'Delvis utestengelse';
$txt['ban_cannot_post'] = 'Kan ikke skrive';
$txt['ban_cannot_register'] = 'Kan ikke registere';
$txt['ban_cannot_login'] = 'Kan ikke logge inn';
$txt['ban_add'] = 'Legg til';
$txt['ban_edit_list'] = 'Liste over utestengelser';
$txt['ban_type'] = 'Utestengelsestype';
$txt['ban_days'] = 'dag(er)';
$txt['ban_will_expire_within'] = 'Vil være utestengt i';
$txt['ban_added'] = 'Lagt til';
$txt['ban_expires'] = 'Utgår';
$txt['ban_hits'] = 'Treff';
$txt['ban_actions'] = 'Handlinger';
$txt['ban_expiration'] = 'Utgår';
$txt['ban_reason_desc'] = 'Grunn for utestengelse som blir vist til utestengt medlem.';
$txt['ban_notes_desc'] = 'Notater som vil være til hjelp for andre administratorer.';
$txt['ban_remove_selected'] = 'Slett valgt(e)';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Er du sikker på at du vil slette de valgte utestengelsene?';
$txt['ban_modify'] = 'Rediger';
$txt['ban_name'] = 'Navn på utestengelse';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Endre utestengelse';
$txt['ban_add_notes'] = '<strong>Merk</strong>: etter å ha lagt til en utestengelse, kan du legge til flere treff for utestengelsen, som IP-adresser, vertsanavn og e-postadresser.';
$txt['ban_expired'] = 'Utgått / deaktivert';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Ingen begrensing er valgt.';

$txt['ban_triggers'] = 'Treff';
$txt['ban_add_trigger'] = 'Legg til treff';
$txt['ban_add_trigger_submit'] = 'Legg til';
$txt['ban_edit_trigger'] = 'Rediger';
$txt['ban_edit_trigger_title'] = 'Endre treff for utestengelsen';
$txt['ban_edit_trigger_submit'] = 'Rediger';
$txt['ban_remove_selected_triggers'] = 'Fjern valgte utestengelsestreff';
$txt['ban_no_entries'] = 'Det er foreløpig ingen forbud som brukes.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Er du sikker på at du vil fjerne valgte utstengelsestreff?';
$txt['ban_trigger_browse'] = 'Bla igjennom treff';
$txt['ban_trigger_browse_description'] = 'This screen shows all banned entities grouped by IP address, hostname, email address and user name.';

$txt['ban_log'] = 'Logg for utestengelser';
$txt['ban_log_description'] = 'Denne loggen viser forsøk fra utestengte medlemmer som vil komme inn på forumet (gjelder kun de som er fullstendig utestengt og de som ikke kan registere seg).';
$txt['ban_log_no_entries'] = 'Det er ingen loggoppføringer over forbudte elementer';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'E-postadresse';
$txt['ban_log_member'] = 'Medlem';
$txt['ban_log_date'] = 'Dato';
$txt['ban_log_remove_all'] = 'Clear Log';
$txt['ban_log_remove_all_confirm'] = 'Er du sikker på at du vil fjerne alle elementene i loggen?';
$txt['ban_log_remove_selected'] = 'Slett valgt(e)';
$txt['ban_log_remove_selected_confirm'] = 'Er du sikker på at du vil fjerne valgte elementer i loggen?';
$txt['ban_no_triggers'] = 'Det er ingen triggere på forbudte elementer';

$txt['settings_not_writable'] = 'Disse innstillingene kan ikke bli endret fordi Settings.php er satt til skrivebeskyttet.';

$txt['maintain_title'] = 'Vedlikehold forumet';
$txt['maintain_info'] = 'Basic forum backups, Database error checking, Clearing the Cache, Integration Hooks and more.';
$txt['maintain_sub_database'] = 'Database';
$txt['maintain_sub_routine'] = 'Rutine';
$txt['maintain_sub_members'] = 'Medlemmer';
$txt['maintain_sub_topics'] = 'Emner';
$txt['maintain_sub_attachments'] = 'Vedlegg';
$txt['maintain_done'] = 'Vedlikehold utført \'%1$s\'.';
$txt['maintain_fail'] = 'The maintenance task \'%1$s\' failed.';
$txt['maintain_no_errors'] = 'Congratulations, no errors were found.  Thanks for checking.';

$txt['maintain_tasks'] = 'Planlagte oppgavr';
$txt['maintain_tasks_desc'] = 'Manage all the scheduled tasks.';

$txt['scheduled_log'] = 'Utførte oppgaver';
$txt['scheduled_log_desc'] = 'Lists logs of the tasks that were run.';
$txt['admin_log'] = 'Administrasjonslogg';
$txt['admin_log_desc'] = 'Lister administrative oppgaver som har blitt utført av admin på forumet ditt.';
$txt['moderation_log'] = 'Moderatorlogg';
$txt['moderation_log_desc'] = 'Lister moderasjonsaktiviteter som er utført av moderatorer på forumet ditt.';
$txt['badbehavior_log'] = 'Bad Behavior Log';
$txt['badbehavior_log_desc'] = 'Lists requests that were blocked or marked suspicious by bad behavior.  If verbose logging is on all HTTP requests are listed.';
$txt['spider_log_desc'] = 'Gjennomgå oppføringene relatert til søkemotorers aktivitet på forumet ditt.';
$txt['pruning_log_desc'] = 'Bruk disse verktøyene til å rydde i gamle oppføringer i de ulike loggene.';

$txt['mailqueue_title'] = 'E-post';

$txt['db_error_send'] = 'Send e-post ved tilkoblingsproblemer til MySQL-databasen?';
$txt['db_persist'] = 'Bruke en dedikert tilkobling?';
$txt['ssi_db_user'] = 'Database user name to use in SSI mode';
$txt['ssi_db_passwd'] = 'Database passord for å bruke i SSI-modus';

$txt['default_language'] = 'Default forum language';

$txt['maintenance_subject'] = 'Emne på meldingen';
$txt['maintenance_message'] = 'Selve meldingen';

$txt['errlog_desc'] = 'Loggen over feil lagrer alle feilmeldinger som oppstår på forumet. Dette er en kronologisk liste over når feilene oppstod.  For å slette noen av meldingene fra loggen, huk av i boksen ved siden av, og trykk på %1$s knappen på bunnen av siden.';
$txt['errlog_no_entries'] = 'Det er foreløpig ingen feiloppføringer i loggen';

$txt['theme_settings'] = 'Designinnstillinger';
$txt['theme_edit_settings'] = 'Edit this theme\'s settings';
$txt['theme_current_settings'] = 'Gjeldende design';

$txt['dvc_your'] = 'Din versjon';
$txt['dvc_current'] = 'Nyeste versjon';
$txt['dvc_sources'] = 'Ressurser';
$txt['dvc_admin'] = 'Administrator';
$txt['dvc_controllers'] = 'Controllers';
$txt['dvc_database'] = 'Database';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Hoveddesign';
$txt['dvc_templates'] = 'Gjeldende design';
$txt['dvc_languages'] = 'Språkfiler';

$txt['smileys_default_set_for_theme'] = 'Select default smiley set for this theme:';
$txt['smileys_no_default'] = 'Use default smiley set';

$txt['censor_test'] = 'Test sensurerte ord';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Ignore case when censoring.';
$txt['censor_whole_words'] = 'Check only whole words.';
$txt['censor_allow'] = 'Allow users to turn off word censoring.';

$txt['admin_confirm_password'] = '(confirm password)';
$txt['admin_incorrect_password'] = 'Feil passord';

$txt['date_format'] = '(ÅÅÅÅ-MM-DD)';
$txt['undefined_gender'] = 'Ikke definert';
$txt['age'] = 'Alder';
$txt['activation_status'] = 'Status for aktivering';
$txt['activated'] = 'Aktivert';
$txt['not_activated'] = 'Ikke aktivert';
$txt['is_banned'] = 'Banned';
$txt['primary'] = 'Primær';
$txt['additional'] = 'Ekstra';
$txt['wild_cards_allowed'] = 'jokertegn som * og ? er tillatt';
$txt['member_part_of_these_membergroups'] = 'Member is part of these member groups';
$txt['membergroups'] = 'Member groups';
$txt['confirm_delete_members'] = 'Er du sikker på at du vil slette de valgte medlemmene?';

$txt['support_credits_title'] = 'Support &amp; Credits';
$txt['support_credits_info'] = 'Support links for most common issues, the relevant forum version information you will be asked for when you request help and a list of contributors to the ElkArte project.';
$txt['support_title'] = 'Hjelpinformasjon';
$txt['support_versions_current'] = 'Current version';
$txt['support_versions_forum'] = 'This version';
$txt['support_versions_db'] = '%1$s versjon';
$txt['support_versions_server'] = 'Serverversjon';
$txt['support_versions_gd'] = 'GD-versjon';
$txt['support_versions_imagick'] = 'Imagick version';
$txt['support_versions'] = 'Versjoninformasjon';
$txt['support_resources'] = 'Support ressurser';
$txt['support_resources_p1'] = 'Our <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> provides the main documentation for ElkArte. The ElkArte Online Manual has many documents to help answer support questions and explain <a href="%2$s" target="_blank" class="new_win">Features</a>, <a href="%3$s" target="_blank" class="new_win">Settings</a>, <a href="%4$s" target="_blank" class="new_win">Themes</a>, <a href="%5$s" target="_blank" class="new_win">Packages</a>, etc. The Online Manual documents each area of ElkArte thoroughly and should answer most questions quickly.';
$txt['support_resources_p2'] = 'If you can\'t find the answers to your questions in the Documentation Wiki, you may want to search our <a href="%1$s" target="_blank" class="new_win">Support Community</a> or ask for assistance in our support boards. The ElkArte Support Community can be used for <a href="%2$s" target="_blank" class="new_win">support</a>, <a href="%3$s" target="_blank" class="new_win">customization</a>, and many other things such as discussing ElkArte, finding a host, and discussing administrative issues with other forum administrators.';

$txt['latest_updates'] = 'Latest noteworthy updates';
$txt['new_in_1_0_2'] = 'The most significant change in ElkArte 1.0.2 is avatar permission management. Currently each method of setting an avatar is permission-based, requiring the enabling/disabling of each method for each group. With 1.0.2 avatars are simply enabled/disabled by user group, this allows the enabled groups to add an avatar (by all available methods).<br />
The only permission available is a general one to allow members to change or not their avatars. Additionally there is only one setting for maximum width and height of avatars, these values apply to all avatar methods.<br /><br />
Due to the nature of the changes it was not impossible to migrate existing settings to the new format, for that reason you are encouraged to visit the <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Settings</a> page and set the options you prefer.';

$txt['edit_permissions_info'] = 'Use permission settings to manage global and specific board features and what actions that guest, members and moderators can do.';
$txt['membergroups_members'] = 'Vanlige medlemmer';
$txt['membergroups_guests'] = 'Gjester';
$txt['membergroups_add_group'] = 'Legg til gruppe';
$txt['membergroups_permissions'] = 'Tillatelser';

$txt['permitgroups_restrict'] = 'Begrenset';
$txt['permitgroups_standard'] = 'Standard';
$txt['permitgroups_moderator'] = 'Moderator';
$txt['permitgroups_maintenance'] = 'Vedlikehold';

$txt['confirm_delete_attachments'] = 'Er du sikker på at du vil slette valgt(e) vedlegg(ene)?';
$txt['attachment_manager_browse_files'] = 'Bla igjennom filer';
$txt['attachment_manager_repair'] = 'Vedlikehold';
$txt['attachment_manager_avatars'] = 'Avatarer';
$txt['attachment_manager_attachments'] = 'Vedlegg';
$txt['attachment_manager_thumbs'] = 'Miniatyrer';
$txt['attachment_manager_last_active'] = 'Sist aktiv';
$txt['attachment_manager_member'] = 'Medlem';
$txt['attachment_manager_avatars_older'] = 'Remove avatars from members not active for more than %1$s days';
$txt['attachment_manager_total_avatars'] = 'Total avatars';

$txt['attachment_manager_avatars_no_entries'] = 'Det er foreløpig ingen avatarer.';
$txt['attachment_manager_attachments_no_entries'] = 'Det er ingen vedlegg.';
$txt['attachment_manager_thumbs_no_entries'] = 'Det er foreløpig ingen miniatyrbilder.';

$txt['attachment_manager_settings'] = 'Vedlegginnstillinger';
$txt['attachment_manager_avatar_settings'] = 'Avatarinnstillinger';
$txt['attachment_manager_browse'] = 'Bla igjennom filer';
$txt['attachment_manager_maintenance'] = 'Filvedlikehold';
$txt['attachmentEnable'] = 'Vedleggsmodus';
$txt['attachmentEnable_deactivate'] = 'Deaktivere vedlegg';
$txt['attachmentEnable_enable_all'] = 'Aktivere alle vedlegg';
$txt['attachmentEnable_disable_new'] = 'Deaktivere nye vedlegg';
$txt['attachmentCheckExtensions'] = 'Kontroller filendelse på vedlegg';
$txt['attachmentExtensions'] = 'Tillatte filendelser på vedlegg';
$txt['attachmentRecodeLineEndings'] = 'Endre linjeavslutninger i tekstlige vedlegg';
$txt['attachmentShowImages'] = 'Vise bildevedlegg som bilde under innlegget';
$txt['attachmentUploadDir'] = 'Vedleggsmappe';
$txt['attachmentUploadDir_multiple_configure'] = 'Manage attachment directories';
$txt['attachmentDirSizeLimit'] = 'Max attachment directory space';
$txt['attachmentPostLimit'] = 'Max attachment size per post';
$txt['attachmentSizeLimit'] = 'Max size per attachment';
$txt['attachmentNumPerPostLimit'] = 'Max number of attachments per post';
$txt['attachment_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Image re-encoding is not possible.';
$txt['attachment_postsize_warning'] = 'The current php.ini setting \'post_max_size\' may not support this.';
$txt['attachment_filesize_warning'] = 'The current php.ini setting \'upload_max_filesize\' may not support this.';
$txt['attachment_image_reencode'] = 'Re-kode potensielt farlige bildevedlegg';
$txt['attachment_image_reencode_note'] = '(requires GD module or ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Den omfattende sikkerhetskontroller kan resultere i at et stort antall avviste vedlegg.';
$txt['attachment_image_paranoid'] = 'Utfør omfattende sikkerhetskontroller på opplastet bildevedlegg';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'Endre bildestørrelse ved visning under innlegget';
$txt['attachment_thumb_png'] = 'Lagre miniatyrbilder som PNG';
$txt['attachment_thumb_memory'] = 'Adaptive thumbnail memory';
$txt['attachment_thumb_memory_note2'] = 'If the system can not get the memory no thumbnail will be created.';
$txt['attachment_thumb_memory_note1'] = 'Leave this unchecked to always attempt to create a thumbnail';
$txt['attachmentThumbWidth'] = 'Maksimumsbredde for miniatyr';
$txt['attachmentThumbHeight'] = 'Maksimumshøyde for miniatyr';
$txt['attachment_thumbnail_settings'] = 'Thumbnail Settings';
$txt['attachment_security_settings'] = 'Attachment security settings';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'Eksisterer ikke';
$txt['attach_dir_not_writable'] = 'Ikke akrivbar';
$txt['attach_dir_files_missing'] = 'Files Missing (<a href="{repair_url}">Repair</a>)';
$txt['attach_dir_unused'] = 'Ubrukt';
$txt['attach_dir_empty'] = 'Empty';
$txt['attach_dir_ok'] = 'OK';
$txt['attach_dir_basedir'] = 'Base directory';

$txt['attach_dir_desc'] = 'Create new directories or change the current directory below. Directories can be renamed as long as they do not contain a sub-directory. If the new directory is to be created within the forum directory structure, you\'ll just need to type the directory name. To remove a directory, blank the path input field. Directories can not be deleted if they contain either files or sub-directories (shown in brackets next to the file count).';
$txt['attach_dir_base_desc'] = 'You may use the area below to change the current base directory or create a new one. New base directories are also added to the Attachment Directory list. You may also designate an existing directory to be a base directory.';
$txt['attach_dir_save_problem'] = 'Oops, there seems to be a problem.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory. Please do so using a FTP client or your site file manager.';
$txt['attachments_no_write'] = 'This directory has been created but is not writable. Please attempt to do so using a FTP client or your site file manager.';
$txt['attach_dir_reserved'] = 'Unable to add. This directory is a system directory and cannot be used for attachments.';
$txt['attach_dir_duplicate_msg'] = 'Unable to add. This directory already exists.';
$txt['attach_dir_exists_msg'] = 'Unable to move. A directory already exists at that path.';
$txt['attach_dir_base_dupe_msg'] = 'Unable to add. This base directory has already been created.';
$txt['attach_dir_base_no_create'] = 'Unable to create. Please verify the path input or create this directory using an FTP client or site file manager and re-try.';
$txt['attach_dir_no_rename'] = 'Unable to move or rename. Please verify that the path is correct or that this directory does not contain any sub-directories.';
$txt['attach_dir_no_delete'] = 'Is not empty and can not be deleted. Please do so using a FTP client or site file manager.';
$txt['attach_dir_no_remove'] = 'Still contains files or is a base directory and can not be deleted.';
$txt['attach_dir_is_current'] = 'Unable to remove while it is selected as the current directory.';
$txt['attach_dir_is_current_bd'] = 'Unable to remove while it is selected as the current base directory.';
$txt['attach_last_dir'] = 'Last active attachment directory';
$txt['attach_current_dir'] = 'Current attachment directory';
$txt['attach_current'] = 'Current';
$txt['attach_path_manage'] = 'Manage attachment paths';
$txt['attach_directories'] = 'Attachment Directories';
$txt['attach_paths'] = 'Attachment directory paths';
$txt['attach_path'] = 'Stier';
$txt['attach_current_size'] = 'Size (KiB)';
$txt['attach_num_files'] = 'Filer';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Legg til sti';
$txt['attach_path_current_bad'] = 'Ugyldig vedleggssti.';
$txt['attachmentDirFileLimit'] = 'Maximum number of files per directory';

$txt['attach_base_paths'] = 'Base directory paths';
$txt['attach_num_dirs'] = 'Directories';
$txt['max_image_width'] = 'Max display width of posted or attached images';
$txt['max_image_height'] = 'Max display height of posted or attached images';

$txt['automanage_attachments'] = 'Choose the method for the management of the attachment directories';
$txt['attachments_normal'] = '(Manual) ElkArte default behaviour';
$txt['attachments_auto_years'] = '(Auto) Subdivide by years';
$txt['attachments_auto_months'] = '(Auto) Subdivide by years and months';
$txt['attachments_auto_days'] = '(Auto) Subdivide by years, months and days';
$txt['attachments_auto_16'] = '(Auto) 16 random directories';
$txt['attachments_auto_16x16'] = '(Auto) 16 random directories with 16 random sub-directories';
$txt['attachments_auto_space'] = '(Auto) When either directory space limit is reached';

$txt['use_subdirectories_for_attachments'] = 'Create new directories within a base directory';
$txt['use_subdirectories_for_attachments_note'] = 'Otherwise any new directories will be created within the forum\'s main directory.';
$txt['basedirectory_for_attachments'] = 'Set a base directory for attachments';
$txt['basedirectory_for_attachments_current'] = 'Current base directory';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Please note that the directory is wrong. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">There seems to be a problem with this directory. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';

$txt['attachment_transfer'] = 'Transfer Attachments';
$txt['attachment_transfer_desc'] = 'Transfer files between directories.';
$txt['attachment_transfer_select'] = 'Select directory';
$txt['attachment_transfer_now'] = 'Transfer';
$txt['attachment_transfer_from'] = 'Transfer files from';
$txt['attachment_transfer_auto'] = 'Move them automatically by space or file count';
$txt['attachment_transfer_auto_select'] = 'Select base directory';
$txt['attachment_transfer_to'] = 'Or move them to a specific directory.';
$txt['attachment_transfer_empty'] = 'Move all files from the source directory.';
$txt['attachment_transfer_no_base'] = 'No base directories available.';
$txt['attachment_transfer_forum_root'] = 'Forum root directory.';
$txt['attachment_transfer_no_room'] = 'Directory size or file count limit reached.';
$txt['attachment_transfer_no_find'] = 'No files were found to transfer.';
$txt['attachments_transfered'] = '%1$d files were transferred to %2$s';
$txt['attachments_not_transfered'] = '%1$d files were not transferred.';
$txt['attachment_transfer_no_dir'] = 'Either the source directory or one of the target options were not selected.';
$txt['attachment_transfer_same_dir'] = 'You cannot select the same directory as both the source and target.';
$txt['attachment_transfer_progress'] = 'Please wait. Transfer in progress.';

$txt['avatar_settings'] = 'General avatar settings';
$txt['avatar_default'] = 'Enable a default avatar for all users without their own avatar';
$txt['avatar_directory'] = 'Avatarmappe';
$txt['avatar_url'] = 'Avatarsadresse';
$txt['avatar_max_width'] = 'Maximum width of avatars in pixels (px)';
$txt['avatar_max_height'] = 'Maximum height of avatars in pixels (px)';
$txt['avatar_action_too_large'] = 'Om avataren er for stor...';
$txt['option_refuse'] = 'Ikke godta den';
$txt['option_resize'] = 'Let the CSS resize it';
$txt['option_download_and_resize'] = 'Download and resize it (requires GD module or ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Enable use of gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'Bruk PNG for avatarene som har fått ny størrelse';
$txt['avatar_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Some avatar features are disabled.';
$txt['avatar_external'] = 'Eksertne avatarer';
$txt['avatar_external_enabled'] = 'Enable use of external (remote/URL) avatars';
$txt['avatar_upload'] = 'Opplastbare avatarer';
$txt['avatar_resize_options'] = 'Server storage options';
$txt['avatar_upload_enabled'] = 'Enable the upload of avatars';
$txt['avatar_server_stored'] = 'Lokale avatarer';
$txt['avatar_stored_enabled'] = 'Enable the selection of server stored avatars';
$txt['profile_set_avatar'] = 'Member groups allowed to select an avatar';
$txt['avatar_select_permission'] = 'Velg rettigheter for hver gruppe';
$txt['avatar_download_external'] = 'Laste ned avatar fra spesifisert adresse';
$txt['custom_avatar_enabled'] = 'Laste opp avatarer til...';
$txt['option_attachment_dir'] = 'Vedleggmappe';
$txt['option_specified_dir'] = 'Egen mappe...';
$txt['custom_avatar_dir'] = 'Opplastningsmappe';
$txt['custom_avatar_dir_desc'] = 'This should be a valid and writable directory, different than the server-stored directory.';
$txt['custom_avatar_url'] = 'Opplastningsadresse';
$txt['custom_avatar_check_empty'] = 'Den egendefinerte avatarmappen du har angitt kan være tom eller ugyldig. Vennligst påse at disse innstillingene er riktige.';
$txt['avatar_reencode'] = 'Endre potensielt farlig avatarer';
$txt['avatar_reencode_note'] = '(krever modulen GD installert)';
$txt['avatar_paranoid_warning'] = 'Den omfattende sikkerhetskontroller kan resultere i et stort antall avviste avatarer.';
$txt['avatar_paranoid'] = 'Utfør omfattende sikkerhetskontroller på opplastede avatarer';

$txt['repair_attachments'] = 'Behandle vedlegg';
$txt['repair_attachments_complete'] = 'Vedlikehold utført';
$txt['repair_attachments_complete_desc'] = 'Alle valgte feil har nå blitt reparert';
$txt['repair_attachments_no_errors'] = 'No errors were found';
$txt['repair_attachments_error_desc'] = 'Følgende feil ble funnet under vedlikeholdet. Huk av i boksen ved siden av feilene du ønsker å reparere og klikk fortsett.';
$txt['repair_attachments_continue'] = 'Fortsett';
$txt['repair_attachments_cancel'] = 'Avbryt';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d miniatyrer mangler tilhørende vedlegg';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d vedlegg markert med manglende miniatyrer';
$txt['attach_repair_file_missing_on_disk'] = '%1$d vedlegg/avatarer er lagret i databasen, men eksisterer ikke lenger på disken';
$txt['attach_repair_file_wrong_size'] = '%1$d vedlegg/avatarer blir rapportert med feil filstørrelse';
$txt['attach_repair_file_size_of_zero'] = '%1$d vedlegg/avatarer blir rapportert med å ha en filstørrelse på null bytes. (disse vil nå bli slettet)';
$txt['attach_repair_attachment_no_msg'] = '%1$d vedlegg uten tilhørende innlegg';
$txt['attach_repair_avatar_no_member'] = '%1$d avatater uten tilhørende medlem';
$txt['attach_repair_wrong_folder'] = '%1$d attachments are in the wrong directory';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d files do not have a corresponding entry in the database. (These will be deleted)';

$txt['news_title'] = 'Nyheter og nyhetsbrev';
$txt['news_settings_desc'] = 'Her kan du endre innstillingene og rettigheter relatert til nyheter og nyhetsbrev.';
$txt['news_mailing_desc'] = 'From this menu you can send messages to all users who\'ve registered and entered their email addresses. You may edit the distribution list, or send messages to all. Useful for important update/news information.';
$txt['news_error_no_news'] = 'Nothing to preview';
$txt['groups_edit_news'] = 'Grupper som har tilgang til å endre nyhetselementer';
$txt['groups_send_mail'] = 'Grupper som har tilgang til å sende ut nyhetsbrev';
$txt['xmlnews_enable'] = 'Aktivere XML/RSS-nyheter';
$txt['xmlnews_maxlen'] = 'Maximum message length';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Number of items in a news feed';
$txt['xmlnews_maxlen_note'] = '(0 to disable, bad idea.)';
$txt['editnews_clickadd'] = 'Add another item';
$txt['editnews_remove_selected'] = 'Slett valgt(e)';
$txt['editnews_remove_confirm'] = 'Er du sikker på at du vil fjerne valgt(e) nyhet(er)?';
$txt['censor_clickadd'] = 'Add another word';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Logg';
$txt['generate_reports'] = 'Opprett rapporter';

$txt['update_available'] = 'Update Available';
$txt['update_message'] = 'You\'re using an outdated version of ElkArte, which contains some bugs which have since been fixed.
	It is recommended that you <a href="#" id="update-link">update your forum</a> to the latest version as soon as possible. It only takes a minute!';

$txt['manageposts'] = 'Innlegg og emner';
$txt['manageposts_title'] = 'Behandle innlegg og emner';
$txt['manageposts_description'] = 'Her kan du behandle innstillinger relatert til emner og innlegg.';

$txt['manageposts_seconds'] = 'sekunder';
$txt['manageposts_minutes'] = 'minutter';
$txt['manageposts_characters'] = 'tegn';
$txt['manageposts_days'] = 'dager';
$txt['manageposts_posts'] = 'innlegg';
$txt['manageposts_topics'] = 'emner';

$txt['pollMode'] = 'Aktiver avstemninger';

$txt['manageposts_settings'] = 'Innlegginnstillinger';
$txt['manageposts_settings_description'] = 'Her kan du endre alt som er relatert til innlegg og skriving av innlegg.';

$txt['manageposts_bbc_settings'] = 'BB-kode';
$txt['manageposts_bbc_settings_description'] = 'BB-kode er brukt til å formatere innlegg på forumet. For eksempel, du vil utheve ordet "hus", så kan du skrive [b]hus[/B]. Alle BB-koder har klammer rundt seg ( [ og ] ).';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code settings';

$txt['manageposts_topic_settings'] = 'Emneinnstillinger';
$txt['manageposts_topic_settings_description'] = 'Her kan du endre innstillinger som er relatert til emner.';

$txt['managedrafts_settings'] = 'Draft Settings';
$txt['managedrafts_settings_description'] = 'Here you can set all settings involving drafts.';
$txt['manage_drafts'] = 'Drafts';

$txt['mail_center'] = 'Maillist Center';
$txt['mm_emailerror'] = 'Failed Emails';
$txt['mm_emailfilters'] = 'Filters';
$txt['mm_emailparsers'] = 'Parsers';
$txt['mm_emailtemplates'] = 'Templates';
$txt['mm_emailsettings'] = 'Innstillinger';

$txt['removeNestedQuotes'] = 'Fjern anførselstegn ved sitering';
$txt['enableSpellChecking'] = 'Aktivere stavekontroll';
$txt['enableSpellChecking_warning'] = 'this does not work on all servers.';
$txt['enableSpellChecking_error'] = 'this does not work on your server.';
$txt['enableVideoEmbeding'] = 'Enable auto-embedding of video links.';
$txt['enableCodePrettify'] = 'Enable prettifying of code tags';
$txt['max_messageLength'] = 'Maksimalt antall tegn i innlegg';
$txt['max_messageLength_zero'] = '0 for ubegrenset.';
$txt['convert_to_mediumtext'] = 'Your database is not setup to accept messages longer than 65535 characters. Please use the <a href="%1$s">database maintenance</a> page to convert the database and then come back to increase the maximum allowed post size.';
$txt['topicSummaryPosts'] = 'Antall innlegg for å vise på emneoppsummering';
$txt['spamWaitTime'] = 'Tid (i sekunder) mellom innlegg fra samme IP';
$txt['edit_wait_time'] = 'Tidsbegrensing for usynlig redigering';
$txt['edit_disable_time'] = 'Maksimumstid for endring av innlegg';
$txt['edit_disable_time_zero'] = '0 for deaktivert';
$txt['preview_characters'] = 'Maximum length of last/first post preview';
$txt['preview_characters_units'] = 'tegn';
$txt['preview_characters_zero'] = '0 to show the entire message';
$txt['message_index_preview'] = 'Show post previews on the message index';
$txt['message_index_preview_off'] = 'Do not show the previews';
$txt['message_index_preview_first'] = 'Show the text of the first post';
$txt['message_index_preview_last'] = 'Show the text of the last post';

$txt['enableBBC'] = 'Aktivere BB-kode?';
$txt['enablePostHTML'] = 'Aktiver <em>vanlige</em> HTML-koder i innlegg';
$txt['autoLinkUrls'] = 'Automatisk gjør adresser om til linker';
$txt['disabledBBC'] = 'Aktiverte BB-koder';
$txt['bbcTagsToUse'] = 'Aktiverte BB-koder';
$txt['bbcTagsToUse_select'] = 'Velg kodene du vil tillate';
$txt['bbcTagsToUse_select_all'] = 'Velg alle';

$txt['enableParticipation'] = 'Aktivere ikoner for deltakelser';
$txt['enableFollowup'] = 'Enable followups';
$txt['enable_unwatch'] = 'Enable unwatching of topics';
$txt['oldTopicDays'] = 'Tid før emnet er markert som gammelt ved svar';
$txt['oldTopicDays_zero'] = '0 for deaktivert';
$txt['defaultMaxTopics'] = 'Antall emner per side i oversikten';
$txt['defaultMaxMessages'] = 'Antall innlegg per side i et emne';
$txt['disable_print_topic'] = 'Disable print topic feature';
$txt['hotTopicPosts'] = 'Antall innlegg for et aktivt emne';
$txt['hotTopicVeryPosts'] = 'Antall innlegg for et veldig aktivt emne';
$txt['useLikesNotViews'] = 'Use number of likes in place of posts to define hot topics';
$txt['enableAllMessages'] = 'Maks antall innlegg for å vise &quot;Alle&quot; innlegg';
$txt['enableAllMessages_zero'] = '0 for å aldri vise &quot;Alle&quot;';
$txt['disableCustomPerPage'] = 'Deaktiver brukerdefinert emne/meldings telling per side';
$txt['enablePreviousNext'] = 'Aktivere linker for forrige/neste emne';

$txt['not_done_title'] = 'Not done yet';
$txt['not_done_reason'] = 'For å ikke overbelaste serveren, har det du jobber med blitt midlertidig stanset. Det skal fortsette innen noen sekunder. Dersom det ikke gjør det, klikk på fortsett under.';
$txt['not_done_continue'] = 'Fortsett';

$txt['general_settings'] = 'Generelt';
$txt['database_paths_settings'] = 'Database og stier';
$txt['cookies_sessions_settings'] = 'Informasjonskapsler og økter';
$txt['caching_settings'] = 'Internminne';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Local Settings';
$txt['phpinfo_defaultsettings'] = 'Default Settings';
$txt['phpinfo_itemsettings'] = 'Innstillinger';

$txt['language_configuration'] = 'Språk';
$txt['language_description'] = 'This section allows you to edit languages installed on your forum or download new ones from the ElkArte site. You may also edit language-related settings here.';
$txt['language_edit'] = 'Rediger språk';
$txt['language_add'] = 'Legg til språk';
$txt['language_settings'] = 'Innstillinger';

$txt['advanced'] = 'Avansert';
$txt['simple'] = 'Enkel';

$txt['admin_news_select_recipients'] = 'Velg hvem som skal motta en kopi av nyhetsbrevet';
$txt['admin_news_select_group'] = 'Member groups';
$txt['admin_news_select_group_desc'] = 'Velg grupper som skal motta dette nyhetsbrevet.';
$txt['admin_news_select_members'] = 'Medlemmer';
$txt['admin_news_select_members_desc'] = 'Additional members to receive the newsletter.';
$txt['admin_news_select_excluded_members'] = 'Ekskluderte medlemmer';
$txt['admin_news_select_excluded_members_desc'] = 'Members who should not receive the newsletter.';
$txt['admin_news_select_excluded_groups'] = 'Ekskluderte grupper';
$txt['admin_news_select_excluded_groups_desc'] = 'Velg grupper som ikke skal motta nyhetsbrev.';
$txt['admin_news_select_email'] = 'E-postadresser';
$txt['admin_news_select_email_desc'] = 'A semi-colon separated list of email addresses which should be sent this newsletter. (i.e. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Override notification settings';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Du kan ikke sende en personlig melding til en e-postadresse. Hvis du fortsetter vil alle e-postadresser bli ignorert.\\n\\nEr du sikker på at du ønsker å gjøre dette?';

$txt['mailqueue_browse'] = 'Bla gjennom køen';
$txt['mailqueue_settings'] = 'Innstillinger';

$txt['admin_search'] = 'Hurtigsøk';
$txt['admin_search_type_internal'] = 'Oppgave/Innstilling';
$txt['admin_search_type_member'] = 'Medlem';
$txt['admin_search_type_online'] = 'Online brukerhåndbok';
$txt['admin_search_go'] = 'Ok';
$txt['admin_search_results'] = 'Søkeresulater';
$txt['admin_search_results_desc'] = 'Søkeresultat: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Søk på nytt';
$txt['admin_search_results_none'] = 'No results found.';

$txt['admin_search_section_sections'] = 'Seksjon';
$txt['admin_search_section_settings'] = 'Innstillinger';

$txt['core_settings_title'] = 'Kjernefunksjoner';
$txt['core_settings_desc'] = 'This page allows you to turn on or off optional features of your forum.';
$txt['mods_cat_features'] = 'Generelt';
$txt['mods_cat_security_general'] = 'Generelt';
$txt['antispam_title'] = 'Antispam';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Diverse';
$txt['mods_cat_layout'] = 'Utforming';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderering';
$txt['signature_settings_short'] = 'Signaturer';
$txt['custom_profile_shorttitle'] = 'Profilfelter';
$txt['pruning_title'] = 'Slette logger';

$txt['core_settings_activation_message'] = 'The feature {core_feature} has been activated, click on the title to configure it';
$txt['core_settings_deactivation_message'] = 'The feature {core_feature} has been deactivated';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Rediger forum';
$txt['mboards_new_cat'] = 'Create new category';
$txt['manage_holidays'] = 'Behandle helligdager';
$txt['calendar_settings'] = 'Kalenderinnstillinger';
$txt['search_weights'] = 'Vektlegging';
$txt['search_method'] = 'Søkemetode';
$txt['search_sphinx'] = 'Configure Sphinx';

$txt['smiley_sets'] = 'Stiler smilefjes';
$txt['smileys_add'] = 'Nytt smilefjes';
$txt['smileys_edit'] = 'Rediger smilefjes';
$txt['smileys_set_order'] = 'Set Smiley order';
$txt['icons_edit_message_icons'] = 'Edit message icons';

$txt['membergroups_new_group'] = 'Add Member Group';
$txt['membergroups_edit_groups'] = 'Edit Member Groups';
$txt['permissions_groups'] = 'Generelle rettigheter';
$txt['permissions_boards'] = 'Forumrettigheter';
$txt['permissions_profiles'] = 'Rediger profiler';
$txt['permissions_post_moderation'] = 'Innleggsmoderering';

$txt['browse_packages'] = 'Bla igjennom pakker';
$txt['download_packages'] = 'Last ned pakker';
$txt['upload_packages'] = 'Upload Package';
$txt['installed_packages'] = 'Installerte pakker';
$txt['package_file_perms'] = 'Filrettigheter';
$txt['package_settings'] = 'Innstillinger';
$txt['package_servers'] = 'Package Servers';
$txt['themeadmin_admin_title'] = 'Behandling og installasjon';
$txt['themeadmin_list_title'] = 'Designinnstillinger';
$txt['themeadmin_reset_title'] = 'Medlemsalternativer';
$txt['themeadmin_edit_title'] = 'Endre design';
$txt['admin_browse_register_new'] = 'Register new member';

$txt['search_engines'] = 'Søkemotorer';
$txt['spider_logs'] = 'Logg';
$txt['spider_stats'] = 'Status';

$txt['paid_subscriptions'] = 'Betalet abonnementer';
$txt['paid_subs_view'] = 'Vis abonnementer';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks';
$txt['hooks_field_hook_name'] = 'Hook Name';
$txt['hooks_field_function_name'] = 'Function Name';
$txt['hooks_field_function'] = 'Function';
$txt['hooks_field_included_file'] = 'Included file';
$txt['hooks_field_file_name'] = 'Filnavn';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Exists';
$txt['hooks_disabled'] = 'Deaktivert'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Not found';
$txt['hooks_no_hooks'] = 'There are currently no hooks in the system.';
$txt['hooks_disable_legend'] = 'Forklaring';
$txt['hooks_disable_legend_exists'] = 'the hook exists and is active';
$txt['hooks_disable_legend_disabled'] = 'the hook exists but has been disabled';
$txt['hooks_disable_legend_missing'] = 'the hook has not been found';
$txt['hooks_reset_filter'] = 'Reset filter';

$txt['board_perms_allow'] = 'Tillat';
$txt['board_perms_ignore'] = 'Ignorer';
$txt['board_perms_deny'] = 'Nekt';
$txt['all_boards_in_cat'] = 'All boards in this category';

$txt['url'] = 'Adresse';
$txt['words_sep'] = 'Words separator';

$txt['admin_order_title'] = 'Ordering Error';
$txt['admin_order_error'] = 'An unknown error occurred while processing your request';

// Known controllers that can work on the front page
$txt['default'] = 'Standard';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
