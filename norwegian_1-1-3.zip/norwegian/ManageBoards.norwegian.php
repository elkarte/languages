<?php
// Version: 1.1; ManageBoards

$txt['boards_and_cats'] = 'Behandle forum og kategorier';
$txt['order'] = 'Bestilling';
$txt['full_name'] = 'Navn';
$txt['name_on_display'] = 'Dette er navnet som vil vises.';
$txt['boards_and_cats_desc'] = 'Edit your categories and boards here. List multiple moderators as <em>&quot;username&quot;, &quot;username&quot;</em>. (these must be usernames and *not* display names)<br />To create a new board, click the Add Board button.<br />To move a board you can drag and drop it to its new location in the list (across cataegories and Child of locations)<br />To create a new board as a child of a current board, select "Child of..." from the Order drop down menu when creating the board.';
$txt['parent_members_only'] = 'Vanlige medlemmer';
$txt['parent_guests_only'] = 'Gjester';
$txt['catConfirm'] = 'Er du sikker på at du vil slette denne kategorien?';
$txt['boardConfirm'] = 'Er du sikker på at du vil slette dette forumet?';

$txt['catEdit'] = 'Rediger kategori';
$txt['collapse_enable'] = 'Sammenslåbar';
$txt['collapse_desc'] = 'Tillat medlemmer å slå sammen denne kategorien';
$txt['catModify'] = '[modify]';

$txt['mboards_order_after'] = 'Etter ';
$txt['mboards_order_first'] = 'Helt først';
$txt['mboards_board_error'] = 'Failed to resolve move location.';

$txt['mboards_new_board'] = 'Legg til forum';
$txt['mboards_new_cat_name'] = 'Ny kategori';
$txt['mboards_add_cat_button'] = 'Legg til kategori';
$txt['mboards_new_board_name'] = 'Nytt forum';

$txt['mboards_modify'] = 'rediger';
$txt['mboards_permissions'] = 'rettigheter';
// Don't use entities in the below string.
$txt['mboards_permissions_confirm'] = 'Er du sikker på at du vil sette dette forumet til å benytte lokale rettigheter?';

$txt['mboards_delete_cat'] = 'Slett kategori';
$txt['mboards_delete_board'] = 'Slett forum';

$txt['mboards_delete_cat_contains'] = 'Sletting av denne kategorien vil også slette underliggende forum, inkludert alle emner, innlegg og vedlegg inne i hvert forum';
$txt['mboards_delete_option1'] = 'Slett kategori og alle tilhørende forum.';
$txt['mboards_delete_option2'] = 'Slett kategori men flytt alle tilhørende forum til';
$txt['mboards_delete_board_contains'] = 'Deleting this board will also move the sub-boards below, including all topics, posts and attachments within each board';
$txt['mboards_delete_board_option1'] = 'Delete board and move sub-boards contained within to category level.';
$txt['mboards_delete_board_option2'] = 'Delete board and move all sub-boards contained within to';
$txt['mboards_delete_what_do'] = 'Vennligst velg hva du vil gjøre med disse fora';
$txt['mboards_delete_confirm'] = 'Bekreft';
$txt['mboards_delete_cancel'] = 'Avbryt';

$txt['mboards_category'] = 'Kategori';
$txt['mboards_description'] = 'Beskrivelse';
$txt['mboards_description_desc'] = 'A short description of your board.<br />You may use BBC to format your description.';
$txt['mboards_groups'] = 'Tillatte medlemsgrupper';
$txt['mboards_groups_desc'] = 'Grupper med tilgang til dette forumet.<br /><em>Merk: Hvis et medlem er med i minst en av de avkryssede gruppene eller innleggsbaserte gruppene, vil han/hun ha tilgang til forumet.</em>';
$txt['mboards_groups_regular_members'] = 'Denne gruppen inneholder alle medlemmer som ikke er i noen primær gruppe.';
$txt['mboards_groups_post_group'] = 'Denne gruppen er en innleggsbasert gruppe.';
$txt['mboards_moderators'] = 'Moderatorer';
$txt['mboards_moderators_desc'] = 'Medlemmer med moderatorrettigheter på forumet. Merk at administratorer ikke trenger å listes her.';
$txt['mboards_count_posts'] = 'Tell innlegg';
$txt['mboards_count_posts_desc'] = 'Gjør slik at svar og emner øker medlemmers innleggsteller.';
$txt['mboards_unchanged'] = 'Uforandret';
$txt['mboards_theme'] = 'Forumdesign';
$txt['mboards_theme_desc'] = 'Dette lar deg endre design for kun dette bestemte forumet.';
$txt['mboards_theme_default'] = '(generell standard)';
$txt['mboards_override_theme'] = 'Overstyr medlemmers valg av tema';
$txt['mboards_override_theme_desc'] = 'Bruk dette forumets tema selv om medlemmet ikke valgte å bruke standard-designet.';

$txt['mboards_redirect'] = 'Viderekoble til en web-adresse';
$txt['mboards_redirect_desc'] = 'Aktiver dette alternativet for å viderekoble alle som klikker på dette forumet til en annen web-adresse.';
$txt['mboards_redirect_url'] = 'Adresse for å omdirigere brukere til';
$txt['mboards_redirect_url_desc'] = 'For example: &quot;https://www.elkarte.net&quot;.';
$txt['mboards_redirect_reset'] = 'Nullstill telleren for redirigeringer';
$txt['mboards_redirect_reset_desc'] = 'Hvis du velger dette vil omadresseringer tilbakestille  telleren for dette forumet til null.';
$txt['mboards_current_redirects'] = 'For tiden: %1$s';
$txt['mboards_redirect_disabled'] = 'Merk: Forumet må være tomt for temaer å aktivere dette alternativet.';
$txt['mboards_redirect_disabled_recycle'] = 'Du kan ikke sette forumet der bliver brugt som papirkurv, til å være en omdirigerings-forum.';

$txt['mboards_order_before'] = 'Foran';
$txt['mboards_order_child_of'] = 'Under';
$txt['mboards_order_in_category'] = 'I kategori';
$txt['mboards_current_position'] = 'Gjeldende posisjon';
$txt['no_valid_parent'] = 'Forumet %1$s har ikke en gyldig plassering. Bruk funksjonen \'Finn og reparer alle feil\' for å rette dette.';

$txt['mboards_recycle_disabled_delete'] = 'You must select an alternative recycle bin board or disable recycling before you can delete this board.';

$txt['mboards_settings_desc'] = 'Endre generelle innstillinger for forum og kategorier.';
$txt['groups_manage_boards'] = 'Medlemsgrupper med tilgang til å behandle forum og kategorier';
$txt['recycle_enable'] = 'Aktiver papirkurv-funksjon for slettede emner';
$txt['recycle_board'] = 'Forum som skal benyttes som papirkurv for slettede emner';
$txt['recycle_board_unselected_notice'] = 'Du har aktivert gjenvinning av emner uten å angi et forum for å plassere dem i. Denne funksjonen vil ikke være aktivert før du angir et forum til å plassere resirkulerte emner inn.';
$txt['countChildPosts'] = 'Tell også innlegg i delforum ved beregning av hovedforumets total';
$txt['allow_ignore_boards'] = 'Tillat å ignorere forumene';
$txt['deny_boards_access'] = 'Enable the option to deny board access based on membergroup';
$txt['boardsaccess_option_desc'] = 'For each permission you can choose \'Allow\' (A), \'Ignore\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />If you deny access, any member - (including moderators) - in that group will be denied access.<br />For this reason, you should set deny carefully, only when <strong>necessary</strong>. Ignore, on the other hand, denies unless otherwise granted.';

$txt['mboards_select_destination'] = 'Velg en destinasjon for forumet \'<strong>%1$s</strong>\'';
$txt['mboards_cancel_moving'] = 'Avbryt flytting';
$txt['mboards_move'] = 'flytt';

$txt['mboards_no_cats'] = 'Det er for tiden ingen kategorier eller forum konfigurert.';
