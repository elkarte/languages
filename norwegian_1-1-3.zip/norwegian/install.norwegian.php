<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Velkommen';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Sjekker skrivetilgangen';
$txt['install_step_forum'] = 'Vanlige innstillinger';
$txt['install_step_databaseset'] = 'Databaseinnstillinger';
$txt['install_step_databasechange'] = 'Setter opp databasen';
$txt['install_step_admin'] = 'Administrator konto';
$txt['install_step_delete'] = 'Finalize Installation';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'Språk';
$txt['installer_language_set'] = 'Sett';
$txt['congratulations'] = 'Gratulerer! Installasjonen er nå fullført!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Installasjonsmappen din er fremdeles skrivbar. Det er gjerne en god idé å endre rettighetene for den mappen sånn at den ikke er skrivbar av hensyn til sikkerheten.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(fungerer ikke på alle servere.)</em>';
$txt['go_to_your_forum'] = 'Nå kan du gå inn og se på <a href="%1$s">ditt helt nye forum</a> som er klar til bruk. Du bør først logge inn, slik at du får tilgang til å utføre Administratoroppgaver.';
$txt['good_luck'] = 'Thanks for installing ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Velkommen';
$txt['install_welcome_desc'] = 'Welcome to ElkArte. This script will guide you through the process for installing %1$s. We\'ll gather a few details about your forum over the next few steps, and after a couple of minutes your forum will be ready for use.';
$txt['install_all_lovely'] = 'Vi har gjennomført noen innledende tester på serveren din og alt ser ut til å være i orden. Bare klikk på knappen &quot;Fortsett&quot; nedenfor for å komme i gang.';

$txt['user_refresh_install'] = 'Forum oppdatert';
$txt['user_refresh_install_desc'] = 'Under installering fant scriptet ut (med detaljer du har lagt ved) at en eller flere tabeller som skulle opprettes allerede eksisterte.<br />Tabeller som manglet i din installasjon er blitt laget, men ingen data er blitt fjernet fra eksisterende tabeller.';

$txt['default_topic_subject'] = 'Welcome to ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Generelt';
$txt['default_board_description'] = 'Diskuter alt mulig i dette forumet.';
$txt['default_category_name'] = 'Generell kategori';
$txt['default_time_format'] = '%d.%m.%Y, %H:%i:%s';
$txt['default_news'] = 'ElkArte - Just Installed!';
$txt['default_karmaLabel'] = 'Karma:';
$txt['default_karmaSmiteLabel'] = '[dårlig]';
$txt['default_karmaApplaudLabel'] = '[bra]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGjest\\nroot';
$txt['default_smileyset_name'] = 'Fugue\'s Set';
$txt['default_theme_name'] = 'ElkArte Default Theme';

$txt['default_administrator_group'] = 'Administrator';
$txt['default_global_moderator_group'] = 'Global moderator';
$txt['default_moderator_group'] = 'Moderator';
$txt['default_newbie_group'] = 'Nybegynner';
$txt['default_junior_group'] = 'Juniormedlem';
$txt['default_full_group'] = 'Fullstendig medlem';
$txt['default_senior_group'] = 'Seniormedlem';
$txt['default_hero_group'] = 'Supermedlem';

$txt['default_smiley_smiley'] = 'Smiler';
$txt['default_wink_smiley'] = 'Blunker';
$txt['default_cheesy_smiley'] = 'Osteaktig';
$txt['default_grin_smiley'] = 'Gliser';
$txt['default_angry_smiley'] = 'Sint';
$txt['default_sad_smiley'] = 'Trist';
$txt['default_shocked_smiley'] = 'Sjokkert';
$txt['default_cool_smiley'] = 'Kult';
$txt['default_huh_smiley'] = 'Hææ?';
$txt['default_roll_eyes_smiley'] = 'Øyerulling';
$txt['default_tongue_smiley'] = 'Rekke tunge';
$txt['default_embarrassed_smiley'] = 'Flaut';
$txt['default_lips_sealed_smiley'] = 'Hemmelig';
$txt['default_undecided_smiley'] = 'Tvilende';
$txt['default_kiss_smiley'] = 'Kysser';
$txt['default_cry_smiley'] = 'Gråter';
$txt['default_evil_smiley'] = 'Ondskapsfull';
$txt['default_azn_smiley'] = 'Djevelsk';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Ler';
$txt['default_police_smiley'] = 'Politi';
$txt['default_angel_smiley'] = 'Angel';

$txt['error_message_click'] = 'Klikk her';
$txt['error_message_try_again'] = 'for å prøve dette steget en gang til.';
$txt['error_message_bad_try_again'] = 'for å installere uansett, men merk at du er <em>sterkt</em> frarådet fra å gjøre det.';

$txt['install_settings'] = 'Vanlige innstillinger';
$txt['install_settings_info'] = 'This page requires you to define a few key settings for your forum. ElkArte has automatically detected key settings for you.';
$txt['install_settings_name'] = 'Navn på forumet';
$txt['install_settings_name_info'] = 'This is the name of your forum, e.g. &quot;The Testing Forum&quot;.';
$txt['install_settings_name_default'] = 'Mitt SMF-forum';
$txt['install_settings_url'] = 'Nettadressen til forumet';
$txt['install_settings_url_info'] = 'Dette er adressen til forumet ditt <strong>uten \'/\' på slutten!</strong>.<br />I de fleste tilfellene trenger du ikke å redigere denne boksen, da det som står der fra før, normalt er korrekt.';
$txt['install_settings_compress'] = 'Gzip utdata';
$txt['install_settings_compress_title'] = 'Komprimerer utdata for å spare båndbredde.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'This function does not work properly on all servers, but can save you a lot of bandwidth.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Click here to test it</a>. (it should just say "PASS".)';
$txt['install_settings_dbsession'] = 'Database-baserte sesjoner';
$txt['install_settings_dbsession_title'] = 'Lagre sessjoner i databasen i stedet for i filer.';
$txt['install_settings_dbsession_info1'] = 'Dette er nesten alltid det beste, fordi det gjør bruk av sesjoner mer pålitelig.';
$txt['install_settings_dbsession_info2'] = 'Dette er nesten alltid det beste, men det vil kanskje ikke virke på denne serveren.';
$txt['install_settings_proceed'] = 'Fortsett';

$txt['db_settings'] = 'Database serverinnstillinger';
$txt['db_settings_info'] = 'Dette er innstillingene skal brukes til databaseserveren. Hvis du ikke kjenner verdiene, bør du spørre din leverandør hva de er.';
$txt['db_settings_type'] = 'Databasetype';
$txt['db_settings_type_info'] = 'Multiple supported database types were detected - which one do you wish to use?';
$txt['db_settings_server'] = 'Servernavn';
$txt['db_settings_server_info'] = 'Dette er oftest localhost - så om du ikke vet, prøv localhost.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Leave empty if your server is listening on the default port, or you are uncertain.';
$txt['db_settings_username'] = 'User name';
$txt['db_settings_username_info'] = 'Fill in the user name you need to connect to your database here.<br />If you don\'t know what it is, try the user name of your FTP account, most of the time they are the same.';
$txt['db_settings_password'] = 'Passord';
$txt['db_settings_password_info'] = 'Here you should put the password you need to connect to your database.<br />If you don\'t know this, you should try the password to your FTP account.';
$txt['db_settings_database'] = 'Databasenavn';
$txt['db_settings_database_info'] = 'Fill in the name of the database you want to use for ElkArte to store its data in.';
$txt['db_settings_database_info_note'] = 'Om databasen ikke eksisterer, vil dette installasjonsprogrammet prøve å opprette databasen.';
$txt['db_settings_database_file'] = 'Database file name';
$txt['db_settings_database_file_info'] = 'This is the name of the file in which to store the ElkArte data. We recommend you use the randomly generated name for this and set the path of this file to be outside of the public area of your webserver.';
$txt['db_settings_prefix'] = 'Tabellprefiks';
$txt['db_settings_prefix_info'] = 'Prefiksen for hver tabell i databasen. <strong>Ikke installer to fora med samme prefiks!</strong><br />Denne verdien muliggjør flere installasjoner i én database.';
$txt['db_populate'] = 'Setter opp databasen';
$txt['db_populate_info'] = 'Innstillingene er nå lagret og databasen installert med alle data som kreves for å få forumet oppe og gå. Oppsummering av installasjonen:';
$txt['db_populate_info2'] = 'Klikk &quot;Fortsett&quot; for å gå videre til siden for opprettelse av administrator kontoen.';
$txt['db_populate_inserts'] = 'Satt inn %1$d rader.';
$txt['db_populate_tables'] = 'Opprettet %1$d tabeller.';
$txt['db_populate_insert_dups'] = 'Ignorert %1$d dupliserte innsettelser.';
$txt['db_populate_table_dups'] = 'Ignorert %1$d dupliserte tabeller.';

$txt['user_settings'] = 'Opprette din konto';
$txt['user_settings_info'] = 'Dette installasjonsprogrammet vil nå opprette en ny administratorkonto for deg.';
$txt['user_settings_username'] = 'Your user name';
$txt['user_settings_username_info'] = 'Choose the name you want to login with.';
$txt['user_settings_password'] = 'Passord';
$txt['user_settings_password_info'] = 'Skriv inn ditt foretrukne passord her, og husk godt på det!';
$txt['user_settings_again'] = 'Passord';
$txt['user_settings_again_info'] = '(bare for bekreftelse.)';
$txt['user_settings_email'] = 'E-postadresse';
$txt['user_settings_email_info'] = 'Skriv inn din e-postadresse. <strong>Dette må være en gyldig e-postadresse.</strong>';
$txt['user_settings_database'] = 'Passord for databasen';
$txt['user_settings_database_info'] = 'Av sikkerhetsgrunner kreves det at du skriver inn passordet for databasen når du oppretter en administratorkonto.';
$txt['user_settings_skip'] = 'Hopp over';
$txt['user_settings_skip_sure'] = 'Er du sikker på at du ønsker å oppe over opprettelse av admin-kontoen';
$txt['user_settings_proceed'] = 'Fullfør';

$txt['ftp_checking_writable'] = 'Checking if files are writable';
$txt['ftp_setup'] = 'Informasjon for FTP-tilkobling';
$txt['ftp_setup_info'] = 'Dette installasjonsprogrammet kan koble til med FTP for å rette på filene som må være skrivbare, men som ikke allerede er det. Dersom dette ikke fungerer for deg, må du selv gå inn og manuelt gjøre filene skrivbare. Merk at denne funksjonen ikke støtter SSL-tilgang for øyeblikket.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'This should be the server address and port for your FTP server.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'User name';
$txt['ftp_username_info'] = 'The user name to login with. <em>This will not be saved anywhere.</em>';
$txt['ftp_password'] = 'Passord';
$txt['ftp_password_info'] = 'Passordet som brukes til innlogging. <em>Dette vil ikke lagres noe sted.</em>';
$txt['ftp_path'] = 'Installasjons-sti';
$txt['ftp_path_info'] = 'Dette er den <em>relative</em> stien du bruker på din FTP-server.';
$txt['ftp_path_found_info'] = 'Stien i feltet ovenfor ble automatisk funnet.';
$txt['ftp_connect'] = 'Koble til';
$txt['ftp_setup_why'] = 'Hva er dette steget godt for?';
$txt['ftp_setup_why_info'] = 'Some files need to be writable for ElkArte to work properly.  This step allows you to let the installer make them writable for you.  However, in some cases it won\'t work - in that case, please make the following files 777 (writable, 755 on some hosts):';
$txt['ftp_setup_again'] = 'for å på nytt teste om disse filene er skrivbare.';

$txt['error_php_too_low'] = 'Warning!  You do not appear to have a version of PHP installed on your webserver that meets ElkArte\'s <strong>minimum installations requirements</strong>.<br />If you are not the host, you will need to ask your host to upgrade, or use a different host - otherwise, please upgrade PHP to a recent version.<br /><br />If you know for a fact that your PHP version is high enough you may continue, although this is strongly discouraged.';
$txt['error_missing_files'] = 'Kunne ikke finne viktige installasjonsfiler i samme mappe som dette scriptet!<br /><br />Kontroller at du lastet opp alle filene i installasjonspakken, inklusive sql-filen, og gjør så et nytt forsøk.';
$txt['error_session_save_path'] = 'Informer din leverandør om at følgende streng i php.ini er ugyldig: <strong>session.save_path</strong>. Den må endres til en mappe som <strong>eksisterer</strong> og er <strong>skrivbar</strong> for brukeren PHP kjører som.<br />';
$txt['error_windows_chmod'] = 'You\'re on a windows server, and some crucial files are not writable.  Please ask your host to give <strong>write permissions</strong> to the user PHP is running under for the files in your ElkArte installation.  The following files or directories need to be writable:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Kunne ikke koble til FTP-serveren med den informasjonen du skrev inn.';
$txt['error_db_file'] = 'Kan ikke finne kilden til databaseskriptet! Vennligst sjekk at filen %1$s is er i rot mappen på forumet.';
$txt['error_db_connect'] = 'Kan ikke koble til database-serveren med de oppgitte dataene.<br /><br />Hvis du ikke er sikker på hva som skal skrives inn, vennligst kontakt din leverandør.';
$txt['error_db_too_low'] = 'The version of your database server is very old and does not meet ElkArte\'s minimum requirements.<br /><br />Please ask your host to either upgrade it or supply a new one, and if they won\'t, please try a different host.';
$txt['error_db_database'] = 'The installer was unable to access the &quot;<em>%1$s</em>&quot; database.  With some hosts, you have to create the database in your administration panel before ElkArte can use it.  Some also add prefixes - like your username - to your database names.';
$txt['error_db_queries'] = 'Noen av spørringene ble ikke kjørt korrekt. Dette kan være forårsaket av ikke støttet (utvikling eller gamle) versjonen av databaseprogramvaren.<br /><br />Teknisk informasjon om spørringene:';
$txt['error_db_queries_line'] = 'Linje nr.';
$txt['error_db_missing'] = 'The installer was unable to detect database support in PHP that ElkArte can utilize.  Please ask your host to ensure that PHP was compiled with the desired database, or that the proper php extension is being loaded.  Currently ElkArte supports the:  &quot;%1$s&quot; extensions';
$txt['error_db_script_missing'] = 'Installasjonsprogrammet fant ingen installasjonsskriptfiler for den oppdagede databasen. Vennligst sjekk at du har lastet de nødvendige installasjonsskriptfilene til forum mappen, for eksempel &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Installasjonsprogrammet kunne ikke finne støtte for sesjoner i serverens PHP-installasjon. Vennligst be din leverandør om å forsikre seg om at PHP ble kompilert med støtte for sesjoner (faktisk må det kompileres eksplisitt for å ikke støtte det.)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Du skrev inn to helt forskjellige passord!';
$txt['error_user_settings_no_password'] = 'Passordet ditt må være minst 4 tegn langt.';
$txt['error_user_settings_taken'] = 'Sorry, a member is already registered with that user name and/or email address.<br /><br />A new account has not been created.';
$txt['error_user_settings_query'] = 'En database-feil oppstod under opprettelsen av administratorkontoen. Denne feilen var:';
$txt['error_subs_missing'] = 'Unable to find the sources/Subs.php file.  Please make sure it was uploaded properly, and then try again.';
$txt['error_db_alter_priv'] = 'The database account you specified does not have permission to ALTER, CREATE, and/or DROP tables in the database; this is necessary for ElkArte to function properly.';
$txt['error_versions_do_not_match'] = 'The installer has detected another version of ElkArte already installed with the specified information.  If you are trying to upgrade, you should use the upgrader, not the installer.<br /><br />Otherwise, you may wish to use different information, or create a backup and then delete the data currently in the database.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'The current version of your database doesn\'t support the use of the UTF-8 character set. You can not install ElkArte';
$txt['error_valid_email_needed'] = 'Du har ikke skrevet en gyldig e-postadresse.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Advarsel!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Du må angi et navn til databasefilen til SQLite.';
$txt['error_db_prefix_numeric'] = 'Den valgte databasetype støtter ikke bruk av numeriske prefikser.';
$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';
$txt['error_username_too_long'] = 'User name must be less than 25 characters long.';
$txt['error_username_left_empty'] = 'User name field was left empty.';
$txt['error_db_filename_exists'] = 'Databasen som du prøver å opprette eksisterer allerede. Vennligst slette den aktuelle databasefilen eller angi et annet navn.';
$txt['error_db_prefix_reserved'] = 'Prefikset som du skrev er et reservert prefiks. Vennligst skriv inn et annet prefiks.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade Utility';
$txt['upgrade_warning'] = 'Advarsel!';
$txt['upgrade_critical_error'] = 'Kritisk feil!';
$txt['upgrade_continue'] = 'Fortsett';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Hopp over';
$txt['upgrade_note'] = 'Merk!';
$txt['upgrade_step'] = 'Steg';
$txt['upgrade_steps'] = 'Steg';
$txt['upgrade_progress'] = 'Fremdrift';
$txt['upgrade_overall_progress'] = 'Samlet fremdrift';
$txt['upgrade_step_progress'] = 'Gjeldende fremdrift';
$txt['upgrade_time_elapsed'] = 'Tid brukt';
$txt['upgrade_time_mins'] = 'minutter';
$txt['upgrade_time_secs'] = 'sekunder';

$txt['upgrade_incomplete'] = 'Ufullstendig';
$txt['upgrade_not_quite_done'] = 'Ikke helt ferdig ennå!';
$txt['upgrade_paused_overload'] = 'Oppgraderingen er satt på pause for å unngå overbelastning på serveren. Ikke bekymre deg, ingenting er galt - bare klikk på knappen <label for="contbutt">fortsette</label> nedenfor for å fortsette.';

$txt['upgrade_ready_proceed'] = 'Thank you for choosing to upgrade to ElkArte %1$s. All files appear to be in place, and we\'re ready to proceed.';

$txt['upgrade_error_script_js'] = 'The upgrade script cannot find script.js or it is out of date. Make sure your theme paths are correct. You can download a settings check and repair script from <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte tools</a>.';

$txt['upgrade_warning_lots_data'] = 'Oppgraderingsskriptet har oppdaget at Forumet inneholder store mengder av data som trenger oppgradering. Denne prosessen kan ta ganske lang tid avhengig av server og størrelsen på forumet, og for veldig store fora (~ 300 000 meldinger) kan det ta flere timer å fullføre.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';