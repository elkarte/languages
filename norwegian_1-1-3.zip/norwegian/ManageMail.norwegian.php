<?php
// Version: 1.1; ManageMail

$txt['mailqueue_desc'] = 'Fra denne siden kan du konfigurere e-postinnstillingene, samt visning og administrasjon av den gjeldende e-post køen hvis det er aktivert.';
$txt['mail_settings'] = 'Mail Settings';

$txt['mail_type'] = 'Type e-post';
$txt['mail_type_default'] = '(standard for PHP)';
$txt['smtp_host'] = 'SMTP-server';
$txt['smtp_client'] = 'SMTP client';
$txt['smtp_port'] = 'SMTP-port';
$txt['smtp_starttls'] = 'STARTTLS';
$txt['smtp_username'] = 'Brukernavn for SMTP';
$txt['smtp_password'] = 'Passord for SMTP';

$txt['mail_queue'] = 'Enable mail queue';
$txt['mail_period_limit'] = 'Maksimum e-post  å sende per minutt';
$txt['mail_period_limit_desc'] = '(Sett denne til 0 for å deaktivere)';
$txt['mail_batch_size'] = 'Maksimum antall e-poster å sende per sideinnlasting';

$txt['mailqueue_stats'] = 'Mail queue statistics';
$txt['mailqueue_oldest'] = 'Eldste mail';
$txt['mailqueue_oldest_not_available'] = 'N/A';
$txt['mailqueue_size'] = 'Queue length';

$txt['mailqueue_age'] = 'Alder';
$txt['mailqueue_priority'] = 'Prioritet';
$txt['mailqueue_recipient'] = 'Mottaker';
$txt['mailqueue_subject'] = 'Tittel';
$txt['mailqueue_clear_list'] = 'Send mail queue now';
$txt['mailqueue_no_items'] = 'E-post køen er tom';
// Do not use numeric entities in below string.
$txt['mailqueue_clear_list_warning'] = 'Er du sikker på at du ønsker å sende hele e-post køen nå? Dette vil overstige alle grensene du har sett.';

$txt['mq_day'] = '%1.1f Dag';
$txt['mq_days'] = '%1.1f Dager';
$txt['mq_hour'] = '%1.1f Time';
$txt['mq_hours'] = '%1.1f Timer';
$txt['mq_minute'] = '%1$d Minutt';
$txt['mq_minutes'] = '%1$d Minutter';
$txt['mq_second'] = '%1$d Sekund';
$txt['mq_seconds'] = '%1$d Sekunder';

$txt['mq_mpriority_5'] = 'Svært lav';
$txt['mq_mpriority_4'] = 'Lav';
$txt['mq_mpriority_3'] = 'Normal';
$txt['mq_mpriority_2'] = 'Høy';
$txt['mq_mpriority_1'] = 'Svært høy';

$txt['birthday_email'] = 'Birthday message to use';
$txt['birthday_body'] = 'Email body';
$txt['birthday_subject'] = 'Email subject';