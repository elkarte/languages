<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'nb_NO.utf8';
$txt['lang_dictionary'] = 'nb';
$txt['lang_spelling'] = 'american';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'Sunday';
$txt['monday'] = 'Monday';
$txt['tuesday'] = 'Tuesday';
$txt['wednesday'] = 'Wednesday';
$txt['thursday'] = 'Thursday';
$txt['friday'] = 'Friday';
$txt['saturday'] = 'Saturday';

$txt['sunday_short'] = 'Sun';
$txt['monday_short'] = 'Mon';
$txt['tuesday_short'] = 'Tue';
$txt['wednesday_short'] = 'Wed';
$txt['thursday_short'] = 'Thu';
$txt['friday_short'] = 'Fri';
$txt['saturday_short'] = 'Sat';

$txt['january'] = 'January';
$txt['february'] = 'February';
$txt['march'] = 'March';
$txt['april'] = 'April';
$txt['may'] = 'May';
$txt['june'] = 'June';
$txt['july'] = 'July';
$txt['august'] = 'August';
$txt['september'] = 'September';
$txt['october'] = 'October';
$txt['november'] = 'November';
$txt['december'] = 'December';

$txt['january_titles'] = 'January';
$txt['february_titles'] = 'February';
$txt['march_titles'] = 'March';
$txt['april_titles'] = 'April';
$txt['may_titles'] = 'May';
$txt['june_titles'] = 'June';
$txt['july_titles'] = 'July';
$txt['august_titles'] = 'August';
$txt['september_titles'] = 'September';
$txt['october_titles'] = 'October';
$txt['november_titles'] = 'November';
$txt['december_titles'] = 'December';

$txt['january_short'] = 'Jan';
$txt['february_short'] = 'Feb';
$txt['march_short'] = 'Mar';
$txt['april_short'] = 'Apr';
$txt['may_short'] = 'May';
$txt['june_short'] = 'Jun';
$txt['july_short'] = 'Jul';
$txt['august_short'] = 'Aug';
$txt['september_short'] = 'Sep';
$txt['october_short'] = 'Oct';
$txt['november_short'] = 'Nov';
$txt['december_short'] = 'Dec';

$txt['time_am'] = 'am';
$txt['time_pm'] = 'pm';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Hovedside';
$txt['community'] = 'Community';
// Sub menu labels
$txt['help'] = 'Hjelp';
$txt['search'] = 'Søk';
$txt['calendar'] = 'Kalender';
$txt['members'] = 'Medlemmer';
$txt['recent_posts'] = 'Nyeste innlegg';

$txt['admin'] = 'Administrator';
// Sub menu labels
$txt['errlog'] = 'Loggførte feilmeldinger';
$txt['package'] = 'Pakkebehandling';
$txt['edit_permissions'] = 'Tillatelser';
$txt['modSettings_title'] = 'Funksjoner og innstillinger';

$txt['moderate'] = 'Moderer';
// Sub menu labels
$txt['modlog_view'] = 'Moderatorlogg';
$txt['mc_emailerror'] = 'Unapproved Emails';
$txt['mc_reported_posts'] = 'Rapportert innlegg';
$txt['mc_reported_pms'] = 'Reported Personal Messages';
$txt['mc_unapproved_attachments'] = 'Ikke godkjente vedlegg';
$txt['mc_unapproved_poststopics'] = 'Ikke godkjente innlegg og emner';

$txt['pm_short'] = 'Mine meldinger';
// Sub menu labels
$txt['pm_menu_read'] = 'Les meldinger';
$txt['pm_menu_send'] = 'Send en melding';

$txt['account_short'] = 'My Account';
// Sub menu labels
$txt['profile'] = 'Profiler';
$txt['mydrafts'] = 'My Drafts';
$txt['summary'] = 'Oppsummering';
$txt['theme'] = 'Utseende- og layoutinnstillinger';
$txt['account'] = 'Innstillinger for medlemskonto';
$txt['forumprofile'] = 'Forum profil';

$txt['view_unread_category'] = 'Nye innlegg';
$txt['view_replies_category'] = 'New Replies';

$txt['login'] = 'Log in';
$txt['register'] = 'Registrer';
$txt['logout'] = 'Log out';
// End main menu strings.

$txt['save'] = 'Lagre';

$txt['modify'] = 'Rediger';
$txt['forum_index'] = '%1$s - Hovedside';
$txt['board_name'] = 'Navn på forum';
$txt['posts'] = 'Innlegg';

$txt['member_postcount'] = 'Innlegg';
$txt['no_subject'] = '(Uten tittel)';
$txt['view_profile'] = 'Vis profil';
$txt['guest_title'] = 'gjest';
$txt['author'] = 'Laget av';
$txt['on'] = 'am';
$txt['remove'] = 'Slett';
$txt['start_new_topic'] = 'Start nytt emne';

// Use numeric entities in the below string.
$txt['username'] = 'Brukernavn';
$txt['password'] = 'Passord';

$txt['username_no_exist'] = 'Brukernavnet eksisterer ikke.';
$txt['no_user_with_email'] = 'Det er ingen brukernavn knyttet til denne e-postadressen.';

$txt['board_moderator'] = 'Moderator';
$txt['remove_topic'] = 'Slett';
$txt['topics'] = 'Emner';
$txt['modify_msg'] = 'Rediger innlegg';
$txt['name'] = 'Navn';
$txt['email'] = 'E-post';
$txt['user_email_address'] = 'E-postadresse';
$txt['subject'] = 'Tittel';
$txt['message'] = 'Melding';
$txt['redirects'] = 'Omdirigeringer';

$txt['choose_pass'] = 'Velg passord';
$txt['verify_pass'] = 'Bekreft passord';
$txt['position'] = 'Stilling';
$txt['notify_announcements'] = 'Sign up to receive important site news by email';

$txt['profile_of'] = 'Viser profilen til';
$txt['total'] = 'Totalt';
$txt['posts_made'] = 'Innlegg';
$txt['topics_made'] = 'Emner';
$txt['website'] = 'Hjemmeside';
$txt['contact'] = 'Contact Us';
$txt['warning_status'] = 'Status advarsler';
$txt['user_warn_watch'] = 'Brukeren er på moderators overvåkingsliste';
$txt['user_warn_moderate'] = 'Brukerens innlegg er lagt i godkjenningskøen';
$txt['user_warn_mute'] = 'Brukeren er utestengt fra å legge til innlegg';
$txt['warn_watch'] = 'Overvåket';
$txt['warn_moderate'] = 'Modereret';
$txt['warn_mute'] = 'Ignorert';
$txt['warning_issue'] = 'Warn';

$txt['message_index'] = 'Oversikt';
$txt['news'] = 'Nyheter';
$txt['page'] = 'Page';
$txt['prev'] = 'previous';
$txt['next'] = 'next';

$txt['post'] = 'Legg til innlegg';
$txt['error_occurred'] = 'An Error Has Occurred';
$txt['send_error_occurred'] = 'An error has occurred, <a href="{href}">please click here to try again</a>.';
$txt['require_field'] = 'This is a required field.';
$txt['started_by'] = 'Started by author';
$txt['topic_started_by'] = 'Started by %1$s';
$txt['topic_started_by_in'] = 'Started by %1$s in %2$s';
$txt['replies'] = 'Svar';
$txt['last_post'] = 'Nyeste innlegg';
$txt['first_post'] = 'First post';
$txt['last_poster'] = 'Last post author';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s </span><span class="board_lastposter">by %1$s</span><span class="board_lasttime"><strong>Last post: </strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s Posts in %2$s Topics by %3$s Members';
$txt['show'] = 'Show';
$txt['hide'] = 'Hide';
$txt['sort_by'] = 'Sort By';
$txt['sort_asc'] = 'Sort ascending';
$txt['sort_desc'] = 'Sort descending';

$txt['admin_login'] = 'Administration Log in';
// Use numeric entities in the below string.
$txt['topic'] = 'Emne';
$txt['help'] = 'Hjelp';
$txt['notify'] = 'Varsling';
$txt['unnotify'] = 'Stopp varsling';
$txt['notify_request'] = 'Ønsker du å få en varsling på e-post om noen svarer på dette emnet?';
// Use numeric entities in the below string.
$txt['regards_team'] = "Regards,\nThe {forum_name_html_unsafe} Team.";
$txt['notify_replies'] = 'Varsling ved svar';
$txt['move_topic'] = 'Flytt';
$txt['move_to'] = 'Flytt til';
$txt['pages'] = 'Sider';
$txt['users_active'] = 'Active in past %1$d minutes';
$txt['personal_messages'] = 'Personlige meldinger';
$txt['reply_quote'] = 'Svar med sitat';
$txt['reply'] = 'Svar';
$txt['reply_number'] = 'Reply #%1$s';
$txt['approve'] = 'Godkjenn';
$txt['unapprove'] = 'Unapprove';
$txt['approve_all'] = 'godkjenn alle';
$txt['awaiting_approval'] = 'Venter på godkjenning';
$txt['attach_awaiting_approve'] = 'Vedlegg venter på godkjenning';
$txt['post_awaiting_approval'] = 'Merk: Denne meldingen avventer godkjennelse av en moderator.';
$txt['there_are_unapproved_topics'] = 'There are %1$s topics and %2$s posts awaiting approval in this board. <a href="%3$s">Click here to view them</a>.';
$txt['send_message'] = 'Send melding';

$txt['msg_alert_no_messages'] = 'you don\'t have any message';
$txt['msg_alert_one_message'] = 'you have <a href="%1$s">1 message</a>';
$txt['msg_alert_many_message'] = 'you have <a href="%1$s">%2$d messages</a>';
$txt['msg_alert_one_new'] = '1 is new';
$txt['msg_alert_many_new'] = '%1$d are new';
$txt['remove_message'] = 'Slett melding';

$txt['topic_alert_none'] = 'Ingen meldinger...';
$txt['pm_alert_none'] = 'Ingen meldinger...';

$txt['online_users'] = 'Brukere pålogget'; //Deprecated
$txt['online_now'] = 'Online Now';
$txt['personal_message'] = 'Personlig melding';
$txt['jump_to'] = 'Gå til';
$txt['go'] = 'Ok';
$txt['are_sure_remove_topic'] = 'Er du sikker på at du vil slette dette emnet?';
$txt['yes'] = 'Ja';
$txt['no'] = 'Nei';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'am';

$txt['search'] = 'Søk';
$txt['all'] = 'Alle';
$txt['search_entireforum'] = 'Entire Forum';
$txt['search_thisbrd'] = 'This board';
$txt['search_thistopic'] = 'This topic';
$txt['search_members'] = 'Medlemmer';

$txt['back'] = 'Tilbake';
$txt['continue'] = 'Fortsett';
$txt['password_reminder'] = 'passord-påminnelse';
$txt['topic_started'] = 'Emne startet av';
$txt['title'] = 'Tittel';
$txt['post_by'] = 'Skrevet av';
$txt['welcome_newest_member'] = 'Please welcome %1$s, our newest member.';
$txt['admin_center'] = 'Administratorpanel';
$txt['admin_session_active'] = 'You have an active admin session in place. We recommend to <strong><a class="strong" href="%1$s">end this session</a></strong> once you have finished your administrative tasks.';
$txt['admin_maintenance_active'] = 'Your forum is currently in maintenance mode, only admins can log in.  Remember to <strong><a class="strong" href="%1$s">exit maintenance</a></strong> once you have finished your administrative tasks.';
$txt['query_command_denied'] = 'The following MySQL errors are occurring, please verify your setup:';
$txt['query_command_denied_guests'] = 'It seems something has gone sour on the forum with the database. This problem should only be temporary, so please come back later and try again.  If you continue to see this message, please report the following message to the administrator:';
$txt['query_command_denied_guests_msg'] = 'the command %1$s is denied on the database';
$txt['last_edit_by'] = '<span class="lastedit">Last Edit</span>: %1$s by %2$s';
$txt['notify_deactivate'] = 'Ønsker du å deaktivere varsling for dette emnet?';

$txt['date_registered'] = 'Registreringsdato';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'View all recent posts.';
$txt['is_recent_updated'] = '%1$s is the most recently updated topic';

$txt['male'] = 'Mann';
$txt['female'] = 'Kvinne';

$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Hei,';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Velkommen,';
$txt['select_destination'] = 'Vennligst velg en destinasjon';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Skrevet av';

$txt['icon_smiley'] = 'Smiler';
$txt['icon_angry'] = 'Sint';
$txt['icon_cheesy'] = 'Osteaktig';
$txt['icon_laugh'] = 'Ler';
$txt['icon_sad'] = 'Trist';
$txt['icon_wink'] = 'Blunker';
$txt['icon_grin'] = 'Gliser';
$txt['icon_shocked'] = 'Sjokkert';
$txt['icon_cool'] = 'Kult';
$txt['icon_huh'] = 'Hæ';
$txt['icon_rolleyes'] = 'Øyerulling';
$txt['icon_tongue'] = 'Rekke tunge';
$txt['icon_embarrassed'] = 'Flaut';
$txt['icon_lips'] = 'Hemmelig';
$txt['icon_undecided'] = 'Tvilende';
$txt['icon_kiss'] = 'Kysser';
$txt['icon_cry'] = 'Gråter';
$txt['icon_angel'] = 'Innocent';

$txt['moderator'] = 'Moderator';
$txt['moderators'] = 'Moderatorer';

$txt['views'] = 'Visninger';
$txt['new'] = 'Ny(e)';
$txt['no_redir'] = 'Redirected from %1$s';

$txt['view_all_members'] = 'Vis alle medlemmer';
$txt['view'] = 'Vis';

$txt['viewing_members'] = 'Viser medlemmer %1$s til %2$s';
$txt['of_total_members'] = 'av %1$s medlemmer';

$txt['forgot_your_password'] = 'Glemt passordet?';

$txt['date'] = 'Dato';
// Use numeric entities in the below string.
$txt['from'] = 'Fra';
$txt['to'] = 'Til';

$txt['board_topics'] = 'Emner';
$txt['members_title'] = 'Medlemmer';
$txt['members_list'] = 'Medlemsliste';
$txt['new_posts'] = 'Nye innlegg';
$txt['old_posts'] = 'Ingen nye innlegg';
$txt['redirect_board'] = 'Omadresser emne';
$txt['redirect_board_to'] = 'Redirecting to %1$s';

$txt['sendtopic_send'] = 'Send';
$txt['report_sent'] = 'Din rapport er sendt.';
$txt['topic_sent'] = 'Your email has been sent successfully.';

$txt['time_offset'] = 'Tidsavvik';
$txt['or'] = 'eller';

$txt['mention'] = 'Varsling og e-post';
$txt['notifications'] = 'Varsling og e-post';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = 'Beklager %1$s, du er utestengt fra dette forumet!';
$txt['your_ban_expires'] = 'Denne utestengingen er satt til å utløpe %1$s.';
$txt['your_ban_expires_never'] = 'Denne utestengningen er satt til å vare for alltid';
$txt['ban_continue_browse'] = 'Du kan fortsette å surfe på forumet som en gjest.';

$txt['mark_as_read'] = 'Marker alle innlegg som lest';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'Mark THESE messages as read';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'Steng emne';
$txt['normal_topic'] = 'Vanlig emne';
$txt['participation_caption'] = 'Emne du har postet til';

$txt['print'] = 'Skriv ut';
$txt['topic_summary'] = 'Emneoversikt';
$txt['not_applicable'] = 'N/A';
$txt['name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['total_members'] = 'Medlemmer totalt';
$txt['total_posts'] = 'Innlegg totalt';
$txt['total_topics'] = 'Emner totalt';

$txt['mins_logged_in'] = 'Innloggingstid i minutter';

$txt['preview'] = 'Forhåndsvis';
$txt['always_logged_in'] = 'Forbli alltid innlogget';

$txt['logged'] = 'Loggført';
// Use numeric entities in the below string.
$txt['ip'] = 'IP';

$txt['www'] = 'Hjemmeside';
$txt['link'] = 'Link';

$txt['by'] = 'av'; //Deprecated

$txt['hours'] = 'timer';
$txt['minutes'] = 'minutter';
$txt['seconds'] = 'sekunder';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'Time';
$txt['days_word'] = 'dager';

$txt['newest_member'] = ', vårt nyeste medlem.'; //Deprecated

$txt['search_for'] = 'Søk etter';
$txt['search_match'] = 'Match';

$txt['maintain_mode_on'] = 'Husk at forumet er under vedlikehold.';

$txt['read'] = 'Les'; //Deprecated
$txt['times'] = 'ganger'; //Deprecated
$txt['read_one_time'] = 'Read 1 time';
$txt['read_many_times'] = 'Read %1$d times';

$txt['forum_stats'] = 'Forum-statistikk';
$txt['latest_member'] = 'Nyeste medlem';
$txt['total_cats'] = 'Kategorier totalt';
$txt['latest_post'] = 'Nyeste innlegg';

$txt['here'] = 'her';
$txt['you_have_no_msg'] = 'You don\'t have any message...';
$txt['you_have_one_msg'] = 'You\'ve 1 message...<a href="%1$s">Click here to view it</a>';
$txt['you_have_many_msgs'] = 'You\'ve %2$d messages...<a href="%1$s">Click here to view them</a>';

$txt['total_boards'] = 'Forum totalt';

$txt['print_page'] = 'Skriv ut side';
$txt['print_page_text'] = 'Text only';
$txt['print_page_images'] = 'Text with Images';

$txt['valid_email'] = 'Dette må være en gyldig e-postadresse.';

$txt['info_center_title'] = '%1$s - Info-senter';

$txt['send_topic'] = 'Share';
$txt['unwatch'] = 'Unwatch';
$txt['watch'] = 'Watch';

$txt['sendtopic_title'] = 'Tips en venn om emnet &quot;%1$s&quot;.';
$txt['sendtopic_sender_name'] = 'Ditt navn';
$txt['sendtopic_sender_email'] = 'Din e-postadresse';
$txt['sendtopic_receiver_name'] = 'Mottakers navn';
$txt['sendtopic_receiver_email'] = 'Mottakers e-postadresse';
$txt['sendtopic_comment'] = 'Legg til kommentar';

$txt['allow_user_email'] = 'Tillat medlemmer å sende e post til meg';

$txt['check_all'] = 'Marker alle';

// Use numeric entities in the below string.
$txt['database_error'] = 'Feil i databasen';
$txt['try_again'] = 'Prøv på nytt. Om du kommer tilbake til denne feilmeldingen, rapporter feilen til en administrator.';
$txt['file'] = 'Fil';
$txt['line'] = 'Linje';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'ElkArte has detected and automatically tried to repair an error in your database.  If you continue to have problems, or continue to receive these emails, please contact your host.';
$txt['database_error_versions'] = '<strong>Note:</strong> Your database version is %1$s.';
$txt['template_parse_error'] = 'PHP-feil i designfilene!';
$txt['template_parse_error_message'] = 'Det kan se ut som noe har gått virkelig galt med designet du vil vise på forumet. Problemet er gjerne bare midlertidig, så du må gjerne komme tilbake og prøve på nytt. Dersom problemet fortsetter, ta kontakt med administrator.<br /><br />Du kan også prøve å <a href="javascript:location.reload();">oppdatere denne siden</a>.';
$txt['template_parse_error_details'] = 'There was a problem loading the <span class="tt"><strong>%1$s</strong></span> template or language file.  Please check the syntax and try again - remember, single quotes (<span class="tt">\'</span>) often have to be escaped with a backslash (<span class="tt">\\</span>).  To see more specific error information from PHP, try <a href="%2$s%1$s">accessing the file directly</a>.<br /><br />You may want to try to <a href="javascript:location.reload();">refresh this page</a> or <a href="%3$s">use the default theme</a>.';
$txt['template_parse_undefined'] = 'An undefined error occurred during the parsing of this template';

$txt['today'] = 'Today at %1$s';
$txt['yesterday'] = 'Yesterday at %1$s';

// Relative times
$txt['rt_now'] = 'just now';
$txt['rt_minute'] = 'A minute ago';
$txt['rt_minutes'] = '%s minutes ago';
$txt['rt_hour'] = 'An hour ago';
$txt['rt_hours'] = '%s hours ago';
$txt['rt_day'] = 'A day ago';
$txt['rt_days'] = '%s days ago';
$txt['rt_week'] = 'A week ago';
$txt['rt_weeks'] = '%s weeks ago';
$txt['rt_month'] = 'A month ago';
$txt['rt_months'] = '%s months ago';
$txt['rt_year'] = 'A year ago';
$txt['rt_years'] = '%s years ago';

$txt['new_poll'] = 'Ny avstemning';
$txt['poll_question'] = 'Spørgsmål';
$txt['poll_question_options'] = 'Question and Options';
$txt['poll_vote'] = 'Lagre avstemning';
$txt['poll_total_voters'] = 'Stemmer totalt';
$txt['draft_saved_on'] = 'Draft last saved';
$txt['poll_results'] = 'Vis resultater';
$txt['poll_lock'] = 'Steng avstemning';
$txt['poll_unlock'] = 'Åpne avstemning';
$txt['poll_edit'] = 'Rediger avstemning';
$txt['poll'] = 'avstemning';
$txt['one_day'] = '1 dag';
$txt['one_week'] = '1 uke';
$txt['two_weeks'] = '2 Weeks';
$txt['one_month'] = '1 måned';
$txt['two_months'] = '2 Months';
$txt['forever'] = 'Alltid';
$txt['quick_login_dec'] = 'Logg inn med brukernavn, passord og innloggingstid';
$txt['one_hour'] = '1 time';
$txt['moved'] = 'FLYTTET';
$txt['moved_why'] = 'Skriv inn en kort beskrivelse for<br />hvorfor emnet flyttes.';
$txt['board'] = 'Forum';
$txt['in'] = 'nb';
$txt['sticky_topic'] = 'Pinned Topic';
$txt['split'] = 'SPLIT';

$txt['delete'] = 'Slett';

$txt['byte'] = 'B';
$txt['kilobyte'] = 'KB';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[Mer statisikk]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Kode';
$txt['code_select'] = '[Velg]';
$txt['quote_from'] = 'Sitat fra';
$txt['quote'] = 'Sitat';
$txt['quote_new'] = 'New topic';
$txt['follow_ups'] = 'Follow-ups';
$txt['topic_derived_from'] = 'Topic derived from %1$s';
$txt['edit'] = 'Rediger';
$txt['quick_edit'] = 'Quick Edit';
$txt['post_options'] = 'More...';

$txt['set_sticky'] = 'Pin';
$txt['set_nonsticky'] = 'Unpin';
$txt['set_lock'] = 'Låse';
$txt['set_unlock'] = 'Åpne';

$txt['search_advanced'] = 'Show advanced options';
$txt['search_simple'] = 'Hide advanced options';

$txt['security_risk'] = 'ALVORLIG SIKKERHETSRISIKO:';
$txt['not_removed'] = 'You have not removed %1$s';
$txt['not_removed_extra'] = '%1$s is a backup of %2$s that was not generated by ElkArte. It can be accessed directly and used to gain unauthorised access to your forum. You should delete it immediately.';
$txt['generic_warning'] = 'Warning';
$txt['agreement_missing'] = 'You are requiring new users to accept a registration agreement, however the file (agreement.txt) doesn\'t exist.';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'You have just updated!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Click here to see what\'s new in this version of ElkArte!</a>!';

$txt['cache_writable'] = 'Mappe formellomlagring er ikke skrivbar - dette vil påvirke ytelsen til forumet ditt.';

$txt['page_created_full'] = 'Page created in %1$.3f seconds with %2$d queries.';

$txt['report_to_mod_func'] = 'Bruk denne funksjonen til å informere moderatorene og administratorene om et støtende eller feilplassert innlegg.<br /><em>Vær oppmersom på at din e-postadresse blir synlig for moderatorene ved bruk av denne funksjonen.</em>';

$txt['online'] = 'Innlogget';
$txt['member_is_online'] = '%1$s is online';
$txt['offline'] = 'Utlogget';
$txt['member_is_offline'] = '%1$s is offline';
$txt['pm_online'] = 'Personlig melding (innlogget)';
$txt['pm_offline'] = 'Personlig melding (utlogget)';
$txt['status'] = 'Status';

$txt['skip_nav'] = 'Skip to main content';
$txt['go_up'] = 'Til toppen';
$txt['go_down'] = 'Til bunnen';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Fødselsdager:';
$txt['events'] = 'Hendelser:';
$txt['birthdays_upcoming'] = 'Kommende fødselsdager:';
$txt['events_upcoming'] = 'Kommende hendelser:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Holidays:';
$txt['calendar_month'] = 'Måned:';
$txt['calendar_year'] = 'År:';
$txt['calendar_day'] = 'Dag:';
$txt['calendar_event_title'] = 'Tittel på hendelsen:';
$txt['calendar_event_options'] = 'Hendelses alternativer';
$txt['calendar_post_in'] = 'Lag emne i:';
$txt['calendar_edit'] = 'Rediger hendelse';
$txt['event_delete_confirm'] = 'Slett denne hendelsen?';
$txt['event_delete'] = 'Slett hendelse';
$txt['calendar_post_event'] = 'Legg til hendelse';
$txt['calendar'] = 'Kalender';
$txt['calendar_link'] = 'Tilknytt kalender';
$txt['calendar_upcoming'] = 'Kommende hendelser';
$txt['calendar_today'] = 'Dagens kalender';
$txt['calendar_week'] = 'Uke';
$txt['calendar_week_title'] = 'Uke %1$d av %2$d';
$txt['calendar_numb_days'] = 'Antall dager:';
$txt['calendar_how_edit'] = 'hvordan redigerer du disse hendelsene?';
$txt['calendar_link_event'] = 'Tilknytt hendelse';
$txt['calendar_confirm_delete'] = 'Er du sikker på at du vil slette denne hendelsen?';
$txt['calendar_linked_events'] = 'Tilknyttede hendelser';
$txt['calendar_click_all'] = 'klikk for å se alle %1$s';

$txt['moveTopic1'] = 'Legg til videresendings-emne';
$txt['moveTopic2'] = 'Endre tittel på emnet';
$txt['moveTopic3'] = 'Ny tittel';
$txt['moveTopic4'] = 'Rediger tittel på alle innlegg';
$txt['move_topic_unapproved_js'] = 'Advarsel! Dette emnet er ennå ikke godkjent.\\n\\nDet anbefales ikke at du oppretter en omdirigerings emne med mindre du har tenkt å godkjenne innlegget umiddelbart etter flyttingen.';
$txt['movetopic_auto_board'] = '[FORUM]';
$txt['movetopic_auto_topic'] = '[EMNE-LENKE]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Redirect to the moved topic';
$txt['movetopic_expires'] = 'Automatically remove the redirection topic';

$txt['merge_to_topic_id'] = 'ID til målemne';
$txt['split_topic'] = 'Split';
$txt['merge'] = 'Merge';
$txt['subject_new_topic'] = 'Tittel på nytt emne';
$txt['split_this_post'] = 'Splitt kun dette innlegget.';
$txt['split_after_and_this_post'] = 'Splitt emne fra og med dette innlegget.';
$txt['select_split_posts'] = 'Velg innlegg som skal splittes.';

$txt['splittopic_notification'] = 'Post a message when the topic is split';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Move the new topic to another board';

$txt['new_topic'] = 'Nytt emne';
$txt['split_successful'] = 'Emnet ble splittet i to emner.';
$txt['origin_topic'] = 'Opprinnelig emne';
$txt['please_select_split'] = 'Velg hvilke innlegg du vil splitte.';
$txt['merge_successful'] = 'Emnene ble slått sammen.';
$txt['new_merged_topic'] = 'Nytt sammenslått emne';
$txt['topic_to_merge'] = 'Emnet som skal sammenslås';
$txt['target_board'] = 'Plasseres i forum';
$txt['target_topic'] = 'Plasseres i emne';
$txt['merge_confirm'] = 'Er du sikker på at du vil slå sammen';
$txt['with'] = 'med';
$txt['merge_desc'] = 'Denne funksjonen vil slå sammen innleggene i to emner til ett emne. Innleggene vil da bli sortert etter dato og derfor kan rekkefølgen på innleggene være forandret, slik at det eldste innlegget vil komme først i det nye emnet.';

$txt['theme_template_error'] = 'Kunne ikke laste utseende til \'%1$s\'.';
$txt['theme_language_error'] = 'Kunne ikke laste språkfilen til \'%1$s\'.';

$txt['parent_boards'] = 'Sub-boards';

$txt['smtp_no_connect'] = 'Kunne ikke koble til SMTP verten';
$txt['smtp_port_ssl'] = 'SMTP-porten er stilt inn feil; den bør være 465 for SSL-servere.';
$txt['smtp_bad_response'] = 'Kunne ikke motta respons fra mailserver';
$txt['smtp_error'] = 'Det oppsto et problem ved sending av e-post. Feilmelding: ';
$txt['mail_send_unable'] = 'Kunne ikke sende e-post til adressen \'%1$s\'';

$txt['mlist_search'] = 'Søk etter medlemmer';
$txt['mlist_search_again'] = 'Søk på nytt'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Søk på e-postadresse';
$txt['mlist_search_group'] = 'Søk på posisjon';
$txt['mlist_search_name'] = 'Søk på navn';
$txt['mlist_search_website'] = 'Søk på hjemmeside';
$txt['mlist_search_results'] = 'Søkeresultater';
$txt['mlist_search_by'] = 'Søk på %1$s';

$txt['attach_downloaded'] = 'downloaded %1$d times';
$txt['attach_viewed'] = 'viewed %1$d times';

$txt['settings'] = 'Innstillinger';
$txt['never'] = 'Aldri';
$txt['more'] = 'flere';

$txt['hostname'] = 'Vertsnavn';
$txt['you_are_post_banned'] = 'Beklager %1$s, du er utestengt fra å skrive innlegg og personlige meldinger på dette forumet.';
$txt['ban_reason'] = 'Grunn';

$txt['add_poll'] = 'Legg til avstemning';
$txt['poll_options6'] = 'Du kan bare velge opptil %1$s alternativer.';
$txt['poll_remove'] = 'Fjern avstemning';
$txt['poll_remove_warn'] = 'Er du sikker på at du vil fjerne avstemningen fra dette emnet?';
$txt['poll_results_expire'] = 'Resultatene vil vises når avstemningen er avsluttet';
$txt['poll_expires_on'] = 'Avstemning avsluttes';
$txt['poll_expired_on'] = 'Avstemning er avsluttet';
$txt['poll_change_vote'] = 'Fjern stemme';
$txt['poll_return_vote'] = 'Innstillinger for stemmegivning';
$txt['poll_cannot_see'] = 'Du kan ikke se resultatene av denne avstemningen for øyeblikket.';

$txt['quick_mod_approve'] = 'Godkjenn valgte';
$txt['quick_mod_remove'] = 'Slett valgt(e)';
$txt['quick_mod_lock'] = 'Steng/åpne valgte';
$txt['quick_mod_sticky'] = 'Pin/Unpin selected';
$txt['quick_mod_move'] = 'Flytt valgt(e) til';
$txt['quick_mod_merge'] = 'Slå sammen valgt(e)';
$txt['quick_mod_markread'] = 'Marker valgt(e) som lest';
$txt['quick_mod_go'] = 'Ok';
$txt['quickmod_confirm'] = 'Er du sikker på at du vil gjøre dette?';

$txt['spell_check'] = 'Stavekontroll';

$txt['quick_reply'] = 'Hurtigsvar';
$txt['quick_reply_warning'] = 'Warning! This topic is currently locked, only admins and moderators can reply.';
$txt['quick_reply_verification'] = 'Etter innsending av innlegget ditt vil du bli henvist til den vanlige siden for å verifisere ditt innlegg %1$s.';
$txt['quick_reply_verification_guests'] = '(kreves for alle gjester)';
$txt['quick_reply_verification_posts'] = '(kreves for alle brukere med mindre enn %1$d innlegg)';
$txt['wait_for_approval'] = 'Merk: dette innlegget vil ikke vises før det er blitt godkjent av en moderator.';

$txt['notification_enable_board'] = 'Er du sikker på at du vil aktivere varsling om nye emner i dette forumet?';
$txt['notification_disable_board'] = 'Er du sikker på at du vil deaktivere varsling om nye emner i dette forumet?';
$txt['notification_enable_topic'] = 'Er du sikker på at du vil aktivere varsling om nye svar i dette emnet?';
$txt['notification_disable_topic'] = 'Er du sikker på at du vil deaktivere varsling om nye svar i dette emnet?';

$txt['report_to_mod'] = 'Report Post';
$txt['issue_warning_post'] = 'Utstede en advarsel på grunn av denne meldingen';

$txt['like_post'] = 'Like';
$txt['unlike_post'] = 'Unlike';
$txt['likes'] = 'Likes';
$txt['liked_by'] = 'Liked by:';
$txt['liked_you'] = 'You';
$txt['liked_more'] = 'flere';
$txt['likemsg_are_you_sure'] = 'You already liked this message, are you sure you want to remove your like?';

$txt['unread_topics_visit'] = 'Nye uleste emner';
$txt['unread_topics_visit_none'] = 'No unread topics found since your last visit. <a href="{unread_all_url}" class="linkbutton">Click here to try all unread topics</a>';
$txt['unread_topics_all'] = 'Alle uleste emner';
$txt['unread_replies'] = 'Oppdaterte emner';

$txt['who_title'] = 'Hvem er pålogget';
$txt['who_and'] = ' og ';
$txt['who_viewing_topic'] = ' leser dette emnet.';
$txt['who_viewing_board'] = ' er inne på dette forumet.';
$txt['who_member'] = 'Medlem';

// Current footer strings
$txt['valid_html'] = 'Valid HTML 5';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'gjest';
$txt['guests'] = 'Gjester';
$txt['user'] = 'Bruker';
$txt['users'] = 'Brukere';
$txt['hidden'] = 'Skjult';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'Skjult';
$txt['buddy'] = 'venn';
$txt['buddies'] = 'venner';
$txt['most_online_ever'] = 'Flest pålogget noen sinne';
$txt['most_online_today'] = 'Flest pålogget idag';

$txt['merge_select_target_board'] = 'Velg hvilket forum det sammenslåtte emnet skal plasseres i';
$txt['merge_select_poll'] = 'Velg hvilken avstemning det sammenslåtte emnet skal ha';
$txt['merge_topic_list'] = 'Velg emner som skal slås sammen';
$txt['merge_select_subject'] = 'Velg tittel på sammenslått emne';
$txt['merge_custom_subject'] = 'Annen tittel';
$txt['merge_enforce_subject'] = 'Endre tittel på alle innlegg';
$txt['merge_include_notifications'] = 'Inkluder varslinger?';
$txt['merge_check'] = 'Slå sammen?';
$txt['merge_no_poll'] = 'Ingen avstemning';

$txt['response_prefix'] = 'Sv: ';
$txt['current_icon'] = 'Current icon';
$txt['message_icon'] = 'Ikon for innlegg';

$txt['smileys_current'] = 'Gjeldende smilefjes-sett';
$txt['smileys_none'] = 'Ingen smilefjes';
$txt['smileys_forum_board_default'] = 'Forvalg for forum';

$txt['search_results'] = 'Søkeresulater';
$txt['search_no_results'] = 'Beklager, ingen treff ble funnet';

$txt['totalTimeLogged2'] = ' dager, ';
$txt['totalTimeLogged3'] = ' timer og ';
$txt['totalTimeLogged4'] = ' minutter.';
$txt['totalTimeLogged5'] = 'd';
$txt['totalTimeLogged6'] = 't ';
$txt['totalTimeLogged7'] = 'm';

$txt['approve_thereis'] = 'Det er'; //Deprecated
$txt['approve_thereare'] = 'Det er'; //Deprecated
$txt['approve_member'] = 'ett medlem'; //Deprecated
$txt['approve_members'] = 'medlemmer'; //Deprecated
$txt['approve_members_waiting'] = 'som venter på godkjenning.'; //Deprecated
$txt['approve_one_member_waiting'] = 'There is <a href="%1$s">one member</a> awaiting approval.';
$txt['approve_many_members_waiting'] = 'There are <a href="%1$s">%2$d members</a> awaiting approval.';

$txt['notifyboard_turnon'] = 'Ønsker du å få varsling på e-post når noen lager et nytt emne i dette forumet?';
$txt['notifyboard_turnoff'] = 'Er du sikker på at du ikke vil motta varsling på e-post om nye emner i dette forumet?';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Søk etter medlemmer';
$txt['find_username'] = 'Navn, brukernavn, eller e-postadresse';
$txt['find_buddies'] = 'Vis kun venner?';
$txt['find_wildcards'] = 'Tillatte jokertegn: *, ?';
$txt['find_no_results'] = 'Ingen treff funnet';
$txt['find_results'] = 'Resultater';
$txt['find_close'] = 'Lukk';

$txt['quickmod_delete_selected'] = 'Slett valgte';
$txt['quickmod_split_selected'] = 'Split Selected';

$txt['show_personal_messages_heading'] = 'New messages';
$txt['show_personal_messages'] = 'You have <strong>%1$s</strong> unread personal messages in your inbox.<br /><br /><a href="%2$s">Go to your inbox</a>';

$txt['help_popup'] = 'A little lost? Let me explain:';

$txt['previous_next_back'] = 'previous topic';
$txt['previous_next_forward'] = 'next topic';

$txt['upshrink_description'] = 'Krymp eller utvid topp-feltet.';

$txt['mark_unread'] = 'Marker som ulest';

$txt['ssi_not_direct'] = 'Vennligst ikke lag lenker direkte mot SSI.php; du kan istedet benytte stien (%1$s) eller legge til ?ssi_function=etellerannet.';
$txt['ssi_session_broken'] = 'SSI.php klarte ikke å laste inn en sessjon! Dette kan skape problem med utlogging og andre funksjoner - vennligst forsikre deg om at SSI.php inkluderes før *alt* annet i dine scripts!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Forhåndsvis innlegg';
$txt['preview_fetch'] = 'Henter forhåndsvisning...';
$txt['pm_error_while_submitting'] = 'The following error or errors occurred while sending this personal message:';
$txt['warning_while_submitting'] = 'Something happened, review it here:';
$txt['error_while_submitting'] = 'The message has the following error or errors that must be corrected before continuing:';
$txt['error_old_topic'] = 'Advarsel: Det er ikke blitt lagt til noen emner her på minst %1$d dager.<br />Med mindre du er helt sikker på at du vil svare, kan du vurdere å starte et nytt emne.';

$txt['split_selected_posts'] = 'Valgte innlegg';
$txt['split_selected_posts_desc'] = 'Innleggene nedenfor vil danne et nytt emne etter splitting.';
$txt['split_reset_selection'] = 'tilbakestill valg';

$txt['modify_cancel'] = 'Avbryt';
$txt['mark_read_short'] = 'Merk som lest';

$txt['hello_member_ndt'] = 'Hallo';

$txt['unapproved_posts'] = 'Ikke godkjente innlegg (Emner: %1$d, Innlegg: %2$d)';

$txt['ajax_in_progress'] = 'Laster...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = 'Det er for tiden %1$d moderator rapporter åpne.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'Click to see the new posts in %1$s';
$txt['verification'] = 'Bekreftelse';
$txt['visual_verification_hidden'] = 'Please leave this box empty';
$txt['visual_verification_description'] = 'Skriv tegn som vises i bildet';
$txt['visual_verification_sound'] = 'Lytt til tegn';
$txt['visual_verification_request_new'] = 'Be om et nytt bilde';

// @todo Send email strings - should move?
$txt['send_email'] = 'Send email';
$txt['send_email_disclosed'] = 'Merk: Dette vil være synlig for mottakeren.';
$txt['send_email_subject'] = 'E-post emne';

$txt['ignoring_user'] = 'Du ignorerer denne brukeren.';
$txt['show_ignore_user_post'] = '<em>[Show me the post.]</em>';

$txt['spider'] = 'Robot';
$txt['spiders'] = 'Roboter';
$txt['openid'] = 'OpenID';

$txt['downloads'] = 'Nedlastinger';
$txt['filesize'] = 'File size';
$txt['subscribe_webslice'] = 'Abonner på Webslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Gjenopprett emne';
$txt['restore_message'] = 'Gjenopprett';
$txt['quick_mod_restore'] = 'Gjenopprett utvalgte';

// Editor prompt.
$txt['prompt_text_email'] = 'Vennligst oppgi e-postadressen.';
$txt['prompt_text_ftp'] = 'Please enter the FTP address.';
$txt['prompt_text_url'] = 'Vennligst skriv inn nettadressen du ønsker å lenke til.';
$txt['prompt_text_img'] = 'Skriv inn bilde plassering';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Slett element';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> has blocked %1$s access attempts in the last 7 days.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Maler: ';
$txt['debug_subtemplates'] = 'Undermaler: '; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Undermaler: ';
$txt['debug_language_files'] = 'Språkfiler:';
$txt['debug_sheets'] = 'Stilark: ';
$txt['debug_javascript'] = 'Scripts: ';
$txt['debug_files_included'] = 'Filer inkludert: ';
$txt['debug_kb'] = 'KB.';
$txt['debug_show'] = 'vis';
$txt['debug_cache_hits'] = 'Hurtigbuffer treff: ';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s bytes';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss for %2$s bytes';
$txt['debug_queries_used'] = 'Spørringer brukt: %1$d.';
$txt['debug_queries_used_and_warnings'] = 'Spørringer brukt: %1$d, %2$d advarsler.';
$txt['debug_query_in_line'] = 'i <em>%1$s</em> linje <em>%2$s</em>, ';
$txt['debug_query_which_took'] = 'som tok %1$s sekunder.';
$txt['debug_query_which_took_at'] = 'som tok %1$s sekunder ved %2$s inn i forespørselen.';
$txt['debug_show_queries'] = '[Vis spørringer]';
$txt['debug_hide_queries'] = '[Skjul spørringer]';
$txt['debug_tokens'] = 'Tokens: ';
$txt['debug_browser'] = 'Browser ID: ';
$txt['debug_hooks'] = 'Hooks called: ';
$txt['debug_system_type'] = 'System: ';
$txt['debug_server_load'] = 'Server Load: ';
$txt['debug_script_mem_load'] = 'Script Memory Usage: ';
$txt['debug_script_cpu_load'] = 'Script CPU Time (user/system): ';

// Video embedding
$txt['preview_image'] = 'Video Preview Image';
$txt['ctp_video'] = 'Click to play video, double click to load video';
$txt['hide_video'] = 'Show/Hide video';
$txt['youtube'] = 'YouTube video:';
$txt['vimeo'] = 'Vimeo video:';
$txt['dailymotion'] = 'Dailymotion video:';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (click to show/hide)';

$txt['ok_uppercase'] = 'OK';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Warning';

$txt['via'] = 'via';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
