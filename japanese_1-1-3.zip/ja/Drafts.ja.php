<?php
// Version: 1.1; Drafts

// profile
$txt['drafts_show'] = 'Show Drafts';
$txt['drafts_show_desc'] = 'これがあなたの保存している下書きです。ここから、下書きを編集して投稿したり、削除したりすることができます。';

// misc
$txt['drafts'] = '下書き';
$txt['draft_save'] = '下書きを保存する';
$txt['draft_save_note'] = 'This will save the text of your post, but it will not save attachments, poll or event information.';
$txt['draft_none'] = '下書きはありません。';
$txt['draft_edit'] = '下書きを編集する';
$txt['draft_load'] = 'Load drafts';
$txt['draft_hide'] = '下書きを隠す';
$txt['draft_delete'] = '下書きを削除する';
$txt['draft_days_ago'] = '%s days ago';
$txt['draft_retain'] = 'this will be retained for %s more days';
$txt['draft_remove'] = 'この下書きを除外する';
$txt['draft_remove_selected'] = '指定した全部の下書きを除外する';
$txt['draft_saved'] = 'The contents have been saved as a draft and will be accessible from the <a href="%1$s">Show Drafts area</a> of your profile.';
$txt['draft_pm_saved'] = 'The contents have been saved as a draft and will be accessible from the <a href="%1$s">Show Drafts area</a> of your message center.';

// Admin options
$txt['drafts_autosave_enabled'] = '自動的に下書きを保存する';
$txt['drafts_autosave_enabled_subnote'] = 'This will automatically save user drafts in the background on a given frequency.  The user must also have the proper permissions';
$txt['drafts_keep_days'] = '下書きを保存できる、最大の日数';
$txt['drafts_keep_days_subnote'] = 'Enter 0 to keep drafts indefinitely';
$txt['drafts_autosave_frequency'] = 'How often should drafts be autosaved?';
$txt['drafts_autosave_frequency_subnote'] = '30秒以上を指定できます';
$txt['drafts_pm_enabled'] = 'Enable the saving of PM drafts';
$txt['drafts_post_enabled'] = 'Enable the saving of Post drafts';
$txt['drafts_none'] = '表題がありません';
$txt['drafts_saved'] = 'ドラフトが保存されました';