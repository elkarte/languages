<?php
// Version: 1.1; Stats

$txt['most_online'] = 'Most Online';

$txt['stats_center'] = '統計センター';
$txt['general_stats'] = '一般の統計';
$txt['top_posters'] = '投稿数トップ10';
$txt['top_boards'] = 'Top 10 Boards';
$txt['forum_history'] = 'Forum History (using forum time offset)';
$txt['stats_new_topics'] = '新しいトピックス';
$txt['stats_new_posts'] = '新しい投稿';
$txt['stats_new_members'] = '新しいメンバー';
$txt['page_views'] = 'Page views';
$txt['top_topics_replies'] = 'トップ10の投稿（リプライの数による）';
$txt['top_topics_views'] = '投稿トップ10(閲覧数)';
$txt['yearly_summary'] = '年間の概要';
$txt['top_starters'] = 'Top Topic Starters';
$txt['most_time_online'] = 'Most Time Online';

$txt['average_members'] = 'Average registrations per day';
$txt['average_posts'] = '1日平均の投稿数';
$txt['average_topics'] = '1日平均のトピックスの数';
$txt['average_online'] = '1日平均利用者';
$txt['users_online'] = 'アクセスしているユーザー';
$txt['emails_sent'] = '1日平均メール数';
$txt['users_online_today'] = '今日の利用者';
$txt['num_hits'] = 'ページ閲覧総数';
$txt['average_hits'] = 'Average page views per day';

$txt['ssi_comment'] = 'コメント';
$txt['ssi_comments'] = 'comments';
$txt['ssi_write_comment'] = 'Write Comment';
$txt['ssi_no_guests'] = 'You cannot specify a board that doesn\'t allow guests.  Please check the board ID before trying again.';
$txt['xml_rss_desc'] = 'Live information from {forum_name}';