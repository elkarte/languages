<?php
// Version: 1.1; Maillist

// Email posting errors
$txt['error_locked'] = 'Bu konu kilitlenmiştir, ileti gönderemezsiniz';
$txt['error_locked_short'] = 'Kilitli Konu';
$txt['error_cant_start'] = 'Mevcut bölümde yeni bir konuyu başlatmaya yetkili değil';
$txt['error_cant_start_short'] = 'Yeni Konu Başlatılamıyor';
$txt['error_cant_reply'] = 'Cevap vermek için yetkili değil';
$txt['error_cant_reply_short'] = 'Off Limits Topic';
$txt['error_topic_gone'] = 'Konu bulunamadı - silinmiş veya birleştirilmiş olabilir.';
$txt['error_topic_gone_short'] = 'Silinen Konu';
$txt['error_not_find_member'] = 'E-posta adresiniz üye veritabanında bulunamadı, yalnızca üyeler ileti gönderebilir.';
$txt['error_not_find_member_short'] = 'Veritabanında e-posta kimliği bulunamadı';
$txt['error_key_sender_match'] = 'E-posta anahtarı geçerli iken anahtarı içeren e-posta adresine gönderilmedi. Mesajı alan aynı e-postayı yanıtlamalısınız';
$txt['error_key_sender_match_short'] = 'Anahtar Uyumsuzluğu';
$txt['error_not_find_entry'] = 'Bu e-postayı zaten yanıtladığınız anlaşılıyor. Yazınızı değiştirmeniz gerekiyorsa lütfen web arayüzünü kullanın, bu konuyu başka bir yanıtta buluyorsanız lütfen en son bildirime cevap verin.';
$txt['error_not_find_entry_short'] = 'Anahtarın Süresi Doldu';
$txt['error_pm_not_found'] = 'Yanıtladığınız kişisel ileti bulunamadı.';
$txt['error_pm_not_found_short'] = 'PM Missing';
$txt['error_pm_not_allowed'] = 'Kişisel ileti göndermek için izniniz yok!';
$txt['error_pm_not_allowed_short'] = 'Kişisel ileti için yetkili değil';
$txt['error_no_message'] = 'E-postada herhangi bir ileti bulamadık, ileti göndermek için bir ileti göndermelisin.';
$txt['error_no_message_short'] = 'Boş Mesaj';
$txt['error_no_subject'] = 'İletinizin konu başlığını yazmadınız.';
$txt['error_no_subject_short'] = 'Konusu Yok';
$txt['error_board_gone'] = 'İleti göndermeye çalıştığınız bölüm, sizin için sınırların dışında kaldı';
$txt['error_board_gone_short'] = 'Geçersiz veya Korumalı Bölüm';
$txt['error_missing_key'] = 'Yanıtta anahtarı bulamıyor. E-postaların kabul edilmesi için, geçerli bir bildirim e-postasına cevap gönderilmeleri ve cevapların bildirimin gönderildiği e-posta adresinden yapılması gerekir.';
$txt['error_missing_key_short'] = 'Eksik Anahtar';
$txt['error_found_spam'] = 'Uyarı: Postanız spam filtreniz tarafından potansiyel spam olarak sınıflandırılmış ve henüz yayınlanmamıştır.';
$txt['error_found_spam_short'] = 'Potansiyel Spam';
$txt['error_pm_not_find_entry'] = 'Bu kişisel iletiyi zaten yanıtladığınız anlaşılıyor. Başka bir yanıt vermeniz gerekiyorsa lütfen web arayüzünü kullanın veya başka bir yanıt gelene kadar bekleyin.';
$txt['error_pm_not_find_entry_short'] = 'Kişisel ileti Anahtarının Süresi Doldu';
$txt['error_not_find_board'] = 'Mevcut olmayan bir bölüme, potansiyel bir hack girişimine, yeni bir konu başlatmaya çalışıldı';
$txt['error_not_find_board_short'] = 'Böyle bir Bölüm yok';
$txt['error_no_pm_attach'] = '[Kişilsel iletiler dosya eklerini desteklenmiyor]';
$txt['error_no_attach'] = '[E-postalar dosya eklerini desteklenmiyor]';
$txt['error_in_maintenance_mode'] = 'E-posta, bakım modundayken alındı ve zamanında gönderilemedi';
$txt['error_in_maintenance_mode_short'] = 'Bakımda';
$txt['error_email_notenabled_short'] = 'Etkin değil';
$txt['error_email_notenabled'] = 'E-postayla gönder işlevi etkinleştirilmedi, e-posta işlenemedi';
$txt['error_permission'] = 'Kullanıcının,  bu bölümde e-posta ile ileti gönderme izni yok';
$txt['error_permission_short'] = 'İzin yok';
$txt['error_bounced'] = 'İleti hedef posta sunucusu tarafından reddedildi';
$txt['error_bounced_short'] = 'İleti teslim edilemedi';

// Maillist page items
$txt['ml_admin_configuration'] = 'E-posta Listesi Yapılandırması';
$txt['ml_configuration_desc'] = 'Bu bölüm, e-postayla ilgili etkinlikler aracılığıyla tüm gönderimler için bazı tercihler belirlemenize olanak tanır';
$txt['ml_emailerror_none'] = 'Denetim gerektiren başarısız bir giriş yok';
$txt['ml_emailerror'] = 'Başarısız E-postalar';
$txt['ml_emailsettings'] = 'Ayarlar';

// Settings tab
$txt['maillist_enabled'] = 'E-posta Liste İşlevlerini Etkinleştir (ana açık/kapalı ayarı)';
$txt['pbe_post_enabled'] = 'E-postayla foruma ileti göndermeye izin ver';
$txt['pbe_pm_enabled'] = 'Kişisel ileti\'lere e-postayla cevap vermeye izin ver';
$txt['pbe_no_mod_notices'] = 'Moderasyon bildirimlerini kapat';
$txt['pbe_no_mod_notices_desc'] = 'Taşınan, kilitli, silinmiş, birleştirilmiş vb. iletiler için bildirim göndermeyin. ';
$txt['pbe_bounce_detect'] = 'Turn on automatic bounce detection';
$txt['pbe_bounce_detect_desc'] = 'Attempt to identify mail bounces and disable further notifications';
$txt['pbe_bounce_record'] = 'Record bounce messages in failed mail after auto processing';
$txt['pbe_bounce_record_desc'] = 'Bounce messages will always be recorded if Bounce Detection is disabled';

$txt['saved'] = 'Bilgi Kaydedildi';

// General Sending Settings
$txt['maillist_outbound'] = 'Genel Gönderi Ayarları';
$txt['maillist_outbound_desc'] = 'Gönderilen e-postaların kullanıcıya nasıl göründüğünü ve bir yanıtın nereye gönderileceğini değiştirmek için bu ayarları kullanın.';
$txt['maillist_group_mode'] = 'Grup e-posta listesi modunu etkinleştir';
$txt['maillist_digest_enabled'] = 'Enable enhanced daily digest (provides topic snips in the digest)';
$txt['maillist_sitename'] = 'E-posta için kullanılacak Site Adı (e-posta adresi değil)';
$txt['maillist_sitename_desc'] = 'Bu, e-posta adresinin adıdır, kullanıcılara tanıdık gelen bir şey, bu konu satırı da dahil olmak üzere, giden e-postanın çeşitli alanlarında görünür - [Site Adı] konusu';
$txt['maillist_sitename_post'] = 'Örneğin. &lt;<strong>Site Adı</ strong>&gt; e-posta@alanadiniz.com';
$txt['maillist_sitename_address'] = 'Yanıtla  Gönderen e-posta adresinden';
$txt['maillist_sitename_address_desc'] = 'Mesajlara cevap veren e-posta adresi gönderilecektir. Boş ise bildirimde webmaster (varsa)  kullanılacaktır.';
$txt['maillist_sitename_regards'] = 'E-posta "imzası"';
$txt['maillist_sitename_regards_desc'] = 'Giden e-postaların sonuna ne koyulacak, "Saygılarımızla, Site Adı Ekibi" gibi ';
$txt['maillist_sitename_address_post'] = 'Örneğin. e-posta@alanadiniz.com';
$txt['maillist_sitename_help'] = 'Yardım E-posta adresi';
$txt['maillist_sitename_help_desc'] = 'Giden e-postanın spam olarak işaretlenmesini önlemek için "Liste Sahibi" başlığı kullanılır.';
$txt['maillist_sitename_help_post'] = 'Örneğin.  yardim@alanadiniz.com';
$txt['maillist_mail_from'] = 'Bildirim e-posta adresi';
$txt['maillist_mail_from_desc'] = 'Şifre hatırlatıcıları, bildirimler vb. Için kullanılan e-posta adresi. Boş bırakılırsa web yöneticisi adresi kullanılır (varsayılan ayardır)';
$txt['maillist_mail_from_post'] = 'Örneğin. yanitlamayin@alanadiniz.com';

// Imap settings
$txt['maillist_imap'] = 'IMAP Ayarları';
$txt['maillist_imap_host'] = 'E-Posta Kutusu Sunucu Adı';
$txt['maillist_imap_host_desc'] = 'Bir posta sunucusu ana makine adı ve isteğe bağlı: port numarası girin. Örneğin. Imap.gmail.com veya imap.gmail.com:993';
$txt['maillist_imap_mailbox'] = 'E-Posta Kutusu  Adı';
$txt['maillist_imap_mailbox_desc'] = 'Sunucuda bir posta kutusu adı girin. Örneğin: GELENLER';
$txt['maillist_imap_uid'] = 'E-Posta Kutusu Kullanıcı Adı';
$txt['maillist_imap_uid_desc'] = 'E-Posta kutusuna erişim için kullanıcı adı.';
$txt['maillist_imap_pass'] = 'E-Posta Kutusu Şifresi';
$txt['maillist_imap_pass_desc'] = 'E-Posta kutusuna giriş yapmak için şifre.';
$txt['maillist_imap_connection'] = 'E-Posta Kutusu Bağlantısı';
$txt['maillist_imap_connection_desc'] = 'Kullanılacak bağlantı türü, IMAP veya POP3 (şifrelenmemiş, TLS veya SSL modunda).';
$txt['maillist_imap_unsecure'] = 'IMAP';
$txt['maillist_pop3_unsecure'] = 'POP3';
$txt['maillist_imap_tls'] = 'IMAP/TLS';
$txt['maillist_imap_ssl'] = 'IMAP/SSL';
$txt['maillist_pop3_tls'] = 'POP3/TLS';
$txt['maillist_pop3_ssl'] = 'POP3/SSL';
$txt['maillist_imap_delete'] = 'İletileri Sil';
$txt['maillist_imap_delete_desc'] = 'Alınan ve işlenen posta kutusu iletilerini kaldırmayı deneyin.';
$txt['maillist_imap_reason'] = 'İletileri foruma yönlendirmeyi planlıyorsanız, aşağıdakiler BOŞ bırakılmalıdır (önerilir).';
$txt['maillist_imap_missing'] = 'IMAP işlevleri sisteminize kurulu değil, herhangi bir ayar mevcut değil';
$txt['maillist_imap_cron'] = 'Sahte-Cron (zamanlanmış görev)';
$txt['maillist_imap_cron_desc'] = 'Sisteminizde bir Cron işi çalıştıramazsanız, bunun yerine bir ElkArte zamanlanmış görev olarak çalıştırın.';
$txt['scheduled_task_desc_pbeIMAP'] = 'Runs the post by email IMAP mailbox program to read new email from the designated mailbox';

// General Receiving Settings
$txt['maillist_inbound'] = 'Genel Alıcı Ayarları';
$txt['maillist_inbound_desc'] = 'Yeni bir konu e-postası alındığında sistemin gerçekleştireceği eylemleri belirlemek için bu ayarları kullanın. Bu, bildirimlerimize verilen yanıtları etkilemez';
$txt['maillist_newtopic_change'] = 'Yanıt konusunu değiştirerek yeni bir konunun başlatılmasına izin ver';
$txt['maillist_newtopic_needsapproval'] = 'Yeni Konunun onaylanması gerekir';
$txt['maillist_newtopic_needsapproval_desc'] = 'E-postayla gönderilen tüm yeni konuların, e-posta sahteciliğini önlemek için gönderilmeden önce onaylanmasını gerekir';
$txt['recommended'] = 'Bu önerilir';
$txt['experimental'] = 'Bu işlevsellik deneysel';
$txt['receiving_address'] = 'Alıcı e-posta adresleri';
$txt['receiving_board'] = 'Board to post new messages to';
$txt['reply_add_more'] = 'Başka Bir Adres Ekle';
$txt['receiving_address_desc'] = 'Alınan e-postanın gönderileceği yere e-posta adresinin bir listesini girin. Bu, belirli bir bölümde yeni bir başlık başlatmak için gereklidir, üyeler bu e-posta adresine bir e-posta göndermelidir ve ilgili bölümde yayınlanır. Varolan bir öğeyi kaldırmak için, e-posta adresini temizleyin ve kaydedin.';
$txt['email_not_valid'] = 'E-posta adresi (%s) geçerli değil';
$txt['board_not_valid'] = 'Geçersiz bir bölüm kimliği girdiniz (%d)';

// Other settings
$txt['misc'] = 'Diğer Ayarlar';
$txt['maillist_allow_attachments'] = 'E-posta eki eklerinin gönderilmesine izin verin (Kişisel ileti\'ler için geçerli değildir)';
$txt['maillist_key_active'] = 'Verileri veritabanında etkin kılmak için geçen gün sayısı';
$txt['maillist_key_active_desc'] = 'i.e. How long after a notification is sent are you willing to accept a response';
$txt['maillist_sig_keys'] = 'Words that signify the start of someones signature';
$txt['maillist_sig_keys_desc'] = 'Separate words with a | character, suggested to use "best|regard|thank". Lines starting with these will be triggered as the start of a signature line';
$txt['maillist_leftover_remove'] = 'E-postalardan ayrılan satırlar';
$txt['maillist_leftover_remove_desc'] = 'Separate words with a | character suggested to use "To: |Re: |Sent: |Subject: |Date: |From: ". Most things get removed by the parser but some things end up in quotes.  Don\'t add to this unless you know what you are doing.';
$txt['maillist_short_line'] = 'Kısa satır uzunluğu, e-postaları açmak için kullanılır';
$txt['maillist_short_line_desc'] = 'Varsayılan değerden değiştirmek olağandışı sonuçlara neden olabilir, dikkatle değiştirin';

// Failed log actions
$txt['approved'] = 'E-posta onaylandı ve gönderildi';
$txt['error_approved'] = 'Bu e-postayı onaylamaya çalışırken bir hata oluştu';
$txt['id'] = '#';
$txt['error'] = 'Hata';
$txt['key'] = 'Anahtar';
$txt['message_id'] = 'İleti';
$txt['message_type'] = 'Tür';
$txt['message_action'] = 'İşlemler';
$txt['emailerror_title'] = 'Başarısız E-posta Günlüğü';
$txt['show_notice'] = 'E-posta Ayrıntıları';
$txt['private'] = 'Özel';
$txt['show_notice_text'] = 'Post text';
$txt['noaccess'] = 'Özel Mesajlar incelenemez';
$txt['badid'] = 'Geçersiz veya eksik e-posta kimliği';
$txt['delete_warning'] = 'Bu girdiyi silmek istediğinizden emin misiniz?';
$txt['pm_approve_warning'] = 'Approve this personal message with CAUTION!
The PM being replied to has been REMOVED.
The system attempts to find others in that conversation but the results are not 100% accurate.
If in doubt, its better to bounce!';
$txt['filter_delete_warning'] = 'Bu filtreyi kaldırmak istediğinizden emin misiniz?';
$txt['parser_delete_warning'] = 'Bu ayrıştırıcıyı kaldırmak istediğinizden emin misiniz?';
$txt['bounce'] = 'Bounce';
$txt['heading'] = 'Bu, başarısız olan e-posta gönderilerinin listesidir; buradan, göndereni onaylamayı (mümkünse) , silmeyi veya geri dönmeyi seçebilirsiniz.';
$txt['cant_approve'] = 'Hata, öğenin onaylanmasına izin vermiyor (otomatik tamir edemiyor)';
$txt['email_attachments'] = '[Bu iletide %d e-posta eki var]';
$txt['email_failure'] = 'Başarısız olma Nedeni';

// Filters
$txt['filters'] = 'E-posta Filtreleri';
$txt['add_filter'] = 'Filtre Ekle';
$txt['sort_filter'] = 'Filtreleri Sırala';
$txt['edit_filter'] = 'Varolan Filtreyi Düzenle';
$txt['no_filters'] = 'Hiçbir filtre tanımlamadınız';
$txt['error_no_filter'] = 'Belirtilen filtre bulunamadı/yüklenemedi';
$txt['regex_invalid'] = 'Regex geçerli değil';
$txt['filter_to'] = 'Değiştirme Metni';
$txt['filter_to_desc'] = 'Bulunan metni şu şekilde değiştirin';
$txt['filter_from'] = 'Metin Ara';
$txt['filter_from_desc'] = 'Aramak istediğiniz metni girin';
$txt['filter_type'] = 'Tür';
$txt['filter_type_desc'] = 'Standart, tam aşamayı bulacak ve değiştirme alanındaki metinle değiştirecektir. Düzenli İfade, Standart\'ın joker karakteri olup PCRE formatında sağlanmalıdır.';
$txt['filter_name'] = 'İsim';
$txt['filter_name_desc'] = 'İsteğe bağlı olarak, bu filtrenin ne yaptığını hatırlamanıza yardımcı olacak bir ad girin';
$txt['filters_title'] = 'Bu alandan e-posta filtreleri ekleyebilir, düzenleyebilir veya kaldırabilirsiniz. Filtreler bir yanıtta belirli bir metni arar ve daha sonra bunu seçtiğiniz metinle değiştirir.';
$txt['filter_invalid'] = 'Tanım geçerli değil ve kaydedilemedi';
$txt['error_no_id_filter'] = 'Filtre kimliği geçerli değil';
$txt['saved_filter'] = 'Filtre başarıyla kaydedildi';
$txt['filter_sort_description'] = 'Filtreler, gösterilen sırayla yürütülür, önce regex gruplanır, daha sonra standart gruplandırma, bu sürüklemeyi değiştirmek ve bir öğeyi listede yeni bir yere bırakmaktır (ancak standart bir filtrenin normal bir filtreden önce çalıştırılmasını zorlayamazsınız).';

// Parsers
$txt['saved_parser'] = 'Ayrıştırıcı başarıyla kaydedildi';
$txt['parser_reordered'] = 'Alanlar başarıyla yeniden düzenlendi';
$txt['error_no_id_parser'] = 'Ayrıştırıcı kimliği geçerli değil';
$txt['add_parser'] = 'Ayrıştırıcı ekle';
$txt['sort_parser'] = 'Ayrıştırıcıları Sırala';
$txt['edit_parser'] = 'Varolan Ayrıştırıcıyı Düzenle';
$txt['parsers'] = 'E-posta Ayrıştırıcıları';
$txt['parser_from'] = 'Terimi orijinal e-postada ara';
$txt['parser_from_desc'] = 'Orijinal e-postanın başlangıç dönemini girin, sistem bu noktada yalnızca yeni mesaj bırakarak mesajı keser (mümkünse). Normal ifade kullanılıyorsa, düzgün şekilde sınırlandırılmış olmalıdır';
$txt['parser_type'] = 'Tür';
$txt['parser_type_desc'] = 'Standart, tam aşamayı bulacak ve e-postayı o noktada kesecektir. Normal İfade standardının joker karakteri olup PCRE formatında sağlanmalıdır.';
$txt['parser_name'] = 'İsim';
$txt['parser_name_desc'] = 'İsteğe bağlı olarak bu ayrıştırıcının hangi e-posta istemcisini hatırlamanıza yardımcı olacak bir ad girin';
$txt['no_parsers'] = 'Herhangi bir ayrıştırıcı tanımlamadınız';
$txt['parsers_title'] = 'Bu alandan e-posta ayrıştırıcıları ekleyebilir, düzenleyebilir veya kaldırabilirsiniz. Ayrıştırıcılar belirli satırları arar ve orjinal ileti yanıtını kaldırmak için bu noktada ileti keserler. Bir ayrıştırıcı metin oluşturmazsa (ör. Orijinal iletinin altında bir yanıt varsa veya karıştırılmışsa), atlanır';
$txt['option_standard'] = 'Standart';
$txt['option_regex'] = 'Düzenli ifade';
$txt['parser_sort_description'] = 'Ayrıştırıcılar, gösterilen sırada sürüklenir ve bir öğeyi listede yeni bir konuma bırakmak için çalıştırılır.';

// Bounce
$txt['bounce_subject'] = 'Başarısız';
$txt['bounce_error'] = 'Hata';
$txt['bounce_title'] = 'Bounced Email Creator';
$txt['bounce_notify_subject'] = 'Bounce Notification Subject';
$txt['bounce_notify'] = 'Send a Bounce Notification';
$txt['bounce_notify_template'] = 'Şablon seçin';
$txt['bounce_notify_body'] = 'Bounce Notification Message';
$txt['bounce_issue'] = 'Send Bounce';
$txt['bad_bounce'] = 'The bounce message and/or subject is blank and can not be sent';

// Subject tags
$txt['RE:'] = 'YNT:';
$txt['FW:'] = 'FW:';
$txt['FWD:'] = 'FWD:';
$txt['SUBJECT:'] = 'KONU:';

// Quote strings
$txt['email_wrote'] = 'Wrote';
$txt['email_quoting'] = 'Alıntı';
$txt['email_quotefrom'] = 'Alıntı yapılan';
$txt['email_on'] = 'On';
$txt['email_at'] = '-';

// Our digest strings for the digest "template"
$txt['digest_preview'] = "\n     <*> Topic Summary:\n     ";
$txt['digest_see_full'] = "\n\n     <*> See the full Topic at the following link:\n     <*> ";
$txt['digest_reply_preview'] = "\n     <*> Latest Reply:\n     ";
$txt['digest_unread_reply_link'] = "\n\n     <*> See all your unread replies to this topic at the following link:\n     <*> ";
$txt['message_attachments'] = '<*> Bu ileti ile ilişkili %d resim/dosya var.
<*> Görmek için lütfen bağlantıyı takip edin: %s';

// Help
$txt['maillist_help'] = 'For help in setting up the maillist feature, please visit the maillist section on the <a href="https://github.com/elkarte/Elkarte/wiki/Posting-by-Email-Feature" target="_blank" class="new_win">ElkArte Wiki</a>';

// Email bounce templates
$txt['ml_bounce_templates_title'] = 'Custom bounce email templates';
$txt['ml_bounce_templates_none'] = 'No custom bounce templates have been created yet';
$txt['ml_bounce_templates_time'] = 'Oluşturulma Zamanı';
$txt['ml_bounce_templates_name'] = 'Şablon';
$txt['ml_bounce_templates_creator'] = 'Oluşturan';
$txt['ml_bounce_template_add'] = 'Şablon Ekle';
$txt['ml_bounce_template_modify'] = 'Şablonu Düzenle';
$txt['ml_bounce_template_delete'] = 'Seçilileri Sil';
$txt['ml_bounce_template_delete_confirm'] = 'Seçili şablonları kaldırmak istediğinizden emin misiniz?';
$txt['ml_bounce_body'] = 'İleti';
$txt['ml_bounce_template_subject_default'] = 'Başlık';
$txt['ml_bounce_template_desc'] = 'Şablonun ayrıntılarını yazmak için bu sayfayı kullanın. E-postanın konusunun şablonun parçası olmadığını unutmayın.';
$txt['ml_bounce_template_title'] = 'Şablon Başlığı';
$txt['ml_bounce_template_title_desc'] = 'Şablon seçim listesinde kullanılacak bir ad';
$txt['ml_bounce_template_body'] = 'Şablon İçeriği';
$txt['ml_bounce_template_body_desc'] = 'Geri dönen mesajın içeriği. Bu şablonda aşağıdaki kısayolları kullanabileceğinizi unutmayın: <ul><li>{MEMBER} - Üye Adı.</li><li> {FORUMNAME} - Forum Adı. </li><li>{FORUMNAMESHORT} - Sitenin kısa adı</li><li>{ERROR} - E-postanın ürettiği hata. </li><li>{SUBJECT} - Başarısız olan e-postanın konusu</li><li> {SCRIPTURL} - Forumun web adresi. </li><li>{EMAILREGARDS} - Maillist e-posta imzası. </li><li>{REGARDS} - Standart forum imzası.</li></ul>';
$txt['ml_bounce_template_personal'] = 'Kişisel Şablon';
$txt['ml_bounce_template_personal_desc'] = 'Bu seçeneği seçerseniz, yalnızca bu şablonu görebilir, düzenleyebilir ve kullanabilirsiniz, aksi takdirde tüm yöneticiler kullanabilecektir.';
$txt['ml_bounce_template_error_no_title'] = 'Açıklayıcı bir başlık belirlemelisiniz.';
$txt['ml_bounce_template_error_no_body'] = 'You must set a email template body.';

$txt['ml_bounce'] = 'E-posta Tasarımları';
$txt['ml_bounce_description'] = 'From this section you can add and modify the email bounce templates used when rejecting a post by email.';
$txt['ml_bounce_title'] = 'Bounce';
$txt['ml_bounce_subject'] = 'E-postanız gönderilemedi';
$txt['ml_bounce_body'] = 'İleti';
$txt['ml_inform_title'] = 'Haberdar Et';
$txt['ml_inform_subject'] = 'E-postanızla ilgili bir sorun oluştu';
$txt['ml_inform_body'] = '{MEMBER},

{FORUMNAMESHORT} adresine gönderdiğiniz e-postada, gönderiminde gecikmelere neden olan bir hata oluştu. Hata oluştu: {ERROR}

Gelecekteki gecikmelerin önüne geçmek için bu hatayı düzeltmelisiniz.

{EMAILREGARDS}';
$txt['ml_bounce_template_body_default'] = 'Hi. This is the post-by-email program at {FORUMNAMESHORT}

I\'m afraid I wasn\'t able to deliver and/or post your message with the title of: {SUBJECT}.

The error I received while trying was: {ERROR}

This is a permanent error; I\'ve given up. Sorry it didn\'t work out.

{EMAILREGARDS}'; // redundant?