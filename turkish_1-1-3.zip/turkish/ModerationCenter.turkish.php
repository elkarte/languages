<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Moderasyon Merkezi';
$txt['mc_main'] = 'Genel';
$txt['mc_logs'] = 'Kayıtlar';
$txt['mc_posts'] = 'İleti';
$txt['mc_groups'] = 'Üyeler ve gruplar';

$txt['mc_view_groups'] = 'Grupları Görüntüle';

$txt['mc_description'] = '<strong>Hoşgeldiniz, %1$s!</strong><br /> Burası &quot;Moderasyon Merkezinizdir&quot;. Burada forum yöneticisinin size vermiş olduğu tüm moderasyon görevlerini gerçekleştirebilirsiniz. Bu ana sayfa toplulukta gerçekleşen son olayların bir özetini içerir.  <a href="%2$s"> buraya  tıklayarak  </a> görünümü kişiselleştirebilirsiniz.';
$txt['mc_group_requests'] = 'Grup Talepleri';
$txt['mc_member_requests'] = 'Üye Talepleri';
$txt['mc_unapproved_posts'] = 'Onaylanmamış İletiler';
$txt['mc_watched_users'] = 'Son İzlenen Üyeler';
$txt['mc_watched_topics'] = 'En Son İzlemeye Alınmış Konular';
$txt['mc_scratch_board'] = 'Moderasyon Tahtası';
$txt['mc_latest_news'] = 'Son Duyurular';
$txt['mc_recent_reports'] = 'Son Konu Raporları';
$txt['mc_warnings'] = 'Uyarılar';
$txt['mc_notes'] = 'Moderatör Sohbeti';
$txt['mc_required'] = 'Onay Gereken Öğeler';
$txt['mc_attachments'] = 'Onay gerektiren ekler';
$txt['mc_emailmod'] = 'Onay gerektiren E-posta gönderileri';
$txt['mc_topics'] = 'Onay bekleyen konular';
$txt['mc_posts'] = 'İleti';
$txt['mc_groupreq'] = 'Onay bekleyen grup istekleri';
$txt['mc_memberreq'] = 'Onay bekleyen üyeler';
$txt['mc_reports'] = 'Rapor edilmiş iletiler için onay gerekli';
$txt['mc_pm_reports'] = 'Rapor edilen kişisel iletiler';

$txt['mc_cannot_connect_sm'] = 'ElkArte\'de bulunan Son Haberler dosyasına bağlanılamadı.';

$txt['mc_recent_reports_none'] = 'Yeni rapor bulunmamaktadır';
$txt['mc_watched_users_none'] = 'Herhangi bir izleme bulunmamaktadır.';
$txt['mc_group_requests_none'] = 'Herhangi bir grup üyeliği talebi bulunmamaktadır.';

$txt['mc_seen'] = '%1$s son görüldü %2$s ';
$txt['mc_seen_never'] = '%1$s asla görülmedi';
$txt['mc_groupr_by'] = 'gönderen';

$txt['mc_reported_posts_desc'] = 'Bu bölümde topluluk tarafından gönderilmiş tüm ileti raporlarını görüntüleyebilirsiniz.';
$txt['mc_reported_pms_desc'] = 'Burada topluluk üyeleri tarafından gönderilen tüm kişisel ileti raporlarını inceleyebilirsiniz.';
$txt['mc_reportedp_active'] = 'Aktif Raporlar';
$txt['mc_reportedp_closed'] = 'Eski Raporlar';
$txt['mc_reportedp_by'] = 'gönderen';
$txt['mc_reportedp_reported_by'] = 'Rapor Eden';
$txt['mc_reportedp_last_reported'] = 'Son Rapor';
$txt['mc_reportedp_none_found'] = 'Hiç Rapor Bulunamadı';

$txt['mc_reportedp_details'] = 'Detaylar';
$txt['mc_reportedp_close'] = 'Kapalı';
$txt['mc_reportedp_open'] = 'Açık';
$txt['mc_reportedp_ignore'] = 'Yoksay';
$txt['mc_reportedp_unignore'] = 'Yoksay-ma';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Bu ileti hakkındaki raporları yoksaymak istediğinize emin misiniz?

Bu rapor, forumun tüm moderatörleri için  kapatılacaktır.';
$txt['mc_reportedp_close_selected'] = 'Seçilileri Kapat';

$txt['mc_groupr_group'] = 'Üye Grupları';
$txt['mc_groupr_member'] = 'Üye';
$txt['mc_groupr_reason'] = 'Sebep';
$txt['mc_groupr_none_found'] = 'Herhangi bir grup üyeliği talebi bulunmamaktadır.';
$txt['mc_groupr_submit'] = 'Gönder';
$txt['mc_groupr_reason_desc'] = '%1$s\'nin, &quot;%2$s&quot; grubuna katılma isteğinin reddedilme sebebi';
$txt['mc_groups_reason_title'] = 'Reddedilme Sebebi';
$txt['with_selected'] = 'Seçili';
$txt['mc_groupr_approve'] = 'Talebi Onayla';
$txt['mc_groupr_reject'] = 'Talebi Reddet (Sebep göstermeden)';
$txt['mc_groupr_reject_w_reason'] = 'Sebep Göstererek Talebi Reddet';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Bunu yapmak istediğinize emin misiniz?';

$txt['mc_unapproved_attachments_none_found'] = 'Onaylanmamış eklenti bulunamadı!';
$txt['mc_unapproved_attachments_desc'] = 'Buradan moderatör onayı bekleyen herhangi eki onaylayabilir veya silebilirsiniz.';
$txt['mc_unapproved_replies_none_found'] = 'Onaylanmamış ileti bulunamadı!';
$txt['mc_unapproved_topics_none_found'] = 'Onaylanmamış konu bulunamadı!';
$txt['mc_unapproved_posts_desc'] = 'Bu bölümü kullanarak moderasyon beklemekte olan iletileri onaylayabilir veya kaldırabilirsiniz.';
$txt['mc_unapproved_replies'] = 'Yanıtlar';
$txt['mc_unapproved_topics'] = 'Konular';
$txt['mc_unapproved_by'] = 'gönderen';
$txt['mc_unapproved_sure'] = 'Bunu yapmak istediğinize emin misiniz?';
$txt['mc_unapproved_attach_name'] = 'Dosya Adı';
$txt['mc_unapproved_attach_size'] = 'Dosya Boyutu';
$txt['mc_unapproved_attach_poster'] = 'Gönderen';
$txt['mc_viewmodreport'] = '%1$s için %2$s tarafından yazılmış moderasyon raporu';
$txt['mc_modreport_summary'] = 'Bu ileti ile ilgili %1$d rapor(lar)  var. Son rapor %2$s idi.';
$txt['mc_view_pmreport'] = 'Kişisel ileti için %1$s tarafından gönderilen rapor';
$txt['mc_pmreport_summary'] = 'Bu Kişisel ileti ile ilgili %1$d rapor(lar)  var. Son rapor %2$s idi.';
$txt['mc_modreport_whoreported_title'] = 'Bu iletileri rapor eden üyeler';
$txt['mc_modreport_whoreported_data'] = '%1$s tarafından %2$s\'de bildirildi. Mesaj Aşağıdadırr:';
$txt['mc_modreport_modactions'] = 'Diğer moderatörlerin yaptığı işlemler';
$txt['mc_modreport_mod_comments'] = 'Moderatör Yorumları';
$txt['mc_modreport_no_mod_comment'] = 'Şu anda herhangi bir moderatör yorumu bulunmamaktadır';
$txt['mc_modreport_add_mod_comment'] = 'Yorum Ekle';

$txt['show_notice'] = 'Bilgilendirme Metni';
$txt['show_notice_subject'] = 'Konu';
$txt['show_notice_text'] = 'Metin';

$txt['mc_watched_users_title'] = 'İzlenen Üyeler';
$txt['mc_watched_users_desc'] = 'Bu bölümü kullanarak, moderasyon ekibi tarafından &quot;izlemeye alınmış&quot; tüm üyeleri görüntüleyebilirsiniz.';
$txt['mc_watched_users_post'] = 'İletiye Göre Görüntüle';
$txt['mc_watched_users_warning'] = 'Uyarı Seviyesi';
$txt['mc_watched_users_last_login'] = 'Son Giriş';
$txt['mc_watched_users_last_post'] = 'Son İleti';
$txt['mc_watched_users_no_posts'] = 'İzlenen kullanıcılar tarafından gönderilmiş herhangi bir ileti yok.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Bu iletiyi silmek istediğinize emin misiniz?';
$txt['mc_watched_users_delete_posts'] = 'Bu iletileri silmek istediğinize emin misiniz?';
$txt['mc_watched_users_posted'] = 'Tarih';
$txt['mc_watched_users_member'] = 'Üye';

$txt['mc_warnings_description'] = 'Bu bölümü kullanarak üyelere verilen uyarıları görebilir, üyelere gönderilecek uyarılar için şablonlar hazırlayabilirsiniz.';
$txt['mc_warning_log'] = 'Uyarı Günlüğü';
$txt['mc_warning_templates'] = 'Şablonlar';
$txt['mc_warning_log_title'] = 'Uyarı Günlüğü Görüntüleniyor';
$txt['mc_warning_templates_title'] = 'Kişisel Uyarı Şablonları';

$txt['mc_warnings_none'] = 'Hiçbir uyarı almamış';
$txt['mc_warnings_recipient'] = 'Alıcı';

$txt['mc_warning_templates_none'] = 'Herhangi bir uyarı şablonu oluşturulmamış';
$txt['mc_warning_templates_time'] = 'Oluşturulma Zamanı';
$txt['mc_warning_templates_name'] = 'Şablon';
$txt['mc_warning_templates_creator'] = 'Oluşturan';
$txt['mc_warning_template_add'] = 'Şablon Ekle';
$txt['mc_warning_template_modify'] = 'Şablonu Düzenle';
$txt['mc_warning_template_delete'] = 'Seçilileri Sil';
$txt['mc_warning_template_delete_confirm'] = 'Seçili şablonları kaldırmak istediğinizden emin misiniz?';

$txt['mc_warning_template_desc'] = 'Bu sayfayı şablonun detaylarını girmek için kullanabilirsiniz. E-posta\'nın başlığı şablonun bir parçası değildir. Eğer bilgilendirme kişisel ileti olarak gönderilecekse şablon içerisinde BBC kullanabilirsiniz. Eğer {MESSAGE} değişkenini kullanırsanız jenerik uyarılarda (yani bir postayla bağlantılı olmayan bir uyarı)  bu şablon çalışmayacaktır.';
$txt['mc_warning_template_title'] = 'Şablon Başlığı';
$txt['mc_warning_template_body_desc'] = 'Bildirim mesajının içeriği. Bu şablonda aşağıdaki kısayolları kullanabilirsiniz.<ul> <li> {MEMBER} - Üye Adı. </li> <li>{MESSAGE} - rapor edilen ileti  bağlantısı. (Uygulanabilir ise)</li> <li> {FORUMNAME} - Forum Adı. </li> <li>{SCRIPTURL} - Forumun Web adresi.</li> <li>{REGARDS} - Standart e-posta imzası.</li> </ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

Uygunsuz davranışlarınız nedeniyle uyarı almış bulunuyorsunuz. 

Lütfen ilgili davranışlarınıza son veriniz ve forum kurallarınıza uyunuz, aksi takdirde daha büyük yaptırımlarda bulunulacaktır.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Kişisel Şablon';
$txt['mc_warning_template_personal_desc'] = 'Bu seçeneği seçerseniz, bu şablonu sadece siz görebilecek, düzenleyebilecek ve kullanabileceksiniz. Eğer seçilmezse bu şablon tüm moderatörlerin kullanımına açık olacaktır.';
$txt['mc_warning_template_error_no_title'] = 'Başlık koymalısın.';
$txt['mc_warning_template_error_no_body'] = 'Bir bildirim içeriği girmelisiniz.';

$txt['mc_settings'] = 'Ayarları Değiştir';
$txt['mc_prefs_title'] = 'Moderasyon Seçenekleri';
$txt['mc_prefs_desc'] = 'Bu bölüm kullanarak moderasyon ile ilgili kişisel bazı temel ayarları değiştirebilrisiniz.';
$txt['mc_prefs_homepage'] = 'Moderasyon ana sayfasında gösterilecek öğeler';
$txt['mc_prefs_latest_news'] = 'ElkArte Duyurular';
$txt['mc_prefs_show_reports'] = 'Başlıkta açık rapor sayısı gösterilsin';
$txt['mc_prefs_notify_report'] = 'Yeni raporlarla ilgili bilgilendirme';
$txt['mc_prefs_notify_report_never'] = 'Hiç';
$txt['mc_prefs_notify_report_moderator'] = 'Moderatörü olduğum bir bölüm ise';
$txt['mc_prefs_notify_report_always'] = 'Her zaman';
$txt['mc_prefs_notify_approval'] = 'Onay bekleyen öğelerle ilgili bilgilendir';
$txt['mc_logoff'] = 'Moderatör oturumunu sonlandır';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Yeni not ekle';
$txt['mc_add_note'] = 'Ekle';