<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Bölümler';
$txt['admin_back_to'] = 'Admin paneline geri dön';
$txt['admin_users'] = 'Üyeler';
$txt['admin_newsletters'] = 'Bültenler';
$txt['include_these'] = 'Dahil edilecek üyeler';
$txt['exclude_these'] = 'Hariç tutulacak üyeler';
$txt['admin_newsletters_select_groups'] = 'Dahil edilecek gruplar';
$txt['admin_newsletters_exclude_groups'] = 'Hariç tutulacak gruplar';
$txt['admin_edit_news'] = 'Haberler';
$txt['admin_groups'] = 'Üye grupları';
$txt['admin_members'] = 'Üyeleri Yönet';
$txt['admin_members_list'] = 'Aşağıda foruma kayıtlı tüm üyelerin listesi bulunmaktadır.';
$txt['admin_next'] = 'Sonraki';
$txt['admin_censored_words'] = 'Sansürlü Kelimeler';
$txt['admin_censored_where'] = 'Sansürlenecek kelimeyi sol kutuya, yerine kullanılacak olanı ise sağ kutuya yazınız. Sansürlenmesini istediğiniz kelimeleri aşağıya girebilirsiniz, işiniz bittiğinde Kaydet\'i tıklayın. Silmek için kutulardaki kelimeleri temizleyip kaydetmeniz yeterlidir. Kaydetmeden önce \'Başka kelime ekle\' düğmesini tıklayarak birden çok giriş yapılabilir.';
$txt['admin_censored_desc'] = 'Forumların yapısı gereği belli kelimelerin forumda kullanılmasını engellemek isteyebilirsiniz. Bu amaçla sansürlenmesini istediğiniz kelimeleri aşağıya girebilirsiniz.<br />Silmek için kutulardaki kelimeleri temizlemeniz yeterlidir.';
$txt['admin_reserved_names'] = 'Ayrılmış İsimler';
$txt['admin_template_edit'] = 'Forum Temasını Düzenle';
$txt['admin_modifications'] = 'Eklenti Ayarları';
$txt['admin_security_moderation'] = 'Güvenlik ve Moderasyon';
$txt['admin_server_settings'] = 'Sunucu Ayarları';
$txt['admin_reserved_set'] = 'Ayrılmış İsimleri Belirt';
$txt['admin_reserved_line'] = 'Bir satırda sadece bir isim bulunabilir.';
$txt['admin_basic_settings'] = 'Bu sayfa forumunuzun temel ayarlarını değiştirmenizi sağlar. Bu ayarları yaparken dikkatli olun çünkü yapacağınız yanlış bir ayar forum\'un çalışmamasına neden olabilir.';
$txt['admin_maintain'] = 'Bakım Modunu Etkinleştir';
$txt['admin_title'] = 'Forum Başlığı';
$txt['admin_url'] = 'Forum URL\'si';
$txt['cookie_name'] = 'Çerez Adı';
$txt['admin_webmaster_email'] = 'Site yöneticisinin e-posta adresi';
$txt['boarddir'] = 'ElkArte Dizini';
$txt['sourcesdir'] = 'Kaynak Dizini';
$txt['cachedir'] = 'Önbellek Dizini';
$txt['admin_news'] = 'Haberleri Etkinleştir';
$txt['admin_guest_post'] = 'Ziyaretçilerin ileti göndermelerini etkinleştir';
$txt['admin_manage_members'] = 'Üyeler';
$txt['admin_main'] = 'Genel';
$txt['admin_config'] = 'Yapılandırma';
$txt['admin_version_check'] = 'Detaylı sürüm kontrolü';
$txt['admin_elkfile'] = 'ElkArte dosyası';
$txt['admin_elkpackage'] = 'ElkArte paketi';
$txt['admin_logoff'] = 'Yönetici Oturumunu bitir';
$txt['admin_maintenance'] = 'Bakım';
$txt['admin_image_text'] = 'Butonlar için metin yerine resim kullan';
$txt['admin_credits'] = 'Hazırlayanlar - Ekip';
$txt['admin_agreement'] = 'Kayıt sırasında üyelik sözleşmesinin onaylanmasını zorunlu kıl';
$txt['admin_checkbox_agreement'] = 'Sözleşme için tam sayfa yerine kayıt formunda bir onay kutusu gösterin';
$txt['admin_checkbox_accept_agreement'] = 'Tüm üyeleri bir sonraki forum ziyaretinde kullanıcı sözleşmesinin yeni versiyonunu kabul etmeye zorla';
$txt['admin_agreement_default'] = 'Varsayılan';
$txt['admin_agreement_select_language'] = 'Düzenlenecek dil';
$txt['admin_agreement_select_language_change'] = 'Değiştir';

$txt['admin_privacypol'] = 'Kayıt sırasında Gizlilik Politikasını göster ve kabul edilmesini gereklidir';
$txt['admin_checkbox_accept_privacypol'] = 'Tüm üyeleri bir sonraki forum ziyaretinde gizlilik politikasının yeni versiyonunu kabul etmeye zorla';

$txt['admin_delete_members'] = 'Seçili Üyeleri Sil';
$txt['admin_change_primary_membergroup'] = 'Birincil üye grubunu değiştir';
$txt['admin_change_secondary_membergroup'] = 'Ek üye grubunu değiştir/ekle';
$txt['confirm_remove_membergroup'] = 'Bunu seçerek tüm üye gruplar kaldırılacak! Emin misiniz?';
$txt['confirm_change_primary_membergroup'] = 'Seçili üyelerin birincil grubunu değiştirmek istediğinizden emin misiniz?';
$txt['confirm_change_secondary_membergroup'] = 'Seçilen üyelerin ek grubunu değiştirmek istediğinizden emin misiniz?';
$txt['admin_ban_usernames'] = 'Kullanıcı Adı Yasaklama';
$txt['admin_ban_useremails'] = 'E-Posta Yasaklama';
$txt['admin_ban_userips'] = 'IP Yasaklama';
$txt['admin_ban_usernames_and_emails'] = 'Kullanıcı Adı ve E-Posta Yasaklama';
$txt['admin_ban_name'] = 'Toplu Kullanıcı Yasaklama';
$txt['remove_groups'] = 'Tüm grupları kaldır';

$txt['admin_repair'] = 'Tüm bölüm ve konuları onar';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Lütfen her kutuya birer haber giriniz. Haberlerde <span>[b]</span>, <span>[i]</span> ve <span>[u]</span> gibi BBC etiketlerinin yanı sıra gülümsemeler kullanılabilirsiniz. Kaldırmak istediğiniz haberin içeriğini temizlemeniz yeterli olacaktır.';
$txt['administrators'] = 'Forum Yöneticileri';
$txt['admin_reserved_desc'] = 'Ayrılmış isimler kullanıcıların belli isimler ile kayıt olmasını veya belirlenmiş kelimelerin üye isimlerinde kullanılmasını engelleyecektir. Ek seçenekler aşağıda listelenmiştir.';
$txt['admin_activation_email'] = 'Yeni kayıt olan kullanıcılara aktivasyon gönder';
$txt['admin_match_whole'] = 'Tam ismin eşleşmesini zorunlu kıl.';
$txt['admin_match_case'] = 'Büyük-küçük harfe duyarlı olsun.';
$txt['admin_check_user'] = 'Kullanıcı adını denetle';
$txt['admin_check_display'] = 'Görünen ismi denetle.';
$txt['admin_newsletter_send'] = 'Bu bölümde istediğiniz kullanıcı gruplarındaki üyelere e-posta gönderebilirsiniz. Seçilen kullanıcı gruplarındaki kullanıcıların e-posta adresleri aşağıda listelendi. Ek adres belirtmek istiyorsanız, e-posta adreslerini \'adres1; adres2\' biçiminde girebilirsiniz.';
$txt['admin_fader_delay'] = 'Haber kutusundaki iletilerin kaybolma hızını milisaniye olarak girin';
$txt['zero_for_no_limit'] = '(0 - sınırsız)';
$txt['zero_to_disable'] = '(0 devre dışı bırakır)';

$txt['admin_backup_fail'] = 'Settings.php dosyasının yedeği alınamıyor - forum ana dizininizde Settings_bak.php adlı dosyanın yazılabilir ve var olduğundan emin olun';
$txt['modSettings_info'] = 'Genel özellikler, Karma, İmzalar, Beğebilerr ve daha pek çok şey için bu forumun çalışma şeklini ayarlar';
$txt['database_server'] = 'Veritabanı Sunucu Adresi';
$txt['database_user'] = 'Veritabanı Kullanıcı Adı';
$txt['database_password'] = 'Veritabanı Şifresi';
$txt['database_name'] = 'Veritabanı Adı';
$txt['registration_agreement'] = 'Üyelik Sözleşmesi';
$txt['registration_agreement_desc'] = 'Bu sözleşme kullanıcılara kayıt sırasında gösterilecek ve kaydın tamamlanabilmesi için kabul edilmesi zorunlu olacaktır.';
$txt['privacy_policy'] = 'Gizlilik Politikası';
$txt['privacy_policy_desc'] = 'Bu gizlilik ilkesi, bir kullanıcı bu forumda bir hesapla kaydolduğunda gösterilir ve kullanıcılar kaydolmaya devam etmeden önce zorunlu hale getirilebilir.';
$txt['database_prefix'] = 'Veritabanı tablolarının öneki';
$txt['errors_list'] = 'Forum Hatalarının Listesi';
$txt['errors_found'] = 'Forum\'unuzda aşağıdaki hatalar bulunmuştur';
$txt['errors_fix'] = 'Hataları düzeltmek istiyor musunuz?';
$txt['errors_do_recount'] = 'Tüm hatalar çözüldü - bir kurtarma alanı oluşturuldu! Bazı anahtar istatistikleri tekrar saymak için lütfen aşağıdaki butona tıklayın.';
$txt['errors_recount_now'] = 'İstatistikleri Yeniden Say';
$txt['errors_fixing'] = 'Forum hataları düzeltiliyor';
$txt['errors_fixed'] = 'Tüm hatalar düzeltildi! Lütfen kategorilerinizi, bölümlerinizi ve konularınızı kontrol edin.';
$txt['attachments_avatars'] = 'Eklentiler ve Avatarlar';
$txt['attachments_desc'] = 'Forum\'daki eklentileri bu alanda yönetebilirsiniz. Eklentileri tarih veya boyutlarına göre silebilirsiniz. Ayrıca eklentiler ile ilgili istatistiklerde aşağıda gösterilmektedir.';
$txt['attachment_stats'] = 'Eklenti İstatistikleri';
$txt['attachment_integrity_check'] = 'Ek Bütünlük Kontrolü';
$txt['attachment_integrity_check_desc'] = 'Bu fonksiyon veritabanında listelenmiş eklerin ve dosya isimlerinin boyutunu ve bütünlüğünü kontrol edecektir ve eğer gerekirse, karşılaşılan hataları çözecektir.';
$txt['attachment_check_now'] = 'Kontrolü şimdi çalıştır';
$txt['attachment_pruning'] = 'Ek Temizliği';
$txt['attachment_pruning_message'] = 'İletiye eklenicek mesaj';
$txt['attachment_pruning_warning'] = 'Bu ekleri silmek istediğinize eminmisiniz?\\nGeri alınamaz.';

$txt['attachment_total'] = 'Toplam Eklenti';
$txt['attachmentdir_size'] = 'Eklenti Klasörünün Toplam Boyutu';
$txt['attachmentdir_size_current'] = 'Şu Andaki Eklenti Klasörünün Toplam Boyutu';
$txt['attachmentdir_files_current'] = 'Geçerli eklentidizininde ki toplam dosyalar';
$txt['attachment_space'] = 'Kullanılabilir Boş Alan';
$txt['attachment_files'] = 'Kalan toplam dosya';

$txt['attachment_options'] = 'Dosya Ekleme Seçenekleri';
$txt['attachment_log'] = 'Eklenti Kayıtları';
$txt['attachment_remove_old'] = '%1$s günden daha eski eklentileri kaldır';
$txt['attachment_remove_size'] = '%1$s KiB daha büyük eklentileri kaldır';
$txt['attachment_name'] = 'Dosya Adı';
$txt['attachment_file_size'] = 'Dosya Boyutu';
$txt['attachmentdir_size_not_set'] = 'Eklenti dizini için maksimum boyut belirlenmemiş.';
$txt['attachmentdir_files_not_set'] = 'Şu anda klasör dosya boyutu limiti ayarlı değil';
$txt['attachment_delete_admin'] = '[eklenti yönetici tarafından silindi]';
$txt['live'] = 'Son Yazılım Güncellemeleri';
$txt['remove_all'] = 'Tümünü Kaldır';
$txt['agreement_not_writable'] = 'Uyarı - agreement.txt yazılabilir değil. Yaptığınız değişiklikler kaydedilmeyecek.';
$txt['agreement_backup_not_writable'] = 'Uyarı - Yedekleme dizini forum_root/packages/backup yolunda oluşturulamadı.';
$txt['privacypol_not_writable'] = 'Uyarı - privacypolicy.txt yazılabilir değil. Yaptığınız değişiklikler kaydedilmeyecek.';
$txt['privacypol_backup_not_writable'] = 'Uyarı - Yedekleme dizini forum_root/packages/backup yolunda oluşturulamadı.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(daha fazla detay)';

$txt['lfyi'] = 'ElkArte\'de bulunan Son Haberler dosyasına bağlanılamadı.';

$txt['manage_calendar'] = 'Takvim';
$txt['manage_search'] = 'Arama';
$txt['viewmembers_online'] = 'Son Aktif Olma';

$txt['smileys_manage'] = 'Gülümsemeler ve İleti İkonları';
$txt['smileys_manage_info'] = 'Yeni Gülümsemeler ve İleti İkonları   yükleyin, mevcut setlere gülümsemeler ekleyin veya mesaj simgelerinizi yönetin.';

$txt['bbc_manage'] = 'İleti biçimlendirme etiketleri (BBC)';
$txt['bbc_manage_info'] = 'BBC etiketleri ekleyin, kaldırın veya düzenleyin.';

$txt['package_info'] = 'Paketleri indirin, yükleyin; Dosya İzinleri ve FTP ayarlarını kontrol edin.';
$txt['theme_admin'] = 'Temalar ve Görünüm';
$txt['theme_admin_info'] = 'Burada varsayılan temayı değiştirebilir, tüm üyelerin temalarını sıfırlayabilir veya tema seçimi ile ilgili diğer ayarlarda değişiklikler yapabilirsiniz. Aynı zamanda buradan yeni temalar da yükleyebilirsiniz.';
$txt['registration_center'] = 'Üye Olma';
$txt['member_center_info'] = 'Üye listesini görüntüleyebilir, üyelarde arama yapabilir,  hesapları yönetebilir hesap aktivasyon işlemlerini yapabilirsiniz.';
$txt['viewmembers_online'] = 'Son Aktif Olma';

$txt['display_name'] = 'Görünen Adı';
$txt['email_address'] = 'E-Posta Adresi';
$txt['ip_address'] = 'IP adresi';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'bilinmeyen';
$txt['security_wrong'] = 'Yönetici giriş girişimi!
Yönlendiren: %1$s
Tarayıcı: %2$s
IP: %3$s\'';

$txt['email_as_html'] = 'HTML formatında gönder. <em class="smalltext">(bu seçenek sayesinde iletilerde normal HTML kodları kullanabilirsiniz)</em>';
$txt['email_parsed_html'] = '&lt;br /&gt; ve &amp;nbsp; etiketlerini bu iletiye ekle';
$txt['email_variables'] = 'Bu ileti içerisinde bazı &quot;değişkenler&quot; kullanılabilmektedir. Daha fazla bilgi için <a href="{help_emailmembers}" class="help">tıklayın</a>.';
$txt['email_force'] = 'Üye duyuruları kabul etmemeyi tercih etmişse bile gönder.';
$txt['email_as_pms'] = 'E-Posta yerine kişisel ileti olarak gönder.';
$txt['email_continue'] = 'Devam Et';
$txt['email_done'] = 'bitti.';
$txt['email_members_succeeded'] = 'Bülteninizi başarıyla gönderdiniz!';

$txt['ban_title'] = 'Yasaklama Listesi';
$txt['ban_ip'] = 'IP yasaklama: (Örn. 114.008.87.08 veya 128.0.*.*) - Her satıra bir tane';
$txt['ban_email'] = 'E-Posta yasaklama: (Örn. eren@alper.com) - Her satıra bir tane';
$txt['ban_username'] = 'Kullanıcı adı yasaklama: (Örn. dreadLord) - Her satıra bir tane';

$txt['ban_errors_detected'] = 'Yasağı, tetikleyicileri düzenlerken ya da kaydederken aşağıdaki hata veya hatalar oluştu';
$txt['ban_description'] = 'Buradan kişilerin forum\'a girişini IP, host adı, kullanıcı adı, veya e-posta\'ya dayalı olarak engelleyebilirsiniz.';
$txt['ban_add_new'] = 'Yeni yasaklama ekle';
$txt['ban_banned_entity'] = 'Yasaklama türü';
$txt['ban_on_ip'] = 'IP Yasaklama (Örn. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Hostadı Yasaklama (Örn. *.edu)';
$txt['ban_on_email'] = 'E-Posta Yasaklama (Örn. *@kotusite.com)';
$txt['ban_on_username'] = 'Kullanıcı Adı Yasaklama';
$txt['ban_notes'] = 'Notlar';
$txt['ban_restriction'] = 'Uygulanılacak İşlem';
$txt['ban_full_ban'] = 'Tam Yasaklama';
$txt['ban_partial_ban'] = 'Kısmi Yasaklama';
$txt['ban_cannot_post'] = 'İleti gönderemesin';
$txt['ban_cannot_register'] = 'Üye olamasın';
$txt['ban_cannot_login'] = 'Giriş yapamasın';
$txt['ban_add'] = 'Ekle';
$txt['ban_edit_list'] = 'Yasaklama Listesi';
$txt['ban_type'] = 'Yasaklama Türü';
$txt['ban_days'] = 'günde bir tekrarlanır';
$txt['ban_will_expire_within'] = 'Belirtilen zamandan sonra iptal edilsin:';
$txt['ban_added'] = 'Eklendi';
$txt['ban_expires'] = 'Zaman Aşımı';
$txt['ban_hits'] = 'Hitler';
$txt['ban_actions'] = 'İşlemler';
$txt['ban_expiration'] = 'Zaman Aşımı';
$txt['ban_reason_desc'] = 'Yasaklamanın nedenini belirtin, yasaklanan üyeye gösterilecektir';
$txt['ban_notes_desc'] = 'Diğer ekip üyelerini bilgilendirmek amacıyla notlar girebilirsiniz';
$txt['ban_remove_selected'] = 'Seçilenleri kaldır';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Seçilen yasaklamaları kaldırmak istediğinizden emin misiniz?';
$txt['ban_modify'] = 'Düzenle';
$txt['ban_name'] = 'Yasaklama ismi';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Yasaklamayı düzenle';
$txt['ban_add_notes'] = '<b>Not</b>: yukarıdaki yasaklamayı oluşturduktan sonra, yasaklamaya başka tetikleyiciler de ekleyebilirsiniz, IP adresleri, host adları ve e-mail adresleri gibi.';
$txt['ban_expired'] = 'Süresi dolmuş / kapatılmış';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Herhangi bir kısıtlama seçilmemiş.';

$txt['ban_triggers'] = 'Tetikleyiciler';
$txt['ban_add_trigger'] = 'Yasaklama tetikleyicisi ekle';
$txt['ban_add_trigger_submit'] = 'Ekle';
$txt['ban_edit_trigger'] = 'Düzenle';
$txt['ban_edit_trigger_title'] = 'Yasaklama tetikleyicisini düzenle';
$txt['ban_edit_trigger_submit'] = 'Düzenle';
$txt['ban_remove_selected_triggers'] = 'Seçili tetikleyicileri sil';
$txt['ban_no_entries'] = 'Yürürlükte yasak yok.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Seçili tetikleyicileri silmek istediğinizden emin misiniz?';
$txt['ban_trigger_browse'] = 'Tetikleyicilere gözat';
$txt['ban_trigger_browse_description'] = 'Bu ekran tüm yasaklanmış girdileri gösterir IP adresi, host adı, email adresi ve kullanıcı adı.';

$txt['ban_log'] = 'Yasaklama Kayıtları';
$txt['ban_log_description'] = 'Yasaklanan kullanıcı, IP yada e-posta adresinden yapılan işlemleri burada izleyebilirsiniz.';
$txt['ban_log_no_entries'] = 'Herhangi bir ban kaydı yok.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'E-Posta Adresi';
$txt['ban_log_member'] = 'Üye';
$txt['ban_log_date'] = 'Tarih';
$txt['ban_log_remove_all'] = 'Tümünü Kaldır';
$txt['ban_log_remove_all_confirm'] = 'Tüm yasaklama kayıtlarının silinmesini istiyor musunuz?';
$txt['ban_log_remove_selected'] = 'Seçilenleri kaldır';
$txt['ban_log_remove_selected_confirm'] = 'Seçilen tüm yasaklama kayıtlarının silinmesini istiyor musunuz?';
$txt['ban_no_triggers'] = 'Yasaklama tetikleyicisi yok.';

$txt['settings_not_writable'] = 'Bu ayarlar Settings.php dosyası yazılabilir olmadığı için kaydedilemedi.';

$txt['maintain_title'] = 'Forum Bakımı';
$txt['maintain_info'] = 'Bu bölüm aracılığıyla veritabanı tablolarını iyileştirebilir, forum yedekleri alabilir, oluşmuş olabilecek hataları kontrol edebilir, ve bölümleri temizleyebilirsiniz.';
$txt['maintain_sub_database'] = 'Veritabanı';
$txt['maintain_sub_routine'] = 'Rutin';
$txt['maintain_sub_members'] = 'Üyeler';
$txt['maintain_sub_topics'] = 'Konular';
$txt['maintain_sub_attachments'] = 'Eklentiler';
$txt['maintain_done'] = '\'%1$s\' bakım görevi  başarılı bir şekilde gerçekleştirilmiştir';
$txt['maintain_fail'] = '\'%1$s\' bakım çalışması başarısız oldu.';
$txt['maintain_no_errors'] = 'Tebrikler, hiç hataya rastlanmadı!  Kontrol için teşekkürler.';

$txt['maintain_tasks'] = 'Zamanlanmış Görevler';
$txt['maintain_tasks_desc'] = 'Bu bölümü kullanarak tüm zamanlanmış işlemleri yönetebilirsiniz.';

$txt['scheduled_log'] = 'Görev Günlüğü';
$txt['scheduled_log_desc'] = 'Şimdiye kadar tamamlanmış görevlerin günlüklerini listeler.';
$txt['admin_log'] = 'Yönetim Kaydı';
$txt['admin_log_desc'] = 'Yöneticileriniz tarafından yapılmış yönetimsel eylemlerin bir kaydını tutar.';
$txt['moderation_log'] = 'Moderasyon Kaydı';
$txt['moderation_log_desc'] = 'Moderatörleriniz tarafından yapılmış moderasyon eylemlerinin bir kaydını tutar.';
$txt['badbehavior_log'] = 'Kötü Davranış Günlüğü';
$txt['badbehavior_log_desc'] = 'Kötü davranışlarla şüpheli veya kötü amaçlı olarak işaretlenmiş istekleri listeler. Ayrıntılı günlüğe kaydetme varsa tüm HTTP istekleri listelenir.';
$txt['spider_log_desc'] = 'Forumunuzdaki arama motoru örümcek aktivitesi girdilerini gözden geçirin.';
$txt['pruning_log_desc'] = 'Çeşitli kayıtlardaki girdileri temizlemek için bu araçları kullanın.';

$txt['mailqueue_title'] = 'E-Posta';

$txt['db_error_send'] = 'MySQL bağlantı hatalarını e-posta ile gönder';
$txt['db_persist'] = 'Sürekli bir bağlantı oluştur';
$txt['ssi_db_user'] = 'SSI Veritabanı Kullanıcı Adı ';
$txt['ssi_db_passwd'] = 'SSI Veritabanı Parolası';

$txt['default_language'] = 'Forum\'un Varsayılan Dili';

$txt['maintenance_subject'] = 'Görüntülenecek Başlık';
$txt['maintenance_message'] = 'Görüntülenecek İleti';

$txt['errlog_desc'] = 'Forumunuzun veritabanında sakladığı hata iletilerinin listesi aşağıdadır. Veritabanından silmek istediğiniz hata iletilerini işaretleyin ve en alttaki %s tuşuna basın.';
$txt['errlog_no_entries'] = 'Şu anda hata kaydı bulunmamaktadır.';

$txt['theme_settings'] = 'Tema Ayarları';
$txt['theme_edit_settings'] = 'Bu temanın ayarlarını düzenleyin';
$txt['theme_current_settings'] = 'Kullanılan Tema';

$txt['dvc_your'] = 'Kullandığınız Sürüm';
$txt['dvc_current'] = 'Güncel Sürüm';
$txt['dvc_sources'] = 'Kaynak Dosyaları';
$txt['dvc_admin'] = 'Yönetim';
$txt['dvc_controllers'] = 'Denetleyiciler';
$txt['dvc_database'] = 'Veritabanı';
$txt['dvc_subs'] = 'Abonelikler';
$txt['dvc_default'] = 'Varsayılan Tema';
$txt['dvc_templates'] = 'Güncel Temalar';
$txt['dvc_languages'] = 'Dil Dosyaları';

$txt['smileys_default_set_for_theme'] = 'Bu tema için varsayılan gülümseme setini seçin:';
$txt['smileys_no_default'] = 'Varsayılan gülümseme setini kullan';

$txt['censor_test'] = 'Sansürlenen Kelimeleri Deneyin';
$txt['censor_test_save'] = 'Deneme';
$txt['censor_case'] = 'Büyük/küçük harf farkını yoksay';
$txt['censor_whole_words'] = 'Sadece tam kelimeleri kontrol et';
$txt['censor_allow'] = 'Kullanıcıların kelime sansürlerini kapatmalarına izin ver.';

$txt['admin_confirm_password'] = '(şifreyi onayla)';
$txt['admin_incorrect_password'] = 'Geçersiz Şifre';

$txt['date_format'] = '(YYYY-AA-GG)';
$txt['undefined_gender'] = 'Tanımlanmamış';
$txt['age'] = 'Yaşı';
$txt['activation_status'] = 'Aktivasyon Durumu';
$txt['activated'] = 'Aktifleştirilmiş';
$txt['not_activated'] = 'Aktifleştirilmemiş';
$txt['is_banned'] = 'Yasaklı';
$txt['primary'] = 'Birincil';
$txt['additional'] = 'İkincil';
$txt['wild_cards_allowed'] = 'Joker olarak * ve ? kullanabilirsiniz';
$txt['member_part_of_these_membergroups'] = 'Üye bu üye grupların bir parçasıdır';
$txt['membergroups'] = 'Üye grupları';
$txt['confirm_delete_members'] = 'Seçili üyeleri silmek istediğinizden emin misiniz?';

$txt['support_credits_title'] = 'Destek &amp; Hazırlayanlar';
$txt['support_credits_info'] = 'En sık karşılaşılan sorunların bağlantılarını, yardım istemek için gerekli forum sürümü bilgilerini ve ElkArte projesine katkıda bulunanların  listesi.';
$txt['support_title'] = 'Destek Bilgileri';
$txt['support_versions_current'] = 'Güncel sürüm';
$txt['support_versions_forum'] = 'Mevcut Sürüm';
$txt['support_versions_db'] = '%s sürümü';
$txt['support_versions_server'] = 'Sunucu Sürümü';
$txt['support_versions_gd'] = 'GD sürümü';
$txt['support_versions_imagick'] = 'Imagick sürümü';
$txt['support_versions'] = 'Sürüm Bilgileri';
$txt['support_resources'] = 'Yardım Kaynakları';
$txt['support_resources_p1'] = '<a href="%1$s" target="_blank" class="new_win">Çevrimiçi El Kitabı</a>  ElkArte hakkındaki ana dökümantasyonu sağlamaktadır. ElkArte  Çevrimiçi El Kitabı, yardım sorularınıza cevap bulabilmenize yardım edebilecek birçok döküman bulunduruyor ve <a href="%2$s" target="_blank" class="new_win">Özellikleri</a>, <a href="%3$s" target="_blank" class="new_win">Ayarları</a>, <a href="%4$s" target="_blank" class="new_win">Temaları</a>, <a href="%5$s" target="_blank" class="new_win">Paketleri</a> vs. açıklıyor. Çevrimiçi El Kitabı dökümanları sorularınıza hızlıca cevap verir.';
$txt['support_resources_p2'] = 'Eğer cevaplarınızı Çevrimiçi El Kitabın\'da bulamıyorsanız, <a href="%1$s" target="_blank" class="new_win>Yardım Topluluğu</a>\'muzda bir arama yapabilirsiniz veya ElkArte Yardım Topluluğu, <a href="%2$s" target="_blank" class="new_win">yardım</a>, <a href="%3$s" target="_blank" class="new_win">kişiselleştirme</a>, ElkArte hakkında tartışma gibi birçok şey, hosting sağlayıcı bulma ve yöneticilik sorunlarını diğer forum yöneticileriyle tartışma için kullanılabilir.';

$txt['latest_updates'] = 'En son kayda değer güncellemeler';
$txt['new_in_1_0_2'] = 'ElkArte 1.0.2\'deki en önemli değişiklik, avatar izin yönetimidir. Şu anda, her avatar ayarı yöntemi, her bir grup için her yöntemin etkinleştirilmesini/devre dışı bırakılmasını gerektiren, izin tabanlıdır. 1.0.2 ile avatarlar kullanıcı grubu tarafından etkinleştirilir/devre dışı bırakılır; bu, etkin grupların bir avatar (mevcut tüm yöntemlerle) eklemelerine izin verir. <br />
Tek izin, üyelerin avatarlarını değiştirmelerine izin vermek için genel bir izin. Ayrıca avatarların maksimum genişliği ve yüksekliği için yalnızca bir ayar var, bu değerler tüm avatar yöntemleri için geçerlidir. <br /> <br />
Değişikliklerin niteliğinden ötürü mevcut ayarları yeni bir formata taşımak imkansız değildi, bu nedenle <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Ayarları</a>  sayfasına gidin ve tercih ettiğiniz seçenekleri belirleyin.';

$txt['edit_permissions_info'] = 'Genel ve belirli bölüm özelliklerini ziyaretçi, üyeler ve moderatörlerin  neler yapabileceğini yönetmek için izin ayarlarını belirleyin.';
$txt['membergroups_members'] = 'Normal Üyeler';
$txt['membergroups_guests'] = 'Ziyaretçiler';
$txt['membergroups_add_group'] = 'Grup Ekle';
$txt['membergroups_permissions'] = 'İzinler';

$txt['permitgroups_restrict'] = 'Kısıtlı';
$txt['permitgroups_standard'] = 'Standart';
$txt['permitgroups_moderator'] = 'Moderatör';
$txt['permitgroups_maintenance'] = 'Bakım';

$txt['confirm_delete_attachments'] = 'Seçilen eklentileri silmek istediğinizden emin misiniz?';
$txt['attachment_manager_browse_files'] = 'Dosyalara Gözat';
$txt['attachment_manager_repair'] = 'Bakım';
$txt['attachment_manager_avatars'] = 'Avatarlar';
$txt['attachment_manager_attachments'] = 'Eklentiler';
$txt['attachment_manager_thumbs'] = 'Küçük Resimler';
$txt['attachment_manager_last_active'] = 'Son Aktif Olma Zamanı';
$txt['attachment_manager_member'] = 'Üye';
$txt['attachment_manager_avatars_older'] = '%1$s  gündür aktif olmayan üyelerin avatarları sil';
$txt['attachment_manager_total_avatars'] = 'Toplam Avatar';

$txt['attachment_manager_avatars_no_entries'] = 'Şu anda avatar yok.';
$txt['attachment_manager_attachments_no_entries'] = 'Şu anda eklenti yok.';
$txt['attachment_manager_thumbs_no_entries'] = 'Şu anda önizleme yok.';

$txt['attachment_manager_settings'] = 'Eklenti Ayarları';
$txt['attachment_manager_avatar_settings'] = 'Avatar Ayarları';
$txt['attachment_manager_browse'] = 'Dosyalara Gözat';
$txt['attachment_manager_maintenance'] = 'Dosya Bakımı';
$txt['attachmentEnable'] = 'Eklenti Ayarları';
$txt['attachmentEnable_deactivate'] = 'Eklentileri devre dışı bırak';
$txt['attachmentEnable_enable_all'] = 'Tüm eklentileri aktifleştir';
$txt['attachmentEnable_disable_new'] = 'Yeni eklentileri devre dışı bırak';
$txt['attachmentCheckExtensions'] = 'Eklentilerin uzantısını kontrol et';
$txt['attachmentExtensions'] = 'İzin verilen eklenti uzantıları';
$txt['attachmentRecodeLineEndings'] = 'Metin eklentilerinde satır sonlarını tekrar kodla';
$txt['attachmentShowImages'] = 'İletinin altında resim eklentilerinin önizlemesini göster';
$txt['attachmentUploadDir'] = 'Eklenti dizini';
$txt['attachmentUploadDir_multiple_configure'] = 'Eklenti dizinlerini yönet';
$txt['attachmentDirSizeLimit'] = 'Eklenti klasörünün maks. boyutu';
$txt['attachmentPostLimit'] = 'Her bir iletideki eklentinin maks. boyutu';
$txt['attachmentSizeLimit'] = 'Her bir eklentinin maks. boyutu';
$txt['attachmentNumPerPostLimit'] = 'Her bir iletideki maks. eklenti sayısı';
$txt['attachment_img_enc_warning'] = 'GD modülü veya ImagMagick şu anda yüklü değil. Resim yeniden-kodlaması mümkün değildir.';
$txt['attachment_postsize_warning'] = 'Şu anki php.ini \'post_max_size\' ayarı bunu desteklemeyebilir.';
$txt['attachment_filesize_warning'] = 'Şu anki php.ini \'upload_max_filesize\' ayarı bunu desteklemeyebilir.';
$txt['attachment_image_reencode'] = 'Ekteki resimlerin tekrar-şifrelenmesi potansiyel tehlikedir';
$txt['attachment_image_reencode_note'] = '(GD modülü, veya ImageMagick modülü gereklidir)';
$txt['attachment_image_paranoid_warning'] = 'Kapsamlı güvenlik kontrolü, büyük sayıda rededilmiş eklerin ortaya çıkmasına yol açar.';
$txt['attachment_image_paranoid'] = 'Yüklenmiş resim ekleri üzerinde kapsamlı güvenlik kontrolü gerçekleştir';
$txt['attachment_autorotate'] = 'Yanlış döndürülmüş görüntüleri algıla ve düzelt';
$txt['attachment_autorotate_na'] = '(Bu sistemde yok)';
$txt['attachmentThumbnails'] = 'İletinin altında gösterilen resimleri yeniden boyutlandır';
$txt['attachment_thumb_png'] = 'Küçükresimleri PNG olarak kaydet';
$txt['attachment_thumb_memory'] = 'Uyarlanabilir küçükresim belleği';
$txt['attachment_thumb_memory_note2'] = 'Sistem belleği yetersizse, küçük resim oluşturulmayacak.';
$txt['attachment_thumb_memory_note1'] = 'Her zaman küçük resim oluşturmaya çalışmak için bu kutuyu işaretlemeyin';
$txt['attachmentThumbWidth'] = 'Küçük Resmin maks. genişliği';
$txt['attachmentThumbHeight'] = 'Küçük Resmin maks. yüksekliği';
$txt['attachment_thumbnail_settings'] = 'Küçük Resim Ayarları';
$txt['attachment_security_settings'] = 'Eklenti güvenlik ayarları';

$txt['attachment_inline_title'] = 'Satır içi ek ayarları';
$txt['attachment_inline_enabled'] = 'Satır içi ek görüntülemeyi etkinleştir';
$txt['attachment_inline_basicmenu'] = 'Sadece temel menü göster';
$txt['attachment_inline_quotes'] = 'Alıntılarda satır içi ekler görünsün';

$txt['attach_dir_does_not_exist'] = 'Bulunamadı';
$txt['attach_dir_not_writable'] = 'Yazılabilir Değil';
$txt['attach_dir_files_missing'] = 'Kayıp Dosyalar Var (<a href="{repair_url}">Tamir Et</a>)';
$txt['attach_dir_unused'] = 'Kullanılmıyor';
$txt['attach_dir_empty'] = 'Boş';
$txt['attach_dir_ok'] = 'TAMAM';
$txt['attach_dir_basedir'] = 'Ana dizin';

$txt['attach_dir_desc'] = 'Yeni dizinler oluşturun veya aşağıdaki geçerli dizini değiştirin. Dizinler, bir alt dizin içermediği sürece yeniden adlandırılabilir. Yeni dizin forum dizin yapısı içinde oluşturulacaksa, sadece dizin adını yazmanız yeterlidir. Bir dizini kaldırmak için, yol girişi alanını boş bırakın. Dizinler, dosya veya alt dizinleri içeriyorsa (dosya sayısının yanında parantez içinde gösterilir) silinemez.';
$txt['attach_dir_base_desc'] = 'Mevcut alt dizini değiştirmek veya yeni bir dizin oluşturmak için aşağıdaki alanı kullanabilirsiniz. Yeni alt dizinler de Ek Dizini listesine eklenir. Varolan bir dizini temel dizin olarak da atayabilirsiniz.';
$txt['attach_dir_save_problem'] = 'Ops, bir hata oluştu gibi görünüyor.';
$txt['attachments_no_create'] = 'Yeni bir ek dizini yaratılamıyor. Lütfen FTP istemcisi veya site dosya yöneticisi kullanarak yapınız.';
$txt['attachments_no_write'] = 'Bu klasör oluşturuldu fakat yazılabilir durumda değil. Lütfen bir FTP istemci veya dosya yöneticisi kullanarak yazılabilir olmasını sağlayın.';
$txt['attach_dir_reserved'] = 'Eklenemiyor. Bu dizin bir sistem dizin ve ekleri için kullanılamaz.';
$txt['attach_dir_duplicate_msg'] = 'Eklenemiyor. Dizin zaten mevcut.';
$txt['attach_dir_exists_msg'] = 'Taşınamıyor. O yolda zaten bir dizin bulunuyor.';
$txt['attach_dir_base_dupe_msg'] = 'Eklenemiyor. Ana dizin zaten yaratılmış.';
$txt['attach_dir_base_no_create'] = 'Oluşturulamıyor. Lütfen dosya yolunu doğrulayınız. Ya da bu klasörü bir FTP istemci veya dosya yöneticisiyle oluşturarak tekrar deneyin.';
$txt['attach_dir_no_rename'] = 'Taşıma veya yeniden adlandırma yapılamıyor. Lütfen dosya yolunun doğruluğundan veya kendi içerisinde başka klasör olmadığından emin olun.';
$txt['attach_dir_no_delete'] = 'boş değil ve silinemez. Lütfen FTP istemcisi veya site dosya yöneticisi kullanarak yapınız.';
$txt['attach_dir_no_remove'] = 'Hala dosya içeriyor veya bir ana dizin ve silinemez.';
$txt['attach_dir_is_current'] = 'Geçerli dizin seçiliyken kaldıramaz.';
$txt['attach_dir_is_current_bd'] = 'Geçerli ana dizin olarak seçiliyken kaldıramaz.';
$txt['attach_last_dir'] = 'Son aktif ek dizini';
$txt['attach_current_dir'] = 'Geçerli ek dizini';
$txt['attach_current'] = 'Şu anki';
$txt['attach_path_manage'] = 'Ek yollarını yönet';
$txt['attach_directories'] = 'Ek Dizinleri';
$txt['attach_paths'] = 'Ek dizin yolları';
$txt['attach_path'] = 'Adres';
$txt['attach_current_size'] = 'Boyut (KiB)';
$txt['attach_num_files'] = 'Dosyalar';
$txt['attach_dir_status'] = 'Durumu';
$txt['attach_add_path'] = 'Adres Ekle';
$txt['attach_path_current_bad'] = 'Geçersiz eklenti adresi.';
$txt['attachmentDirFileLimit'] = 'Dizin başına en fazla dosya sayısı';

$txt['attach_base_paths'] = 'Ana dizin yolu';
$txt['attach_num_dirs'] = 'Dizinler';
$txt['max_image_width'] = 'İletilmiş veya eklenmiş resimlerin gösterilecek maksimum genişliği';
$txt['max_image_height'] = 'İletilmiş veya eklenmiş resimlerin gösterilecek maksimum yüksekliği';

$txt['automanage_attachments'] = 'Eklenti klasörlerinin yönetilme şeklini seçin';
$txt['attachments_normal'] = '(Elle) ElkArte varsayılan davranışı';
$txt['attachments_auto_years'] = '(Otomatik) Yıllara göre ayır';
$txt['attachments_auto_months'] = '(Otomatik) Yıllara ve aylara göre ayır';
$txt['attachments_auto_days'] = '(Otomatik) Yıllara, aylara ve günlere göre ayır';
$txt['attachments_auto_16'] = '(Otomatik) 16 rastgele dizin';
$txt['attachments_auto_16x16'] = '(Otomatik) Rastgele 16 rastgele dizin ile 16 alt-dizin';
$txt['attachments_auto_space'] = '(Otomatik) Dizin alanı sınırına ulaşıldığında';

$txt['use_subdirectories_for_attachments'] = 'Bir alt dizinde yeni dizinler oluştur';
$txt['use_subdirectories_for_attachments_note'] = 'Veya herhangi bir klasör forumun ana dizininde oluşturulacak.';
$txt['basedirectory_for_attachments'] = 'Ekler için bir ana dizin ayarla';
$txt['basedirectory_for_attachments_current'] = 'Şu anki ana dizin';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Lütüfen dikkat ediniz, dizin yanlış. <br />(<a href="{attach_repair_url}">Düzeltmeyi dene</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">Bu klasörle ilgili bir sorun görünüyor. <br />(<a href="{attach_repair_url}">Düzeltmeyi dene</a>)</div>';

$txt['attachment_transfer'] = 'Ekleri Taşı';
$txt['attachment_transfer_desc'] = 'Dizinler arası dosya taşı.';
$txt['attachment_transfer_select'] = 'Dizin seçin';
$txt['attachment_transfer_now'] = 'Taşı';
$txt['attachment_transfer_from'] = 'Taşıyacağın dosyayı seç';
$txt['attachment_transfer_auto'] = 'Otomatik olarak boşluk veya dosya sayısına göre';
$txt['attachment_transfer_auto_select'] = 'Ana dizini seç';
$txt['attachment_transfer_to'] = 'veya taşımak için farklı bir dizin seç.';
$txt['attachment_transfer_empty'] = 'Kaynak dizinindeki tüm dosyaları taşı';
$txt['attachment_transfer_no_base'] = 'Kullanılabilir temel klasör yok.';
$txt['attachment_transfer_forum_root'] = 'Forum ana dizini.';
$txt['attachment_transfer_no_room'] = 'Klasör boyutu veya dosya sayısı limitine ulaşıldı.';
$txt['attachment_transfer_no_find'] = 'Taşınacak dosya bulunamadı.';
$txt['attachments_transfered'] = '%1$d dosya şuraya taşındı: %2$s';
$txt['attachments_not_transfered'] = '%1$d dosya taşınmadı.';
$txt['attachment_transfer_no_dir'] = 'Kaynak klasörü veya hedef seçeneklerden biri seçilmedi.';
$txt['attachment_transfer_same_dir'] = 'Aynı dizini hem kaynak hem de hedef olarak seçemezsiniz.';
$txt['attachment_transfer_progress'] = 'Lütfen bekleyin. Taşıma gerçekleşiyor.';

$txt['avatar_settings'] = 'Genel avatar ayarları';
$txt['avatar_default'] = 'Kendi avatarına sahip olmayan tüm kullanıcılar için varsayılan bir avatar etkinleştirilsin';
$txt['avatar_directory'] = 'Avatar Dizini';
$txt['avatar_url'] = 'Avatar URL\'si';
$txt['avatar_max_width'] = 'Avatarın maks. genişliği (px)';
$txt['avatar_max_height'] = 'Avatarın maks. yüksekliği (px)';
$txt['avatar_action_too_large'] = 'Eğer avatar çok büyükse...';
$txt['option_refuse'] = 'Kabul etme';
$txt['option_resize'] = 'CSS boyutunu küçült';
$txt['option_download_and_resize'] = 'Yükle ve yeniden boyutlandır (GD veya ImageMagick modülü gerektirir)';
$txt['gravatar'] = 'Gravatar';
$txt['avatar_gravatar_enabled'] = 'Gravatar kullanımını etkinleştir';
$txt['gravatar_rating'] = 'Gravatar Derecesi';
$txt['avatar_download_png'] = 'Yeniden boyutlandırılan avatarlar için PNG kullan';
$txt['avatar_img_enc_warning'] = 'GD veya ImageMagick modüllerinden biri şu anda yüklü olmadığından. Bazı avatar özellikleri devre dışı bırakıldı.';
$txt['avatar_external'] = 'Harici Avatarlar';
$txt['avatar_external_enabled'] = 'Başka bir sunucuda (uzaktan/URL)  bulunan avatarları kullanmayı etkinleştir';
$txt['avatar_upload'] = 'Yüklenebilir Avatarlar';
$txt['avatar_resize_options'] = 'Sunucu depolama seçenekleri';
$txt['avatar_upload_enabled'] = 'Avatar yüklemeyi etkinleştir';
$txt['avatar_server_stored'] = 'Sunucuda Kayıtlı Avatarlar';
$txt['avatar_stored_enabled'] = 'Sunucuda bulunan avatarları kullanmayı etkinleştir';
$txt['profile_set_avatar'] = 'Avatar kullanmaya yetkili üye grupları';
$txt['avatar_select_permission'] = 'Yetkili Grupları Belirlemek İçin Tıklayınız';
$txt['avatar_download_external'] = 'Verilmiş adresteki avatar\'ı sunucuya yükle';
$txt['custom_avatar_enabled'] = 'Avatarı yükle...';
$txt['option_attachment_dir'] = 'Dosya eki dizini';
$txt['option_specified_dir'] = 'Belirli dizine...';
$txt['custom_avatar_dir'] = 'Yükleme Dizini';
$txt['custom_avatar_dir_desc'] = 'Bu, sunucu tarafından depolanan dizinden farklı, geçerli ve yazılabilir bir dizin olmalıdır.';
$txt['custom_avatar_url'] = 'Yükleme Adresi';
$txt['custom_avatar_check_empty'] = 'Belirttiğiniz özel avatar dizini boş veya geçersiz. Lütfen ayarların doğru olup olmadıklarını kontrol ediniz.';
$txt['avatar_reencode'] = 'Avatarların tekrar-şifrelenmesi potansiyel tehlikedir';
$txt['avatar_reencode_note'] = '(GD modülü gereklidir)';
$txt['avatar_paranoid_warning'] = 'Kapsamlı güvenlik kontrolü, büyük sayıda rededilmiş avatarların ortaya çıkmasına yol açar.';
$txt['avatar_paranoid'] = 'Yüklenmiş avatarlar üstünde kapsamlı güvenlik kontrolü uygula';

$txt['repair_attachments'] = 'Eklentilere Bakım Yap';
$txt['repair_attachments_complete'] = 'Bakım Tamamlandı';
$txt['repair_attachments_complete_desc'] = 'Seçilmiş tüm hatalar düzeltildi.';
$txt['repair_attachments_no_errors'] = 'Hiçbir hata bulunamadı';
$txt['repair_attachments_error_desc'] = 'Bakım sırasında aşağıdaki hatalar bulundu. Düzeltmek istediğiniz hataları, yanındaki kutucuğa tıklayarak seçin.';
$txt['repair_attachments_continue'] = 'Devam Et';
$txt['repair_attachments_cancel'] = 'İptal';
$txt['attach_repair_missing_thumbnail_parent'] = '%d adındaki küçük resimlerin ana eklentileri eksik';
$txt['attach_repair_parent_missing_thumbnail'] = '%d küçük resme sahip olarak gösterilmiş, ama küçük resim bulunmamakta';
$txt['attach_repair_file_missing_on_disk'] = '%d eklenti/avatar var olarak gözükmekte ama aslında diskte görünmemekte';
$txt['attach_repair_file_wrong_size'] = '%d eklenti/avatarın boyutu yanlış kaydedilmiş';
$txt['attach_repair_file_size_of_zero'] = '%d eklenti/avatarın boyutu 0 olarak gözükmekte. (Silinecek)';
$txt['attach_repair_attachment_no_msg'] = '%1$d eklentinin kendileri ile bağlantılı iletileri bulunmamakta';
$txt['attach_repair_avatar_no_member'] = '%1$d eklentinin kendileri ile bağlantılı kullanıcıları bulunmamakta';
$txt['attach_repair_wrong_folder'] = '%1$d eklenti yanlış dizinde bulunmakta';
$txt['attach_repair_missing_extension'] = '%1$d eklerin uygun bir uzantısı yok ve yanlış dizinde olabilir';
$txt['attach_repair_files_without_attachment'] = '%1$d dosyanın veritabanında kaydı bulanamadı. (Bunlar silinecek)';

$txt['news_title'] = 'Haberler ve Bültenler';
$txt['news_settings_desc'] = 'Burada haberler ve haber bültenlerine ait ayarlarda ve izinlerde değişiklikler yapabilirsiniz.';
$txt['news_mailing_desc'] = 'Burayı kullanarak kayıtlı tüm üyelere e-posta gönderebilirsiniz. Önemli duyuruları ve haberleri göndermek için ideal bir yöntemdir.';
$txt['news_error_no_news'] = 'Önizlenecek bir şey yok';
$txt['groups_edit_news'] = 'Haberleri düzenlemeye izinli gruplar';
$txt['groups_send_mail'] = 'Haberleri göndermeye izinli gruplar';
$txt['xmlnews_enable'] = 'XML/RSS haberlerini aktif et';
$txt['xmlnews_maxlen'] = 'En fazla mesaj uzunluğu';
$txt['xmlnews_limit'] = 'XML/RSS Sınırlama';
$txt['xmlnews_limit_note'] = 'Haber akışındaki öğe sayısı';
$txt['xmlnews_maxlen_note'] = '(0 devre dışı, kötü fikir.)';
$txt['editnews_clickadd'] = 'Başka bir öğe ekle';
$txt['editnews_remove_selected'] = 'Seçilenleri kaldır';
$txt['editnews_remove_confirm'] = 'Seçilen öğeleri silmek istediğinizden emin misiniz?';
$txt['censor_clickadd'] = 'Başka bir kelime ekle';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Kayıtlar';
$txt['generate_reports'] = 'Raporlar';

$txt['update_available'] = 'Güncelleme Mevcut';
$txt['update_message'] = 'Hatalar ve sorunlar içeren eski bir ElkArte sürümü kullanmaktasınız.
 En çok kısa sürede <a href="#" id="update-link"> forumunuzu en yeni sürüme geçirmeniz </a> önerilir. Sadece bir kaç dakika sürer!';

$txt['manageposts'] = 'İletiler ve Konular';
$txt['manageposts_title'] = 'İletileri ve Konuları Yönet';
$txt['manageposts_description'] = 'Burada iletiler ve konularla ilgili tüm ayarları değiştirebilirsiniz.';

$txt['manageposts_seconds'] = 'saniye';
$txt['manageposts_minutes'] = 'dakika';
$txt['manageposts_characters'] = 'karakter';
$txt['manageposts_days'] = 'gün arasında';
$txt['manageposts_posts'] = 'ileti';
$txt['manageposts_topics'] = 'konu';

$txt['pollMode'] = 'Aktif';

$txt['manageposts_settings'] = 'İleti Ayarları';
$txt['manageposts_settings_description'] = 'Burada iletiler ve ileti gönderme ile ilgili birçok seçeneği değiştirebilirsiniz.';

$txt['manageposts_bbc_settings'] = 'BBC';
$txt['manageposts_bbc_settings_description'] = 'Bulletin board code (BBC) forumdaki yazılara bazı efektler uygulamak için kullanılabilir. Örneğin, \'ev\' kelimesini kalın göstermek için [b]ev[/b] şeklinde yazabilirsiniz. Tüm Bulletin board code (BBC) etiketleri kare parantezler (\'[\' and \']\') ile çevrilidirler.';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code Ayarları';

$txt['manageposts_topic_settings'] = 'Konu Ayarları';
$txt['manageposts_topic_settings_description'] = 'Burada konularla ilgili birçok seçeneği değiştirebilirsiniz.';

$txt['managedrafts_settings'] = 'Taslak Ayarları';
$txt['managedrafts_settings_description'] = 'Burada taslaklar ile ilgili tüm ayarları yapabilirsiniz.';
$txt['manage_drafts'] = 'Taslaklar';

$txt['mail_center'] = 'E-posta Liste Merkezi';
$txt['mm_emailerror'] = 'Başarısız E-postalar';
$txt['mm_emailfilters'] = 'Filtreler';
$txt['mm_emailparsers'] = 'Ayrıştırıcılar';
$txt['mm_emailtemplates'] = 'Şablonlar';
$txt['mm_emailsettings'] = 'Ayarlar';

$txt['removeNestedQuotes'] = 'Alıntı yaparken içiçe olan alıntıları kaldır';
$txt['enableSpellChecking'] = 'Yazım denetimi aktif';
$txt['enableSpellChecking_warning'] = 'tüm sunucularda çalışmayabilir.';
$txt['enableSpellChecking_error'] = 'sunucunuz üzerinde çalışmaz.';
$txt['enableVideoEmbeding'] = 'Video bağlantılarının otomatik gömülmesini etkinleştir.';
$txt['enableCodePrettify'] = 'İletilerde Kod renklendirmeyi etkinleştir';
$txt['max_messageLength'] = 'İletilerde izin verilen en fazla karakter';
$txt['max_messageLength_zero'] = '(0 - sınırsız.)';
$txt['convert_to_mediumtext'] = 'Veritabanınız 65535 karakterden fazla mesaj almaya uygun olarak ayarlanmamış. Lütfen <a href="%1$s">veritabanı yönetimi<a/> sayfasını kullanarak dönüşüm işlemlerini yaptıktan sonra mesajlardaki maksimum karakter sayısını tekrar ayarlayınız.';
$txt['topicSummaryPosts'] = 'Konu özetinde gösterilecek en fazla ileti';
$txt['spamWaitTime'] = 'Aynı IP adresinden gönderilecek iki ileti arasındaki zaman limiti';
$txt['edit_wait_time'] = 'Düzenleme yapılabilmesi için beklenecek süre';
$txt['edit_disable_time'] = 'İleti gönderildikten sonra düzenleme yapılabilecek maksimum süre';
$txt['edit_disable_time_zero'] = '0 - sınırsız';
$txt['preview_characters'] = 'En yüksek ilk/son ileti ön gösterim uzunluğu.';
$txt['preview_characters_units'] = 'karakter';
$txt['preview_characters_zero'] = '0 yaparsanız "Tümü" görünecektir';
$txt['message_index_preview'] = 'İleti dizininde ileti önizlemelerini göster';
$txt['message_index_preview_off'] = 'Önizlemeleri gösterme';
$txt['message_index_preview_first'] = 'İlk iletinin metnini göster';
$txt['message_index_preview_last'] = 'Son iletinin metnini göster';

$txt['enableBBC'] = 'BBC kullanılmasına izin ver';
$txt['enablePostHTML'] = 'İletilerde <i>basit</i> HTML kodlarına izin ver';
$txt['autoLinkUrls'] = 'URL\'leri bağlantılara çevir';
$txt['disabledBBC'] = 'İzin Verilen BBC Etkiketleri';
$txt['bbcTagsToUse'] = 'İzin Verilen BBC Etkiketleri';
$txt['bbcTagsToUse_select'] = 'Kullanılmasına izin verilecek etiketleri seç';
$txt['bbcTagsToUse_select_all'] = 'Tüm etiketleri seç';

$txt['enableParticipation'] = 'Katılım ikonlarına izin ver';
$txt['enableFollowup'] = 'Takipleri etkinleştir';
$txt['enable_unwatch'] = 'Konu izlemeyi etkinleştir';
$txt['oldTopicDays'] = 'Bir konuya yanıt verilebilecek maksimum süre';
$txt['oldTopicDays_zero'] = '0 - sınırsız';
$txt['defaultMaxTopics'] = 'Bir sayfada gösterilecek en fazla konu';
$txt['defaultMaxMessages'] = 'Bir konuda gösterilecek en fazla ileti';
$txt['disable_print_topic'] = 'Konu yazdırma özelliğini devre dışı bırak';
$txt['hotTopicPosts'] = 'Beğenilen konu değeri';
$txt['hotTopicVeryPosts'] = 'Çok beğenilen konu değeri';
$txt['useLikesNotViews'] = 'Popüler konuları tanımlamak için ileti sayısı yerine beğenen sayısını  kullan';
$txt['enableAllMessages'] = 'Gösterilecek en çok yanıt sayısı:';
$txt['enableAllMessages_zero'] = '0 yaparsanız "Tümü" gözükmeyecektir';
$txt['disableCustomPerPage'] = 'Sayfa başına özel konu/ileti seçeneğini devre dışı bırak';
$txt['enablePreviousNext'] = 'Önceki/Sonraki konu bağlantıları aktif';

$txt['not_done_title'] = 'İşlem henüz tamamlanamadı';
$txt['not_done_reason'] = 'Sunucunuza aşırı yüklenmemek için, işlem geçici olarak durduruldu. Birkaç saniye içinde kaldığı yerden devam edecektir.  Eğer etmez ise, lütfen aşağıdaki Devam Et tuşuna basınız.';
$txt['not_done_continue'] = 'Devam Et';

$txt['general_settings'] = 'Genel';
$txt['database_paths_settings'] = 'Veritabanı ve dosya yolları';
$txt['cookies_sessions_settings'] = 'Çerezler ve Oturumlar';
$txt['caching_settings'] = 'Önbellek Ayarları';
$txt['loadavg'] = 'Sunucu Yükü';
$txt['loadavg_settings'] = 'Yük Yönetimi';
$txt['phpinfo_settings'] = 'PHP Bilgileri';
$txt['phpinfo_localsettings'] = 'Yerel Ayarlar';
$txt['phpinfo_defaultsettings'] = 'Varsayılan Ayarlar';
$txt['phpinfo_itemsettings'] = 'Ayarlar';

$txt['language_configuration'] = 'Diller';
$txt['language_description'] = 'Bu bölüm forumunuzda kurulu olan dilleri düzenlemenizi sağlar. ElkArte sitesinden farklı diller de indirebilirsiniz. Ayrıca bu bölümden dille ilgili ayarları da yapabilirsiniz.';
$txt['language_edit'] = 'Dilleri Düzenle';
$txt['language_add'] = 'Dil Ekle';
$txt['language_settings'] = 'Ayarlar';

$txt['advanced'] = 'Gelişmiş';
$txt['simple'] = 'Basit';

$txt['admin_news_select_recipients'] = 'Bu bölümü kullanarak bültenin yollanacağı kişileri belirtebilirsiniz:';
$txt['admin_news_select_group'] = 'Üye grupları';
$txt['admin_news_select_group_desc'] = 'Bültenin yollanacağı grupları seçiniz.';
$txt['admin_news_select_members'] = 'Üyeler';
$txt['admin_news_select_members_desc'] = 'Bültenin ek olarak yollanacağı üyeleri seçiniz.';
$txt['admin_news_select_excluded_members'] = 'Hariç Tutulacak Üyeler';
$txt['admin_news_select_excluded_members_desc'] = 'Bültenin yollanmayacağı üyeler.';
$txt['admin_news_select_excluded_groups'] = 'Hariç Tutulacak Gruplar';
$txt['admin_news_select_excluded_groups_desc'] = 'Bültenin yollanmayacağı üye grupları.';
$txt['admin_news_select_email'] = 'E-Posta Adresleri';
$txt['admin_news_select_email_desc'] = 'Bu bültenin gönderilmesi gereken, e-posta adreslerinin bir sembolik ayrılmış listesi. (örneğin: adres1; adres2)';
$txt['admin_news_select_override_notify'] = 'Bildirim ayarlarını geçersiz kıl';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'E-posta adresine kişisel ileti gönderemezsiniz. Eğer devam edersiniz girilmiş tüm e-posta adresleri yoksayılacaktır.\\n\\nDevam etmek istediğinize emin misiniz?';

$txt['mailqueue_browse'] = 'Sırayı Görüntüle';
$txt['mailqueue_settings'] = 'Ayarlar';

$txt['admin_search'] = 'Hızlı Arama';
$txt['admin_search_type_internal'] = 'Görev/Ayar';
$txt['admin_search_type_member'] = 'Üye';
$txt['admin_search_type_online'] = 'Çevrimiçi Kılavuz';
$txt['admin_search_go'] = 'Başla';
$txt['admin_search_results'] = 'Arama Sonuçları';
$txt['admin_search_results_desc'] = 'Araması yapılan sözcük: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Tekrar ara';
$txt['admin_search_results_none'] = 'Sonuç bulunamadı.';

$txt['admin_search_section_sections'] = 'Bölüm';
$txt['admin_search_section_settings'] = 'Ayar';

$txt['core_settings_title'] = 'Çekirdek Ayarlar';
$txt['core_settings_desc'] = 'Bu sayfa forumun isteğe bağlı özelliklerini açmak veya devre dışı bırakmak içindir.';
$txt['mods_cat_features'] = 'Genel';
$txt['mods_cat_security_general'] = 'Genel';
$txt['antispam_title'] = 'Spam Koruması';
$txt['badbehavior_title'] = 'Kötü Davranış';
$txt['mods_cat_modifications_misc'] = 'Çeşitli';
$txt['mods_cat_layout'] = 'Görünüm';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderasyon';
$txt['signature_settings_short'] = 'İmzalar';
$txt['custom_profile_shorttitle'] = 'Profil Alanları';
$txt['pruning_title'] = 'Kayıtları Temizle';

$txt['core_settings_activation_message'] = '{core_feature} özelliği etkinleştirildi, yapılandırmak için başlığa tıklayın.';
$txt['core_settings_deactivation_message'] = '{core_feature}  özelliği devre dışı bırakıldı';
$txt['core_settings_generic_error'] = 'Bir hata oluştu, lütfen sayfayı tekrar yükleyin ve tekrar deneyin.';

$txt['boardsEdit'] = 'Bölümleri Düzenle';
$txt['mboards_new_cat'] = 'Yeni kategori oluştur';
$txt['manage_holidays'] = 'Tatilleri Yönet';
$txt['calendar_settings'] = 'Takvim Ayarları';
$txt['search_weights'] = 'Ağırlıklar';
$txt['search_method'] = 'Arama metodu';
$txt['search_sphinx'] = 'Sphinx yapılandırması';

$txt['smiley_sets'] = 'Gülümseme Setleri';
$txt['smileys_add'] = 'Gülümseme Ekle';
$txt['smileys_edit'] = 'Gülümsemeleri Düzenle';
$txt['smileys_set_order'] = 'Gülümseme sıralamasını belirle';
$txt['icons_edit_message_icons'] = 'İleti İkonlarını Düzenle';

$txt['membergroups_new_group'] = 'Kullanıcı Grubu Ekle';
$txt['membergroups_edit_groups'] = 'Kullanıcı Gruplarını Düzenle';
$txt['permissions_groups'] = 'Genel İzinler';
$txt['permissions_boards'] = 'Bölüm İzinleri';
$txt['permissions_profiles'] = 'Profilleri Düzenle';
$txt['permissions_post_moderation'] = 'İleti Moderasyonu';

$txt['browse_packages'] = 'Paketleri Görüntüle';
$txt['download_packages'] = 'Paket İndir';
$txt['upload_packages'] = 'Paket Yükle';
$txt['installed_packages'] = 'Yüklü Paketler';
$txt['package_file_perms'] = 'Dosya İzinleri';
$txt['package_settings'] = 'Ayarlar';
$txt['package_servers'] = 'Paket Sunucuları';
$txt['themeadmin_admin_title'] = 'Yönet ve Yükle';
$txt['themeadmin_list_title'] = 'Tema Ayarları';
$txt['themeadmin_reset_title'] = 'Üye Seçenekleri';
$txt['themeadmin_edit_title'] = 'Temaları Düzenle';
$txt['admin_browse_register_new'] = 'Yeni üye kaydet';

$txt['search_engines'] = 'Arama Motorları';
$txt['spider_logs'] = 'Kayıtlar';
$txt['spider_stats'] = 'İstatistikler';

$txt['paid_subscriptions'] = 'Ücretli Abonelikler';
$txt['paid_subs_view'] = 'Abonelikleri Görüntüle';

$txt['maintain_sub_hooks_list'] = 'Entegrasyon Kancaları';
$txt['hooks_field_hook_name'] = 'Kanca Adı';
$txt['hooks_field_function_name'] = 'Fonksiyon Adı';
$txt['hooks_field_function'] = 'İşlev';
$txt['hooks_field_included_file'] = 'Dahil edilen dosya';
$txt['hooks_field_file_name'] = 'Dosya Adı';
$txt['hooks_field_hook_exists'] = 'Durumu';
$txt['hooks_active'] = 'Var';
$txt['hooks_disabled'] = 'Kapalı'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Bulunamadı';
$txt['hooks_no_hooks'] = 'Şu anda sistemde kanca yok.';
$txt['hooks_disable_legend'] = 'Gösterge';
$txt['hooks_disable_legend_exists'] = 'Kanca var ve aktif';
$txt['hooks_disable_legend_disabled'] = 'Kanca var ama devre dışı';
$txt['hooks_disable_legend_missing'] = 'Kanca bulunamadı';
$txt['hooks_reset_filter'] = 'Filtreyi sıfırlayın';

$txt['board_perms_allow'] = 'İzinli';
$txt['board_perms_ignore'] = 'Yoksay';
$txt['board_perms_deny'] = 'Yasaklı';
$txt['all_boards_in_cat'] = 'Bu kategorideki tüm bölümler';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Sözcük ayırıcı';

$txt['admin_order_title'] = 'Sipariş Hatası';
$txt['admin_order_error'] = 'İsteğiniz işlenirken bilinmeyen bir hata oluştu';

// Known controllers that can work on the front page
$txt['default'] = 'Varsayılan';
$txt['front_page'] = 'Ana sayfada gösterilecek eylemi seçin:';

$txt['BoardIndex_Controller'] = 'Ana Sayfa';
$txt['MessageIndex_Controller'] = 'Bir bölümün içeriği';
$txt['message_index_frontpage'] = 'Ana sayfada gösterilecek bölümü seçin:';
$txt['Recent_Controller'] = 'Son iletiler';
$txt['recent_frontpage'] = 'Gösterilecek mesaj sayısı:';
