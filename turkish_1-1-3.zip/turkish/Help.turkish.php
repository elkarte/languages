<?php
// Version: 1.1; Help

global $helptxt;

$txt['close_window'] = 'Pencereyi kapat';

$helptxt['manage_boards'] = '
<strong>Bölümeri düzenle</strong><br />
	Bu menüde oda ve kategori ekleme/düzenleme/kaldırma işlemlerini 
	yapabilirsiniz. Örneğin, &quot;Spor&quot;,&quot;Araba&quot; ve &quot;Müzik&quot; ile ilgili
        oldukça geniş yelpazeli bir siteniz var ise bunlar sizin ekleyeceğiniz en üst Kategoriler olur.
	Tüm bu kategorilerin içinde isteğiniz yönünde hiyerarşik &quot;alt-kategoriler&quot;,
	veya &quot;Odalar&quot; oluşturabilirsiniz. Hiyerarşik düzen şu şekildedir: <br />

	<ul>
		<li>
			<strong>Spor</strong>
			&nbsp;- Bir &quot;kategori&quot;
		</li>
		<ul>
			<li>
				<strong>Futbol</strong>
				&nbsp;- Bu &quot;Spor&quot; kategorisininin altında bir kategoridir.
			</li>
			<ul>
				<li>
					<strong>İstatistikler</strong>
					&nbsp;- Bu ise &quot;Futbol&quot; alt bölümüne ait bir alt bölümdür
				</li>
			</ul>
			<li><strong>Yüzme</strong>
			&nbsp;- Bu &quot;Spor&quot; kategorisinin altında bir kategoridir</li>
		</ul>
	</ul>
	Kategoriler size forumu çeşitli başlıklar altında ayırmanızı sağlar (&quot;Araba,
	Spor&quot;), ve bu kategorilerin içindeki &quot;Odalar&quot; kısmında üyelerin ileti
	gönderebileceği konular bulunur. Galatasaray hakkındaki konuları görmek isteyen üye
	&quot;Spor->Futbol->GALATASARAY&quot; dizinindeki konulara kolaylıkla ulaşabilir. 
	Kategoriler üyelere istedikleri konuyu kolaylıkla bulmalarını sağlar. Sadece &quot;Alışveriş&quot; yerine
	&quot;Bilgisayar&quot; ve &quot;Giyim&quot; bölümlerinde ilginize göre kolaylıkla ulaşabilirsiniz.
	Bu sayede girmek istemediğiniz yerlere girmeye mecbur kalmazsınız; çünkü Bilgisayar Malzemesi ararken
	bu &quot;kategori&quot yerine Giyim Mağazası kısmına girmek zorunda değilsiniz.<br />
	Yukarıda belirtildiği gibi bu odalar geniş kapsamlı kategorilerin altındaki birer konu gibidirler.
	Eğer &quot;Galatasaray&quot; hakkında konuşmak istiyorsanız, &quot;Spor->Futbol&quot; kategorilerinin
	içinde yer alan &quot;Galatasaray&quot; odasına girip düşünceleriniz paylaşabilirsiniz.<br />
	Bu menüdeki yönetici işlemleri her kategori altında yeni bir oda oluşturma, onların 
	sıralamalarını değiştirme (&quot;Galatasaray&quot\'ı; &quot;Sakaryaspor&quot;\'un üstüne yerleştirme)
	veya tamamen bu konuları silme.';

$helptxt['edit_news'] = '	<ul class="normallist">
		<li>
			<strong>Haberler</strong><br />
			Bu bölüm Ana Sayfanızda görüntülenecek metinleri ayarlamanızı sağlar.
			İstediğiniz her maddeyi ekleyebilirsiniz. (örn: &quot;Bu Salı günündeki konferansı kaçırmayın&quot;) Tüm haber maddeleri rastgele olarak gösterilir ve ayrı kutulara yerleştirilmelidir.
		</li>
		<li>
			<strong>Haber Bültenleri</strong><br />
			Bu bölüm forum üyelerinize özel ileti veya e-posta olarak haber bültenleri göndermenizi sağlar. İlk olarak haber bültenlerini almasını istediğiniz grupları ve haber bültenlerini almasını istemediğiniz üye gruplarını seçin. Dilerseniz, haber bültenlerini alacak üyeleri ve email adreslerini de ekleyebilirsiniz. Son olarak, göndermek istediğiniz iletiyi girin ve özel ileti olarak mı yoksa e-posta olarak mı göndermek istediğinizi seçin.
		</li>
		<li>
			<strong>Ayarlar</strong><br />
			Bu bölüm, hangi grupların forum haberlerini düzenleyebileceği veya haber bülteni gönderebileceği de dahil, haberler ve haber bültenleri hakkında birkaç ayar içerir. Ayrıca forumdan haber bülteni almak isteyip istemediğinizi ve alacağınız her haber bülteni gönderisinde kaç karakterlik yazı gösterilmesini istediğinizi yine buradan belirleyebilirsiniz.
		</li>
	</ul>';

$helptxt['view_members'] = '
<ul class="normallist">
		<li>
			<strong>Tüm Üyeleri Göster</strong><br />
			Bu özellik forum\'da bulunan tüm üyeleri isimleri profil\'lerine köprülenmiş bir şekilde
			görüntülemenize ve eğer yönetici iseniz bu üyelerin seçeneklerinizi değiştirmenize olanak
                        tanır (website, yaş, vb.). Yönetici haklarına sahip biri, üyeler üzerinde komple kontrole 
                        sahiptir, üye hesabını silmek gibi seçeneklerde Yöneticinin yetkileri arasında bulunur.<br /><br />
		</li>
		<li>
			<strong>Onay Bekleyen Üyeler</strong><br />
			Bu bölüm sadece Yönetici onaylı üyelik sistemi seçili ise görüntülenebilir. Bu seçenek seçili ise bir kişi ancak yönetici 
                        onun üyelik isteğini kabul ettiyse tam bir üye haline gelebilir. Bu bölümde hala yönetici onayı beklemekte olan üyeler,
                        e-posta ve IP adresleri ile birlikte gösterilirler. Burada kişilerin üyelik isteklerini ister kabul edebilir istersenizde
			kabul etmeyebilirsiniz (silme). Üyelerin isimlerinin yanındaki kutulara tıklayabilir ve aşağıdaki çoktan seçmeli menüden yapılacak işlemi
                        seçebilirsiniz. Bir üyenin başvurusunu kabul etmeyecekseniz, bu üyenin bu kararınızdan haberdar edilip edilmeyeceğini belirleyebilirsiniz.<br /><br />
		</li>
		<li>
			<strong>Aktivasyon Bekleyen Üyeler</strong><br />
			Bu bölüm sadece forum seçeneklerinde aktivasyon onaylı üyeliği seçtiyseniz görüntülenebilir olacaktır. Bu bölümde henüz
                        hesaplarını aktifleştirmemiş üyelerin tümünü görebilirsiniz. Bu bölümde isterseniz üyenin hesabını aktifleştirebilir,
			silebilir veya br hatırlatma maili yollayabilirsiniz. Ayrıca isterseniz kararınızdan bu üyeyi haberdar edebilirsiniz.<br /><br />
		</li>
	</ul>';

$helptxt['ban_members'] = '<strong>Üyeleri yasaklama</strong><br />
	Forumlardaki güvenilirliği arttırmak ve belli bir yaptırım uygulayabilmek adına üyeleri &quot;banlama&quot; 
	hakkını vermektedir. Administrator olarak gördüğünüz tüm iletilerde kullanıcıların hangi IP den ileti gönderdiğini
	görebilirsiniz. Ban Listesinde üyeleri IP adresleri ile banlayarak o alandan ileti gönderilmesini engellersiniz. <br />
	Kullanıcıları mail adreslerine görede banlayabilirsiniz.';

$helptxt['featuresettings'] = '<strong>Özellikler ve Seçenekler</strong><br />
Burada tercihlerinize göre değiştirebileceğiniz çeşitli özellikler bulunmaktadır.';

$helptxt['securitysettings'] = '<b>Güvenlik ve Moderasyon</b><br />
	Bu bölüm forum güvenliği ve moderasyonu hakkında bir çok seçenek içerir.';

$helptxt['addonsettings'] = '<strong> Eklenti Ayarları </ strong> <br />
Bu bölüm forumunuza yüklü eklentiler tarafından eklenen ayarları içerir.';

$helptxt['time_format'] = '<strong>Zaman biçimi</strong><br />
	Forumun zaman biçiminide istediğiniz gibi ayarlayabilirsiniz.
	Ufak PHP kodlarının anlamları aşağıda belirtilmiştir. (daha fazla detay için <a href="http://www.php.net/manual/function.strftime.php" target="_new">php.net</a>).<br />
	<br />
	Bu karakterler zaman biçimlendirilmesinde kullanılmaktadır: <br />
	<span class="smalltext">
	&nbsp;&nbsp;%a - Belirlenmiş hafta ismi<br />
	&nbsp;&nbsp;%A - Tüm hafta ismi<br />
	&nbsp;&nbsp;%b - Belirlenmiş ay ismi<br />
	&nbsp;&nbsp;%B - Tüm ay ismi<br />
	&nbsp;&nbsp;%d - ay\'ın günleri (01\'den 31\'e kadar) <br />
	&nbsp;&nbsp;%D<strong>*</strong> - ile %m/%d/%y aynıdır<br />
	&nbsp;&nbsp;%e<strong>*</strong> - ay\'ın günü (1 den 31 e kadar) <br />
	&nbsp;&nbsp;%H - 24 saat sistemi (00 ile 23 arası) <br />
	&nbsp;&nbsp;%I - 12 saat sistemi (01 ile 12 arası) <br />
	&nbsp;&nbsp;%m - sayı olarak ay (01 den 12 ye kadar) <br />
	&nbsp;&nbsp;%M - sayı olarak dakika <br />
	&nbsp;&nbsp;%p - &quot;am&quot; veya &quot;pm&quot; olması<br />
	&nbsp;&nbsp;%R<strong>*</strong> - 24 saatlik sistemde düzen <br />
	&nbsp;&nbsp;%S - saniyeler <br />
	&nbsp;&nbsp;%T<strong>*</strong> - Şu an, %H:%M:%S <br />
	&nbsp;&nbsp;%y - 2 rakamlı yıl (00 dan 99 a) <br />
	&nbsp;&nbsp;%Y - 4 rakamlı yıl<br />
	&nbsp;&nbsp;%Z - yerel zaman bölgesi <br />
	&nbsp;&nbsp;%% - \'%\' karakteri <br />
	<br />
	<em>* Windows altyapılı serverlarda çalışmamaktadır.</em></span>';

$helptxt['deleteAccount_posts'] = 'Sadece Cevaplar: Bu, üyenin diğer konulara verdiği cevapları kaldırır<br /> 
Konular ve Cevaplar: Bu, yukarıdaki ile aynı işlemi yapar ve ek olarak bu üye tarafından başlatılan tüm konulari kaldıracaktır.';

$helptxt['live_news'] = '<strong>Live announcements</strong><br />
	This box shows recently updated announcements from <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.
	You should check here every now and then for updates, new releases, and important information from ElkArte.';

$helptxt['registrations'] = '<strong>Kayıt yönetimi</strong><br />
	Bu bölüm forumunuza kayıt yaptırmak isteyenler için olan seçekleri düzenleyebileceğiniz yerdir.
	Burada 4 seçenek bulunmaktadır. Bunlar:<br /><br />
	<ul class="normallist">
		<li>
			<strong>Yeni Üye Kaydetme</strong><br />
			Bu ekrandan yeni üye kayıdı yapılmaktadır. Bu ekran genelde sınırlandırılmış kullanıcı hizmeti veren forumlarda adminler 
			tarafından kullanıcı açılması için yapılmıştır veya test kullanıcıları oluşturmak için kullanılmaktadır. Kullanıcıları aktivasyonla
			üye yapacak olursanız mail adresine gelen linkin tıklanması gerekir, isteyen adminler şifreleri maillere otomatik yollayabilirler.<br /><br />
		</li>
		<li>
			<strong>Üyelik Sözleşmesini Düzenle</strong><br />
			Bu bölümde kayıt sırasında gösterilecek üyelik sözleşmesini düzenleyebilirsiniz. ElkArte ile birlikte gelen
			varsayılan anlaşmayı komple değiştirebilir veya üzerinde oynamalar yapabilirsiniz.<br /><br />
		</li>
		<li>
			<strong>Ayrılmış İsimleri Düzenle</strong><br />
                        Bu arayüzü kullanarak üyeler tarafından seçilmesine izin olmayacak kullanıcı adlarını belirleyebilirsiniz.<br /><br />
		</li>
		<li>
			<strong>Seçenekler</strong><br />
			Bu bölüm sadece forum\' yönetmeye izniniz varsa görüntülenebilir olacaktır. Bu bölümden forum\'unuzda kullanılacak
			üye kayıt şeklini, ve diğer kayıtla alakalı seçenekleri değiştirebilirsiniz.
		</li>
	</ul>';

$helptxt['modlog'] = '<strong>Moderasyon Kaydı</strong><br />
	Bu bölüm moderatörlerin tüm moderasyon kayıtlarını ve işlemlerini takip etmelerini sağlar. Burada bulunan kayıtlar 24 saat geçmeden silinemezler.';
$helptxt['adminlog'] = '<b>Yönetim Kaydı</b><br />

Bu bölümde yöneticilerin yaptığı bazı etkinlikleri,değişiklikleri takip etmenizi ve kaydını tutmanızı sağlar. Yaptıkları olayları hemen kaldırmadıklarından emin olmak için girdiler olay gerçekleştikten 24 saat sonrasında ancak silinebilir.';
$helptxt['badbehaviorlog'] = '<strong>Kötü Davranış Günlüğü </ strong> <br />
Bu bölüm, yönetim ekibinin üyelerinin forumda meydana gelen bazı kötü davranışları görüntülemesine izin verir. Bu günlük, kötü davranış işleviyle otomatik olarak budamaktadır, bu nedenle yalnızca etkinliğin son haftasını içerecektir.';
$helptxt['warning_enable'] = '<strong>Üye Uyarı Sistemi</strong><br /> Bu özellik üyelerin uyarı düzeylerinin admin veya moderasyon ekibi tarafından düzenlenmesini sağlar - ve uyarı düzeyleri sayesinde üyenin forum üstünde neler yapabileceği belirler. Bu özelliğin aktif edilmesi sonucunda izinler bölümünde hangi grupların üyeleri uyarabileceğine yönelik izinler çıkar. Uyarı düzeyleri üyenin profilinden ayarlanabilir. Takip eden şu özellikler mevcuttur: ';
$helptxt['watch_enable'] = '<strong>Üye İzlenmesi için Uyarı Seviyesi</strong><br /> Bu özellik üyenin uyarı düzeyinin belirtilmiş düzeye ulaştığında otomatik olarak &quot;İzle&quot; bölümüne alınmasını sağlar. &quot;İzleniyor&quot; konumundaki üyelerin isimleri direkt olarak moderasyon alanında gözükür. ';
$helptxt['moderate_enable'] = '<strong>İleti Moderasyonu için Uyarı Seviyesi</strong><br /> Eğer bir üye bu uyarıyı taşıyorsa forumda göndereceği tüm iletiler öncelikle bir moderatörün kontrolünden geçer. Bu, bulunan lokal bölüm ileti moderasyon özelliklerinin üstüne yazılacaktır.';
$helptxt['mute_enable'] = '<strong>Üye Susturulması için Uyarı Seviyesi</strong><br /> Eğer bu uyarı düzeyi üye tarafından geçilmiş ise kendilerini yasaklılar arasında bulur. Üye tüm ileti gönderme haklarını kaybeder.';
$helptxt['perday_limit'] = '<strong>Gün için Maksimum Üye Uyarı Puanı</strong><br /> Bu özellik yirmi dör saatlik zaman diliminde moderatörlerin üyelere ekleyip veya çıkarabilecekleri puanları limitler. Bu sistem ayrıca kısa zaman aralığında moderatörlerin yapabileceklerinide kısıtlar. Bu özellik değerin sıfır girilmesi ile iptal edilebilir. Admin izinlerine sahip üyeler bu değişimlerden etkilenmez. ';
$helptxt['error_log'] = '<strong>Hata Kaydı</strong><br />Hata kaydı forum içerisinde herhangi bir kullanıcının karşılaştığı önemli hataları saniye saniye kayıt eder. Tarih başlığındaki ok işaretini tıklayarak kayıtları zamana göre sıralayabilirsiniz. Ek olarak kayıtlara belirli filtrelere göre sıralayabilirsiniz, örneğin üyeye göre. Filtre aktif edildiğinde sadece o filtreye uyan kayıtlar gösterilir.';
$helptxt['theme_settings'] = '<strong>Tema Ayarları</strong><br />
	Ayarlar ekranı varsayılan tema ile alakalı olarak görünüyor. Tema dizinleri ve URL adresleri gibi ayarları içermektedir. Çoğu tema kullanıcıların 
	isteklerine göre değiştirebileceği ayarlarla donatılmıştır';
$helptxt['smileys'] = '<strong>Gülümseme Merkezi</strong><br />
	Bu bölümde forumunuzda kullanmak istediğiniz gülümseme resimlerinin dizinlerini belirleyebilir ve isteğinize göre değiştirebilirsiniz.<br /><br />
	Buradan ileti ikonlarını düzenleyebilirsiniz,eğer ayarlar sayfasından aktifleştirirseniz .';

$helptxt['calendar'] = '<strong>Takvim Yönetimi</strong><br />
	Buradan takvim ayarlarını düzenleyebilirsiniz, tatilleri ve özel günleri ekleyebilir ve kaldırabilirsiniz.';
$helptxt['calendar_settings'] = 'Takvim, doğum günlerini göstermek veya topluluğunuzda gerçekleşen önemli olayları göstermek için kullanılabilir. <br /> <br /> Takvim kullanımını (etkinlikleri gönderme, etkinlikleri görüntüleme vb.) izinlerde belirlenen ayarlar ile kontrol edildiğini unutmayın.';
$helptxt['cal_days_for_index'] = 'Ana sayfada gösterilecek olayların kapsayacağı gün sayısı<br /> Bu 7 olarak ayarlanırsa, önümüzdeki haftanın etkinlikleri gösterilir.';
$helptxt['cal_showevents'] = 'Mini Takvimler, Ana Takvim, her iki yerde olayların vurgulamasını etkinleştirir veya olay vurgulamayı devre dışı bırakır.';
$helptxt['cal_showholidays'] = 'Bu ayar Mini Takvim, Ana Takvim, her iki yerde tatil günlerini vurgulamanıza veya etkinliğin vurgulamasını devre dışı bırakmanıza olanak tanır.';
$helptxt['cal_showbdays'] = 'Bu ayar, Mini Takvimler, Ana Takvim, her iki yerde de doğum günlerini vurgulamanıza veya etkinliğin vurgulamasını devre dışı bırakmanıza olanak tanır.';
$helptxt['cal_export'] = 'Diğer takvim uygulamalarına içe aktarmak için bir metin dosyasını iCal biçiminde dışa aktarır.';
$helptxt['cal_daysaslink'] = 'Günleri \'Etkinlik Sonrası\' bağlantısını göster. <br /> Bu, üyelerin o güne ait tıklamaları tıkladıklarında etkinlik yayınlamasına olanak tanır.';
$helptxt['cal_allow_unlinked'] = 'İletilere bağlı olmayan etkinliklere izin ver: <br /> Üyelerin birbölümde ki bir yayınla bağlantılandırılmasına gerek kalmadan etkinlikler göndermesine izin ver.';
$helptxt['cal_defaultboard'] = 'Olayların gönderileceği varsayılan bölüm<br /> Etkinlikleri yüklemek için varsayılan bölüme girin.';
$helptxt['cal_showInTopic'] = 'Bağlı etkinlikleri konu ekranında göster: <br /> Etkinliğe, konu görünümünün üstündeki bir bağlantıyı göstermek için işaretleyin.';
$helptxt['cal_allowspan'] = 'Etkinliklerin birden fazla güne yayılmasına izin ver: <br /> Birden fazla güne yayılmasına izin vermek için kontrol edin.';
$helptxt['cal_maxspan'] = 'Bir olayın geçebileceği maksimum gün sayısı: <br /> Tek bir etkinliğin geçebileceği maksimum gün sayısını girin.';
$helptxt['cal_minyear'] = 'Minimum yıl: <br /> &quot; ilk&quot; Yıl takvim listesinde.';
$helptxt['cal_maxyear'] = 'Maksimum yıl: <br /> &quot; son&quot; <br /> Takvim listesinde yıl';

$helptxt['serversettings'] = '<strong>Sunucu Ayaları</strong><br />
	Burada forum\'unuzun çekirdek ayarlarını yapabilirsiniz. Bu bölüm veritabanı ayarlarının yanı sıra
	önbellek ve mail ayarları gibi daha birçok ayarı içermektedir. Burada düzenleme yaparken dikkatli olun
	çünkü yapacağınız değişiklikler forum\'unuzun erişilememez olmasına neden olabilir.';
$helptxt['manage_files'] = '
<ul class="normallist">
		<li>
			<strong>Dosyalara Gözat</strong><br />
			Tüm dosyalara göz atabilmenize olanak tanır.
		</li><li>
			<strong>Eklenti Ayarları</strong><br />
			Eklentilerin bulundukları yerleri belirler.<br /><br />
		</li><li>
			<strong>Avatar Ayarları</strong><br />
			Avatarların bulundukları yerleri, ayarları belirler.<br /><br />
		</li><li>
			<strong>Dosya Bakımı</strong><br />
			Bozukluklar düzeltilebilir ve eklentiler ile ilgili ek değişiklikler yapılabilir.<br /><br />
		</li>
	</ul>';

$helptxt['topicSummaryPosts'] = 'Yanıtlama ekranında yer alacak önceki iletilerin sayısını belirlemenizi sağlar.';
$helptxt['enableAllMessages'] = 'Bunu hepsini göster tuşu görüntülenmeden önce gösterilecek <em>maksimum</em> ileti sayısını ayarlayabilirsiniz.';
$helptxt['allow_guestAccess'] = 'Bu kutuyu işaretlememek, ziyaretçilerin basit işlemler dışında neredeyse hiçbir şey yapamamalarına neden olacaktır. Bu ziyaretçilerin bölümlere erişememesi ile aynı şey değildir.';
$helptxt['userLanguage'] = 'Bu seçeneği kullanıma açtığınız takdirde her üye forumu desteklenen her dilde görüntüleyebilecektir. Bu forumun varsayılan dilini değiştirmez.';
$helptxt['trackStats'] = 'İstatistikler:<br />Bu üyelerin forumdaki en son iletileri ve en popüler konuları görmelerini sağlar.
		En fazla online olan üye,en yeni üye vs.. gibi değişik alanda istatistiklerde bulunmaktadır.<hr />
		Hit:<br />Sayfaların görüntülenme sayısını belirler';
$helptxt['enable_unwatch'] = 'Bu seçeneğin etkinleştirilmesi, kullanıcıların daha önce gönderdikleri konuların yeni cevap bildirimlerini seçerek kapatmalarına olanak tanır.';
$helptxt['titlesEnable'] = 'Bu özellik sayesinde kullanıcılar kendileri için özel başlık seçebilecekler açabileceklerdir. Bu kullanıcı adının altında gözükecektir.
<br /><em>Örneğin:</em><br />Burhan<br />Karizma';
$helptxt['onlineEnable'] = 'Kullanıcının online olup olmadığı hakkında bir resim gösterilir.';
$helptxt['todayMod'] = 'Sadece tarihler yerine &quot;Bugün&quot; veya &quot;Dün&quot; yazılarının eklenebilmesini sağlar.<br /><br />
<strong>Örneğin:</strong><br /><br />
<dl class="settings">
<dt>  <dt>Kapalıyken</dt>
<dd>Ekim 3, 2009  12:59:18 </dd>
<dt>Göreceli</dt>
<dt> 2 Saat Önce </dd>
<dt>Sadece Bugün</dt>
<dd>Bugün 12:59:18 </dd>
<dt>Bugün ve Dün</dt> 
<dd>Dün 09:36:55</dd>  </dt>  
</dl>';
$helptxt['disableCustomPerPage'] = 'Üyelerin ileti listesi ve ileti görünümündeki sayfa başına gösterilecek öğe sayısını özelleştirmelerini engeller.';
$helptxt['enablePreviousNext'] = 'Bir önceki ve sonraki konuya link verir.';
$helptxt['pollMode'] = 'Anketlerin etkin kılınmasını sağlar. Eğer bu seçenek kapatılırsa varolan konulardaki anketler gizlenecektir. 
		Bunu engellemek için Varolan Anketleri Konu olarak göster seçeneğini etkin kılabilirsiniz.<br /><br />
		Kimlerin anket açabileceğini veya görebileceğini izinler kısmından ayarlayabilirsiniz.';
$helptxt['enableVBStyleLogin'] = 'Her sayfada ziyaretçiler için giriş panelinin gösterilmesini sağlar.';
$helptxt['enableCompressedOutput'] = 'Düşük trafik limitleri için sıkıştırma özelliğini sağlar anca yüklenebilmesi için zlib gerekmektedir.';
$helptxt['databaseSession_enable'] = 'Bu seçenek oturum bilgilerini depolamak için veritabanının kullanılmasını sağlar - yük dengesi yapılmış sunucular için en iyisidir, ancak tüm zaman aşımı hatalarını giderir ve forumun hızlanmasını sağlar.';
$helptxt['databaseSession_loose'] = 'Bu seçeneğin etkin kılınması forumun kullandığı bandwith i düşürür ve sayfalar arası geri dönüş mümkün olmaz - ve yeni ikonlar yüklenmez. (seçip gösterilmelerini istemediğiniz sürece)';
$helptxt['databaseSession_lifetime'] = 'Bir oturumun zaman aşımına uğraması için gerekli süre.  Bir oturum uzun süredir işlem yapmadıysa &quot;Zaman Aşımı&quot; hatası ile forumdan çıkışı sağlanır. 2400\'den yüksek seçenekler tavsiye edilir.';
$helptxt['cache_enable'] = 'ElkArte çeşitli seviyelerde önbellekleme gerçekleştirir. Önbellekleme seviyesi ne kadar yüksek olursa, önbelleğe alınan bilgilerin alınması için daha fazla CPU zamanı harcanır. Önbellekleme sunucunuzda mevcutsa, öncelikle 1. seviye önbelleğe almayı denemeniz önerilir.';
$helptxt['cache_memcached'] = 'Memcached kullanıyorsanız, sunucu ayrıntılarını sağlamanız gerekir. Bu, aşağıdaki örnekteki gibi virgülle ayrılmış bir liste halinde girilmelidir:<br /> <br/> &quot;server1, server2, server3: port, server4&quot;  <br /> <br /> Hiçbir bağlantı noktası belirtilmemişse yazılım, bağlantı noktası 11211 kullanacak, UNIX etki alanı kullanırken soketler 0 olarak ayarlayacaktır.';
$helptxt['cache_cachedir'] = 'Bu ayar yalnızca dosya sistemi tabanlı önbellek sistemi içindir. Önbellek dizininin yolunu belirtir. Bu dosyayı /tmp/ dizinine yerleştirmeniz önerilir, ancak bunu kullanacaksanız herhangi bir dizinde çalışabilir';
$helptxt['cache_uid'] = 'Bazı önbellek sistemleri, örneğin Xcache, önbellek temizlemek için ElkArte erişimine izin vermek için bir kullanıcı kimliği ve parola gerektirir.';
$helptxt['cache_password'] = 'Bazı önbellek sistemleri, örneğin Xcache, önbellek temizlemek için ElkArte erişimine izin vermek için bir kullanıcı kimliği ve parola gerektirir.';
$helptxt['enableErrorLogging'] = 'Hertürlü hatanın kayıt edilmesini sağlar. Yanlış şifre vs..';
$helptxt['enableErrorQueryLogging'] = 'Bu seçenek tüm veritabanı hatalarında sorguyuda günlüğe ekler. Hata raporlamanın açık olmasını gerektirir.<br /><br /><strong>Not: Hata iletisine göre hata filtreleme özelliğini etkileyecektir.</strong> ';
$helptxt['allow_disableAnnounce'] = 'Bu kullancıların duyuruları alıp almayacaklarını seçebilmelerini sağlar.';
$helptxt['disallow_sendBody'] = 'Bu seçenek kullanıcıların duyuru alırken metinin içerilip içerilmeyeceğini seçmelerine olanak tanıyan özelliği ortadan kaldırır.<br /><br />Çoğu zaman kullanıcılar yanlışlıkla duyuru mail\'ine cevap yazabilirler ve buda yöneticinin ilgili metini almasına neden olur.';
$helptxt['enable_contactform'] = 'Bu seçenek, kayıt ekranına iletişim butonu ekler.';
$helptxt['jquery_source'] = 'Bu, jQuery Kütüphanesi\'ni yüklemek için kullanılan kaynağı belirleyecektir. Auto ilk önce CDN\'yi kullanacak ve mevcut değilse yerel kaynağa geri dönecektir. Yerel yalnızca yerel kaynağı kullanacak, CDN yalnızca Google\'ın İçerik Dağıtım Ağı\'ndan yükleyecek';
$helptxt['jquery_default'] = 'ElkArte ile gelen jQuery\'den farklı bir sürümünü kullanmak isterseniz, bu kutuyu işaretleyin ve X.XX.X sürüm numarasını girin. Yerel dosya jquery-X.XX.X.min\'in adlandırma kuralını izlemelidir.  jquery-X.XX.X.min.js şeklinde yüklenmeli';
$helptxt['jqueryui_default'] = 'ElkArte ile gelen jQueryUI\'den farklı bir sürümünü kullanmak isterseniz, bu kutuyu işaretleyin ve X.XX.X sürüm numarasını girin. Yerel dosya, jquery-ui-X.XX.X\'in adlandırma kuralını izlemelidir. jquery-ui-X.XX.X.min.js şeklinde yüklenmeli';
$helptxt['minify_css_js'] = 'Bu, sayfa başına birden fazla CSS veya JavaScript dosyası gerektiğinde birleştirecektir. Ayrıca boyutlarını küçültmek için gereksiz boşlukları ve yorumları dosyalardan kaldıracaktır. Birleştirilmiş ve küçültülmüş dosyalar kaydedilir, böylece daha fazla istek hemen anında bu dosyaları sunabilir. <br /> İlk kez bir derlemenin gerekli / oluşturulduğuna dikkat edin, dosyayı oluşturmak için o sayfanın yüklenmesinde hafif bir gecikme olacağını unutmayın (önbellek silindikten sonra da gerçekleşir)';
$helptxt['compactTopicPagesEnable'] = 'Seçili sayfa numarasını gösterir.<br /><em>Örneğin:</em>
		&quot;3&quot; şu şekilde görünecek : 1 ... 4 [5] 6 ... 9
		<br />  &quot;5&quot; şu şekilde görünecek : 1 ... 3 4 [5] 6 7 ... 9';
$helptxt['timeLoadPageEnable'] = 'Ana sayfada alt bölümde sayfaların oluşturulması için gereken süreyi gösterir';
$helptxt['removeNestedQuotes'] = 'Alıntı bağlantısını takip ederek ileti gönderilmeye çalışıldığında ortaya çıkan iç içe yerleşmiş alıntıların iletiden silinmesini sağlar.';
$helptxt['search_dropdown'] = 'Hızlı arama kutusunun yanında  arama seçimi için açılır kutusu gösterecektir. Buradan geçerli siteyi, mevcut bölümü  (bir bölüm içindeyse), geçerli konuyu (bir konudaysa) aramak veya üye aramak için seçebilirsiniz.';
$helptxt['max_image_width'] = 'Bu, iletilerde görüntülenen resimler için maksimum boyutu ayarlamanızı sağlar. Maksimumdan küçük resimler etkilenmeyecektir. Bu aynı zamanda küçük resim üzerine tıklandığında ekli görüntülerin nasıl görüntüleneceğini belirler.';
$helptxt['mail_type'] = 'Bu seçenek PHP\'nin varsayılan mail seçeneğini kullanmanıza, veya SMTP kullanmanıza olanak tanır.  Unutmayın SMTP kullanmak PHP\'nin varsayılan seçeneğini kullanmaktan daha uzun sürebilir (sunucu kimlik doğrulaması gerektiriyor,) ayrıca SMTP sunucusu her zaman bir kullanıcı adı ve şifre gerektirmeyebilir.<br /><br />Eğer PHP\'nin varsayılan mail sistemini kullanacaksanız kullanıcı adı ve şifre girmenize zaten gerek yoktur.';
$helptxt['mail_batch_size'] = 'Bu ayar, sayfa yüklemesi başına kaç e-postanın gönderileceğini belirler ve dakikada izin verilen maksimum sayısından daha büyük bir değere ayarlanamaz. <br /> Bu değeri 0 olarak bırakırsanız, sistem otomatik olarak yükü eşit şekilde yayar. <br /> Kendi değerlerinizi ayarlamak istiyorsanız, bunu limitinizle aynı değere ayarlamak, dakika başına düşen düşük limitler için iyi bir seçenek veya dakikada daha yüksek limitler için limitin 1 / 6\'sı için iyi bir seçenektir.';
$helptxt['smtp_client'] = 'Used to identify this client to the SMTP server.<br />The field should contain the fully-qualified domain name (FQDN) of the SMTP client. In situations in which the client system does not have a meaningful domain name you can instead use an address literal formatted as [ipv4] or [IPv6:ipv6 address].<br />If left blank the system will attempt to detect this value for you.';

$helptxt['attachmentEnable'] = 'Ek sistemini etkinleştir/devre dışı bırak veya eski olanları bırakarak yeni ekleri devre dışı bırak';
$helptxt['attachmentRecodeLineEndings'] = 'Bunu etkinleştirmek, sunucunuza (Windows, Mac veya Unix) dayalı metin tabanlı dosyaların (txt, css, html, php, xml) satır sonlarını yeniden kodlandıracaktır.';
$helptxt['automanage_attachments'] = 'Bu ayar, seçilen seçeneğe dayalı bir dizin yapısı oluşturacaktır. Bu, yayın tarihi olabilir (ekleri yıllara göre,  yıl ve ay veya yıl, ay ve gün olarak alt bölümlere ayırma) veya alan sınırına ulaşıldığında yalnızca yeni bir dizin ekleyebilirsiniz. Yaratılan her dizinin aynı dosya sayısı ve toplam boyut sınırlaması olacaktır. Bu, dizinlerin dosya veya boyut sınırına ulaşmasını önlemeye yardımcı olur.';
$helptxt['use_sub-directories_for_attachments'] = 'Tüm yeni dizinleri ana ek dizininin altındaki alt dizinleri olarak yaratacaktır.';
$helptxt['attachmentDirSizeLimit'] = 'Ek klasörünün ne kadar büyük olabileceğini ayarlayın.';
$helptxt['attachmentDirFileLimit'] = 'Tek bir ek dizininin içerebileceği maks. dosya sayısı değerini ayarlayın.  ';
$helptxt['attachmentPostLimit'] = 'Tek bir gönderinin toplam yükleme boyutunun ne kadar büyük olabileceğini belirtin (KiB), bu, bir iletide yapılan tüm eklerin toplu boyutudur.';
$helptxt['attachmentSizeLimit'] = 'Bir iletideki tek bir ekin sahip olabileceği en büyük boyutu belirtin.';
$helptxt['attachmentNumPerPostLimit'] = 'Bir üyenin her bir iletide ekleyeceği eklenti sayısını seçmenizi sağlar';
$helptxt['attachmentCheckExtensions'] = 'Tanımladığınız dosya uzantılarıyla yalnızca o dosyaların yüklenmesine izin verecek ek filtrelemeyi etkinleştirmek için bu kutuyu işaretleyin.';
$helptxt['attachmentExtensions'] = 'Hangi ek türlerine izin verileceğini belirtin, örneğin: jpg, png, gif Bazı dosya uzantılarının web siteniz için bir güvenlik riski oluşturabileceğinden, izin verdikleriniz konusunda dikkatli olmayı unutmayın.';
$helptxt['attachment_image_paranoid'] = 'Yüklenen resimlerde sıkı güvenlik denetlemelerini aktifleştirir. Dikkat! Bu kapsamlı denetlemeler geçerli resimlerde bile hata verebilir. Bu seçeneği sadece resim şifrelemesi seçeneğiyle kullanmanız önerilir. ElkArte\'in güvenlik denetlemesinde hata veren resimleri küçültmeyi denemesi için: eğer başarılı olursa, gözden geçirilir ve yüklenirler. Aksi takdirde, eğer resim şifrelemesi aktif değilse, denetlemede hata veren tüm eklentiler reddedilecektir.';
$helptxt['attachment_autorotate'] = 'Selecting this option will allow the system to detect rotated images, typical of phone cameras, and automatically adjust the orientation such that the image top is oriented up. Requires either ImageMagick or both GD and Exif modules to be available.';
$helptxt['attachmentShowImages'] = 'Yüklenen dosya bir resimse, otomatik olarak iletinin altına görüntülenir.';
$helptxt['attachmentThumbnails'] = 'Gönderi resimlerini, seçildiğinde tam boyutlu görüntüye genişleyecek  küçük resim olarak göstermek için bunu etkinleştirin.';
$helptxt['attachment_thumb_png'] = 'İletilerde görüntülenecek küçük resimleri , PNG olarak oluşturur.';
$helptxt['attachmentThumbWidth'] = 'Only used with the &quot;Resize images when showing under posts&quot; option, the maximum width to resize attachments down from.  They will be resized proportionally.';
$helptxt['attachmentThumbHeight'] = 'Only used with the &quot;Resize images when showing under posts&quot; option, the maximum height to resize attachments down from.  They will be resized proportionally.';
$helptxt['attachment_image_reencode'] = 'Yüklenen resmi tekrar şifreler. Resmi tekrar şifrelemek daha iyi güvenlik sağlar. Ancak bu seçenek, tüm hareketli resimleri duraklatır. <br /> Sadece GD modülü yüklü olan sunucularda çalışır.';
$helptxt['attachment_thumb_memory'] = 'Bu seçenek işaretlendiğinde, sistem istenilen belleği tahmin edecek ve daha sonra bunu isteyecektir. Kaynak görüntüsü (boyut ve genişlik x yükseklik) büyüdükçe sistem için bellek gereksinimleri de o kadar yüksek olacaktır. <br /> Tutar. Başarılı olursa o halde o zaman küçük resim oluşturmaya çalışacaktır. <br /> Bu, daha az beyaz ekran hatası ile sonuçlanacak ancak daha az küçük resim oluşturulmasına neden olabilir..<br /> Bu seçeneği işaretlemiyorsanız, sistem her zaman küçük resmi oluşturmaya çalışacaktır (sabit bir bellek miktarıyla). Bu, daha fazla beyaz ekran hatasına neden olabilir.';
$helptxt['max_image_height'] = 'Eklenmiş resimlerin gösterilecek maksimum yüksekliği';
$helptxt['max_image_width'] = 'Bu, iletilerde görüntülenen resimler için maksimum boyutu ayarlamanızı sağlar. Maksimumdan küçük resimler etkilenmeyecektir. Bu aynı zamanda küçük resim üzerine tıklandığında ekli görüntülerin nasıl görüntüleneceğini belirler.';
$helptxt['attachmentUploadDir'] = 'Yüklenen dosyaların sunucunuzda nerede saklanacağını seçin. Ek güvenlik için public html dizininizin dışında olabilir.';
$helptxt['attachment_transfer_empty'] = 'Bu etkinleştirildiğinde, tüm dosyalar kaynak dizinden yeni konumuna taşınır, aksi takdirde yalnızca dizin başı ayarına göre izin verilen maksimum dosya sayısı taşınır.';
$helptxt['avatar_paranoid'] = 'Yüklenen avatarlarda sıkı güvenlik denetlemelerini aktifleştirir. Dikkat! Bu kapsamlı denetlemeler geçerli resimlerde bile hata verebilir. ElkArte, güvenlik kontrollerini geçemeyen görüntüleri yeniden örneklemeye çalışmak için yalnızca  bu seçeneği sadece avatar şifrelemesi seçeneğiyle kullanmanız önerilir. ';
$helptxt['avatar_reencode'] = 'Yüklenen avatarı tekrar şifreler. Resmi tekrar şifrelemek daha iyi güvenlik sağlar. Ancak bu seçenek, tüm hareketli resimleri duraklatır. <br /> Sadece GD modülü yüklü olan sunucularda çalışır.';
$helptxt['karmaMode'] = 'Karma bir üyenin popülerliğini göstermeye yarar. &quot;Karma&quot; vermek için gerekli olan ileti sayısını,
		karmalar arasında geçmesi gerek süreyi değiştirebilirsiniz.<br /><br />İzinlerden gerekli ayarlarda yapılabilir.';
$helptxt['localCookies'] = 'Sistem giriş bilgilerinizin saklanması için çerez yükler bilgisayarınıza.
	çerez ler genel ayarla (myserver.com) veya yerel (myserver.com/path/to/forum) olarak saklanabilir.<br />
	Eğer otomatik olarak çıkış problemi yaşıyorsanız bu seçeneği kontrol ediniz.<hr />
	Genel olarak kullanılan cookieler paylaşılan web sunucular tarafından kullanıldığı zaman daha az güvenli olurlar (bkz. Tripod)<hr />
	Yerel çerezler belirtildiği dosyanın dışında çalışmaz, eğer forumunuz örneğin www.myserver.com/forum de kuruluysa www.myserver.com/index.php  gibi sayfalar bilgilerinize ulaşamaz.
	Özellikle SSI.php yi kullanırken, genel çerezler tercih edilir.';
$helptxt['enableBBC'] = 'Bu seçeneği aktif etmek kullanıcıların ileti gönderirken BBC kullanmasına olanak sağlayarak, iletilerini resimlerle ve değişik yazı tipleriyle renklendirmelerine olanak tanıyacaktır.';
$helptxt['time_offset'] = 'Tüm forum adminleri forumlarının aynı GMT ayarları üzerinde kullanımını isterler. Bu seçenek sayesinde + veya - saatler belirterek GMT yi belirleyebilirsiniz.';
$helptxt['default_timezone'] = 'Sunucu zaman dilimi ayarı PHP\'ye sunucunuzun bulunduğu yeri bildirir. Bunu doğru ayarlamanız gerekir. Daha fazla bilgi için <a href="http://www.php.net/manual/en/timezones.php" target="_blank">PHP Sitesi</a>.';
$helptxt['spamWaitTime'] = 'Gönderilen iletiler arasında beklenilmesi gereken süreyi belirtiniz. Bu özellik sürekli gereksiz ileti gönderen kullanıcıları bir nevi olsun durdurabilir.';

$helptxt['enablePostHTML'] = 'Bazı HTML biçimlerinin kullanılabilmesini sağlar:
		<ul class="normallist enablePostHTML">
		<li>&lt;b&gt;, &lt;u&gt;, &lt;i&gt;, &lt;s&gt;, &lt;em&gt;, &lt;ins&gt;, &lt;del&gt;</li>
		<li>&lt;a href=&quot;&quot;&gt;</li>
		<li>&lt;img src=&quot;&quot; alt=&quot;&quot; /&gt;</li>
		<li>&lt;br /&gt;, &lt;hr /&gt;</li>
		<li>&lt;pre&gt;, &lt;blockquote&gt;</li>
	</ul>';

// Initial theme settings - Manage and Install
$helptxt['themes'] = 'Burada, varsayılan temanın seçilebileceğini, misafirlerin hangi temayı kullanacağı ve diğer seçenekler arasından seçim yapmayı seçebilirsiniz. Ayarlarını değiştirmek için sağdaki bir temayı tıklayın.';
$helptxt['theme_install'] = 'Bu bölüm  yeni temalar yüklemenize izin verir. Bunu, kişisel bilgisayardan temaya arşivlenen bir dosya yükleyerek, ana sunucuda bir tema dizininden kurarak veya varsayılan temayı kopyalayıp kopyalanan dosyayı yeniden adlandırarak gerçekleştirin.<br /><br /> Lütfen şunu unutmayın: sıkıştırılmış arşiv dosyası  veya dizinin bir <span class="alert">theme_info.xml</span>  dosyası içermesi gerekir. Tanım dosyası temanın bir parçası olmalı.';
$helptxt['theme_forum_theme'] = 'Forum varsayılanının değiştirilmesi, mevcut başka bir tema seçmiş üyeleri etkilemez. Ayrıca, onları yeni forum varsayılanına zorlamak için tüm üyeleri \'Sıfırla\' yapmanız gerekir. Ziyaretçiler tarafından görülen ve ardından üyeleri farklı bir temaya getiren forum varsayılan temasını da ayarlayabilirsiniz. <br /> <br /> Kendi temalarını seçme izni verildiğinde, üyeler sizin belirlediğiniz temayı geçersiz kılabilirler.';

// Theme Management and Options - Theme settings
$helptxt['themeadmin_list_reset'] = 'Nadiren, temanın yolu kaybolabilir ve forumunuz düzgün şekilde görüntülenmeyebilir. Bu, Yönetici, veritabanı hataları, başarısız yazılım güncellemeleri, mod kurulumları veya başka bir olay tarafından yapılan bir hata olabilir. Temaları sıfırlamak URL\'leri ve dizin sorunlarını çözecektir.';
$helptxt['themeadmin_delete_help'] = 'Varsayılan tema, forumunuza zarar verecek ve diğer temaları kırdığı için silinemez. Bununla birlikte, yanındaki kırmızı \'X\' işaretine sahip herhangi bir temayı, \'X\' işaretini tıklayarak silebilirsiniz. <br /> <br /> Unutmayın: Bir temayı silmek, sunucudan kaldırmaz, yalnızca forumda kullanılacak temaların kullanılabilirliğini kaldırır. Özel temayı sunucudan kaldırmak için sunucunuza FTP göndermeniz veya ana bilgisayar tarafından sağlanan paneli kullanmanız gerekir. \'Varsayılan\' adlı temayı hiç silmeyin.';

$helptxt['enableVideoEmbeding'] = 'Konu görünümünde video linklerinin otomatik dönüştürülmesini sağlar. Şu anda yalnızca YouTube, Vimeo ve Dailymotion video bağlantılarını destekliyor.';
$helptxt['enableCodePrettify'] = 'Kod etiketlerinde arasında kullanılan kodları renklendirir. Kod snippet\'lerine stiller ekleyerek belirteçlerin öne çıkmasını sağlar ve kullanıcılarınız kodu daha kolay okuyabilir.';
// @todo Add more information about how to use them here.
$helptxt['xmlnews_enable'] = 'Kullanıcıların <a href="%1$s?action=.xml;sa=news" target="_blank" class="new_win">En son haberler</a>\'a link verebilmelerini sağlar.
	En son haberlerin sayısının kısıtlanması tavsiye edilir, çünkü Trillian gibi programlarda RSS data
	gösterilmeye çalışıldığı zaman haberlerin tepeleri kesilir';
$helptxt['hotTopicPosts'] = 'Change the number of posts for a topic to reach the state of a &quot;hot&quot; or
	&quot;very hot&quot; topic.  Select the likes option to base this state on the number of likes instead of the number of posts';
$helptxt['globalCookies'] = 'Subdomainlerin bağımsız çerezler kullanabilmesini sağlar.  Örneğin, eğer...<br />
	Sizin siteniz http://www.myserver.com/ da ise,<br />
	ve forumunuzda http://forum.myserver.com/ da kayıtlıysa,<br />
	bu değişikliği kullanarak forumunuzun çerezini kullanabilmenizi sağlayacak.
Eğer sizin tarafınızdan kontrol edilmeyen diğer alt alanlar (hacker.elkarte.net gibi) varsa bunu etkinleştirmeyin. <br /> 
Bu seçenek, yerel çerezler etkinleştirildiğinde çalışmaz.';
$helptxt['globalCookiesDomain'] = 'Define the main domain to be used when login cookies are available across subdomains';
$helptxt['httponlyCookies'] = 'Bu ayar açıkken, çerezlere JavaScript gibi komut dosyası dilleri erişemez. Bu ayar, XSS saldırıları yoluyla kimlik hırsızlığını azaltmaya yardımcı olabilir. Bu, bazı üçüncü taraf komut dosyalarıyla ilgili sorunlara neden olabilir ancak mümkün olduğunda açık olması önerilir.';
$helptxt['secureCookies'] = 'Bu özelliği aktive etmeniz kullanıcılar tarafından yaratılan çerezleri güvenceye alacaktır. Bu özellik sadece HTTPS kullanan siteler için geçerlidir aksi taktirde çerez yönetimini bozacaktır!';
$helptxt['admin_session_lifetime'] = 'Bu ayar, bir yönetici oturumunun etkin kalabileceği süreyi belirler. Bu süre dolduktan sonra oturum sona erecek ve yönetici alanına erişmeye devam etmek için yönetici kimlik bilgilerinizi girmeniz istenecektir. Minimum değer 5 dakikadır, izin verilen maksimum değer 14400 dakikadır (bir güne eşittir). Güvenlik nedenlerinden ötürü 60 dakikanın altında bir değer kullanılması şiddetle önerilir.';
$helptxt['auto_admin_session'] = 'This controls whether an administrative session is activated during logon or not.';
$helptxt['securityDisable'] = 'Yönetim paneline girmek için sorulan şifre kontrolünü <em>devre dışı bırakır</em>. Tavsiye edilmemektedir!';
$helptxt['securityDisable_why'] = 'Bu sizin şuan kullandığınız şifredir.<br /><br />Bu kontrolün yapılması yapılan tüm işlemlerin <strong>sizin</strong> tarafınızdan yapıldığından emin olmak içindir.';
$helptxt['securityDisable_moderate'] = 'Bu, moderatör alanı için ek şifre denetimini <em>devre dışı</em> bırakır. Önerilmez!';
$helptxt['securityDisable_moderate_why'] = 'This is your current password. (the same one you use to login.)<br /><br />Having to type this helps ensure that you want to do whatever moderation you are doing, and that it is <strong>you</strong> doing it.';
$helptxt['enableOTP'] = 'Enabling this feature allows another layer of security for a member\'s account. Two-factor authentication, or 2FA, is a way of logging into websites that requires more than just a password. Using a password to log into a website is susceptible to security threats, because it represents a single piece of information a malicious person needs to acquire. The added security that 2FA provides is requiring additional information to sign in.<br /><br />A Time-based One-Time Password (TOTP) application such as Google Authenticator or Authy automatically generates an authentication code that changes after a certain period of time.';
$helptxt['emailmembers'] = 'Mesajınızda  birkaç &quot;değişken&quot; kullanabilirsiniz. Bunlar: <br /> 
{$ board_url} - Forumunuzun URL\'si. <br />
{$ current_time} - Geçerli süre. <br />
{$ member.email} - Mevcut üyenin e-postası. <br />
 {$ member.link} - Geçerli üyenin linki. <br />
{$ member.id} - Geçerli üyenin kimliği. <br />
{$ member.name} - Geçerli üyenin adı. (Kişiselleştirme için.) <br />
{$ latest_member.link} - En yakın zamanda kayıtlı üye bağlantı. <br />
{$ latest_member.id} - En son kayıt edilen üyenin kimliğidir. <br />
{$ latest_member.name} - En yakın zamanda üye olan üyenin adı.';
$helptxt['attachmentEncryptFilenames'] = 'Ek dosya adlarını şifrelemek, aynı ismin birden fazla eklenmesine izin verir ve güvenliği artırır. Bununla birlikte, ciddi bir şey olursa, veritabanınızı yeniden yapılandırmanın daha zor olmasına neden olabilir.';

$helptxt['failed_login_threshold'] = 'Şifre Hatırlatma ekranına iletilmeden önce yapılabilecek yanlış şifre girişimlerinin sayısı.';
$helptxt['loginHistoryDays'] = 'Kullanıcı profili geçmişi altında giriş geçmişi tutmak için gün sayısı. Varsayılan değer 30 gündür';
$helptxt['oldTopicDays'] = 'Eğer bu seçenek aktif edilirse, ayarlanmış zaman\'dan sonra bir konuya bir cevap yazılması durumunda kullanıcı bir uyarı iletisi alacaktır. Buradaki veri giriş türü gün\'dür, örneğin konu cevap süresini maksimum bir hafta yapmak için rakamı 7 olarak, seçeneği devre dışı bırakmak için değeri 0 olarak girebilirsiniz.';
$helptxt['edit_wait_time'] = 'Bir iletinin gönderildikten sonra ne kadar zamana kadar tekrar düzenlenebileceğini gösteren zaman(saniye).';
$helptxt['edit_disable_time'] = 'Bir kullanıcının iletisini düzenleyebileceği maksimum süre. Devre dışı bırakmak için 0 olarak ayarlayın. <br /><br /><i>Note: This will not effect any user who has permission to edit other peoples posts.</i>';
$helptxt['preview_characters'] = 'This option sets the number of available characters for the first and last message of the topic preview.  <strong>Note</strong> this only makes the information available to the theme, the theme must support the &quot;Show post previews on the message index&quot; setting';
$helptxt['posts_require_captcha'] = 'İletiler için resim doğrulamasını aktif eder.';
$helptxt['enableSpellChecking'] = 'Enable spell checking. You MUST have the pspell library installed on your server and your PHP configuration set up to use the pspell library. Your server ' . (function_exists('pspell_new') ? 'DOES' : 'DOES NOT') . ' appear to have this set up.';
$helptxt['lastActive'] = 'Ana sayfada aktif olarak gösterilecek kullanıcılar için süre belirleyiniz. Varsayılan 15 dakikadır.';

$helptxt['customoptions'] = 'Bu bölüm kullanıcıların açılan bir listeden farklı seçenekler seçebilmesini sağlar.
	<ul class="normallist">
		<li><strong>Varsayılan Ayar:</strong>Hangi ayar kutusunun yanında &quot;radio butonu&quot; varsa üye profilini girdiğinde varsayılan seçenek olacaktır.</li>
		<li><strong>Ayarları Kaldırma:</strong>Bir ayarı kaldırmak için sadece metin kutusunu boşaltın - bu seçeneği seçmis üyelerin bu ayarı silinecektir.</li>
		<li><strong>Ayarları Sıralamak:</strong>Metinleri kutuların arasına taşıyarak sıralayabilirsiniz.Ancak - önemli not - ayarları sıralarken metinleri <strong>sakın değiştirmeyin</strong>. Değiştirirseniz tüm üye bilgileri kaybolacaktır.</li>
	</ul>';

$helptxt['autoOptDatabase'] = 'Veritabanını günaşırı optimize eder. Bu kontrolü her gün yapmasını istiyorsanız 1 i seçin. Maksimum online kullanıcı sayısınıda sınırlandırabilirsiniz bu sayede serverınızda aşırı yüklenmeyi önleyebilirsiniz.';
$helptxt['autoFixDatabase'] = 'Otomatik olarak hatalı tabloları düzeltir ve hiçbirşey olmamış gibi devam eder.  Yararlı olabilir çünkü forumunuza zarar vermeden önce kolaylıkla bu riskten kurtulabilirsiniz.  İşlem bittiği zaman size mail gönderilir.';

$helptxt['enableParticipation'] = 'Kullanıcının ileti gönderdiği konuların üzerinde küçük bir ikon belirir.';
$helptxt['enableFollowup'] = 'Bu ayar, üyelerin herhangi bir konunun metnini alıntılayarak yeni konu başlamasına izin verir.';

$helptxt['db_persist'] = 'Performansı arttırmak için bağlantıyı aktif kılar.  Servera bağlı değilseniz host ile aranızda sorun meydana getirebilir.';
$helptxt['ssi_db_user'] = 'SSI.php ile bağlıyken farklı veritabanı erişim bilgileri kullanılabilmesine olanak tanır.';

$helptxt['queryless_urls'] = 'URL formatlarını bir ölçüde değiştirir bu sayede daha kullanışlı aramalar yapılabilir. Şu şekilde görünürler index.php/topic,1.0.html.';
$helptxt['countChildPosts'] = 'Bu seçeneği seçtiğiniz takdirde alt bölümlerin ileti sayısı, üst bölümün ileti sayısına dahil edilecektir. Bu işlem biraz ek yük getirsede üst bölümde hiç konu yoksa ileti sayısı \'0\' görünmeyecektir.';
$helptxt['allow_ignore_boards'] = 'Bu özellik kullanıcıların belli bölümlerini yoksayabilmelerine olanak tanır.';
$helptxt['deny_boards_access'] = 'Bu seçeneğin işaretlenmesi,  üye grubu bazlı bölüm engeli koymaya izni verecektir';

$helptxt['who_enabled'] = 'Forumda kimin ne yaptığını görmenizi sağlar.';

$helptxt['recycle_enable'] = '&quot;Çöp Kutusu&quot; silinen iletiler veya konular bu odaya gönderilir.';

$helptxt['enableReportPM'] = 'Bu özellik kullanıcıların aldıkları kişisel iletileri yöneticilere şikayet edebilmelerine olanak tanımaktadır.';
$helptxt['max_pm_recipients'] = 'Bu özellik kişisel ileti gönderilirken, sönderilecek kişi sayısını sınırlamanızı sağlar. Limiti kaldırmak için 0 yapın.';
$helptxt['pm_posts_verification'] = 'Bu seçenek kişisel ilet gönderilirken resim doğrulamasını zorunlu kılar.';
$helptxt['pm_posts_per_hour'] = 'Bir saat içinde gönderilecek kişiel ileti sayısını sınırlar.';

$helptxt['default_personal_text'] = 'Sets the default text a new user will have as their &quot;personal text.&quot; This option is not available when personal text is disabled, or when users can set their personal text on registration for themselves.';

$helptxt['modlog_enabled'] = 'Tüm moderatör hareketlerini kaydet.';

$helptxt['registration_method'] = 'Bu seçenek foruma katılmak isteyen insanların nasıl kayıt olabileceğini belirlemenizi sağlar. Seçebileceğiniz:<br /><br /> 

 <ul class="normallist">  
<li>  
<strong>Üyelik Devre Dışı</strong><br />  
Üyelik işlemini devre dışı bırakır, bu demektir ki forumunuza kimse üye olarak katılamaz.<br />  </li>

<li>  <strong>Anında Kayıt</strong><br /> 

 Yeni üyeler kayıt olduktan hemen sonra giriş yapabilir ve ileti gönderebilir.<br />  </li>

<li>  <strong>Eposta Aktivasyonu</strong><br />  

Bu seçenek aktifleştirildiğinde her hangi bir üyenin foruma kayıt olduktan sonra tam üye konumuna geçmesi için eposta adreslerine gönderilen aktivasyon linkine tıklamaları gerekmektedir.<br />  </li>

<li>  <strong>Admin Onaylı</strong><br />  Bu seçenek forumunuza kayıt olan tüm yeni üyelerin, üye olabilmeleri için yönetici tarafından onaylanmasını gerektirir. </li> 

</ul> ';
$helptxt['register_openid'] = '<strong>Authenticate with OpenID</strong><br />
	OpenID allows you to use the same user credentials across different websites to simplify your online experience. To use OpenID you first need to create an OpenID account - a list of providers can be found on the <a href="http://openid.net/" target="_blank">OpenID Official Site</a><br /><br />
	Once you have an OpenID account simply enter your unique identification URL into the OpenID input box and submit. You will then be taken to your provider\'s site to verify your identity before being passed back to this site.<br /><br />
	On your first visit to this site you will be asked to supply a couple of details before you will be recognized, after which you can login to this site and change your profile settings using just your OpenID.<br /><br />
	For more information please visit the <a href="http://openid.net/" target="_blank">OpenID Official Site</a>';

$helptxt['send_validation_onChange'] = 'When this option is checked all members who change their email address in their profile will have to reactivate their account from an email sent to the new address';
$helptxt['send_welcomeEmail'] = 'Yeni gelen üyelere HOŞGELDİNİZ maili gönderilir.';
$helptxt['password_strength'] = 'Bu seçenek üyelerin şifreleri için gerekli olan şifre karmaşıklığını ayarlamanızı sağlar. Şifre karmaşıklaştıkça, kırmak da o kadar zorlaşır.

Olası seçenekler şunlardır:

<ul class="normallist">

<li><strong>Düşük:</strong> Parola en az dört karakter uzunluğunda olmalıdır.</li>

<li><strong>Orta:</strong> En az sekiz karakter uzunluğunda olmalı  kullanıcı adı veya e-posta adresini içeremez</li>

<li><strong>Yüksek:</strong> Değişik büyük, küçük karakterlerin karışımı olmalıdır. En az bir küçük veya büyük harf olmalı</li>
</ul>';
$helptxt['enable_password_conversion'] = 'Bu ayarı etkinleştirdiğinizde,  ElkArte başka formatlarda kaydedilmiş şifreleri bularak onları ElkArte\'nin kullandığı formata çevirecektir. Genellikle bu dönüştürülmüş forumlar tarafından kullanılır, fakat bunun farklı kullanımları da mevcuttur. Bunun devre dışı bırakılması, dönüştürme sonucu kullanıcıların şifrelerini kullanarak foruma girişlerini engelleyecektir ve kullanıcıların şifrelerini değiştirmelerini gerektirir.';

$helptxt['coppaAge'] = 'Bu kutuda belirtilen değer, siteye üye olabilecek kişilerinin minimum yaşlarını belirtecektir.
	Yaşı belirlenmiş değerin altında olanlar ayarlarda seçilen seçeneğe bağlı olarak ya ebeveyinlerinden izin almak zorunda olacak yada forum\'a üye olamayacaklardır.
	Burada değer 0 olarak girildiği takdirde tüm yaş sınırlamaları kaldırılacaktır.';
$helptxt['coppaType'] = 'Eğer yaş sınırlaması aktif ise, akabinde belirlenen yaşın altındaki kişinin foruma üyeliği konusunda olucakları içerir. Bu alanda iki seçenek yer alır: <ul class="normallist"> <li> <strong>Kaydı reddet:</strong><br /> Yeni üyelik yapıcak olan bu kişilerin üyelikleri direkt olarak reddedilir.<br /> </li><li> <strong>Koruyucu veya Aile onayı</strong><br /> Kayıt olmak isteyen belirlenmiş yaşın altındaki üyeler bekletilir, ve ebeveynleri tarafından foruma üye olabileceğine dair bir onay formu alınır. Ayrıca kullanılan iletişim bilgileri aracılığı ile ulaşacaklardır,yani onay formu adminlere mail veya fax yolu ile gönderilebilir. </li> </ul>';
$helptxt['coppaPost'] = 'İletişim kutuları ebeveyinlerin çocuklarının siteye erişimini onaylaması için forum yöneticilerine onay göndermeleri için gereklidir. En az bir posta adresi veya faks numarası verilmelidir.';

$helptxt['allow_hideOnline'] = 'Üyeler diğer üyelerden online olduklarını gizleyebilirler (yöneticiler hariç). Bu özellik kapatılması durumunda sadece yöneticiler ve moderatörler tarafından kullanılabilecektir.  Bu seçeneğin devre dışı bırakılmasının herhangi bir üyenin şu anki durumunu değiştirmeyeceğini unutmayın.';

$helptxt['latest_support'] = 'Bu panel size sunucu yapılandırmanızla ilgili en yaygın sorunlardan ve soruların bir kısmını gösterir. Endişelenmeyin, bu bilgiler günlüğe kaydedilmemiştir. <br /> <br /> Eğer bu durum &quot; Destekleme bilgileri alınıyor ... &quot; olarak kalırsa, bilgisayarınız muhtemelen web sitesine bağlanamıyordur.';
$helptxt['latest_packages'] = 'Here you can see some of the most popular and some random packages, with quick and easy installations.<br /><br />If this section doesn\'t show up, your computer probably cannot connect to <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.';
$helptxt['latest_themes'] = 'This area shows a few of the latest and most popular themes from <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>.  It may not show up properly if your computer can\'t find <a href="https://www.elkarte.net/" target="_blank" class="new_win">www.elkarte.net/</a>, though.';

$helptxt['secret_why_blank'] = 'Sizin güvenliğiniz için verilen cevap ve şifre otomatik olarak şifrelenir ve hiç bir koşulda kimseye verilmez.';
$helptxt['moderator_why_missing'] = 'Moderasyon bölüm bölüm yapıldığından, üyelerinizi <a href="%1$s?action=admin;area=manageboards" target="_blank" class="new_win">bölüm yönetim arayüzünden</a> moderatör yapmalısınız.';

$helptxt['permissions'] = 'İzinler size belirli konular hakkında yasaklama,izin verme gibi haklar sağlar.<br /><br />İzinleri kutulara tik atarak kolaylık belirleyebilir ve \'Düzenle. tuşu ile bitirebilirsiniz.';
$helptxt['permissions_board'] = 'Eğer bir oda  \'Genel,\' olarak belirtildiyse bu oda herkes tarafından görülebilir.  \'Yerel\' özel izinler karşılığında görülebilen ve girilebilen odaları belirtir.';
$helptxt['permissions_quickgroups'] = 'Bunlar size &quot;varsayılan&quot; izinlerin yapılandırılmasındada yardımcı olur - standart \'özel bir şey yok\' anlamına gelir, kısıtlı ise \'ziyaretçi gibi\' manasına gelir, moderatör \'moderatör ne yaparsa\'anlamına gelir, ve son olarak \'bakım\' admin seviyesine en yakın gruptur.';
$helptxt['permission_enable_deny'] = 'İzinleri yasaklamak belli üyelere forum\'da belli eylemleri yasaklamak istediğiniz zaman size çok yardımcı olabilirler.<br /><br />Belli üyelere yasaklama getirmek için onlar için bir üye grubu yaratın ve izinlerini yasaklayıp üyeleri bu gruba dahil edin. Unutmayın eğer bir üye bir izni yasaklanmış bir gruba dahilse, diğer gruplardan hangi haklar gelirse gelsin yasaklanmış hakkını kullanamayacaktır.';
$helptxt['permission_enable_postgroups'] = 'İletiye bağlı gruplar için izin ayarlanmasını aktif etmek, belli ileti sayısındaki kullanıcılara belli izinleri vermenizi sağlayacaktır. Bu gruplardan alınan yeni izinler ana üye grubunun izinlerine <em>eklenecektir</em>.';
$helptxt['membergroup_guests'] = 'Ziyaretçiler, forum\'a giriş yapmamış tüm kullanıcıları içeren gruptur.';
$helptxt['membergroup_regular_members'] = 'Normal üyeler forum\'a giriş yapmış ama herhangi bir üye grubuna dahil edilmemiş üyelerdir.';
$helptxt['membergroup_administrator'] = 'Yöneticiler forum\'da tüm bölümleri görebilir istedikleri her şeyi yapabilmektedirler. Yöneticiler için izin sınırlaması yapılamamaktadır.';
$helptxt['membergroup_moderator'] = 'Moderatör grubu özel bir üye grubudur. <em>Sadece moderatörü oldukları bölümlerde</em> belli başlı izinlere sahiplerdir. Bu bölümleri dışında diğer üyelerden bir farkları yoktur. Lütfen unutmayın bir bölümü yönetmek için atanan gruplar için de aynı izinler uygulanacaktır.';
$helptxt['membergroups'] = 'Üyelerinizin ayrıldığı iki çeşit grup vardır. Bunlar:
	<ul class="normallist">
		<li><strong>Düzenli Gruplar:</strong> Düzenli gruplar &quot;Üyelik Ayarları&quot;ndan girilerek yapılabilir.Bu sayede üyeleri istediğini sayıda düzenli gruba üye yapabilirsiniz.</li>
		<li><strong>İleti Yapılı Gruplar:</strong> Düzenli grupların aksine üyeler atanamaz. Grubun minimum ileti sayısına ulaşan üye o gruba girmiş olur.</li>
	</ul>';

$helptxt['calendar_how_edit'] = 'Olayları isimlerinin sağ tarafında bulunan kırmızı (*) işarete tıklayarak düzenleyebilirsiniz.';

$helptxt['maintenance_backup'] = 'Forumunuzdaki tüm bilgileri büyük bir dosya halinde kopyalamanızı sağlar.<br /><br />Haftalık olarak güvenliğiniz açısından yapılmasını tavsiye ederiz.';
$helptxt['maintenance_rot'] = 'Bu seçenek <strong>Geri Dönülemeyecek Şekilde</strong> eski konularınızı silmenizi sağlar. Herhangi birşey yapmadan önce forumunuzun yedeğini almanız önerilir. <br /><br />Bu seçeneği dikkatli kullanmalısınız.';
$helptxt['maintenance_members'] = 'Bu forumunuzdan üye hesaplarını <strong>tamamen</strong> silebilmenizi sağlar. <strong>İstenmeyen sonuçlarla</strong> karşılaşmamak için yedek almanız önerilir.<br /><br /> Bu seçeneği dikkatli kullanmalısınız.';

$helptxt['avatar_default'] = 'Bu seçenek etkinleştirildiğinde, kendi avatarına sahip olmayan tüm kullanıcılar için varsayılan bir avatar gösterilir. \'default_avatar.png\' adlı dosya, temalar dizininin içindeki images klasöründe bulunur.';
$helptxt['avatar_server_stored'] = 'Kullanıcıların avatarlarını sunucunuzdan seçmesini sağlar<br />Eğer  avatarlar klasörü içine dizinler oluşturursanız avatar &quot;kategorisi&quot; yapabilirsiniz.';
$helptxt['avatar_external'] = 'Başka adreslerden link verilmesini ve avatarlarda kullanılabilmeyi sağlar.';
$helptxt['avatar_download_external'] = 'Bu özellik seçilirse, karşı bir sunucudan avatar bu sunucuya transfer edilir ve öntanımlı boyuta küçültülür.';
$helptxt['avatar_upload'] = 'Bu seçenek üyelerinizin avatlarını sizin sunucunuza yüklemelerine olanak tanır. Bu sayede avatarları yeniden boyutlandırabilirsiniz.<br /><br />Bu seçeneğin kötü bir etkisi ise sunucunuzdaki yer kullanımını artıracak olmasıdır.';
$helptxt['avatar_resize_options'] = 'Bu seçenekler, yüklenen veya harici bir URL\'den alınan kullanıcıların sunucuya yüklediği avatarlar için geçerlidir.';
$helptxt['avatar_download_png'] = 'PNG dosyaları daha büyük boyutlu ancak daha kaliteli resim formatıdır. Bu seçenek seçilmediği takdirde JPEG- daha küçük ancak daha az kaliteli- resimler kullanılacaktır.';
$helptxt['gravatar'] = 'Gravatar (küresel olarak tanınan avatar), küresel olarak benzersiz görüntü sağlayan bir hizmettir. Daha fazla bilgi için lütfen Gravatar <a href="http://www.gravatar.com" target="_blank"><strong> web sitesi</strong>.</a> adresini ziyaret edin.';
$helptxt['gravatar_rating'] = 'Gravatar, kullanıcıların resimlerini belirli bir izleyiciye uygun olup olmadığını gösterebilmeleri için kendi görüntü oranlarına göre ayarlamalarına izin verir. Varsayılan olarak, daha yüksek derecelendirmeler görmek istediğinizi belirtmedikçe yalnızca \'G\' dereceli görüntüler görüntülenir. <br /> <br /> <ul> <li> <strong> G: </strong> herhangi bir kitle türüne sahip tüm web sitelerinde gösterilmeye uygundur. </ li> <li> <strong> pg: </strong> </li> <li> <strong> R: </strong> sert kaba, şiddetli şiddet, çıplaklık veya sert uyuşturucu gibi şeyleri içerebilir, kaba sözler, kışkırtıcı giyimli kişiler, daha az küfür sözleri veya hafif şiddet içeriyor olabilir. </li> <li> <strong> X: </strong>, sert cinsel imaj veya aşırı derecede rahatsız edici şiddet içeriyor olabilir. </li> </ ul>';
$helptxt['custom_avatar_enabled'] = 'Avatarı olan sayfaları görüntülerken işlemci yükünü ve veritabanı yükünü azaltacağı için bunu en iyi performans için etkinleştirmeniz önerilir. <br /> Hem avatarları kaydetmek için genel olarak erişilebilir bir dizin hem de genel olarak erişilebilir URL\'yi girmeniz gerekir Bu dizin. Örneğin, / home / kendi kaynak adınız / public_html / NewAvatarDirectory dizininizin bir URL\'si ve http://www.yourforumname.com/NewAvatarDirectory adresinin bir URL\'si.';
$helptxt['disableHostnameLookup'] = 'Host isimlerinin bakılmasını kaldıracaktır.';

$helptxt['search_weight_commonheader'] = 'Weight factors are used to determine the relevancy of a search result. Change these weight factors to match the things that are specifically important for your forum. For instance, a forum of a news site might want a relatively high value for \'age of last matching message\'. All values are relative in relation to each other and should be positive integers.';
$helptxt['search_weight_frequency'] = 'Bu faktör, eşleşen mesajların sayısını sayar ve bir konudaki toplam mesaj sayısına böler.';
$helptxt['search_weight_age'] = 'Bu faktör, bir konudaki en son eşleşen mesajın yaşını değerlendirir. Bu mesaj ne kadar yeni olursa puan da o kadar yüksek olur.';
$helptxt['search_weight_length'] = 'Bu faktör, konu boyutuna dayanmaktadır. Konudaki mesaj sayısı arttıkça puan da artar.';
$helptxt['search_weight_subject'] = 'Bu faktör, bir konunun  içinde arama teriminin bulunup bulunamayacağına bakar.';
$helptxt['search_weight_first_message'] = 'Bu faktör, bir konunun ilk mesajında bir eşleşme bulunup bulunamayacağına bakar.';
$helptxt['search_weight_sticky'] = 'Bu faktör, bir konunun sabitlenmiş olup olmadığına bakar ve varsa, alaka puanını artırır.';
$helptxt['search_weight_likes'] = 'This factor looks whether a topic has likes and increases the relevancy score based on the number.';
$helptxt['search'] = 'Arama ile ilgili tüm seçenekleri burada ayarlayabilirsiniz.';
$helptxt['search_why_use_index'] = 'Arama dizini, forumunuzdaki aramaların performansını önemli ölçüde artırabilir. Özellikle bir forumdaki mesaj sayısı arttıkça, bir endeks olmadan arama uzun sürebilir ve veritabanınız üzerindeki baskıyı artırabilir. Forumunuz 50.000 iletiden daha büyükse, forumunuzda en üst düzeyde performans sağlamak için bir arama dizini oluşturmayı düşünmelisiniz. <br /> <br /> Bir arama dizininin biraz yer kaplayabileceğini unutmayın. Tam metin dizini, veritabanının dahili bir dizinidir. Oldukça kompakt (mesaj tablosu ile yaklaşık aynı boyutta), ancak bir çok ortak kelime dizine eklenmedi ve bazı joker sorgularda yavaş olabiliyor. Özel dizin daha büyük (yapılandırmanıza bağlı olarak ileti tablosunun boyutunun 3 katına kadar çıkabiliyor), ancak performansı çoğu zaman tam metinlerden daha iyi ve çoğu kelimeyi dizine ekiyor.';

$helptxt['see_admin_ip'] = 'IP adresleri moderatörler ve adminler tarafından görülebilir. Bu özellik yetkili kişilerin kullanıcıları daha rahat takip ederek, forumun yapısını korumalarına yardımcı olur. Unutmayın IP adresleri her zaman kişileri göstermez çünkü çoğu kullanıcının IP si belirli aralıklarla değişir.<br /><br />Kullanıcıların kendi IP lerini görebilmeleride sağlanmıştır.';
$helptxt['see_member_ip'] = 'IP adresiniz sadece siz ve moderatörler tarafından görülebilir, diğer kullanıcılar sizin IP\'nizi göremezler. Unutmayın bu bilgi kimliğini ortaya çıkarmaz, ve çoğu IP dinamiktir yani devamlı değişirler.<br /><br />Ne siz diğer kullanıcıların IP adreslerini görebilirsiniz, ne de onlar sizin IP adresinizi görebilirler.';
$helptxt['whytwoip'] = 'Kullanıcı IP adreslerini tespit etmek için çeşitli yöntemler kullanılır. Genellikle bu iki yöntem aynı adresle sonuçlanır, ancak bazı durumlarda birden fazla adres tespit edilebilir. Bu durumda, her iki adres günlüğe kaydedilir ve her ikisi de yasaklama çekleri için kullanılır (vb.). IP\'yi izlemek için herhangi bir adresi tıklayabilir, gerekirse banlayabilirsiniz.';

$helptxt['ban_cannot_post'] = '\'İleti Gönderme Engellemesi\', forum\'u yasaklanmış kullanıcı için sadece-okunulabilir bir hale getirir. Kullanıcı yeni konular açamaz, konulara cevap atamaz, özel iletiler gönderemez veya anketlerde oy kullanamaz. Ama engellenmiş kullanıcı kendi özel iletilerini ve diğer tüm konuları okuma hakkına hala sahiptir.<br /><br />Bu şekilde yasaklanmış kullanıcılara engellenmiş hareketleri yapmak istediklerinde bir uyarı gösterilir.';

$helptxt['posts_and_topics'] = '
<ul class="normallist">
		<li>
			<strong>İleti Ayarları</strong><br />
			İletilerin gönderilme ve gösterimleriyle ilgili ayarları düzenler. Aynı zamanda yazım denetimini de burada aktif edebilirsiniz.
		</li><li>
			<strong>Bulletin Board Code</strong><br />
			İletilerdeki görünümü değiştirebilen BBC kodları ile ilgili ayarları düzenleyin. Aynı zamanda buradan izin verilen/verilmeyen kodları seçebilirsiniz.
		</li><li>
			<strong>Sansürlü Kelimeler</strong>
			Forumdaki üslubu kontrol altında tutabilmek için, belli kelimeleri sansürleyebilirsiniz. Bu özellik forumdaki yasak kelimeleri zararsız keilemelere çeverimenizi sağlar.
		</li><li>
			<strong>Konu Ayarları</strong>
			Konularla ilgili ayarları düzenler. Örneğin, bir sayfada gösterilecek konu sayısı, sabit konulara izin veriliyor mu, verilmiyor mu, bir konunun beğenilen konu sayılması için kaç ileti gerektiği, vb.
		</li>
	</ul>';
$helptxt['allow_no_censored'] = 'İşaretlendiğinde, bu genel ayar, üyelerin Kullanıcı Profili\'ndeki kelime sansür özelliğini Görünüm ve Tasarım ayarlarıyla devre dışı bırakmalarını sağlar. Üyelerin sözcük sansürünü devre dışı bırakma kabiliyeti, izin profilleriyle sınırlıdır.';
$helptxt['spider_mode'] = 'Kayıt seviyesini ayarlar. <br />
Standard - En az örümcek aktivitesi kaydeder. <br />
Orta - Daha doğru istatistikler sağlar. <br />
Agresif - &quot;Orta dereceli&quot; Ancak ziyaret edilen her sayfa hakkında verileri günlüğe kaydeder.';

$helptxt['spider_group'] = 'Bu özelliği kullanarak arama motorlarına normal ziyaretçilerden daha kısıtlı veya daha fazla içerik gösterebilirsiniz';
$helptxt['show_spider_online'] = 'Bu seçenek arama örümceklerinin anasayfada ve &quot;Kimler Çevrimiçi&quot; sayfalarında görüntülenip görüntülenmeyeceğini belirtir. Seçenekler : <ul class="normallist"> <li> <strong>Gösterme</strong><br /> Örümceler hiçbir yerde ziyaretçi olarak gösterilmeyecek. </li><li> <strong>Örümcek sayısını göster</strong><br /> Forum anasayfasında oan kaç örümcek olduğu görüntülenecek. </li><li> <strong>Örümcek detayını göster</strong><br />Tüm örümcek isimleri görüntülenecek, böylece üyeleriniz hangi örümceklerde kaç tane olduğunu görebilecekler - forum anasayfasın ve kimler çevrim içi bölümümünün her ikisindede geçerli</li><li> <strong>Örümcek detayını göster - sadece yöneticilere</strong><br /> Sadece yöneticiler örümcek isimlerini görebilecek, diğer üyeler örümcekleri ziyaretçi olarak görecekler. </li> </ul> ';

$helptxt['birthday_email'] = 'Doğum günü için kullanılacak e-posta içeriğini seçiniz. Önizleme olarak E-posta içeriği ve başlığı gösterilecektir.<br /><strong>Not:</strong> Bu ayarı aktif ettiğinizde doğum günü kutlamalarının otomatik olarak göndermeyi aktif etmiş olmazsınız. Otomatik doğum günü E-postaları göndermek için <a href="%1$s?action=admin;area=scheduledtasks;%3$s=%2$s" target="_blank" class="new_win">Zamanlanmış Görevler</a> sayfasından Doğum Günü E-Postalarını aktifleştirmelisiniz.';
$helptxt['pm_bcc'] = 'Kişisel iletilerde birden fazla kişiyle (görünmez) ileti gönderilebilmsine olanak tanır.';

$helptxt['move_topics_maintenance'] = 'Bu tüm iletilerin bölümden bölüme taşınmasını sağlar.';
$helptxt['maintain_reattribute_posts'] = 'Bu özelliği kullanarak iletileri üyelere yeniden atayabilirsiniz, özellikle bir üyenin hesabını silindikten sonra eski iletilerinin hesabı ile tekrar ilişkilendirilmesi gerektiğinde faydalı olacaktır.';
$helptxt['chmod_flags'] = 'Seçilen dosyaları ayarlamak istediğiniz izinleri manuel olarak ayarlayabilirsiniz. Bunu yapmak için chmod değerini sayısal (sekizli) bir değer olarak girin. Bu bayrakların Microsoft Windows işletim sistemlerinde hiçbir etkisi olmayacağını unutmayın.';

$helptxt['postmod'] = 'Bu bölümde moderasyon  ekibi (yeterli izni olanlar) onay gerektiren konuları ve iletileri görünmeden önce onaylayabilirler.';

$helptxt['field_show_enclosed'] = 'Encloses the user input between some text or HTML code.  This will allow you to add more instant message providers, images or an embed, etc. For example:<br /><br />
		&lt;a href="http://website.com/{INPUT}"&gt;&lt;img src="{DEFAULT_IMAGES_URL}/icon.png" alt="{INPUT}" /&gt;&lt;/a&gt;<br /><br />
		You can use the following variables:<br />
		<ul class="normallist">
			<li>{INPUT} - The input specified by the user.</li>
			<li>{KEY} - The key specified for a certain value of select box or radio buttons in the admin panel. Usually to use in case of localization or use in CSS of Javascript elements (e.g. as class name).</li>
			<li>{SCRIPTURL} - Web address of forum.</li>
			<li>{IMAGES_URL} - URI of the images directory of the user\'s current theme.</li>
			<li>{DEFAULT_IMAGES_URL} - URI of the images directory of the default theme.</li>
		</ul>';

$helptxt['custom_mask'] = 'Giriş maskesi forumunuzun güvenliği için önemlidir. Bir üyeden gelen girdiyi onaylama, verinin sizin istemediğiniz gibi kullanılmadiğını kesinleştirir. Bazı basit düzenli ifadeler:<br /><br /> <div class="smalltext" style="margin: 0 2em"> &quot;&quot;"[A-Za-z]+" - Alfabenin tüm küçük ve büyük harfleriyle eşleşir.<br /> &quot;&quot;"[0-9]+" - Tüm sayılar ile eşleşir.<br /> &quot;&quot;"[A-Za-z0-9]{7}" -  Alfabenin tüm küçük ve büyük harfleriyle ve sayılar ile 7 defa eşleşir.<br /> &quot;&quot;"[^0-9]?" - Bir sayının eşleşmiş olmasını engeller.<br /> &quot;&quot;"^([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$" - Sadece 3 veya 6 hexcode karakterine izin verir.<br /> </div><br /><br /> Ayrıca, özel karakterler ?+*^$ ve {xx} karakterleri tanımlanabilir.  <div class="smalltext" style="margin: 0 2em"> &quot;&quot;? - önceki ifadeden 0 veya 1 eşleşme<br /> &quot;&quot;+ - önceki ifadeden 1 veya daha fazla<br /> &quot;&quot;* - önceki ifadeden 0 yada daha fazla<br /> &quot;&quot;{xx} - önceki ifadeyle aynı<br /> &quot;&quot;{xx,} - önceki ifadeyle aynı veya daha fazla<br /> &quot;&quot;{,xx} - önceki ifadeyle aynı veya daha az<br /> &quot;&quot;{xx,yy} - önceki ifadeden iki sayı arasında bir eşleşme<br /> &quot;&quot;$ - ifade baslangıcı.<br /> &quot;&quot;^ - ifade bitişi.<br /> &quot;&quot;\\ - yanındaki karakteri kurtarır.<br /> </div><br /><br /> İnternette daha fazla bilgiyi ve gelişmiş teknikleri bulabilirsiniz.';

$helptxt['badbehavior_reverse_proxy_addresses'] = 'In some server farm configurations, Bad Behavior may be unable to determine whether a remote request originated from your reverse proxy/load balancer or arrived directly. In this case you should add all of the internal IP addresses for your reverse proxy/load balancer servers as seen from the origin server. These can usually be omitted; however if you have a configuration where some requests can bypass the reverse proxy/load balancer and connect to the origin server directly, then you should use this option. You should also use this option when incoming requests pass through two or more reverse proxies before reaching the origin server.<br /><br />Enter each IP address or CIDR netblocks separated by a | (1.2.3.4|5.4.3.2/27)';
$helptxt['badbehavior_reverse_proxy_header'] = 'When a reverse proxy is in use, Bad Behavior looks at this HTTP header to determine the actual source IP address for each web request. Your reverse proxy or load balancer must add an HTTP header containing the remote IP address where the connection originated. Most do this by default; check the configuration for your reverse proxy or load balancer to ensure that this header is sent.<br /><br />If you use the CloudFlare service, you should change this option to CF-Connecting-IP.';
$helptxt['badbehavior_reverse_proxy'] = 'When enabled, Bad Behavior will assume it is receiving a connection from a reverse proxy, when a specific HTTP header is received.';
$helptxt['badbehavior_httpbl_maxage'] = 'This is the number of days since suspicious activity was last observed from an IP address by Project Honey Pot. Bad Behavior will block requests with a maximum age equal to or less than this setting.';
$helptxt['badbehavior_httpbl_threat'] = 'This number provides a measure of how suspicious an IP address is, based on activity observed at Project Honey Pot. Bad Behavior will block requests with a threat level equal or higher to this setting. Project Honey Pot has <a href="http://www.projecthoneypot.org/threat_info.php" target="_blank">more information on this parameter</a>.';
$helptxt['badbehavior_httpbl_key'] = 'Bad Behavior is capable of using data from the <a href="http://www.projecthoneypot.org/faq.php#g" target="_blank">http:BL</a> service provided by <a href="http://www.projecthoneypot.org/" target="_blank">Project Honey Pot</a> to screen requests.<br /><br />This is purely optional; however if you wish to use it, you must <a href="http://www.projecthoneypot.org/httpbl_configure.php" target="_blank">sign up for the service</a> and obtain an API key. To disable http:BL use, remove the API key from your settings.';
$helptxt['badbehavior_verbose'] = 'Enabling verbose mode causes all HTTP requests to be logged. When verbose mode is off, only blocked requests and suspicious requests are logged.<br /><br />Verbose mode is off by default. Using verbose mode is not recommended as it can significantly slow down your site; it exists to capture data from live spammers which are not being blocked.';
$helptxt['badbehavior_logging'] = 'Should Bad Behavior keep a log of requests? On by default, and it is not recommended to disable it, since it will cause additional spam to get through.';
$helptxt['badbehavior_strict'] = 'Bad Behavior operates in two blocking modes: normal and strict.<br />When strict mode is enabled, additional checks for (old) software which have been spam sources are enabled, but occasional legitimate users using the same software may be blocked as well.';
$helptxt['badbehavior_offsite_forms'] = 'Bad Behavior normally prevents your site from receiving data posted from forms on other websites. This prevents spammers from, e.g., using a Google cached version of your website to send you spam. However, some web applications such as OpenID require that your site be able to receive form data in this way. If you are running OpenID, enable this option.';
$helptxt['badbehavior_postcount_wl'] = 'This allows you to bypass bad behavior checks for users over a certain post count.<br />-1 will bypass all registered users, including those with no posts<br />0 will disable bypassing and scan everyone regardless of post count<br />Any number greater than zero sets the post count under which users will be checked.';
$helptxt['badbehavior_ip_wl'] = 'IP address ranges use the CIDR format.  To remove an address just leave it blank and then save';
$helptxt['badbehavior_useragent_wl'] = 'User agents are matched by exact match only.';
$helptxt['badbehavior_url_wl'] = 'URLs are matched from the first / after the server name up to, but not including, the ? (if any). The URL to be whitelisted is a URL on YOUR site. A partial URL match is permitted, so URL whitelist entries should be as specific as possible, but no more specific than necessary.<br />For instance, /example would match /example.php and /example/address';

$helptxt['filter_to'] = 'Bulunan metni bununla değiştirin, bulunan metni yerine koymak için boş bırakın (başka bir deyişle kaldırın).';
$helptxt['filter_from'] = 'Enter the text you want to find/replace.  If type is set to regex then this must be a valid regular expression, including delimiters.  If not regex it will do a simple text match and replace it with the replacement text';
$helptxt['filter_type'] = 'Standart tam bir cümleyi bulacak ve değiştirme alanındaki metinle değiştirecektir. Düzenli İfade joker bir seçenektir, ancak geçerli bir düzenli ifade biçiminde olmalıdır.';
$helptxt['pbe_post_enabled'] = 'Kullanıcıların e-posta bildirimlerine yanıt vermesine ve yanıt olarak göndermelerine izin vermek için bunu etkinleştirin. Yine de gönderim izinlerine sahip olmaları gerekiyor.';
$helptxt['pbe_pm_enabled'] = 'Kullanıcıların kişisel iletilerine  e-posta ile yanıt vermesine izin vermek için bunu etkinleştirin. Kişisel iletilerineizinlerine sahip olmaları gerekiyor, bu ayar yalnızca  bildirimleri almalarını ve yanıtlamalarını sağlar';
$helptxt['maillist_group_mode'] = 'If enabled outbound post/topic emails will come from the poster\'s display name, otherwise it will come from the site name.  This is simply a envelope, affecting only how the "From name" appears in the receiving mailbox, the actual from email address is unchanged.';
$helptxt['maillist_newtopic_change'] = 'This will allow a user to change the subject of a email notification and have it post as a new topic.  The new topic will be started on the same board as the reply was going to.';
$helptxt['maillist_sitename_address'] = 'Bu, emailpost.php dosyasına veya IMAP posta kutusunun adresine yönlendirilen adres olmalıdır';
$helptxt['maillist_help_short'] = 'Bu özellik, forum kullanıcılarının sitenin e-posta bildirimlerini yanıtlamasına ve bu yanıtların foruma gönderilmesine olanak tanır. Tüm talimatlar için lütfen Wiki\'yi ziyaret edin.';

$helptxt['frame_security'] = 'The X-Frame-Options HTTP response header can be used to indicate whether or not a browser should be allowed to render a page in a frame or an iframe. You can use this additional security restriction on your site against attempts at clickjacking attacks, by ensuring that the content of your site is not embedded into other sites.
	<br />
	More information about this header may be found on the internet.';

$helptxt['attachment_inline_title'] = '<b>Add an inline attachment</b><br />
		Example:
		<br /><b>[attach align=left width=400]123[/attach]</b>
		<br />This will show a left-aligned image resized to 400 pixels wide with the post text flowing around it. Except for the attachment tag and the attachment id all other parameters are optional
		<br /><b>[attach]123[/attach]</b>
		<br />This will show the attachment as a thumbnail if available, if no thumbnail is available it will use a full sized image. The image will be in line with the text of your post.
		<br /><br />
		<br /><b>Options:</b>
		<br />where x is the attachment id
		<br />align=left, center, right
		<br />width=### (where # is number in pixels)
		<br />height=### (where # is number in pixels)
		<br />
		<h3>Modes available</h3>
		<p>
			You can choose the inline mode you want for your attachment:
			<ul>
				<li>Thumbnail [attach]x[/attach] : Your image will be shown as a thumbnail</li>
				<li>Text Link [attachurl]x[/attachurl] : Only a link is show with size and view details. By clicking on it, the image is displayed.</li>
			</ul>
		</p><br />
		<p>
			You can choose how to align the inline image:
			<ul>
				<li>align=left : The image is aligned to the left and the text will flow around it</li>
				<li>align=right : The image is aligned to the right and the text will flow around it</li>
				<li>align=center : The image is centered and the text will be below it</li>
			</ul>
		</p><br />
		<p>
			You can choose how wide to show the image:
			<ul>
				<li>width=123 : The image is displayed 123 pixels wide</li>
				<li>If the width specified is larger than the image or larger than the forum allows the largest allowable width will be used</li>
				<li>Can be used to shrink a thumbnail as well [attach width=50]x[/attach] will display a 50px wide thumbnail</li>
			</ul>
		</p><br />
		<p>
			You can choose how tall to show the image:
			<ul>
				<li>height=123 : The image is displayed 123 pixels tall</li>
				<li>If the height specified is bigger than the image or bigger than the forum allows the biggest allowable width will be used</li>
				<li>Can be used to shrink a thumbnail as well [attach height=50]x[/attach] will display a 50px tall thumbnail</li>
			</ul>
		</p>';