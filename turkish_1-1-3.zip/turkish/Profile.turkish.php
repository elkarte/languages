<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Bu üyenin profilini değiştirmek için yetkiniz yok.';
$txt['website_title'] = 'Website Başlığı';
$txt['website_url'] = 'Website Adresi';
$txt['signature'] = 'İmza';
$txt['profile_posts'] = 'İleti';

$txt['profile_info'] = 'İlave Detaylar';
$txt['profile_contact'] = 'İletişim Bilgileri';
$txt['profile_moderation'] = 'Moderasyon Bilgileri';
$txt['profile_more'] = 'İmza';
$txt['profile_attachments'] = 'Son Eklentiler';
$txt['profile_attachments_no'] = 'Bu üye tarafından hiç eklenti gönderilmemiş';
$txt['profile_recent_posts'] = 'Son İletiler';
$txt['profile_posts_no'] = 'Bu üye tarafından hiç ileti gönderilmemiş';
$txt['profile_topics'] = 'Son Konular';
$txt['profile_topics_no'] = 'Bu üye tarafından hiç konu gönderilmemiş';
$txt['profile_buddies_no'] = 'Arkadaş listesi boş';
$txt['profile_user_info'] = 'Kullanıcı Bilgileri';
$txt['profile_contact_no'] = 'Bu üye için iletişim bilgisi yoktur';
$txt['profile_signature_no'] = 'Bu üye için hiçbir imza yoktur';
$txt['profile_additonal_no'] = 'Bu üye için ek bilgi yok';
$txt['profile_user_summary'] = 'Profil';
$txt['profile_action'] = 'Şu anda';
$txt['profile_recent_activity'] = 'Son Etkinlikler';
$txt['profile_activity'] = 'Aktivite';
$txt['profile_loadavg'] = 'Lütfen tekrar deneyin. Sitedeki aşırı talepten ötürü bu bilgiye ulaşılamıyor.';

$txt['change_profile'] = 'Profili değiştir';
$txt['preview_signature'] = 'İmzayı önizle';
$txt['current_signature'] = 'Şu anki imza';
$txt['signature_preview'] = 'İmza önizlenimi';
$txt['personal_picture'] = 'Kişisel Resim';
$txt['no_avatar'] = 'Avatar yok';
$txt['choose_avatar_gallery'] = 'Galeriden avatar seçin';
$txt['preferred_language'] = 'Tercih Edilen Dil';
$txt['age'] = 'Yaş';
$txt['no_pic'] = '(resim yok)';
$txt['avatar_by_url'] = 'Avatarınızın URL adresini belirtin. (Örn: <em>http://www.benimsitem.org/avatar.gif</em>)';
$txt['my_own_pic'] = 'Avatarınızı URL ile belirtin';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'Bu seçim forumdaki tarih formatının görünümünü değiştirecektir.';
$txt['time_format'] = 'Zaman biçimi';
$txt['display_name_desc'] = 'Diğer kullanıcılar tarafından görüntülenecek isminiz.';
$txt['personal_time_offset'] = 'Görüntülenen saati, yerel saatinize eşitlemek için gerekli saat farkı (+/-).';
$txt['dob'] = 'Doğum Tarihi';
$txt['dob_month'] = 'Ay (AA)';
$txt['dob_day'] = 'Gün (GG)';
$txt['dob_year'] = 'Yıl (YYYY)';
$txt['password_strength'] = 'Güvenlik açısından harf, rakam ve sembollerden oluşan bir kombinasyon kullanmanız önerilir.';
$txt['include_website_url'] = 'Eğer aşağıya bir adres girerseniz dahil olmalıdır.';
$txt['complete_url'] = 'Bu tam bir adres olmalıdır. (örn. http://www.simplemachines.org/)';
$txt['sig_info'] = 'İmzanız, gönderdiğiniz her iletinin altında gösterilir. BBC etiketleri ve gülücük kullanabilirsiniz.';
$txt['max_sig_characters'] = 'İzin verilen %1$d karakter. Kalan: ';
$txt['send_member_pm'] = 'Bu üyeye bir kişisel ileti gönder.';
$txt['hidden'] = 'gizli';
$txt['current_time'] = 'Şu anki forum zamanı';

$txt['language'] = 'Dil';
$txt['avatar_too_big'] = 'Avatarınızın için seçtiğiniz resim çok büyüktür (izin verilen maks.';
$txt['invalid_registration'] = 'Geçersiz kayıt tarihi değeri, geçerli örnek:';
$txt['current_password'] = 'Şu anki şifreniz';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Güvenlik sebebiyle şu an kullandığınız şifrenizi girmeniz gerekmektedir.';

$txt['timeoffset_autodetect'] = 'otomatik bul';

$txt['secret_question'] = 'Gizli Soru';
$txt['secret_desc'] = 'Şifrenizi hatırlatmaya yarar. Buraya yanıtını <b>sadece</b> sizin bildiğiniz bir soru ve cevap girin.';
$txt['secret_desc2'] = 'Dikkatli seçin, başkası cevabınızı tahmin edebilir!';
$txt['secret_answer'] = 'Cevap';
$txt['incorrect_answer'] = 'Üzgünüz ama profilinizde geçerli bir gizli soru/cevap kombinasyonu belirtmediniz.  Lütfen tarayıcınızın geri tuşuna tıklayarak tekrar deneyiniz.';
$txt['enter_new_password'] = 'Lütfen sorunuzun cevabını ve yeni şifrenizi girin. Şifreniz, sorunuza doğru cevabı verdiğinizde değiştirilecektir.';
$txt['secret_why_blank'] = 'Bu neden boş?';

$txt['authentication_reminder'] = 'Doğrulama Hatırlatması';
$txt['password_reminder_desc'] = 'Eğer giriş bilgilerinizi unuttuysanız endişelenmenize gerek yoktur. Şifrenizi yenileme işlemini başlatmak için lütfen aşağıya kullanıcı adınızı veya e-posta adresinizi giriniz.';
$txt['authentication_options'] = 'Lütfen aşağıdaki iki seçenekten birini seçiniz';
$txt['authentication_openid_email'] = 'OpenID hesabım için bir hatırlatma gönderin';
$txt['authentication_openid_secret'] = 'OpenID hesabımı görüntülemek için &quot;gizli sorunuzu&quot; kullanın';
$txt['authentication_password_email'] = 'E-posta adresime yeni bir şifre gönderilsin';
$txt['authentication_password_secret'] = '&quot;Gizli soruma&quot; verilecek bir cevapla yeni bir şifre ayarlayabileyim';
$txt['openid_secret_reminder'] = 'Sorunun cevabını aşağıya giriniz. Eğer doğru bir cevap sağlarsanız OpenID hesabınız görüntülenecektir.';
$txt['reminder_openid_is'] = 'Hesabınızla ilişkilendirilmiş OpenID:<br />&nbsp;&nbsp;&nbsp;&nbsp;<b>%1$s</b><br /><br />Lütfen bunu not ediniz.';
$txt['reminder_continue'] = 'Devam Et';

$txt['accept_agreement_title'] = 'Anlaşmayı kabul et';
$txt['agreement_accepted_title'] = 'Devam Et';

$txt['current_theme'] = 'Kullanılan Tema';
$txt['change'] = 'Temayı değiştir';
$txt['theme_forum_default'] = 'Forum ya da Bölüm Varsayılanı';
$txt['theme_forum_default_desc'] = 'Bu varsayılan temadır. Forumda yapılan değişiklikler bu tema üzerinde olacaktır.';

$txt['profileConfirm'] = 'Bu üyeyi gerçekten silmek istiyor musunuz?';

$txt['custom_title'] = 'Kişisel Başlığı';

$txt['lastLoggedIn'] = 'Son Aktif Olma Zamanı';

$txt['notify_settings'] = 'Haberdar Edilme Ayarları:';
$txt['notify_save'] = 'Ayarları kaydet';
$txt['notify_important_email'] = 'Forum duyurularını ve önemli bildirimleri e-posta ile bildir.';
$txt['notify_regularity'] = 'Haberdar edilmeyi seçtiğim bölümler ve konular için e-posta almak istediğim sıklık:';
$txt['notify_regularity_none'] = 'Hiç';
$txt['notify_regularity_instant'] = 'Hemen';
$txt['notify_regularity_first_only'] = 'Hemen - sadece ilk okunmamış ileti için';
$txt['notify_regularity_daily'] = 'Günlük';
$txt['notify_regularity_weekly'] = 'Haftalık';
$txt['auto_notify'] = 'Bir konuya ileti ya da cevap gönderildiğinde haberdar olma seçeneğini otomatik olarak aktif kıl.';
$txt['auto_notify_pbe_post'] = 'Eğer forum uyarılarını etkinleştirdiyseniz <strong>ÖNERİLMEZ</strong>.';
$txt['notify_send_types'] = 'Duyuru almayı seçtiğim bölüm veya konular hakkında bana:';
$txt['notify_send_type_everything'] = 'Olan her şeyi bildir';
$txt['notify_send_type_everything_own'] = 'Eğer benim başlattığım bir konuda ise her şeyi bildir';
$txt['notify_send_type_only_replies'] = 'Sadece yanıtları bildir';
$txt['notify_send_type_only_replies_pbe'] = 'Tüm mesajlar';
$txt['notify_send_type_nothing'] = 'Hiçbir şeyi bildirme';
$txt['notify_send_body'] = 'Bir konuya cevap verildiğin de e-posta ile bildir (lütfen bu e-postalara cevap vermeyiniz.)';
$txt['notify_send_body_pbe'] = 'E-posta bildirimleri gönderirken, e-postadaki yazının tam metnini gönder';
$txt['notify_send_body_pbe_post'] = 'Günlük / Haftalık özet ile <strong>GÖRÜNTÜLENEMEZ</strong>.';

$txt['notify_method'] = 'Bildirim ve:';
$txt['notify_notification'] = 'e-posta yok (yalnızca bildirim / uyarı)';
$txt['notify_email'] = 'Derhal e-posta';
$txt['notify_email_daily'] = 'Günlük e-posta';
$txt['notify_email_weekly'] = 'Haftalık e-posta';

$txt['notify_type_likemsg'] = 'Mesajlarınızdan biri beğenildiğinde bildirim yapılır';
$txt['notify_type_mentionmem'] = 'Bir iletie @Kullanıcı adınız  geçtiğinde haberdar edilirsiniz';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Birisi beni arkadaş olarak eklediğinde haber ver';
$txt['notify_type_quotedmem'] = 'Birisi mesajlarınızdan birini alıntıladığında bildir';
$txt['notify_type_mailfail'] = 'E-posta bildirimleri devre dışı bırakıldığı zaman bildir (yalnızca uyarı)';

$txt['notifications_topics'] = 'Haber edilmeyi istediğiniz konular';
$txt['notifications_topics_none'] = 'Hiçbir konuda haberdar edilme seçeneği aktif değildir.';
$txt['notifications_topics_howto'] = 'Herhangi bir konudan haberdar olmayı istediğiniz zaman; konuyu okurken &quot;haberdar et&quot; bağlantısına tıklamanız yeterlidir.';

$txt['notifications_boards'] = 'Haberdar edilmeyi istediğiniz bölümler';
$txt['notifications_boards_none'] = 'Şu anda herhangi bir bölümden haberdar edilmiyorsunuz.';
$txt['notifications_boards_howto'] = 'Herhangi bir bölüme konu açıldığında haberdar olmayı istediğiniz zaman; bölüm içindeyken &quot;haberdar et&quot; bağlantısına tıklayın seçin <strong>veya</strong> haberdar olmayı  etkinleştirmek için aşağıdaki onay kutularını kullanın.';
$txt['notifications_boards_current'] = '<strong>KOYU</strong> ile gösterilen forumlardan uyarıları alıyorsunuz. Uyarıları kapatmak veya uyarı listenize yenilerini eklemek için kutucukları kullanın.';
$txt['notifications_boards_update'] = 'Güncelleme';
$txt['notifications_update'] = 'İptal et';

$txt['statPanel_showStats'] = 'Kullanıcı istatistikleri: ';
$txt['statPanel_users_votes'] = 'Kullandığı oy';
$txt['statPanel_users_polls'] = 'Başlattığı anket';
$txt['statPanel_total_time_online'] = 'Çevrimiçi olduğu toplam süre';
$txt['statPanel_noPosts'] = 'Hiç ileti göndermemiş';
$txt['statPanel_generalStats'] = 'Genel İstatistikler';
$txt['statPanel_posts'] = 'ileti';
$txt['statPanel_topics'] = 'konu';
$txt['statPanel_total_posts'] = 'Toplam İleti';
$txt['statPanel_total_topics'] = 'Toplam Başlatılan Konu';
$txt['statPanel_votes'] = 'oy';
$txt['statPanel_polls'] = 'anket';
$txt['statPanel_topBoards'] = 'En çok ileti gönderdiği bölümler';
$txt['statPanel_topBoards_posts'] = 'Forumun %2$d iletisi içindeki %1$d ileti (%3$01.2f%%) ';
$txt['statPanel_topBoards_memberposts'] = 'Üyenin %2$d iletisinin %1$d iletisi (%3$01.2f%%)';
$txt['statPanel_topBoardsActivity'] = 'En çok çevrimiçi olduğu bölümler';
$txt['statPanel_activityTime'] = 'Gün içinde ileti gönderdiği saatler';
$txt['statPanel_activityTime_posts'] = '%1$d ileti (%2$d%%)';

$txt['deleteAccount_warning'] = 'Uyarı! Bu işlemin geri dönüşü yoktur!';
$txt['deleteAccount_desc'] = 'Bu sayfayı kullanarak üyelerin hesaplarını ve tüm iletilerini silebilirsiniz.';
$txt['deleteAccount_member'] = 'Bu üyeyi sil';
$txt['deleteAccount_posts'] = 'Bu üyenin gönderdiği iletileri sil';
$txt['deleteAccount_none'] = 'Yok';
$txt['deleteAccount_all_posts'] = 'Sadece yanıtlar';
$txt['deleteAccount_topics'] = 'Konular ve Yanıtlar';
$txt['deleteAccount_confirm'] = 'Üyeliği silmek istediğinizden emin misiniz?';
$txt['deleteAccount_approval'] = 'Unutmayın silinme işleminin tam olarak gerçekleşebilmesi için silme isteğinizin yöneticiler tarafından onaylanması gerekmektedir.';

$txt['profile_of_username'] = '%1$s profili';
$txt['profileInfo'] = 'Kimlik Bilgileri';
$txt['showPosts'] = 'İletileri Göster';
$txt['showPosts_help'] = 'Bu özellik size üyenin attığı tüm iletileri gösterme olanağı sağlayacaktır . Not sadece size izin verilen bölümlerdeki iletilerini görebilirsiniz';
$txt['showMessages'] = 'Mesajlar';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = 'Konular';
$txt['showUnwatched'] = 'İzlenmeyen konular';
$txt['showAttachments'] = 'Eklentiler';
$txt['viewWarning_help'] = 'Bu bölüm kullanıcıya verilen uyarıları görüntülemenize yarar.';
$txt['statPanel'] = 'İstatistikleri Göster';
$txt['editBuddyIgnoreLists'] = 'Arkadaşlar / Engelli Listesi';
$txt['editBuddies'] = 'Arkadaş Listesini Düzenle';
$txt['editIgnoreList'] = 'Engellenenler Listesini Düzenle';
$txt['trackUser'] = 'Kullanıcıyı İzle';
$txt['trackActivity'] = 'Aktivite';
$txt['trackIP'] = 'IP\'yi İzle';
$txt['trackLogins'] = 'Girişler';

$txt['likes_show'] = 'Beğenileri göster';
$txt['likes_given'] = 'Beğendiğiniz iletiler';
$txt['likes_profile_received'] = 'alınan';
$txt['likes_profile_given'] = 'verilen';
$txt['likes_received'] = ' Başkaları tarafından beğenilen iletileriniz';
$txt['likes_none_given'] = 'Hiçbir gönderiyi beğenmediniz.';
$txt['likes_none_received'] = 'Kimse hiçbir gönderinizi beğenmedi :\'(';
$txt['likes_confirm_delete'] = 'beğeni kaldırılsın mı?';
$txt['likes_show_who'] = 'Bu gönderiyi beğenen üyeleri göster';
$txt['likes_by'] = 'Beğenen';
$txt['likes_delete'] = 'Sil';

$txt['authentication'] = 'Doğrulama';
$txt['change_authentication'] = 'Bu bölümü kullanarak forum\'a nasıl giriş yaptığınızı kontrol edebilirsiniz. Giriş yapmak için OpenID hesabınızı veya standart kullanıcı adı/şifre tipi doğrulama kullanabilirsiniz.';

$txt['profileEdit'] = 'Profili Düzenle';
$txt['account_info'] = 'Bu sizin kimlik bilgilerinizdir ve forum üyelerinin sizi tanımasına yardımcı olacaktır..Değiştirmek için şu anki şifrenizi girmelisiniz.';
$txt['forumProfile_info'] = 'Kişisel bilgilerinizi bu sayfadan düzenleyebilirsiniz. Bu bilgiler burada {forum_name_html_safe}.  görüntülenecektir. Eğer bazı kişisel bilgilerinizi paylaşmak istemiyorsanız, ilgili alanı boş bırakın - bu bölümdeki hiçbir alan zorunlu değildir.';
$txt['theme_info'] = 'Bu bölüm forum görünüşünü kişisel tercihlerinize göre ayarlamanızı sağlar.';
$txt['notification_info'] = 'Forum, iletilerinize yazılan cevaplar, açılan yeni konular ve forum bildirimleri hakkında bilgilendirme mesajları almanıza olanak verir. Bu seçenekleri burada ayarlabilir ve bilgilendirilme için seçtiğiniz mevcut konu ve bölümleri görebilirsiniz.';
$txt['groupmembership'] = 'Grup Üyeliği';
$txt['groupMembership_info'] = 'Bu bölümü kullanarak üye olduğunuz grupları değiştirebilirsiniz.';
$txt['ignoreboards'] = 'Yoksayılan Bölümler';
$txt['ignoreboards_info'] = 'Bu sayfa istediğiniz bölümleri yoksaymanızı sağlar. Bir bölüm yoksayıldığında anasayfada, bölümün yanındaki yeni ileti göstergesi hiçbir zaman görüntülenmez. Ayrıca "okunmamış iletiler" (arama bağlantısını kullandığınızda yoksayılmış bölümlerin içerdiği yeni iletiler de gösterilmez.) "Okunmamış yanıtlar" bağlantısı kullanıldığında ise bölüm yoksayılmış olsa bile iletiler gösterilecektir.';
$txt['contactprefs'] = 'Kişisel iletiler';

$txt['profileAction'] = 'İşlemler';
$txt['deleteAccount'] = 'Bu Hesabı Sil';
$txt['profileSendIm'] = 'Kişisel İleti Gönder';
$txt['profile_sendpm_short'] = 'Kişisel İleti Gönder';

$txt['profileBanUser'] = 'Üyeyi Yasakla';

$txt['display_name'] = 'Görünen Adı';
$txt['enter_ip'] = 'IP Adresi';
$txt['errors_by'] = 'Karşılaştığı hata iletileri:';
$txt['errors_desc'] = 'Bu kullanıcının neden olduğu veya karşılaştığı tüm hataların bir listesidir.';
$txt['errors_from_ip'] = 'IP\'nin hata iletileri';
$txt['errors_from_ip_desc'] = 'Bu IP adresinin neden olduğu veya karşılaştığı tüm hataların bir listesidir.';
$txt['ip_address'] = 'IP adresi';
$txt['ips_in_errors'] = 'Hata iletilerindeki IP adresi';
$txt['ips_in_messages'] = 'Geçmiş iletilerde kullanılmış IPler';
$txt['members_from_ip'] = 'Bu IP\'yi kullanan üyeler:';
$txt['members_in_range'] = 'Aynı kişi olabileceği tahmin edilen üyeler';
$txt['messages_from_ip'] = 'Bu IP\'den gönderilenler:';
$txt['messages_from_ip_desc'] = 'Bu IP adresini kullananların gönderdiği iletiler.';
$txt['trackLogins_desc'] = 'Aşağıda bu hesabın tüm zamanlarda yapmış olduğu girişler listelenmiştir.';
$txt['most_recent_ip'] = 'En son kullandığı IP adresi';
$txt['why_two_ip_address'] = 'Neden iki adet IP adresi var?';
$txt['no_errors_from_ip'] = 'Bu IP adresine ait hata iletisiyok.';
$txt['no_errors_from_user'] = 'Bu kullanıcıya ait hata iletisi yok.';
$txt['no_members_from_ip'] = 'Bu IP adresini kullanan üye bulunamadı.';
$txt['no_messages_from_ip'] = 'Bu IP adresinden gönderilen ileti bulunamadı.';
$txt['trackLogins_none_found'] = 'Yakında yapılmış giriş yok';
$txt['none'] = 'Yok';
$txt['own_profile_confirm'] = 'Üyeliğinizi silmek istediğinize emin misiniz?';
$txt['view_ips_by'] = 'Kullandığı IP adreslerine bak:';

$txt['avatar_will_upload'] = 'Kendi avatar\'ını sunucuya yükleyebilir';

$txt['activate_changed_email_title'] = 'Eposta Adresi Değiştirildi';
$txt['activate_changed_email_desc'] = 'Eposta adresinizi değiştirdiniz. Adresi onaylamak için bir eposta alıcaksınız. Epostanın içerisindeki bağlantıya tıklayarak hesabınızı tekrar aktifleştirebilirsiniz.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Hatırlatma e-postası gönderilemedi.';
$txt['send_email'] = 'E-Posta gönder';
$txt['to_ask_password'] = 'şifreyi sormak için';

$txt['user_email'] = 'Kullanıcı Adı/E-Posta';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'Şifreniz e-posta adresinize gönderildi. Yeni şifrenizi ayarlamak için e-postadaki bağlantıya tıklayın.';
$txt['reminder_openid_sent'] = 'Var olan OpenID\'niz e-posta adresinize gönderilmiştir.';
$txt['reminder_set_password'] = 'Şifreyi Değiştir';
$txt['reminder_password_set'] = 'Şifreniz değiştirildi';
$txt['reminder_error'] = '%1$s unuttuğunuz parolayı değiştirmek için gizli soruyu doğru olarak yanıtlamalısınız.';

$txt['registration_not_approved'] = 'Üzgünüm, bu hesap henüz onaylanmadı. Eğer e-posta adresinizi değiştirmek istiyorsanız lütfen tıklayın';
$txt['registration_not_activated'] = 'Üzgünüm, bu hesap henüz aktifleştirilmedi. Eğer aktivasyon e-postasını tekrar göndermek istiyorsanız lütfen tıklayın';

$txt['primary_membergroup'] = 'Öncelikli Üyegrubu';
$txt['additional_membergroups'] = 'İlave Üyegrupları';
$txt['additional_membergroups_show'] = 'Ek grupları göster ';
$txt['no_primary_membergroup'] = '(başlıca üye grubu yok)';
$txt['deadmin_confirm'] = 'Yönetici konumunuzu geri alınamaz biçimde değiştirmek istiyor musunuz?';

$txt['account_activate_method_2'] = 'E-posta değişikliğinden sonra hesabın tekrar aktifleştirilmesi gerekmekte';
$txt['account_activate_method_3'] = 'Hesap onaylanmamış';
$txt['account_activate_method_4'] = 'Hesabın silinme işlemi için onaylanması bekleniyor';
$txt['account_activate_method_5'] = 'Hesap &quot;yaş sınırının altındadır&quot; hesap onay bekliyor';
$txt['account_not_activated'] = 'Hesap şu anda aktif değildir';
$txt['account_activate'] = 'etkinleştir';
$txt['account_approve'] = 'onayla';
$txt['user_is_banned'] = 'Üye şu anda yasaklı';
$txt['view_ban'] = 'Göster';
$txt['user_banned_by_following'] = 'Bu kullanıcı şu an için aşağıdaki yasaklamaların etkisi altındadır';
$txt['user_cannot_due_to'] = 'Kullanıcı &quot;%2$s&quot; , %1$s yasağı sonucunda işlem gerçekleştiremez.';
$txt['ban_type_post'] = 'ileti gönderme';
$txt['ban_type_register'] = 'kayıt';
$txt['ban_type_login'] = 'giriş';
$txt['ban_type_access'] = 'forum erişimi';

$txt['show_online'] = 'Diğer üyelere çevrimiçi durumumu göster';

$txt['return_to_post'] = 'İleti gönderdikten sonra konuya geri dön.';
$txt['no_new_reply_warning'] = 'İleti gönderirken yeni bir yanıt gönderilirse uyarma.';
$txt['recent_pms_at_top'] = 'Yeni kişisel iletileri en üstte göster.';
$txt['wysiwyg_default'] = 'İletilerde WYSIWYG editörü varsayılan olarak göster';

$txt['timeformat_default'] = '(Forumda Varsayılanı)';
$txt['timeformat_easy1'] = 'Ay Gün, Yıl, SS:DD:SS ÖÖ/ÖS';
$txt['timeformat_easy2'] = 'Ay Gün, Yıl, SS:DD:SS (24 saat)';
$txt['timeformat_easy3'] = 'YYYY-AA-GG, SS:DD:SS';
$txt['timeformat_easy4'] = 'GG Ay YYYY, SS:DD:SS';
$txt['timeformat_easy5'] = 'GG-AA-YYYY, SS:DD:SS';

$txt['poster'] = 'Gönderen';

$txt['use_sidebar_menu'] = 'Kenar menülerinin yerine açılabilir menü kullanın.';
$txt['use_click_menu'] = 'Menülerde seçenekler tıklama ile açılsın.';
$txt['show_no_avatars'] = 'Diğer kullanıcıların avatarlarını gösterme.';
$txt['show_no_signatures'] = 'Diğer kullanıcıların imzalarını gösterme.';
$txt['show_no_censored'] = 'Kelimeleri sansürleme.';
$txt['topics_per_page'] = 'Sayfa başına gösterilecek konu sayısı:';
$txt['messages_per_page'] = 'Sayfa başına gösterilecek ileti sayısı:';
$txt['hide_poster_area'] = 'Gönderici bilgi ekranını gizle.';
$txt['per_page_default'] = 'forum varsayılanı';
$txt['calendar_start_day'] = 'Takvimde haftanın ilk günü';
$txt['display_quick_reply'] = 'İletilerde hızlı yanıt bölümünü göster:';
$txt['use_editor_quick_reply'] = 'Hızlı yanıtta tam editör kullan.';
$txt['display_quick_mod'] = 'Hızlı yönetim seçeneklerini göster:';
$txt['display_quick_mod_none'] = 'gösterme';
$txt['display_quick_mod_check'] = 'tıklama kutuları olarak göster';
$txt['display_quick_mod_image'] = 'simge olarak göster';

$txt['whois_title'] = 'Bu IP adresini bir \'whois-server\' kullanarak incele:';
$txt['whois_afrinic'] = 'AfriNIC (Afrika)';
$txt['whois_apnic'] = 'APNIC (Asya Pasifik bölgesi)';
$txt['whois_arin'] = 'ARIN (Kuzey Amerika, Karayiplerin bir bölümü ve Kuzey Afrika)';
$txt['whois_lacnic'] = 'LACNIC (Latin Amerika ve Karayip Adaları)';
$txt['whois_ripe'] = 'RIPE (Avrupa, Ortadoğu ve Afrika ve Asya nın bazı bölümleri)';

$txt['moderator_why_missing'] = 'Burda neden moderatör yok?';
$txt['username_change'] = 'değiştir';
$txt['username_warning'] = 'Bu kullanıcının adını değiştirmek için ayrıca şifresinin de sıfırlanması gerekmekte. Yeni şifre kullanıcıya yeni ismi ile beraber e-posta yoluyla gönderilecektir.';

$txt['show_member_posts'] = 'İletileri Göster';
$txt['show_member_topics'] = 'Konuları Göster';
$txt['show_member_attachments'] = 'Eklentileri Göster';
$txt['show_posts_none'] = 'Şimdiye kadar hiç ileti gönderilmemiş.';
$txt['show_topics_none'] = 'Her hangi bir konu gönderilmemiş.';
$txt['unwatched_topics_none'] = 'İzlenmeyen listenizde herhangi bir konu bulunmamaktadır.';
$txt['show_attachments_none'] = 'Şimdiye kadar hiç eklenti gönderilmemiş.';
$txt['show_attach_filename'] = 'Dosya Adı';
$txt['show_attach_downloads'] = 'İndirilme';
$txt['show_attach_posted'] = 'Tarih';

$txt['showPermissions'] = 'İzinleri Göster';
$txt['showPermissions_status'] = 'İzin durumu';
$txt['showPermissions_help'] = 'Bu bölüm de bu üye için olan tüm izinleri görmenize izin verilir (verilmeyen izinlerin <del>üstü çiziktir</del>).';
$txt['showPermissions_given'] = 'Belirlenenler';
$txt['showPermissions_denied'] = 'Belirlenmeyenler';
$txt['showPermissions_permission'] = 'İzinler (reddedilenlerin <del>üstü çizilidir</del>)';
$txt['showPermissions_none_general'] = 'Bu üye için hiçbir genel izin ayarlanmadı.';
$txt['showPermissions_none_board'] = 'Bu üye için hiçbir bölümde belirli bir izin ayarlanmadı.';
$txt['showPermissions_all'] = 'Yönetici olarak bu üyeye bütün izinler verilmiştir.';
$txt['showPermissions_select'] = 'İzinlerini görmek istediğiniz bölüm';
$txt['showPermissions_general'] = 'Genel İzinler';
$txt['showPermissions_global'] = 'Tüm Bölümler';
$txt['showPermissions_restricted_boards'] = 'Kısıtlı bölümler';
$txt['showPermissions_restricted_boards_desc'] = 'Aşağıdaki bölümler bu kullanıcı tarafından erişilebilir değillerdir';

$txt['local_time'] = 'Yerel Zaman';
$txt['posts_per_day'] = 'gün başına';

$txt['buddy_ignore_desc'] = 'Bu alanda arkadaşlarınızı ve yasakladığınız listeleri görebilirsiniz. Buraya eklediğiniz üyeler, diğer avantajlar dışında, e-posta ve özel mesaj trafiğini de düzenlediğiniz seçeneklere göre etkileyecektir.';

$txt['buddy_add'] = 'Arkadaş Listeme Ekle';
$txt['buddy_remove'] = 'Arkadaş Listemden Çıkar';
$txt['buddy_add_button'] = 'Ekle';
$txt['no_buddies'] = 'Arkadaş listenizde şu anda kimse bulunmamakta.';

$txt['ignore_add'] = 'Engelli Listesine Ekle';
$txt['ignore_remove'] = 'Engellei Listesinden Çıkar';
$txt['ignore_add_button'] = 'Ekle';
$txt['no_ignore'] = 'Yoksayılanlar Listeniz Boş.';

$txt['regular_members'] = 'Kayıtlı Üyeler';
$txt['regular_members_desc'] = 'Tüm üyeler bu grubun bir parçasıdır.';
$txt['group_membership_msg_free'] = 'Grup üyeliğiniz başarılı bir şekilde güncellenmiştir.';
$txt['group_membership_msg_request'] = 'Üyelik talebiniz iletilmiştir, sonuçtan e-posta ile haberdar edileceksiniz.';
$txt['group_membership_msg_primary'] = 'Birincil grubunuz güncellenmiştir.';
$txt['current_membergroups'] = 'Üyesi Olunan Gruplar';
$txt['available_groups'] = 'Diğer Gruplar';
$txt['join_group'] = 'Grupa Katıl';
$txt['leave_group'] = 'Gruptan Ayrıl';
$txt['request_group'] = 'Üyelik Talep Et';
$txt['approval_pending'] = 'Onay Bekleniyor';
$txt['make_primary'] = 'Birincil Grup Yap';

$txt['request_group_membership'] = 'Grup Üyeliği Talebinde Bulun';
$txt['request_group_membership_desc'] = 'Bu gruba katılabilmeniz için talebinizin öncelikle bir moderatör tarafından incelenmesi gerekmektedir. Lütfen gruba katılma isteğinizin sebebini belirtiniz';
$txt['submit_request'] = 'Başvuru Gönder';

$txt['profile_updated_own'] = 'Profiliniz başarıyla güncellenmiştir';
$txt['profile_updated_else'] = '%1$s adlı üyenin profili başarıyla güncellenmiştir.';

$txt['profile_error_signature_max_length'] = 'İmzanız en fazla %1$d karakter barındırabilir';
$txt['profile_error_signature_max_lines'] = 'İmzanız en fazla %1$d satıra sahip olabilir';
$txt['profile_error_signature_max_image_size'] = 'İmzanızdaki resimler %1$dx%2$d pikselden büyük olamaz';
$txt['profile_error_signature_max_image_width'] = 'İmzanızdaki resimlerin genişliği %1$d pikselden fazla olamaz';
$txt['profile_error_signature_max_image_height'] = 'İmzanızdaki resimlerin yüksekliği %1$d pikselden fazla olamaz';
$txt['profile_error_signature_max_image_count'] = 'İmzanız en fazla %1$d resim içerebilir';
$txt['profile_error_signature_max_font_size'] = 'İmzanızdaki metin %1$s boyutundan daha büyük olamaz';
$txt['profile_error_signature_allow_smileys'] = 'İmzanızda her hangi bir gülücük kullanmanıza izin verilmemektedir';
$txt['profile_error_signature_max_smileys'] = 'İmzanızda %1$d gülücükten daha fazlasını kullanmanıza izin verilmemektedir';
$txt['profile_error_signature_disabled_bbc'] = 'Kullanmış olduğunuz bu BBC etiketinin imzalarda kullanılması yasaktır: %1$s';

$txt['profile_view_warnings'] = 'Uyarıları Göster';
$txt['profile_issue_warning'] = 'Uyarı Ver';
$txt['profile_warning_level'] = 'Uyarı Seviyesi';
$txt['profile_warning_desc'] = 'Bu bölümde üyenin uyarı seviyesini değiştirebilir ve gerekli durumlarda bir uyarı metni belirleyebilirsiniz. Ayrıca üyenin uyarı geçmişini görüntüleyebilir ve forum yöneticisinin belirlemiş olduğu şartlar doğrultusunda üyenin sahip olduğu uyarı seviyesinin üyeye olan etkilerini görüntüleyebilirsiniz.';
$txt['profile_warning_name'] = 'Üye Adı';
$txt['profile_warning_impact'] = 'Sonuç';
$txt['profile_warning_reason'] = 'Uyarı Sebebi';
$txt['profile_warning_reason_desc'] = 'Uyarı sebebi girilmesi zorunludur.';
$txt['profile_warning_effect_none'] = 'Yok.';
$txt['profile_warning_effect_watch'] = 'Kullanıcı moderatör izleme listesine alınacaktır.';
$txt['profile_warning_effect_own_watched'] = 'Moderatör İzleme Listesindesiniz.';
$txt['profile_warning_is_watch'] = 'kullanıcı izlenilmekte';
$txt['profile_warning_effect_moderate'] = 'Tüm kullanıcıların gönderileri denetlenecek';
$txt['profile_warning_effect_own_moderated'] = 'Tüm İletileriniz Moderatör Onayına Tabii dir.';
$txt['profile_warning_is_moderation'] = 'iletiler moderasyona tabidir';
$txt['profile_warning_effect_mute'] = 'Kullanıcı ileti yollayamayacaktır.';
$txt['profile_warning_effect_own_muted'] = 'Burada ileti gönderemessiniz.';
$txt['profile_warning_is_muted'] = 'ileti yollayamaz';
$txt['profile_warning_effect_text'] = 'Seviye >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'E-Posta Gönder';
$txt['profile_warning_notify_template'] = 'Şablon seç:';
$txt['profile_warning_notify_subject'] = 'Başlık';
$txt['profile_warning_notify_body'] = 'İleti';
$txt['profile_warning_notify_template_subject'] = 'Bir uyarı aldınız';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},\' . "\n\n" . \'Şu sebeple bir uyarı almış bulunuyorsunuz: %1$s. Lütfen bu eylemlerinizi tekrarlamayınız, aksi takdirde forum kuralları doğrultusunda yaptırım uygulanacaktır.\' . "\n\n" . \'{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},\' . "\n\n" . \'{MESSAGE}.\' . "\n\n" . \' mesajınızda %1$s nedeniyle bir uyarı aldınız. Lütfen bu eylemlerinizi tekrarlamayınız, aksi takdirde forum kuralları doğrultusunda yaptırım uygulanacaktır.\' . "\n\n" . \'{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'spam';
$txt['profile_warning_notify_title_spamming'] = 'Spam';
$txt['profile_warning_notify_for_offence'] = 'uygunsuz içerik';
$txt['profile_warning_notify_title_offence'] = 'Uygunsuz İçerik Göndermek';
$txt['profile_warning_notify_for_insulting'] = 'kullanıcı veya ekip üyelerine hakaret';
$txt['profile_warning_notify_title_insulting'] = 'Kullanıcı veya Ekip Üyelerine Hakaret';
$txt['profile_warning_issue'] = 'Uyarıyı Gönder';
$txt['profile_warning_max'] = '(Maks. 100)';
$txt['profile_warning_limit_attribute'] = 'Bu üyenin seviyesini 24 saat içerisinde %1$d%% kereden fazla değiştiremezsiniz.';
$txt['profile_warning_errors_occurred'] = 'Şu sebeplerle uyarı gönderilemedi';
$txt['profile_warning_success'] = 'Uyarı Başarıyla Gönderildi';
$txt['profile_warning_new_template'] = 'Yeni Şablon';

$txt['profile_warning_previous'] = 'Geçmiş Uyarılar';
$txt['profile_warning_previous_none'] = 'Bu kullanıcıya ait eski bir uyarı bulunmamaktadır.';
$txt['profile_warning_previous_issued'] = 'Uyaran';
$txt['profile_warning_previous_time'] = 'Zaman';
$txt['profile_warning_previous_level'] = 'Seviye';
$txt['profile_warning_previous_reason'] = 'Sebep';
$txt['profile_warning_previous_notice'] = 'Üyeye Gönderilmiş İletiyi İncele';

$txt['viewwarning'] = 'Uyarıları Göster';
$txt['profile_viewwarning_for_user'] = '%1$s\'ye verilen uyarılar';
$txt['profile_viewwarning_no_warnings'] = 'Hiçbir uyarı almamış';
$txt['profile_viewwarning_desc'] = 'Alttaki özette moderasyon ekibi tarafından yaratılmış tüm uyarılar yer almaktadır';
$txt['profile_viewwarning_previous_warnings'] = 'Geçmiş Uyarılar';
$txt['profile_viewwarning_impact'] = 'Uyarı Etkisi';

$txt['subscriptions'] = 'Ücretli Abonelikler';

$txt['pm_settings_desc'] = 'Bu sayfayı kullanarak kişisel iletiler ile ilgili birçok seçenekte değişiklik yapabilirsiniz. Ayrıca belli kişileri engelleyebilir, bu sayede o kişilerden kişisel ileti alımını devre dışı bırakabilirsiniz.';
$txt['email_notify'] = 'Kişisel ileti alındığında e-posta ile haberdar et:';
$txt['email_notify_never'] = 'Hiç';
$txt['email_notify_buddies'] = 'Sadece Arkadaşlardan';
$txt['email_notify_always'] = 'Her zaman';

$txt['receive_from'] = 'Bu kişilerden özel mesaj al:';
$txt['receive_from_everyone'] = 'Tüm Üyeler';
$txt['receive_from_ignore'] = 'Engelli listesindeki hariç tüm üyeler';
$txt['receive_from_admins'] = 'Sadece Adminler';
$txt['receive_from_buddies'] = 'Sadece Arkadaşlar ve Adminler';
$txt['receive_from_description'] = 'Bu ayar Kişisel Mesajlar ve e-postalar için de geçerlidir (üyelerin e-posta gönderme seçeneği etkinse)';

$txt['popup_messages'] = 'Yeni bir kişisel ileti alındığında açılan pencere görüntüle.';
$txt['pm_remove_inbox_label'] = 'Başka bir etiket atandığında, gelen kutusu etiketi kaldırılsın.';
$txt['pm_display_mode'] = 'Kişisel iletiler görünümü';
$txt['pm_display_mode_all'] = 'Hepsi bir arada';
$txt['pm_display_mode_one'] = 'Bir seferde bir tane';
$txt['pm_display_mode_linked'] = 'Sohbet tarzında';

$txt['history'] = 'Kayıtlar';
$txt['history_description'] = 'Bu bölüm kullanıcı tarafından gerçekeleştirilmiş bazı işlemleri görüntülemenize ve bu kullanıcıya ait IP adresleri ve giriş geçmişi hakkında bilgi toplamanıza olanak tanır.';

$txt['trackEdits'] = 'Profil Düzenlemeleri';
$txt['trackEdit_deleted_member'] = 'Silinmiş Üye';
$txt['trackEdit_no_edits'] = 'Bu kullanıcı tarafından şimdiye kadar herhangi bir düzenleme gerçekleştirilmemiştir.';
$txt['trackEdit_action'] = 'Alan';
$txt['trackEdit_before'] = 'Önceki Değeri';
$txt['trackEdit_after'] = 'Sonraki Değeri';
$txt['trackEdit_applicator'] = 'Değiştiren';

$txt['trackEdit_action_real_name'] = 'Üye Adı';
$txt['trackEdit_action_usertitle'] = 'Kişisel Başlığı';
$txt['trackEdit_action_member_name'] = 'Kullanıcı Adı';
$txt['trackEdit_action_email_address'] = 'E-Posta Adresi';
$txt['trackEdit_action_id_group'] = 'Öncelikli Üyegrubu';
$txt['trackEdit_action_additional_groups'] = 'İlave Üyegrupları';

$txt['otp_enabled_help'] = 'Bunu etkinleştirmek, kimlik doğrulama için ikinci bir faktörü (bir seferlik şifre) ekleyecektir.';
$txt['otp_token_help'] = 'Bu,  Authy veya Google Authenticator gibi zaman tabanlı bir kerelik şifre uygulamaları için gizli bir belirteç oluşturur. Gizlilik oluşturulduktan sonra en sevdiğiniz kimlik doğrulama uygulamasını kullanın ve qrcode. <ul> <li> <a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en"> Google Authenticator\'ı Android için</a></li><li> <a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8"> tarayın Google Authenticator  IOS (Apple) </a></li></ul>';
