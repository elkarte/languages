<?php
// Version: 1.1; UserNotifications

$txt['usernotif_title'] = 'Kullanıcı Bildirim Ayarları';
$txt['usernotif_desktop_enable'] = 'Masaüstü bildirimlerini etkinleştir';
$txt['usernotif_favicon_enable'] = 'Favicon\'da bildirimlerin sayısını etkinleştir';

$txt['usernotif_favicon_position'] = 'Bildirim konumu:';
$txt['usernotif_favicon_up'] = 'Sağ-üst';
$txt['usernotif_favicon_down'] = 'Sağ alt';
$txt['usernotif_favicon_left'] = 'Sol-alt';
$txt['usernotif_favicon_upleft'] = 'Sol-üst';

$txt['usernotif_favicon_bgColor'] = 'Arka plan rengi:';
$txt['usernotif_favicon_textColor'] = 'Metin rengi:';

$txt['usernotif_favicon_fontStyle'] = 'Yazı stili:';
$txt['usernotif_favicon_style_normal'] = 'Normal';
$txt['usernotif_favicon_style_italic'] = 'İtalik';
$txt['usernotif_favicon_style_oblique'] = 'Eğik';
$txt['usernotif_favicon_style_bold'] = 'Kalın';
$txt['usernotif_favicon_style_bolder'] = 'Kalın';
$txt['usernotif_favicon_style_lighter'] = 'Açık';

$txt['usernotif_favicon_type'] = 'Biçim:';
$txt['usernotif_favicon_shape_circle'] = 'Yuvarlak';
$txt['usernotif_favicon_shape_rectangle'] = 'Dikdörtgen';