<?php
// Version: 1.1; mentions

$txt['my_mentions'] = 'Bildirimleriniz';
$txt['my_unread_mentions'] = 'Okunmamış bildirimleriniz';
$txt['my_mentions_pages'] = 'sayfa %1$d';
$txt['no_mentions_yet'] = 'Bildirim yok';
$txt['no_new_mentions'] = 'Yeni bildirim yok';

$txt['mentions_from'] = 'Üye';
$txt['mentions_when'] = 'Sırala';
$txt['mentions_what'] = 'İleti';
$txt['mentions_all'] = 'Hepsini göster';
$txt['mentions_unread'] = 'Okunmamışları göster';
$txt['mentions_action'] = 'İşlemler';
$txt['mentions_delete_warning'] = 'Bu girdiyi silmek istediğinizden emin misiniz?';
$txt['mentions_markread'] = 'Okundu olarak işaretle';
$txt['mentions_markunread'] = 'Okunmamış olarak işaretle';

$txt['mentions_settings'] = 'Bildirim Ayarları';
$txt['mentions_settings_desc'] = 'In this area you can configure the methods your members will be able to select in order to receive notifications. The "in forum" notifications method cannot be denied, for any other method you can decide to allow it or not.';
$txt['mentions_enabled'] = 'Site bildirimlerini etkinleştir';
$txt['mentions_buddy'] = 'Bir üye arkadaş listesine eklendiğinde bildirim gönder';
$txt['mentions_dont_notify_rlike'] = 'Geri alınan begeniler üyelere bildirilmesin';

$txt['mention_mentionmem'] = '{msg_link} iletisinde sizden bahsedildi';
$txt['mention_likemsg'] = 'İletiniz beğenildi  {msg_link}';
$txt['mention_rlikemsg'] = 'İletinizden beğeni geri alındı {msg_link}';
$txt['mention_buddy'] = 'kendi arkadaş listesine ekledi.';
$txt['mention_quotedmem'] = ' {msg_link} konusunda iletiniz alıntı yapıldı';
$txt['mention_mailfail'] = 'Bildirimlerin devre dışı olması sebebiyle gönderilemedi';

$txt['mentions_type_all'] = 'Tüm Bildirimler';
$txt['mentions_type_mentionmem'] = 'Bahsedilen';
$txt['mentions_type_likemsg'] = 'Beğeni';
$txt['mentions_type_rlikemsg'] = 'Geri alınan begeni';
$txt['mentions_type_buddy'] = 'Arkadaş';
$txt['mentions_type_quotedmem'] = 'Alıntı';
$txt['mentions_type_mailfail'] = 'Teslim edilmedi';

$txt['mentions_mark_all_read'] = 'Bildirimleri okunmuş say';

$txt['setting_notify_enable_this'] = 'Enable user notifications of this event.';

$txt['setting_buddy'] = 'Arkadaşlar';
$txt['setting_likemsg'] = 'Beğeni';
$txt['setting_rlikemsg'] = 'Silinen beğeniler';
$txt['setting_mentionmem'] = '@bahsedenler';
$txt['setting_quotedmem'] = 'Alıntı';
$txt['setting_mailfail'] = 'Teslim Edilemedi';