<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Tarih';
$txt['badbehaviorlog_protocol'] = 'Protokol';
$txt['badbehaviorlog_method'] = 'Yöntem';
$txt['badbehaviorlog_request'] = 'İstek';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'Kullanıcı Kimliği';
$txt['badbehaviorlog_username'] = 'Kullanıcı adı';
$txt['badbehaviorlog_headers'] = 'Üst bilgiler';
$txt['badbehaviorlog_agent'] = 'Tarayıcı';
$txt['badbehaviorlog_entity'] = 'Gönder';
$txt['badbehaviorlog_key'] = 'Anahtar';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Toplam Girdi';
$txt['badbehaviorlog_error_valid_code'] = 'Sebep kodu';
$txt['badbehaviorlog_error_valid_response'] = 'HTTP Durumu';
$txt['badbehaviorlog_error_valid_explaination'] = 'HTTP Nedeni';
$txt['badbehaviorlog_error_valid_log'] = 'Detaylar';
$txt['badbehaviorlog_log'] = 'BadBehavior Kayıtları';
$txt['badbehaviorlog_desc'] = 'Kayıt altına alınmış bütün kötü davranışlar aşağıdadır';
$txt['badbehaviorlog_details'] = 'Ek Ayrıntılar';
$txt['badbehaviorlog_no_entries_found'] = 'Şimdilik kötü davranış kaydı bulunmamaktadır.';

$txt['badbehaviorlog_remove_selection'] = 'Seçilenleri sil';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Bütün kayıt girdilerini silmek istediğinizden emin misiniz?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Filtrelenmiş sonuçları temizle';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Filtrelenmiş sonuçları temizlemek istediğinizden emin misiniz?';
$txt['badbehaviorlog_sure_remove'] = 'Tüm kötü davranış kayıtlarını silmek istediğinizden emin misiniz?';

$txt['badbehaviorlog_remove'] = 'Seçilileri Sil';
$txt['badbehaviorlog_removeall'] = 'Tümünü Kaldır';
$txt['badbehaviorlog_clear_filter'] = 'Filtre oluştur';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Bu filtreyi uygula';
$txt['badbehaviorlog_apply_filter'] = 'Filtreyi Uygula';
$txt['badbehaviorlog_applying_filter'] = 'Filtre Uygulanıyor';
$txt['badbehaviorlog_filter_only_member'] = 'Sadece bu üyeye ait kötü davranış kayıtlarını göster';
$txt['badbehaviorlog_filter_only_ip'] = 'Sadece bu IP adresine ait kötü davranış kayıtlarını göster';
$txt['badbehaviorlog_filter_only_session'] = 'Sadece bu oturuma ait kötü davranış kayıtlarını göster';
$txt['badbehaviorlog_filter_only_headers'] = 'Sadece bu URL\'ye ait kötü davranış kayıtlarını göster';
$txt['badbehaviorlog_filter_only_agent'] = 'Sadece aynı tarayıcı bilgilerine ait kötü davranış kayıtlarını göster';

$txt['badbehaviorlog_session'] = 'Oturum';
$txt['badbehaviorlog_error_url'] = 'Sayfa URL\'si kayıt altına alındı';

$txt['badbehaviorlog_reverse_direction'] = 'Listenin kronolojik sıralamasını ters çevir';
$txt['badbehaviorlog_filter_only_type'] = 'Sadece bu koda ait kayıtları göster';