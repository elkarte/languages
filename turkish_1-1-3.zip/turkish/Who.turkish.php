<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm ... hiçbir fikrim yok, üzgünüm</em>';
$txt['who_admin'] = 'Yönetici portalını görüntülüyor';
$txt['who_moderate'] = 'Moderatör portalını görüntülüyor';
$txt['who_generic'] = '%1$s görüntülüyor';
$txt['who_unknown'] = '<em>Bilinmeyen Eylem</em>';
$txt['who_user'] = 'Kullanıcı';
$txt['who_time'] = 'Zaman';
$txt['who_action'] = 'Eylem';
$txt['who_show1'] = 'Göster';
$txt['who_show_members_only'] = 'Sadece Üyeler';
$txt['who_show_guests_only'] = 'Sadece Ziyaretçiler';
$txt['who_show_spiders_only'] = 'Sadece Örümcekler';
$txt['who_show_all'] = 'Herkes';
$txt['who_no_online_spiders'] = 'Şu anda herhangi bir örümcek çevrimiçi değildir.';
$txt['who_no_online_guests'] = 'Şu anda herhangi bir ziyaretçi çevrimiçi değildir.';
$txt['who_no_online_members'] = 'Şu anda herhangi bir üye çevrimiçi değildir.';

$txt['whospider_login'] = 'Giriş sayfasını görüntülüyor.';
$txt['whospider_register'] = 'Kayıt sayfasını görüntülüyor.';
$txt['whospider_reminder'] = 'Hatırlatma sayfasını görüntülüyor.';

$txt['whoall_activate'] = 'Hesabını etkinleştiriyor.';
$txt['whoall_buddy'] = 'Arkadaş listesini düzenliyor.';
$txt['whoall_coppa'] = 'Veli izni formunu dolduruyor.';
$txt['whoall_credits'] = 'Hazırlayanlar sayfasını görüntülüyor.';
$txt['whoall_emailuser'] = 'Başka bir üyeye e-posta gönderiyor.';
$txt['whoall_groups'] = 'Üye grupları sayfasını görüntülüyor.';
$txt['whoall_help'] = '<a href="{help_url}">Yardım</a> sayfasına bakıyor.';
$txt['whoall_quickhelp'] = 'Yardım iletisine bakıyor.';
$txt['whoall_pm'] = 'İletilerine bakıyor.';
$txt['whoall_auth'] = 'Giriş yapıyor.';
$txt['whoall_login'] = 'Giriş sayfasını görüntülüyor.';
$txt['whoall_login2'] = 'Giriş sayfasını görüntülüyor.';
$txt['whoall_logout'] = 'Çıkış yapıyor.';
$txt['whoall_markasread'] = 'Konuları okunmuş sayıyor.';
$txt['whoall_mentions'] = 'Bahsedenler listesini görüntülüyor.';
$txt['whoall_modifykarma_applaud'] = 'Bir üyenin karmasını arttırıyor.';
$txt['whoall_modifykarma_smite'] = 'Bir üyenin karmasını azaltıyor.';
$txt['whoall_news'] = 'Haberlere bakıyor.';
$txt['whoall_notify'] = 'Haberdar edilme ayarlarını değiştiriyor.';
$txt['whoall_notifyboard'] = 'Haberdar edilme ayarlarını değiştiriyor.';
$txt['whoall_openidreturn'] = 'OpenID kullanarak giriş yapıyor.';
$txt['whoall_quickmod'] = 'Bir bölümü yönetiyor.';
$txt['whoall_recent'] = '<a href="{recent_url}">son iletilerin</a> listesine bakıyor.';
$txt['whoall_register'] = 'Foruma üye oluyor.';
$txt['whoall_reminder'] = 'Şifre hatırlatmayı kullanıyor.';
$txt['whoall_reporttm'] = 'Bölüm yöneticisine bir konuyu rapor ediyor.';
$txt['whoall_spellcheck'] = 'Yazım denetleyicisini kullanıyor';
$txt['whoall_unread'] = 'Son gelişinden bu yana gönderilmiş yeni iletilere bakıyor.';
$txt['whoall_unreadreplies'] = 'En son yanıtladığı konulara gelen iletilere bakıyor.';
$txt['whoall_who'] = '<a href="{who_url}">Kim nerede</a>\'ye bakıyor.';

$txt['whoall_collapse_collapse'] = 'Bölüm kapatıyor.';
$txt['whoall_collapse_expand'] = 'Bölüm açıyor.';
$txt['whoall_pm_removeall'] = 'Tüm kişisel iletilerini siliyor.';
$txt['whoall_pm_send'] = 'Kişisel ileti gönderiyor.';
$txt['whoall_pm_send2'] = 'Kişisel ileti gönderiyor.';

$txt['whotopic_announce'] = '<a href="%1$s">%2$s</a>" konusunu duyuruyor.';
$txt['whotopic_attachapprove'] = 'Bir eklentiyi onaylıyor.';
$txt['whotopic_dlattach'] = 'Eklentiye bakıyor.';
$txt['whotopic_deletemsg'] = 'Bir iletiyi siliyor.';
$txt['whotopic_editpoll'] = '&quot;<a href="%1$s">%2$s</a>&quot;. konusundaki anketi düzenliyor.';
$txt['whotopic_editpoll2'] = '&quot;<a href="%1$s">%2$s</a>&quot;. konusundaki anketi düzenliyor.';
$txt['whotopic_jsmodify'] = '&quot;<a href="%1$s">%2$s</a>&quot;. konusunda bir iletiyi düzenliyor.';
$txt['whotopic_likes'] = '&quot;<a href="%1$s">%2$s</a>&quot başlıklı konudaki iletiyi beğeniyor.';
$txt['whotopic_lock'] = '&quot;<a href="%1$s">%2$s</a>&quot;. konusunu kilitliyor.';
$txt['whotopic_lockvoting'] = '&quot;<a href="%1$s">%2$s</a>&quot;. konusundaki anketi kilitliyor.';
$txt['whotopic_mergetopics'] = '&quot;<a href="%1$s">%2$s</a>&quot; konusunu başka bir konu ile birleştiriyor.';
$txt['whotopic_movetopic'] = '&quot;<a href="%1$s">%2$s</a>&quot; konusu başka bir bölüme taşınıyor.';
$txt['whotopic_movetopic2'] = '&quot;<a href="%1$s">%2$s</a>&quot; konusu başka bir bölüme taşınıyor.';
$txt['whotopic_post'] = '<a href="%1$s">%2$s</a> konusuna yanıt veriyor.';
$txt['whotopic_post2'] = '<a href="%1$s">%2$s</a> konusuna yanıt veriyor.';
$txt['whotopic_printpage'] = '&quot;<a href="%1$s">%2$s</a>&quot;  konusunu yazdırıyor.';
$txt['whotopic_quickmod2'] = '<a href="%1$s">%2$s</a> konusunu yönetiyor.';
$txt['whotopic_poll_remove'] = '&quot;<a href="%1$s">%2$s</a>&quot;   konusundaki anketi kaldırıyor.';
$txt['whotopic_removetopic2'] = '<a href="%1$s">%2$s</a>  konusunu kaldırıyor.';
$txt['whotopic_sendtopic'] = '&quot;<a href="%1$s">%2$s</a>&quot; konusunu arkadaşına gönderiyor.';
$txt['whotopic_splittopics'] = '&quot;<a href="%1$s">%2$s</a>&quot;  başlıklı konuyu bölüyor.';
$txt['whotopic_sticky'] = '&quot;<a href="%1$s">%2$s</a>&quot;  konusunu sabitleştiriyor.';
$txt['whotopic_unwatch'] = 'Bir konuyu izlemeyi bıraktı.';
$txt['whotopic_vote'] = '<a href="%1$s">%2$s</a> anketine oy veriyor.';
$txt['whotopic_watch'] = 'Bir konuyu izlemeye aldı.';

$txt['whopost_quotefast'] = ' &quot;<a href="%1$s">%2$s</a>&quot;  konusundan alıntı yapıyor.';

$txt['whoadmin_editagreement'] = 'Üyelik sözleşmesini düzenliyor.';
$txt['whoadmin_featuresettings'] = 'Forum özellik ve seçeneklerini düzenliyor.';
$txt['whoadmin_modlog'] = 'Moderasyon günlüğünü görüntülüyor.';
$txt['whoadmin_serversettings'] = 'Sunucuyu ayarlarını düzenliyor.';
$txt['whoadmin_packageget'] = 'Paket indiriyor.';
$txt['whoadmin_packages'] = 'Paket yöneticisini görüntülüyor.';
$txt['whoadmin_permissions'] = 'İzinleri düzenliyor.';
$txt['whoadmin_pgdownload'] = 'Paket indiriyor.';
$txt['whoadmin_theme'] = 'Tema ayarlarını düzenliyor.';
$txt['whoadmin_trackip'] = 'IP adresi takip ediyor.';

$txt['whoallow_manageboards'] = 'Bölüm ayarlarını düzenliyor.';
$txt['whoallow_admin'] = '<a href="{admin_url}">Yönetici sayfası</a>na bakıyor.';
$txt['whoallow_ban'] = 'Yasaklılar listesini düzenliyor.';
$txt['whoallow_boardrecount'] = 'Forum toplamlarını tekrar hesaplıyor.';
$txt['whoallow_calendar'] = '<a href="{calendar_url}">Takvim</a>e bakıyor.';
$txt['whoallow_editnews'] = 'Haberleri düzenliyor.';
$txt['whoallow_mailing'] = 'Forumdan E-Posta gönderiyor.';
$txt['whoallow_maintain'] = 'Bakım yapıyor.';
$txt['whoallow_manageattachments'] = 'Eklentileri düzenliyor.';
$txt['whoallow_moderate'] = '<a href="{moderate_url}">Moderasyon Bölümü</a>\'nü görüntülüyor.';
$txt['whoallow_memberlist'] = '<a href="{memberlist_url}">üye listesini</a> görüntülüyor.';
$txt['whoallow_optimizetables'] = 'Veritabanı tablolarını en iyi hale getiriyor.';
$txt['whoallow_repairboards'] = 'Veritabanı tablolarını onarıyor.';
$txt['whoallow_search'] = '<a href="{search_url}">Arama</a> yapıyor.';
$txt['whoallow_search_results'] = 'Arama sonuçlarına bakıyor.';
$txt['whoallow_setcensor'] = 'Sansürlü kelimeleri düzenliyor.';
$txt['whoallow_setreserve'] = 'Ayrılmış isimleri düzenliyor.';
$txt['whoallow_stats'] = '<a href="{stats_url}">Forum İstatistikleri</a>ne bakıyor.';
$txt['whoallow_viewErrorLog'] = 'Hata iletilerine bakıyor.';
$txt['whoallow_viewmembers'] = 'Üye listesine bakıyor.';

$txt['who_topic'] = '<a href="%1$s">%2$s</a> adlı konuya bakıyor';
$txt['who_board'] = '<a href="%1$s">%2$s</a> adlı bölüme bakıyor.';
$txt['who_index'] = '<a href="{script_url}">{forum_name}</a> ana sayfasına bakıyor.';
$txt['who_viewprofile'] = '<a href="%1$s">%2$s</a> kullanıcısının profiline bakıyor.';
$txt['who_profile'] = '<a href="%1$s">%2$s</a> kullanıcısının profilini düzenliyor.';
$txt['who_post'] = '<a href="%1$s">%2$s</a> bölümüne yeni konu açıyor.';
$txt['who_poll'] = '<a href="%1$s">%2$s</a> bölümüne yeni anket açıyor.';
$txt['who_topicbyemail'] = 'E-posta ile yeni konu başlatıyor  <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'E-posta ile yeni ileti gönderiyor  <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'E-posta ile kişisel ileti gönderiyor.';

// Credits text
$txt['credits'] = 'Hazırlayanlar - Ekip';
$txt['credits_intro'] = 'ElkArte 100% ücretsiz ve açık kaynaktır.  Katkıları kabul eden aktif, açık bir topluluğu teşvik eder ve destekliyoruz. Kod, geribildirim, hata raporları ve fikirler sağlayarak projeyi destekleyen herkese teşekkür ederiz, çünkü bunların hiçbiri sizin olmadan mümkün olmazdı. Ayrıca, ElkArte\'nin doğduğu <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF </a> \'yi özel olarak kabul diyoruz.';
$txt['credits_contributors'] = 'Katkıda bulunanlar';
$txt['credits_and'] = 've';
$txt['credits_copyright'] = 'Telif Hakkı';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Eklentiler';
$txt['credits_software_graphics'] = 'Yazılım/Grafik';
$txt['credits_software'] = 'Yazılım';
$txt['credits_graphics'] = 'Grafik';
$txt['credits_fonts'] = 'Fontlar';
$txt['credits_groups_contrib'] = 'Katkıda bulunanlar';
$txt['credits_contrib_list'] = 'Elkarte\'nin tasarım ve uygulamasına katkıda bulunan birçok kişinin tam listesi için lütfen resmi GitHub hesabında <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">katkıda bulunanların listesine bakınız.</a>';
$txt['credits_license'] = 'Lisans';
$txt['credits_copyright'] = 'Telif Hakkı';
$txt['credits_version'] = 'Sürüm';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Çevirmenler';
$txt['credits_translators_message'] = 'Tüm dünyadaki insanlara, ElkArte kullanabilmenizi sağlayan çabalarınız için teşekkür ederiz. Tam bir liste için resmi Transifeks <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">katkıda bulunanlar listesine bakınız.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';