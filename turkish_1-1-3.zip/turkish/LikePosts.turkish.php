<?php
// Version: 1.1; LikePosts

global $txt;

// Like posts stats strings
$txt['like_posts_stats_desc'] = 'Beğenilen ileti ve konularla ilgili istatistikler';
$txt['like_post_tab_mlm'] = 'En çok beğenilen iletiler';
$txt['like_post_tab_mlt'] = 'En çok beğenilen konular';
$txt['like_post_tab_mlb'] = 'En çok beğenilen bölümler';
$txt['like_post_tab_mlmember'] = 'En çok beğeni alan üyeler';
$txt['like_post_tab_mlgmember'] = 'En çok beğeni yapan üyeler';
$txt['like_post_generic_heading1'] = 'like(s)';
$txt['like_post_liked_by_others'] = 'Likes received';
$txt['like_post_show'] = 'Göster';
$txt['like_post_hide'] = 'Gizle';

// For message
$txt['like_post_users_who_liked'] = '%1% users liked this post';

// For topic
$txt['like_post_most_popular_topic_heading1'] = 'has received a total of (%1%) like(s).';
$txt['like_post_most_popular_topic_sub_heading1'] = 'The topic contains (%1%) liked posts.  %2% some of the liked posts from it.';

// For board
$txt['like_post_most_popular_board_heading1'] = 'has received';
$txt['like_post_most_popular_board_sub_heading1'] = 'The board contains';
$txt['like_post_most_popular_board_sub_heading2'] = 'topics, out of which';
$txt['like_post_most_popular_board_sub_heading3'] = 'topics are liked.';
$txt['like_post_most_popular_board_sub_heading4'] = 'The topics contain';
$txt['like_post_most_popular_board_sub_heading5'] = 'different posts, of which';
$txt['like_post_most_popular_board_sub_heading6'] = 'posts are liked.';

// Most liked user
$txt['like_post_total_likes_received'] = 'Alınan Toplam Beğeni Sayısı';
$txt['like_post_most_popular_user_heading1'] = '%1% this users most liked postings';

// Most like giving user
$txt['like_post_total_likes_given'] = 'Verilen Toplam Beğeni Sayısı';
$txt['like_post_most_like_given_user_heading1'] = '%1% this users recently liked posts';

// Like posts generic strings
$txt['like_post_topic'] = 'Konu';
$txt['like_post_message'] = 'İleti';
$txt['like_post_board'] = 'Bölüm';
$txt['like_post_total_posts'] = 'Toplam ileti';
$txt['like_post_posted_at'] = 'Tarihinde gönderildi';
$txt['like_post_read_more'] = 'Devamını oku';

// Error msgs
$txt['like_post_error_no_data'] = 'Maalesef, henüz gösterilecek bir şey yok gibi görünüyor!';
$txt['like_post_error_something_wrong'] = 'Üzgünüz, veri alınırken bir sorun var gibi görünüyor ...';
