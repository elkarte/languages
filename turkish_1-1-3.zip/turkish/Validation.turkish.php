<?php
// Version: 1.1; Validation

$txt['_validate_required'] = '%1$s alanı zorunlu.';
$txt['_validate_valid_email'] = '%1$s alanın geçerli bir e-posta adresi olması gerekiyor. ';
$txt['_validate_max_length'] = '%1$s alanının maksimum %2$s karakteri olabilir.';
$txt['_validate_min_length'] = '%1$s alanının minimum %2$skarakter olması gerekiyor.';
$txt['_validate_length'] = '%1$s alanının %2$s uzunluğunda olması gerekiyor.';
$txt['_validate_alpha'] = '%1$s alanı sadece harf içerebilir.';
$txt['_validate_alpha_numeric'] = '%1$s alanı yalnızca harf ve rakam içerebilir.';
$txt['_validate_alpha_dash'] = '%1$s alanı yalnızca &amp; tire içerebilir.';
$txt['_validate_numeric'] = '%1$salanı sayısal olmalıdır. ';
$txt['_validate_integer'] = '%1$s alanı sadece bir tam sayı içerebilir.';
$txt['_validate_boolean'] = '%1$salanı yalnızca bir boolean içerebilir. ';
$txt['_validate_float'] = '%1$salanı yalnızca bir kayan noktalı sayı içerebilir. ';
$txt['_validate_valid_url'] = '%1$salanının geçerli bir URL olması gerekiyor. ';
$txt['_validate_url_exists'] = '%1$sURL\'si mevcut değil. ';
$txt['_validate_valid_ip'] = '%1$salanının geçerli bir IPv4 adresi içermesi gerekiyor. ';
$txt['_validate_valid_ipv6'] = '%1$s alanının geçerli bir IPv6 adresi içermesi gerekiyor.';
$txt['_validate_contains'] = '%1$s alanının şu değerlerden birini içermesi gerekiyor: %2$s.';
$txt['_validate_invalid_function'] = 'Belirtilen doğrulama işlevi %1$s mevcut değil.';
$txt['_validate_without'] = '%1$s alanı %2$s karakterini içeremez.';
$txt['_validate_notequal'] = '%1$salanı geçerli bir değer içermiyor. ';
$txt['_validate_isarray'] = '%1$salanı geçerli bir dizi içermiyor. ';
$txt['_validate_php_syntax'] = 'PHP sözdizimi hatası: %2$s.';
$txt['_validate_limits'] = '%1$s alanına izin verilen sınırlar %2$s dışında bir değer var.';
$txt['_validate_generic'] = '%1$s alanı geçersiz bir deđer içeriyor.';
$txt['validation_failure'] = 'Form, devam etmeden önce düzeltilmesi gereken aşağıdaki hata veya hatalara sahiptir:';