<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Arama Parametleri Oluştur';
$txt['choose_board'] = 'Arama yapmak için bir bölüm seçin veya tümünde arayın';
$txt['all_words'] = 'Tüm kelimelerle eşleşsin';
$txt['any_words'] = 'Herhangi bir kelimeyle eşleşsin';
$txt['by_user'] = 'Kullanıcı tarafından';

$txt['search_post_age'] = 'İleti yaşı';
$txt['search_between'] = 'arasında';
$txt['search_and'] = 've';
$txt['search_options'] = 'Seçenekler';
$txt['search_show_complete_messages'] = 'Sonuçları ileti olarak göster';
$txt['search_subject_only'] = 'Arama sadece konu başlıklarını içersin';
$txt['search_relevance'] = 'İlişki';
$txt['search_date_posted'] = 'Tarihi';
$txt['search_order'] = 'Gösterim Önceliği';
$txt['search_orderby_relevant_first'] = 'Önce en ilişkili sonuçlar';
$txt['search_orderby_large_first'] = 'Önce en büyük konular';
$txt['search_orderby_small_first'] = 'Önce en küçük konular';
$txt['search_orderby_recent_first'] = 'Önce en son konular';
$txt['search_orderby_old_first'] = 'Önce en eski konular';
$txt['search_visual_verification_label'] = 'Doğrulama';
$txt['search_visual_verification_desc'] = 'Arama yapabilmek için yukarıdaki resimdeki kodu girmeniz gerekmektedir.';

$txt['search_specific_topic'] = 'Sadece konudaki iletiler aranıyor';

$txt['groups_search_posts'] = 'Arama fonksiyonuna erşilebilen üyegrupları';
$txt['search_dropdown'] = 'Hızlı Arama, açılır listesini etkinleştir';
$txt['search_results_per_page'] = 'Arama sonuçları sayfasında her sayfada gösterilecek sonuç sayısı';
$txt['search_weight_frequency'] = 'Bir konu içinde eşlenen ileti sayısı için arama ağırlığı';
$txt['search_weight_age'] = 'Son eşleşen iletinin zamanı için arama ağırlığı';
$txt['search_weight_length'] = 'Konu uzunluğu için arama ağırlığı';
$txt['search_weight_subject'] = 'Eşleşen bir başlık için arama ağırlığı';
$txt['search_weight_first_message'] = 'Eşleşen bir ileti için arama ağırlığı';
$txt['search_weight_sticky'] = 'Sabit bir konu için arama ağılığı';
$txt['search_weight_likes'] = 'Konu beğenileri için göreceli arama ağırlığı';

$txt['search_settings_desc'] = 'Burada arama fonksiyonu ile ilgili basit ayarları değiştirebilirsiniz.';
$txt['search_settings_title'] = 'Arama Ayarları';

$txt['search_weights_desc'] = 'Burada ilişkinin belirlenmesi sürecinde aktif olacak bileşenlerin değerlerini değiştirebilirsiniz.';
$txt['search_weights_sphinx'] = 'Sphinx ile ağırlık faktörlerini güncellemek için yeni bir sphinx.conf dosyası oluşturup kurmanız gerekir.';
$txt['search_weights_title'] = 'Arama - ağırlıklar';
$txt['search_weights_total'] = 'Toplam:';
$txt['search_weights_save'] = 'Kaydet';

$txt['search_method_desc'] = 'Burada aramanın nasıl yapılacağını seçebilirsiniz. 1.1 ile birlikte geniş indeksleme özellikleri getirilmiştir, indeksleme bir kelime listesi (fihrist) oluşturulması ve aramada bunun kullanılması anlamına gelmektedir, büyük sitelerde hıza büyük bir katkı sağlamaktadır.';
$txt['search_method_title'] = 'Arama - metod';
$txt['search_method_save'] = 'Kaydet';
$txt['search_method_messages_table_space'] = 'Forum iletilerı tarafında veritabanında kullanılan yer';
$txt['search_method_messages_index_space'] = 'Mesajları indekslemek için veritabanında kullanılan yer';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Tam kelime indeksi';
$txt['search_method_no_index_exists'] = 'şu anda bulunmamaktadır';
$txt['search_method_fulltext_create'] = 'Tam metin dizini oluştur';
$txt['search_method_fulltext_cannot_create'] = 'yaratılamıyor, ya karakter sayısı 65,535\'den büyük yada tablo türü MyISAM değil';
$txt['search_method_index_already_exists'] = 'zaten oluşturulmuş';
$txt['search_method_fulltext_remove'] = 'tam kelime indeksini kaldır';
$txt['search_method_index_partial'] = 'yarım yaratılmış';
$txt['search_index_custom_resume'] = 'devam et';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'Tam kelime aramayı kullanabilmeden önce, bir tam kelime indeksi yaratmanız gerekir!';
$txt['search_index_custom_warning'] = 'Özel indeksli aramayı kullanabilmek için önce bir özel indeks yaratmalısınız!';

$txt['search_index'] = 'Arama İndeksi';
$txt['search_index_none'] = 'İndeks yok';
$txt['search_index_custom'] = 'Özel indeks';
$txt['search_index_label'] = 'İndeks';
$txt['search_index_size'] = 'Boyut';
$txt['search_index_create_custom'] = 'Özel dizin oluştur';
$txt['search_index_custom_remove'] = 'Özel dizini kaldır';

$txt['search_index_sphinx'] = '  	Sphinx ';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'Sphinx ayarlarını yapmak için <a class="linkbutton" href="{managesearch_url}">Sphinx\'i yapılandırın</a>';

$txt['search_force_index'] = 'Arama indeksini zorunlu kıl';
$txt['search_match_words'] = 'Sadece tam kelimelerle eşleştir';
$txt['search_max_results'] = 'Gösterilecek en fazla sonuç';
$txt['search_max_results_disable'] = '(0: limit yok)';
$txt['search_floodcontrol_time'] = 'Bir kullanıcının üst üste arama yapabileceği süre';
$txt['search_floodcontrol_time_desc'] = '(0: limit yok)';

$txt['additional_search_engines'] = 'Ek arama motorları';
$txt['setup_search_engine_add_more'] = 'Başka bir arama motoru ekle';

$txt['search_create_index'] = 'İndeks oluştur';
$txt['search_create_index_why'] = 'İndeks neden oluşturulsun?';
$txt['search_create_index_start'] = 'Oluştur';
$txt['search_predefined'] = 'Öntanımlı profil';
$txt['search_predefined_small'] = 'Küçük İndeks';
$txt['search_predefined_moderate'] = 'Orta İndeks';
$txt['search_predefined_large'] = 'Büyük İndeks';
$txt['search_create_index_continue'] = 'Devam Et';
$txt['search_create_index_not_ready'] = 'ElkArte şu anda arama indeksinizi oluşturulmaktadır. Sunucunuz aşırı yüklenmemek için işlem geçici olarak duraklatıldı. Otomatik olarak birkaç saniye içinde devam etmelidir. Devam etmez ise, lütfen devam et düğmesini tıklayın.';
$txt['search_create_index_progress'] = 'Tamamlanma';
$txt['search_create_index_done'] = 'Özel arama indeksi oluşturuldu!';
$txt['search_create_index_done_link'] = 'Devam Et';
$txt['search_double_index'] = 'Şu anda iki indeks bulunmakta, en fazla performans için lütfen birini silin.';

$txt['search_error_indexed_chars'] = 'Geçersiz indeks uzunluğu. Kaliteli bir indeks için en az 3 harf gerekmektedir.';
$txt['search_error_max_percentage'] = 'Pas geçilecek kelimeler için geçersiz yüzde. Lütfen en az %5 kullanınız.';
$txt['error_string_too_long'] = 'Arama kelimesi %1$d karakterden az olmalıdır.';

$txt['search_warning_ignored_word'] = 'Aramanızdaki şu terim çok kısa olduğu için göz ardı edildi.';
$txt['search_warning_ignored_words'] = 'Aşağıdaki terimler, aramanızda dikkate alınmadı.';

$txt['search_adjust_query'] = 'Arama Seçeneklerini Belirle';
$txt['search_adjust_submit'] = 'Aramayı Tekrar Yap';
$txt['search_did_you_mean'] = 'Demek istemiş olanileceğiniz kelime';

$txt['search_example'] = '<em>Örnek</em>Gonçarov "Oblamov" -kitap';

$txt['search_engines_description'] = 'Bu bölümü kullanarak arama motorlarını forum\'da ne kadar izlemek istediğinizi ayarlayabilir ve arama kayıtlarını inceleyebilirsiniz.';
$txt['spider_mode'] = 'Arama Moturu İzleme Seviyesi';
$txt['spider_mode_note'] = 'Not yüksek seviyeler sunucunuzun kaynak kullanımını artırır.';
$txt['spider_mode_off'] = 'Kapalı';
$txt['spider_mode_standard'] = 'Standart';
$txt['spider_mode_high'] = 'Moderasyon';
$txt['spider_mode_vhigh'] = 'Çok Yüksek';
$txt['spider_settings_desc'] = 'Bu sayfayı kullanarak örümcekler hakkında kayıt tutmayı düzenleyebilirsiniz. Eğer tıklama kayıtlarının otomatik olarak temizlenmesini istiyorsanız, <a href="%1$s">buraya tıklayınız</a>.';

$txt['spider_group'] = 'Kısıtlayıcı izinlere izin ver';
$txt['spider_group_note'] = 'Bazı sayfaların indekslenmesini engellemenizi sağlar.';
$txt['spider_group_none'] = 'Kapalı';

$txt['show_spider_online'] = 'Örümcekleri kimler çevrimiçi listesinde göster';
$txt['show_spider_online_no'] = 'Gösterme';
$txt['show_spider_online_summary'] = 'Örümcek sayısını görüntüle';
$txt['show_spider_online_detail'] = 'Örümcek detayını görüntüle';
$txt['show_spider_online_detail_admin'] = 'Örümcek detayını görüntüle - sadece yöneticilere';

$txt['spider_name'] = 'Örümcek Adı';
$txt['spider_last_seen'] = 'Son Görülme';
$txt['spider_last_never'] = 'Hiç';
$txt['spider_agent'] = 'Kullanıcı Aracısı';
$txt['spider_ip_info'] = 'IP Adresleri';
$txt['spiders_add'] = 'Yeni Örümcek Ekle';
$txt['spiders_edit'] = 'Örümceği Düzenle';
$txt['spiders_remove_selected'] = 'Seçilenleri sil';
$txt['spider_remove_selected_confirm'] = 'Bu örümcekleri kaldırmak istediğinize emin misiniz?\\n\\nİlgili tüm istatistikler silinecektir!';
$txt['spiders_no_entries'] = 'Ayarlanmış örümcek bulunmuyor.';

$txt['add_spider_desc'] = 'Bu sayfada örümceklerin neye göre kategorize edildiğini düzenleyebilirsiniz. Eğer bir ziyaretçinin IP adresi veya user-agent\'ı bu örümceklerden biriyle eşleşirse, forum seçeneklerinde belirtildiği üzere kaydı tutulacaktır.';
$txt['spider_name_desc'] = 'Örümceğe verilecek isim.';
$txt['spider_agent_desc'] = 'Bu örümcekle alakalı user-agent.';
$txt['spider_ip_info_desc'] = 'Virgülle ayrılmış IP adresleri.';

$txt['spider_time'] = 'Zaman';
$txt['spider_viewing'] = 'Görüntülüyor';
$txt['spider_logs_empty'] = 'Şu anda örümcek kaydı bulunmuyor.';
$txt['spider_logs_info'] = 'Örümceğin tüm hareketleri sadece kayıt seviyesi &quot;yüksek&quot; veya &quot;çok yüksek&quot; olarak ayarlandıysa kayıt edilir. Örümceğin her hareketinin detayı ancak &quot;çok yüksek&quot; ayarı aktifse kayıt edilir.';
$txt['spider_disabled'] = 'Kapalı';
$txt['spider_log_empty_log'] = 'Tümünü Kaldır';
$txt['spider_log_empty_log_confirm'] = 'Kayıtları tamamen temizlemek istediğinize eminmisiniz';

$txt['spider_logs_delete'] = 'Girdileri Sil';
$txt['spider_logs_delete_older'] = '%1$s günden eski tüm girdileri kaldır';
$txt['spider_logs_delete_submit'] = 'Sil';

$txt['spider_stats_delete_older'] = '%1$s gün içinde görülmemiş tüm örümcek istatistiklerini sil.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Tüm logları boşaltmak istediğine eminmisin ?';

$txt['spider_stats_select_month'] = 'Şu Aya Git';
$txt['spider_stats_page_hits'] = 'Sayfa Görüntüleme';
$txt['spider_stats_no_entries'] = 'Örümcek istatistiği bulunmuyor.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'Arama Yönteminiz olarak henüz Sphinx veya SphinxQL kullanmayı seçmediniz.';
$txt['sphinx_test_passed'] = 'Tüm testler başarılı, sistem Sfenks API\'sini kullanarak sphinx arama sunucusuna bağlanabiliyor.';
$txt['sphinxql_test_passed'] = 'Tüm testler başarılı, sistem SphinxQL komutlarını kullanarak sphinx arama sunucusuna bağlanabiliyor.';
$txt['sphinx_test_connect_failed'] = 'Sphinx arka plan programına bağlanılamıyor. Çalıştığından ve yapılandırıldığından emin olun. Sorunu düzeltene kadar Sphinx arama çalışmaz.';
$txt['sphinxql_test_connect_failed'] = 'SphinxQL\'ye erişilemiyor. Sphinx.conf dosyanızın SphinxQL portu için ayrı bir dinleme yönergesi içerdiğinden emin olun. Sorunu düzeltene kadar SphinxQL arama çalışmaz';
$txt['sphinx_test_api_missing'] = 'Sphinxapi.php dosyası, &quot;kaynaklar&quot; Dizini. Bu dosyayı Sphinx dağıtımından kopyalamanız gerekiyor. Sorunu düzeltene kadar Sphinx arama çalışmaz.';
$txt['sphinx_description'] = 'Sphinx arama sunucunuza erişim ayrıntılarını sağlamak için bu arayüzü kullanın.<strong> Bu ayarlar yalnızca Sphinx yapılandırma dizininizde (genellikle / usr / local / etc veya / etc / sphinxsearch) </strong>kaydetmeniz gereken başlangıçtaki bir sphinx.conf yapılandırma dosyası oluşturmak için kullanılır. Genellikle, aşağıdaki seçeneklere dokunulmadan kalabilir, ancak Sophinx yazılımının / usr / local klasörüne kurulduğunu ve arama dizini veri deposu için / var / sphinx\'i kullandığını varsayarlar. Sphinx\'i güncel tutmak için dizinleri güncellemek için bir cron görevi kullanmanız gerekir; aksi takdirde yeni veya silinen içerik arama sonuçlarına yansımaz. Yapılandırma dosyası iki dizini tanımlar:<br /><br/><strong> elkarte_delta_index</strong>, yalnızca son değişiklikleri saklar ve sıkça çağrılabilen bir dizin. <strong>elkarte_base_index</strong>, veritabanının tamamını saklar ve daha az çağrılacak bir dizin. Örnek: <br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Dizin öneki:';
$txt['sphinx_index_prefix_desc'] = 'Bu tablo temel ve delta indeksleri için önektir. <br /> Varsayılan olarak elkarte kullanır ve iki indeks elkarte_base_index ve elkarte_delta_index olacaktır. Sphinx elkarte_index\'e (prefix_index) bağlanacaktır. Bunu değiştirirseniz, cron görevinizde doğru önek kullandığınızdan emin olun.';
$txt['sphinx_index_data_path'] = 'Dizin veri yolu:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Kayıt dosyası yolu:';
$txt['sphinx_log_file_path_desc'] = 'Sphinx tarafından oluşturulan günlük dosyalarını içerecek sunucu yolu. <br /> Bu dizin, sunucunuzda bulunmalı ve sphinx arama arka plan programı ve dizin oluşturucu tarafından yazılabilir olmalıdır.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indeksleyici bellek sınırı:';
$txt['sphinx_memory_limit_desc'] = 'İndeksleyicinin kullanmasına izin verilen azami (RAM) bellek miktarı.';
$txt['sphinx_searchd_server'] = 'Arama daemon sunucu:';
$txt['sphinx_searchd_server_desc'] = 'Arama servisini çalıştıran sunucunun adresi. Bu, geçerli bir ana makine adı veya IP adresi olmalıdır. <br /> Eğer ayarlanmazsa, localhost kullanılacaktır.';
$txt['sphinx_searchd_port'] = 'Arama daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Arama daemon dinleyeceği bağlantı noktası.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Arama arka plan programının SphinxQL sorgularını dinleyeceği bağlantı noktası.';
$txt['sphinx_max_matches'] = 'Maksimum # eşleşme sayısı:';
$txt['sphinx_max_matches_desc'] = 'Arama sunucusunun döneceği maksimum eşleşme miktarı.';
$txt['sphinx_create_config'] = 'Sphinx yapılandırması oluştur';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';