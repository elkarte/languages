<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Yanıt gönder';
$txt['post_in_board'] = 'Bölümde yayımla';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Alıntı Yap';
$txt['disable_smileys'] = 'Gülümsemeler Devre Dışı';
$txt['dont_use_smileys'] = 'Gülümseme kullanma.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Tarih';
$txt['standard'] = 'Standart';
$txt['thumbs_up'] = 'Yukarı Parmak';
$txt['thumbs_down'] = 'Aşağı Parmak';
$txt['exclamation_point'] = 'Ünlem İşareti';
$txt['question_mark'] = 'Soru İşareti';
$txt['icon_poll'] = 'Anket';
$txt['lamp'] = 'Lamba';
$txt['add_smileys'] = 'Gülümseme ekle';
$txt['topic_notify_no'] = 'Haber verilecek konu yok.';

$txt['rich_edit_wont_work'] = 'Tarayıcınız zengin metin düzenlemesini desteklememektedir.';
$txt['rich_edit_function_disabled'] = 'Tarayıcınız bu fonksiyonu desteklememektedir.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Buraya tıklayarak bu konudaki aboneliğinizi kaldırabilirsiniz';

$txt['lock_after_post'] = 'Gönderdikten sonra kilitle';
$txt['notify_replies'] = 'Yanıt gönderildiğinde haberdar et.';
$txt['lock_topic'] = 'Bu konuyu kilitle.';
$txt['shortcuts'] = 'kısa yollar: göndermek için shift+alt+s veya önizleme yapmak için shift+alt+p';
$txt['shortcuts_drafts'] = 'kısa yollar: shift+alt+s gönder/ilet, shift+alt+p önizle veya shift+alt+d taslak kaydet';
$txt['option'] = 'Seçenek';
$txt['reset_votes'] = 'Oyları Sıfırla';
$txt['reset_votes_check'] = 'Eğer verilen tüm oyları 0lamak isterseniz bunu işaretleyin.';
$txt['votes'] = 'oy';
$txt['attach'] = 'Dosya Ekle';
$txt['clean_attach'] = 'Eki Temizle';
$txt['attached'] = 'Eklentide Olan'; // @deprecated since 1.1
$txt['allowed_types'] = 'İzin verilen dosya türleri';
$txt['cant_upload_type'] = 'Bu tür dosya yükleyemezsiniz. İzin verilen dosya türleri %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Ekte olan dosyayı çıkartmak istiyorsanız  işareti kaldırın'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Dosya adı geçersiz. Lütfen farklı bir dosya adı deneyin.';
$txt['topic_locked_no_reply'] = 'Uyarı: Konu şu anda kilitlidir!<br />Sadece yöneticiler ve moderatörler yanıt verebilir.';
$txt['attachment_requires_approval'] = 'Bir moderatör tarafından onaylanana dek ekli dosyalar görüntülenmeyecektir.';
$txt['error_temp_attachments'] = 'Daha önceden eklediğiniz fakat iletmediğiniz ekler bulundu. Bu ekler şimdi bu iletiye eklenecektir. Eğer onları bu iletiye eklemek istemezseniz, <a href="#postAttachment">buraya</a> tıklayarak silebilirsiniz.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Hatırlatma: Bu ileti bir moderatör tarafından onaylanana dek görüntülenmeyecektir.';

$txt['enter_comment'] = 'Yorum ekle';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'İletiyi rapor';
$txt['reported_to_mod_by'] = 'gönderen';
$txt['rtm10'] = 'Gönder';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = '"1$s" başlıklı iletiyi gönderen';
$txt['reported_by'] = 'adlı üye';
$txt['board_moderate'] = 'tarafından rapor edilmiştir.';
$txt['report_comment'] = 'Raporu gönderenin yorumu';

$txt['attach_drop_files'] = 'Sürükleyip bırakarak veya <a class="drop_area_fileselect_text" href="javascript:void(0)">seçerek</a> dosyaları ekle';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Dosya Ekle</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'toplam boyut  en fazla  %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'Kişisel Boyut En Fazla  %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d post başına';
$txt['attach_restrictions'] = 'Kısıtlama:';

$txt['post_additionalopt_attach'] = 'Ekler ve diğer seçenekler';
$txt['post_additionalopt'] = 'Diğer seçenekler';
$txt['sticky_after'] = 'Konuyu sabitle.';
$txt['move_after2'] = 'Konuyu taşı.';
$txt['back_to_topic'] = 'Konuya geri dön.';
$txt['approve_this_post'] = 'Bu İletiyi Onayla';

$txt['retrieving_quote'] = 'Alıntı yapılıyor...';

$txt['post_visual_verification_label'] = 'Doğrulama';
$txt['post_visual_verification_desc'] = 'Bu iletiyi gönderebilmek için lütfen yukarıdaki resimdeki kodu giriniz.';

$txt['poll_options'] = 'Anket Seçenekleri';
$txt['poll_run'] = 'Anketi';
$txt['poll_run_limit'] = '(Limitsiz olması için boş bırakın)';
$txt['poll_results_visibility'] = 'Sonuç görünümü';
$txt['poll_results_anyone'] = 'Anket sonuçlarını herhangi biri görebilir.';
$txt['poll_results_voted'] = 'Sonuçları sadece üye oy verince göster.';
$txt['poll_results_after'] = 'Sonuçları sadece anket bittikten sonra göster.';
$txt['poll_max_votes'] = 'Her üyenin verebileceği en çok oy.';
$txt['poll_do_change_vote'] = 'Kullanıcılara oylarını değiştirebilmelerine izin ver.';
$txt['poll_too_many_votes'] = 'Çok fazla seçenek seçtiniz. Bu anket için en fazla %1$s seçenekte bulunabilirsiniz.';
$txt['poll_add_option'] = 'Seçenek Ekle';
$txt['poll_guest_vote'] = 'Ziyaretçilerin oy vermesine izin ver.';

$txt['spellcheck_done'] = 'Yazım denetimi tamamlandı.';
$txt['spellcheck_change_to'] = 'Bununla değiştir:';
$txt['spellcheck_suggest'] = 'Öneriler:';
$txt['spellcheck_change'] = 'Değiştir';
$txt['spellcheck_change_all'] = 'Tümünü Değiştir';
$txt['spellcheck_ignore'] = 'Yoksay';
$txt['spellcheck_ignore_all'] = 'Tümünü yoksay';

$txt['more_attachments'] = 'daha çok eklenti';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Üzgünüm, izin verilenden fazla eklenti gönderemezsiniz.';

$txt['more_smileys'] = 'daha';
$txt['more_smileys_title'] = 'Daha Fazla Gülümseme';
$txt['more_smileys_pick'] = 'Bir gülümseme seç';
$txt['more_smileys_close_window'] = 'Pencereyi kapat';

$txt['error_new_reply'] = 'Siz iletinizi yazarken yeni bir ileti daha gönderildi. Gönderilen iletiyi incelemeniz önerilir.';
$txt['error_new_replies'] = 'Siz iletinizi yazarken %1$d yeni ileti daha gönderildi. Gönderilen iletiyi incelemeniz önerilir.';
$txt['error_new_reply_reading'] = 'Siz iletinizi okurken yeni bir ileti daha gönderildi. Gönderilen iletiyi incelemeniz önerilir.';
$txt['error_new_replies_reading'] = 'Siz iletinizi okurken %1$d yeni ileti daha gönderildi.  Gönderilen iletiyi incelemeniz önerilir.';

$txt['announce_this_topic'] = 'Üyelere bu konu hakkında duyuru gönder:';
$txt['announce_title'] = 'Duyuru Gönderimi';
$txt['announce_desc'] = 'Bu form, konuyu seçili üye gruplarına göndermenizi sağlar.';
$txt['announce_sending'] = 'Konu Duyurusu Gönderiliyor';
$txt['announce_done'] = 'tamam';
$txt['announce_continue'] = 'Devam Et';
$txt['announce_topic'] = 'Duyuruyu gönder.';
$txt['announce_regular_members'] = 'Normal Üyeler';

$txt['digest_subject_daily'] = 'Günlük Derleme';
$txt['digest_subject_weekly'] = 'Haftalık Derleme';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'Şu konular başlatılmıştır';
$txt['digest_new_topics_line'] = '"%1$s" - %2$s ';
$txt['digest_new_replies'] = 'Şu konulara yanıtlar gönderilmiştir';
$txt['digest_new_replies_one'] = '1 yanıt - "%1$s"';
$txt['digest_new_replies_many'] = '%1$d yanıt - "%2$s"';
$txt['digest_mod_actions'] = 'Şu moderasyonlar gerçekleştirilmiştir';
$txt['digest_mod_act_sticky'] = '"%1$s" sabitlenmiştir';
$txt['digest_mod_act_lock'] = '"%1$s" kilitlenmiştir';
$txt['digest_mod_act_unlock'] = '"%1$s" kilidi açılmıştır';
$txt['digest_mod_act_remove'] = '"%1$s" kaldırılmıştır';
$txt['digest_mod_act_move'] = '"%1$s" taşınmıştır';
$txt['digest_mod_act_merge'] = '"%1$s" birleştirilmiştir';
$txt['digest_mod_act_split'] = '"%1$s" bölünmüştür';

$txt['attach_error_title'] = 'Ek yüklerken sorun.';
$txt['attach_warning'] = '<strong>%1$s</strong> yüklenmesi sırasında bir problem oluştu.';
$txt['attach_max_total_file_size'] = 'Üzgünüz, ek alanınız dolmuştur. İleti başına izin verilen ek boyutu %1$s KB. Kalan alan %2$s KB.';
$txt['attach_folder_warning'] = 'Ek dizini bulunamadı. Lütfen yöneticiyi bu sorun hakkında bilgilendirin.';
$txt['attach_folder_admin_warning'] = 'Ek dizin yolu (%1$s) yanlıştır. Lütfen yönetici panelinde ki ek ayarlarından düzeltin.';
$txt['attach_limit_nag'] = 'İleti başına izin verilen en fazla ek sayısına ulaştınız.';
$txt['attach_no_upload'] = 'Bir problem oluştu ve ekleriniz yüklenemedi.';
$txt['attach_remaining'] = '%1$d kaldı';
$txt['attach_available'] = '%1$s KB mevcut';
$txt['attach_kb'] = '(%1$s KB)';
$txt['attach_0_byte_file'] = 'Dosya boş gözüküyor. Eğer bu sorun olmaya devam ederse lütfen forum yöneticiniz ile iletişime geçin';
$txt['attached_files_in_session'] = '<em>Yukarı da altı çizili dosya(ları) yüklendi fakat gönderilene kadar iletiye eklenmeyecektir.</em>';

$txt['attach_php_error'] = 'Bir hatadan ötürü ekleriniz yüklenemedi. Hatanın devamı halinde lütfen forum yöneticisi ile iletişime geçin.';
$txt['php_upload_error_1'] = 'Yüklenen dosya php.ini içindeki upload_max_filesize yönergesini aşmaktadır. Eğer sorunu düzeltemiyorsanız, lütfen alan sağlayıcınız ile iletişime geçin.';
$txt['php_upload_error_3'] = 'Yüklenen dosya kısmi olarak yüklenmiştir. Bu PHP tabanlı bir hatadır. Eğer sorun devam ederse lütfen alan sağlayıcınız ile iletişime geçin.';
$txt['php_upload_error_4'] = 'Dosya yüklenemedi. Bu PHP ile ilgili bir sorundur. Eğer sorun devam ederse lütfen hostunuz ile iletişime geçin.';
$txt['php_upload_error_6'] = 'Kaydedilemedi. Bir geçici dizin eksik. Eğer bu sorunu düzeltemiyorsanız lütfen alan sağlayıcınızla iletişime geçin.';
$txt['php_upload_error_7'] = 'Dosya diske yazdırılamadı. Bu PHP ile ilgili bir sorundur. Eğer sorun devam ederse lütfen alan sağlayıcınızla iletişime geçin.';
$txt['php_upload_error_8'] = 'Bir PHP eklentisi dosya yüklemeyi durdurdu. Bu PHP tabanlı bir sorundur. Eğer sorun devam ederse lütfen alan sağlayınıcızla iletişime geçin.';
$txt['error_temp_attachments_new'] = 'Daha önce eklediğiniz fakat gönderilmeyen ekler bulunmaktadır. Bu ekler hala bu iletiye ekli durumdadır. Bu ekler kaydedilmeden veya silinmeden önce bu ileti gönderilmelidir. Bunu da <a href="#postAttachment">buradan</a> yapabilirsiniz';
$txt['error_temp_attachments_found'] = 'Aşağıda, önceden başka bir iletiye eklenmiş fakat gönderilmemiş ekler bulundu. Ekler kaldırılana veya o ileti gönderilene kadar bu ekleri göndermemeniz önerilir.<br />Ekleri kaldırmak için <a href="%1$s">buraya</a> tıklayın. Veya o iletiye dönmek için <a href="%2$s">buraya</a> tıklayın.%3$s ';
$txt['error_temp_attachments_lost'] = 'Aşağıda, daha önce başka iletiye eklenmiş fakat iletilmemiş ekler bulunmuştur. Gönderilen bu ekler kaldırılana veya iletilene kadar daha fazla ek yüklememeniz önerilir.<br />Bu ekleri kaldırmak için <a href="%1$s">buraya</a> tıklayın.%2$s';
$txt['error_temp_attachments_gone'] = 'Şu ekler kaldırıldı ve bir önce bulunduğunuz sayfaya döndünüz';
$txt['error_temp_attachments_flushed'] = 'Lütfen unutmayın önceden eklenmiş fakat iletilmemiş dosyalar kaldırılmıştır.';
$txt['error_topic_already_announced'] = 'Lütfen unutmayın bu konu zaten duyurulmuştur.';

$txt['cant_access_upload_path'] = 'Eklentinin adresine ulaşılamıyor!';
$txt['file_too_big'] = 'Dosyanız çok büyük. İzin verilen en büyük ek boyutu %1$s KB.';
$txt['attach_timeout'] = 'Eklentinizi kaydetmede bir sorun var, lütfen tekrar deneyin.';
$txt['bad_attachment'] = 'Ekiniz güvenlik kontrollerini geçemedi ve yüklenmedi. Lütfen forum yöneticisi ile danışın.';
$txt['ran_out_of_space'] = 'Yükleme dizini dolu. Lütfen bu sorun hakkında bir yönetici ile iletişim kurun.';
$txt['attachments_no_write'] = 'Eklentilerin yükleneceği yer yazılabilir değil. Eklentiniz veya avatarınızı kaydedilemedi.';
$txt['attachments_no_create'] = 'Yeni bir ek dizini yaratılamadı. Ekiniz veya avatarınız kaydedilemedi.';
$txt['attachments_limit_per_post'] = 'Bir ileti içerisinde en fazla %1$d eklenti gönderebilirsiniz';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'Yazı sonu sonrası genişletilebilir küçük resim';
$txt['insert'] = 'Ekle';
$txt['ila_opt_size'] = 'Boyut';
$txt['ila_opt_align'] = 'Hizalama';
$txt['ila_opt_size_thumb'] = 'Küçük resim';
$txt['ila_option2'] = 'Metin bağlantısı';
$txt['ila_option3'] = 'Kısa metin bağlantısı';
$txt['ila_opt_size_full'] = 'Tam boy';
$txt['ila_opt_size_cust'] = 'Özel boyut';
$txt['ila_opt_align_none'] = 'Yok';
$txt['ila_opt_align_left'] = 'Sol';
$txt['ila_opt_align_right'] = 'Sağ';
$txt['ila_opt_align_center'] = 'Ortala';
$txt['ila_confirm_removal'] = 'Bu eki kalıcı olarak kaldırmak istediğinizden emin misiniz?';
/*
$txt['ila_thereare'] = 'Yalnızca şu anda';
$txt['ila_attachment'] = 'ek(ler)';
$txt['ila_none'] = 'genişletilebilir küçük resim olarak';
$txt['ila_img'] = 'tam boyutlu grafik olarak';
$txt['ila_url'] = 'bir bağlantı olarak';
$txt['ila_mini'] = 'kompakt bir bağlantı olarak';
*/