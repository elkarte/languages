<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Varsayılan ElkArte teması <br /> <br /> Yazar: ElkArte katkıda bulunan kişiler
';