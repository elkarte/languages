<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Hoşgeldiniz';
$txt['install_step_exist'] = 'Varlık Kontrolü';
$txt['install_step_writable'] = 'Yazılabilirlik Kontrolü';
$txt['install_step_forum'] = 'Temel Ayarlar';
$txt['install_step_databaseset'] = 'Veritabanı Ayarları';
$txt['install_step_databasechange'] = 'Veritabanı Bilgi Girişi';
$txt['install_step_admin'] = 'Yönetici Hesabı';
$txt['install_step_delete'] = 'Yüklemeyi Tamamla';

$txt['installer'] = 'ElkArte Yükleyicisi';
$txt['installer_language'] = 'Dil';
$txt['installer_language_set'] = 'Dil Paketi';
$txt['congratulations'] = 'Tebrikler, kurulum süreci başarı ile tamamlandı!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Yükleme klasörünüz hala yazılılabilirdir. Güvenlik nedeniyle klasörü yazılamaz hale getirmeniz önerilir.';
$txt['delete_installer'] = 'Yükleme dizinini silmek için burayı tıklayın.';
$txt['delete_installer_maybe'] = '<i>(her sunucuda çalışmayabilir.)</i>';
$txt['go_to_your_forum'] = 'Şimdi <a href="%1$s">yeni yüklenen forumunuza</a> göz atabilir ve hemen kullanmaya başlayabilirsiniz. Yönetim merkezine erişebilmek için daha önce sağlamış olduğunuz kullanıcı bilgileri ile oturum açmayı ihmal etmeyiniz.';
$txt['good_luck'] = 'ElkArte kurulumu için teşekkürler!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Hoşgeldiniz';
$txt['install_welcome_desc'] = 'ElkArte\'ye hoşgeldiniz. Bu yükleme yazılımı, gerçekleştirmek istediğiniz %1$s yüklemesinde sizi adım adım yönlendirecektir. Bir sonraki adımlarda forumunuzla ilgili bilgi toplanacak, birkaç dakika içerisinde ise forumunuz kullanıma hazır olacaktır.';
$txt['install_all_lovely'] = 'Sunucunuzla ilgili ön testleri tamamladık ve herşey yolunda gibi gözüküyor. Başlamak için aşağıda bulunan &quot;Devam Et&quot; butonuna tıklayınız..';

$txt['user_refresh_install'] = 'Forum Yenilendi';
$txt['user_refresh_install_desc'] = 'Yükleme sırasında yükleme aygıtının ihtiyacı olan bazı tabloların daha önceden oluşturulduğu belirlendi.<br />Kayıp tablolar tekrar oluşturulmuş, varolan veride ise değişiklik yapılmamıştır.';

$txt['default_topic_subject'] = 'ElkArte\'ye Hoş Geldiniz!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Genel Sohbet';
$txt['default_board_description'] = 'Bu bölümde istediğiniz her konuda sohbet edebilirsiniz.';
$txt['default_category_name'] = 'Genel Kategori';
$txt['default_time_format'] = '%d %B %Y, %H:%M:%S';
$txt['default_news'] = 'ElkArte  - Henüz Yeni Yüklendi!';
$txt['default_karmaLabel'] = 'Karma';
$txt['default_karmaSmiteLabel'] = '[azalt]';
$txt['default_karmaApplaudLabel'] = '[artır]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGuest\\nroot\\nYönetici';
$txt['default_smileyset_name'] = 'Fugue\'nin Seti';
$txt['default_theme_name'] = 'ElkArte Varsayılan Teması';

$txt['default_administrator_group'] = 'Yönetici';
$txt['default_global_moderator_group'] = 'Genel Moderatör';
$txt['default_moderator_group'] = 'Moderatör';
$txt['default_newbie_group'] = 'Yeni Üye';
$txt['default_junior_group'] = 'Acemi Üye';
$txt['default_full_group'] = 'Tam Üye';
$txt['default_senior_group'] = 'Kıdemli Üye';
$txt['default_hero_group'] = 'Kahraman Üye';

$txt['default_smiley_smiley'] = 'Gülümseme';
$txt['default_wink_smiley'] = 'Göz Kırp';
$txt['default_cheesy_smiley'] = 'Peynir';
$txt['default_grin_smiley'] = 'Sırıt';
$txt['default_angry_smiley'] = 'Sinirli';
$txt['default_sad_smiley'] = 'Üzgün';
$txt['default_shocked_smiley'] = 'Şokta';
$txt['default_cool_smiley'] = 'Cool';
$txt['default_huh_smiley'] = 'Ha?';
$txt['default_roll_eyes_smiley'] = 'Gözleri Dönüyor';
$txt['default_tongue_smiley'] = 'Dil Çıkart';
$txt['default_embarrassed_smiley'] = 'Utangaç';
$txt['default_lips_sealed_smiley'] = 'Dudaklar Mühürlü';
$txt['default_undecided_smiley'] = 'Kararsız';
$txt['default_kiss_smiley'] = 'Öpücük';
$txt['default_cry_smiley'] = 'Ağla';
$txt['default_evil_smiley'] = 'Kötücül';
$txt['default_azn_smiley'] = 'Azn';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Kahkaha';
$txt['default_police_smiley'] = 'Polis';
$txt['default_angel_smiley'] = 'Melek';

$txt['error_message_click'] = 'Buraya tıklayarak';
$txt['error_message_try_again'] = 'bu adımı tekrar deneyebilirsiniz.';
$txt['error_message_bad_try_again'] = 'yükleme işlemini gerçekleştirmeyi tekrar deneyebilirsiniz ama unutmayın bu işlem tarafımızdan <em>önerilmemektedir.</em>';

$txt['install_settings'] = 'Temel Ayarlar';
$txt['install_settings_info'] = 'Kurulumunuz için gerekli birkaç ayarı tanımlamak gerektirir. ElkArte sizin için otomatik olarak gerekli ayarları tespit etti.';
$txt['install_settings_name'] = 'Forum ismi';
$txt['install_settings_name_info'] = 'Bu forumunuzun ismi olacaktır, örn. &quot;Test Forumu&quot;.';
$txt['install_settings_name_default'] = 'Benim Topluluğum';
$txt['install_settings_url'] = 'Forum URL\'si';
$txt['install_settings_url_info'] = 'Forumunuzun adresi <b>(sonuna \'/\' eklemeyin!)</b>.<br />Çoğu zaman bu kutucuktaki alana dokunmazsanız doğru değer atanır.';
$txt['install_settings_compress'] = 'Gzip Çıktısı';
$txt['install_settings_compress_title'] = 'Çıktıyı bant genişliğinden tasarruf etmek için sıkıştır.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'Bu özellik her sunucuda çalışmayabilir ancak size bant genişliği açısından büyük bir kazanım sunar.<br />Sınamak için <a href="install.php?obgz=1&amp;pass_string=KULLANILABİLİR" onclick="return reqWin(this.href, 200, 60);" target="_blank">buraya</a> tıklayın. (Sadece "KULLANILABİLİR" demek gerekir.)';
$txt['install_settings_dbsession'] = 'Veritabanı Oturumları';
$txt['install_settings_dbsession_title'] = 'Oturum için dosyalar yerine veritabanını kullan.';
$txt['install_settings_dbsession_info1'] = 'Bu özellik oturumları daha güvenilir yapar.';
$txt['install_settings_dbsession_info2'] = 'Bu özelliği aktif etmek iyi bir fikirdir, fakat bu özellik sunucunuzda düzgün çalışacak gibi gözükmüyor.';
$txt['install_settings_proceed'] = 'Devam Et';

$txt['db_settings'] = 'Veritabanı Sunucusu Ayarları';
$txt['db_settings_info'] = 'Veritabanına bağlanmak için gerekli olan ayarlar. Eğer değerleri bilmiyorsanız, barındırma firmanızdan gerekli bilgiyi alabilirsiniz.';
$txt['db_settings_type'] = 'Veritabanı türü';
$txt['db_settings_type_info'] = 'Desteklenen birden fazla veritabanı sağlayıcısı bulundu - hangisini kullanmak istiyorsunuz?';
$txt['db_settings_server'] = 'Sunucu ismi';
$txt['db_settings_server_info'] = 'Bu genellikle localhost\'dur - eğer bilmiyorsanız localhost\'u deneyin.';
$txt['db_settings_port'] = 'B. Noktası';
$txt['db_settings_port_info'] = 'Varsayılanı kullanmak için boş bırakın';
$txt['db_settings_username'] = 'Kullanıcı Adı';
$txt['db_settings_username_info'] = 'Veritabanına bağlanmak için buraya kullanıcı adınızı girmeniz gerekiyor.<br />Eğer ne olduğunu bilmiyorsanız, FTP kullanıcı adını deneyebilirsiniz, çoğu zaman eşleşecektir.';
$txt['db_settings_password'] = 'Şifre';
$txt['db_settings_password_info'] = 'Veritabanına bağlanmak için buraya şifrenizi girmeniz gerekiyor.<br />Eğer ne olduğunu bilmiyorsanız, FTP şifenizi deneyebilirsiniz, çoğu zaman eşleşecektir.';
$txt['db_settings_database'] = 'Veritabanı adı';
$txt['db_settings_database_info'] = 'ElkArte için kullanmak istediğiniz veritabanı ismini giriniz.';
$txt['db_settings_database_info_note'] = 'Eğer belirttiğiniz veritabanı bulunamazsa, yükleyici veritabanını oluşturma girişiminde bulunacaktır.';
$txt['db_settings_database_file'] = 'Veritabanı dosya adı';
$txt['db_settings_database_file_info'] = 'Bu ElkArte\'in verisinin bulunacağı veritabanı dosyasıdır. Veritabanı dosyasını açık ağ alanınızın dışında bir konumda bulundurmayı ve rastgele oluşturulmuş bir isim kullanmanız şiddetle önerilir.';
$txt['db_settings_prefix'] = 'Veritabanı tablo öneki';
$txt['db_settings_prefix_info'] = 'Veritabanındaki her tablo için önektir.  <b>Aynı önek ile iki forum kurmayı denemeyin!</b><br />bu değer tek veritabanına birden fazla  yükleme yapabilmek için gereklidir.';
$txt['db_populate'] = 'Veritabanına Bilgi Yüklemesi Tamamlandı';
$txt['db_populate_info'] = 'Ayarlarınız kaydedildi ve veritabanınız forumunuzun çalışması ile gerekli tüm veri ile dolduruldu. Bilgi yüklemenin özeti:';
$txt['db_populate_info2'] = 'Yönetici hesabınızı oluşturmak için &quot;Devam Et&quot; tuşuna basınız.';
$txt['db_populate_inserts'] = '%1$d satır girildi.';
$txt['db_populate_tables'] = '%1$d tablo oluşturuldu.';
$txt['db_populate_insert_dups'] = '%1$d ikiz girdi yoksayıldı.';
$txt['db_populate_table_dups'] = '%1$d ikiz tablo yoksayıldı.';

$txt['user_settings'] = 'Hesabınızı Oluşturun';
$txt['user_settings_info'] = 'Yükleme sizin için şimdi yeni bir yönetici hesabı oluşturacaktır.';
$txt['user_settings_username'] = 'Kullanıcı Adınız';
$txt['user_settings_username_info'] = 'Giriş yapmak için kullanacağınız kullanıcı adını belirtiniz.';
$txt['user_settings_password'] = 'Şifre';
$txt['user_settings_password_info'] = 'Şifrenizi yazın, ve sakın unutmayın!';
$txt['user_settings_again'] = 'Şifre';
$txt['user_settings_again_info'] = '(doğrulayın)';
$txt['user_settings_email'] = 'E-Posta Adresi';
$txt['user_settings_email_info'] = 'E-Posta adresinizi belirtin.  <b>Geçerli bir e-posta adresi olmalıdır.</b>';
$txt['user_settings_database'] = 'Veritabanı Şifresi';
$txt['user_settings_database_info'] = 'Yükleme aygıtı güvenlik nedenlerinden dolayı, yönetici hesabı açılması için veritabanı şifrenize tekrar ihtiyaç duymaktadır.';
$txt['user_settings_skip'] = 'Atla';
$txt['user_settings_skip_sure'] = 'Yönetici hesabı oluşturmayı atlamak istediğinize emin misiniz?';
$txt['user_settings_proceed'] = 'Bitir';

$txt['ftp_checking_writable'] = 'Dosya Yazılabilirliği Kontrol Ediliyor';
$txt['ftp_setup'] = 'FTP Bağlantı Bilgileri';
$txt['ftp_setup_info'] = 'Yükleme aygıtı FTP ile bağlanarak onarım yapamıyor. Eğer otomatik olarak yapılmıyorsa kendiniz dosyaları tek tek yazılabilir konuma getirmelisiniz. Unutmayın şu anda SSL yi desteklemiyor.';
$txt['ftp_server'] = 'Sunucu';
$txt['ftp_server_info'] = 'Sizin FTP sunucunuza ait sunucu adı ve bağlantı noktası sağlanmalıdır.';
$txt['ftp_port'] = 'B. Noktası';
$txt['ftp_username'] = 'Kullanıcı Adı';
$txt['ftp_username_info'] = 'Giriş yapılacak kullanıcı adı. <em>Hiçbir yere kaydedilmeyecektir.</em>';
$txt['ftp_password'] = 'Şifre';
$txt['ftp_password_info'] = 'Giriş yapılacak şifre. <i>Hiçbir yere kaydedilmeyecektir.</i>';
$txt['ftp_path'] = 'Kurulum Dizini';
$txt['ftp_path_info'] = 'FTP sunucunuza <i>bağlı</i> olarak değişir.';
$txt['ftp_path_found_info'] = 'Yukardaki kutudaki konum otomatik olarak bulundu.';
$txt['ftp_connect'] = 'Bağlan';
$txt['ftp_setup_why'] = 'Bu adım ne için?';
$txt['ftp_setup_why_info'] = 'Bazı dosyalar forum\'unuzdan daha fazla verim alabilmeniz için yazılabilir yapılmak zorundadırlar. Bu basamak yükleme aygıtının bu dosyaları sizin yerinize yazılabilir yapmasını sağlar, ancak bazı durumlarda bu özelliği yerine getiremez. Bu dosyaların erişim haklarını 777 (yazılabilir, bazı barındırıcılarda 755) yapınız:';
$txt['ftp_setup_again'] = 'dosyaların yazılabilirliğini dene.';

$txt['error_php_too_low'] = 'Uyarı! ElkArte\'nin ihtiyaçlarını karşılayabilecek bir PHP serverı kurulmadığı belirlenmiştir <strong>minimum yükleme gereksinimleri</strong>.<br />Eğer host değil iseniz hostunuzu değiştirmenizi veya hostunuz ile temasa geçerek PHP versiyonunun yükseltilmesini isteyiniz<br /><br />Mevcut PHP versiyonunun size yeteceğini düşünüyorsanız devam edebilirsiniz ancak bu tavsiye edilmez.';
$txt['error_missing_files'] = 'Kurulum dosyaları bulunamıyor!<br /><br />Lütfen kurulum paketinin tamamnın ve sql dosyalarının yüklendiğinden emin olun, ve tekrar deneyin.';
$txt['error_session_save_path'] = 'Hostunuzu bu konu hakkında bilgilendirin <b>php.ini içinde bulunan session.save_path </b> geçerli değil!  <b>Varolan</b>  bir dizin olarak değiştirilmesi gerekmektedir, ve <b>yazdırılabilir</b>olmalıdır.<br />';
$txt['error_windows_chmod'] = 'Şu an bir windows serverındasınız ve bazı dosyalar yazdırılabilir değil. Hostunuzdan size <strong>yazma izni</strong> vermesini isteyiniz. ElkArte kurulumu için belirtilen dosya veya dizinlerin yazdırılabilir olmaları gerekmektedir:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Bu detaylar çerçevesinde FTP servera bağlanması imkansızdır.';
$txt['error_db_file'] = 'Veritabanı kaynak dosyası bulunamadı. Lütfen %1$s dosyasının kaynak dosyalar klasöründe olduğundan emin olun.';
$txt['error_db_connect'] = 'MySQL database serverına bağlanılamıyor.<br /><br />Eğer ne yazacağınızı bilmiyorsanız, hostunuz ile irtibata geçiniz.';
$txt['error_db_too_low'] = 'Bu server eski veritabanı versiyonunu kullanıyor, ve bu sürüm ElkArte\'nin çalışması için yetmez.<br /><br />Lütfen hostunuzdan versiyonun yükseltilmesini isteyiniz, aksi takdirde başka bir hostu deneyiniz.';
$txt['error_db_database'] = 'Yükleme aygıtı &quot;<em>%1$s</em>&quot; veritabanına giremiyor.  Bazı hostlarda ElkArte  admin panelinden kendiniz veritabanı oluşturmanız gerekmektedir. Bazılarıda sizin adınızı veya veritabanı ismi eklerler.';
$txt['error_db_queries'] = 'Bazı sorgular hala yerine getirilmedi. Eski bir MySQL versiyonundan kaynaklanıyor olabilir.<br /><br />Sorgular hakkından teknik bilgiler:';
$txt['error_db_queries_line'] = 'Satır #';
$txt['error_db_missing'] = 'Yükleme aygıtı PHP de veritabanı desteği bulamamaktadır. Lütfen hostunuzun veritabanı  ile desteklenmiş bir PHP kurulumunu yaptıklarından emin olmalarını sağlayınız. Şu anda ElkArte\'in desteklediği: &quot;%1$s&quot;  uzantılar';
$txt['error_db_script_missing'] = 'Yükleyici, saptanan veritabanları için yükleme komut dosyası bulamadı. Lütfen tüm dosyaları forum klasörünüze yüklediğinizden emin olunuz, örn: &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Yükleyici sunucunuzda bulunan PHP de oturum (session) desteği bulamadı. Lütfen hosting firmanızla bu konu ile ilgili iletişime geçin.'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'İki farklı şifre girdiniz!';
$txt['error_user_settings_no_password'] = 'Şifreniz en az 4 karakterden oluşmalıdır.';
$txt['error_user_settings_taken'] = 'Üzgünüz, bu isimle veya e-posta adresi ile bir kullanıcı bulunmaktadır.<br /><br />Yeni bir hesap oluşturulamadı.';
$txt['error_user_settings_query'] = 'Bir administrator hesabı oluşturulurken database hatası meydana gelmiştir. Bu hata:';
$txt['error_subs_missing'] = 'Sources/Subs.php dosyası bulunamıyor.  Lütfen uygun konuma yüklendiğinden emin olun ve tekrar deneyin.';
$txt['error_db_alter_priv'] = 'Seçili veritabanı hesabı ALTER, CREATE, ve/veya DROP komutlarını kullanmak için yetkili değil; ElkArte\'nin doğru çalışması için gerekli izinleri lütfen atayın.';
$txt['error_versions_do_not_match'] = 'Yükleme aygıtı verdiğiniz bilgilerle daha önceden bir ElkArte yüklemesi yapılmış olduğunu tespit etti. Eğer forum sürümünüzü yükseltmek istiyorsanız, yükleme yerine güncelleme paketini indirmeniz gerekmektedir.<br /><br />Eğer yükseltme yapmıyorsanız, yeni veritabanı erişim bilgileri girebilir veya eski verilerinizi yedekledikten sonra veritbanınızdaki tabloları silebilirsiniz.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'Sahip olduğunuz veritabanı sürümü UTF-8 karakter setini desteklememektedir. ElkArte yüklemesi yapamazsınız.';
$txt['error_valid_email_needed'] = 'Geçerli bir e-posta adresi girmediniz.';
$txt['error_already_installed'] = 'Yükleyici ElkArte\'nin zaten kurulu olduğunu tespit etti. Mevcut bir yüklemenin üzerine  <strong>yazmamaya</strong> dikkat edin - yükleme işlemine devam etmek <strong>varolan verilerin kaybolmasına veya bozulmasına neden olabilir</strong>. <ul><li>Forumunuzu yüklemeyi yeni bitirdiyseniz, lütfen sunucunuzdan yükleme dizinini silin. {try_delete}</li><li> Yükseltmek istiyorsanız lütfen yükseltme<a href="./upgrade.php"><strong> komut dosyasını kullanın. </strong>Verileriniz de dahil olmak üzere mevcut kurulumunuzun üzerine yazmak isterseniz, mevcut veritabanı tablolarını silmeniz ve Settings.php dosyasını değiştirmeniz ve tekrar denemeniz önerilir.<li></li>';
$txt['error_no_settings'] = 'Settings.php ve / veya Settings_bak.php\'in forumunuzun varsayılan dizininde olmadığı görünüyor, ElkArte kurulumla birlikte verilen örnek dosyaların adını değiştirmeye çalışacaktır. Bu işlem başarısız olursa, lütfen bu komut dosyasını çalıştırmadan önce Settings.sample.php ve Settings_bak.sample.php\'yi Settings.php ve Setting_bak.php olarak yeniden adlandırın.';
$txt['error_settings_do_not_exist'] = 'Elkarte dosya/ları bulamıyor ve oluşturamıyor <strong>%1$s</strong>. Lütfen forumunuzun dizinine gitmek için ftp kullanın ve bu betiği yeniden çalıştırmadan önce aşağıdaki gibi kurulum paketiyle birlikte verilen örnek dosyaları yeniden adlandırın: <ul>%2$s</ul>Dosyalardan herhangi biri yoksa, aynı ada sahip boş bir dosya oluşturun.';
$txt['error_warning_notice'] = 'Uyarı!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'SQLite için veritabanı dosya ismi girmeniz gerekmektedir.';
$txt['error_db_prefix_numeric'] = 'Seçtiğiniz veritabanı tipi rakamsal önekleri desteklememektedir.';
$txt['error_invalid_characters_username'] = 'Kullanıcı adında geçersiz karakter kullanılmıştır.';
$txt['error_username_too_long'] = 'Kullanıcı adı 25 karakterden az olmalıdır.';
$txt['error_username_left_empty'] = 'Kullanıcı adı alanı boş bırakılamaz.';
$txt['error_db_filename_exists'] = 'Oluşturmak istediğiniz veritabanı zaten bulunmakta. Lütfen varolan dosyayı kaldırınız veya farklı bir dosya adı kullanınız.';
$txt['error_db_prefix_reserved'] = 'Kullanmış olduğunuz önek ayrılmıştır. Lütfen başka bir öneki girmeyi deneyiniz.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Güncelleme Aracı';
$txt['upgrade_warning'] = 'Uyarı!';
$txt['upgrade_critical_error'] = 'Kritik Hata!';
$txt['upgrade_continue'] = 'Devam Et';
$txt['upgrade_retry'] = 'Tekrar dene';
$txt['upgrade_skip'] = 'Atla';
$txt['upgrade_note'] = 'Not!';
$txt['upgrade_step'] = 'Aşama';
$txt['upgrade_steps'] = 'Aşama';
$txt['upgrade_progress'] = 'Tamamlanma';
$txt['upgrade_overall_progress'] = 'Toplam İlerleme';
$txt['upgrade_step_progress'] = 'Aşama İlerlemesi';
$txt['upgrade_time_elapsed'] = 'Geçen Zaman';
$txt['upgrade_time_mins'] = 'dakika';
$txt['upgrade_time_secs'] = 'saniye';

$txt['upgrade_incomplete'] = 'Tamamlanmamış';
$txt['upgrade_not_quite_done'] = 'Tam olarak tamamlanmadı!';
$txt['upgrade_paused_overload'] = 'Sunucunuza aşırı yüklenilmemesi için güncellemeye ara verilmiştir. Endişelenmeyin, yanlış giden bir şey yoktur - devam etmek için aşağıdaki <label for="contbutt">devam et butonuna</label> tıklamanız yeterli olacaktır.';

$txt['upgrade_ready_proceed'] = 'ElkArte\'yi %1$s sürümüne yükseltmeyi seçtiğiniz için teşekkür ederiz. Tüm dosyalar yerinde ve işlemin başlatılması için her şey hazır.';

$txt['upgrade_error_script_js'] = 'Yükleyici, script.js dosyasını bulamadı veya güncel olmadığını tespit etti. Lütfen tema konumlarınızın doğru ayarlandığından emin olunuz. Ayar kontrol aracımızı <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte Araçlar</a> sayfasından indirebilirsiniz.';

$txt['upgrade_warning_lots_data'] = 'Yükleyici forum\'unuzda güncellenmesi gereken çok fazla veri olduğunu tespit etti. Bu işlem sunucunuza ve forum boyutunuza göre biraz zaman alabilir, çok büyük forumlarda ise (~300,000 ileti) tamamlanması birkaç saat sürebilir. ';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';