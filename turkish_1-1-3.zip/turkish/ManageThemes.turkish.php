<?php
// Version: 1.1; ManageThemes

$txt['themeadmin_explain'] = 'Temalar, forum\'unuzun görüntüsünü değiştiren paketlerdir.  Bu ayarlar, tema seçimini ve ziyaretçiler ile üyelerin kullanacakları temaları belirler.';
$txt['themeadmin_manage'] = 'Yönet ve Yükle';
$txt['theme_forum_theme'] = 'Genel Tema Ayarları';
$txt['theme_allow'] = 'Üyelerin kullanacakları temayı kendilerinin seçmelerine izin ver.';
$txt['theme_guests'] = 'Forum varsayılanı';
$txt['theme_select'] = 'seç...';
$txt['theme_reset'] = 'Aşağıdaki temaya bağlı herkesi sıfırla:';
$txt['theme_nochange'] = 'Değişiklik yok';
$txt['theme_forum_default'] = 'Forum Varsayılanı';

$txt['theme_remove'] = 'Kaldır';
$txt['theme_remove_confirm'] = 'Bu temayı kaldırmak istediğinize emin misiniz?';

$txt['theme_install'] = 'Yeni Tema Yükle';
$txt['theme_install_file'] = 'Bir arşivden (örneğin: .zip, .tar.gz)';
$txt['theme_install_dir'] = 'Sunucudaki bir dizinden';
$txt['theme_install_error'] = 'Belirtmiş olduğunuz dizin yanlış veya geçerli bir tema bulundurmamakta';
$txt['theme_install_write_error'] = 'Devam edilebilmesi için tema dizini yazılabilir olmalıdır!';
$txt['theme_install_go'] = 'Yükle';
$txt['theme_install_new'] = 'Varsayılan ElkArte temasının kopyasını oluştur';
$txt['theme_install_new_confirm'] = 'Bu temayı yüklemek istediğinize emin misiniz?';
$txt['theme_install_writable'] = 'Dikkat - tema dizininiz yazılabilir olmadığı için, yeni bir tema oluşturamaz veya yükleyemezsiniz!';
$txt['theme_install_general'] = 'Belirtmiş olduğunuz dizin yanlış veya geçerli bir tema bulundurmamakta, bilgileri kontrol ediniz.';
$txt['theme_installed'] = 'Yükleme Tamamlandı';
$txt['theme_installed_message'] = 'başarıyla yüklenmiştir.';

$txt['theme_pick'] = 'Tema seçin...';
$txt['theme_preview'] = 'Temayı ön-izle';
$txt['theme_set'] = 'Bu temayı kullan';
$txt['theme_user'] = 'kişi bu temayı kullanıyor.';
$txt['theme_users'] = 'kişi bu temayı kullanıyor.';
$txt['theme_pick_variant'] = 'Tema Biçmini Seç';

$txt['theme_edit'] = 'Temayı düzenle';
$txt['theme_edit_style'] = 'Stil dosyasını düzenle. (renkler, yazı tipleri, vs.)';
$txt['theme_edit_index'] = 'Index şablonunu düzenle. (ana şablon)';
$txt['theme_edit_no_save'] = 'Bu dosya yazılabilir olmadığı için kaydedilemiyor!  Lütfen aşağıdaki dosyanın chmod 777 olduğundan veya uygun izinlerin verildiğinden emin olun';
$txt['theme_edit_save'] = 'Değişiklikleri kaydet.';
$txt['theme_edit_not_writable'] = 'Yazılabilir Değil';

$txt['theme_global_description'] = 'Bu tema varsayılan forum temasıdır. Forumda yapılacaklar değişiklikler bu tema üzerinde olacaktır.';

$txt['theme_url_config'] = 'Tema URL\'leri ve Ayarları';
$txt['theme_variants'] = 'Tema Biçimleri';
$txt['theme_options'] = 'Tema Seçenekleri ve Özellikleri';
$txt['actual_theme_name'] = 'Tema adı: ';
$txt['actual_theme_dir'] = 'Tema dizini: ';
$txt['actual_theme_url'] = 'Tema URL\'si: ';
$txt['actual_images_url'] = 'Tema resimlerinin URL\'si: ';

$txt['theme_variants_default'] = 'Varsayılan tema biçimi:';
$txt['theme_variants_user_disable'] = 'Kullanıcıların tema biçimi seçebilmelerini engelle';

$txt['site_slogan'] = 'Site sloganı';
$txt['site_slogan_desc'] = '(Buraya slogan için kendi metninizi ekleyin.)';
$txt['header_layout'] = 'Üstbilgi düzeni:';
$txt['header_layout_desc'] = '(Bu ayar, üstbilgi için üç düzenden birini seçmenize izin verir.)';
$txt['header_layout_default_name'] = 'Varsayılan';
$txt['header_layout_default_desc'] = 'Logo sağda ve solda topluluğun adı yer alıyor.';
$txt['header_layout_logo_only_name'] = 'Sadece logo:';
$txt['header_layout_logo_only_desc'] = 'Sadece logo, ortada olacak şekilde görüntülenir.';
$txt['header_layout_inverted_name'] = 'Soldaki Logo:';
$txt['header_layout_inverted_desc'] = 'Varsayılana benzer, ancak logo ve adı ters çevrilmiş haldedir (diğer bir deyişle sağda ad, solda logo).';
$txt['header_layout_default'] = 'Varsayılan';
$txt['header_layout_logo_only'] = 'Sadece logo:';
$txt['header_layout_inverted'] = 'Logo Solda';
$txt['forum_width'] = 'Forum genişliği:';
$txt['forum_width_desc'] = '(Forum genişliğini ayarı. Örneğin: 950px, 80% , 1240px.)';

$txt['enable_news'] = 'Forum üst bölümünde ki haberler satırı:';
$txt['enable_news_off'] = 'Kapalı';
$txt['enable_news_random'] = 'Rastgele';
$txt['enable_news_fader'] = 'Geçiş';
$txt['enable_news_off_name'] = 'Kapalı:';
$txt['enable_news_off_desc'] = 'Haberler gösterilmez';
$txt['enable_news_random_name'] = 'Rastgele:';
$txt['enable_news_random_desc'] = 'Rastgele haberleri aktifleştir.';
$txt['enable_news_fader_name'] = 'Geçiş:';
$txt['enable_news_fader_desc'] = 'Tüm haberler sırayla görüntülenir.';

$txt['show_group_key'] = 'Ana sayfa bölümünde grup başlıklarını göster.';
$txt['additional_options_collapsible'] = 'Açılır-kapanır ek ileti seçeneklerini etkinleştir';
$txt['who_display_viewing'] = 'Ana sayfaya ve iletilere bakanları göster:';
$txt['who_display_viewing_off'] = 'gösterilmesin';
$txt['who_display_viewing_numbers'] = 'sayıları gösterilsin';
$txt['who_display_viewing_names'] = 'isimleri gösterilsin';
$txt['show_stats_index'] = 'Ana sayfada istatistikleri göster';
$txt['latest_members'] = 'Forum anasayfasında son üyeyi göster';
$txt['last_modification'] = 'İletilerde son düzenleme tarihini göster.';
$txt['user_avatars'] = 'Mesaj görünümünde kullanıcı avatarları göster.';
$txt['member_list_bar'] = 'Forum anasayfasında üye listesi bölümünü göster';
$txt['current_pos_text_img'] = 'Forumdaki güncel pozisyonu metin yerine bağlantı olarak göster.';
$txt['show_view_profile_button'] = 'Gönderi altındaki görünümde profil butonunu göster.';
$txt['enable_mark_as_read'] = '\'Okundu olarak işaretle\' butonlarını etkinleştir ve göster.';
$txt['header_logo_url'] = 'Site Logosunun Adresi:';
$txt['header_logo_url_desc'] = '(Boş bırakırsanız varsayılan logo veya forum ismi görüntülenecektir)';

$txt['recent_post_topics'] = 'Forum ana sayfasında son ileti veya son konuları göster.';
$txt['show_recent_topics'] = 'Son konuları göster';
$txt['show_recent_posts'] = 'Son iletileri göster';
$txt['number_recent_posts'] = 'Forum ana sayfasında gösterilen ileti veya son konu sayısı:';
$txt['number_recent_posts_desc'] = '(devre dışı bırakmak için bu değeri sıfıra ayarlayın.)';
$txt['hide_post_group'] = 'Gruplandırılmış üyeler için  grup başlıklarını gizle.';
$txt['hide_post_group_desc'] = '(Bunu etkinleştirirseniz, üyeyi ileti tabanlı olmayan bir gruba atandıysanız,  üyenin ileti grup başlığını mesaj görünümünde görüntülemez.)';

$txt['theme_options_defaults'] = 'Varsayılan kişisel görünüm ayarlarıdır. Değişiklikler sadece yeni üyeler ve ziyaretçiler için etkili olur.';
$txt['theme_options_title'] = 'Varsayılan seçenekleri değiştir veya sıfırla';

$txt['themeadmin_title'] = 'Tema Yönetimi ve Seçenekler';
$txt['themeadmin_description'] = 'Burada tema ayarlarınızı değiştirebilir, seçilebilir temaları güncelleyebilir ve kişisel birçok tema seçeneğini düzenleyebilirsiniz.';
$txt['themeadmin_admin_desc'] = 'Burada varsayılan temayı değiştirebilir, tüm üyelerin temalarını sıfırlayabilir veya tema seçimi ile ilgili diğer ayarlarda değişiklikler yapabilirsiniz. Aynı zamanda buradan yeni temalar da yükleyebilirsiniz. Temanızın ayarlarını ve görünümünü değiştirmek için Temalar Ayarları\' na göz atmayı unutmayın.';
$txt['themeadmin_list_desc'] = 'Burada yüklü olan temaları görebilir, konumlarını ve ayarlarını değiştirebilir veya kaldırabilirsiniz.';
$txt['themeadmin_reset_desc'] = 'Tüm kullanıcılarınız için varolan kişisel tema özelliklerini değiştirebilirsiniz.';
$txt['themeadmin_edit_desc'] = 'Burada yüklü temalarınızın sitil ve kaynak kodlarını düzenleyebilirsiniz.  Temel CSS ve PHP bilgisi gerektirir.';
$txt['themeadmin_modify_styles'] = 'Changing a themes style is risky so be certain of what you are doing. Always have a backup copy of the theme directory that you are working in to use to recover from an error with. For help with this before you start, visit the <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">ElkArte Community</a>.';

$txt['themeadmin_list_heading'] = 'Tema Ayarları';
$txt['themeadmin_list_tip'] = 'Unutmayın görünüm ayarları bir temadan diğerine değişebilir.  Temaların özelliklerini ayarlamak için ayarlamak istediğiniz temanın üstüne tıklayın. Buradan ayrıca tema klasörlerinin konumlarını veya URL\'lerini değiştirebilirsiniz.';
$txt['themeadmin_list_theme_dir'] = 'Temanın klasörü:';
$txt['themeadmin_list_invalid'] = '( Dikkat girdiğiniz bilgi doğru değildir!)';
$txt['themeadmin_list_theme_url'] = 'Yukarıdaki klasörün URL\'si:';
$txt['themeadmin_list_images_url'] = 'Resimler klasörü URL\'si:';
$txt['themeadmin_list_reset'] = 'Tüm tema URL\'lerini ve klasörlerini sıfırla';
$txt['themeadmin_list_reset_dir'] = 'Ana tema klasörü';
$txt['themeadmin_list_reset_url'] = 'Yukarıdaki klasörün URL\'si:';
$txt['themeadmin_list_reset_go'] = 'Tüm temaları sıfırla';

$txt['themeadmin_reset_tip'] = 'Her temanın kendine özgü kullanıcılar tarafından değiştirilebilir özellikleri olabilir.  Bu özellikler arasında avatarlar ve imzalar, görünüm seçenekleri ve başka benzer ayarlar yer alabilir.  Burada varsayılan ayarları değiştirebilir veya herkesin ayarlarını sıfırlayabilirsiniz.<br /><br />Unutmayın: Bazı temalar varsayılan seçenekleri kullanırlar, bu durumda doğal olarak kendilerine özgü ayarları olmayacaktır.';
$txt['themeadmin_reset_defaults'] = 'Bu tema için varsayılan (aynı zamanda ziyaretçilerin sahip olacağı) ayarları sıfırla';
$txt['themeadmin_reset_defaults_current'] = 'özel ayar bulunmakta.';
$txt['themeadmin_reset_members'] = 'Bu tema için üyelerin sahip olduğu ayarları sıfırla';
$txt['themeadmin_reset_remove'] = 'Bu tema için tüm üyelerin ayarlarını sıfırla ve varsayılan olanları kullan';
$txt['themeadmin_reset_remove_current'] = 'üye kendi ayarlarını kullanmakta.';
// Don't use entities in the below string.
$txt['themeadmin_reset_remove_confirm'] = 'Tüm tema ayarlarını kaldırmak istediğinize emin misiniz?\\nBu aynı zamanda bazı kişisel profil seçeneklerinin değişmesine de neden olabilir.';
$txt['themeadmin_reset_options_info'] = 'Aşağıda yapacağınız ayarlar <em>herkes</em>\'in ayarlarını değiştirecektir.  Bir ayarı değiştirmek için, ayarın solundaki kutudaki &quot;değiştir&quot; seçeneğini seçin, ve sonra da sağda nasıl değiştirilmesini istediğinizi seçin.  Varsayılan olanı seçmek için &quot;kaldır&quot; seçeneğini aktif edin.  Eğer ilgili ayarı değiştirmeyip, olduğu gibi bırakmak istiyorsanız &quot;değiştirme&quot; seçeneğini aktif edin.';
$txt['themeadmin_reset_options_change'] = 'Değiştir';
$txt['themeadmin_reset_options_none'] = 'Değiştirme';
$txt['themeadmin_reset_options_default'] = 'Varsayılan';

$txt['themeadmin_edit_browse'] = 'Bu temadaki dosyalara göz atın ve düzenle.';
$txt['themeadmin_edit_style'] = 'Bu temanın stil (css) dosyasını düzenle.';
$txt['themeadmin_edit_copy_template'] = 'Bu tema tabanlı yeni bir tema oluştur.';
$txt['themeadmin_edit_exists'] = 'zaten bulunmakta';
$txt['themeadmin_edit_do_copy'] = 'kopyala';
$txt['themeadmin_edit_copy_warning'] = 'Sistem ihtiyacı olduğu bir görünüm veya dil dosyasını ilgili temanın klasöründe bulamadığında, temanın tabanlı olduğu temada veya varsayılan tema da o dosyaları arar.<br>Eğer bir görünüm dosyasını değiştirmeyecekseniz, dosyayı kopyalamamak daha iyidir.';
$txt['themeadmin_edit_copy_confirm'] = 'Bu temayı kopyalamak istediğinize emin misiniz?';
$txt['themeadmin_edit_overwrite_confirm'] = 'Bu temayı diğerinin üzerine kopyalamak istediğinize emin misiniz?\\nBu yapmış olduğunuz tüm değişikliklerin KAYBOLMASINA neden olacaktır';
$txt['themeadmin_edit_no_copy'] = '<em>(kopyalanamıyor)</em>';
$txt['themeadmin_edit_filename'] = 'Dosya Adı';
$txt['themeadmin_edit_modified'] = 'Son Değiştirilme Tarihi';
$txt['themeadmin_edit_size'] = 'Boyut';
$txt['themeadmin_edit_error'] = 'Kaydetmiş olduğunuz dosya aşağıdaki hataya neden oldu:';
$txt['themeadmin_edit_on_line'] = 'Satır:';
$txt['themeadmin_edit_preview'] = 'Önizleme';
$txt['themeadmin_selectable'] = 'Kullanıcının seçmesine izin verilen temalar:';
$txt['themeadmin_themelist_link'] = 'Yüklü temaların listesini göster';

// Strings for the variants
$txt['variant_light'] = 'ElkArte hafif';
$txt['variant_besocial'] = 'ElkArte Sosyal ol!';
