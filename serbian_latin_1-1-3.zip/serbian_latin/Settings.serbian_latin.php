<?php
// Version: 1.1; Settings

$txt['theme_description'] = 'Podrazumevana ElkArte tema.<br /><br />Autor: ElkArte saradnici';