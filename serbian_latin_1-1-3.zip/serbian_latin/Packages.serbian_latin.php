<?php

// Version: 1.1; Packages

$txt['package_proceed'] = 'Nastavi';
$txt['package_id'] = 'ID';
$txt['list_file'] = 'Spisak datoteka u paketu';
$txt['files_archive'] = 'Datoteke u arhivi';
$txt['package_browse'] = 'Pretraži';
$txt['add_server'] = 'Dodaj server';
$txt['server_name'] = 'Ime servera';
$txt['serverurl'] = 'URL';
$txt['no_packages'] = 'Trenutno nema paketa.';
$txt['download'] = 'Preuzmi';
$txt['download_success'] = 'Paket uspešno preuzet';
$txt['package_downloaded_successfully'] = 'Paket je uspešno preuzet';
$txt['package_manager'] = 'Paketi';
$txt['install_mod'] = 'Install Add-on';
$txt['uninstall_mod'] = 'Uninstall Add-on';
$txt['no_adds_installed'] = 'No addons currently installed';
$txt['uninstall'] = 'Deinstaliraj';
$txt['delete_list'] = 'Delete Add-on List';
$txt['package_delete_list_warning'] = 'Are you sure you wish to clear the installed addons list?';

$txt['package_manager_desc'] = 'From this easy to use interface, you can download and install addons for use on your forum.';
$txt['installed_packages_desc'] = 'Ovde možete da pogledate pakete koji su trenutno instalirani na vašem forumu i uklonite one koji vam više ne trebaju.';
$txt['download_packages_desc'] = 'From this section you can add or remove package servers, browse for packages, or download new packages from servers.';
$txt['package_servers_desc'] = 'From this easy to use interface, you can manage your package servers and download addon archives on your forum.';
$txt['upload_packages_desc'] = 'From this section you can upload a package file from your local computer directly to the forum.';

$txt['upload_new_package'] = 'Upload new package';
$txt['view_and_remove'] = 'View and remove installed packages';
$txt['modification_package'] = 'Add-on packages';
$txt['avatar_package'] = 'Avatar packages';
$txt['language_package'] = 'Language packages';
$txt['unknown_package'] = 'Other packages';
$txt['smiley_package'] = 'Smiley packages';
$txt['use_avatars'] = 'Koristi avatare';
$txt['add_languages'] = 'Dodaj jezik';
$txt['list_files'] = 'Spisak datoteka';
$txt['package_type'] = 'Tip paketa';
$txt['extracting'] = 'Raspakujem';
$txt['avatars_extracted'] = 'The avatars have been installed, you should now be able to use them.';
$txt['language_extracted'] = 'The language pack has been installed, you can now enable its use in the language settings area of your admin control panel.';

$txt['mod_name'] = 'Add-on Name';
$txt['mod_version'] = 'Verzija';
$txt['mod_author'] = 'Autor';
$txt['author_website'] = 'Stranica autora';
$txt['package_no_description'] = 'No description given';
$txt['package_description'] = 'Opis';
$txt['file_location'] = 'Preuzmi';
$txt['bug_location'] = 'Issue tracker';
$txt['support_location'] = 'Support';
$txt['mod_hooks'] = 'No source edits';
$txt['mod_date'] = 'Last updated';
$txt['mod_section_count'] = 'Browse the (%1d) addons in this section';

// Package Server strings
$txt['package_current'] = '(%s <em>You have the Current version %s</em>)';
$txt['package_update'] = '(%s <em>An update for your %s version is available</em>)';
$txt['package_installed'] = 'installed';
$txt['package_downloaded'] = 'preuzeto';

$txt['package_installed_key'] = 'Installed addons:';
$txt['package_installed_current'] = 'trenutna verzija';
$txt['package_installed_old'] = 'starija verzija';
$txt['package_installed_warning1'] = 'This package is already installed, and no upgrade was found.';
$txt['package_installed_warning2'] = 'Trebalo bi da prvo deinstalirate stariju verziju kako biste izbegli probleme ili zamolite autora da napravi ažuriranje sa vaše starije verzije.';
$txt['package_installed_warning3'] = 'Ne zaboravite da uvek redovno napravite rezervne kopije izvornih datoteka i baze podataka pre instaliranja modifikacija a posebno onih koji su još uvek u beta verziji.';
$txt['package_installed_extract'] = 'Raspakujem paket';
$txt['package_installed_done'] = 'Paket je uspešno instaliran. Sada ćete moći da koristite koje god funkcije da dodaje ili menja ili da ne koristite funkcije koje uklanja.';
$txt['package_installed_redirecting'] = 'Preusmeravam...';
$txt['package_installed_redirect_go_now'] = 'Preusmeri odmah';
$txt['package_installed_redirect_cancel'] = 'Vrati se na menadžer paketa';

$txt['package_upgrade'] = 'Ažuriraj';
$txt['package_uninstall_readme'] = 'Deinstalacija: pročitaj me';
$txt['package_install_readme'] = 'Instalacija: pročitaj me';
$txt['package_install_license'] = 'Licensa';
$txt['package_install_type'] = 'Tip';
$txt['package_install_action'] = 'Akcija';
$txt['package_install_desc'] = 'Opis';
$txt['install_actions'] = 'Akcije instalacije';
$txt['perform_actions'] = 'This will perform the following actions:';
$txt['corrupt_compatible'] = 'The package you are trying to download or install is either corrupt or not compatible with this version of the software.';
$txt['package_create'] = 'Napravi';
$txt['package_move'] = 'Premesti';
$txt['package_delete'] = 'Obriši';
$txt['package_extract'] = 'Raspakuj';
$txt['package_file'] = 'Datoteka';
$txt['package_tree'] = 'direktorijum';
$txt['execute_modification'] = 'Izvrši modifikaciju';
$txt['execute_code'] = 'Izvrši kod';
$txt['execute_database_changes'] = 'Execute file';
$txt['execute_hook_add'] = 'Add Hook';
$txt['execute_hook_remove'] = 'Remove Hook';
$txt['execute_hook_action'] = 'Adapting hook %1$s';
$txt['package_requires'] = 'Requires Modification';
$txt['package_check_for'] = 'Check for installation:';
$txt['execute_credits_add'] = 'Add Credits';
$txt['execute_credits_action'] = 'Credits: %1$s';

$txt['package_install_actions'] = 'Opcije instalacije za';
$txt['package_will_fail_title'] = 'Error in package %1$s';
$txt['package_will_fail_warning'] = 'At least one error was encountered during a test %1$s of this package.<br />It is <strong>strongly</strong> recommended that you do not continue with %1$s unless you know what you are doing, and have made a backup very recently.<br /><br />This error may be caused by a conflict between the package you\'re trying to install and another package you have already installed, an error in the package, a package which requires another package that you have not installed yet, or a package designed for another version of the software.';
$txt['package_will_fail_unknown_action'] = 'The package is trying to perform an unknown action: %1$s';
// Don't use entities in the below string.
$txt['package_will_fail_popup'] = 'Are you sure you wish to continue installing this addon, even though it will not install successfully?';
$txt['package_will_fail_popup_uninstall'] = 'Are you sure you wish to continue uninstalling this addon, even though it will not uninstall successfully?';
$txt['package_install'] = 'installation';
$txt['package_uninstall'] = 'removal';
$txt['package_install_now'] = 'Install now';
$txt['package_uninstall_now'] = 'Uninstall now';
$txt['package_other_themes'] = 'Install in other themes';
$txt['package_other_themes_uninstall'] = 'UnInstall in other themes';
$txt['package_other_themes_desc'] = 'To use this addon in themes other than the default, the package manager needs to make additional changes to the other themes. If you\'d like to install this addon in the other themes, please select these themes below.';
// Don't use entities in the below string.
$txt['package_theme_failure_warning'] = 'Došlo je do barem jedne greške prilikom probnog instaliranja na ovoj temi. Da li ste sigurni da želite da probate instalaciju?';

$txt['package_bytes'] = 'bajtova';

$txt['package_action_missing'] = '<strong class="error">Datoteka nije nađena</strong>';
$txt['package_action_error'] = '<strong class="error">Greška pri raščlanjivanju modifikacije</strong>';
$txt['package_action_failure'] = '<strong class="error">Test nije uspeo</strong>';
$txt['package_action_success'] = '<strong>Test je uspeo</strong>';
$txt['package_action_skipping'] = '<strong>Preskačem datoteku</strong>';

$txt['package_uninstall_actions'] = 'Akcije za deinstaliranje';
$txt['package_uninstall_done'] = 'The package has been successfully uninstalled.';
$txt['package_uninstall_cannot'] = 'This package cannot be uninstalled, because there is no uninstaller.<br /><br />Please contact the addon author for more information.';

$txt['package_install_options'] = 'Opcije instaliranja';
$txt['package_install_options_desc'] = 'Set various options for how the package manager installs addons, including backups and ftp access';
$txt['package_install_options_ftp_why'] = 'Korišćenje FTP-a je najlakši način kada morate da ručno podesite datoteke da budu otvorene za upisivanje kako bi menadžer paketa mogao da radi.<br />Ovde možete da podesite podrazumevane vrednosti za neka polja.';
$txt['package_install_options_ftp_server'] = 'FTP server';
$txt['package_install_options_ftp_port'] = 'Port';
$txt['package_install_options_ftp_user'] = 'Korisničko ime';
$txt['package_install_options_make_backups'] = 'Napravi rezervne kopije zamenjenih datoteka sa tildom (~) na krajevima njihovih imena.';
$txt['package_install_options_make_full_backups'] = 'Create an entire backup (excluding smileys, avatars and attachments) of the ElkArte install.';

$txt['package_ftp_necessary'] = 'FTP informacije su neophodne';
$txt['package_ftp_why'] = 'Some of the files the package manager needs to modify are not writable.  This needs to be changed by logging into FTP and using it to chmod or create the files and directories.  Your FTP information may be temporarily cached for proper operation of the package manager. Note you can also do this manually using an FTP client - <a href="#" onclick="%1$s">to view a list of the affected files please click here</a>.';
$txt['package_ftp_why_file_list'] = 'Sledeće datoteke moraju da se otvore za upisivanje pre nastavljanja sa instalacijom';
$txt['package_ftp_why_download'] = 'In order to download packages, the packages directory, and any files in it, must be writable.  Currently the system does not have the needed permissions to write to this directory.  The package manager can use your FTP information to attempt to fix this problem.';
$txt['package_ftp_server'] = 'FTP server';
$txt['package_ftp_port'] = 'Port';
$txt['package_ftp_username'] = 'Korisničko ime';
$txt['package_ftp_password'] = 'Lozinka';
$txt['package_ftp_path'] = 'Local path to ElkArte';
$txt['package_ftp_test'] = 'Test';
$txt['package_ftp_test_connection'] = 'Test';
$txt['package_ftp_test_success'] = 'FTP veza je ostvarena.';
$txt['package_ftp_test_failed'] = 'Ne mogu da se povežem sa serverom.';
$txt['package_ftp_bad_server'] = 'Ne mogu da se povežem sa serverom.';

// For a break, use \\n instead of <br />... and don't use entities.
$txt['package_delete_bad'] = 'Paket koji hoćete da obrišete je trenutno instaliran. Ako ga obrišete, možda kasnije nećete moći da ga deinstalirate.\\n\\nDa li ste sigurni?';

$txt['package_examine_file'] = 'Pogledaj datoteke u paketu';
$txt['package_file_contents'] = 'Sadržaj datoteke';

$txt['package_upload_title'] = 'Dostavi paket';
$txt['package_upload_select'] = 'Paket za dostavljanje';
$txt['package_upload'] = 'Dostavi';
$txt['package_uploaded_success'] = 'Paket uspešno dostavljen';
$txt['package_uploaded_successfully'] = 'Paket je uspešno dostavljen';

$txt['package_modification_malformed'] = 'Malformed or invalid addon file.';
$txt['package_modification_missing'] = 'Datoteka nije pronađena.';
$txt['package_no_zlib'] = 'Vaša PHP konfiguracija nema podršku za <strong>zlib</strong>.  Bez ovoga, menadžer paketa ne može da funkcioniše. Kontaktirajte vaš hosting za više informacija.';

$txt['package_cleanperms_title'] = 'Čišćenje dozvola';
$txt['package_cleanperms_desc'] = 'Ovaj odeljak vam dozvoljava da uspostavite početne vrednosti dozvola za datoteke u vašoj instalaciji, kao i da povećate bezbednost ili da rešite bilo koje probleme sa dozvolama koji se mogu dogoditi prilikom instalacije paketa.';
$txt['package_cleanperms_type'] = 'Promeni sve dozvole datoteka foruma po šablonu';
$txt['package_cleanperms_standard'] = 'Samo standardne datoteke su otvorene za upisivanje.';
$txt['package_cleanperms_free'] = 'Sve datoteke su otvorene za upisivanje.';
$txt['package_cleanperms_restrictive'] = 'Minimum datoteka je otvoren za upisivanje.';
$txt['package_cleanperms_go'] = 'Promeni dozvole datoteka';

$txt['package_download_by_url'] = 'Preuzmi paket po url-u';
$txt['package_download_filename'] = 'Ime datoteke';
$txt['package_download_filename_info'] = 'Opcionalna vrednost.  Trebalo bi da se koristi kada se url ne završava imenom datoteke.  Na primer: index.php?mod=5';

$txt['package_db_uninstall'] = 'Remove all data associated with this addon.';
$txt['package_db_uninstall_details'] = 'Detalji';
$txt['package_db_uninstall_actions'] = 'Checking this option will result in the following actions';
$txt['package_db_remove_table'] = 'Odbaci tabelu &quot;%1$s&quot;';
$txt['package_db_remove_column'] = 'Ukloni kolonu &quot;%1$s&quot; iz &quot;%2$s&quot;';
$txt['package_db_remove_index'] = 'Ukloni indeks &quot;%1$s&quot; iz &quot;%2$s&quot;';

$txt['package_emulate_install'] = 'Install Emulating:';
$txt['package_emulate_uninstall'] = 'Uninstall Emulating:';

// Operations.
$txt['operation_find'] = 'Pronađi';
$txt['operation_replace'] = 'Zameni';
$txt['operation_after'] = 'Dodaj posle';
$txt['operation_before'] = 'Dodaj pre';
$txt['operation_title'] = 'Operacije';
$txt['operation_ignore'] = 'Zanemari greške';
$txt['operation_invalid'] = 'Operacije koje ste izabrali su pogrešne.';

$txt['package_file_perms_desc'] = 'Možete da koristite ovaj odeljak da pregledate status kritičnih datoteka i direktorijuma vašeg foruma. Ova opcija uzima u obzir samo ključne datoteke i direktorijume foruma - koristite FTP klijent za dodatne opcije.';
$txt['package_file_perms_name'] = 'File/Directory Name';
$txt['package_file_perms_status'] = 'Trenutni status';
$txt['package_file_perms_new_status'] = 'Nov status';
$txt['package_file_perms_status_read'] = 'Pročitano';
$txt['package_file_perms_status_write'] = 'Pisanje';
$txt['package_file_perms_status_execute'] = 'Izvršavanje';
$txt['package_file_perms_status_custom'] = 'Prilagođeno';
$txt['package_file_perms_status_no_change'] = 'Bez promene';
$txt['package_file_perms_writable'] = 'Otvoreno za pisanje';
$txt['package_file_perms_not_writable'] = 'Nije otvoreno za upisivanje';
$txt['package_file_perms_chmod'] = 'chmod';
$txt['package_file_perms_more_files'] = 'Još datoteka';

$txt['package_file_perms_change'] = 'Promeni dozvole datoteka';
$txt['package_file_perms_predefined'] = 'Koristi predefinisani profil dozvola';
$txt['package_file_perms_predefined_note'] = 'Note that this only applies the predefined profile to key directories and files.';
$txt['package_file_perms_apply'] = 'Primeni individualne dozvole datoteka podešene iznad.';
$txt['package_file_perms_custom'] = 'Ako je izabrano &quot;Prilagođeno&quot;, koristi vrednost chmod-a';
$txt['package_file_perms_pre_restricted'] = 'Strogo - minimum datoteka otvoreno za pisanje';
$txt['package_file_perms_pre_standard'] = 'Standardno - ključne datoteke otvorene za pisanje';
$txt['package_file_perms_pre_free'] = 'Slobodno - sve datoteke otvorene za pisanje';
$txt['package_file_perms_ftp_details'] = 'Na većini servera je moguće izvršiti promenu dozvola datoteka pomoću FTP naloga. Unesite ispod svoje detalje za povezivanje na FTP';
$txt['package_file_perms_ftp_retain'] = 'Note, the system will only retain the password information temporarily to aid operation of the package manager.';
$txt['package_file_perms_go'] = 'Napravi promene';

$txt['package_file_perms_applying'] = 'Primenjujem promene';
$txt['package_file_perms_items_done'] = 'Završeno je %1$d od %2$d stavki';
$txt['package_file_perms_skipping_ftp'] = '<strong>Upozorenje:</strong> Nisam mogao da se povežem na FTP server. Pokušaću da promeni dozvole bez toga. Ovo <em>verovatno</em> neće uspeti - proverite rezultate kada završim i pokušajte ponovo unošenjem ispravnih FTP podataka ukoliko je to potrebno.';

$txt['package_file_perms_dirs_done'] = 'Završeno je %1$d od %2$d direktorijuma';
$txt['package_file_perms_files_done'] = 'Završeno %1$d of %2$d datoteka u trenutnom direktorijumu';

$txt['chmod_value_invalid'] = 'Uneli ste pogrešnu vrednost za chmod. Chmod mora da bude između 0444 i 0777';

$txt['package_restore_permissions'] = 'Restore file permissions';
$txt['package_restore_permissions_desc'] = 'The following file permissions were changed in order to install the selected package(s). You can return these files back to their original status by clicking &quot;Restore&quot; below.';
$txt['package_restore_permissions_restore'] = 'Vrati';
$txt['package_restore_permissions_filename'] = 'Ime datoteke';
$txt['package_restore_permissions_orig_status'] = 'Originalni status';
$txt['package_restore_permissions_cur_status'] = 'Trenutni status';
$txt['package_restore_permissions_result'] = 'Rezultat';
$txt['package_restore_permissions_pre_change'] = '%1$s (%3$s)';
$txt['package_restore_permissions_post_change'] = '%2$s (%3$s - bilo %2$s)';
$txt['package_restore_permissions_action_skipped'] = '<em>Preskočeno</em>';
$txt['package_restore_permissions_action_success'] = '<span class="success">Success</span>';
$txt['package_restore_permissions_action_failure'] = '<b class="error">Nije uspelo</span>';
$txt['package_restore_permissions_action_done'] = 'An attempt to restore the selected files back to their original permissions has been completed, the results can be seen below. If a change failed, or for a more detailed view of file permissions, please see the <a href="%1$s">File Permissions</a> section.';

$txt['package_file_perms_warning'] = 'Pažnja';
$txt['package_file_perms_warning_desc'] = '
	Be careful when changing file permissions from this section - incorrect permissions can adversely affect the operation of your forum!<br />
	On some server configurations selecting the wrong permissions may stop the forum from operating.<br />
	Certain directories such as <em>attachments</em> need to be writable to use that functionality.<br />
	This functionality is mainly applicable on non-Windows based servers - it will not work as expected on Windows in regards to permission flags.<br />
	Before proceeding make sure you have an FTP client installed in case you do make an error and need to FTP into the server to remedy it.';

$txt['package_confirm_view_package_content'] = 'Da li ste sigurni da želite da pogledate sadržaj paketa sa ove adrese:<br /><br />%1$s';
$txt['package_confirm_proceed'] = 'Nastavi';
$txt['package_confirm_go_back'] = 'Vrati se nazad';

$txt['package_readme_default'] = 'Uobičajeno';
$txt['package_available_readme_language'] = 'Raspoloživi Pročitaj me Jezici:';
$txt['package_license_default'] = 'Uobičajeno';
$txt['package_available_license_language'] = 'Available License Languages:';