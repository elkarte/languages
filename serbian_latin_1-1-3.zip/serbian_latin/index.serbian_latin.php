<?php
// Version: 1.1; index

global $forum_copyright;

// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)
// For more information see:
//   - http://www.php.net/function.pspell-new
//   - http://www.php.net/function.setlocale
// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!
$txt['lang_locale'] = 'sr_YU.utf8';
$txt['lang_dictionary'] = 'sr-el';
$txt['lang_spelling'] = 'american';

// Ensure you remember to use uppercase for character set strings.
$txt['lang_character_set'] = 'UTF-8';
// Character set and right to left?
$txt['lang_rtl'] = false;
// Capitalize day and month names?
$txt['lang_capitalize_dates'] = true;
// Number format.
$txt['number_format'] = '1,234.00';

$txt['sunday'] = 'Sunday';
$txt['monday'] = 'Monday';
$txt['tuesday'] = 'Tuesday';
$txt['wednesday'] = 'Wednesday';
$txt['thursday'] = 'Thursday';
$txt['friday'] = 'Friday';
$txt['saturday'] = 'Saturday';

$txt['sunday_short'] = 'Sun';
$txt['monday_short'] = 'Mon';
$txt['tuesday_short'] = 'Tue';
$txt['wednesday_short'] = 'Wed';
$txt['thursday_short'] = 'Thu';
$txt['friday_short'] = 'Fri';
$txt['saturday_short'] = 'Sat';

$txt['january'] = 'January';
$txt['february'] = 'February';
$txt['march'] = 'March';
$txt['april'] = 'April';
$txt['may'] = 'May';
$txt['june'] = 'June';
$txt['july'] = 'July';
$txt['august'] = 'August';
$txt['september'] = 'September';
$txt['october'] = 'October';
$txt['november'] = 'November';
$txt['december'] = 'December';

$txt['january_titles'] = 'January';
$txt['february_titles'] = 'February';
$txt['march_titles'] = 'March';
$txt['april_titles'] = 'April';
$txt['may_titles'] = 'May';
$txt['june_titles'] = 'June';
$txt['july_titles'] = 'July';
$txt['august_titles'] = 'August';
$txt['september_titles'] = 'September';
$txt['october_titles'] = 'October';
$txt['november_titles'] = 'November';
$txt['december_titles'] = 'December';

$txt['january_short'] = 'Jan';
$txt['february_short'] = 'Feb';
$txt['march_short'] = 'Mar';
$txt['april_short'] = 'Apr';
$txt['may_short'] = 'May';
$txt['june_short'] = 'Jun';
$txt['july_short'] = 'Jul';
$txt['august_short'] = 'Aug';
$txt['september_short'] = 'Sep';
$txt['october_short'] = 'Oct';
$txt['november_short'] = 'Nov';
$txt['december_short'] = 'Dec';

$txt['time_am'] = 'pre podne';
$txt['time_pm'] = 'posle podne';

// Let's get all the main menu strings in one place.
$txt['home'] = 'Početna';
$txt['community'] = 'Community';
// Sub menu labels
$txt['help'] = 'Pomoć';
$txt['search'] = 'Pretraga';
$txt['calendar'] = 'Kalendar';
$txt['members'] = 'Korisnici';
$txt['recent_posts'] = 'Skorašnje poruke';

$txt['admin'] = 'Administracija';
// Sub menu labels
$txt['errlog'] = 'Dnevnik grešaka';
$txt['package'] = 'Paketi';
$txt['edit_permissions'] = 'Dozvole';
$txt['modSettings_title'] = 'Mogućnosti i opcije';

$txt['moderate'] = 'Uređivanje';
// Sub menu labels
$txt['modlog_view'] = 'Dnevnik uređivanja';
$txt['mc_emailerror'] = 'Unapproved Emails';
$txt['mc_reported_posts'] = 'Prijavljene poruke';
$txt['mc_reported_pms'] = 'Reported Personal Messages';
$txt['mc_unapproved_attachments'] = 'Neodobrene priložene datoteke';
$txt['mc_unapproved_poststopics'] = 'Neodobrene poruke i teme';

$txt['pm_short'] = 'Moje poruke';
// Sub menu labels
$txt['pm_menu_read'] = 'Pročitajte svoje poruke';
$txt['pm_menu_send'] = 'Pošaljite poruku';

$txt['account_short'] = 'My Account';
// Sub menu labels
$txt['profile'] = 'Profil';
$txt['mydrafts'] = 'My Drafts';
$txt['summary'] = 'Pregled';
$txt['theme'] = 'Podešavanja izgleda';
$txt['account'] = 'Podešavanja vezana za nalog';
$txt['forumprofile'] = 'Profil na forumu';

$txt['view_unread_category'] = 'Nove poruke';
$txt['view_replies_category'] = 'New Replies';

$txt['login'] = 'Log in';
$txt['register'] = 'Registracija';
$txt['logout'] = 'Log out';
// End main menu strings.

$txt['save'] = 'Sačuvaj';

$txt['modify'] = 'Izmeni';
$txt['forum_index'] = '%1$s - Index';
$txt['board_name'] = 'Ime foruma';
$txt['posts'] = 'poruka';

$txt['member_postcount'] = 'poruka';
$txt['no_subject'] = '(Nema teme)';
$txt['view_profile'] = 'Pogledaj profil';
$txt['guest_title'] = 'Gost';
$txt['author'] = 'Autor';
$txt['on'] = 'poslato';
$txt['remove'] = 'Ukloni';
$txt['start_new_topic'] = 'Počni novu temu';

// Use numeric entities in the below string.
$txt['username'] = 'Korisničko ime';
$txt['password'] = 'Lozinka';

$txt['username_no_exist'] = 'To korisničko ime ne postoji.';
$txt['no_user_with_email'] = 'Nema korisničkih imena povezanih sa tim imejlom.';

$txt['board_moderator'] = 'Urednik foruma';
$txt['remove_topic'] = 'Ukloni';
$txt['topics'] = 'Teme';
$txt['modify_msg'] = 'Izmeni poruku';
$txt['name'] = 'Ime';
$txt['email'] = 'Imejl';
$txt['user_email_address'] = 'Imejl adresa';
$txt['subject'] = 'Naslov';
$txt['message'] = 'Poruka';
$txt['redirects'] = 'Preusmeravanja';

$txt['choose_pass'] = 'Izaberite lozinku';
$txt['verify_pass'] = 'Potvrdite lozinku';
$txt['position'] = 'Pozicija';
$txt['notify_announcements'] = 'Sign up to receive important site news by email';

$txt['profile_of'] = 'Pogledaj profil';
$txt['total'] = 'Ukupno';
$txt['posts_made'] = 'poruka';
$txt['topics_made'] = 'Teme';
$txt['website'] = 'Vebsajt';
$txt['contact'] = 'Contact Us';
$txt['warning_status'] = 'Status upozorenja';
$txt['user_warn_watch'] = 'Korisnika nadgledaju urednici';
$txt['user_warn_moderate'] = 'Poruke korisnika moraju da se odobre pre prikazivanja';
$txt['user_warn_mute'] = 'Korisniku je zabranjeno da šalje poruke';
$txt['warn_watch'] = 'Nadgledan';
$txt['warn_moderate'] = 'Uređivan';
$txt['warn_mute'] = 'Ućutkan';
$txt['warning_issue'] = 'Warn';

$txt['message_index'] = 'Indeks poruka';
$txt['news'] = 'Novosti';
$txt['page'] = 'Page';
$txt['prev'] = 'previous';
$txt['next'] = 'next';

$txt['post'] = 'Pošalji';
$txt['error_occurred'] = 'An Error Has Occurred';
$txt['send_error_occurred'] = 'An error has occurred, <a href="{href}">please click here to try again</a>.';
$txt['require_field'] = 'This is a required field.';
$txt['started_by'] = 'Started by author';
$txt['topic_started_by'] = 'Started by %1$s';
$txt['topic_started_by_in'] = 'Started by %1$s in %2$s';
$txt['replies'] = 'Odgovora';
$txt['last_post'] = 'Poslednja poruka';
$txt['first_post'] = 'First post';
$txt['last_poster'] = 'Last post author';

// @todo - Clean this up a bit. See notes in template.
// Just moved a space, so the output looks better when things break to an extra line.
$txt['last_post_message'] = '<span class="lastpost_link">%2$s </span><span class="board_lastposter">by %1$s</span><span class="board_lasttime"><strong>Last post: </strong>%3$s</span>';
$txt['boardindex_total_posts'] = '%1$s Posts in %2$s Topics by %3$s Members';
$txt['show'] = 'Show';
$txt['hide'] = 'Hide';
$txt['sort_by'] = 'Sort By';
$txt['sort_asc'] = 'Sort ascending';
$txt['sort_desc'] = 'Sort descending';

$txt['admin_login'] = 'Administration Log in';
// Use numeric entities in the below string.
$txt['topic'] = 'Tema';
$txt['help'] = 'Pomoć';
$txt['notify'] = 'Obavesti';
$txt['unnotify'] = 'Prekini obaveštavanje';
$txt['notify_request'] = 'Da li želite da primate mejl sa obaveštenjem ako neko odgovori na ovu temu?';
// Use numeric entities in the below string.
$txt['regards_team'] = "Regards,\nThe {forum_name_html_unsafe} Team.";
$txt['notify_replies'] = 'Obavesti me pri odgovoru';
$txt['move_topic'] = 'Premesti';
$txt['move_to'] = 'Premesti u';
$txt['pages'] = 'Stranice';
$txt['users_active'] = 'Active in past %1$d minutes';
$txt['personal_messages'] = 'Privatne poruke';
$txt['reply_quote'] = 'Odgovori sa citatom';
$txt['reply'] = 'Odgovor';
$txt['reply_number'] = 'Reply #%1$s';
$txt['approve'] = 'Odobri';
$txt['unapprove'] = 'Unapprove';
$txt['approve_all'] = 'Odobri sve';
$txt['awaiting_approval'] = 'Čeka odobrenje';
$txt['attach_awaiting_approve'] = 'Priložene datoteke čekaju na odobrenje';
$txt['post_awaiting_approval'] = 'Pažnja: Ova poruka čeka odobrenje urednika.';
$txt['there_are_unapproved_topics'] = 'There are %1$s topics and %2$s posts awaiting approval in this board. <a href="%3$s">Click here to view them</a>.';
$txt['send_message'] = 'Pošalji poruku';

$txt['msg_alert_no_messages'] = 'you don\'t have any message';
$txt['msg_alert_one_message'] = 'you have <a href="%1$s">1 message</a>';
$txt['msg_alert_many_message'] = 'you have <a href="%1$s">%2$d messages</a>';
$txt['msg_alert_one_new'] = '1 is new';
$txt['msg_alert_many_new'] = '%1$d are new';
$txt['remove_message'] = 'Ukloni poruku';

$txt['topic_alert_none'] = 'Nema poruka...';
$txt['pm_alert_none'] = 'Nema poruka...';

$txt['online_users'] = 'Prisutni korisnici'; //Deprecated
$txt['online_now'] = 'Online Now';
$txt['personal_message'] = 'Privatna poruka';
$txt['jump_to'] = 'Prebaci se na';
$txt['go'] = 'Idi';
$txt['are_sure_remove_topic'] = 'Da li ste sigurni da želite da uklonite ovu temu?';
$txt['yes'] = 'Da';
$txt['no'] = 'Ne';

// @todo this string seems a good candidate for deprecation
$txt['search_on'] = 'poslato';

$txt['search'] = 'Pretraga';
$txt['all'] = 'Sve';
$txt['search_entireforum'] = 'Entire Forum';
$txt['search_thisbrd'] = 'This board';
$txt['search_thistopic'] = 'This topic';
$txt['search_members'] = 'Korisnici';

$txt['back'] = 'Nazad';
$txt['continue'] = 'Nastavi';
$txt['password_reminder'] = 'podsećanje';
$txt['topic_started'] = 'Temu započeo';
$txt['title'] = 'Naslov';
$txt['post_by'] = 'Poruka od';
$txt['welcome_newest_member'] = 'Please welcome %1$s, our newest member.';
$txt['admin_center'] = 'Administracioni centar';
$txt['admin_session_active'] = 'You have an active admin session in place. We recommend to <strong><a class="strong" href="%1$s">end this session</a></strong> once you have finished your administrative tasks.';
$txt['admin_maintenance_active'] = 'Your forum is currently in maintenance mode, only admins can log in.  Remember to <strong><a class="strong" href="%1$s">exit maintenance</a></strong> once you have finished your administrative tasks.';
$txt['query_command_denied'] = 'The following MySQL errors are occurring, please verify your setup:';
$txt['query_command_denied_guests'] = 'It seems something has gone sour on the forum with the database. This problem should only be temporary, so please come back later and try again.  If you continue to see this message, please report the following message to the administrator:';
$txt['query_command_denied_guests_msg'] = 'the command %1$s is denied on the database';
$txt['last_edit_by'] = '<span class="lastedit">Last Edit</span>: %1$s by %2$s';
$txt['notify_deactivate'] = 'Da li želite da onemogućite obaveštavanje o ovoj temi?';

$txt['date_registered'] = 'Datum registracije';
$txt['date_joined'] = 'Joined';
$txt['date_joined_format'] = '%b %d, %Y';

$txt['recent_view'] = 'View all recent posts.';
$txt['is_recent_updated'] = '%1$s is the most recently updated topic';

$txt['male'] = 'Muškarac';
$txt['female'] = 'Žena';

$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';

$txt['welcome_guest'] = 'Welcome, <strong>Guest</strong>. Please <a href="{login_url}" rel="nofollow">login</a>.';
$txt['welcome_guest_register'] = 'Welcome to <strong>{forum_name}</strong>. Please <a href="{login_url}" rel="nofollow">login</a> or <a href="{register_url}" rel="nofollow">register</a>.';
$txt['welcome_guest_activate'] = '<br />Did you miss your <a href="{activate_url}" rel="nofollow">activation email</a>?';

// @todo the following to sprintf
$txt['hello_member'] = 'Ćao,';
// Use numeric entities in the below string.
$txt['hello_guest'] = 'Dobrodošli,';
$txt['select_destination'] = 'Izaberite destinaciju';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_by'] = 'Poslao';

$txt['icon_smiley'] = 'Smeško';
$txt['icon_angry'] = 'Ljutko';
$txt['icon_cheesy'] = 'Nasmejan';
$txt['icon_laugh'] = 'Smejavko';
$txt['icon_sad'] = 'Tužan';
$txt['icon_wink'] = 'Namigivanje';
$txt['icon_grin'] = 'Zelenko';
$txt['icon_shocked'] = 'Šokiran';
$txt['icon_cool'] = 'Opušten';
$txt['icon_huh'] = 'Molim?';
$txt['icon_rolleyes'] = 'Prevrtanje očima';
$txt['icon_tongue'] = 'Jezik';
$txt['icon_embarrassed'] = 'Zaprepašćen';
$txt['icon_lips'] = 'Usne su mi zapečaćene';
$txt['icon_undecided'] = 'Neodlučan';
$txt['icon_kiss'] = 'Poljubac';
$txt['icon_cry'] = 'Plačko';
$txt['icon_angel'] = 'Innocent';

$txt['moderator'] = 'Uredničke';
$txt['moderators'] = 'Urednici';

$txt['views'] = 'Pregleda';
$txt['new'] = 'Nove';
$txt['no_redir'] = 'Redirected from %1$s';

$txt['view_all_members'] = 'Prikaži sve korisnike';
$txt['view'] = 'Prikaži';

$txt['viewing_members'] = 'Prikazano %1$s do %2$s';
$txt['of_total_members'] = 'ukupno članova: %1$s';

$txt['forgot_your_password'] = 'Zaboravili ste lozinku?';

$txt['date'] = 'Datum';
// Use numeric entities in the below string.
$txt['from'] = 'Od';
$txt['to'] = 'Za';

$txt['board_topics'] = 'Teme';
$txt['members_title'] = 'Korisnici';
$txt['members_list'] = 'Spisak članova';
$txt['new_posts'] = 'Nove poruke';
$txt['old_posts'] = 'Nema novih poruka';
$txt['redirect_board'] = 'Forum za preusmeravanje';
$txt['redirect_board_to'] = 'Redirecting to %1$s';

$txt['sendtopic_send'] = 'Pošalji';
$txt['report_sent'] = 'Vaša prijava je uspešno poslata.';
$txt['topic_sent'] = 'Your email has been sent successfully.';

$txt['time_offset'] = 'Odstupanje vremena';
$txt['or'] = 'ili';

$txt['mention'] = 'Obaveštenja';
$txt['notifications'] = 'Obaveštenja';
$txt['unread_notifications'] = 'You have %1$s unread notifications since your last visit.';
$txt['new_from_last_notifications'] = 'You have %1$s new notifications.';
$txt['forum_notification'] = 'Notifications from %1$s.';

$txt['your_ban'] = 'Izvinjavamo se %1$s, zabranjeno vam je da koristite ovaj forum!';
$txt['your_ban_expires'] = 'Vaša zabrana ističe %1$s.';
$txt['your_ban_expires_never'] = 'Vaša zabrana neće isteći.';
$txt['ban_continue_browse'] = 'Možete da nastavite čitanje foruma kao gost.';

$txt['mark_as_read'] = 'Označi SVE poruke kao pročitane';
$txt['mark_as_read_confirm'] = 'Are you sure you want to mark ALL messages as read?';
$txt['mark_these_as_read'] = 'Mark THESE messages as read';
$txt['mark_these_as_read_confirm'] = 'Are you sure you want to mark THESE messages as read?';

$txt['locked_topic'] = 'Zaključana tema';
$txt['normal_topic'] = 'Normalna tema';
$txt['participation_caption'] = 'Tema u kojoj ste odgovarali';

$txt['print'] = 'Štampaj';
$txt['topic_summary'] = 'Pregled teme';
$txt['not_applicable'] = 'Nije dostupno';
$txt['name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['total_members'] = 'Ukupno članova';
$txt['total_posts'] = 'Ukupno poruka';
$txt['total_topics'] = 'Ukupno tema';

$txt['mins_logged_in'] = 'Prijavi me za sledećih<br/>minuta';

$txt['preview'] = 'Pregledaj';
$txt['always_logged_in'] = 'Prijavi me za stalno';

$txt['logged'] = 'Sačuvana';
// Use numeric entities in the below string.
$txt['ip'] = 'IP';

$txt['www'] = 'WWW';
$txt['link'] = 'Link';

$txt['by'] = 'od strane'; //Deprecated

$txt['hours'] = 'sati';
$txt['minutes'] = 'minuta';
$txt['seconds'] = 'sekundi';

// Used upper case in Paid subscriptions management
$txt['hour'] = 'Sat';
$txt['days_word'] = 'dana';

$txt['newest_member'] = ', našeg najnovijeg člana.'; //Deprecated

$txt['search_for'] = 'Pretraži za';
$txt['search_match'] = 'Match';

$txt['maintain_mode_on'] = 'Zapamtite, ovaj forum je u modu održavanja.';

$txt['read'] = 'Pročitano'; //Deprecated
$txt['times'] = 'puta'; //Deprecated
$txt['read_one_time'] = 'Read 1 time';
$txt['read_many_times'] = 'Read %1$d times';

$txt['forum_stats'] = 'Statistike foruma';
$txt['latest_member'] = 'Poslednji član';
$txt['total_cats'] = 'Ukupno kategorija';
$txt['latest_post'] = 'Poslednja poruka';

$txt['here'] = 'ovde';
$txt['you_have_no_msg'] = 'You don\'t have any message...';
$txt['you_have_one_msg'] = 'You\'ve 1 message...<a href="%1$s">Click here to view it</a>';
$txt['you_have_many_msgs'] = 'You\'ve %2$d messages...<a href="%1$s">Click here to view them</a>';

$txt['total_boards'] = 'Ukupno foruma';

$txt['print_page'] = 'Odštampaj stranicu';
$txt['print_page_text'] = 'Text only';
$txt['print_page_images'] = 'Text with Images';

$txt['valid_email'] = 'Morate da unesete ispravnu imejl adresu.';

$txt['info_center_title'] = '%1$s - info centar';

$txt['send_topic'] = 'Share';
$txt['unwatch'] = 'Unwatch';
$txt['watch'] = 'Watch';

$txt['sendtopic_title'] = 'Pošaljite temu &quot;%1$s&quot; prijatelju.';
$txt['sendtopic_sender_name'] = 'Vaše ime';
$txt['sendtopic_sender_email'] = 'Vaša imejl adresa';
$txt['sendtopic_receiver_name'] = 'Primaočevo ime';
$txt['sendtopic_receiver_email'] = 'Primaočeva imejl adresa';
$txt['sendtopic_comment'] = 'Dodaj komentar';

$txt['allow_user_email'] = 'Dozvoli korisnicima da mi šalju mejlove';

$txt['check_all'] = 'Označi sve';

// Use numeric entities in the below string.
$txt['database_error'] = 'Greška u bazi podataka';
$txt['try_again'] = 'Molim vas pokušajte ponovo. Ako ponovo vidite ovu grešku, prijavite grešku administratoru.';
$txt['file'] = 'Datoteka';
$txt['line'] = 'Linija';

// Use numeric entities in the below string.
$txt['tried_to_repair'] = 'ElkArte has detected and automatically tried to repair an error in your database.  If you continue to have problems, or continue to receive these emails, please contact your host.';
$txt['database_error_versions'] = '<strong>Note:</strong> Your database version is %1$s.';
$txt['template_parse_error'] = 'Greška u parsiranju predloška!';
$txt['template_parse_error_message'] = 'Izgleda da je nešto pošlo naopako sa sistemom predložaka na forumu. Ovaj problem bi trebao da bude privremen tako da vas molimo da dođete malo kasnije i pokušate ponovo. Ako nastavite da primate ovu poruku, kontaktirajte administratora.<br /><br />Možete da probate i da <a href="javascript:location.reload();">osvežite ovu stranicu</a>.';
$txt['template_parse_error_details'] = 'There was a problem loading the <span class="tt"><strong>%1$s</strong></span> template or language file.  Please check the syntax and try again - remember, single quotes (<span class="tt">\'</span>) often have to be escaped with a backslash (<span class="tt">\\</span>).  To see more specific error information from PHP, try <a href="%2$s%1$s">accessing the file directly</a>.<br /><br />You may want to try to <a href="javascript:location.reload();">refresh this page</a> or <a href="%3$s">use the default theme</a>.';
$txt['template_parse_undefined'] = 'An undefined error occurred during the parsing of this template';

$txt['today'] = 'Today at %1$s';
$txt['yesterday'] = 'Yesterday at %1$s';

// Relative times
$txt['rt_now'] = 'just now';
$txt['rt_minute'] = 'A minute ago';
$txt['rt_minutes'] = '%s minutes ago';
$txt['rt_hour'] = 'An hour ago';
$txt['rt_hours'] = '%s hours ago';
$txt['rt_day'] = 'A day ago';
$txt['rt_days'] = '%s days ago';
$txt['rt_week'] = 'A week ago';
$txt['rt_weeks'] = '%s weeks ago';
$txt['rt_month'] = 'A month ago';
$txt['rt_months'] = '%s months ago';
$txt['rt_year'] = 'A year ago';
$txt['rt_years'] = '%s years ago';

$txt['new_poll'] = 'Nova anketa';
$txt['poll_question'] = 'Pitanje';
$txt['poll_question_options'] = 'Question and Options';
$txt['poll_vote'] = 'Glasaj';
$txt['poll_total_voters'] = 'Ukupno glasova';
$txt['draft_saved_on'] = 'Draft last saved';
$txt['poll_results'] = 'Pogledajte rezultate';
$txt['poll_lock'] = 'Zaključaj anketu';
$txt['poll_unlock'] = 'Otključaj anketu';
$txt['poll_edit'] = 'Izmeni anketu';
$txt['poll'] = 'Anketa';
$txt['one_day'] = '1 dan';
$txt['one_week'] = '1 nedelja';
$txt['two_weeks'] = '2 Weeks';
$txt['one_month'] = '1 mesec';
$txt['two_months'] = '2 Months';
$txt['forever'] = 'Zauvek';
$txt['quick_login_dec'] = 'Prijavite se korisničkim imenom, lozinkom i dužinom sesije';
$txt['one_hour'] = '1 čas';
$txt['moved'] = 'PREMEŠTENA';
$txt['moved_why'] = 'Unesite kratak opis kao razlog<br />zbog čega je tema premeštena.';
$txt['board'] = 'Forum';
$txt['in'] = 'u';
$txt['sticky_topic'] = 'Pinned Topic';
$txt['split'] = 'SPLIT';

$txt['delete'] = 'Obriši';

$txt['byte'] = 'B';
$txt['kilobyte'] = 'KB';
$txt['megabyte'] = 'MB';
$txt['gigabyte'] = 'MB';

$txt['more_stats'] = '[više statistike]';

// Use numeric entities in the below three strings.
$txt['code'] = 'Kod';
$txt['code_select'] = '[Izaberi]';
$txt['quote_from'] = 'Citat';
$txt['quote'] = 'Citat';
$txt['quote_new'] = 'New topic';
$txt['follow_ups'] = 'Follow-ups';
$txt['topic_derived_from'] = 'Topic derived from %1$s';
$txt['edit'] = 'Izmeni';
$txt['quick_edit'] = 'Quick Edit';
$txt['post_options'] = 'More...';

$txt['set_sticky'] = 'Pin';
$txt['set_nonsticky'] = 'Unpin';
$txt['set_lock'] = 'Zaključaj';
$txt['set_unlock'] = 'Otključaj';

$txt['search_advanced'] = 'Show advanced options';
$txt['search_simple'] = 'Hide advanced options';

$txt['security_risk'] = 'VELIKI BEZBEDNOSNI RIZIK:';
$txt['not_removed'] = 'You have not removed %1$s';
$txt['not_removed_extra'] = '%1$s is a backup of %2$s that was not generated by ElkArte. It can be accessed directly and used to gain unauthorised access to your forum. You should delete it immediately.';
$txt['generic_warning'] = 'Warning';
$txt['agreement_missing'] = 'You are requiring new users to accept a registration agreement, however the file (agreement.txt) doesn\'t exist.';
$txt['agreement_accepted'] = 'You have just accepted the agreement.';
$txt['privacypolicy_accepted'] = 'You have just accepted the forum privacy policy.';

$txt['new_version_updates'] = 'You have just updated!';
$txt['new_version_updates_text'] = '<a href="{admin_url};area=credits#latest_updates">Click here to see what\'s new in this version of ElkArte!</a>!';

$txt['cache_writable'] = 'Direktorijum za keširanje nije otvoren za pisanje - ovo u dobroj meri može da utiče na performanse vašeg foruma.';

$txt['page_created_full'] = 'Page created in %1$.3f seconds with %2$d queries.';

$txt['report_to_mod_func'] = 'Koristite ovu funkciju da biste obavestili urednike i administratore o uvredljivoj ili pogrešno poslatoj poruci.<br /><em>Vaša imejl adresa biće otkrivena urednicima ako upotrebite ovu funkciju.</em>';

$txt['online'] = 'Na mreži';
$txt['member_is_online'] = '%1$s is online';
$txt['offline'] = 'Van mreže';
$txt['member_is_offline'] = '%1$s is offline';
$txt['pm_online'] = 'Privatna poruka (Na mreži)';
$txt['pm_offline'] = 'Privatna poruka (Van mreže)';
$txt['status'] = 'Status';

$txt['skip_nav'] = 'Skip to main content';
$txt['go_up'] = 'Idi gore';
$txt['go_down'] = 'Idi dole';

$forum_copyright = '<a href="https://www.elkarte.net" title="ElkArte Forum" target="_blank" class="new_win">Powered by %1$s</a> | <a href="{credits_url}" title="Credits" target="_blank" class="new_win" rel="nofollow">Credits</a>';

$txt['birthdays'] = 'Rođendani:';
$txt['events'] = 'Događaji:';
$txt['birthdays_upcoming'] = 'Predstojeći rođendani:';
$txt['events_upcoming'] = 'Predstojeći događaji:';
// Prompt for holidays in the calendar, leave blank to just display the holiday's name.
$txt['calendar_prompt'] = 'Holidays:';
$txt['calendar_month'] = 'Mesec:';
$txt['calendar_year'] = 'Godina:';
$txt['calendar_day'] = 'Dan:';
$txt['calendar_event_title'] = 'Naslov događaja:';
$txt['calendar_event_options'] = 'Event Options';
$txt['calendar_post_in'] = 'Pošalji u:';
$txt['calendar_edit'] = 'Izmeni događaje';
$txt['event_delete_confirm'] = 'Da obrišem ovaj događaj?';
$txt['event_delete'] = 'Obriši događaj';
$txt['calendar_post_event'] = 'Dodaj događaj';
$txt['calendar'] = 'Kalendar';
$txt['calendar_link'] = 'Dodaj vezu ka kalendaru';
$txt['calendar_upcoming'] = 'Predstojeći kalendar';
$txt['calendar_today'] = 'Današnji kalendar';
$txt['calendar_week'] = 'Nedelja';
$txt['calendar_week_title'] = 'Nedelja %1$d od %2$d';
$txt['calendar_numb_days'] = 'Broj dana:';
$txt['calendar_how_edit'] = 'kako da izmenim ove događaje?';
$txt['calendar_link_event'] = 'Dodaj vezu ka dešavanju';
$txt['calendar_confirm_delete'] = 'Da li ste sigurni da želite da obrišete ovaj događaj?';
$txt['calendar_linked_events'] = 'Povezani događaji';
$txt['calendar_click_all'] = 'kliknite da biste videli sve %1$s';

$txt['moveTopic1'] = 'Pošalji preusmeravajuću temu';
$txt['moveTopic2'] = 'Promeni naslov teme';
$txt['moveTopic3'] = 'Nov naslov teme';
$txt['moveTopic4'] = 'Promeni naslov svake poruke';
$txt['move_topic_unapproved_js'] = 'Upozorenje! Ova tema još uvek nije odobrena.\\n\\nNije preporučljivo da napravite preusmeravajuću temu ukoliko ne nameravate da odobrite ovu temu odmah nakon premeštanja.';
$txt['movetopic_auto_board'] = '[FORUM]';
$txt['movetopic_auto_topic'] = '[LINK TEME]';
$txt['movetopic_default'] = 'This topic has been moved to [BOARD] - [TOPIC LINK]';
$txt['movetopic_redirect'] = 'Redirect to the moved topic';
$txt['movetopic_expires'] = 'Automatically remove the redirection topic';

$txt['merge_to_topic_id'] = 'ID ciljne poruke';
$txt['split_topic'] = 'Split';
$txt['merge'] = 'Merge';
$txt['subject_new_topic'] = 'Naslov za novu temu';
$txt['split_this_post'] = 'Izdvoj samo ovu poruku.';
$txt['split_after_and_this_post'] = 'Izdvoj ovu poruku i sve posle nje.';
$txt['select_split_posts'] = 'Izdvoj izabrane poruke.';

$txt['splittopic_notification'] = 'Post a message when the topic is split';
$txt['splittopic_default'] = 'One or more of the messages of this topic have been moved to [BOARD] - [TOPIC LINK]';
$txt['splittopic_move'] = 'Move the new topic to another board';

$txt['new_topic'] = 'Nova tema';
$txt['split_successful'] = 'Tema je uspešno podeljena na dve teme.';
$txt['origin_topic'] = 'Početna tema';
$txt['please_select_split'] = 'Molim vas izaberite koje poruke želite da podelite.';
$txt['merge_successful'] = 'Teme su uspešno spojene.';
$txt['new_merged_topic'] = 'Novospojena tema';
$txt['topic_to_merge'] = 'Tema za spajanje';
$txt['target_board'] = 'Ciljni forum';
$txt['target_topic'] = 'Ciljna tema';
$txt['merge_confirm'] = 'Da li ste sigurni da želite da spojite';
$txt['with'] = 'sa';
$txt['merge_desc'] = 'Ova funkcija će spojiti poruke iz dve teme u jednu. Poruke će biti poređane po vremenu slanja. Stoga, najranije poslata poruka biće prikazana kao prva u spojenoj temi.';

$txt['theme_template_error'] = 'Ne mogu da učitam šablon \'%1$s\'.';
$txt['theme_language_error'] = 'Ne mogu da učitam jezičku datoteku \'%1$s\'.';

$txt['parent_boards'] = 'Sub-boards';

$txt['smtp_no_connect'] = 'Ne mogu da se povežem sa SMTP serverom';
$txt['smtp_port_ssl'] = 'Podešavanja SMTP porta su pogrešna; port za SSL servere bi trebalo da bude 465.';
$txt['smtp_bad_response'] = 'Ne dobija kodove odgovora mejl servera  ';
$txt['smtp_error'] = 'Zapao sam u probleme prilikom slanja mejla. Greška: ';
$txt['mail_send_unable'] = 'Ne mogu da pošaljem mejl na imejl adresu \'%1$s\'';

$txt['mlist_search'] = 'Traži korisnike';
$txt['mlist_search_again'] = 'Traži ponovo'; // @deprecated since 1.0.4
$txt['mlist_search_email'] = 'Pretražuj po imejl adresi';
$txt['mlist_search_group'] = 'Pretražuj po poziciji';
$txt['mlist_search_name'] = 'Pretražuj po imenu';
$txt['mlist_search_website'] = 'Pretražuj po vebsajtu';
$txt['mlist_search_results'] = 'Rezultati pretrage za';
$txt['mlist_search_by'] = 'Pretraži po %1$s';

$txt['attach_downloaded'] = 'downloaded %1$d times';
$txt['attach_viewed'] = 'viewed %1$d times';

$txt['settings'] = 'Podešavanja';
$txt['never'] = 'Nikad';
$txt['more'] = 'još';

$txt['hostname'] = 'Ime domaćina';
$txt['you_are_post_banned'] = 'Izvinite %1$s, zabranjeno vam je da šaljete poruke ili privatne poruke na ovom forumu.';
$txt['ban_reason'] = 'Razlog';

$txt['add_poll'] = 'Dodaj anketu';
$txt['poll_options6'] = 'Možete da izaberete najviše %1$s opcija.';
$txt['poll_remove'] = 'Ukloni anketu';
$txt['poll_remove_warn'] = 'Da li ste sigurni da želite da uklonite anketu iz ove teme?';
$txt['poll_results_expire'] = 'Rezultati će biti prikazani kada se anketa završi';
$txt['poll_expires_on'] = 'Anketa se završava';
$txt['poll_expired_on'] = 'Anketa završena';
$txt['poll_change_vote'] = 'Ukloni glas';
$txt['poll_return_vote'] = 'Opcije glasanja';
$txt['poll_cannot_see'] = 'Trenutno ne možete da vidite rezultate ove ankete.';

$txt['quick_mod_approve'] = 'Odobri izabrano';
$txt['quick_mod_remove'] = 'Ukloni izabrano';
$txt['quick_mod_lock'] = 'Zaključaj/Otključaj izabrano';
$txt['quick_mod_sticky'] = 'Pin/Unpin selected';
$txt['quick_mod_move'] = 'Premesti izabrano u';
$txt['quick_mod_merge'] = 'Spoji izabrano';
$txt['quick_mod_markread'] = 'Označi izabrano kao pročitano';
$txt['quick_mod_go'] = 'Idi';
$txt['quickmod_confirm'] = 'Da li ste sigurni da želite da uradite ovo?';

$txt['spell_check'] = 'Provera pravopisa';

$txt['quick_reply'] = 'Brz odgovor';
$txt['quick_reply_warning'] = 'Warning! This topic is currently locked, only admins and moderators can reply.';
$txt['quick_reply_verification'] = 'Nakon slanja poruke, bićete preusmereni na stranu za obično slanje poruka da biste potvrdili svoju poruku %1$s.';
$txt['quick_reply_verification_guests'] = '(obavezno za sve goste)';
$txt['quick_reply_verification_posts'] = '(obavezno sa sve korisnike sa manje od %1$d poruka)';
$txt['wait_for_approval'] = 'Pažnja: ova poruka se neće prikazati dok je ne odobre urednici.';

$txt['notification_enable_board'] = 'Da li ste sigurni da želite da omogućite obaveštavanje o novim temama u ovom forumu?';
$txt['notification_disable_board'] = 'Da li ste sigurni da želite da onemogućite obaveštavanje o novim temama u ovom forumu?';
$txt['notification_enable_topic'] = 'Da li ste sigurni da želite da omogućite obaveštavanje o novim odgovorima u ovom forumu?';
$txt['notification_disable_topic'] = 'Da li ste sigurni da želite da onemogućite obaveštavanje o novim odgovorima u ovom forumu?';

$txt['report_to_mod'] = 'Report Post';
$txt['issue_warning_post'] = 'Izdaj upozorenje zbog ove poruke';

$txt['like_post'] = 'Like';
$txt['unlike_post'] = 'Unlike';
$txt['likes'] = 'Likes';
$txt['liked_by'] = 'Liked by:';
$txt['liked_you'] = 'You';
$txt['liked_more'] = 'još';
$txt['likemsg_are_you_sure'] = 'You already liked this message, are you sure you want to remove your like?';

$txt['unread_topics_visit'] = 'Skorašnje nepročitane teme';
$txt['unread_topics_visit_none'] = 'No unread topics found since your last visit. <a href="{unread_all_url}" class="linkbutton">Click here to try all unread topics</a>';
$txt['unread_topics_all'] = 'Sve nepročitane teme';
$txt['unread_replies'] = 'Ažurirane teme';

$txt['who_title'] = 'Ko je prisutan';
$txt['who_and'] = ' i ';
$txt['who_viewing_topic'] = ' pregledaju ovu temu.';
$txt['who_viewing_board'] = ' pregledaju ovaj forum.';
$txt['who_member'] = 'Član';

// Current footer strings
$txt['valid_html'] = 'Valid HTML 5';
$txt['rss'] = 'RSS';
$txt['atom'] = 'Atom';
$txt['html'] = 'HTML';

$txt['guest'] = 'Gost';
$txt['guests'] = 'Gosti';
$txt['user'] = 'Korisnik';
$txt['users'] = 'korisnika';
$txt['hidden'] = 'sakrivenih';
// Plural form of hidden for languages other than English
$txt['hidden_s'] = 'sakrivenih';
$txt['buddy'] = 'Prijatelj';
$txt['buddies'] = 'Prijatelji';
$txt['most_online_ever'] = 'Najviše prisutnih korisnika';
$txt['most_online_today'] = 'Najviše prisutnih korisnika danas';

$txt['merge_select_target_board'] = 'Izaberite odredišni forum za spojene teme';
$txt['merge_select_poll'] = 'Izaberite koju anketu bi spojene teme trebalo da imaju';
$txt['merge_topic_list'] = 'Izaberite teme za spajanje';
$txt['merge_select_subject'] = 'Izaberite naslov spojenih tema';
$txt['merge_custom_subject'] = 'Korisnički naslov';
$txt['merge_enforce_subject'] = 'Promeni naslov svih poruka';
$txt['merge_include_notifications'] = 'Da uključim obaveštenja?';
$txt['merge_check'] = 'Spojiti?';
$txt['merge_no_poll'] = 'Bez ankete';

$txt['response_prefix'] = 'Odg: ';
$txt['current_icon'] = 'Current icon';
$txt['message_icon'] = 'Ikona poruke';

$txt['smileys_current'] = 'Trenutna postavka smajlija';
$txt['smileys_none'] = 'Bez smajlija';
$txt['smileys_forum_board_default'] = 'Podrazumevana na forumu';

$txt['search_results'] = 'Rezultati pretrage';
$txt['search_no_results'] = 'Izvinite ali nema traženih rezultata';

$txt['totalTimeLogged2'] = ' dana, ';
$txt['totalTimeLogged3'] = ' sati i ';
$txt['totalTimeLogged4'] = ' minuta.';
$txt['totalTimeLogged5'] = 'd ';
$txt['totalTimeLogged6'] = 'č ';
$txt['totalTimeLogged7'] = 'm';

$txt['approve_thereis'] = 'Ima'; //Deprecated
$txt['approve_thereare'] = 'Ima'; //Deprecated
$txt['approve_member'] = 'jedan član'; //Deprecated
$txt['approve_members'] = 'člana'; //Deprecated
$txt['approve_members_waiting'] = 'koji čekaju na odobrenje.'; //Deprecated
$txt['approve_one_member_waiting'] = 'There is <a href="%1$s">one member</a> awaiting approval.';
$txt['approve_many_members_waiting'] = 'There are <a href="%1$s">%2$d members</a> awaiting approval.';

$txt['notifyboard_turnon'] = 'Da li želite da primate mejlove sa obaveštenjem kada neko postavi novu temu u ovom forumu?';
$txt['notifyboard_turnoff'] = 'Da li ste sigurni da ne želite da primate obaveštenje o novim temama u ovom forumu?';

$txt['notify_board_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications from the "%1$s" board.';
$txt['notify_topic_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent notifications on the "%1$s" topic.';
$txt['notify_mention_unsubscribed'] = 'The email, %2$s, has been successfully unsubscribed and will no longer be sent "%1$s" notifications.';
$txt['notify_default_unsubscribed'] = 'Your request has been successfully processed.';

$txt['find_members'] = 'Pronađi članove';
$txt['find_username'] = 'Ime, korisničko ime ili imejl adresa';
$txt['find_buddies'] = 'Prikazati samo prijatelje?';
$txt['find_wildcards'] = 'Dozvoljeni džokeri: *, ?';
$txt['find_no_results'] = 'Nema pronađenih rezultata';
$txt['find_results'] = 'Rezultati';
$txt['find_close'] = 'Zatvori';

$txt['quickmod_delete_selected'] = 'Izbriši izabrano';
$txt['quickmod_split_selected'] = 'Split Selected';

$txt['show_personal_messages_heading'] = 'New messages';
$txt['show_personal_messages'] = 'You have <strong>%1$s</strong> unread personal messages in your inbox.<br /><br /><a href="%2$s">Go to your inbox</a>';

$txt['help_popup'] = 'A little lost? Let me explain:';

$txt['previous_next_back'] = 'previous topic';
$txt['previous_next_forward'] = 'next topic';

$txt['upshrink_description'] = 'Skupi ili raširi zaglavlje.';

$txt['mark_unread'] = 'Označi kao nepročitano';

$txt['ssi_not_direct'] = 'Molim vas ne pristupajte SSI.php direktno preko URL-a; verovatno želite da koristite putanju (%1$s) ili dodate ?ssi_function=nesto.';
$txt['ssi_session_broken'] = 'SSI.php nije mogao da učita sesiju! Ovo može prouzrokovati probleme prilikom odjavljivanja ili korišćenja drugih funkcija - osigurajte da SSI.php bude uvršćen pre *bilo čega* u vašoj skripti!';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['preview_title'] = 'Pregledaj poruku';
$txt['preview_fetch'] = 'Dobavljam pregled...';
$txt['pm_error_while_submitting'] = 'The following error or errors occurred while sending this personal message:';
$txt['warning_while_submitting'] = 'Something happened, review it here:';
$txt['error_while_submitting'] = 'The message has the following error or errors that must be corrected before continuing:';
$txt['error_old_topic'] = 'Upozorenje: u ovoj temi nije pisano već više od %1$d dana.<br />Ukoliko niste sigurni da želite da odgovorite, razmislite o pokretanju nove teme.';

$txt['split_selected_posts'] = 'Izabrane poruke';
$txt['split_selected_posts_desc'] = 'Poruke naznačene ispod će obrazovati novu temu nakon deobe.';
$txt['split_reset_selection'] = 'resetuj odabir';

$txt['modify_cancel'] = 'Otkaži';
$txt['mark_read_short'] = 'Označi kao pročitano';

$txt['hello_member_ndt'] = 'Zdravo';

$txt['unapproved_posts'] = 'Neodobrene poruke (tema: %1$d, poruka: %2$d)';

$txt['ajax_in_progress'] = 'Učitavam...';
$txt['ajax_bad_response'] = 'Invalid response.';

$txt['mod_reports_waiting'] = 'Trenutno ima %1$d nerešenih prijava urednicima.';
$txt['pm_reports_waiting'] = 'There are currently %1$d personal message reports open.';

$txt['new_posts_in_category'] = 'Click to see the new posts in %1$s';
$txt['verification'] = 'Potvrda';
$txt['visual_verification_hidden'] = 'Please leave this box empty';
$txt['visual_verification_description'] = 'Ukucajte slova prikazana na slici';
$txt['visual_verification_sound'] = 'Slušajte slova';
$txt['visual_verification_request_new'] = 'Zatraži drugu sliku';

// @todo Send email strings - should move?
$txt['send_email'] = 'Send email';
$txt['send_email_disclosed'] = 'Pažnja: ovo će biti vidljivo primaocu.';
$txt['send_email_subject'] = 'Naslov mejla';

$txt['ignoring_user'] = 'Ignorišete ovog korisnika.';
$txt['show_ignore_user_post'] = '<em>[Show me the post.]</em>';

$txt['spider'] = 'pauk';
$txt['spiders'] = 'Pauci';
$txt['openid'] = 'OtvoreniID';

$txt['downloads'] = 'Preuzimanja';
$txt['filesize'] = 'File size';
$txt['subscribe_webslice'] = 'Pretplati se na Webslice'; // @deprecated since 1.1

// Restore topic
$txt['restore_topic'] = 'Vrati temu';
$txt['restore_message'] = 'Vrati';
$txt['quick_mod_restore'] = 'Vrati izabrano';

// Editor prompt.
$txt['prompt_text_email'] = 'Unesite imejl adresu.';
$txt['prompt_text_ftp'] = 'Please enter the FTP address.';
$txt['prompt_text_url'] = 'Unesite URL na koji želite da linkujete.';
$txt['prompt_text_img'] = 'Unesite lokaciju slike';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['autosuggest_delete_item'] = 'Obriši stavku';

// Bad Behavior
$txt['badbehavior_blocked'] = '<a href="http://www.bad-behavior.ioerror.us/">Bad Behavior</a> has blocked %1$s access attempts in the last 7 days.';

// Debug related - when $db_show_debug is true.
$txt['debug_templates'] = 'Šabloni:';
$txt['debug_subtemplates'] = 'Delovi šablona:'; // @deprecated since 1.1
$txt['debug_sub_templates'] = 'Delovi šablona:';
$txt['debug_language_files'] = 'Jezičke datoteke:';
$txt['debug_sheets'] = 'Datoteke stilova (CSS):';
$txt['debug_javascript'] = 'Scripts: ';
$txt['debug_files_included'] = 'Uvršćene datoteke:';
$txt['debug_kb'] = 'KB.';
$txt['debug_show'] = 'prikaži';
$txt['debug_cache_hits'] = 'Korišćenje keša:';
$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s bajtova';
$txt['debug_cache_seconds_bytes_total'] = '%1$ss za %2$s bajtova';
$txt['debug_queries_used'] = 'Upotrebljenih upita: %1$d.';
$txt['debug_queries_used_and_warnings'] = 'Upotrebljenih upita: %1$d, %2$d upozorenja.';
$txt['debug_query_in_line'] = 'u datoteci <em>%1$s</em> linija <em>%2$s</em>,';
$txt['debug_query_which_took'] = 'što je trajalo %1$s sekundi.';
$txt['debug_query_which_took_at'] = 'što je trajalo %1$s sekundi uz %2$s zahteva.';
$txt['debug_show_queries'] = '[Prikaži upite]';
$txt['debug_hide_queries'] = '[Sakrij upite]';
$txt['debug_tokens'] = 'Tokens: ';
$txt['debug_browser'] = 'Browser ID: ';
$txt['debug_hooks'] = 'Hooks called: ';
$txt['debug_system_type'] = 'System: ';
$txt['debug_server_load'] = 'Server Load: ';
$txt['debug_script_mem_load'] = 'Script Memory Usage: ';
$txt['debug_script_cpu_load'] = 'Script CPU Time (user/system): ';

// Video embedding
$txt['preview_image'] = 'Video Preview Image';
$txt['ctp_video'] = 'Click to play video, double click to load video';
$txt['hide_video'] = 'Show/Hide video';
$txt['youtube'] = 'YouTube video:';
$txt['vimeo'] = 'Vimeo video:';
$txt['dailymotion'] = 'Dailymotion video:';

// Spoiler BBC
$txt['spoiler'] = 'Spoiler (click to show/hide)';

$txt['ok_uppercase'] = 'u redu';

// Title of box for warnings that admins should see
$txt['admin_warning_title'] = 'Warning';

$txt['via'] = 'via';

$txt['like_post_stats'] = 'Like stats';

$txt['otp_token'] = 'Time-based One-time Password';
$txt['otp_enabled'] = 'Enable two factor authentication';
$txt['invalid_otptoken'] = 'Time-based One-time Password is invalid';
$txt['otp_used'] = 'Time-based One-time Password already used.<br /> Please wait a moment and use the next code.';
$txt['otp_generate'] = 'Generate';
$txt['otp_show_qr'] = 'Show QR-Code';
