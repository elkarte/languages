<?php
// Version: 1.1; Profile

$txt['no_profile_edit'] = 'Nemate dozvolu da izmenite profil ove osobe';
$txt['website_title'] = 'Naziv vebsajta';
$txt['website_url'] = 'URL vebsajta';
$txt['signature'] = 'Potpis';
$txt['profile_posts'] = 'poruka';

$txt['profile_info'] = 'Extra Details';
$txt['profile_contact'] = 'Contact Information';
$txt['profile_moderation'] = 'Moderation Information';
$txt['profile_more'] = 'Potpis';
$txt['profile_attachments'] = 'Recent Attachments';
$txt['profile_attachments_no'] = 'There are no Attachments from this member';
$txt['profile_recent_posts'] = 'Skorašnje poruke';
$txt['profile_posts_no'] = 'There are no posts from this member';
$txt['profile_topics'] = 'Recent Topics';
$txt['profile_topics_no'] = 'There are no topics from this member';
$txt['profile_buddies_no'] = 'You have not set any buddies';
$txt['profile_user_info'] = 'User Info';
$txt['profile_contact_no'] = 'There is no contact information for this member';
$txt['profile_signature_no'] = 'There is no signature for this member';
$txt['profile_additonal_no'] = 'There is no additional information for this member';
$txt['profile_user_summary'] = 'Profil';
$txt['profile_action'] = 'Currently';
$txt['profile_recent_activity'] = 'Recent Activity';
$txt['profile_activity'] = 'Aktivnost';
$txt['profile_loadavg'] = 'Please try again later.  This information is not currently available due to high demand on the site.';

$txt['change_profile'] = 'Izmeni profil';
$txt['preview_signature'] = 'Preview signature';
$txt['current_signature'] = 'Current signature';
$txt['signature_preview'] = 'Signature preview';
$txt['personal_picture'] = 'Lična slika';
$txt['no_avatar'] = 'Nema avatara';
$txt['choose_avatar_gallery'] = 'Izaberi avatar iz galerije';
$txt['preferred_language'] = 'Preferirani jezik';
$txt['age'] = 'Starost';
$txt['no_pic'] = '(nema slike)';
$txt['avatar_by_url'] = 'Specify your own avatar by URL. (e.g.: <em>http://www.mypage.com/mypic.png</em>)';
$txt['my_own_pic'] = 'Precizirajte svoj avatar unoseći URL';
$txt['gravatar'] = 'Gravatar';
$txt['date_format'] = 'Ovaj format će se koristiti za prikazivanje datuma na forumu.';
$txt['time_format'] = 'Format vremena';
$txt['display_name_desc'] = 'Ovo je ime koje će ostali korisnici videti.';
$txt['personal_time_offset'] = 'Broj sati +/- koje će učiniti da prikazano vreme bude identično lokalnom vremenu.';
$txt['dob'] = 'Datum rođenja';
$txt['dob_month'] = 'Mesec (MM)';
$txt['dob_day'] = 'Dan (DD)';
$txt['dob_year'] = 'Godina (GGGG)';
$txt['password_strength'] = 'Za najbolju bezbednost, trebalo bi da koristite šest ili više znakova: kombinaciju slova, brojeva i simbola.';
$txt['include_website_url'] = 'Ovo mora da bude naznačeno ako precizirate URL sajta.';
$txt['complete_url'] = 'Ovo mora da bude kompletan URL.';
$txt['sig_info'] = 'Potpisi su prikazani pri dnu svake poruke. BBKod i smajliji mogu da budu korišćeni.';
$txt['max_sig_characters'] = 'Maksimum znakova %1$d; preostalih znakova: ';
$txt['send_member_pm'] = 'Pošaljite privatnu poruku ovom članu';
$txt['hidden'] = 'sakriven';
$txt['current_time'] = 'Trenutno vreme na forumu';

$txt['language'] = 'Jezik';
$txt['avatar_too_big'] = 'Slika za avatar je prevelika. Promenite joj veličinu i pokušajte ponovo (maks.';
$txt['invalid_registration'] = 'Pogrešna vrednost za datum registracije. Primer pravilne vrednosti:';
$txt['current_password'] = 'Trenutna lozinka';
// Don't use entities in the below string, except the main ones. (lt, gt, quot.)
$txt['required_security_reasons'] = 'Iz bezbednosnih razloga, potrebno je da unesete svoju trenutnu lozinku da biste izmenili profil.';

$txt['timeoffset_autodetect'] = 'auto detect';

$txt['secret_question'] = 'Tajno pitanje';
$txt['secret_desc'] = 'Da bi vam pomoglo u podsećanju svoje lozinke, unesite pitanje na koje <strong>samo vi</strong> znate odgovor.';
$txt['secret_desc2'] = 'Izaberite pažljivo. Ne biste želeli da neko pogodi odgovor!';
$txt['secret_answer'] = 'Odgovor';
$txt['incorrect_answer'] = 'Izvinite, ali niste precizirali ispravnu kombinaciju tajnog pitanja i odgovora u svom profilu. Vratite se nazad i upotrebite podrazumevani metod povratka lozinke.';
$txt['enter_new_password'] = 'Unesite odgovor na svoje pitanje i lozinku koju želite da koristite.  Lozinka će biti promenjena na onu koju izaberete ako na pitanje odgovorite tačno.';
$txt['secret_why_blank'] = 'zašto je ovo prazno?';

$txt['authentication_reminder'] = 'Podsećanje o autentifikaciji';
$txt['password_reminder_desc'] = 'Ako ste zaboravili vaše detalje za prijavljivanje, nemojte da se brinete, mogu biti preuzeti ponovo. Da biste pokrenuli ovaj proces, unesite ispod svoje korisničko ime ili imejl.';
$txt['authentication_options'] = 'Izaberite jednu od dve opcije';
$txt['authentication_openid_email'] = 'Pošaljite mi mejlom podsećanje na moj OpenID identitet';
$txt['authentication_openid_secret'] = 'Odgovoriću na moje &quot;tajno pitanje&quot; da biste prikazali moj OpenID identitet';
$txt['authentication_password_email'] = 'Pošaljite mi mejlom novu lozinku';
$txt['authentication_password_secret'] = 'Dozvolite mi da postavim novu lozinku odgovaranjem na moje &quot;tajno pitanje&quot;';
$txt['openid_secret_reminder'] = 'Unesite odgovor na pitanje prikazano ispod. Ako tačno odgovorite, prikazaćemo vam vaš OpenID identitet.';
$txt['reminder_openid_is'] = 'OpenID identitet povezan sa vašim nalogom je:<br />&nbsp;&nbsp;&nbsp;&nbsp;<strong>%1$s</strong><br /><br />Zapamtite ga da biste mogli da nastavite da ga koristite.';
$txt['reminder_continue'] = 'Nastavi';

$txt['accept_agreement_title'] = 'Accept agreement';
$txt['agreement_accepted_title'] = 'Nastavi';

$txt['current_theme'] = 'Trenutna tema';
$txt['change'] = 'Change Theme';
$txt['theme_forum_default'] = 'Podrazumevana tema foruma';
$txt['theme_forum_default_desc'] = 'Ovo je podrazumevana tema što znači da će se menjati zajedno sa podešavanjima administratora.';

$txt['profileConfirm'] = 'Da li stvarno želite da obrišete ovog korisnika?';

$txt['custom_title'] = 'Prilagođeni naslov';

$txt['lastLoggedIn'] = 'Poslednji put aktivan';

$txt['notify_settings'] = 'Podešavanja obaveštavanja:';
$txt['notify_save'] = 'Sačuvaj podešavanja';
$txt['notify_important_email'] = 'Primaj objave foruma i važna obaveštenja na mejl.';
$txt['notify_regularity'] = 'O temama i forumima za koje sam zatražio obaveštenja, obaveštavaj me';
$txt['notify_regularity_none'] = 'Nikad';
$txt['notify_regularity_instant'] = 'Odmah';
$txt['notify_regularity_first_only'] = 'Odmah - ali samo za prvi nepročitani odgovor';
$txt['notify_regularity_daily'] = 'Dnevno';
$txt['notify_regularity_weekly'] = 'Nedeljno';
$txt['auto_notify'] = 'Turn topic notification on when you post or reply to a topic.';
$txt['auto_notify_pbe_post'] = 'This is <strong>NOT</strong> recommended if you have "board" notifications enabled.';
$txt['notify_send_types'] = 'Notify me of topics and boards I\'ve requested notification on';
$txt['notify_send_type_everything'] = 'odgovorima i uređivanju';
$txt['notify_send_type_everything_own'] = 'uređivanju ako sam ja započeo temu';
$txt['notify_send_type_only_replies'] = 'samo odgovorima';
$txt['notify_send_type_only_replies_pbe'] = 'All messages';
$txt['notify_send_type_nothing'] = 'ni o čemu';
$txt['notify_send_body'] = 'When sending notifications of a reply to a topic, send the post in the email (but please don\'t reply to these emails.)';
$txt['notify_send_body_pbe'] = 'When sending email notifications, send the full text of the post in the email';
$txt['notify_send_body_pbe_post'] = '<strong>NOT</strong> available with Daily / Weekly summary';

$txt['notify_method'] = 'Notification and:';
$txt['notify_notification'] = 'no email (only mention/alert)';
$txt['notify_email'] = 'Immediate email';
$txt['notify_email_daily'] = 'Daily email';
$txt['notify_email_weekly'] = 'Weekly email';

$txt['notify_type_likemsg'] = 'Notify when one of your messages is liked';
$txt['notify_type_mentionmem'] = 'Notify when you are @mentioned';
$txt['notify_type_rlikemsg'] = 'Notify when a like is removed from one of your messages';
$txt['notify_type_buddy'] = 'Notify when someone adds you as buddy';
$txt['notify_type_quotedmem'] = 'Notify when someone quotes one of your messages';
$txt['notify_type_mailfail'] = 'Notify when email notifications are disabled (mention only)';

$txt['notifications_topics'] = 'Trenutna obaveštenja o temama';
$txt['notifications_topics_none'] = 'Trenutno ne primate obaveštenja ni o jednoj temi.';
$txt['notifications_topics_howto'] = 'To receive notifications from a specific topic, click the &quot;Notify&quot; button while viewing it.';

$txt['notifications_boards'] = 'Trenutna obaveštenja o forumima';
$txt['notifications_boards_none'] = 'Trenutno ne primate obaveštenja ni o jednom forumu.';
$txt['notifications_boards_howto'] = 'To request notifications from a specific board, either click the &quot;Notify&quot; button in the index of that board <strong>or</strong> use the checkboxes below to enable select board notifications.';
$txt['notifications_boards_current'] = 'You are receiving notifications on the boards shown in <strong>BOLD</strong>.  Use the checkboxes to turn these off or add additional boards to your notification list';
$txt['notifications_boards_update'] = 'Update';
$txt['notifications_update'] = 'Prekini obaveštavanje';

$txt['statPanel_showStats'] = 'Korisničke statistike za: ';
$txt['statPanel_users_votes'] = 'Broj glasanja';
$txt['statPanel_users_polls'] = 'Broj napravljenih anketa';
$txt['statPanel_total_time_online'] = 'Ukupno vreme provedeno na forumu';
$txt['statPanel_noPosts'] = 'Nema poruka o kojima bismo mogli da pričamo!';
$txt['statPanel_generalStats'] = 'Opšta statistika';
$txt['statPanel_posts'] = 'poruka';
$txt['statPanel_topics'] = 'tema';
$txt['statPanel_total_posts'] = 'Ukupno poruka';
$txt['statPanel_total_topics'] = 'Ukupno pokrenutih tema';
$txt['statPanel_votes'] = 'glasova';
$txt['statPanel_polls'] = 'glasanja';
$txt['statPanel_topBoards'] = 'Najpopularniji forumi po porukama';
$txt['statPanel_topBoards_posts'] = '%1$d postova od ukupno %2$d postova (%3$01.2f%%) ';
$txt['statPanel_topBoards_memberposts'] = '%1$d postova od korisnikovih %2$d postova (%3$01.2f%%) ';
$txt['statPanel_topBoardsActivity'] = 'Najpopularniji forumi po aktivnosti';
$txt['statPanel_activityTime'] = 'Slanje poruka u zavisnosti od vremena';
$txt['statPanel_activityTime_posts'] = '%1$d poruka (%2$d%%) ';

$txt['deleteAccount_warning'] = 'Upozorenje - Ove akcije se ne mogu opozvati!';
$txt['deleteAccount_desc'] = 'Sa ove strane možete da obrišete korisnikov nalog i poruke.';
$txt['deleteAccount_member'] = 'Obriši nalog ovog člana';
$txt['deleteAccount_posts'] = 'Poruke korisnika koje će biti uklonjene';
$txt['deleteAccount_none'] = 'Bez';
$txt['deleteAccount_all_posts'] = 'Replies Only';
$txt['deleteAccount_topics'] = 'Topics and Replies';
$txt['deleteAccount_confirm'] = 'Da li ste stvarno sigurni da želite da obrišete ovaj nalog?';
$txt['deleteAccount_approval'] = 'Napomena: urednici foruma će morati da odobre brisanje naloga pre nego što isti bude uklonjen.';

$txt['profile_of_username'] = 'Profil korisnika %1$s';
$txt['profileInfo'] = 'Informacije o profilu';
$txt['showPosts'] = 'Prikaži poruke ';
$txt['showPosts_help'] = 'Ovaj odeljak vam dozvoljava da vidite sve poruke ovog člana. Imajte na umu da možete da vidite samo poruke iz onih oblasti kojima imate pristup.';
$txt['showMessages'] = 'Poruke';
$txt['showGeneric_help'] = 'This section allows you to view all %1$s made by this member. Note that you can only see %1$s made in areas you currently have access to.';
$txt['showTopics'] = 'Teme';
$txt['showUnwatched'] = 'Unwatched topics';
$txt['showAttachments'] = 'Priložene datoteke';
$txt['viewWarning_help'] = 'This section allows you to view all warnings issued to this member.';
$txt['statPanel'] = 'Prikaži statistiku';
$txt['editBuddyIgnoreLists'] = 'Spisak prijatelja/ignorisanja';
$txt['editBuddies'] = 'Izmeni spisak prijatelja';
$txt['editIgnoreList'] = 'Izmeni spisak ignorisanja';
$txt['trackUser'] = 'Praćenje korisnika';
$txt['trackActivity'] = 'Aktivnost';
$txt['trackIP'] = 'IP adresa';
$txt['trackLogins'] = 'Logins';

$txt['likes_show'] = 'Show Likes';
$txt['likes_given'] = 'Posts you liked';
$txt['likes_profile_received'] = 'received';
$txt['likes_profile_given'] = 'given';
$txt['likes_received'] = 'Your posts liked by others';
$txt['likes_none_given'] = 'You have not liked any posts';
$txt['likes_none_received'] = 'No one has liked any of your posts :\'(';
$txt['likes_confirm_delete'] = 'Remove this like?';
$txt['likes_show_who'] = 'Show the members that liked this post';
$txt['likes_by'] = 'Liked by';
$txt['likes_delete'] = 'Obriši';

$txt['authentication'] = 'Prijavljivanje';
$txt['change_authentication'] = 'U ovom odeljku možete da promenite način na koji se prijavljujete na forum. Možete da se odaberete korišćenje OpenID naloga za potvrdu svog identiteta ili da, alternativno, pređete na korišćenje korisničkog imena i lozinke.';

$txt['profileEdit'] = 'Izmeni profil';
$txt['account_info'] = 'Ovo su podešavanja vezana za vaš nalog. Ova stranica sadrži kritične informacije koje vas predstavljaju na ovom forumu. Iz bezbednosnih razloga, moraćete da unesete svoju (trenutnu) lozinku da biste izmenili ove informacije.';
$txt['forumProfile_info'] = 'You can change your personal information on this page. This information will be displayed throughout {forum_name_html_safe}. If you aren\'t comfortable with sharing some information, simply skip it - nothing here is required.';
$txt['theme_info'] = 'Ovaj odeljak vam omogućava da prilagodite izgled foruma.';
$txt['notification_info'] = 'This allows you to be notified of replies to posts, newly posted topics, and forum announcements. You can change those settings here, or oversee the topics and boards you are currently receiving notifications for.';
$txt['groupmembership'] = 'Članstvo u grupama';
$txt['groupMembership_info'] = 'U ovom odeljku vašeg profila možete da promenite kojim grupama pripadate.';
$txt['ignoreboards'] = 'Opcije ignorisanja foruma';
$txt['ignoreboards_info'] = 'This page lets you ignore particular boards.  When a board is ignored, the new post indicator will not show up on the board index.  New posts will not show up using the "unread post" search link (when searching it will not look in those boards). However, ignored boards will still appear on the board index and upon entering will show which topics have new posts.  When using the "unread replies" link, new posts in an ignored board will still be shown.';
$txt['contactprefs'] = 'Messaging';

$txt['profileAction'] = 'Akcije';
$txt['deleteAccount'] = 'Obriši ovaj nalog';
$txt['profileSendIm'] = 'Pošalji privatnu poruku';
$txt['profile_sendpm_short'] = 'Pošalji PP';

$txt['profileBanUser'] = 'Zabrani ovog korisnika';

$txt['display_name'] = 'Prikazano ime';
$txt['enter_ip'] = 'Unesite IP (opseg)';
$txt['errors_by'] = 'Poruke o grešci od';
$txt['errors_desc'] = 'Ispod je spisak svih skorašnjih grešaka koje je ovaj korisnik napravio/iskusio.';
$txt['errors_from_ip'] = 'Poruke o greškama sa IP (opsega)';
$txt['errors_from_ip_desc'] = 'Ispod je spisak svih poruka o greškama napravljenih sa ovog IP (opsega).';
$txt['ip_address'] = 'IP adresa';
$txt['ips_in_errors'] = 'IP adrese korišćene u porukama o grešci';
$txt['ips_in_messages'] = 'IP adrese korišćene u poslednjim porukama';
$txt['members_from_ip'] = 'Članovi sa IP (opsega)';
$txt['members_in_range'] = 'Članovi koji su verovatno u istom opsegu';
$txt['messages_from_ip'] = 'Poruke poslate sa ovog IP (opsega)';
$txt['messages_from_ip_desc'] = 'Ispod je spisak svih poruka poslatih sa ovog IP (opsega).';
$txt['trackLogins_desc'] = 'Below is a list of all times this account was logged into.';
$txt['most_recent_ip'] = 'Najnovija IP adresa';
$txt['why_two_ip_address'] = 'Zašto su prikazane dve IP adrese?';
$txt['no_errors_from_ip'] = 'Nisu pronađene poruke o grešci sa naznačenog IP (opsega)';
$txt['no_errors_from_user'] = 'Nisu pronađene poruke o grešci od naznačenog korisnika';
$txt['no_members_from_ip'] = 'Nisu pronađeni članovi sa naznačenog IP (opsega)';
$txt['no_messages_from_ip'] = 'Nisu pronađene poruke sa naznačenog IP (opsega)';
$txt['trackLogins_none_found'] = 'No recent logins were found';
$txt['none'] = 'Bez';
$txt['own_profile_confirm'] = 'Da li ste sigurni da želite da obrišete svoj nalog?';
$txt['view_ips_by'] = 'Pogledajte IP adrese korišćene od';

$txt['avatar_will_upload'] = 'Dostavljanje avatara';

$txt['activate_changed_email_title'] = 'Promenjena je imejl adresa';
$txt['activate_changed_email_desc'] = 'Promenili ste imejl adresu. Kako biste potvrdili validnost adrese dobićete mejl. Kliknite na link u mejlu kako biste reaktivirali nalog.';

// Use numeric entities in the below three strings.
$txt['no_reminder_email'] = 'Ne mogu da pošaljem mejl sa podsetnikom.';
$txt['send_email'] = 'Pošalji mejl na';
$txt['to_ask_password'] = 'da biste zatražili lozinku';

$txt['user_email'] = 'Korisničko ime/Imejl';

// Use numeric entities in the below two strings.
$txt['reminder_sent'] = 'Mejl je poslat na vašu adresu. Kliknite na link u tom mejlu da biste postavili novu lozinku';
$txt['reminder_openid_sent'] = 'Vaš trenutni OpenID identitet je poslat na vašu imejl adresu.';
$txt['reminder_set_password'] = 'Postavi lozinku';
$txt['reminder_password_set'] = 'Lozinka je uspešno promenjena';
$txt['reminder_error'] = '%1$s nije uspeo da odgovori tačno na svoje tajno pitanje pokušavajući da promeni zaboravljenu lozinku.';

$txt['registration_not_approved'] = 'Ovaj nalog još uvek nije odobren. Ako morate da promenite svoju imejl adresu kliknite';
$txt['registration_not_activated'] = 'Ovaj nalog još nije aktiviran. Ako želite da vam ponovo pošaljemo aktivacioni mejl kliknite';

$txt['primary_membergroup'] = 'Primarna korisnička grupa';
$txt['additional_membergroups'] = 'Dodatne grupe članova';
$txt['additional_membergroups_show'] = 'Show additional groups';
$txt['no_primary_membergroup'] = '(bez primarne korisničke grupe)';
$txt['deadmin_confirm'] = 'Da li stvarno želite da sami uklonite svoj administratorski status?';

$txt['account_activate_method_2'] = 'Nalog zahteva ponovnu aktivaciju nakon promene imejl adrese';
$txt['account_activate_method_3'] = 'Nalog nije odobren';
$txt['account_activate_method_4'] = 'Nalog zahteva odobrenje brisanja';
$txt['account_activate_method_5'] = 'Nalog pripada &quot;mladoj&quot; osobi i zahteva odobrenje';
$txt['account_not_activated'] = 'Nalog još nije aktiviran';
$txt['account_activate'] = 'aktiviraj';
$txt['account_approve'] = 'odobri';
$txt['user_is_banned'] = 'Korisnik je trenutno zabranjen';
$txt['view_ban'] = 'Prikaži';
$txt['user_banned_by_following'] = 'Korisnik je trenutno pod sledećim zabranama';
$txt['user_cannot_due_to'] = 'Korisnik ne može da %1$s kao rezultat zabrane: &quot;%2$s&quot;';
$txt['ban_type_post'] = 'šalje poruke';
$txt['ban_type_register'] = 'se registruje';
$txt['ban_type_login'] = 'se prijavi';
$txt['ban_type_access'] = 'pristupi forumu';

$txt['show_online'] = 'Prikaži ostalima moj status prisutnosti';

$txt['return_to_post'] = 'Vrati se na temu nakon slanja.';
$txt['no_new_reply_warning'] = 'Ne upozoravaj me o novim odgovorima poslatim prilikom pisanja poruke.';
$txt['recent_pms_at_top'] = 'Prikaži najnovije privatne poruke pri vrhu.';
$txt['wysiwyg_default'] = 'Prikaži WYSIWYG editor na strani za slanje poruka';

$txt['timeformat_default'] = '(podrazumevano na forumu)';
$txt['timeformat_easy1'] = 'mesec dan, godina, čč:mm:ss am/pm';
$txt['timeformat_easy2'] = 'mesec dan, godina, čč:mm:ss (24 sata)';
$txt['timeformat_easy3'] = 'gggg-mm-dd, čč:mm:ss';
$txt['timeformat_easy4'] = 'dd mesec gggg, čč:mm:ss';
$txt['timeformat_easy5'] = 'dd-mm-gggg, čč:mm:ss';

$txt['poster'] = 'Postavio';

$txt['use_sidebar_menu'] = 'Use sidebar menu instead of dropdowns.';
$txt['use_click_menu'] = 'Use click to open menus, instead of hover to open.';
$txt['show_no_avatars'] = 'Ne prikazuj avatare korisnika.';
$txt['show_no_signatures'] = 'Ne prikazuj potpise korisnika.';
$txt['show_no_censored'] = 'Ne cenzuriši reči.';
$txt['topics_per_page'] = 'Tema za prikazivanje po strani:';
$txt['messages_per_page'] = 'Poruka za prikazivanje po strani:';
$txt['hide_poster_area'] = 'Hide the poster information area.';
$txt['per_page_default'] = 'podrazumevano na forumu';
$txt['calendar_start_day'] = 'First day of the week on the calendar:';
$txt['display_quick_reply'] = 'Prikaži brz odgovor u prikazu teme: ';
$txt['use_editor_quick_reply'] = 'Use full editor in Quick Reply.';
$txt['display_quick_mod'] = 'Show quick-moderation as:';
$txt['display_quick_mod_none'] = 'ne prikazuj.';
$txt['display_quick_mod_check'] = 'kućice.';
$txt['display_quick_mod_image'] = 'ikone.';

$txt['whois_title'] = 'Potraži IP adresu pomoću regionalnih whois servera';
$txt['whois_afrinic'] = 'AfriNIC (Afrika)';
$txt['whois_apnic'] = 'APNIC (Region Azije i Pacifika)';
$txt['whois_arin'] = 'ARIN (Severna Amerika, deo Kariba i pod-Saharska Afrika)';
$txt['whois_lacnic'] = 'LACNIC (Latinoamerički i Karipski region)';
$txt['whois_ripe'] = 'RIPE (Evropa, Bliski istok i delovi Afrike i Azije)';

$txt['moderator_why_missing'] = 'zašto se ovde ne nalazi urednik?';
$txt['username_change'] = 'promeni';
$txt['username_warning'] = 'Da biste promenili ime člana, forum mora da poništi i njegovu lozinku koja će mu biti poslata mejlom zajedno sa novim korisničkim imenom.';

$txt['show_member_posts'] = 'Prikaži poruke ovog člana';
$txt['show_member_topics'] = 'Prikaži teme ovog člana';
$txt['show_member_attachments'] = 'Prikaži priložene datoteke ovog člana';
$txt['show_posts_none'] = 'Korisnik još nije napisao nijednu poruku. ';
$txt['show_topics_none'] = 'Još nema pokrenutih tema.';
$txt['unwatched_topics_none'] = 'You don\'t have any topic in the unwatch list.';
$txt['show_attachments_none'] = 'Korisnik još nije priložio nijednu datoteku. ';
$txt['show_attach_filename'] = 'Ime datoteke';
$txt['show_attach_downloads'] = 'Preuzimanja';
$txt['show_attach_posted'] = 'Poslao';

$txt['showPermissions'] = 'Prikaži dozvole';
$txt['showPermissions_status'] = 'Status dozvole';
$txt['showPermissions_help'] = 'Ova sekcija vam omogućava da vidite dozvole ovog člana (onemogućene dozvole su  <del>precrtane</del>). ';
$txt['showPermissions_given'] = 'Date od';
$txt['showPermissions_denied'] = 'Oduzete od';
$txt['showPermissions_permission'] = 'Permission (denied permissions are shown <del>struck through</del>)';
$txt['showPermissions_none_general'] = 'Ovaj član nema postavljenih opštih dozvola.';
$txt['showPermissions_none_board'] = 'Ovaj član nema dozvole specifične za određeni forum.';
$txt['showPermissions_all'] = 'Kao administrator, ovaj član ima sve moguće dozvole.';
$txt['showPermissions_select'] = 'Dozvole specifične za forum za';
$txt['showPermissions_general'] = 'Dozvole po grupama članova';
$txt['showPermissions_global'] = 'Svi forumi';
$txt['showPermissions_restricted_boards'] = 'Ograničeni forumi';
$txt['showPermissions_restricted_boards_desc'] = 'Ovaj korisnik nema pristup sledećim forumima';

$txt['local_time'] = 'Lokalno vreme';
$txt['posts_per_day'] = 'po danu';

$txt['buddy_ignore_desc'] = 'Ova stranica vam omogućava da upravljate spiskovima svojih prijatelja i ignorisanih članova na ovom forumu. Dodavanje članova ovim spiskovima će, između ostalog, pomoći boljoj kontroli primljenih mejlova i privatnih poruka, zavisno od vaših podešavanja.';

$txt['buddy_add'] = 'Add to buddy list';
$txt['buddy_remove'] = 'Remove from buddy list';
$txt['buddy_add_button'] = 'Dodaj';
$txt['no_buddies'] = 'Vaš spisak prijatelja je trenutno prazan';

$txt['ignore_add'] = 'Add to ignore list';
$txt['ignore_remove'] = 'Remove from ignore list';
$txt['ignore_add_button'] = 'Dodaj';
$txt['no_ignore'] = 'Vaš spisak ignorisanja je trenutno prazan';

$txt['regular_members'] = 'Registrovani članovi';
$txt['regular_members_desc'] = 'Svaki član ovog foruma je član ove grupe.';
$txt['group_membership_msg_free'] = 'Vaše članstvo u grupi je uspešno ažurirano.';
$txt['group_membership_msg_request'] = 'Vaš zahtev je podnet. Budite strpljivi dok se bude razmatrao.';
$txt['group_membership_msg_primary'] = 'Vaša primarna grupa je ažurirana';
$txt['current_membergroups'] = 'Trenutne grupe članova';
$txt['available_groups'] = 'Dostupne grupe';
$txt['join_group'] = 'Pridruži se grupi';
$txt['leave_group'] = 'Napusti grupu';
$txt['request_group'] = 'Zatraži članstvo';
$txt['approval_pending'] = 'Odobrenja na čekanju';
$txt['make_primary'] = 'Napravi primarnom grupom';

$txt['request_group_membership'] = 'Zatraži članstvo u grupi';
$txt['request_group_membership_desc'] = 'Pre nego što se budete pridružili ovoj grupi, članstvo mora da odobri urednik. Upišite razlog za pridruživanje ovoj grupi';
$txt['submit_request'] = 'Podnesi zahtev';

$txt['profile_updated_own'] = 'Vaš profil je uspešno ažuriran.';
$txt['profile_updated_else'] = 'The profile for <strong>%1$s</strong> has been updated successfully.';

$txt['profile_error_signature_max_length'] = 'Vaš potpis ne može da bude veći od %1$d znakova';
$txt['profile_error_signature_max_lines'] = 'Vaš potpis ne može da se prostire na više od %1$d linija';
$txt['profile_error_signature_max_image_size'] = 'Slike u vašem potpisu ne smeju da budu veće od %1$dx%2$d piksela';
$txt['profile_error_signature_max_image_width'] = 'Slike u vašem potpisu ne smeju da budu šire od %1$d piksela';
$txt['profile_error_signature_max_image_height'] = 'Slike u vašem potpisu ne smeju da budu više od %1$d piksela';
$txt['profile_error_signature_max_image_count'] = 'Ne možete da imate više od %1$d slika u svom potpisu';
$txt['profile_error_signature_max_font_size'] = 'Tekst u vašem potpisu ne sme da bude veći od %1$s';
$txt['profile_error_signature_allow_smileys'] = 'Nemate dozvolu da koristite smajlije u vašem potpisu';
$txt['profile_error_signature_max_smileys'] = 'Ne možete da imate više od %1$d smajlija u vašem potpisu';
$txt['profile_error_signature_disabled_bbc'] = 'Sledeći BBC tagovi nisu dozvoljeni u vašem potpisu: %1$s';

$txt['profile_view_warnings'] = 'Pogledaj upozorenja';
$txt['profile_issue_warning'] = 'Izdaj upozorenje';
$txt['profile_warning_level'] = 'Nivo upozorenja';
$txt['profile_warning_desc'] = 'Ovde možete da podesite nivo upozorenja korisnika i izdate im pismeno upozorenje ukoliko je to potrebno. Možete i da pratite istoriju njihovih upozorenja kao i da pogledate posledice njihovog trenutnog nivoa upozorenja koje su ustanovili administratori.';
$txt['profile_warning_name'] = 'Ime člana';
$txt['profile_warning_impact'] = 'Rezultat';
$txt['profile_warning_reason'] = 'Razlog za upozorenje';
$txt['profile_warning_reason_desc'] = 'Ovo polje je zahtevano i biće sačuvano.';
$txt['profile_warning_effect_none'] = 'Bez.';
$txt['profile_warning_effect_watch'] = 'Korisnik će biti dodat na urednički spisak nadgledanja.';
$txt['profile_warning_effect_own_watched'] = 'Nalazite se na popisu moderatora za nadgledanje';
$txt['profile_warning_is_watch'] = 'nadgleda se';
$txt['profile_warning_effect_moderate'] = 'Sve korisnikove poruke biće uređivane.';
$txt['profile_warning_effect_own_moderated'] = 'Sve vaše poruke će biti uređene';
$txt['profile_warning_is_moderation'] = 'poruke se uređuju';
$txt['profile_warning_effect_mute'] = 'Korisnik neće moći da šalje poruke.';
$txt['profile_warning_effect_own_muted'] = 'Nećete moći da šaljete poruke.';
$txt['profile_warning_is_muted'] = 'ne može da šalje poruke';
$txt['profile_warning_effect_text'] = 'Nivo >= %1$d: %2$s';
$txt['profile_warning_notify'] = 'Pošalji obaveštenje';
$txt['profile_warning_notify_template'] = 'Izaberite predložak:';
$txt['profile_warning_notify_subject'] = 'Naslov obaveštenja';
$txt['profile_warning_notify_body'] = 'Tekst obaveštenja';
$txt['profile_warning_notify_template_subject'] = 'Primili ste upozorenje';
// Use numeric entities in below string.
$txt['profile_warning_notify_template_outline'] = '{MEMBER},

You have received a warning for %1$s. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_template_outline_post'] = '{MEMBER},

You have received a warning for %1$s in regards to the message:
{MESSAGE}.

Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['profile_warning_notify_for_spamming'] = 'spamovanja';
$txt['profile_warning_notify_title_spamming'] = 'Spamovanje';
$txt['profile_warning_notify_for_offence'] = 'slanja uvredljivog materijala';
$txt['profile_warning_notify_title_offence'] = 'Slanje uvredljivog materijala';
$txt['profile_warning_notify_for_insulting'] = 'vređanja ostalih korisnika i/ili osoblja';
$txt['profile_warning_notify_title_insulting'] = 'Vređanje korisnika/osoblja';
$txt['profile_warning_issue'] = 'Izdaj upozorenje';
$txt['profile_warning_max'] = '(Maksimalno 100)';
$txt['profile_warning_limit_attribute'] = 'Napomena: ne možete da podesite nivo upozorenja ovog korisnika za više od %1$d%% poena u roku od 24 časa.';
$txt['profile_warning_errors_occurred'] = 'Upozorenje nije poslato iz sledećih razloga';
$txt['profile_warning_success'] = 'Upozorenje je uspešno izdato';
$txt['profile_warning_new_template'] = 'Novi predložak';

$txt['profile_warning_previous'] = 'Prethodna upozorenja';
$txt['profile_warning_previous_none'] = 'Ovaj korisnik nije primio nijedno upozorenje ranije.';
$txt['profile_warning_previous_issued'] = 'Izdao';
$txt['profile_warning_previous_time'] = 'Vreme';
$txt['profile_warning_previous_level'] = 'Poena';
$txt['profile_warning_previous_reason'] = 'Razlog';
$txt['profile_warning_previous_notice'] = 'Pogledaj obaveštenje poslato članu';

$txt['viewwarning'] = 'Pogledaj upozorenja';
$txt['profile_viewwarning_for_user'] = 'Upozorenja korisniku %1$s';
$txt['profile_viewwarning_no_warnings'] = 'No warnings have been issued.';
$txt['profile_viewwarning_desc'] = 'Ispod se nalazi pregled svih upozorenja koje je urednički tim poslao ovom članu.';
$txt['profile_viewwarning_previous_warnings'] = 'Prethodna upozorenja';
$txt['profile_viewwarning_impact'] = 'Uticaj Upozorenja';

$txt['subscriptions'] = 'Plaćene pretplate';

$txt['pm_settings_desc'] = 'Na ovoj strani možete da promenite niz opcija vezanih za privatne poruke uključujući i način na koji se poruke prikazuju i ko može da vam ih šalje.';
$txt['email_notify'] = 'Obavesti me mejlom svaki put kada primim privatnu poruku:';
$txt['email_notify_never'] = 'Nikad';
$txt['email_notify_buddies'] = 'Samo od prijatelja';
$txt['email_notify_always'] = 'Uvek';

$txt['receive_from'] = 'Members allowed to contact me:';
$txt['receive_from_everyone'] = 'svih članova';
$txt['receive_from_ignore'] = 'svih članova, sem onih na mom spisku ignorisanja';
$txt['receive_from_admins'] = 'samo administratora';
$txt['receive_from_buddies'] = 'prijatelja i administratora';
$txt['receive_from_description'] = 'This setting applies to both Personal Messages and emails (if the option to email members is enabled)';

$txt['popup_messages'] = 'Prikaži iskačući prozor kada primim nove poruke.';
$txt['pm_remove_inbox_label'] = 'Remove the inbox label when applying another label.';
$txt['pm_display_mode'] = 'Prikaz privatnih poruka';
$txt['pm_display_mode_all'] = 'Sve odjednom';
$txt['pm_display_mode_one'] = 'Jednu po jednu';
$txt['pm_display_mode_linked'] = 'Kao razgovor';

$txt['history'] = 'History';
$txt['history_description'] = 'This section allows you to review certain profile actions performed on this member\'s profile as well as track their IP address and login history.';

$txt['trackEdits'] = 'Izmene profila';
$txt['trackEdit_deleted_member'] = 'Obrisan član';
$txt['trackEdit_no_edits'] = 'Nisam zabeležio nijednu promenu profila ovog člana.';
$txt['trackEdit_action'] = 'Polje';
$txt['trackEdit_before'] = 'Vrednost Pre';
$txt['trackEdit_after'] = 'Vrednost Posle';
$txt['trackEdit_applicator'] = 'Izmenio';

$txt['trackEdit_action_real_name'] = 'Ime člana';
$txt['trackEdit_action_usertitle'] = 'Prilagođeni naslov';
$txt['trackEdit_action_member_name'] = 'Korisničko ime';
$txt['trackEdit_action_email_address'] = 'Imejl adresa';
$txt['trackEdit_action_id_group'] = 'Primarna korisnička grupa';
$txt['trackEdit_action_additional_groups'] = 'Dodatne grupe članova';

$txt['otp_enabled_help'] = 'Enabling this will add a second factor (one-time password) for authentication.';
$txt['otp_token_help'] = 'This generates a secret token for time-based one-time password  apps such as Authy or Google Authenticator. Once the secret was generated use your favorite authenticator app and scan the qrcode.<ul><li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en">Google Authenticator for Android</a></li><li><a href="https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8">Google Authenticator for IOS (Apple)</a></li></ul>';
