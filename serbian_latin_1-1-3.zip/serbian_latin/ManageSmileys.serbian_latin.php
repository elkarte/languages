<?php
// Version: 1.1; ManageSmileys

$txt['smiley_sets_save'] = 'Sačuvaj promene';
$txt['smiley_sets_add'] = 'New Smiley Set';
$txt['smiley_sets_delete'] = 'Obriši izabrano';
$txt['smiley_sets_confirm'] = 'Da li ste sigurni da želite da uklonite ove postavke smajlija?\\n\\nNapomena: Ovo neće ukloniti slike, samo odabir.';
$txt['smiley_sets_none'] = 'There are currently no smiley sets.';

$txt['setting_smiley_sets_default'] = 'Podrazumevana postavka smajlija';
$txt['setting_smiley_sets_enable'] = 'Omogući odabir postavki smajlija od strane članova';
$txt['setting_smiley_enable'] = 'Omogući prilagođene smajlije';
$txt['setting_smileys_url'] = 'Osnovni URL do svih postavki smajlija';
$txt['setting_smileys_dir'] = 'Apsolutna putanja do svih postavki smajlija';
$txt['setting_messageIcons_enable'] = 'Omogući prilagođene ikone poruka';
$txt['setting_messageIcons_enable_note'] = '(u suprotnom, biće korišćene podrazumevane ikone poruka.)';
$txt['groups_manage_smileys'] = 'Grupe kojima je dozvoljeno da upravljaju smajlijima i ikonama poruka';

$txt['smiley_sets_name'] = 'Ime';
$txt['smiley_sets_url'] = 'URL';
$txt['smiley_sets_default'] = 'Uobičajeno';

$txt['smileys_add_method'] = 'Izvor slika';
$txt['smileys_add_existing'] = 'Use existing file';
$txt['smileys_add_upload'] = 'Upload new smiley';
$txt['smileys_add_upload_choose'] = 'Datoteka za prilaganje';
$txt['smileys_add_upload_choose_desc'] = 'Slika koje će biti korišćena za sve postavke smajlija.';
$txt['smileys_add_upload_all'] = 'Ista slika za sve postavke';
$txt['smileys_add_upload_for1'] = 'Slika za';
$txt['smileys_add_upload_for2'] = 'postavku';

$txt['smileys_enable_note'] = '(u suprotnom, koristiće se podrazumevani smajliji.)';
$txt['smileys_code'] = 'Kod';
$txt['smileys_filename'] = 'Ime datoteke';
$txt['smileys_description'] = 'Opis';
$txt['smileys_remove'] = 'Ukloni';
$txt['smileys_save'] = 'Sačuvaj promene';
$txt['smileys_delete'] = 'Izbriši smajli';
// Don't use entities in the below string.
$txt['smileys_delete_confirm'] = 'Da li ste sigurni da želite da izbrišete ovaj smajli?';
$txt['smileys_with_selected'] = 'Sa izabranim';
$txt['smileys_make_hidden'] = 'učini nevidljivim';
$txt['smileys_show_on_post'] = 'Show on post form';
$txt['smileys_show_on_popup'] = 'Show on popup';

$txt['smiley_settings_explain'] = 'Ova podešavanja vam dozvoljavaju da promenite podrazumevanu postavku smajlija, dozvolite ljudima odabir sopstvenih smajlija i zadate putanje i konfiguracione podatke.';
$txt['smiley_editsets_explain'] = 'Postavke smajlija su grupe smajlija između kojih vaši korisnici mogu da biraju. Na primer, možete da imate žute i crvene smajlije.<br />Ovde možete da promenite ime i lokaciju svake postavke smajlija. Zapamtite da sve postavke smajlija dele iste smajlije.';
$txt['smiley_editsmileys_explain'] = 'Change your smileys here by clicking on the smiley you want to modify. Remember that these smileys all have to exist in all the sets or some smileys won\'t show up.  Don\'t forget to save after you are done editing.';
$txt['smiley_setorder_explain'] = 'Promenite red smajlija.';
$txt['smiley_addsmiley_explain'] = 'Ovde možete da dodate nov smajli - ili iz postojeće datoteke ili dostavljanjem nove.';

$txt['smiley_set_select_default'] = 'Podrazumevana postavka smajlija';
$txt['smiley_set_new'] = 'Create new Smiley Set';
$txt['smiley_set_modify_existing'] = 'Modify existing Smiley Set';
$txt['smiley_set_modify'] = 'Izmeni';
$txt['smiley_set_import_directory'] = 'Uvezi smajlije koji su već u ovom direktorijumu';
$txt['smiley_set_import_single'] = 'Postoji jedan smajli u ovoj postavci smajlija koji još uvek nije uvežen. Kliknite';
$txt['smiley_set_import_multiple'] = 'Postoje %1$d smajlija u direktorijumu koji još uvek nisu uveženi. Kliknite';
$txt['smiley_set_to_import_single'] = 'da bi ga odmah uvezli.';
$txt['smiley_set_to_import_multiple'] = 'da biste ih odmah uvezli.';

$txt['smileys_location'] = 'Lokacija';
$txt['smileys_location_form'] = 'Forma za slanje';
$txt['smileys_location_hidden'] = 'sakrivenih';
$txt['smileys_location_popup'] = 'Iskačući prozor';
$txt['smileys_modify'] = 'Izmeni';
$txt['smileys_not_found_in_set'] = 'Smajli nije nađen u postavci(kama)';
$txt['smileys_default_description'] = '(unesite opis)';
$txt['smiley_new'] = 'Dodaj novi smajli';
$txt['smiley_modify_existing'] = 'Izmeni smajli';
$txt['smiley_preview'] = 'Pregledaj';
$txt['smiley_preview_using'] = 'koristeći postavku smajlija';
$txt['smileys_confirm'] = 'Da li ste sigurni da želite da uklonite ove smajlije?\\n\\nNapomena: Ovo neće ukloniti slike, samo odabir.';
$txt['smileys_location_form_description'] = 'Ovi smajliji će se pojaviti iznad polja za unos teksta pri slanju nove poruke na forumu ili privatne poruke.';
$txt['smileys_location_popup_description'] = 'Ovi smajliji će se prikazati u iskačućem prozoru, koji se prikazuje kada korisnik klikne na \'[još]\'';
$txt['smileys_move_select_destination'] = 'Izaberite odredište smajlija';
$txt['smileys_move_select_smiley'] = 'Select smiley to move or drag it to the location you want';
$txt['smileys_move_here'] = 'Premesti smajlije na ovu lokaciju';
$txt['smileys_no_entries'] = 'Trenutno nema podešenih smajlija.';
$txt['smileys_moved_done'] = 'Smiley successfully moved';
$txt['smileys_moved_fail'] = 'Unable to move smiley';

$txt['icons_edit_icons_explain'] = 'Ovde možete da promenite koje će ikone poruka biti dostupne na vašem forumu. Možete da dodate, menjate i uklanjate ikone kao i da ograničite njihovu upotrebu na određene forume.';
$txt['icons_edit_icons_all_boards'] = 'Available in all boards';
$txt['icons_board'] = 'Forum';
$txt['icons_confirm'] = 'Da li ste sigurni da želite da uklonite ove ikone?\\n\\nPažnja: ovo će samo sprečiti korisnike da upotrebljavaju ove ikone dok će slike ostati.';
$txt['icons_add_new'] = 'Add new icon';

$txt['icons_edit_icon'] = 'Edit message icon';
$txt['icons_new_icon'] = 'New message icon';
$txt['icons_location_first_icon'] = 'As first icon';
$txt['icons_location_after'] = 'Posle';
$txt['icons_filename_all_png'] = 'All files must be &quot;png&quot; files';
$txt['icons_no_entries'] = 'Trenutno nema podešenih ikona poruka.';
$txt['icons_reordered'] = 'Message Icons successfully reordered';
$txt['icons_reorder_note'] = 'You can change the message icon order by dragging and dropping an item to a new location in the list.';