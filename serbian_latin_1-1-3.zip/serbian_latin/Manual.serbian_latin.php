<?php
// Version: 1.1; Manual

/* Everything in this file is for the ElkArte help manual
   If you are looking at translating the manual into another language
   please visit the ElkArte website for tools to assist! */

$txt['manual_elkarte_user_help'] = 'ElkArte User Help';

$txt['manual_welcome'] = 'Welcome to %s, powered by ElkArte Forum software!';
$txt['manual_introduction'] = 'ElkArte is the elegant, effective, powerful and free forum software solution that this site is running. It allows users to communicate in discussion topics on a given subject in a clever and organized manner. Furthermore, it has a number of powerful features which end users can take advantage of. Help for many of ElkArte\'s features can be found by either clicking the question mark icon next to the relevant section or by selecting one of the links on this page. These links will take you to ElkArte\'s centrally-located documentation on the ElkArte official site.';
$txt['manual_docs_and_credits'] = 'For more information about how to use ElkArte, please see the <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> and check out the <a href="%2$s">credits</a> to find out who has made ElkArte what it is today.';

$txt['manual_section_registering_title'] = 'Registracija';
$txt['manual_section_logging_in_title'] = 'Prijavljivanje';
$txt['manual_section_profile_title'] = 'Profil';
$txt['manual_section_search_title'] = 'Pretraga';
$txt['manual_section_posting_title'] = 'Pisanje';
$txt['manual_section_bbc_title'] = 'Bilten Forum Kod (BBC) ';
$txt['manual_section_personal_messages_title'] = 'Privatne poruke';
$txt['manual_section_memberlist_title'] = 'Lista članova';
$txt['manual_section_calendar_title'] = 'Kalendar';
$txt['manual_section_features_title'] = 'Karakteristike';

$txt['manual_section_registering_desc'] = 'Mnogi forumi zahtevaju od korisnika da se registruju kako bi dobili pun pristup sadržaju.';
$txt['manual_section_logging_in_desc'] = 'Jednom kada su registrovani korisnici se moraju prijaviti sa svojim nalogom.';
$txt['manual_section_profile_desc'] = 'Svaki korisnik ima svoj lični profil.';
$txt['manual_section_search_desc'] = 'Pretraživanje je vrlo korisna opcija koja vam omogućava da pronađete informacije u postovima i temama.';
$txt['manual_section_posting_desc'] = 'Poenta postojanja foruma jeste da omogući korisnicima da se izraze.';
$txt['manual_section_bbc_desc'] = 'Poruke mogu biti oblikovane pomoću BBC kodova.';
$txt['manual_section_personal_messages_desc'] = 'Korisnici mogu slati privatne poruke jedni drugima.';
$txt['manual_section_memberlist_desc'] = 'Lista članova prikazuje listu svih registrovanih članova foruma.';
$txt['manual_section_calendar_desc'] = 'Korisnici mogu pratiti događaje, praznike i rođendane koji se nalaze u kalendaru.';
$txt['manual_section_features_desc'] = 'Here is a list of the most popular features in ElkArte.';