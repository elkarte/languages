<?php
// Version: 1.1; Admin

$txt['admin_boards'] = 'Forumi';
$txt['admin_back_to'] = 'Nazad u admin panel';
$txt['admin_users'] = 'Korisnici';
$txt['admin_newsletters'] = 'Infodopisi';
$txt['include_these'] = 'Members to include';
$txt['exclude_these'] = 'Members to exclude';
$txt['admin_newsletters_select_groups'] = 'Groups to include';
$txt['admin_newsletters_exclude_groups'] = 'Groups to exclude';
$txt['admin_edit_news'] = 'Novosti';
$txt['admin_groups'] = 'Korisničke grupe';
$txt['admin_members'] = 'Upravljanje članovima';
$txt['admin_members_list'] = 'Ispod je lista svih korisnika trenutno registrovanih na vašem forumu.';
$txt['admin_next'] = 'Sledeća';
$txt['admin_censored_words'] = 'Cenzurisane reči';
$txt['admin_censored_where'] = 'Dodajte reči koje treba da bude cenzurisane sa leve strane i reči koje treba da ih zamene sa desne. Onda izaberite da li želite da se se proverava čitava reč i velika i mala slova. Kada završite sa svakom rečju, kliknite sačuvaj. Više unosa reči pre čuvanja moguće je postići klikom na dugme \'Dodaj još jednu reč\'.';
$txt['admin_censored_desc'] = 'Zbog prirode foruma moguće je da želite zabraniti neke reči koje su napisali korisnici vašeg foruma. Možete uneti bilo koje reči ispod za koje želite da budu cenzurisane kada god su korišćene od strane korisnika.<br />Očistite prozor da izbrišete reč iz liste cenzura.';
$txt['admin_reserved_names'] = 'Rezervisana Imena';
$txt['admin_template_edit'] = 'Izmenite šablon(template) foruma';
$txt['admin_modifications'] = 'Podešavanja dodataka';
$txt['admin_security_moderation'] = 'Bezbednost i moderacija';
$txt['admin_server_settings'] = 'Sačuvaj podešavanja';
$txt['admin_reserved_set'] = 'Postavi rezervisana imena';
$txt['admin_reserved_line'] = 'Jedna rezervisana reč po liniji.';
$txt['admin_basic_settings'] = 'Ova stranica vam omogućava da promenite osnovna podešavanja vašeg foruma. Budite jako pažlivi sa ovim podešavanjima pošto mogu učiniti forum nefunkcionalnim.';
$txt['admin_maintain'] = 'Uključiti mod održavanja';
$txt['admin_title'] = 'Ime foruma';
$txt['admin_url'] = 'Url foruma';
$txt['cookie_name'] = 'Ime kolačića';
$txt['admin_webmaster_email'] = 'Email adresa webmastera';
$txt['boarddir'] = 'ElkArte folder';
$txt['sourcesdir'] = 'Sources folder';
$txt['cachedir'] = 'Cache folder';
$txt['admin_news'] = 'Omogući vesti';
$txt['admin_guest_post'] = 'Omoguci gostima slanje poruka';
$txt['admin_manage_members'] = 'Korisnici';
$txt['admin_main'] = 'Glavno';
$txt['admin_config'] = 'Podešavanje';
$txt['admin_version_check'] = 'Detaljna provera verzije';
$txt['admin_elkfile'] = 'ElkArte fajl';
$txt['admin_elkpackage'] = 'ElkArte Paket';
$txt['admin_logoff'] = 'Završi admin Session';
$txt['admin_maintenance'] = 'Održavanje';
$txt['admin_image_text'] = 'Prikazi dugmad kao slike umesto texta';
$txt['admin_credits'] = 'Zasluge';
$txt['admin_agreement'] = 'Prikaži i zahtevaj sporazum o registraciji pri registrovanju';
$txt['admin_checkbox_agreement'] = 'Prikaži polje za potvrdu o sporazumu o registraciji umesto čitave stranice';
$txt['admin_checkbox_accept_agreement'] = 'Force all members to accept this new version of the agreement at the next visit to the forum';
$txt['admin_agreement_default'] = 'Uobičajeno';
$txt['admin_agreement_select_language'] = 'Jezik za izmenu';
$txt['admin_agreement_select_language_change'] = 'Izmeni';

$txt['admin_privacypol'] = 'Show and require accepting the privacy policy when registering';
$txt['admin_checkbox_accept_privacypol'] = 'Force all members to accept this new version of the privacy policy at the next visit to the forum';

$txt['admin_delete_members'] = 'Izbiši Izabrane Korisnike';
$txt['admin_change_primary_membergroup'] = 'Change primary member group';
$txt['admin_change_secondary_membergroup'] = 'Change/add additional member group';
$txt['confirm_remove_membergroup'] = 'Selecting this all the membergroups will be removed! Are you sure?';
$txt['confirm_change_primary_membergroup'] = 'Are you sure you want to change the primary group of the selected members?';
$txt['confirm_change_secondary_membergroup'] = 'Are you sure you want to change the additional group of the selected members?';
$txt['admin_ban_usernames'] = 'Ban by usernames';
$txt['admin_ban_useremails'] = 'Ban by email addresses';
$txt['admin_ban_userips'] = 'Ban by IPs';
$txt['admin_ban_usernames_and_emails'] = 'Ban by usernames and email addresses';
$txt['admin_ban_name'] = 'Mass-user Ban';
$txt['remove_groups'] = 'Remove all groups';

$txt['admin_repair'] = 'Popravi Sve forume i teme';
$txt['admin_main_welcome'] = 'This is your &quot;%1$s&quot;.  From here, you can edit settings, maintain your forum, view logs, install packages, manage themes, and many other things.<br /><br />If you have any trouble, please look at the &quot;Support &amp; Credits&quot; page.  If the information there doesn\'t help you, feel free to <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">look to us for help</a> with the problem.<br />You may also find answers to your questions or problems by clicking the <i class="helpicon i-help"><s>Help</s></i> symbols for more information on the related functions.';
$txt['admin_news_desc'] = 'Molimo vas postavite jednu novost po prozoru. BBC tagovi, kao sto su <span>[b]</span>, <span>[i]</span> and <span>[u]</span> su dozvoljeni u vašim novostima, kao i smajliji. Ocistite text novosti da bi novost izbrisali.';
$txt['administrators'] = 'Forum Administratori';
$txt['admin_reserved_desc'] = 'Rezervisana imena će sprečiti korisnike od registrovanja korisničkih imena ili korišćenja ovih reči u nihovim prikazanim imenima. Izaberite opcije pri dnu koje želite da koristite pre sačuvavanja.';
$txt['admin_activation_email'] = 'Pošalji aktivacioni email novim korisnicima prilikom registracije';
$txt['admin_match_whole'] = 'Poklapaj samo celo ime. Ukoliko je neobeleženo, pretražiće se i unutar imena.';
$txt['admin_match_case'] = 'Poklopi velika i mala slova. Ukoliko je neobeleženo, pretraga neće biti osetliva na velika i mala slova';
$txt['admin_check_user'] = 'Proveri korisničko ime.';
$txt['admin_check_display'] = 'Proveri prikazano ime.';
$txt['admin_newsletter_send'] = 'You can email anyone from this page. The email addresses of the selected member groups should appear below, but you may remove or add any email addresses you wish. Be sure that each address is separated in this fashion: \'address1; address2\'.';
$txt['admin_fader_delay'] = 'Vreme za prikazivanje svake stavke u pretapaču vesti';
$txt['zero_for_no_limit'] = '(0 za neograničeno)';
$txt['zero_to_disable'] = '(0 to disable)';

$txt['admin_backup_fail'] = 'Nisam mogao da napravim rezervnu kopiju datoteke Settings.php - uverite se da datoteka Settings_bak.php postoji i da je otvorena za pisanje.';
$txt['modSettings_info'] = 'Settings for General features, Karma, Signatures, Likes and much more that control how this forum operates.';
$txt['database_server'] = 'Server baze podataka';
$txt['database_user'] = 'Database User';
$txt['database_password'] = 'Lozinka baze';
$txt['database_name'] = 'Ime baze';
$txt['registration_agreement'] = 'Sporazum o registraciji';
$txt['registration_agreement_desc'] = 'Ovaj sporazum se prikazuje kada korisnik registruje nalog na ovom forumu i mora da bude prihvaćen pre registracije.';
$txt['privacy_policy'] = 'Privacy Policy';
$txt['privacy_policy_desc'] = 'This privacy policy is shown when a user registers an account on this forum and can be made mandatory before users can continue registration.';
$txt['database_prefix'] = 'Prefiks tabela u bazi podataka';
$txt['errors_list'] = 'Spisak grešaka na foruma';
$txt['errors_found'] = 'Sledeće greške se provlače kroz forum';
$txt['errors_fix'] = 'Da li želite da pokušam da popravim ove greške?';
$txt['errors_do_recount'] = 'All errors have been fixed and a salvage area has been created. Please click the button below to recount some key statistics.';
$txt['errors_recount_now'] = 'Prebroj statistiku';
$txt['errors_fixing'] = 'Popravljam greške na forumu';
$txt['errors_fixed'] = 'All errors fixed. Please check on any categories, boards, or topics created to decide what to do with them.';
$txt['attachments_avatars'] = 'Priložene datoteke i avatari';
$txt['attachments_desc'] = 'Odavde možete da administrirate priložene datoteke na vašem sistemu. Možete da obrišete priložene datoteke prema veličini i datumu sa vašeg sistema. Ispod je prikazana i statistika priloženih datoteka.';
$txt['attachment_stats'] = 'File attachment statistics';
$txt['attachment_integrity_check'] = 'Attachment integrity check';
$txt['attachment_integrity_check_desc'] = 'Ova funkcija će proveriti integritet vaših priloženih datoteka i naziva fajlova u bazi, i ukoliko je potrebno popraviće greške koje se pronađu.';
$txt['attachment_check_now'] = 'Pokreni proveru sada';
$txt['attachment_pruning'] = 'Brisanje starih priloženih datoteka';
$txt['attachment_pruning_message'] = 'Poruka za dodavanje u post';
$txt['attachment_pruning_warning'] = 'Jeste li sigurni da želite da obrišete ove priložene datoteke? Ukoliko ih izbrišete ne mogu biti naknadno vraćene!';

$txt['attachment_total'] = 'Total attachments';
$txt['attachmentdir_size'] = 'Total size of all attachment directories';
$txt['attachmentdir_size_current'] = 'Total size of current attachment directory';
$txt['attachmentdir_files_current'] = 'Total files in current attachment directory';
$txt['attachment_space'] = 'Total space available';
$txt['attachment_files'] = 'Total files remaining';

$txt['attachment_options'] = 'Opcije priloženih datoteka';
$txt['attachment_log'] = 'Dnevnik priloženih datoteka';
$txt['attachment_remove_old'] = 'Remove attachments older than %1$s days';
$txt['attachment_remove_size'] = 'Remove attachments larger than %1$s KiB';
$txt['attachment_name'] = 'Attachment name';
$txt['attachment_file_size'] = 'Veličina datoteke';
$txt['attachmentdir_size_not_set'] = 'Trenutno nije postavljena maksimalna veličina direktorijuma priloženih datoteka';
$txt['attachmentdir_files_not_set'] = 'No directory file limit is currently set';
$txt['attachment_delete_admin'] = '[priloženu datoteku obrisao administrator]';
$txt['live'] = 'Latest Software Updates';
$txt['remove_all'] = 'Clear Log';
$txt['agreement_not_writable'] = 'Warning - agreement.txt is not writable. Any changes you make will NOT be saved.';
$txt['agreement_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';
$txt['privacypol_not_writable'] = 'Warning - privacypolicy.txt is not writable. Any changes you make will NOT be saved.';
$txt['privacypol_backup_not_writable'] = 'Warning - the backup directory in forum_root/packages/backup cannot be created.';

$txt['version_check_desc'] = 'This shows you the versions of your installation\'s files versus those of the latest version. If any of these files are out of date, you should download and upgrade to the latest version at our <a href="https://github.com/elkarte/Elkarte/releases" target="_blank" class="new_win">ElkArte Site</a>.';
$txt['version_check_more'] = '(detaljnije)';

$txt['lfyi'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['manage_calendar'] = 'Kalendar';
$txt['manage_search'] = 'Pretraga';
$txt['viewmembers_online'] = 'Zadnji put prisutan';

$txt['smileys_manage'] = 'Smajliji i slike poruka';
$txt['smileys_manage_info'] = 'Install new smiley sets, add smileys to existing sets or manage your message icons.';

$txt['bbc_manage'] = 'Bulletin Board Codes (BBC)';
$txt['bbc_manage_info'] = 'Add, remove, and edit bulletin board codes.';

$txt['package_info'] = 'Install, download and upload Modification packages; check File Permissions and FTP settings.';
$txt['theme_admin'] = 'Theme Management';
$txt['theme_admin_info'] = 'Install new themes, select themes that are available for your users and set or reset theme options.';
$txt['registration_center'] = 'Registracije';
$txt['member_center_info'] = 'View the member list, search for members, or manage account approvals and activations.';
$txt['viewmembers_online'] = 'Zadnji put prisutan';

$txt['display_name'] = 'Prikazano ime';
$txt['email_address'] = 'Imejl adresa';
$txt['ip_address'] = 'IP adresa';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'nepoznato';
$txt['security_wrong'] = 'Administration login attempt!
Referer: %1$s
User agent: %2$s
IP: %3$s';

$txt['email_as_html'] = 'Pošalji u HTML formatu.  (sa ovim možete da koristite normalni HTML u imejlu.)';
$txt['email_parsed_html'] = 'Dodaj &lt;br /&gt; i &amp;nbsp; gde je potrebno ovoj poruci.';
$txt['email_variables'] = 'In this message you can use a few &quot;variables&quot;.<a href="{help_emailmembers}" class="help"> Click here for more information</a>.';
$txt['email_force'] = 'Pošalji ovo i članovima koji su odabrali da ne primaju obaveštenja.';
$txt['email_as_pms'] = 'Pošalji ovo ovim grupama koristeći privatne poruke.';
$txt['email_continue'] = 'Nastavi';
$txt['email_done'] = 'završeno.';
$txt['email_members_succeeded'] = 'You have successfully sent your newsletter!';

$txt['ban_title'] = 'Spisak zabrana';
$txt['ban_ip'] = 'IP zabrana: (na pr. 192.168.12.213 ili 128.0.*.*) - jedan unos po liniji';
$txt['ban_email'] = 'Imejl zabrana: (na pr. haker@negde-tamo.com) - jedan unos po liniji';
$txt['ban_username'] = 'Zabrana korisničkog imena: (na pr. l33tuser) - jedan unos po liniji';

$txt['ban_errors_detected'] = 'The following error or errors occurred while saving or editing the ban or the trigger';
$txt['ban_description'] = 'Here you can ban troublesome people either by IP, hostname, user name, or email.';
$txt['ban_add_new'] = 'Add new ban';
$txt['ban_banned_entity'] = 'Zabranjen opseg';
$txt['ban_on_ip'] = 'Zabrana na osnovu IP adrese (na pr. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Zabrana na osnovu imena domaćina (na pr. *.mil)';
$txt['ban_on_email'] = 'Zabrana na osnovu imejl adrese (na pr. *@los-sajt.com)';
$txt['ban_on_username'] = 'Ban on User Name';
$txt['ban_notes'] = 'Beleške';
$txt['ban_restriction'] = 'Zabrana';
$txt['ban_full_ban'] = 'Puna zabrana';
$txt['ban_partial_ban'] = 'Delimična zabrana';
$txt['ban_cannot_post'] = 'Ne može da šalje poruke';
$txt['ban_cannot_register'] = 'Ne može da se registruje';
$txt['ban_cannot_login'] = 'Ne može da se prijavi';
$txt['ban_add'] = 'Dodaj';
$txt['ban_edit_list'] = 'Spisak zabrana';
$txt['ban_type'] = 'Tip zabrane';
$txt['ban_days'] = 'dan(a)';
$txt['ban_will_expire_within'] = 'Zabrana će isteći posle';
$txt['ban_added'] = 'Dodata';
$txt['ban_expires'] = 'Ističe';
$txt['ban_hits'] = 'Pokušaja';
$txt['ban_actions'] = 'Akcije';
$txt['ban_expiration'] = 'Ističe';
$txt['ban_reason_desc'] = 'Razlog za zabranu koji će biti prikazan zabranjenim članovima.';
$txt['ban_notes_desc'] = 'Beleške koje mogu da pomognu ostalom osoblju.';
$txt['ban_remove_selected'] = 'Ukloni izabrano';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Da li ste sigurni da želite da uklonite izabrane zabrane?';
$txt['ban_modify'] = 'Izmeni';
$txt['ban_name'] = 'Ime zabrane';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Izmeni zabranu';
$txt['ban_add_notes'] = '<strong>Napomena</strong>: nakon kreiranja ove zabrane, moći ćete da dodate dodatne unose koji će okinuti zabranu kao što su IP adrese, imena domaćina i imejl adrese.';
$txt['ban_expired'] = 'Istekla / onemogućena';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Nije izabrana nijedna zabrana.';

$txt['ban_triggers'] = 'Okidači';
$txt['ban_add_trigger'] = 'Dodaj okidač zabrane';
$txt['ban_add_trigger_submit'] = 'Dodaj';
$txt['ban_edit_trigger'] = 'Izmeni';
$txt['ban_edit_trigger_title'] = 'Izmeni okidač zabrane';
$txt['ban_edit_trigger_submit'] = 'Izmeni';
$txt['ban_remove_selected_triggers'] = 'Ukloni izabrane okidače zabrana';
$txt['ban_no_entries'] = 'Trenutno ne postoje zabrane na snazi.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Da li ste sigurni da želite da uklonite izabrane okidače zabrana?';
$txt['ban_trigger_browse'] = 'Pregledaj okidače zabrana';
$txt['ban_trigger_browse_description'] = 'This screen shows all banned entities grouped by IP address, hostname, email address and user name.';

$txt['ban_log'] = 'Dnevnik zabrana';
$txt['ban_log_description'] = 'Ovaj dnevnik zabrana prikazuje sve pokušaje pristupa forumu od strane zabranjenih korisnika (prikazane su samo \'puna zabrana\' i \'zabrana registrovanja\').';
$txt['ban_log_no_entries'] = 'Trenutno nema zapisa u dnevniku zabrana.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'Imejl adresa';
$txt['ban_log_member'] = 'Član';
$txt['ban_log_date'] = 'Datum';
$txt['ban_log_remove_all'] = 'Clear Log';
$txt['ban_log_remove_all_confirm'] = 'Da li ste sigurni da želite da obrišete sve zapise iz dnevnika zabrana?';
$txt['ban_log_remove_selected'] = 'Ukloni izabrano';
$txt['ban_log_remove_selected_confirm'] = 'Da li ste sigurni da želite da obrišete sve izabrane zapise iz dnevnika zabrana?';
$txt['ban_no_triggers'] = 'Nema okidača zabrana.';

$txt['settings_not_writable'] = 'Ova podešavanja ne mogu da se promene jer je Settings.php podešen na samo za čitanje.';

$txt['maintain_title'] = 'Održavanje foruma';
$txt['maintain_info'] = 'Basic forum backups, Database error checking, Clearing the Cache, Integration Hooks and more.';
$txt['maintain_sub_database'] = 'Baza podataka';
$txt['maintain_sub_routine'] = 'Rutina';
$txt['maintain_sub_members'] = 'Korisnici';
$txt['maintain_sub_topics'] = 'Teme';
$txt['maintain_sub_attachments'] = 'Priložene datoteke';
$txt['maintain_done'] = 'Zadatak \'%1$s\' je uspešno završen.';
$txt['maintain_fail'] = 'The maintenance task \'%1$s\' failed.';
$txt['maintain_no_errors'] = 'Congratulations, no errors were found.  Thanks for checking.';

$txt['maintain_tasks'] = 'Planirani zadaci';
$txt['maintain_tasks_desc'] = 'Manage all the scheduled tasks.';

$txt['scheduled_log'] = 'Dnevnik zadataka';
$txt['scheduled_log_desc'] = 'Lists logs of the tasks that were run.';
$txt['admin_log'] = 'Dnevnik administriranja';
$txt['admin_log_desc'] = 'Prikazuje postupke administratora vašeg foruma.';
$txt['moderation_log'] = 'Dnevnik uređivanja';
$txt['moderation_log_desc'] = 'Prikazuje postupke urednika vašeg foruma.';
$txt['badbehavior_log'] = 'Bad Behavior Log';
$txt['badbehavior_log_desc'] = 'Lists requests that were blocked or marked suspicious by bad behavior.  If verbose logging is on all HTTP requests are listed.';
$txt['spider_log_desc'] = 'Pregled unosa vezanih za aktivnosti pretraživačkih paukova  na vašem forumu. ';
$txt['pruning_log_desc'] = 'Koristi ove alatke za potkresivanje starijih unosa u raznim evidencijama. ';

$txt['mailqueue_title'] = 'Pošta';

$txt['db_error_send'] = 'Šalji mejlove pri MySQL greškama pri povezivanju';
$txt['db_persist'] = 'Koristi trajnu vezu';
$txt['ssi_db_user'] = 'Database user name to use in SSI mode';
$txt['ssi_db_passwd'] = 'Lozinka baze za korišćenje u SSI modu';

$txt['default_language'] = 'Default forum language';

$txt['maintenance_subject'] = 'Naslov za prikazivanje';
$txt['maintenance_message'] = 'Poruka za prikazivanje';

$txt['errlog_desc'] = 'Dnevnik grešaka prati sve greške na ovom forumu. Da biste obrisali greške iz baze podataka, označite polje za potvrdu i kliknite dugme %s pri dnu stranice.';
$txt['errlog_no_entries'] = 'Trenutno ne postoje zapisi grešaka.';

$txt['theme_settings'] = 'Podešavanja teme';
$txt['theme_edit_settings'] = 'Edit this theme\'s settings';
$txt['theme_current_settings'] = 'Trenutna tema';

$txt['dvc_your'] = 'Vaša verzija';
$txt['dvc_current'] = 'Trenutna verzija';
$txt['dvc_sources'] = 'Izvori';
$txt['dvc_admin'] = 'Administracija';
$txt['dvc_controllers'] = 'Controllers';
$txt['dvc_database'] = 'Baza podataka';
$txt['dvc_subs'] = 'Subs';
$txt['dvc_default'] = 'Podrazumevani predlošci';
$txt['dvc_templates'] = 'Trenutni predlošci';
$txt['dvc_languages'] = 'Jezičke datoteke';

$txt['smileys_default_set_for_theme'] = 'Select default smiley set for this theme:';
$txt['smileys_no_default'] = 'Use default smiley set';

$txt['censor_test'] = 'Testirajte cenzuru reči';
$txt['censor_test_save'] = 'Test';
$txt['censor_case'] = 'Ignore case when censoring.';
$txt['censor_whole_words'] = 'Check only whole words.';
$txt['censor_allow'] = 'Allow users to turn off word censoring.';

$txt['admin_confirm_password'] = '(confirm password)';
$txt['admin_incorrect_password'] = 'Pogrešna lozinka';

$txt['date_format'] = '(GGGG-MM-DD)';
$txt['undefined_gender'] = 'Neodređeno';
$txt['age'] = 'Starost korisnika';
$txt['activation_status'] = 'Aktivacioni status';
$txt['activated'] = 'Aktiviran';
$txt['not_activated'] = 'Nije aktiviran';
$txt['is_banned'] = 'Banned';
$txt['primary'] = 'Primarno';
$txt['additional'] = 'Dodatno';
$txt['wild_cards_allowed'] = 'džokeri * i ? su dozvoljeni';
$txt['member_part_of_these_membergroups'] = 'Member is part of these member groups';
$txt['membergroups'] = 'Korisničke grupe';
$txt['confirm_delete_members'] = 'Da li ste sigurni da želite da obrišete izabrane članove?';

$txt['support_credits_title'] = 'Support &amp; Credits';
$txt['support_credits_info'] = 'Support links for most common issues, the relevant forum version information you will be asked for when you request help and a list of contributors to the ElkArte project.';
$txt['support_title'] = 'Informacije o podršci';
$txt['support_versions_current'] = 'Current version';
$txt['support_versions_forum'] = 'This version';
$txt['support_versions_db'] = '%1$s verzija';
$txt['support_versions_server'] = 'Verzija servera';
$txt['support_versions_gd'] = 'Verzija GD-a';
$txt['support_versions_imagick'] = 'Imagick version';
$txt['support_versions'] = 'Informacije o verzijama';
$txt['support_resources'] = 'Izvori Podrške';
$txt['support_resources_p1'] = 'Our <a href="%1$s" target="_blank" class="new_win">Documentation Wiki</a> provides the main documentation for ElkArte. The ElkArte Online Manual has many documents to help answer support questions and explain <a href="%2$s" target="_blank" class="new_win">Features</a>, <a href="%3$s" target="_blank" class="new_win">Settings</a>, <a href="%4$s" target="_blank" class="new_win">Themes</a>, <a href="%5$s" target="_blank" class="new_win">Packages</a>, etc. The Online Manual documents each area of ElkArte thoroughly and should answer most questions quickly.';
$txt['support_resources_p2'] = 'If you can\'t find the answers to your questions in the Documentation Wiki, you may want to search our <a href="%1$s" target="_blank" class="new_win">Support Community</a> or ask for assistance in our support boards. The ElkArte Support Community can be used for <a href="%2$s" target="_blank" class="new_win">support</a>, <a href="%3$s" target="_blank" class="new_win">customization</a>, and many other things such as discussing ElkArte, finding a host, and discussing administrative issues with other forum administrators.';

$txt['latest_updates'] = 'Latest noteworthy updates';
$txt['new_in_1_0_2'] = 'The most significant change in ElkArte 1.0.2 is avatar permission management. Currently each method of setting an avatar is permission-based, requiring the enabling/disabling of each method for each group. With 1.0.2 avatars are simply enabled/disabled by user group, this allows the enabled groups to add an avatar (by all available methods).<br />
The only permission available is a general one to allow members to change or not their avatars. Additionally there is only one setting for maximum width and height of avatars, these values apply to all avatar methods.<br /><br />
Due to the nature of the changes it was not impossible to migrate existing settings to the new format, for that reason you are encouraged to visit the <a href="{admin_url};area=manageattachments;sa=avatars">Avatar Settings</a> page and set the options you prefer.';

$txt['edit_permissions_info'] = 'Use permission settings to manage global and specific board features and what actions that guest, members and moderators can do.';
$txt['membergroups_members'] = 'Negrupisani članovi';
$txt['membergroups_guests'] = 'Gosti';
$txt['membergroups_add_group'] = 'Dodaj grupu';
$txt['membergroups_permissions'] = 'Dozvole';

$txt['permitgroups_restrict'] = 'Ograničene';
$txt['permitgroups_standard'] = 'Uobičajene';
$txt['permitgroups_moderator'] = 'Uredničke';
$txt['permitgroups_maintenance'] = 'Održavanje';

$txt['confirm_delete_attachments'] = 'Da li ste sigurni da želite da obrišete izabrane priložene datoteke?';
$txt['attachment_manager_browse_files'] = 'Pregledaj datoteke';
$txt['attachment_manager_repair'] = 'Održavanje';
$txt['attachment_manager_avatars'] = 'Avatari';
$txt['attachment_manager_attachments'] = 'Priložene datoteke';
$txt['attachment_manager_thumbs'] = 'Sličice';
$txt['attachment_manager_last_active'] = 'Poslednji put aktivan';
$txt['attachment_manager_member'] = 'Član';
$txt['attachment_manager_avatars_older'] = 'Remove avatars from members not active for more than %1$s days';
$txt['attachment_manager_total_avatars'] = 'Total avatars';

$txt['attachment_manager_avatars_no_entries'] = 'Trenutno nema avatara.';
$txt['attachment_manager_attachments_no_entries'] = 'Trenutno nema priloženih datoteka.';
$txt['attachment_manager_thumbs_no_entries'] = 'Trenutno nema umanjenih prikaza.';

$txt['attachment_manager_settings'] = 'Podešavanja priloženih datoteka';
$txt['attachment_manager_avatar_settings'] = 'Podešavanja avatara';
$txt['attachment_manager_browse'] = 'Pregledaj datoteke';
$txt['attachment_manager_maintenance'] = 'Održavanje datoteka';
$txt['attachmentEnable'] = 'Priložene datoteke';
$txt['attachmentEnable_deactivate'] = 'Onemogući priložene datoteke';
$txt['attachmentEnable_enable_all'] = 'Omogući sve priložene datoteke';
$txt['attachmentEnable_disable_new'] = 'Onemogući nove priložene datoteke';
$txt['attachmentCheckExtensions'] = 'Proveri ekstenziju priloženih datoteka';
$txt['attachmentExtensions'] = 'Dozvoljene ekstenzije priloženih datoteka';
$txt['attachmentRecodeLineEndings'] = 'Rekodiraj završne linije u tekstualnim prilozima.';
$txt['attachmentShowImages'] = 'Prikaži slike priloženih datoteka ispod poruka';
$txt['attachmentUploadDir'] = 'Direktorijum priloženih datoteka';
$txt['attachmentUploadDir_multiple_configure'] = 'Manage attachment directories';
$txt['attachmentDirSizeLimit'] = 'Max attachment directory space';
$txt['attachmentPostLimit'] = 'Max attachment size per post';
$txt['attachmentSizeLimit'] = 'Max size per attachment';
$txt['attachmentNumPerPostLimit'] = 'Max number of attachments per post';
$txt['attachment_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Image re-encoding is not possible.';
$txt['attachment_postsize_warning'] = 'The current php.ini setting \'post_max_size\' may not support this.';
$txt['attachment_filesize_warning'] = 'The current php.ini setting \'upload_max_filesize\' may not support this.';
$txt['attachment_image_reencode'] = 'Prešifriraj potencijalno opasne slikovne priložene datoteke';
$txt['attachment_image_reencode_note'] = '(requires GD module or ImageMagick)';
$txt['attachment_image_paranoid_warning'] = 'Opsežne bezbednosne provere mogu rezultirati velikim brojem odbačenih priloga.';
$txt['attachment_image_paranoid'] = 'Obavlja jaku sigurnosnu proveru priloženih datoteka.';
$txt['attachment_autorotate'] = 'Detect and fix improperly rotated images';
$txt['attachment_autorotate_na'] = '(Not available on this system)';
$txt['attachmentThumbnails'] = 'Promeni veličinu slikama pri prikazivanju ispod poruke';
$txt['attachment_thumb_png'] = 'Sačuvaj umanjene slike kao PNG';
$txt['attachment_thumb_memory'] = 'Adaptive thumbnail memory';
$txt['attachment_thumb_memory_note2'] = 'If the system can not get the memory no thumbnail will be created.';
$txt['attachment_thumb_memory_note1'] = 'Leave this unchecked to always attempt to create a thumbnail';
$txt['attachmentThumbWidth'] = 'Najveća širina sličica';
$txt['attachmentThumbHeight'] = 'Najveća visina sličica';
$txt['attachment_thumbnail_settings'] = 'Thumbnail Settings';
$txt['attachment_security_settings'] = 'Attachment security settings';

$txt['attachment_inline_title'] = 'Inline attachment settings';
$txt['attachment_inline_enabled'] = 'Enable the display of in line attachments';
$txt['attachment_inline_basicmenu'] = 'Only show basic menu';
$txt['attachment_inline_quotes'] = 'Check to enable display of in line attachments in quotes';

$txt['attach_dir_does_not_exist'] = 'ne postoji';
$txt['attach_dir_not_writable'] = 'Nije otvoreno za upisivanje';
$txt['attach_dir_files_missing'] = 'Files Missing (<a href="{repair_url}">Repair</a>)';
$txt['attach_dir_unused'] = 'nekorišćeno';
$txt['attach_dir_empty'] = 'Empty';
$txt['attach_dir_ok'] = 'u redu';
$txt['attach_dir_basedir'] = 'Base directory';

$txt['attach_dir_desc'] = 'Create new directories or change the current directory below. Directories can be renamed as long as they do not contain a sub-directory. If the new directory is to be created within the forum directory structure, you\'ll just need to type the directory name. To remove a directory, blank the path input field. Directories can not be deleted if they contain either files or sub-directories (shown in brackets next to the file count).';
$txt['attach_dir_base_desc'] = 'You may use the area below to change the current base directory or create a new one. New base directories are also added to the Attachment Directory list. You may also designate an existing directory to be a base directory.';
$txt['attach_dir_save_problem'] = 'Oops, there seems to be a problem.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory. Please do so using a FTP client or your site file manager.';
$txt['attachments_no_write'] = 'This directory has been created but is not writable. Please attempt to do so using a FTP client or your site file manager.';
$txt['attach_dir_reserved'] = 'Unable to add. This directory is a system directory and cannot be used for attachments.';
$txt['attach_dir_duplicate_msg'] = 'Unable to add. This directory already exists.';
$txt['attach_dir_exists_msg'] = 'Unable to move. A directory already exists at that path.';
$txt['attach_dir_base_dupe_msg'] = 'Unable to add. This base directory has already been created.';
$txt['attach_dir_base_no_create'] = 'Unable to create. Please verify the path input or create this directory using an FTP client or site file manager and re-try.';
$txt['attach_dir_no_rename'] = 'Unable to move or rename. Please verify that the path is correct or that this directory does not contain any sub-directories.';
$txt['attach_dir_no_delete'] = 'Is not empty and can not be deleted. Please do so using a FTP client or site file manager.';
$txt['attach_dir_no_remove'] = 'Still contains files or is a base directory and can not be deleted.';
$txt['attach_dir_is_current'] = 'Unable to remove while it is selected as the current directory.';
$txt['attach_dir_is_current_bd'] = 'Unable to remove while it is selected as the current base directory.';
$txt['attach_last_dir'] = 'Last active attachment directory';
$txt['attach_current_dir'] = 'Current attachment directory';
$txt['attach_current'] = 'Current';
$txt['attach_path_manage'] = 'Manage attachment paths';
$txt['attach_directories'] = 'Attachment Directories';
$txt['attach_paths'] = 'Attachment directory paths';
$txt['attach_path'] = 'Putanja';
$txt['attach_current_size'] = 'Size (KiB)';
$txt['attach_num_files'] = 'Datoteka';
$txt['attach_dir_status'] = 'Status';
$txt['attach_add_path'] = 'Dodaj putanju';
$txt['attach_path_current_bad'] = 'Trenutna putanja priloženih datoteka nije ispravna.';
$txt['attachmentDirFileLimit'] = 'Maximum number of files per directory';

$txt['attach_base_paths'] = 'Base directory paths';
$txt['attach_num_dirs'] = 'Directories';
$txt['max_image_width'] = 'Max display width of posted or attached images';
$txt['max_image_height'] = 'Max display height of posted or attached images';

$txt['automanage_attachments'] = 'Choose the method for the management of the attachment directories';
$txt['attachments_normal'] = '(Manual) ElkArte default behaviour';
$txt['attachments_auto_years'] = '(Auto) Subdivide by years';
$txt['attachments_auto_months'] = '(Auto) Subdivide by years and months';
$txt['attachments_auto_days'] = '(Auto) Subdivide by years, months and days';
$txt['attachments_auto_16'] = '(Auto) 16 random directories';
$txt['attachments_auto_16x16'] = '(Auto) 16 random directories with 16 random sub-directories';
$txt['attachments_auto_space'] = '(Auto) When either directory space limit is reached';

$txt['use_subdirectories_for_attachments'] = 'Create new directories within a base directory';
$txt['use_subdirectories_for_attachments_note'] = 'Otherwise any new directories will be created within the forum\'s main directory.';
$txt['basedirectory_for_attachments'] = 'Set a base directory for attachments';
$txt['basedirectory_for_attachments_current'] = 'Current base directory';
$txt['basedirectory_for_attachments_warning'] = '<div class="smalltext">Please note that the directory is wrong. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';
$txt['attach_current_dir_warning'] = '<div class="smalltext">There seems to be a problem with this directory. <br />(<a href="{attach_repair_url}">Attempt to correct</a>)</div>';

$txt['attachment_transfer'] = 'Transfer Attachments';
$txt['attachment_transfer_desc'] = 'Transfer files between directories.';
$txt['attachment_transfer_select'] = 'Select directory';
$txt['attachment_transfer_now'] = 'Transfer';
$txt['attachment_transfer_from'] = 'Transfer files from';
$txt['attachment_transfer_auto'] = 'Move them automatically by space or file count';
$txt['attachment_transfer_auto_select'] = 'Select base directory';
$txt['attachment_transfer_to'] = 'Or move them to a specific directory.';
$txt['attachment_transfer_empty'] = 'Move all files from the source directory.';
$txt['attachment_transfer_no_base'] = 'No base directories available.';
$txt['attachment_transfer_forum_root'] = 'Forum root directory.';
$txt['attachment_transfer_no_room'] = 'Directory size or file count limit reached.';
$txt['attachment_transfer_no_find'] = 'No files were found to transfer.';
$txt['attachments_transfered'] = '%1$d files were transferred to %2$s';
$txt['attachments_not_transfered'] = '%1$d files were not transferred.';
$txt['attachment_transfer_no_dir'] = 'Either the source directory or one of the target options were not selected.';
$txt['attachment_transfer_same_dir'] = 'You cannot select the same directory as both the source and target.';
$txt['attachment_transfer_progress'] = 'Please wait. Transfer in progress.';

$txt['avatar_settings'] = 'General avatar settings';
$txt['avatar_default'] = 'Enable a default avatar for all users without their own avatar';
$txt['avatar_directory'] = 'Direktorijum avatara';
$txt['avatar_url'] = 'URL avatara';
$txt['avatar_max_width'] = 'Maximum width of avatars in pixels (px)';
$txt['avatar_max_height'] = 'Maximum height of avatars in pixels (px)';
$txt['avatar_action_too_large'] = 'Ako je avatar prevelik...';
$txt['option_refuse'] = 'Odbij ga';
$txt['option_resize'] = 'Let the CSS resize it';
$txt['option_download_and_resize'] = 'Download and resize it (requires GD module or ImageMagick)';
$txt['gravatar'] = 'Gravatars';
$txt['avatar_gravatar_enabled'] = 'Enable use of gravatars';
$txt['gravatar_rating'] = 'Gravatar Rating';
$txt['avatar_download_png'] = 'Koristi PNG za smanjene avatare';
$txt['avatar_img_enc_warning'] = 'Neither the GD module nor ImageMagick are currently installed. Some avatar features are disabled.';
$txt['avatar_external'] = 'Spoljašnji avatari';
$txt['avatar_external_enabled'] = 'Enable use of external (remote/URL) avatars';
$txt['avatar_upload'] = 'Dostavljeni avatari';
$txt['avatar_resize_options'] = 'Server storage options';
$txt['avatar_upload_enabled'] = 'Enable the upload of avatars';
$txt['avatar_server_stored'] = 'Avatari uskladišteni na serveru';
$txt['avatar_stored_enabled'] = 'Enable the selection of server stored avatars';
$txt['profile_set_avatar'] = 'Member groups allowed to select an avatar';
$txt['avatar_select_permission'] = 'Izaberite dozvole za svaku grupu';
$txt['avatar_download_external'] = 'Preuzmi avatar sa datog URL-a';
$txt['custom_avatar_enabled'] = 'Dostavi avatare u...';
$txt['option_attachment_dir'] = 'Direktorijum priloženih datoteka';
$txt['option_specified_dir'] = 'Poseban direktorijum...';
$txt['custom_avatar_dir'] = 'Direktorijum za dostavu';
$txt['custom_avatar_dir_desc'] = 'This should be a valid and writable directory, different than the server-stored directory.';
$txt['custom_avatar_url'] = 'URL za dostavljanje';
$txt['custom_avatar_check_empty'] = 'Prilagođeni avatar direktorijum koji ste naveli je možda prazan ili nevažeći.Molimo vas da proverite jesu li postavke ispravne.';
$txt['avatar_reencode'] = 'Rekodiraj potencijalno opasne avatare';
$txt['avatar_reencode_note'] = '(zahteva GD modul)';
$txt['avatar_paranoid_warning'] = 'Opsežna bezbednosna provera, može rezultirati velikim brojem odbačenih avatara.';
$txt['avatar_paranoid'] = 'Obavlja jaku sigurnosnu proveru priloženih avatara';

$txt['repair_attachments'] = 'Održavanje priloženih datoteka';
$txt['repair_attachments_complete'] = 'Održavanje završeno.';
$txt['repair_attachments_complete_desc'] = 'Sve izabrane greške su sada ispravljene';
$txt['repair_attachments_no_errors'] = 'No errors were found';
$txt['repair_attachments_error_desc'] = 'Sledeće greške su pronađene prilikom održavanja. Označite kutiju pored grešaka koje želite da ispravite i kliknite nastavi.';
$txt['repair_attachments_continue'] = 'Nastavi';
$txt['repair_attachments_cancel'] = 'Otkaži';
$txt['attach_repair_missing_thumbnail_parent'] = '%1$d sličice nemaju roditeljsku priloženu datoteku';
$txt['attach_repair_parent_missing_thumbnail'] = '%1$d roditelja je označeno kao da imaju sličice a nemaju';
$txt['attach_repair_file_missing_on_disk'] = '%1$d priloženih datoteka/avatara ima unos ali više ne postoje na disku';
$txt['attach_repair_file_wrong_size'] = '%1$d priloženih datoteka/avatara ima loše prijavljenu veličinu datoteke';
$txt['attach_repair_file_size_of_zero'] = '%1$d priloženih datoteka/avatara su veličine nula na disku. (Biće obrisani)';
$txt['attach_repair_attachment_no_msg'] = '%1$d priloženih datoteka više nema poruku sa kojom su povezani';
$txt['attach_repair_avatar_no_member'] = '%1$d avatara više nema člana sa kojim su povezani';
$txt['attach_repair_wrong_folder'] = '%1$d attachments are in the wrong directory';
$txt['attach_repair_missing_extension'] = '%1$d attachments do not have the proper extension and may be in the wrong directory';
$txt['attach_repair_files_without_attachment'] = '%1$d files do not have a corresponding entry in the database. (These will be deleted)';

$txt['news_title'] = 'Vesti i infodopisi';
$txt['news_settings_desc'] = 'Ovde možete da promenite podešavanja i dozvole vezane za vesti i liste za e-poštu.';
$txt['news_mailing_desc'] = 'From this menu you can send messages to all users who\'ve registered and entered their email addresses. You may edit the distribution list, or send messages to all. Useful for important update/news information.';
$txt['news_error_no_news'] = 'Nothing to preview';
$txt['groups_edit_news'] = 'Grupe kojima je dozvoljeno da uređuju vesti';
$txt['groups_send_mail'] = 'Grupe kojima je dozvoljeno da šalju infodopise';
$txt['xmlnews_enable'] = 'Omogućiti XML/RSS vesti';
$txt['xmlnews_maxlen'] = 'Maximum message length';
$txt['xmlnews_limit'] = 'XML/RSS Limit';
$txt['xmlnews_limit_note'] = 'Number of items in a news feed';
$txt['xmlnews_maxlen_note'] = '(0 to disable, bad idea.)';
$txt['editnews_clickadd'] = 'Add another item';
$txt['editnews_remove_selected'] = 'Ukloni izabrano';
$txt['editnews_remove_confirm'] = 'Da li ste sigurni da želite da obrišete izabrane stavke vesti?';
$txt['censor_clickadd'] = 'Add another word';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Dnevnici';
$txt['generate_reports'] = 'Napravi izveštaje';

$txt['update_available'] = 'Update Available';
$txt['update_message'] = 'You\'re using an outdated version of ElkArte, which contains some bugs which have since been fixed.
	It is recommended that you <a href="#" id="update-link">update your forum</a> to the latest version as soon as possible. It only takes a minute!';

$txt['manageposts'] = 'Poruke i teme';
$txt['manageposts_title'] = 'Upravljanje porukama i temama';
$txt['manageposts_description'] = 'Ovde možete da upravljate podešavanjima vezanim za teme i poruke.';

$txt['manageposts_seconds'] = 'sekundi';
$txt['manageposts_minutes'] = 'minuta';
$txt['manageposts_characters'] = 'znakova';
$txt['manageposts_days'] = 'dana';
$txt['manageposts_posts'] = 'poruka';
$txt['manageposts_topics'] = 'tema';

$txt['pollMode'] = 'Omogući ankete';

$txt['manageposts_settings'] = 'Podešavanja poruka';
$txt['manageposts_settings_description'] = 'Ovde možete da podesite sve vezano za poruke i slanje poruka.';

$txt['manageposts_bbc_settings'] = 'Bilten Forum kod';
$txt['manageposts_bbc_settings_description'] = 'Bilten Forum kod može da bude korišćen za ulepšavanje poruka na forumu. Na primer, da biste označili reč \'kuća\' otkucajte [b]kuća[/b]. Sve Bilten Forum kod oznake su okružene uglastim zagradama (\'[\' i \']\').';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code settings';

$txt['manageposts_topic_settings'] = 'Podešavanja tema';
$txt['manageposts_topic_settings_description'] = 'Ovde možete da podesite sva podešavanja vezana za teme.';

$txt['managedrafts_settings'] = 'Draft Settings';
$txt['managedrafts_settings_description'] = 'Here you can set all settings involving drafts.';
$txt['manage_drafts'] = 'Drafts';

$txt['mail_center'] = 'Maillist Center';
$txt['mm_emailerror'] = 'Failed Emails';
$txt['mm_emailfilters'] = 'Filters';
$txt['mm_emailparsers'] = 'Parsers';
$txt['mm_emailtemplates'] = 'Templates';
$txt['mm_emailsettings'] = 'Podešavanja';

$txt['removeNestedQuotes'] = 'Ukloni ugnježdene citate prilikom citata';
$txt['enableSpellChecking'] = 'Omogući proveru pravopisa';
$txt['enableSpellChecking_warning'] = 'this does not work on all servers.';
$txt['enableSpellChecking_error'] = 'this does not work on your server.';
$txt['enableVideoEmbeding'] = 'Enable auto-embedding of video links.';
$txt['enableCodePrettify'] = 'Enable prettifying of code tags';
$txt['max_messageLength'] = 'Najviše dozvoljenih karaktera u porukama';
$txt['max_messageLength_zero'] = '0 za neograničeno';
$txt['convert_to_mediumtext'] = 'Your database is not setup to accept messages longer than 65535 characters. Please use the <a href="%1$s">database maintenance</a> page to convert the database and then come back to increase the maximum allowed post size.';
$txt['topicSummaryPosts'] = 'Broj prikazanih poruka pri odgovaranju na temu';
$txt['spamWaitTime'] = 'Proteklih sekundi između slanja poruka sa iste IP adrese';
$txt['edit_wait_time'] = 'Vreme dozvoljeno za uređivanje';
$txt['edit_disable_time'] = 'Najveći period vremena nakon slanja tokom kojeg je omogućena izmena';
$txt['edit_disable_time_zero'] = '0 za onemogućeno';
$txt['preview_characters'] = 'Maximum length of last/first post preview';
$txt['preview_characters_units'] = 'znakova';
$txt['preview_characters_zero'] = '0 to show the entire message';
$txt['message_index_preview'] = 'Show post previews on the message index';
$txt['message_index_preview_off'] = 'Do not show the previews';
$txt['message_index_preview_first'] = 'Show the text of the first post';
$txt['message_index_preview_last'] = 'Show the text of the last post';

$txt['enableBBC'] = 'Omogući bilten forum kod (BBC)';
$txt['enablePostHTML'] = 'Omogući <em>osnovni</em> HTML u porukama';
$txt['autoLinkUrls'] = 'Automatski linkuj poslate URL-ove';
$txt['disabledBBC'] = 'Dozvoljene BBC oznake';
$txt['bbcTagsToUse'] = 'Dozvoljene BBC oznake';
$txt['bbcTagsToUse_select'] = 'Izaberite oznake čija je upotreba dozvoljena';
$txt['bbcTagsToUse_select_all'] = 'Izaberi sve oznake';

$txt['enableParticipation'] = 'Omogući učešće ikona';
$txt['enableFollowup'] = 'Enable followups';
$txt['enable_unwatch'] = 'Enable unwatching of topics';
$txt['oldTopicDays'] = 'Vreme nakon kojeg se prikazuje upozorenje o staroj temi prilikom odgovaranja';
$txt['oldTopicDays_zero'] = '0 za onemogućeno';
$txt['defaultMaxTopics'] = 'Najveći broj tema prikazanih na jednoj stranici foruma';
$txt['defaultMaxMessages'] = 'Najveći broj poruka prikazanih na jednoj stranici teme';
$txt['disable_print_topic'] = 'Disable print topic feature';
$txt['hotTopicPosts'] = 'Broj poruka za popularnu temu';
$txt['hotTopicVeryPosts'] = 'Broj poruka za veoma popularnu temu';
$txt['useLikesNotViews'] = 'Use number of likes in place of posts to define hot topics';
$txt['enableAllMessages'] = 'Najveći broj odgovora u temi za prikazivanje &quot;Svih&quot; poruka';
$txt['enableAllMessages_zero'] = '0 za neprikazivanje &quot;Sve&quot;';
$txt['disableCustomPerPage'] = 'Onemogući prilagođavanje broja tema/poruka po strani';
$txt['enablePreviousNext'] = 'Omogući linkove ka prethodnoj/sledećoj temi';

$txt['not_done_title'] = 'Not done yet';
$txt['not_done_reason'] = 'Da bi se izbeglo preopterećivanje servera, proces je privremeno pauziran.  Trebalo bi da se nastavi za par sekundi. Ako se ne nastavi, kliknite na nastavi ispod.';
$txt['not_done_continue'] = 'Nastavi';

$txt['general_settings'] = 'Opšte';
$txt['database_paths_settings'] = 'Baza podataka i putanje';
$txt['cookies_sessions_settings'] = 'Kolačići i sesije';
$txt['caching_settings'] = 'Keširanje';
$txt['loadavg'] = 'Server Load';
$txt['loadavg_settings'] = 'Load Management';
$txt['phpinfo_settings'] = 'PHP Info';
$txt['phpinfo_localsettings'] = 'Local Settings';
$txt['phpinfo_defaultsettings'] = 'Default Settings';
$txt['phpinfo_itemsettings'] = 'Podešavanja';

$txt['language_configuration'] = 'Jezici';
$txt['language_description'] = 'This section allows you to edit languages installed on your forum or download new ones from the ElkArte site. You may also edit language-related settings here.';
$txt['language_edit'] = 'Izmeni jezike';
$txt['language_add'] = 'Dodaj jezik';
$txt['language_settings'] = 'Podešavanja';

$txt['advanced'] = 'Napredno';
$txt['simple'] = 'Prosto';

$txt['admin_news_select_recipients'] = 'Izaberite ko bi trebalo da primi kopiju infodopisa.';
$txt['admin_news_select_group'] = 'Korisničke grupe';
$txt['admin_news_select_group_desc'] = 'Izaberite grupe koje će primiti infodopis.';
$txt['admin_news_select_members'] = 'Korisnici';
$txt['admin_news_select_members_desc'] = 'Additional members to receive the newsletter.';
$txt['admin_news_select_excluded_members'] = 'Isključeni članovi';
$txt['admin_news_select_excluded_members_desc'] = 'Members who should not receive the newsletter.';
$txt['admin_news_select_excluded_groups'] = 'Isključene grupe';
$txt['admin_news_select_excluded_groups_desc'] = 'Izaberite grupe koje definitivno ne bi trebalo da prime infodopis.';
$txt['admin_news_select_email'] = 'Imejl adrese';
$txt['admin_news_select_email_desc'] = 'A semi-colon separated list of email addresses which should be sent this newsletter. (i.e. address1; address2)';
$txt['admin_news_select_override_notify'] = 'Override notification settings';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'Ne možete da pošaljete privatnu poruku imejl adresi. Ako nastavite, sve unete imejl adrese biće ignorisane.\\n\\nDa li ste sigurni da želite da uradite ovo?';

$txt['mailqueue_browse'] = 'Pregledaj red za slanje';
$txt['mailqueue_settings'] = 'Podešavanja';

$txt['admin_search'] = 'Brza pretraga';
$txt['admin_search_type_internal'] = 'Zadatak/Podešavanje';
$txt['admin_search_type_member'] = 'Član';
$txt['admin_search_type_online'] = 'Online priručnik';
$txt['admin_search_go'] = 'Idi';
$txt['admin_search_results'] = 'Rezultati pretrage';
$txt['admin_search_results_desc'] = 'Rezultati pretrage za: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Traži ponovo';
$txt['admin_search_results_none'] = 'No results found.';

$txt['admin_search_section_sections'] = 'Odeljak';
$txt['admin_search_section_settings'] = 'Podešavanje';

$txt['core_settings_title'] = 'Osnovne mogućnosti';
$txt['core_settings_desc'] = 'This page allows you to turn on or off optional features of your forum.';
$txt['mods_cat_features'] = 'Opšte';
$txt['mods_cat_security_general'] = 'Opšte';
$txt['antispam_title'] = 'Zaštita od spama';
$txt['badbehavior_title'] = 'Bad Behavior';
$txt['mods_cat_modifications_misc'] = 'Razno';
$txt['mods_cat_layout'] = 'Izgled';
$txt['karma'] = 'Ugled';
$txt['moderation_settings_short'] = 'Uređivanje';
$txt['signature_settings_short'] = 'Potpisi';
$txt['custom_profile_shorttitle'] = 'Polja u profilu';
$txt['pruning_title'] = 'Brisanje dnevnika';

$txt['core_settings_activation_message'] = 'The feature {core_feature} has been activated, click on the title to configure it';
$txt['core_settings_deactivation_message'] = 'The feature {core_feature} has been deactivated';
$txt['core_settings_generic_error'] = 'An error occurred, please reload the page and try again.';

$txt['boardsEdit'] = 'Izmena foruma';
$txt['mboards_new_cat'] = 'Create new category';
$txt['manage_holidays'] = 'Upravljanje praznicima';
$txt['calendar_settings'] = 'Podešavanja kalendara';
$txt['search_weights'] = 'Težine';
$txt['search_method'] = 'Način pretrage';
$txt['search_sphinx'] = 'Configure Sphinx';

$txt['smiley_sets'] = 'Postavke smajlija';
$txt['smileys_add'] = 'Dodaj smajli';
$txt['smileys_edit'] = 'Izmeni smajlije';
$txt['smileys_set_order'] = 'Set Smiley order';
$txt['icons_edit_message_icons'] = 'Edit message icons';

$txt['membergroups_new_group'] = 'Add Member Group';
$txt['membergroups_edit_groups'] = 'Edit Member Groups';
$txt['permissions_groups'] = 'Dozvole po grupama članova';
$txt['permissions_boards'] = 'Dozvole po forumima';
$txt['permissions_profiles'] = 'Izmeni profile';
$txt['permissions_post_moderation'] = 'Uređivanje poruka';

$txt['browse_packages'] = 'Pregledaj pakete';
$txt['download_packages'] = 'Preuzmi pakete';
$txt['upload_packages'] = 'Upload Package';
$txt['installed_packages'] = 'Instalirani paketi';
$txt['package_file_perms'] = 'Dozvole datoteka';
$txt['package_settings'] = 'Podešavanja';
$txt['package_servers'] = 'Package Servers';
$txt['themeadmin_admin_title'] = 'Upravljanje i instaliranje';
$txt['themeadmin_list_title'] = 'Podešavanja teme';
$txt['themeadmin_reset_title'] = 'Opcije članova';
$txt['themeadmin_edit_title'] = 'Izmeni teme';
$txt['admin_browse_register_new'] = 'Register new member';

$txt['search_engines'] = 'Pretraživači';
$txt['spider_logs'] = 'Dnevnici';
$txt['spider_stats'] = 'Statistika';

$txt['paid_subscriptions'] = 'Plaćene pretplate';
$txt['paid_subs_view'] = 'Pogledaj pretplate';

$txt['maintain_sub_hooks_list'] = 'Integration Hooks';
$txt['hooks_field_hook_name'] = 'Hook Name';
$txt['hooks_field_function_name'] = 'Function Name';
$txt['hooks_field_function'] = 'Function';
$txt['hooks_field_included_file'] = 'Included file';
$txt['hooks_field_file_name'] = 'Ime datoteke';
$txt['hooks_field_hook_exists'] = 'Status';
$txt['hooks_active'] = 'Exists';
$txt['hooks_disabled'] = 'Onemogućeno'; //@deprecated since 1.1 - it's no more possible to disable hooks
$txt['hooks_missing'] = 'Not found';
$txt['hooks_no_hooks'] = 'There are currently no hooks in the system.';
$txt['hooks_disable_legend'] = 'Legenda';
$txt['hooks_disable_legend_exists'] = 'the hook exists and is active';
$txt['hooks_disable_legend_disabled'] = 'the hook exists but has been disabled';
$txt['hooks_disable_legend_missing'] = 'the hook has not been found';
$txt['hooks_reset_filter'] = 'Reset filter';

$txt['board_perms_allow'] = 'Dozvoljeno';
$txt['board_perms_ignore'] = 'Ignoriši';
$txt['board_perms_deny'] = 'Nedozvoljeno';
$txt['all_boards_in_cat'] = 'All boards in this category';

$txt['url'] = 'URL';
$txt['words_sep'] = 'Words separator';

$txt['admin_order_title'] = 'Ordering Error';
$txt['admin_order_error'] = 'An unknown error occurred while processing your request';

// Known controllers that can work on the front page
$txt['default'] = 'Uobičajeno';
$txt['front_page'] = 'Select the action to show on the front page:';

$txt['BoardIndex_Controller'] = 'Board Index';
$txt['MessageIndex_Controller'] = 'Content of a board';
$txt['message_index_frontpage'] = 'Select the board to show on the front page:';
$txt['Recent_Controller'] = 'Recent posts';
$txt['recent_frontpage'] = 'Number of messages to show:';
