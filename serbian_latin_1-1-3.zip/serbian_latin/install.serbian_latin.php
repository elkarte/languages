<?php
// Version: 1.1; Install

// These should be the same as those in index.language.php.
$txt['lang_character_set'] = 'UTF-8';
$txt['lang_rtl'] = false;

$txt['install_step_welcome'] = 'Dobrodošli';
$txt['install_step_exist'] = 'Existance Check';
$txt['install_step_writable'] = 'Provera upisivosti';
$txt['install_step_forum'] = 'Osnovna podešavanja';
$txt['install_step_databaseset'] = 'Podešavanja baze podataka';
$txt['install_step_databasechange'] = 'Popunjavanje baze podataka';
$txt['install_step_admin'] = 'Administratorski nalog';
$txt['install_step_delete'] = 'Finalize Installation';

$txt['installer'] = 'ElkArte Installer';
$txt['installer_language'] = 'Jezik';
$txt['installer_language_set'] = 'Skup';
$txt['congratulations'] = 'Čestitamo, instalacioni proces je završen!';
$txt['congratulations_help'] = 'If at any time you need support, or the forum fails to work properly, please remember that <a href="https://www.elkarte.net/index.php" target="_blank" class="new_win">help is available</a> if you need it.';
$txt['still_writable'] = 'Vaš instalacioni direktorijum je i dalje otvoren za upisivanje. Bilo bi dobro da mu promenite dozvole tako da ne bude otvoren za upisivanje iz bezbednosnih razloga.';
$txt['delete_installer'] = 'Click here to try to delete the install directory now.';
$txt['delete_installer_maybe'] = '<em>(ne radi na svim serverima.)</em>';
$txt['go_to_your_forum'] = 'Sada možete da pogledate <a href="%1$s">vaš novoinstalirani forum</a> i početi sa njegovim korišćenjem.  Prvo bi trebalo da proverite da li ste prijavljeni nakon čega bi trebalo da možete da pristupite administracionom centru.';
$txt['good_luck'] = 'Thanks for installing ElkArte!';
$txt['try_again'] = 'Click here to try again.';

$txt['install_welcome'] = 'Dobrodošli';
$txt['install_welcome_desc'] = 'Welcome to ElkArte. This script will guide you through the process for installing %1$s. We\'ll gather a few details about your forum over the next few steps, and after a couple of minutes your forum will be ready for use.';
$txt['install_all_lovely'] = 'Dovršili smo neke početne testove na vašem serveru i sve izgleda u redu. Jednostavno kliknite na "Nastavi" dugme ispod da biste počeli.';

$txt['user_refresh_install'] = 'Forum je osvežen';
$txt['user_refresh_install_desc'] = 'Prilikom instaliranja, instaler je pronašao da (koristeći detalje koje ste pružili) jedna ili više tabela koju je instaler mogao da napravi već postoji.<br />Sve nedostajuće tabele u instalaciji su ponovo napravljene koristeći podrazumevane podatke a nikakvi podaci nisu obrisani iz već postojećih tabela.';

$txt['default_topic_subject'] = 'Welcome to ElkArte!';
$txt['default_topic_message'] = 'Welcome to ElkArte!<br /><br />We hope you enjoy using this software and building your community.&nbsp; If you have any problems, please feel free to [url=https://www.elkarte.net/index.php]ask us for assistance[/url].<br /><br />Thanks!<br />The ElkArte Community.';
$txt['default_board_name'] = 'Opšta diskusija';
$txt['default_board_description'] = 'Slobodno pričajte o svemu i svačemu u ovom forumu.';
$txt['default_category_name'] = 'Opšta kategorija';
$txt['default_time_format'] = '%d.%m.%Y. %H:%M';
$txt['default_news'] = 'ElkArte - Just Installed!';
$txt['default_karmaLabel'] = 'Ugled:';
$txt['default_karmaSmiteLabel'] = '[smanji]';
$txt['default_karmaApplaudLabel'] = '[povećaj]';
$txt['default_reserved_names'] = 'Admin\\nWebmaster\\nGuest\\nroot\\nGost\\nAdministrator\\nModerator\\nUrednik';
$txt['default_smileyset_name'] = 'Fugue\'s Set';
$txt['default_theme_name'] = 'ElkArte Default Theme';

$txt['default_administrator_group'] = 'Administrator';
$txt['default_global_moderator_group'] = 'Opšti urednik';
$txt['default_moderator_group'] = 'Uredničke';
$txt['default_newbie_group'] = 'Novajlija';
$txt['default_junior_group'] = 'Mlađi član';
$txt['default_full_group'] = 'Punopravni član';
$txt['default_senior_group'] = 'Stariji član';
$txt['default_hero_group'] = 'Heroj';

$txt['default_smiley_smiley'] = 'Smeško';
$txt['default_wink_smiley'] = 'Namigivanje';
$txt['default_cheesy_smiley'] = 'Nasmejan';
$txt['default_grin_smiley'] = 'Zelenko';
$txt['default_angry_smiley'] = 'Ljutko';
$txt['default_sad_smiley'] = 'Tužan';
$txt['default_shocked_smiley'] = 'Šokiran';
$txt['default_cool_smiley'] = 'Opušten';
$txt['default_huh_smiley'] = 'Molim?';
$txt['default_roll_eyes_smiley'] = 'Prevrtanje očima';
$txt['default_tongue_smiley'] = 'Jezik';
$txt['default_embarrassed_smiley'] = 'Zaprepašćen';
$txt['default_lips_sealed_smiley'] = 'Usne su mi zapečaćene';
$txt['default_undecided_smiley'] = 'Neodlučan';
$txt['default_kiss_smiley'] = 'Poljubac';
$txt['default_cry_smiley'] = 'Plačko';
$txt['default_evil_smiley'] = 'Zloća';
$txt['default_azn_smiley'] = 'Azijat';
$txt['default_afro_smiley'] = 'Afro';
$txt['default_laugh_smiley'] = 'Smejavko';
$txt['default_police_smiley'] = 'Policajac';
$txt['default_angel_smiley'] = 'Anđeo';

$txt['error_message_click'] = 'Kliknite ovde';
$txt['error_message_try_again'] = 'da biste ponovili ovaj korak.';
$txt['error_message_bad_try_again'] = 'da biste probali da instalirate, ali ovu ideju uopšte <em>ne odobravamo</em>.';

$txt['install_settings'] = 'Osnovna podešavanja';
$txt['install_settings_info'] = 'This page requires you to define a few key settings for your forum. ElkArte has automatically detected key settings for you.';
$txt['install_settings_name'] = 'Ime foruma';
$txt['install_settings_name_info'] = 'This is the name of your forum, e.g. &quot;The Testing Forum&quot;.';
$txt['install_settings_name_default'] = 'Moja zajednica';
$txt['install_settings_url'] = 'Url foruma';
$txt['install_settings_url_info'] = 'Ovo je URL do vašeg foruma <strong>bez poslednje \'/\'!</strong>.<br />U najvećem broju slučajeva, možete da ostavite podrazumevanu vrednost u polju - ona je uglavnom tačna.';
$txt['install_settings_compress'] = 'Gzip izlaz';
$txt['install_settings_compress_title'] = 'Kompresuj izlaz da bi sačuvao propusni opseg.';
// In this string, you can translate the word "PASS" to change what it says when the test passes.
$txt['install_settings_compress_info'] = 'This function does not work properly on all servers, but can save you a lot of bandwidth.<br /><a href="install.php?obgz=1&amp;pass_string=PASS" onclick="return reqWin(this.href, 200, 60);" target="_blank">Click here to test it</a>. (it should just say "PASS".)';
$txt['install_settings_dbsession'] = 'Sesije koriste bazu podataka';
$txt['install_settings_dbsession_title'] = 'Koristi bazu podataka za sesije umesto datoteka.';
$txt['install_settings_dbsession_info1'] = 'Ova mogućnost je uglavnom najbolja jer čini sesije nezavisnijim.';
$txt['install_settings_dbsession_info2'] = 'Izgleda da ova mogućnost ne radi na vašem serveru ali je možete isprobati.';
$txt['install_settings_proceed'] = 'Nastavi';

$txt['db_settings'] = 'Podešavanja servera baze podataka';
$txt['db_settings_info'] = 'Ovo su podešavanja za korišćenje vašeg servera baze podataka. Ukoliko ne znate vrednosti, pitajte vaš hosting.';
$txt['db_settings_type'] = 'Tip baze podataka';
$txt['db_settings_type_info'] = 'Multiple supported database types were detected - which one do you wish to use?';
$txt['db_settings_server'] = 'Ime servera';
$txt['db_settings_server_info'] = 'Ovo je skoro uvek localhost - pa, ako ne znate, pokušajte localhost.';
$txt['db_settings_port'] = 'Port';
$txt['db_settings_port_info'] = 'Leave empty if your server is listening on the default port, or you are uncertain.';
$txt['db_settings_username'] = 'User name';
$txt['db_settings_username_info'] = 'Fill in the user name you need to connect to your database here.<br />If you don\'t know what it is, try the user name of your FTP account, most of the time they are the same.';
$txt['db_settings_password'] = 'Lozinka';
$txt['db_settings_password_info'] = 'Here you should put the password you need to connect to your database.<br />If you don\'t know this, you should try the password to your FTP account.';
$txt['db_settings_database'] = 'Ime baze';
$txt['db_settings_database_info'] = 'Fill in the name of the database you want to use for ElkArte to store its data in.';
$txt['db_settings_database_info_note'] = 'Ako ova baza ne postoji, ovaj instaler će pokušati da je napravi.';
$txt['db_settings_database_file'] = 'Database file name';
$txt['db_settings_database_file_info'] = 'This is the name of the file in which to store the ElkArte data. We recommend you use the randomly generated name for this and set the path of this file to be outside of the public area of your webserver.';
$txt['db_settings_prefix'] = 'Prefiks tabela';
$txt['db_settings_prefix_info'] = 'Prefiks za svaku tabelu u bazi. <strong>Ne instalirajte dva foruma sa istim prefiksom!</strong><br />Ova vrednost vam dozvoljava da imate višestruke instalacije u jednoj bazi podataka.';
$txt['db_populate'] = 'Baza podataka popunjena';
$txt['db_populate_info'] = 'Vaša podešavanja su sada sačuvana i baza podataka je popunjena sa svim podacima potrebnim da biste pokrenuli svoj forum. Pregled popunjavanja:';
$txt['db_populate_info2'] = 'Kliknite &quot;Nastavi&quot; da prprodužite na stranicu za izradu admin naloga.';
$txt['db_populate_inserts'] = 'Ubačeno %1$d redova.';
$txt['db_populate_tables'] = 'Napravljeno %1$d tabela.';
$txt['db_populate_insert_dups'] = 'Zanemareno %1$d dvostrukih unosa.';
$txt['db_populate_table_dups'] = 'Zanemareno %1$d dvostrukih tabela.';

$txt['user_settings'] = 'Napravite svoj nalog';
$txt['user_settings_info'] = 'Instaler će sada napraviti novi administratorski nalog za vas.';
$txt['user_settings_username'] = 'Your user name';
$txt['user_settings_username_info'] = 'Choose the name you want to login with.';
$txt['user_settings_password'] = 'Lozinka';
$txt['user_settings_password_info'] = 'Unesite svoju lozinku i zapamtite je dobro!';
$txt['user_settings_again'] = 'Lozinka';
$txt['user_settings_again_info'] = '(samo zbog potvrde.)';
$txt['user_settings_email'] = 'Imejl adresa';
$txt['user_settings_email_info'] = 'Upišite i svoju imejl adresu. <strong>Adresa mora da bude ispravna imejl adresa.</strong>';
$txt['user_settings_database'] = 'Lozinka baze';
$txt['user_settings_database_info'] = 'Instaler iz bezbednosnih razloga zahteva da dostavite i lozinku baze podataka pri pravljenju administratorskog naloga.';
$txt['user_settings_skip'] = 'Preskoči';
$txt['user_settings_skip_sure'] = 'Da li ste sigurni da želite da preskočite kreiranje administratorskog naloga?';
$txt['user_settings_proceed'] = 'Završi';

$txt['ftp_checking_writable'] = 'Checking if files are writable';
$txt['ftp_setup'] = 'Informacije o FTP vezi';
$txt['ftp_setup_info'] = 'Instaler može da se poveže preko FTP-a i popravi datoteke koje moraju da budu otvorene za upisivanje a trenutno nisu.  Ako vam ovo ne odgovara, moraćete ručno da promenite privilegije nad datotekama i učinite ih otvorenim za pisanje.<br />Napomena: Ova mogućnost trenutno ne podržava SSL.';
$txt['ftp_server'] = 'Server';
$txt['ftp_server_info'] = 'This should be the server address and port for your FTP server.';
$txt['ftp_port'] = 'Port';
$txt['ftp_username'] = 'User name';
$txt['ftp_username_info'] = 'The user name to login with. <em>This will not be saved anywhere.</em>';
$txt['ftp_password'] = 'Lozinka';
$txt['ftp_password_info'] = 'Lozinka za prijavljivanje. <em>Neće biti sačuvana.</em>';
$txt['ftp_path'] = 'Instalaciona putanja';
$txt['ftp_path_info'] = 'Ovo je <em>relativna</em> putanja koju koristite na svom FTP serveru.';
$txt['ftp_path_found_info'] = 'Putanja u polju iznad je automatski određena.';
$txt['ftp_connect'] = 'Poveži se';
$txt['ftp_setup_why'] = 'Čemu služi ovaj korak?';
$txt['ftp_setup_why_info'] = 'Some files need to be writable for ElkArte to work properly.  This step allows you to let the installer make them writable for you.  However, in some cases it won\'t work - in that case, please make the following files 777 (writable, 755 on some hosts):';
$txt['ftp_setup_again'] = 'da biste proverili da li su ove datoteke otvorene za pisanje.';

$txt['error_php_too_low'] = 'Warning!  You do not appear to have a version of PHP installed on your webserver that meets ElkArte\'s <strong>minimum installations requirements</strong>.<br />If you are not the host, you will need to ask your host to upgrade, or use a different host - otherwise, please upgrade PHP to a recent version.<br /><br />If you know for a fact that your PHP version is high enough you may continue, although this is strongly discouraged.';
$txt['error_missing_files'] = 'Ne mogu da pronađem osnovne instalacione datoteke u direktorijumu ove skripte!<br /><br />Proverite da li ste dostavili celokupan instalacioni paket, uključujući i SQL datoteku, i pokušajte ponovo.';
$txt['error_session_save_path'] = 'Obavestite svoj hosting da je <strong>session.save_path precizirana u datoteci php.ini</strong> pogrešna!  Trebalo bi da se podesi na direktorijum koji <strong>postoji</strong>, i <strong>otvoren je za upisivanje</strong> od strane korisnika pod kojim se PHP pokreće.<br />';
$txt['error_windows_chmod'] = 'You\'re on a windows server, and some crucial files are not writable.  Please ask your host to give <strong>write permissions</strong> to the user PHP is running under for the files in your ElkArte installation.  The following files or directories need to be writable:';
$txt['settings_error'] = 'Your settings could not be saved to Settings.php, the file is not writable.';
$txt['error_ftp_no_connect'] = 'Ne mogu da se povežem na FTP server koristeći ovu kombinaciju detalja.';
$txt['error_db_file'] = 'Ne mogu da pronađem skriptu za upravljanje vašom bazom podataka! Proverite da li je datoteka %1$ u vašem source direktorijumu.';
$txt['error_db_connect'] = 'Ne mogu da se povežem na server baze podataka koristeći priložene podatke.<br /><br />Ako niste sigurni šta da ukucate, kontaktirajte svoj hosting';
$txt['error_db_too_low'] = 'The version of your database server is very old and does not meet ElkArte\'s minimum requirements.<br /><br />Please ask your host to either upgrade it or supply a new one, and if they won\'t, please try a different host.';
$txt['error_db_database'] = 'The installer was unable to access the &quot;<em>%1$s</em>&quot; database.  With some hosts, you have to create the database in your administration panel before ElkArte can use it.  Some also add prefixes - like your username - to your database names.';
$txt['error_db_queries'] = 'Neki od upita nisu izvršeni pravilno. Ovo može da bude uzrokovano nepodržanom (razvojnom ili starom) verzijom vašeg servera baze podataka.<br /><br />Tehničke informacije o upitima:';
$txt['error_db_queries_line'] = 'Linija #';
$txt['error_db_missing'] = 'The installer was unable to detect database support in PHP that ElkArte can utilize.  Please ask your host to ensure that PHP was compiled with the desired database, or that the proper php extension is being loaded.  Currently ElkArte supports the:  &quot;%1$s&quot; extensions';
$txt['error_db_script_missing'] = 'Instaler nije mogao da pronađe nijednu instalacionu skriptu za nađenu bazu podataka.Molimo proverite jeste li ubacili potrebne datoteke instalacionih skripti u direktorijum vašeg foruma, na primer &quot;%1$s&quot;';
$txt['error_session_missing'] = 'Instaler nije mogao da pronađe podršku za sesije u instalaciji PHP-a na vašem serveru. Zamolite svoj hosting da osigura da je PHP kompajliran sa podrškom za sesije (u stvari, mora da bude eksplicitno kompajlirana bez nje.)'; // note: is this actually true? I see a contradiction here...!
$txt['error_user_settings_again_match'] = 'Ukucali ste dve potpuno različite lozinke!';
$txt['error_user_settings_no_password'] = 'Vaša lozinka mora da ima najmanje četiri znaka.';
$txt['error_user_settings_taken'] = 'Sorry, a member is already registered with that user name and/or email address.<br /><br />A new account has not been created.';
$txt['error_user_settings_query'] = 'Došlo je do greške u bazi podataka prilikom kreiranja administratora.  Greška je sledeća:';
$txt['error_subs_missing'] = 'Unable to find the sources/Subs.php file.  Please make sure it was uploaded properly, and then try again.';
$txt['error_db_alter_priv'] = 'The database account you specified does not have permission to ALTER, CREATE, and/or DROP tables in the database; this is necessary for ElkArte to function properly.';
$txt['error_versions_do_not_match'] = 'The installer has detected another version of ElkArte already installed with the specified information.  If you are trying to upgrade, you should use the upgrader, not the installer.<br /><br />Otherwise, you may wish to use different information, or create a backup and then delete the data currently in the database.';
$txt['error_mod_security'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a>';
$txt['error_mod_security_no_write'] = 'The installer has detected the mod_security module is installed on your web server. Mod_security will block submitted forms even before ElkArte gets a say in anything. ElkArte has a built-in security scanner that will work more effectively than mod_security and that won\'t block submitted forms.<br /><br /><a href="https://www.elkarte.net/redirect/mod_security" target="_blank" class="new_win">More information about disabling mod_security</a><br /><br />Alternatively, you may wish to use your FTP client to chmod .htaccess in the forum directory to be writable (777), and then refresh this page.';
$txt['error_utf8_version'] = 'The current version of your database doesn\'t support the use of the UTF-8 character set. You can not install ElkArte';
$txt['error_valid_email_needed'] = 'Niste uneli ispravnu imejl adresu.';
$txt['error_already_installed'] = 'The installer has detected that you already have ElkArte installed. It is strongly advised that you do <strong>not</strong> try to overwrite an existing installation - continuing with installation <strong>may result in the loss or corruption of existing data</strong>.<ul><li>If you have just finished installing your forum, please delete the install directory from your server. {try_delete}</li><li>If you wish to upgrade please use the <a href="./upgrade.php"><strong>upgrade script</strong></a>.</li><li>If you wish to overwrite your existing installation, including all data, it\'s recommended that you delete the existing database tables and replace Settings.php and try again.</li></ul>';
$txt['error_no_settings'] = 'It looks like Settings.php and/or Settings_bak.php are missing from the default directory of your forum, ElkArte will try to rename the sample files provided with the installation. If this operation fails, please rename Settings.sample.php and Settings_bak.sample.php respectively to Settings.php and Setting_bak.php before running this script.';
$txt['error_settings_do_not_exist'] = 'Elkarte is not able to find and create the file/s <strong>%1$s</strong>. Please use ftp to go to the directory of your forum and rename the sample files provided with the installation package as follows before running again this script: <ul>%2$s</ul> If any of the files do not exist, create an empty file with the same name.';
$txt['error_warning_notice'] = 'Upozorenje!';
$txt['error_script_outdated'] = 'This install script is out of date! The current version of ElkArte is %1$s but this install script is for %2$s.<br />
	It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte</a> website to ensure you are installing the latest version.';
$txt['error_db_filename'] = 'Morate uneti ime baze podataka za SQLite.';
$txt['error_db_prefix_numeric'] = 'Izabrana baza podataka ne podržava korišćenje numeričkih prefiksa.';
$txt['error_invalid_characters_username'] = 'Invalid character used in user name.';
$txt['error_username_too_long'] = 'User name must be less than 25 characters long.';
$txt['error_username_left_empty'] = 'User name field was left empty.';
$txt['error_db_filename_exists'] = 'Baza podataka koju pokušavate napraviti postoji. Molimo da obrišete postojeću bazu podataka ili unesite drugo ime.';
$txt['error_db_prefix_reserved'] = 'Prefiks koji ste uneli je rezervisan.Molimo unesite drugi prefiks.';

$txt['upgrade_upgrade_utility'] = 'ElkArte Upgrade Utility';
$txt['upgrade_warning'] = 'Upozorenje!';
$txt['upgrade_critical_error'] = 'Kritična greška!';
$txt['upgrade_continue'] = 'Nastavi';
$txt['upgrade_retry'] = 'Retry';
$txt['upgrade_skip'] = 'Preskoči';
$txt['upgrade_note'] = 'Pažnja!';
$txt['upgrade_step'] = 'Korak';
$txt['upgrade_steps'] = 'Koraka';
$txt['upgrade_progress'] = 'Napredak';
$txt['upgrade_overall_progress'] = 'Ukupni Napredak';
$txt['upgrade_step_progress'] = 'Stepen Napretka';
$txt['upgrade_time_elapsed'] = 'Proteklo vreme';
$txt['upgrade_time_mins'] = 'minuta';
$txt['upgrade_time_secs'] = 'sekundi';

$txt['upgrade_incomplete'] = 'Nekompletno';
$txt['upgrade_not_quite_done'] = 'Još nismo završili!';
$txt['upgrade_paused_overload'] = 'Nadogradnja je privremeno zaustavljena da se izbegne preopterećenje servera. Ne brinite, nije ništa - samo kliknite na <label for="contbutt">continue button</label> ispod za nastavak.';

$txt['upgrade_ready_proceed'] = 'Thank you for choosing to upgrade to ElkArte %1$s. All files appear to be in place, and we\'re ready to proceed.';

$txt['upgrade_error_script_js'] = 'The upgrade script cannot find script.js or it is out of date. Make sure your theme paths are correct. You can download a settings check and repair script from <a href="https://github.com/elkarte/tools/downloads" target="_blank" class="new_win">ElkArte tools</a>.';

$txt['upgrade_warning_lots_data'] = 'Skripta za nadogradnju je otkrila da vaš forum sadrži dosta podataka kojima treba nadogradnja. Ovaj proces može da potraje neko vreme u zavisnosti od vašeg servera i veličine foruma, a za vrlo velike forume (~300,000 poruka) može da potraje nekoliko sati dok se završi.';
$txt['upgrade_warning_out_of_date'] = 'This upgrade script is out of date! The current version of ElkArte is <em id="elkVersion">??</em> but this upgrade script is for <em id="installedVersion">%1$s</em>.<br /><br />It is recommended that you visit the <a href="https://www.elkarte.net/" target="_blank" class="new_win">ElkArte Community</a> website to ensure you are upgrading to the latest version.';
$txt['upgrade_warning_already_done'] = 'You are already running <em>ElkArte %1$s</em> no upgrade is available!  You must <strong>delete</strong> the install directory and then proceed to <a href="%2$s">your forum</a>';