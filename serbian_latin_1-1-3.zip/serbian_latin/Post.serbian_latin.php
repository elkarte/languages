<?php
// Version: 1.1; Post

$txt['post_reply'] = 'Pošalji odgovor';
$txt['post_in_board'] = 'Post in the board';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Umetnite citat';
$txt['disable_smileys'] = 'Disable smileys';
$txt['dont_use_smileys'] = 'Ne koristi smajlije.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Poslato';
$txt['standard'] = 'Uobičajene';
$txt['thumbs_up'] = 'Prst nagore';
$txt['thumbs_down'] = 'Prst nadole';
$txt['exclamation_point'] = 'Znak uzvika';
$txt['question_mark'] = 'Upitnik';
$txt['icon_poll'] = 'Anketa';
$txt['lamp'] = 'Lampa';
$txt['add_smileys'] = 'Add smileys';
$txt['topic_notify_no'] = 'There are no topics with notification.';

$txt['rich_edit_wont_work'] = 'Vaš pregledač ne podržava bogato uređivanje teksta.';
$txt['rich_edit_function_disabled'] = 'Vaš pregledač ne podržava ovu funkciju.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Otkažite praćenje ove teme posećivanjem ovog linka';

$txt['lock_after_post'] = 'Zaključaj nakon slanja';
$txt['notify_replies'] = 'Obavesti me o odgovorima.';
$txt['lock_topic'] = 'Zaključaj ovu temu.';
$txt['shortcuts'] = 'shortcuts: shift+alt+s submit/post or shift+alt+p preview';
$txt['shortcuts_drafts'] = 'shortcuts: shift+alt+s submit/post, shift+alt+p preview or shift+alt+d save draft';
$txt['option'] = 'Opcije';
$txt['reset_votes'] = 'Reset vote count';
$txt['reset_votes_check'] = 'Označite ovo ako želite da postavite broj glasova na 0.';
$txt['votes'] = 'glasova';
$txt['attach'] = 'Priloži';
$txt['clean_attach'] = 'Clear attachment';
$txt['attached'] = 'Priloženo'; // @deprecated since 1.1
$txt['allowed_types'] = 'Dozvoljeni tipovi datoteka';
$txt['cant_upload_type'] = 'You cannot upload that type of file. The only allowed extensions are %1$s.';
$txt['uncheck_unwatchd_attach'] = 'Označite priložene datoteke koje želite da uklonite'; // @deprecated since 1.1
$txt['restricted_filename'] = 'Ovo je zabranjeno ime datoteke. Pokušajte drugo ime.';
$txt['topic_locked_no_reply'] = 'Warning! This topic is currently/will be locked<br />Only admins and moderators can reply.';
$txt['attachment_requires_approval'] = 'Priložene datoteke neće biti prikazane dok ih urednik ne odobri.';
$txt['error_temp_attachments'] = 'There are attachments found, which you have attached before but not posted. These attachments are now attached to this post. If you do not want to include them in this post, <a href="#postAttachment">you can remove them here</a>.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Podsetnik: Ova poruka se neće pojaviti dok je urednik ne odobri.';

$txt['enter_comment'] = 'Unesite komentar';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'Prijavljena poruka';
$txt['reported_to_mod_by'] = 'od strane';
$txt['rtm10'] = 'Pošalji';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = 'Sledeća poruka, "%1$s" koju je napisao';
$txt['reported_by'] = 'je prijavljena od';
$txt['board_moderate'] = 'na forumu koji vi uređujete';
$txt['report_comment'] = 'Prijavljivač je uneo sledeći komentar';

$txt['attach_drop_files'] = 'Add files by dragging & dropping or <a class="drop_area_fileselect_text" href="javascript:void(0)">selecting them</a>';
$txt['attach_drop_files_mobile'] = '<a class="drop_area_fileselect_text" href="javascript:void(0)">Add files</a>';
$txt['attach_restrict_attachmentPostLimit'] = 'maximum total size %1$s KB';
$txt['attach_restrict_attachmentSizeLimit'] = 'maximum individual size %1$s KB';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d po poruci';
$txt['attach_restrictions'] = 'Ograničenja:';

$txt['post_additionalopt_attach'] = 'Dodatne opcije...';
$txt['post_additionalopt'] = 'Other options';
$txt['sticky_after'] = 'Pin this topic.';
$txt['move_after2'] = 'Premesti ovu temu.';
$txt['back_to_topic'] = 'Vrati se na ovu temu.';
$txt['approve_this_post'] = 'Approve this post';

$txt['retrieving_quote'] = 'Retrieving quote...';

$txt['post_visual_verification_label'] = 'Potvrda';
$txt['post_visual_verification_desc'] = 'Unesite kod sa slike da biste poslali poruku.';

$txt['poll_options'] = 'Opcije ankete';
$txt['poll_run'] = 'Drži anketu otvorenu';
$txt['poll_run_limit'] = '(Ostavite prazno ukoliko želite da nema ograničenja.)';
$txt['poll_results_visibility'] = 'Vidljivost rezultata';
$txt['poll_results_anyone'] = 'Prikaži svima rezultate ankete.';
$txt['poll_results_voted'] = 'Prikaži rezultate tek nakon glasanja.';
$txt['poll_results_after'] = 'Prikaži rezultate kada anketa istekne.';
$txt['poll_max_votes'] = 'Maksimalni broj glasova po korisniku';
$txt['poll_do_change_vote'] = 'Dozvoli korisniku da menja glas';
$txt['poll_too_many_votes'] = 'Izabrali ste previše opcija. Za ovu anketu, broj dozvoljenih opcija je %1$s.';
$txt['poll_add_option'] = 'Dodaj opciju';
$txt['poll_guest_vote'] = 'Dozvoli gostima da glasaju';

$txt['spellcheck_done'] = 'Provera pravopisa je završena.';
$txt['spellcheck_change_to'] = 'Promeni u:';
$txt['spellcheck_suggest'] = 'Predlozi:';
$txt['spellcheck_change'] = 'Izmeni';
$txt['spellcheck_change_all'] = 'Zameni sve';
$txt['spellcheck_ignore'] = 'Ignoriši';
$txt['spellcheck_ignore_all'] = 'Ignoriši sve';

$txt['more_attachments'] = 'još priloga';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Nije vam dozvoljeno da priložite još datoteka.';

$txt['more_smileys'] = 'još';
$txt['more_smileys_title'] = 'Dodatni smajliji';
$txt['more_smileys_pick'] = 'Izaberite smajli';
$txt['more_smileys_close_window'] = 'Zatvori prozor';

$txt['error_new_reply'] = 'While you were typing a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies'] = 'While you were typing %1$d new replies have been posted. You may wish to review your post.';
$txt['error_new_reply_reading'] = 'While you were reading a new reply has been posted. You may wish to review your post.';
$txt['error_new_replies_reading'] = 'While you were reading %1$d new replies have been posted. You may wish to review your post.';

$txt['announce_this_topic'] = 'Pošaljite objavu o ovoj temi članovima:';
$txt['announce_title'] = 'Pošalji objavu';
$txt['announce_desc'] = 'Ova forma vam omogućava da pošaljete objavu o ovoj temi izabranim korisničkim grupama.';
$txt['announce_sending'] = 'Šaljem objavu o temi';
$txt['announce_done'] = 'završeno';
$txt['announce_continue'] = 'Nastavi';
$txt['announce_topic'] = 'Objavi temu.';
$txt['announce_regular_members'] = 'Negrupisani članovi';

$txt['digest_subject_daily'] = 'Dnevni pregled';
$txt['digest_subject_weekly'] = 'Nedeljni pregled';
$txt['digest_intro_daily'] = 'Below is a summary of today\'s activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_intro_weekly'] = 'Below is a summary of the weekly activity for your subscriptions at %1$s. To unsubscribe please visit the following link.';
$txt['digest_new_topics'] = 'The following topics were started';
$txt['digest_new_topics_line'] = '"%1$s" in the %2$s board';
$txt['digest_new_replies'] = 'Odgovarano je na sledeće teme';
$txt['digest_new_replies_one'] = '1 odgovor u "%1$s"';
$txt['digest_new_replies_many'] = '%1$d odgovora u "%2$s"';
$txt['digest_mod_actions'] = 'Urednici su uradili sledeće';
$txt['digest_mod_act_sticky'] = '"%1$s" was pinned';
$txt['digest_mod_act_lock'] = '"%1$s" je zaključana';
$txt['digest_mod_act_unlock'] = '"%1$s" je otključana';
$txt['digest_mod_act_remove'] = '"%1$s" je uklonjena';
$txt['digest_mod_act_move'] = '"%1$s" je premeštena';
$txt['digest_mod_act_merge'] = '"%1$s" je spojena';
$txt['digest_mod_act_split'] = '"%1$s" je podeljena';

$txt['attach_error_title'] = 'Error uploading attachments.';
$txt['attach_warning'] = 'There was a problem during the uploading of <strong>%1$s</strong>.';
$txt['attach_max_total_file_size'] = 'Sorry, you are out of attachment space. The total attachment size allowed per post is %1$s KB. Space remaining is %2$s KB.';
$txt['attach_folder_warning'] = 'The attachments directory can not be located. Please notify an administrator of this problem.';
$txt['attach_folder_admin_warning'] = 'The path to the attachments directory (%1$s) is incorrect. Please correct it in the attachment settings area of your admin panel.';
$txt['attach_limit_nag'] = 'You have reached the maximum number of attachments allowed per post.';
$txt['attach_no_upload'] = 'There was a problem and your attachments could not be uploaded';
$txt['attach_remaining'] = '%1$d remaining';
$txt['attach_available'] = '%1$s KB available';
$txt['attach_kb'] = ' (%1$s KB)';
$txt['attach_0_byte_file'] = 'The file appears to be empty. Please contact your forum administrator if this continues to be a problem';
$txt['attached_files_in_session'] = '<em>The above underlined file(s) have been uploaded but will not be attached to this post until it is submitted.</em>';

$txt['attach_php_error'] = 'Due to an error, your attachment could not be uploaded. Please contact the forum administrator if this problem continues.';
$txt['php_upload_error_1'] = 'The uploaded file exceeds the upload_max_filesize directive in php.ini. Please contact your host if you are unable to correct this issue.';
$txt['php_upload_error_3'] = 'The uploaded file was only partially uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_4'] = 'No file was uploaded. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_6'] = 'Unable to save. Missing a temporary directory. Please contact your host if you are unable to correct this problem.';
$txt['php_upload_error_7'] = 'Failed to write file to disk. This is a PHP related error. Please contact your host if this problem continues.';
$txt['php_upload_error_8'] = 'A PHP extension stopped the file upload. This is a PHP related error. Please contact your host if this problem continues.';
$txt['error_temp_attachments_new'] = 'There are attachments which you had previously attached but not posted. These attachments are still attached to this post. This post does need to be submitted before these attachments are either saved or removed. You <a href="#postAttachment">can do that here</a>';
$txt['error_temp_attachments_found'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not post until these are either removed or that post has been submitted.<br />Click <a href="%1$s">here to remove </a>those attachments. Or <a href="%2$s">here to return to that post</a>.%3$s';
$txt['error_temp_attachments_lost'] = 'The following attachments were found which you had previously attached to another post but not posted. It is advisable that you do not upload any more attachments until these are removed or that post has been submitted.<br />Click <a href="%1$s">here to remove these attachments</a>.%2$s';
$txt['error_temp_attachments_gone'] = 'Those attachments have now been removed and you have been returned to the page you were previously on';
$txt['error_temp_attachments_flushed'] = 'Please note that any files which had been previously attached, but not posted, have now been removed.';
$txt['error_topic_already_announced'] = 'Please note that this topic has already been announced.';

$txt['cant_access_upload_path'] = 'Ne mogu da pristupim putanji za dostavu priloženih datoteka!';
$txt['file_too_big'] = 'Your file is too large. The maximum attachment size allowed is %1$s KB.';
$txt['attach_timeout'] = 'Datoteka koju ste priložili nije sačuvana. Ovo se dogodilo jer je prilaganje trajalo predugo ili je datoteka veća nego što to server dozvoljava.<br /><br />Za više informacija, konsultujte administratora servera.';
$txt['bad_attachment'] = 'Priložena datoteka nije prošla sigurnosnu proveru i ne može biti dostavljena. Molimo, kontaktirajte administratora.';
$txt['ran_out_of_space'] = 'The upload directory is full. Please contact an administrator about this problem.';
$txt['attachments_no_write'] = 'Direktorijum za dostavu priloženih datoteka nije otvoren za pisanje. Datoteka koju ste priložili ili avatar ne može da bude sačuvan.';
$txt['attachments_no_create'] = 'Unable to create a new attachment directory.  Your attachment or avatar cannot be saved.';
$txt['attachments_limit_per_post'] = 'Ne možete da priložite više od %d datoteka po poruci';

// Post settings (when I implement the post interface)
$txt['ila_insert'] = 'Insert Attachment %1$d in the message';
$txt['ila_title'] = 'End-of-post expandable thumbnail ';
$txt['insert'] = 'Insert';
$txt['ila_opt_size'] = 'Veličina';
$txt['ila_opt_align'] = 'Alignment';
$txt['ila_opt_size_thumb'] = 'Thumbnail';
$txt['ila_option2'] = 'Text link';
$txt['ila_option3'] = 'Short text link';
$txt['ila_opt_size_full'] = 'Full size';
$txt['ila_opt_size_cust'] = 'Custom size';
$txt['ila_opt_align_none'] = 'Bez';
$txt['ila_opt_align_left'] = 'Left';
$txt['ila_opt_align_right'] = 'Right';
$txt['ila_opt_align_center'] = 'Center';
$txt['ila_confirm_removal'] = 'Are you sure you want to remove permanently this attachment?';
/*
$txt['ila_thereare'] = 'There are only';
$txt['ila_attachment'] = 'attachment(s)';
$txt['ila_none'] = 'as expandable thumbnail';
$txt['ila_img'] = 'as full-size graphic';
$txt['ila_url'] = 'as a link';
$txt['ila_mini'] = 'as a compact link';
*/