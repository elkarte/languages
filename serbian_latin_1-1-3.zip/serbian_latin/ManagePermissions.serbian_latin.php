<?php
// Version: 1.1; ManagePermissions

$txt['permissions_title'] = 'Upravljanje dozvolama';
$txt['permissions_modify'] = 'Izmeni';
$txt['permissions_view'] = 'Prikaži';
$txt['permissions_allowed'] = 'Dozvoljene';
$txt['permissions_denied'] = 'Onemogućene';
$txt['permission_cannot_edit'] = '<strong>Note:</strong> You cannot edit this permission profile as it is a predefined profile included within the forum software by default. If you wish to change the permissions of this profile you must first create a duplicate profile. You can <a href="%1$s">carry out this task by clicking here</a>.';

$txt['permissions_for_profile'] = 'Dozvole za profil';
$txt['permissions_boards_desc'] = 'Spisak prikazuje koji je skup dozvola dodeljen kom forumu. Možete da izmenite dodeljen profil dozvola klikom na ime foruma ili odabirom opcije &quot;izmeni sve&quot; na dnu stranice. Da biste izmenili pojedinačne profile, kliknite na njihovo ime.';
$txt['permissions_board_all'] = 'Izmeni sve';
$txt['permission_profile'] = 'Profil dozvola';
$txt['permission_profile_desc'] = 'Which <a target="_blank" href="%1$s">permission set</a> the board should use.';
$txt['permission_profile_inherit'] = 'Nasledi od roditeljskog foruma';

$txt['permissions_profile'] = 'Profil';
$txt['permissions_profiles_desc'] = 'Profili dozvola su dodeljeni pojedinačnim forumima radi lakšeg upravljanja bezbednosnim podešavanjima. Odavde možete da napravite, izmenite ili izbrišete profile dozvola.';
$txt['permissions_profiles_change_for_board'] = 'Izmeni profile dozvola za: &quot;%1$s&quot;';
$txt['permissions_profile_default'] = 'Uobičajeno';
$txt['permissions_profile_no_polls'] = 'Bez anketa';
$txt['permissions_profile_reply_only'] = 'Samo odgovaranje';
$txt['permissions_profile_read_only'] = 'Samo čitanje';

$txt['permissions_profile_rename'] = 'Rename all';
$txt['permissions_profile_edit'] = 'Izmeni profile';
$txt['permissions_profile_new'] = 'Nov profil';
$txt['permissions_profile_new_create'] = 'Napravi';
$txt['permissions_profile_name'] = 'Ime profila';
$txt['permissions_profile_used_by'] = 'Koristi ga';
$txt['permissions_profile_used_by_one'] = '1 forum';
$txt['permissions_profile_used_by_many'] = '%1$d foruma';
$txt['permissions_profile_used_by_none'] = 'nijedan forum';
$txt['permissions_profile_do_edit'] = 'Izmeni';
$txt['permissions_profile_do_delete'] = 'Obriši';
$txt['permissions_profile_copy_from'] = 'Kopiraj dozvole od';

$txt['permissions_includes_inherited'] = 'Nasleđene grupe';
$txt['permissions_includes_inherited_from'] = 'Inherited from: ';

$txt['permissions_all'] = 'sve';
$txt['permissions_none'] = 'nijedna';
$txt['permissions_set_permissions'] = 'Postavi dozvole';

$txt['permissions_advanced_options'] = 'Napredne opcije';
$txt['permissions_with_selection'] = 'Nad odabranim';
$txt['permissions_apply_pre_defined'] = 'Primeni predefinisani profil dozvola';
$txt['permissions_select_pre_defined'] = 'Izaberite predefinisani profil';
$txt['permissions_copy_from_board'] = 'Kopiraj dozvole od ovog foruma';
$txt['permissions_select_board'] = 'Izaberite forum';
$txt['permissions_like_group'] = 'Postavi dozvole kao ova grupa';
$txt['permissions_select_membergroup'] = 'Select a member group';
$txt['permissions_add'] = 'Dodaj dozvolu';
$txt['permissions_remove'] = 'Ukloni dozvolu';
$txt['permissions_deny'] = 'Onemogući dozvolu';
$txt['permissions_select_permission'] = 'Izaberite dozvolu';

// All of the following block of strings should not use entities, instead use \\" for &quot; etc.
$txt['permissions_only_one_option'] = 'Možete da izaberete samo jednu akciju da biste promenili dozvole';
$txt['permissions_no_action'] = 'Akcija nije izabrana';
$txt['permissions_deny_dangerous'] = 'Upravo ćete da onemogućite jednu ili više dozvola.\\nOvo može da bude opasno i izazove neočekivane rezultate ako niste sigurni da niko \\"slučajno\\" nije u grupi ili grupama kojima onemogućavate dozvole.\\n\\nDa li ste sigurni da želite da nastavite?';

$txt['permissions_modify_group'] = 'Izmeni grupu';
$txt['permissions_general'] = 'Dozvole po grupama članova';
$txt['permissions_board'] = 'Globalne dozvole foruma';
$txt['permissions_board_desc'] = '<strong>Pažnja</strong>: izmena ovih dozvola će uticati na sve forume koji trenutno imaju dodeljen &quot;Podrazumevani&quot; profil dozvola. Forumi koji ne koriste &quot;podrazumevani&quot; profil ostaće nepromenjeni.';
$txt['permissions_commit'] = 'Sačuvaj promene';
$txt['permissions_on'] = 'na forumu';
$txt['permissions_local_for'] = 'Lokalne dozvole za grupu';
$txt['permissions_option_on'] = 'D';
$txt['permissions_option_off'] = 'N';
$txt['permissions_option_deny'] = 'O';
$txt['permissions_option_desc'] = 'For each permission you can pick either \'Allow\' (A), \'Disallow\' (X), or <span class="alert">\'Deny\' (D)</span>.<br /><br />Remember that if you deny a permission, any member - whether moderator or otherwise - that is in that group will be denied that as well.<br />For this reason, you should use deny carefully, only when <strong>necessary</strong>. Disallow, on the other hand, denies unless otherwise granted.';

$txt['permissiongroup_general'] = 'Opšte';
$txt['permissionname_view_stats'] = 'Gledanje statistike foruma';
$txt['permissionhelp_view_stats'] = 'Statistika foruma je stranica koja prikazuje svu statistiku foruma kao što je broj članova, broj poruka po danu i nekoliko drugih top 10 stavki. Omogućavanje ove dozvole dodaće link pri dnu početne strane foruma (\'[više statistike]\').';
$txt['permissionname_view_mlist'] = 'View the member list and groups';
$txt['permissionhelp_view_mlist'] = 'The member list shows all members that have registered on your forum. The list can be sorted and searched. The member list is linked from both the board index and the stats page, by clicking on the number of members. It also applies to the groups page which is a mini memberlist of people in that group.';
$txt['permissionname_who_view'] = 'Gledanje spiska "Ko je prisutan"';
$txt['permissionhelp_who_view'] = 'Ko je prisutan prikazuje sve članove koji su trenutno na mreži i šta trenutno rade. Ova dozvola će raditi jedino ako ste je omogućili u \'Mogućnostima i opcijama\'. Ovoj stranici možete da pristupite klikom na link u odeljku \'Prisutni korisnici\' na početnoj strani foruma.';
$txt['permissionname_search_posts'] = 'Pretraživanje poruka i korisnika';
$txt['permissionhelp_search_posts'] = 'Dozvola za pretragu omogućava korisniku da pretražuje sve forume kojima može da pristupi. Ukoliko je pretraga moguća, pojaviće se dugme za pretragu u meniju foruma.';
$txt['permissionname_karma_edit'] = 'Promena ugleda drugih ljudi';
$txt['permissionhelp_karma_edit'] = 'Karma is a feature that shows the popularity of a member. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to cast a vote. This permission has no effect on guests.';
$txt['permissionname_like_posts'] = 'Like other users\' posts';
$txt['permissionhelp_like_posts'] = 'Likes is a feature that shows the popularity of a post. In order to use this feature, you need to have it enabled in \'Features and Options\'. This permission will allow a member group to like a post or unlike one they previously liked.  This permission has no effect on guests.';
$txt['permissionname_like_posts_stats'] = 'See like posts stats';
$txt['permissionhelp_like_posts_stats'] = 'This will allow users to see stats of posts liking';
$txt['permissionname_disable_censor'] = 'Disable word censor';
$txt['permissionhelp_disable_censor'] = 'Allows members the option to disable the word censor.';

$txt['permissiongroup_pm'] = 'Privatne poruke';
$txt['permissionname_pm_read'] = 'Čitanje privatnih poruka';
$txt['permissionhelp_pm_read'] = 'Ova dozvola omogućava korisnicima da pristupe i čitaju svoje privatne poruke. Bez ove dozvole, korisnici neće moći ni da šalju privatne poruke.';
$txt['permissionname_pm_send'] = 'Slanje privatnih poruka';
$txt['permissionhelp_pm_send'] = 'Slanje privatnih poruka ostalim registrovanim članovima. Zahteva dozvolu \'Čitanje privatnih poruka\'.';
$txt['permissionname_send_email_to_members'] = 'Send emails';
$txt['permissionhelp_send_email_to_members'] = 'Send emails to other registered members.';

$txt['permissiongroup_calendar'] = 'Kalendar';
$txt['permissionname_calendar_view'] = 'Gledanje kalendara';
$txt['permissionhelp_calendar_view'] = 'Kalendar prikazuje rođendane, događaje i praznike za svaki mesec. Ova dozvola omogućava pristup kalendaru. Ukoliko je ova dozvola omogućena, prikazaće se odgovarajući link u meniju foruma zajedno sa spiskom predstojećih događaja na početnoj strani foruma. Kalendar mora da bude omogućen u \'Podešavanja - Osnovne Mogućnosti\'.';
$txt['permissionname_calendar_post'] = 'Kreiranje događaja u kalendaru';
$txt['permissionhelp_calendar_post'] = 'Događaj je tema vezana za određeni datum ili opseg datuma. Pravljenje događaja je moguće u kalendaru. Događaj može da bude napravljen samo ako korisnik koji pravi događaj može da postavlja nove teme.';
$txt['permissionname_calendar_edit'] = 'Uređivanje događaja u kalendaru';
$txt['permissionhelp_calendar_edit'] = 'Događaj je tema vezana za određeni datum ili opseg datuma. Događaji mogu da se izmene klikom na crvenu zvezdicu (*) pored događaja u kalendaru. Da bi izmenio događaj, korisnik mora da ima dovoljne dozvole da izmeni prvu poruku u temi koja je vezana sa događajem.';
$txt['permissionname_calendar_edit_own'] = 'Sopstveni događaji';
$txt['permissionname_calendar_edit_any'] = 'Bilo koji događaji';

$txt['permissiongroup_maintenance'] = 'Administracija foruma';
$txt['permissionname_admin_forum'] = 'Administriranje foruma i baze podataka';
$txt['permissionhelp_admin_forum'] = 'Ova dozvola omogućava korisniku da:<ul class="normallist"><li>menja forum, bazu podataka i podešavanja tema</li><li>upravlja paketima</li><li>koristi alate za održavanje foruma i baze podataka</li><li>pregleda dnevnik grešaka i uređivanja</li></ul> Koristite ovu dozvolu sa oprezom pošto je veoma moćna.';
$txt['permissionname_manage_boards'] = 'Uređivanje foruma i kategorija';
$txt['permissionhelp_manage_boards'] = 'Ova dozvola omogućava pravljenje, izmenu i uklanjanje foruma i kategorija.';
$txt['permissionname_manage_attachments'] = 'Upravljanje priloženim datotekama i avatarima';
$txt['permissionhelp_manage_attachments'] = 'Ova dozvola omogućava pristup pregledu priloženih datoteka, gde su prikazane sve priložene datoteke i avatari na forumu odakle se mogu i ukloniti.';
$txt['permissionname_manage_smileys'] = 'Upravljanje smajlijima i ikonama poruka';
$txt['permissionhelp_manage_smileys'] = 'Ova dozvola omogućava pristup uređivanju smajlija. Dozvoljeno je dodavanje, izmena i uklanjanje smajlija i postavki smajlija. Ukoliko su omogućene i prilagođene ikone poruka, korisnik sa ovom dozvolom može i da dodaje i menja ove ikone.';
$txt['permissionname_edit_news'] = 'Uređivanje vesti';
$txt['permissionhelp_edit_news'] = 'The news function allows a random news line to appear on each screen. In order to use the news function, enable it in the forum settings.';
$txt['permissionname_access_mod_center'] = 'Pristup uredničkom centru';
$txt['permissionhelp_access_mod_center'] = 'Svim korisnicima sa ovom dozvolom je omogućen pristup uredničkom centru odakle mogu da pristup opcijama koje im mogu olakšati uređivanje. Pažnja: ova opcija samo po sebi ne daje nikakve uredničke privilegije.';

$txt['permissiongroup_member_admin'] = 'Administracija članova';
$txt['permissionname_moderate_forum'] = 'Uređivanje članova foruma';
$txt['permissionhelp_moderate_forum'] = 'Ova dozvola uključuje sve važne funkcije za uređivanje članova:<ul class="normallist"><li>pristup opcijama za registraciju</li><li>prikaz i brisanje članova</li><li>proširen prikaz informacija u profilu uključujući i opciju za praćenje IP-a/korisnika i (skrivenih) statusa prisutnosti</li><li>aktiviranje naloga</li><li>dobijanje obaveštenja o odobrenju kao i odobravanje naloga</li><li>imunost na ignorisanje privatnih poruka</li><li>još nekoliko manjih stvari</li></ul>';
$txt['permissionname_manage_membergroups'] = 'Upravljanje i dodeljivanje grupa članova';
$txt['permissionhelp_manage_membergroups'] = 'Ova dozvola omogućava korisnicima da menjaju grupe članova i dodaju nove korisnike u postojeće grupe članova.';
$txt['permissionname_manage_permissions'] = 'Upravljanje dozvolama';
$txt['permissionhelp_manage_permissions'] = 'Ova dozvola omogućava korisniku da menja sve dozvole grupa članova, opšte ili specifične za određene forume.';
$txt['permissionname_manage_bans'] = 'Upravljanje spiskom zabrana';
$txt['permissionhelp_manage_bans'] = 'This permission allows a user to add or remove user names, IP addresses, hostnames and email addresses to or from a list of banned users. It also allows a user to view and remove log entries of banned users that attempted to login.';
$txt['permissionname_send_mail'] = 'Broadcast to multiple members';
$txt['permissionhelp_send_mail'] = 'Mass mail all forum members or just a few member groups by email or personal message (the latter requires the \'Send Personal Message\' permission).';
$txt['permissionname_issue_warning'] = 'Upozoravanje članova';
$txt['permissionhelp_issue_warning'] = 'Upozoravanje članova foruma i promena nivoa njihovog upozorenja. Zahteva da sistem za upozoravanje bude omogućen.';

$txt['permissiongroup_profile'] = 'Profili članova';
$txt['permissionname_profile_view'] = 'Gledanje profila i statistike';
$txt['permissionhelp_profile_view'] = 'This permission allows users clicking on a user name to see a summary of profile settings, some statistics and all posts of the user.';
$txt['permissionname_profile_view_own'] = 'Svog profila';
$txt['permissionname_profile_view_any'] = 'Bilo kog profila';
$txt['permissionname_profile_identity'] = 'Izmena podešavanja naloga';
$txt['permissionhelp_profile_identity'] = 'Account settings are the basic settings of a profile, like password, email address, member group and preferred language.';
$txt['permissionname_profile_identity_own'] = 'Svog profila';
$txt['permissionname_profile_identity_any'] = 'Bilo kog profila';
$txt['permissionname_profile_extra'] = 'Izmena dodatnih podešavanja profila';
$txt['permissionhelp_profile_extra'] = 'Dodatna podešavanja profila uključuje opcije poput avatara, podešavanja tema, obaveštavanja i privatnih poruka.';
$txt['permissionname_profile_extra_own'] = 'Svog profila';
$txt['permissionname_profile_extra_any'] = 'Bilo kog profila';
$txt['permissionname_profile_title'] = 'Izmena prilagođenog naziva';
$txt['permissionhelp_profile_title'] = 'Prilagođeni naziv se prikazuje pri pregledu teme, ispod korisničkog imena korisnika koji imaju prilagođeni naziv.';
$txt['permissionname_profile_title_own'] = 'Svog profila';
$txt['permissionname_profile_title_any'] = 'Bilo kog profila';
$txt['permissionname_profile_remove'] = 'Brisanje naloga';
$txt['permissionhelp_profile_remove'] = 'Ova dozvola omogućava korisniku da obriše svoj nalog ukoliko je podešena na \'svoj nalog\'.';
$txt['permissionname_profile_remove_own'] = 'Svog naloga';
$txt['permissionname_profile_remove_any'] = 'Bilo kog naloga';
$txt['permissionname_profile_set_avatar'] = 'Izaberi avatara';
$txt['permissionhelp_profile_set_avatar'] = 'If enabled this will allow a user to select an avatar.';

$txt['permissiongroup_general_board'] = 'Opšte';
$txt['permissionname_moderate_board'] = 'Uređivanje foruma';
$txt['permissionhelp_moderate_board'] = 'Dozvola za uređivanje foruma dodaje nekoliko manjih dozvola koje čini urednika pravim urednikom. Dozvole uključuju mogućnost odgovaranja na zaključane teme, izmena datuma isticanja anketa kao i prikaz rezultata anketa.';

$txt['permissiongroup_topic'] = 'Teme';
$txt['permissionname_post_new'] = 'Postavljanje nove teme';
$txt['permissionhelp_post_new'] = 'Ova dozvola omogućava korisniku da postavlja nove teme. Ne dozvoljava slanje odgovora na teme.';
$txt['permissionname_merge_any'] = 'Spajanje tema';
$txt['permissionhelp_merge_any'] = 'Merge two or more topics into one. The order of messages within the merged topic will be based on the time the messages were created. A user can only merge topics on those boards a user is allowed to merge. In order to merge multiple topics at once, a user has to enable quick moderation in their profile settings.';
$txt['permissionname_split_any'] = 'Deljenje tema';
$txt['permissionhelp_split_any'] = 'Deljenje teme na dve različite teme.';
$txt['permissionname_send_topic'] = 'Slanje teme prijateljima';
$txt['permissionhelp_send_topic'] = 'Ova dozvola omogućava korisniku da pošalje mejl prijatelju sa linkom do određene teme, unošenjem njihove imejl adrese. Dozvoljava i dodavanje prilagođene poruke poslatom mejlu.';
$txt['permissionname_make_sticky'] = 'Zakaci teme';
$txt['permissionhelp_make_sticky'] = 'Pinned topics are topics that always remain on top of a board. They can be useful for announcements or other important messages.';
$txt['permissionname_move'] = 'Move topics';
$txt['permissionhelp_move'] = 'Premeštanje tema iz jednog foruma u drugi. Korisnici mogu da izaberu premeštaju samo u one forume kojima imaju pristup.';
$txt['permissionname_move_own'] = 'Na svoje teme';
$txt['permissionname_move_any'] = 'Na bilo koje teme';
$txt['permissionname_lock'] = 'Zaključavanje tema';
$txt['permissionhelp_lock'] = 'This permission allows a user to lock a topic. This can be done in order to make sure no one can reply to a topic. Only users with a \'Moderate board\' permission can still post in locked topics.';
$txt['permissionname_lock_own'] = 'Na svoje teme';
$txt['permissionname_lock_any'] = 'Na bilo koje teme';
$txt['permissionname_remove'] = 'Uklanjanje tema';
$txt['permissionhelp_remove'] = 'Uklanjanje tema u celini. Ovo ne dozvoljava korisniku da obriše prvu poruku teme.';
$txt['permissionname_remove_own'] = 'Na svoje teme';
$txt['permissionname_remove_any'] = 'Bilo kojih tema';
$txt['permissionname_post_reply'] = 'Slanje odgovora';
$txt['permissionhelp_post_reply'] = 'Ova dozvola omogućava slanje odgovora na teme.';
$txt['permissionname_post_reply_own'] = 'Na svoje teme';
$txt['permissionname_post_reply_any'] = 'Na bilo koje teme';
$txt['permissionname_modify_replies'] = 'Izmena odgovora na svoje teme';
$txt['permissionhelp_modify_replies'] = 'Ova dozvola omogućava korisniku koji je pokrenuo temu da menja odgovore na svoje teme.';
$txt['permissionname_delete_replies'] = 'Brisanje odgovora na svoje teme';
$txt['permissionhelp_delete_replies'] = 'Ova dozvola omogućava korisniku koji je pokrenuo temu da obriše sve odgovore na svoju temu.';
$txt['permissionname_announce_topic'] = 'Objavi temu';
$txt['permissionhelp_announce_topic'] = 'This allows a user to send an announcement email about a topic to all members or to a few member groups.';

$txt['permissionname_approve_emails'] = 'Moderate Post by Email Failures';
$txt['permissionhelp_approve_emails'] = 'Allow moderators to access the Post by Email failure log to perform actions including approve, delete, view and bounce.  Note, since the system may not always know what board a post goes to, this permission should be only be given to members with full board access';
$txt['permissionname_postby_email'] = 'Post by Email';
$txt['permissionhelp_postby_email'] = 'This permission allows users to start new topics as well as reply to topic and PM notifications by email.';

$txt['permissiongroup_post'] = 'poruka';
$txt['permissionname_delete'] = 'Brisanje poruka';
$txt['permissionhelp_delete'] = 'Uklanjanje poruka. Pažnja: ova dozvola ne omogućava brisanje pojedinačnih poruka unutar teme!';
$txt['permissionname_delete_own'] = 'Svojih poruka';
$txt['permissionname_delete_any'] = 'Bilo kojih poruka';
$txt['permissionname_modify'] = 'Izmena poruka';
$txt['permissionhelp_modify'] = 'Izmena poruka';
$txt['permissionname_modify_own'] = 'Svojih poruka';
$txt['permissionname_modify_any'] = 'Bilo kojih poruka';
$txt['permissionname_report_any'] = 'Prijavljivanje poruka urednicima';
$txt['permissionhelp_report_any'] = 'Ova dozvola dodaje vezu svakoj poruci koja omogućava korisniku da prijavi poruku urednicima. Nakon prijavljivanja, svi urednici foruma će primiti imejl sa vezom do prijavljene poruke i opisom problema (ako je dat od korisnika koji je prijavio).';

$txt['permissiongroup_poll'] = 'Ankete';
$txt['permissionname_poll_view'] = 'Gledanje anketa';
$txt['permissionhelp_poll_view'] = 'Ova dozvola omogućava korisniku da vidi anketu. Bez ove dozvole, korisnik će videti samo temu.';
$txt['permissionname_poll_vote'] = 'Glasanje u anketama';
$txt['permissionhelp_poll_vote'] = 'Ova dozvola omogućava (registrovanom) korisniku da glasa u anketi. Dozvola se ne može primeniti na goste.';
$txt['permissionname_poll_post'] = 'Postavljanje anketa';
$txt['permissionhelp_poll_post'] = 'Ova dozvola omogućava korisniku da postavi novu anketu. Korisnik mora da ima i dozvolu za \'Postavljanje novih tema\'.';
$txt['permissionname_poll_add'] = 'Dodavanje anketa temama';
$txt['permissionhelp_poll_add'] = 'Dodavanje anketa temama dozvoljava korisniku da doda anketu temi nakon njenog slanja. Ova dozvola zahteva određena prava za izmenu prve poruke u temi.';
$txt['permissionname_poll_add_own'] = 'Svojim temama';
$txt['permissionname_poll_add_any'] = 'Bilo kojih tema';
$txt['permissionname_poll_edit'] = 'Uređivanje anketa';
$txt['permissionhelp_poll_edit'] = 'Ova dozvola omogućava izmenu opcija ankete kao i resetovanje ankete. Da bi izmenio najveći broj glasova i vreme isteka, korisnik mora da ima dozvolu za \'Uređivanje foruma\'.';
$txt['permissionname_poll_edit_own'] = 'Svojih anketa';
$txt['permissionname_poll_edit_any'] = 'Bilo kojih anketa';
$txt['permissionname_poll_lock'] = 'Zaključavanje anketa';
$txt['permissionhelp_poll_lock'] = 'Zaključavanje anketa sprečava dalje glasanje u njoj.';
$txt['permissionname_poll_lock_own'] = 'Svojih anketa';
$txt['permissionname_poll_lock_any'] = 'Bilo kojih anketa';
$txt['permissionname_poll_remove'] = 'Uklanjanje anketa';
$txt['permissionhelp_poll_remove'] = 'Ova dozvola omogućava uklanjanje anketa.';
$txt['permissionname_poll_remove_own'] = 'Svojih anketa';
$txt['permissionname_poll_remove_any'] = 'Bilo kojih anketa';

// translator note: so many duplicates here? you might want to remove some...:
$txt['permissionname_post_draft'] = 'Save drafts of new posts';
$txt['permissionname_simple_post_draft'] = 'Save drafts of new posts';
$txt['permissionhelp_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionhelp_simple_post_draft'] = 'This permission allows users to save drafts of their posts so they can complete them later.';
$txt['permissionname_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionname_simple_post_autosave_draft'] = 'Automatically save drafts of new posts';
$txt['permissionhelp_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionname_simple_pm_autosave_draft'] = 'Automatically save drafts of new PMs';
$txt['permissionhelp_pm_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid losing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionhelp_simple_post_autosave_draft'] = 'This permission allows users to have their posts autosaved as drafts so they can avoid loosing their work in the event of a timeout, disconnection or other error.  The autosave schedule is defined in the admin panel';
$txt['permissionname_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionname_simple_pm_draft'] = 'Save drafts of personal messages';
$txt['permissionhelp_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';
$txt['permissionhelp_simple_pm_draft'] = 'This permission allows users to save drafts of their personal messages so they can complete them later.';

$txt['permissiongroup_approval'] = 'Uređivanje poruka';
$txt['permissionname_approve_posts'] = 'Odobravanje stavki';
$txt['permissionhelp_approve_posts'] = 'Ova dozvola omogućava korisniku da odobri sve neodobrene stavke na forumu.';
$txt['permissionname_post_unapproved_replies'] = 'Slanje neodobrenih poruka';
$txt['permissionhelp_post_unapproved_replies'] = 'Ova opcija dozvoljava korisniku da palje odgovore na poruke koje se neće prikazivati dok ih ne odobri urednik.';
$txt['permissionname_post_unapproved_replies_own'] = 'Na svoje teme';
$txt['permissionname_post_unapproved_replies_any'] = 'Na bilo koje teme';
$txt['permissionname_post_unapproved_topics'] = 'Slanje neodobrenih tema';
$txt['permissionhelp_post_unapproved_topics'] = 'Ova dozvola omogućava korisniku da postavi novu temu koja zahteva odobrenje urednika pre prikazivanja ostalim korisnicima.';
$txt['permissionname_post_unapproved_attachments'] = 'Slanje neodobrenih priloženih datoteka';
$txt['permissionhelp_post_unapproved_attachments'] = 'Ova dozvola omogućava korisniku da priloži datoteke svojim porukama koje zahtevaju odobrenje urednika pre prikazivanja ostalim korisnicima.';

$txt['permissiongroup_notification'] = 'Obaveštenja';
$txt['permissionname_mark_any_notify'] = 'Zahtevanje obaveštavanja kod odgovora';
$txt['permissionhelp_mark_any_notify'] = 'Ova opcija dozvoljava korisniku da prima obaveštenja svaki put kada neko odgovori na temu na koju su se preplatili.';
$txt['permissionname_mark_notify'] = 'Zahtev za obaveštavanje o novim temama';
$txt['permissionhelp_mark_notify'] = 'Obaveštenje o novim temama je opcija koja omogućava korisniku da prima mejlove sa obaveštenjem svaki put kada se napravi nova tema na forumu na koji su se pretplatili.';

$txt['permissiongroup_attachment'] = 'Priložene datoteke';
$txt['permissionname_view_attachments'] = 'Gledanje priloženih datoteka';
$txt['permissionhelp_view_attachments'] = 'Priložene datoteke su datoteke zakačene uz poruke. Ova mogućnost može da bude omogućena i podešena u \'Mogućnostima i opcijama\'. Pošto se priloženim datotekama ne pristupa direktno, možete da sprečite korisnike bez određene dozvole da ih preuzmu.';
$txt['permissionname_post_attachment'] = 'Slanje priloženih datoteka';
$txt['permissionhelp_post_attachment'] = 'Priložene datoteke su datoteke priložene uz poruke. Jedna poruka može da sadrži više priloženih datoteka.';

$txt['permissionicon'] = '';

$txt['permission_settings_title'] = 'Podešavanja dozvola';
$txt['groups_manage_permissions'] = 'Member groups allowed to manage permissions';
$txt['permission_enable_deny'] = 'Omogući opciju za onemogućavanje dozvola';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_deny_warning'] = 'Isključivanje ove opcije će prouzrokovati ažuriranje \\\'onemogućenih\\\' dozvola na \\\'nedozvoljene\\\'.';
$txt['permission_by_board_desc'] = 'Here you can set which permission profile a board uses. You can create new permission profiles from the &quot;Edit Profiles&quot; menu.';
$txt['permission_settings_desc'] = 'Ovde možete da promenite ko ima dozvolu da menja dozvole kao i koliko bi sistem dozvola trebalo da bude sofisticiran.';
$txt['permission_enable_postgroups'] = 'Omogući dozvole za grupe zasnovane na broju poruka';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['permission_disable_postgroups_warning'] = 'Onemogućavanje ovog podešavanja će ukloniti trenutno podešene dozvole za grupe zasnovane na broju poruka.';

$txt['permissions_post_moderation_desc'] = 'From this page you can easily change which groups have their posts moderated for a particular permission profile.';
$txt['permissions_post_moderation_deny_note'] = 'Bez obzira što imate omogućene napredne dozvole, ne možete da primenite &quot;onemogućene&quot; dozvole sa ove strane. Moraćete direktno da izmenite dozvole ukoliko želite da primenite onemogućene dozvole.';
$txt['permissions_post_moderation_select'] = 'Izaberite profil';
$txt['permissions_post_moderation_new_topics'] = 'Nove teme';
$txt['permissions_post_moderation_replies_own'] = 'Svoji odgovori';
$txt['permissions_post_moderation_replies_any'] = 'Bilo čiji odgovori';
$txt['permissions_post_moderation_attachments'] = 'Priložene datoteke';
$txt['permissions_post_moderation_legend'] = 'Legenda';
$txt['permissions_post_moderation_allow'] = 'Može da napravi';
$txt['permissions_post_moderation_moderate'] = 'Može da napravi ali zahteva odobravanje';
$txt['permissions_post_moderation_disallow'] = 'Ne može da napravi';
$txt['permissions_post_moderation_group'] = 'Grupa';

$txt['auto_approve_topics'] = 'Post new topics without requiring approval';
$txt['auto_approve_replies'] = 'Post replies to topics without requiring approval';
$txt['auto_approve_attachments'] = 'Post attachments without requiring approval';
