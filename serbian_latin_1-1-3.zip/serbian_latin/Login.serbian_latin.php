<?php
// Version: 1.1; Login

// Registration agreement page.
$txt['registration_agreement'] = 'Sporazum o registraciji';
$txt['registration_privacy_policy'] = 'Privacy Policy';
$txt['agreement_agree'] = 'Prihvatam sporazum o registraciji.';
$txt['agreement_no_agree'] = 'I do not accept the terms of the agreement.';
$txt['policy_agree'] = 'I accept the terms of the privacy policy.';
$txt['policy_no_agree'] = 'I do not accept the terms of the privacy policy.';
$txt['agreement_agree_coppa_above'] = 'Prihvatam sporazum o registraciji i imam najmanje %1$d godina.';
$txt['agreement_agree_coppa_below'] = 'Prihvatam sporazum o registraciji i mlađi sam od %1$d godina.';
$txt['agree_coppa_above'] = 'Imam najmanje %1$d godina.';
$txt['agree_coppa_below'] = 'Mladji sam od %1$d godina.';

// Registration form.
$txt['registration_form'] = 'Obrazac za registraciju';
$txt['error_too_quickly'] = 'Prošli ste kroz proces registracije prebrzo, brže nego sto bi normalno bilo moguće. Sačekajte malo i pokušajte opet.';
$txt['error_token_verification'] = 'Potvrda novčića/tokena neuspela. Pokušajte opet.';
$txt['need_username'] = 'Morate da unesete korisničko ime.';
$txt['no_password'] = 'Niste uneli svoju lozinku.';
$txt['improper_password'] = 'Data lozinka je predugačka.';
$txt['incorrect_password'] = 'Pogrešna lozinka';
$txt['openid_not_found'] = 'Dati OpenID identifikator nije pronadjen';
$txt['maintain_mode'] = 'Mod održavanja';
$txt['registration_successful'] = 'Registracija je uspešna';
$txt['valid_email_needed'] = 'Molim vas unesite ispravnu imejl adresu, %1$s.';
$txt['required_info'] = 'Zahtevane informacije';
$txt['additional_information'] = 'Dodatne informacije';
$txt['warning'] = 'Upozorenje!';
$txt['only_members_can_access'] = 'Samo registrovani članovi mogu da pristupe ovom delu.';
$txt['login_below'] = 'Prijavite se ispod.';
$txt['login_below_or_register'] = 'Prijavite se ispod ili <a href="%1$s">se registrujte</a> sa %2$s';
$txt['checkbox_agreement'] = 'Prihvatam sporazum o registraciji.';
$txt['checkbox_privacypol'] = 'I accept the privacy policy';
$txt['confirm_request_accept_agreement'] = 'Are you sure you want to force all members to accept the agreement?';
$txt['confirm_request_accept_privacy_policy'] = 'Are you sure you want to force all members to accept the privacy policy?';

$txt['login_hash_error'] = 'Bezbednost lozinki je skoro ažurirana.<br />Molimo vas, ponovo unesite svoju lozinku.';

$txt['ban_register_prohibited'] = 'Izvinite ali vam nije dozvoljeno da se registrujete na ovaj forum.';
$txt['under_age_registration_prohibited'] = 'Izvinite ali korisnicima mlađim od %1$s godina nije dozvoljeno da se registruju na ovaj forum.';

$txt['activate_account'] = 'Aktivacija naloga';
$txt['activate_success'] = 'Vaš nalog je uspešno aktiviran. Sada možete da se prijavite.';
$txt['activate_not_completed1'] = 'Vaša imejl adresa mora da bude potvrđena pre nego što se prijavite.';
$txt['activate_not_completed2'] = 'Potreban vam je još jedan aktivacioni mejl?';
$txt['activate_after_registration'] = 'Zahvaljujemo se na registraciji. Uskoro ćete primiti mejl sa linkom za aktivaciju vašeg naloga. Ukoliko ne budete primili mejl nakon izvesnog vremena, proverite vaš folder sa neželjenom poštom (spam).';
$txt['invalid_userid'] = 'Korisnik ne postoji';
$txt['invalid_activation_code'] = 'Pogrešan aktivacioni kod';
$txt['invalid_activation_username'] = 'Korisničko ime ili imejl';
$txt['invalid_activation_new'] = 'Ako ste pri registraciji upotrebili pogrešnu imejl adresu, unesite novu zajedno sa vašom lozinkom.';
$txt['invalid_activation_new_email'] = 'Nova imejl adresa';
$txt['invalid_activation_password'] = 'Stara lozinka';
$txt['invalid_activation_resend'] = 'Ponovo pošalji aktivacioni kod';
$txt['invalid_activation_known'] = 'Ako već znate svoj aktivacioni kod, unesite ga ovde.';
$txt['invalid_activation_retry'] = 'Aktivacioni kod';
$txt['invalid_activation_submit'] = 'Aktiviraj';

$txt['coppa_no_concent'] = 'Administrator još nije primio saglasnost roditelja/staratelja za vaš nalog.';
$txt['coppa_need_more_details'] = 'Potrebno vam je još detalja?';

$txt['awaiting_delete_account'] = 'Vaš nalog je označen za brisanje!<br />Ako želite da povratite svoj nalog, označite polje &quot;Ponovo aktiviraj moj nalog&quot; i prijavite se ponovo.';
$txt['undelete_account'] = 'Ponovo aktiviraj moj nalog';

$txt['in_maintain_mode'] = 'Ovaj forum je u modu održavanja.';

// These two are used as a javascript alert; please use international characters directly, not as entities.
$txt['register_agree'] = 'Molim vas pročitajte i prihvatite saglasnost pre registracije.';
$txt['register_passwords_differ_js'] = 'Lozinke koje ste uneli nisu iste!';
$txt['register_did_you'] = 'Did you mean';

$txt['approval_after_registration'] = 'Zahvaljujemo se na registraciji. Administrator mora da odobri vašu registraciji pre nego što počnete da koristite svoj nalog. Ubrzo ćete primiti mejl sa obaveštenjem o administratorovoj odluci.';

$txt['admin_settings_desc'] = 'Ovde možete da promenite razna podešavanja vezana za registraciju novih članova.';

$txt['setting_enableOpenID'] = 'Dozvoli korisnicima da se registruju koristeći OpenID';

$txt['setting_registration_method'] = 'Način registracije novih članova';
$txt['setting_registration_disabled'] = 'Registracija onemogućena';
$txt['setting_registration_standard'] = 'Neposredna registracija';
$txt['setting_registration_activate'] = 'Aktivacija mejlom';
$txt['setting_registration_approval'] = 'Odobravanje člana';
$txt['setting_notify_new_registration'] = 'Obavesti administratore kada se nov član pridruži';
$txt['setting_force_accept_agreement'] = 'Force members to accept the registration agreement when changed';
$txt['force_accept_privacy_policy'] = 'Force members to accept the privacy policy when changed';
$txt['setting_send_welcomeEmail'] = 'Pošalji pozdravni mejl svim novim članovima';
$txt['setting_show_DisplayNameOnRegistration'] = 'Allow users to enter their screen name';

$txt['setting_coppaAge'] = 'Starost ispod koje počinje primenjivanje ograničenja registracije';
$txt['setting_coppaAge_desc'] = '(0 za onemogućeno)';
$txt['setting_coppaType'] = 'Akcija za preduzimanje kada se korisnik mlađi od minimuma registruje';
$txt['setting_coppaType_reject'] = 'Odbaci registraciju';
$txt['setting_coppaType_approval'] = 'Zahtevaj odobrenje roditelja/staratelja';
$txt['setting_coppaPost'] = 'Poštanska adresa na koju bi odobrenje trebalo da bude poslato';
$txt['setting_coppaPost_desc'] = 'Primenjuje se samo kada je postavljeno ograničenje starosti';
$txt['setting_coppaFax'] = 'Broj faksa na koji bi odobrenje trebalo da bude poslato';
$txt['setting_coppaPhone'] = 'Broj za stupanje u vezu sa roditeljima oko pitanja vezanih za ograničenje starosti';

$txt['admin_register'] = 'Registracija novog člana';
$txt['admin_register_desc'] = 'Odavde možete da registrujete nove članove na forum, i ako želite, pošaljete im detalje mejlom.';
$txt['admin_register_username'] = 'Novo korisničko ime';
$txt['admin_register_email'] = 'Imejl adresa';
$txt['admin_register_password'] = 'Lozinka';
$txt['admin_register_username_desc'] = 'Korisničko ime novog člana';
$txt['admin_register_email_desc'] = 'Imejl adresa novog člana';
$txt['admin_register_password_desc'] = 'Lozinka novog člana';
$txt['admin_register_email_detail'] = 'Pošalji korisniku novu lozinku mejlom';
$txt['admin_register_email_detail_desc'] = 'Imejl adresa je potrebna čak i ako opcija nije označena';
$txt['admin_register_email_activate'] = 'Zahtevajte da korisnik aktivira svoj nalog';
$txt['admin_register_group'] = 'Primarna korisnička grupa';
$txt['admin_register_group_desc'] = 'Primarna korisnička grupa kojoj će korisnik pripadati';
$txt['admin_register_group_none'] = '(bez primarne korisničke grupe)';
$txt['admin_register_done'] = 'Član %1$s je uspešno registrovan!';

$txt['coppa_title'] = 'Forum sa ograničenjem starosti';
$txt['coppa_after_registration'] = 'Hvala vam za registraciji na {forum_name_html_safe}.<br /><br />Zato sto imate manje od {MINIMUM_AGE} godina, zakonska je obaveza da dostavite saglasnost roditelja ili staratelja pre nego sto možete početi koristiti vaš nalog. Za početak aktivacije naloga, molimo vas odštampajte formular ispod:';
$txt['coppa_form_link_popup'] = 'Učitaj zahtev u novom prozoru';
$txt['coppa_form_link_download'] = 'Preuzmi zahtev kao tekstualnu datoteku';
$txt['coppa_send_to_one_option'] = 'Zatim neka vaš roditelj ili staratelj pošalje popunjen obrazac:';
$txt['coppa_send_to_two_options'] = 'Zatim neka vaš roditelj ili staratelj pošalje popunjen obrazac na jedan od ovih načina:';
$txt['coppa_send_by_post'] = 'poštom, na sledeću adresu:';
$txt['coppa_send_by_fax'] = 'faksom, na sledeći broj:';
$txt['coppa_send_by_phone'] = 'Umesto ovoga, roditelj ili staratelj može pozvati administratora na broj {PHONE_NUMBER}.';

$txt['coppa_form_title'] = 'Obrazac dozvole registracije na {forum_name_html_safe}';
$txt['coppa_form_address'] = 'Adresa';
$txt['coppa_form_date'] = 'Datum';
$txt['coppa_form_body'] = 'Ja {PARENT_NAME},<br /><br />dajem dozvolu {CHILD_NAME} (ime deteta) da postane ponupravni registrovani korisnik foruma: {forum_name_html_safe}, sa Korisničkim Imenom: {USER_NAME}.<br /><br />Razumem i prihvatam da odredjeni privatni podaci uneseni od strane {USER_NAME} mogu biti prikazani ostalim članovima foruma.<br /><br />Potpis:<br />{PARENT_NAME} (Roditelj/Staratelj).';

$txt['visual_verification_sound_again'] = 'Reprodukuj ponovo';
$txt['visual_verification_sound_close'] = 'Zatvori prozor';
$txt['visual_verification_sound_direct'] = 'Imate problema sa slušanjem ovoga? Probajte direktan link.';

// Use numeric entities in the below.
$txt['registration_username_available'] = 'Korisničko ime je dostupno';
$txt['registration_username_unavailable'] = 'Korisničko ime nije dostupno';
$txt['registration_username_check'] = 'Proveri da li je korisničko ime dostupno';
$txt['registration_password_short'] = 'Lozinka je prekratka';
$txt['registration_password_reserved'] = 'Lozinka sadrži vaše korisničko ime/imejl adresu';
$txt['registration_password_numbercase'] = 'Lozinka mora da sadrži i VELIKA i mala slova, i brojeve';
$txt['registration_password_no_match'] = 'Lozinke se ne poklapaju';
$txt['registration_password_valid'] = 'Lozinka je ispravna';

$txt['registration_errors_occurred'] = 'Sledeće greške su pronađene u vašoj registraciji. Ispravite ih da biste nastavili:';

$txt['authenticate_label'] = 'Način prijavljivanja';
$txt['authenticate_password'] = 'Lozinka';
$txt['authenticate_openid'] = 'OtvoreniID';
$txt['authenticate_openid_url'] = 'OpenID URL za prijavu';
$txt['otp_required'] = 'A Time-based One-time Password is required in order to log in!';
$txt['disable_otp'] = 'Disable two factor authentication.';

// Contact form
$txt['admin_contact_form'] = 'Kontaktirajte admine';
$txt['contact_your_message'] = 'Vaše poruke';
$txt['errors_contact_form'] = 'Došlo je do sledećih grešaka prilikom obrade vašeg zahteva za kontakt';
$txt['contact_subject'] = 'Gost vam je poslao novu poruku';
$txt['contact_thankyou'] = 'Thank you for your message. Someone will contact you as soon as possible.';
