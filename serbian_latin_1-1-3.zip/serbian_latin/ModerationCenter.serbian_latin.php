<?php
// Version: 1.1; ModerationCenter

$txt['moderation_center'] = 'Urednički centar';
$txt['mc_main'] = 'Glavno';
$txt['mc_logs'] = 'Dnevnici';
$txt['mc_posts'] = 'poruka';
$txt['mc_groups'] = 'Members and groups';

$txt['mc_view_groups'] = 'Pregledaj grupe članova';

$txt['mc_description'] = '<strong>Welcome, %1$s!</strong><br />This is your &quot;Moderation Center&quot;. From here you can perform all the moderation actions assigned to yourself by the Administrator. This home page contains a summary of all the latest happenings in your community. You can <a href="%2$s">personalize the layout by clicking here</a>.';
$txt['mc_group_requests'] = 'Zahtevi za grupu članova';
$txt['mc_member_requests'] = 'Member Requests';
$txt['mc_unapproved_posts'] = 'Neodobrene poruke';
$txt['mc_watched_users'] = 'Recently Watched Members';
$txt['mc_watched_topics'] = 'Nadgledane teme';
$txt['mc_scratch_board'] = 'Urednički Polazni Forum';
$txt['mc_latest_news'] = 'Latest News';
$txt['mc_recent_reports'] = 'Zadnje prijavljene teme';
$txt['mc_warnings'] = 'Upozorenja';
$txt['mc_notes'] = 'Beleške urednika';
$txt['mc_required'] = 'Items Requiring Approval';
$txt['mc_attachments'] = 'Attachments needing approval';
$txt['mc_emailmod'] = 'Email Postings needing approval';
$txt['mc_topics'] = 'Topics needing approval';
$txt['mc_posts'] = 'poruka';
$txt['mc_groupreq'] = 'Group requests needing approval';
$txt['mc_memberreq'] = 'Members needing approval';
$txt['mc_reports'] = 'Report posts needing approval';
$txt['mc_pm_reports'] = 'Reported personal messages';

$txt['mc_cannot_connect_sm'] = 'You are unable to connect to ElkArte\'s latest news file.';

$txt['mc_recent_reports_none'] = 'Nema nepregledanih izveštaja.';
$txt['mc_watched_users_none'] = 'Trenutno nikog ne nadgledate.';
$txt['mc_group_requests_none'] = 'Nemate nerešenih zahteva za članstvom u grupi.';

$txt['mc_seen'] = '%1$s poslednji put viđen %2$s ';
$txt['mc_seen_never'] = '%1$s nije viđen';
$txt['mc_groupr_by'] = 'od strane';

$txt['mc_reported_posts_desc'] = 'Ovde možete da pregledate sve teme koje su prijavili članovi vaše zajednice.';
$txt['mc_reported_pms_desc'] = 'Here you can review all the personal message reports raised by members of the community.';
$txt['mc_reportedp_active'] = 'Nerešene';
$txt['mc_reportedp_closed'] = 'Stare prijave';
$txt['mc_reportedp_by'] = 'od strane';
$txt['mc_reportedp_reported_by'] = 'Prijavio';
$txt['mc_reportedp_last_reported'] = 'Zadnji put prijavio';
$txt['mc_reportedp_none_found'] = 'Nisam pronašao prijave';

$txt['mc_reportedp_details'] = 'Detalji';
$txt['mc_reportedp_close'] = 'Zatvori';
$txt['mc_reportedp_open'] = 'Otvori';
$txt['mc_reportedp_ignore'] = 'Dismiss';
$txt['mc_reportedp_unignore'] = 'Reopen';
// Do not use numeric entries in the below string.
$txt['mc_reportedp_ignore_confirm'] = 'Are you sure you wish to dismiss and ignore further reports about this message?

This will turn off further reports for all moderators of the forum.';
$txt['mc_reportedp_close_selected'] = 'Reši izabrano';

$txt['mc_groupr_group'] = 'Grupe članova';
$txt['mc_groupr_member'] = 'Član';
$txt['mc_groupr_reason'] = 'Razlog';
$txt['mc_groupr_none_found'] = 'Trenutno nema nerešenih zahteva za članstvom u grupi.';
$txt['mc_groupr_submit'] = 'Pošalji';
$txt['mc_groupr_reason_desc'] = 'Razlog za odbijanje zahteva korisnika %1$s za pristup &quot;%2$s&quot;';
$txt['mc_groups_reason_title'] = 'Reasons for rejection';
$txt['with_selected'] = 'With selected';
$txt['mc_groupr_approve'] = 'Approve request';
$txt['mc_groupr_reject'] = 'Reject request (No Reason)';
$txt['mc_groupr_reject_w_reason'] = 'Reject request with reason';
// Do not use numeric entries in the below string.
$txt['mc_groupr_warning'] = 'Da li ste sigurni da želite da uradite ovo?';

$txt['mc_unapproved_attachments_none_found'] = 'Nema neodobrenih priloženih datoteka!';
$txt['mc_unapproved_attachments_desc'] = 'From here you can approve or delete any attachments awaiting moderation.';
$txt['mc_unapproved_replies_none_found'] = 'Nema neodobrenih poruka!';
$txt['mc_unapproved_topics_none_found'] = 'Nema neodobrenih tema!';
$txt['mc_unapproved_posts_desc'] = 'Ovde možete da odobrite ili obrišete sve poruke koje čekaju odobrenje.';
$txt['mc_unapproved_replies'] = 'Odgovora';
$txt['mc_unapproved_topics'] = 'Teme';
$txt['mc_unapproved_by'] = 'od strane';
$txt['mc_unapproved_sure'] = 'Da li ste sigurni da želite da uradite ovo?';
$txt['mc_unapproved_attach_name'] = 'Attachment name';
$txt['mc_unapproved_attach_size'] = 'File size';
$txt['mc_unapproved_attach_poster'] = 'Postavio';
$txt['mc_viewmodreport'] = 'Moderation report for %1$s by %2$s';
$txt['mc_modreport_summary'] = 'There have been %1$d report(s) concerning this post. The last report was %2$s.';
$txt['mc_view_pmreport'] = 'Moderation report for Personal Message sent by %1$s';
$txt['mc_pmreport_summary'] = 'There have been %1$d report(s) concerning this Personale Message. The last report was %2$s.';
$txt['mc_modreport_whoreported_title'] = 'Članovi koji su prijavili ove poruke';
$txt['mc_modreport_whoreported_data'] = 'Reported by %1$s on %2$s. They left the following message:';
$txt['mc_modreport_modactions'] = 'Aktivnosti preduzete od drugih urednika';
$txt['mc_modreport_mod_comments'] = 'Komentari urednika';
$txt['mc_modreport_no_mod_comment'] = 'Trenutno nema komentara urednika';
$txt['mc_modreport_add_mod_comment'] = 'Dodaj komentar';

$txt['show_notice'] = 'Tekst Obaveštenja';
$txt['show_notice_subject'] = 'Naslov';
$txt['show_notice_text'] = 'Tekst';

$txt['mc_watched_users_title'] = 'Nadgledani korisnici';
$txt['mc_watched_users_desc'] = 'Ovde možete da pratite sve korisnike koje urednički tim nadgleda.';
$txt['mc_watched_users_post'] = 'Pogledaj po poruci';
$txt['mc_watched_users_warning'] = 'Nivo upozorenja';
$txt['mc_watched_users_last_login'] = 'Zadnji put prijavljen';
$txt['mc_watched_users_last_post'] = 'Zadnja poruka';
$txt['mc_watched_users_no_posts'] = 'Nema poruka od nadgledanih korisnika.';
// Don't use entities in the two strings below.
$txt['mc_watched_users_delete_post'] = 'Da li ste sigurni da želite da izbrišete ovu poruku?';
$txt['mc_watched_users_delete_posts'] = 'Da li ste sigurni da želite da izbrišete ove poruke?';
$txt['mc_watched_users_posted'] = 'Poslao';
$txt['mc_watched_users_member'] = 'Član';

$txt['mc_warnings_description'] = 'U ovom odeljku možete videti koja upozorenja su data članovima foruma.Takođe možete dodavati i menjati  predloške obaveštenja koji se koriste kada se šalje upozorenje članu.';
$txt['mc_warning_log'] = 'Dnevnik upozorenja';
$txt['mc_warning_templates'] = 'Prilagođeni Predlošci';
$txt['mc_warning_log_title'] = 'Viewing warning log';
$txt['mc_warning_templates_title'] = 'Custom warning templates';

$txt['mc_warnings_none'] = 'No warnings have been issued.';
$txt['mc_warnings_recipient'] = 'Primalac';

$txt['mc_warning_templates_none'] = 'Još uvek nema napravljenih predložaka upozorenja';
$txt['mc_warning_templates_time'] = 'Vreme kreiranja';
$txt['mc_warning_templates_name'] = 'Predložak';
$txt['mc_warning_templates_creator'] = 'Napisao';
$txt['mc_warning_template_add'] = 'Dodaj Predložak';
$txt['mc_warning_template_modify'] = 'Izmeni Predložak';
$txt['mc_warning_template_delete'] = 'Obriši izabrano';
$txt['mc_warning_template_delete_confirm'] = 'Da li ste sigurni da želite da izbrišete izabrane šablone?';

$txt['mc_warning_template_desc'] = 'Use this page to fill in the details of the template. Note that the subject for the email is not part of the template. Note that as the notification is sent by PM you can use BBC within the template. If you use the {MESSAGE} variable then this template will not be available when issuing a generic warning (i.e. A warning not linked to a post).';
$txt['mc_warning_template_title'] = 'Naslov Predloška';
$txt['mc_warning_template_body_desc'] = 'The content of the notification message. You can use the following shortcuts in this template.<ul><li>{MEMBER} - Member Name.</li><li>{MESSAGE} - Link to Offending Post. (If Applicable)</li><li>{FORUMNAME} - Forum Name.</li><li>{SCRIPTURL} - Web address of the forum.</li><li>{REGARDS} - Standard email sign-off.</li></ul>';
$txt['mc_warning_template_body_default'] = '{MEMBER},

You have received a warning for inappropriate activity. Please cease these activities and abide by the forum rules otherwise we will take further action.

{REGARDS}';
$txt['mc_warning_template_personal'] = 'Lični Predložak';
$txt['mc_warning_template_personal_desc'] = 'Ako odaberete ovu mogućnost samo vi ćete moći da vidite, menjate i koristite ovaj predložak. Ako nije odabrano svi urednici će moći koristiti ovaj predložak.';
$txt['mc_warning_template_error_no_title'] = 'You must set the title.';
$txt['mc_warning_template_error_no_body'] = 'You must set the notification body.';

$txt['mc_settings'] = 'Promeni podešavanja';
$txt['mc_prefs_title'] = 'Podešavanja urednika';
$txt['mc_prefs_desc'] = 'Ovaj odeljak vam omogućava da podesite neke lične opcije vezane za uređivanje foruma kao što su obaveštenja mejlom.';
$txt['mc_prefs_homepage'] = 'Stavke koje se prikazuju na početnoj strani uredničkog centra';
$txt['mc_prefs_latest_news'] = 'ElkArte News';
$txt['mc_prefs_show_reports'] = 'Prikaži broj nerešenih prijava u zaglavlju foruma';
$txt['mc_prefs_notify_report'] = 'Obavesti me o prijavljenim temama';
$txt['mc_prefs_notify_report_never'] = 'Nikad';
$txt['mc_prefs_notify_report_moderator'] = 'Samo ako sam ja urednik tog foruma';
$txt['mc_prefs_notify_report_always'] = 'Uvek';
$txt['mc_prefs_notify_approval'] = 'Obavesti me o stavkama koje čekaju na odobrenje';
$txt['mc_logoff'] = 'End Moderator Session';

// Use entities in the below string.
$txt['mc_click_add_note'] = 'Dodaj novu belešku';
$txt['mc_add_note'] = 'Dodaj';