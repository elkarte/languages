<?php
// Version: 1.1; PersonalMessage

$txt['pm_inbox'] = 'Indeks privatnih poruka';
$txt['pm_add'] = 'Dodaj';
$txt['make_bcc'] = 'Dodaj BCC';
$txt['pm_to'] = 'Za';
$txt['pm_bcc'] = 'Bcc';
$txt['inbox'] = 'Primljene poruke';
$txt['conversation'] = 'Konverzacija';
$txt['messages'] = 'Poruke';
$txt['sent_items'] = 'Poslate stavke';
$txt['new_message'] = 'Nova poruka';
$txt['delete_message'] = 'Obriši poruke';
// Don't translate "PMBOX" in this string.
$txt['delete_all'] = 'Obriši sve poruke u mom PMBOX sandučetu';
$txt['delete_all_confirm'] = 'Da li ste sigurni da želite da obrišete sve poruke?';

$txt['delete_selected_confirm'] = 'Da li ste sigurni da želite da obrišete sve izabrane privatne poruke?';

$txt['sent_to'] = 'Za';
$txt['reply_to_all'] = 'Odgovori svima';
$txt['delete_conversation'] = 'Izbriši konverzaciju';

$txt['pm_capacity'] = 'Kapacitet';
$txt['pm_currently_using'] = '%1$s poruka, ukupno %2$s%%.';
$txt['pm_sent'] = 'Vaša poruka je uspešno poslata.';

$txt['pm_error_user_not_found'] = 'Ne mogu da pronađem člana \'%1$s\'.';
$txt['pm_error_ignored_by_user'] = 'Korisnik \'%1$s\' je blokirao vaše privatne poruke.';
$txt['pm_error_data_limit_reached'] = 'PM could not be sent to \'%1$s\' as their inbox is full.';
$txt['pm_error_user_cannot_read'] = 'Korisnik \'%1$s\' ne može da prima privatne poruke.';
$txt['pm_successfully_sent'] = 'PP je uspešno poslata korisniku \'%1$s\'.';
$txt['pm_send_report'] = 'Pošalji izveštaj';
$txt['pm_undisclosed_recipients'] = 'Neprikazani primaoci';
$txt['pm_too_many_recipients'] = 'Ne možete da pošaljete privatne poruke ka više od %1$d korisnika istovremeno.';

$txt['pm_read'] = 'Pročitano';
$txt['pm_replied'] = 'Odgovoreno na';
$txt['pm_mark_unread'] = 'Mark as Unread';

// Message Pruning.
$txt['pm_prune'] = 'Prune messages';
$txt['pm_prune_desc'] = 'Delete all personal messages older than %1$s days.';
$txt['pm_prune_warning'] = 'Da li ste sigurni da želite da obrišete svoje privatne poruke?';

// Actions Drop Down.
$txt['pm_actions_title'] = 'Further actions';
$txt['pm_actions_delete_selected'] = 'Obriši izabrano';
$txt['pm_actions_filter_by_label'] = 'Filter by label';
$txt['pm_actions_go'] = 'Idi';

// Manage Labels Screen.
$txt['pm_apply'] = 'Primeni';
$txt['pm_manage_labels'] = 'Manage labels';
$txt['pm_labels_delete'] = 'Da li ste sigurni da želite da obrišete izabrane odeljke?';
$txt['pm_labels_desc'] = 'Ovde možete da dodajete, menjate i brišete odeljke korišćene u privatnim porukama.';
$txt['pm_label_add_new'] = 'Add new label';
$txt['pm_label_name'] = 'Label name';
$txt['pm_labels_no_exist'] = 'Trenutno niste odredili nijedan odeljak!';

// Labeling Drop Down.
$txt['pm_current_label'] = 'Odeljak';
$txt['pm_msg_label_title'] = 'Label message';
$txt['pm_msg_label_apply'] = 'Add label';
$txt['pm_msg_label_remove'] = 'Remove label';
$txt['pm_msg_label_inbox'] = 'Primljene poruke';
$txt['pm_sel_label_title'] = 'Label selected';

// Sidebar Headings.
$txt['pm_labels'] = 'Odeljci';
$txt['pm_messages'] = 'Poruke';
$txt['pm_actions'] = 'Akcije';
$txt['pm_preferences'] = 'Podešavanja';

$txt['pm_is_replied_to'] = 'Prosledili ste ili ste odgovorili na ovu poruku.';

// Reporting messages.
$txt['pm_report_to_admin'] = 'Report to admin';
$txt['pm_report_title'] = 'Report personal message';
$txt['pm_report_desc'] = 'Sa ove stranice možete da prijavite administratorskom timu foruma privatnu poruku koju ste primili. Podnesite i opis razloga iz kojeg prijavljujete poruku jer će biti poslat zajedno sa sadržajem originalne poruke.';
$txt['pm_report_admins'] = 'Administrator kojem želite da pošaljete poruku';
$txt['pm_report_all_admins'] = 'Pošalji svim administratorima';
$txt['pm_report_reason'] = 'Razlog zbog kojeg prijavljujete ovu poruku';
$txt['pm_report_message'] = 'Prijavi poruku';

// Important - The following strings should use numeric entities.
$txt['pm_report_pm_subject'] = '[PRIJAVA] ';
// In the below string, do not translate "{REPORTER}" or "{SENDER}".
$txt['pm_report_pm_user_sent'] = '{REPORTER} je prijavio privatnu poruku, poslatu od {SENDER}, iz sledećih razloga:';
$txt['pm_report_pm_other_recipients'] = 'Primaoci ove privatne poruke su i:';
$txt['pm_report_pm_hidden'] = '%1$d skrivenih primalaca';
$txt['pm_report_pm_unedited_below'] = 'Ispod se nalazi originalni sadržaj privatne poruke koja je prijavljena:';
$txt['pm_report_pm_sent'] = 'Poslato:';

$txt['pm_report_done'] = 'Zahvaljujemo što ste podneli prijavu. Uskoro bi trebalo da dobijete odgovor administratorskog tima.';
$txt['pm_report_return'] = 'Vrati se na primljene poruke';

$txt['pm_search_title'] = 'Search personal messages';
$txt['pm_search_bar_title'] = 'Search messages';
$txt['pm_search_text'] = 'Pretraži za';
$txt['pm_search_go'] = 'Pretraga';
$txt['pm_search_advanced'] = 'Show advanced options';
$txt['pm_search_simple'] = 'Hide advanced options';
$txt['pm_search_user'] = 'po korisniku';
$txt['pm_search_match_all'] = 'Poklopi sve reči';
$txt['pm_search_match_any'] = 'Poklopi bilo koju reč';
$txt['pm_search_options'] = 'Opcije';
$txt['pm_search_post_age'] = 'Starost poruke';
$txt['pm_search_show_complete'] = 'Prikaži cele poruke u rezultatima.';
$txt['pm_search_subject_only'] = 'Traži samo po temi i autoru.';
$txt['pm_search_sent_only'] = 'Search only in sent items.';
$txt['pm_search_between'] = 'između';
$txt['pm_search_between_and'] = 'i';
$txt['pm_search_between_days'] = 'dana';
$txt['pm_search_order'] = 'Sortiranje rezultata';
$txt['pm_search_choose_label'] = 'Izaberite odeljke po kojima želite da tražite ili izaberite sve';

$txt['pm_search_results'] = 'Search results';
$txt['pm_search_none_found'] = 'No messages found';

$txt['pm_search_orderby_relevant_first'] = 'Prvo najrelevantniji rezultati';
$txt['pm_search_orderby_recent_first'] = 'Prvo najsvežiji rezultati';
$txt['pm_search_orderby_old_first'] = 'Prvo najstariji rezultati';

$txt['pm_visual_verification_label'] = 'Potvrda';
$txt['pm_visual_verification_desc'] = 'Please enter the code in the image above in order to send this PM.';

$txt['pm_settings'] = 'Change settings';
$txt['pm_change_view'] = 'Change view';

$txt['pm_manage_rules'] = 'Manage rules';
$txt['pm_manage_rules_desc'] = 'Pravila za sortiranje vam dozvoljavaju da automatski sortirate dolazeće poruke po kriterijumu koji definišete. Ispod se nalaze pravila koja su trenutno podešena. Da biste izmenili neko pravilo, kliknite na njegovo ime.';
$txt['pm_rules_none'] = 'Još niste podesili pravila za sortiranje.';
$txt['pm_rule_title'] = 'Dodaj';
$txt['pm_add_rule'] = 'Add new rule';
$txt['pm_apply_rules'] = 'Apply rules now';
// Use entities in the below string.
$txt['pm_js_apply_rules_confirm'] = 'Da li ste sigurni da želite da primenite trenutna pravila na sve postojeće privatne poruke?';
$txt['pm_edit_rule'] = 'Edit rule';
$txt['pm_rule_save'] = 'Save rule';
$txt['pm_delete_selected_rule'] = 'Delete selected rules';
// Use entities in the below string.
$txt['pm_js_delete_rule_confirm'] = 'Da li ste sigurni da želite da obrišete izabrana pravila?';
$txt['pm_rule_name'] = 'Ime';
$txt['pm_rule_name_desc'] = 'Ime ovog pravila';
$txt['pm_rule_name_default'] = '[IME]';
$txt['pm_rule_description'] = 'Opis';
$txt['pm_rule_not_defined'] = 'Dodajte neke kriterijume da biste počeli da gradite opis pravila.';
$txt['pm_rule_js_disabled'] = '<span class="alert"><strong>Pažnja:</strong> Izgleda da ste onemogućili Javaskript. Preporučujemo vam da omogućite Javaskript da biste koristili ovu opciju.</span>';
$txt['pm_rule_criteria'] = 'Kriterijum';
$txt['pm_rule_criteria_add'] = 'Add criteria';
$txt['pm_rule_criteria_pick'] = 'Choose criteria';
$txt['pm_rule_mid'] = 'Sender name';
$txt['pm_rule_gid'] = 'Sender\'s group';
$txt['pm_rule_sub'] = 'Message subject contains';
$txt['pm_rule_msg'] = 'Message body contains';
$txt['pm_rule_bud'] = 'Sender is buddy';
$txt['pm_rule_sel_group'] = 'Select group';
$txt['pm_rule_logic'] = 'When checking criteria';
$txt['pm_rule_logic_and'] = 'Svi kriterijumi moraju da budu ispunjeni';
$txt['pm_rule_logic_or'] = 'Bilo koji kriterijum može da bude ispunjen';
$txt['pm_rule_actions'] = 'Akcije';
$txt['pm_rule_sel_action'] = 'Select an action';
$txt['pm_rule_add_action'] = 'Add action';
$txt['pm_rule_label'] = 'Premesti poruku u odeljak';
$txt['pm_rule_sel_label'] = 'Select label';
$txt['pm_rule_delete'] = 'Delete message';
$txt['pm_rule_no_name'] = 'Zaboravili ste da unesete ime pravila.';
$txt['pm_rule_no_criteria'] = 'Pravilo mora da ima najmanje jedan kriterijum i najmanje jednu akciju.';
$txt['pm_rule_too_complex'] = 'The rule you are creating is too long to save. Try breaking it up into smaller rules.';

$txt['pm_readable_and'] = '<em>i</em>';
$txt['pm_readable_or'] = '<em>ili</em>';
$txt['pm_readable_start'] = 'Ako ';
$txt['pm_readable_end'] = '.';
$txt['pm_readable_member'] = 'je poruku napisao &quot;{MEMBER}&quot;';
$txt['pm_readable_group'] = 'je pošiljalac iz grupe &quot;{GROUP}&quot; group';
$txt['pm_readable_subject'] = 'naslov poruke sadrži &quot;{SUBJECT}&quot;';
$txt['pm_readable_body'] = 'telo poruke sadrži &quot;{BODY}&quot;';
$txt['pm_readable_buddy'] = 'je pošiljalac prijatelj';
$txt['pm_readable_label'] = 'dodaj u odeljak &quot;{LABEL}&quot;';
$txt['pm_readable_delete'] = 'obriši poruku';
$txt['pm_readable_then'] = '<strong>onda</strong>';