<?php
// Version: 1.1; Search

$txt['set_parameters'] = 'Podesi parametre za pretragu';
$txt['choose_board'] = 'Izaberite forum u okviru kojeg želite da tražite, ili izaberite sve';
$txt['all_words'] = 'Poklopi sve reči';
$txt['any_words'] = 'Poklopi bilo koju reč';
$txt['by_user'] = 'po korisniku';

$txt['search_post_age'] = 'Starost poruke';
$txt['search_between'] = 'između';
$txt['search_and'] = 'i';
$txt['search_options'] = 'Opcije';
$txt['search_show_complete_messages'] = 'Prikaži rezultate kao poruke';
$txt['search_subject_only'] = 'Samo naslov teme';
$txt['search_relevance'] = 'Relevantnost';
$txt['search_date_posted'] = 'Datum slanja';
$txt['search_order'] = 'Sortiranje rezultata';
$txt['search_orderby_relevant_first'] = 'najrelevantnijim rezultatima';
$txt['search_orderby_large_first'] = 'najvećim temama';
$txt['search_orderby_small_first'] = 'najmanjim temama';
$txt['search_orderby_recent_first'] = 'najsvežijim temama';
$txt['search_orderby_old_first'] = 'najstarijim temama';
$txt['search_visual_verification_label'] = 'Potvrda';
$txt['search_visual_verification_desc'] = 'Unesite kod sa slike da biste koristili pretragu.';

$txt['search_specific_topic'] = 'Pretražujem samo poruke u temi';

$txt['groups_search_posts'] = 'Korisničke grupe sa pristupom funkciji pretrage';
$txt['search_dropdown'] = 'Enable the Quick Search dropdown';
$txt['search_results_per_page'] = 'Broj rezultata pretrage po stranici';
$txt['search_weight_frequency'] = 'Relativna težina broja poklapajućih poruka unutar teme';
$txt['search_weight_age'] = 'Relativna težina starosti poslednje poklapajuće poruke';
$txt['search_weight_length'] = 'Relativna težina dužine teme';
$txt['search_weight_subject'] = 'Relativna težina poklapajućeg naslova';
$txt['search_weight_first_message'] = 'Relativna težina prve poklopljene poruke';
$txt['search_weight_sticky'] = 'Relative search weight for a pinned topic';
$txt['search_weight_likes'] = 'Relative search weight for topic likes';

$txt['search_settings_desc'] = 'Here you can change the basic settings of the search function.';
$txt['search_settings_title'] = 'Search Settings';

$txt['search_weights_desc'] = 'Here you can change the individual components of the relevance rating.';
$txt['search_weights_sphinx'] = 'To update weight factors with Sphinx, you must generate and install a new sphinx.conf file.';
$txt['search_weights_title'] = 'Pretraga - težine';
$txt['search_weights_total'] = 'Ukupno';
$txt['search_weights_save'] = 'Sačuvaj';

$txt['search_method_desc'] = 'Ovde možete da promenite način na koji se odvija pretraga.';
$txt['search_method_title'] = 'Pretraga - način';
$txt['search_method_save'] = 'Sačuvaj';
$txt['search_method_messages_table_space'] = 'Prostor zauzet porukama u bazi';
$txt['search_method_messages_index_space'] = 'Prostor zauzet indeksom poruka u bazi';
$txt['search_method_kilobytes'] = 'KB';
$txt['search_method_fulltext_index'] = 'Fulltext indeks';
$txt['search_method_no_index_exists'] = 'trenutno ne postoji';
$txt['search_method_fulltext_create'] = 'Create a fulltext index';
$txt['search_method_fulltext_cannot_create'] = 'ne može da se napravi jer je najveća dužina poruke iznad 65,535 ili tip tabele nije MyISAM';
$txt['search_method_index_already_exists'] = 'je već napravljen';
$txt['search_method_fulltext_remove'] = 'ukloni fulltext index';
$txt['search_method_index_partial'] = 'je delimično napravljen';
$txt['search_index_custom_resume'] = 'nastavi';

// These strings are used in a javascript confirmation popup; don't use entities.
$txt['search_method_fulltext_warning'] = 'In order to be able to use fulltext search, you\\\'ll have to create a fulltext index first.';
$txt['search_index_custom_warning'] = 'Da biste koristili pretragu pomoću prilagođenog indeksa, moraćete prvo da napravite prilagođeni indeks!';

$txt['search_index'] = 'Pretraživački indeks';
$txt['search_index_none'] = 'Bez indeksa';
$txt['search_index_custom'] = 'Prilagođeni indeks';
$txt['search_index_label'] = 'Indeks';
$txt['search_index_size'] = 'Veličina';
$txt['search_index_create_custom'] = 'Create custom index';
$txt['search_index_custom_remove'] = 'Remove custom index';

$txt['search_index_sphinx'] = 'Sphinx';
$txt['search_index_sphinx_desc'] = 'To adjust Sphinx settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';
$txt['search_index_sphinxql'] = 'SphinxQL';
$txt['search_index_sphinxql_desc'] = 'To adjust SphinxQL settings, use <a class="linkbutton" href="{managesearch_url}">Configure Sphinx</a>';

$txt['search_force_index'] = 'Forsiraj upotrebu pretraživačkog indeksa';
$txt['search_match_words'] = 'Poklopi samo cele reči';
$txt['search_max_results'] = 'Najveći broj rezultata za prikaz';
$txt['search_max_results_disable'] = '(0: neograničeno)';
$txt['search_floodcontrol_time'] = 'Zahtevano vreme  između pretraga od istog člana ';
$txt['search_floodcontrol_time_desc'] = '(0 za neograničeno, u sekundama)';

$txt['additional_search_engines'] = 'Additional search engines';
$txt['setup_search_engine_add_more'] = 'Add another search engine';

$txt['search_create_index'] = 'Napravi indeks';
$txt['search_create_index_why'] = 'Zašto napraviti indeks?';
$txt['search_create_index_start'] = 'Napravi';
$txt['search_predefined'] = 'Predefinisan profil';
$txt['search_predefined_small'] = 'Indeks male veličine';
$txt['search_predefined_moderate'] = 'Indeks srednje veličine';
$txt['search_predefined_large'] = 'Indeks velike veličine';
$txt['search_create_index_continue'] = 'Nastavi';
$txt['search_create_index_not_ready'] = 'ElkArte is currently creating a search index of your messages. To avoid overloading your server, the process has been temporarily paused. It should automatically continue in a few seconds. If it doesn\'t, please click continue below.';
$txt['search_create_index_progress'] = 'Napredak';
$txt['search_create_index_done'] = 'Custom search index successfully created.';
$txt['search_create_index_done_link'] = 'Nastavi';
$txt['search_double_index'] = 'Trenutno ste napravili dva indeksa u tabeli poruka. Zbog najboljih performansi, preporučujemo da uklonite jedan od ta dva indeksa.';

$txt['search_error_indexed_chars'] = 'Neispravan broj indeksiranih znakova. Potrebna su najmanje 3 znaka za upotrebljiv indeks.';
$txt['search_error_max_percentage'] = 'Neispravan procenat reči za preskakanje. Koristite vrednost od najmanje 5%.';
$txt['error_string_too_long'] = 'Termini za pretragu ne smeju da imaju manje od %1$d znakova.';

$txt['search_warning_ignored_word'] = 'The following term has been ignored in your search';
$txt['search_warning_ignored_words'] = 'The following terms have been ignored in your search';

$txt['search_adjust_query'] = 'Podesi parametre pretrage';
$txt['search_adjust_submit'] = 'Ponovi pretragu';
$txt['search_did_you_mean'] = 'Da niste možda mislili na';

$txt['search_example'] = '<em>na pr.</em> Stevan Sremac "Zona Zamfirova" -film';

$txt['search_engines_description'] = 'Ovde možete da podesite koliko detaljno želite da pratite kako pretraživači indeksiraju vaš forum kao i da pregledate odgovarajuće dnevnike.';
$txt['spider_mode'] = 'Search Engine Tracking Level';
$txt['spider_mode_note'] = 'Note higher level tracking increases server resource requirement.';
$txt['spider_mode_off'] = 'Onemogućeno';
$txt['spider_mode_standard'] = 'Uobičajene';
$txt['spider_mode_high'] = 'Uređivanje';
$txt['spider_mode_vhigh'] = 'Aggressive';
$txt['spider_settings_desc'] = 'You can change settings for spider tracking from this page. Note, if you wish to <a href="%1$s">enable automatic pruning of the hit logs you can set this up here</a>';

$txt['spider_group'] = 'Apply restrictive permissions from group';
$txt['spider_group_note'] = 'To enable you to stop spiders indexing some pages.';
$txt['spider_group_none'] = 'Onemogućeno';

$txt['show_spider_online'] = 'Prikaži pauke u spisku prisutnih korisnika';
$txt['show_spider_online_no'] = 'Ne prikazuj';
$txt['show_spider_online_summary'] = 'Prikaži broj paukova';
$txt['show_spider_online_detail'] = 'Prikaži detalje paukova';
$txt['show_spider_online_detail_admin'] = 'Prikaži detalje paukova - samo administratorima';

$txt['spider_name'] = 'Ime pauka';
$txt['spider_last_seen'] = 'Poslednji put viđen';
$txt['spider_last_never'] = 'Nikad';
$txt['spider_agent'] = 'Korisnički agent';
$txt['spider_ip_info'] = 'IP adrese';
$txt['spiders_add'] = 'Dodaj novog pauka';
$txt['spiders_edit'] = 'Izmeni pauka';
$txt['spiders_remove_selected'] = 'Izbriši izabrano';
$txt['spider_remove_selected_confirm'] = 'Are you sure you want to remove these spiders?\\n\\nAll associated statistics will also be deleted!';
$txt['spiders_no_entries'] = 'Trenutno nema podešenih pauka.';

$txt['add_spider_desc'] = 'Ovde možete da izmenite parametre po kojima se pauci kategorizuju. Ukoliko se user agent/IP adresa gosta poklapa sa vrednostima unesenim na ovoj stranici, računaće se kao pauk pretraživača i biće praćen po podešavanjima ovog foruma.';
$txt['spider_name_desc'] = 'Ime po kojem će se ovaj pauk prepoznavati.';
$txt['spider_agent_desc'] = 'User agent specifičan za ovog pauka.';
$txt['spider_ip_info_desc'] = 'Spisak IP adresa odvojenih zarezom specifičnih za ovog pauka.';

$txt['spider_time'] = 'Vreme';
$txt['spider_viewing'] = 'Gleda';
$txt['spider_logs_empty'] = 'Trenutno nema zapisa u dnevniku pauka.';
$txt['spider_logs_info'] = 'Zapisivanje svake akcije pauka se dešava ukoliko je stepen praćenja postavljen na &quot;visoko&quot; ili &quot;veoma visoko&quot;. Detalji sve akcije pauka se zapisuju ukoliko je stepen praćenja postavljen na &quot;veoma visoko&quot;.';
$txt['spider_disabled'] = 'Onemogućeno';
$txt['spider_log_empty_log'] = 'Clear Log';
$txt['spider_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log';

$txt['spider_logs_delete'] = 'Izbriši unose';
$txt['spider_logs_delete_older'] = 'Delete all entries older than %1$s days.';
$txt['spider_logs_delete_submit'] = 'Obriši';

$txt['spider_stats_delete_older'] = 'Delete all spider statistics from spiders not seen in %1$s days.';

// Don't use entities in the below string.
$txt['spider_logs_delete_confirm'] = 'Da li ste sigurni da želite da izbrišete sve unose u dnevnik?';

$txt['spider_stats_select_month'] = 'Skoči na mesec';
$txt['spider_stats_page_hits'] = 'Poseta stranici';
$txt['spider_stats_no_entries'] = 'Trenutno nema dostupne statistike pauka.';

// strings for setting up sphinx search
$txt['sphinx_test_not_selected'] = 'You have not yet selected to use Sphinx or SphinxQL as your Search Method';
$txt['sphinx_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using the Sphinx API.';
$txt['sphinxql_test_passed'] = 'All tests were successful, the system was able to connect to the sphinx search daemon using SphinxQL commands.';
$txt['sphinx_test_connect_failed'] = 'Unable to connect to the Sphinx daemon. Make sure it is running and configured properly. Sphinx search will not work until you fix the problem.';
$txt['sphinxql_test_connect_failed'] = 'Unable to access SphinxQL. Make sure your sphinx.conf has a separate listen directive for the SphinxQL port. SphinxQL search will not work until you fix the problem';
$txt['sphinx_test_api_missing'] = 'The sphinxapi.php file is missing in your &quot;sources&quot; directory. You need to copy this file from the Sphinx distribution. Sphinx search will not work until you fix the problem.';
$txt['sphinx_description'] = 'Use this interface to supply the access details to your Sphinx search daemon. <strong>These settings are only used to create</strong> an initial sphinx.conf configuration file which you will need to save in your Sphinx configuration directory (typically /usr/local/etc or /etc/sphinxsearch). Generally the options below can be left untouched, however they assume that the Sphinx software was installed in /usr/local and use /var/sphinx for the search index data storage. In order to keep Sphinx up to date, you must use a cron job to update the indexes, otherwise new or deleted content will not be reflected in  the search results. The configuration file defines two indexes:<br /><br/><strong>elkarte_delta_index</strong>, an index that only stores recent changes and can be called frequently. <strong>elkarte_base_index</strong>, an index that stores the full database and should be called less frequently. Example:<br /><span class="tt">10 3 * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_base_index<br />0 * * * * /usr/local/bin/indexer --config /usr/local/etc/sphinx.conf --rotate elkarte_delta_index</span>';
$txt['sphinx_index_prefix'] = 'Index prefix:';
$txt['sphinx_index_prefix_desc'] = 'This is the prefix for the base and delta indexes.<br />By default it uses elkarte and the two indexes will be elkarte_base_index and elkarte_delta_index. Sphinx will connect to elkarte_index (prefix_index).  If you change this be sure to use the correct prefix in your cron task.';
$txt['sphinx_index_data_path'] = 'Index data path:';
$txt['sphinx_index_data_path_desc'] = 'This is the path that contains the search index files used by Sphinx.<br />It <strong>must</strong> exist and be accessible for reading and writing by the Sphinx indexer and search daemon.';
$txt['sphinx_log_file_path'] = 'Log file path:';
$txt['sphinx_log_file_path_desc'] = 'Server path that will contain the log files created by Sphinx.<br />This directory must exist on your server and must be writable by the sphinx search daemon and indexer.';
$txt['sphinx_stop_word_path'] = 'Stopword path:';
$txt['sphinx_stop_word_path_desc'] = 'The server path to the stopword list (leave empty for no stopword list).';
$txt['sphinx_memory_limit'] = 'Sphinx indexer memory limit:';
$txt['sphinx_memory_limit_desc'] = 'The maximum amount of (RAM) memory the indexer is allowed to use.';
$txt['sphinx_searchd_server'] = 'Search daemon server:';
$txt['sphinx_searchd_server_desc'] = 'Address of the server running the search daemon. This must be a valid host name or IP address.<br />If not set, localhost will be used.';
$txt['sphinx_searchd_port'] = 'Search daemon port:';
$txt['sphinx_searchd_port_desc'] = 'Port on which the search daemon will listen.';
$txt['sphinx_searchd_qlport'] = 'Sphinx QL daemon port:';
$txt['sphinx_searchd_qlport_desc'] = 'Port on which the search daemon will listen for SphinxQL queries.';
$txt['sphinx_max_matches'] = 'Maximum # matches:';
$txt['sphinx_max_matches_desc'] = 'Maximum amount of matches the search daemon will return.';
$txt['sphinx_create_config'] = 'Create Sphinx config';
$txt['sphinx_test_connection'] = 'Test connection to Sphinx daemon';