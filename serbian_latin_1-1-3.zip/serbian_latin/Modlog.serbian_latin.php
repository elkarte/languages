<?php
// Version: 1.1; Modlog

$txt['modlog_date'] = 'Datum';
$txt['modlog_member'] = 'Član';
$txt['modlog_position'] = 'Pozicija';
$txt['modlog_action'] = 'Akcija';
$txt['modlog_ip'] = 'IP';
$txt['modlog_search_result'] = 'Rezultati pretrage';
$txt['modlog_total_entries'] = 'Ukupno zapisa';
$txt['modlog_ac_approve_topic'] = 'Odobrio temu &quot;{topic}&quot; koju je napisao član &quot;{member}&quot;';
$txt['modlog_ac_unapprove_topic'] = 'Unapproved topic &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_approve'] = 'Odobrio poruku &quot;{subject}&quot; u temi &quot;{topic}&quot; koju je napisao član &quot;{member}&quot;';
$txt['modlog_ac_unapprove'] = 'Unapproved message &quot;{subject}&quot; in &quot;{topic}&quot; by &quot;{member}&quot;';
$txt['modlog_ac_lock'] = 'Zaključao &quot;{topic}&quot;';
$txt['modlog_ac_warning'] = 'Upozorio korisnika {member} zbog &quot;{message}&quot;';
$txt['modlog_ac_unlock'] = 'Otključao &quot;{topic}&quot;';
$txt['modlog_ac_sticky'] = 'Pinned &quot;{topic}&quot;';
$txt['modlog_ac_unsticky'] = 'Unpinned &quot;{topic}&quot;';
$txt['modlog_ac_delete'] = 'Izbrisao &quot;{subject}&quot; koju je napisao &quot;{member}&quot; u &quot;{topic}&quot;';
$txt['modlog_ac_delete_member'] = 'Izbrisao člana &quot;{name}&quot;';
$txt['modlog_ac_remove'] = 'Uklonio temu &quot;{topic}&quot; iz &quot;{board}&quot;';
$txt['modlog_ac_modify'] = 'Izmenio &quot;{message}&quot; koju je napisao član &quot;{member}&quot;';
$txt['modlog_ac_merge'] = 'Spojio teme i napravio &quot;{topic}&quot;';
$txt['modlog_ac_split'] = 'Podelio temu &quot;{topic}&quot; i napravio &quot;{new_topic}&quot;';
$txt['modlog_ac_move'] = 'Premestio &quot;{topic}&quot; iz &quot;{board_from}&quot; u &quot;{board_to}&quot;';
$txt['modlog_ac_profile'] = 'Izmenio profil člana &quot;{member}&quot;';
$txt['modlog_ac_pruned'] = 'Izbrisao neke poruke starije od {days} dana';
$txt['modlog_ac_news'] = 'Izmenio vesti';
$txt['modlog_enter_comment'] = 'Unesite urednički komentar';
$txt['modlog_moderation_log'] = 'Dnevnik uređivanja';
$txt['modlog_moderation_log_desc'] = 'Ispod je spisak svih akcija uređivanja koje su sproveli urednici ovog foruma.<br /><strong>Napomena:</strong> Unosi ne mogu da budu uklonjeni iz ovog dnevnika ako nisu stari najmanje 24 sata.';
$txt['modlog_no_entries_found'] = 'Nema pronađenih zapisa u dnevniku uređivanja.';
$txt['modlog_remove'] = 'Obriši izabrano';
$txt['modlog_removeall'] = 'Clear Log';
$txt['modlog_remove_selected_confirm'] = 'Are you sure you want to delete the selected log entries?';
$txt['modlog_remove_all_confirm'] = 'Are you sure you want to completely clear the log?';
$txt['modlog_go'] = 'Idi';
$txt['modlog_add'] = 'Dodaj';
$txt['modlog_search'] = 'Brza pretraga';
$txt['modlog_by'] = 'od';
$txt['modlog_id'] = '<em>(ID:%1$d)</em>';

$txt['modlog_ac_add_warn_template'] = 'Dodao predložak upozorenja: &quot;{template}&quot;';
$txt['modlog_ac_modify_warn_template'] = 'Izmenio predložak upozorenja: &quot;{template}&quot;';
$txt['modlog_ac_delete_warn_template'] = 'Obrisao predložak upozorenja: &quot;{template}&quot;';

$txt['modlog_ac_ban'] = 'Dodao okidače zabrana:';
$txt['modlog_ac_ban_update'] = 'Edited ban triggers:';
$txt['modlog_ac_ban_remove'] = 'Removed ban triggers:';
$txt['modlog_ac_ban_trigger_member'] = ' <em>član:</em> {member}';
$txt['modlog_ac_ban_trigger_email'] = ' <em>imejl:</em> {email}';
$txt['modlog_ac_ban_trigger_ip_range'] = '<em>IP:</em> {ip_range}';
$txt['modlog_ac_ban_trigger_hostname'] = ' <em>ime domaćina:</em> {hostname}';

$txt['modlog_admin_log'] = 'Dnevnik administriranja';
$txt['modlog_admin_log_desc'] = 'Ispod je spisak svih administratorskih akcija sprovedenih na ovom forumu.<br /><strong>Napomena:</strong> Unosi ne mogu da budu uklonjeni iz ovog dnevnika ako nisu stari najmanje 24 sata.';
$txt['modlog_admin_log_no_entries_found'] = 'Trenutno nema zapisa u dnevniku administracije.';

// Admin type strings.
$txt['modlog_ac_upgrade'] = 'Ažurirao forum na verziju {version}';
$txt['modlog_ac_install'] = 'Instalirao verziju {version}';
$txt['modlog_ac_add_board'] = 'Dodao nov forum: &quot;{board}&quot;';
$txt['modlog_ac_edit_board'] = 'Izmenio forum &quot;{board}&quot;';
$txt['modlog_ac_delete_board'] = 'Izbrisao forum &quot;{boardname}&quot;';
$txt['modlog_ac_add_cat'] = 'Dodao novu kategoriju, &quot;{catname}&quot;';
$txt['modlog_ac_edit_cat'] = 'Izmenio kategoriju &quot;{catname}&quot;';
$txt['modlog_ac_delete_cat'] = 'Izbrisao kategoriju &quot;{catname}&quot;';

$txt['modlog_ac_delete_group'] = 'Izbrisao grupu &quot;{group}&quot;';
$txt['modlog_ac_add_group'] = 'Dodao grupu &quot;{group}&quot;';
$txt['modlog_ac_edited_group'] = 'Izmenio grupu &quot;{group}&quot;';
$txt['modlog_ac_added_to_group'] = 'Dodao člana &quot;{member}&quot; u grupu &quot;{group}&quot;';
$txt['modlog_ac_removed_from_group'] = 'Uklonio člana &quot;{member}&quot; iz grupe &quot;{group}&quot;';
$txt['modlog_ac_removed_all_groups'] = 'Uklonio člana &quot;{member}&quot; iz svih grupa';

$txt['modlog_ac_remind_member'] = 'Podsetio člana &quot;{member}&quot; da aktivira svoj nalog';
$txt['modlog_ac_approve_member'] = 'Odobrio/Aktivirao nalog člana &quot;{member}&quot;';
$txt['modlog_ac_newsletter'] = 'Poslao Infodopis';

$txt['modlog_ac_install_package'] = 'Instaliran novi paket: &quot;{package}&quot;, verzija {version} ';
$txt['modlog_ac_upgrade_package'] = 'Nadograđen paket: &quot;{package}&quot; na verziju {version} ';
$txt['modlog_ac_uninstall_package'] = 'Deinstaliran paket: &quot;{package}&quot;, verzija {version} ';

$txt['modlog_ac_database_backup'] = 'Database backup taken by {member}.';
$txt['modlog_ac_editing_theme'] = '{member} edited a theme.';

// Restore topic.
$txt['modlog_ac_restore_topic'] = 'Vratio temu &quot;{topic}&quot; iz &quot;{board}&quot; u &quot;{board_to}&quot;';
$txt['modlog_ac_restore_posts'] = 'Vratio poruke iz teme &quot;{subject}&quot; u temu &quot;{topic}&quot; u forumu &quot;{board}&quot;.';

$txt['modlog_parameter_guest'] = '<em>Gost</em>';

$txt['modlog_ac_approve_attach'] = 'Approved &quot;{filename}&quot; in &quot;{message}&quot;';
$txt['modlog_ac_remove_attach'] = 'Removed unapproved &quot;{filename}&quot; in &quot;{message}&quot;';