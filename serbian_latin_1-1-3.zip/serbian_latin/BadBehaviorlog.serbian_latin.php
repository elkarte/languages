<?php
// Version: 1.1; BadBehaviorlog

$txt['badbehaviorlog_date'] = 'Datum';
$txt['badbehaviorlog_protocol'] = 'Protokol';
$txt['badbehaviorlog_method'] = 'Metod';
$txt['badbehaviorlog_request'] = 'Zahtev';
$txt['badbehaviorlog_uri'] = 'URL';
$txt['badbehaviorlog_id_member'] = 'Korisnikov ID';
$txt['badbehaviorlog_username'] = 'Korisnicko Ime';
$txt['badbehaviorlog_headers'] = 'Zaglavlja';
$txt['badbehaviorlog_agent'] = 'Pretrazivač';
$txt['badbehaviorlog_entity'] = 'Pošalji';
$txt['badbehaviorlog_key'] = 'Kjuč';
$txt['badbehaviorlog_ip'] = 'IP';
$txt['badbehaviorlog_total_entries'] = 'Ukupno zapisa';
$txt['badbehaviorlog_error_valid_code'] = 'Kod razloga';
$txt['badbehaviorlog_error_valid_response'] = 'HTTP Status';
$txt['badbehaviorlog_error_valid_explaination'] = 'HTTP Razlog';
$txt['badbehaviorlog_error_valid_log'] = 'Detalji';
$txt['badbehaviorlog_log'] = 'LošePonašanje log';
$txt['badbehaviorlog_desc'] = 'Below is a list of all the bad behavior entries that have been logged';
$txt['badbehaviorlog_details'] = 'Additional Details';
$txt['badbehaviorlog_no_entries_found'] = 'There are currently no bad behavior log entries.';

$txt['badbehaviorlog_remove_selection'] = 'Izbriši izabrano';
$txt['badbehaviorlog_remove_selection_confirm'] = 'Are you sure you want to delete the selected log entries?';
$txt['badbehaviorlog_remove_filtered_results'] = 'Remove all filtered results';
$txt['badbehaviorlog_remove_filtered_results_confirm'] = 'Are you sure you want to delete the filtered entries?';
$txt['badbehaviorlog_sure_remove'] = 'Are you sure you want to completely clear the bad behavior log?';

$txt['badbehaviorlog_remove'] = 'Obriši izabrano';
$txt['badbehaviorlog_removeall'] = 'Clear Log';
$txt['badbehaviorlog_clear_filter'] = 'Očisti filter';

$txt['badbehaviorlog_apply_filter_of_type'] = 'Primeni filter tipa';
$txt['badbehaviorlog_apply_filter'] = 'Primeni filter';
$txt['badbehaviorlog_applying_filter'] = 'Primenjujem filter';
$txt['badbehaviorlog_filter_only_member'] = 'Only show the badbehavior logs of this member';
$txt['badbehaviorlog_filter_only_ip'] = 'Only show the badbehavior logs of this IP address';
$txt['badbehaviorlog_filter_only_session'] = 'Only show the badbehaviorlogs of this session';
$txt['badbehaviorlog_filter_only_headers'] = 'Only show the badbehavior logs of this URL';
$txt['badbehaviorlog_filter_only_agent'] = 'Only show the entries with the same user agent';

$txt['badbehaviorlog_session'] = 'Sesija';
$txt['badbehaviorlog_error_url'] = 'URL of the page that was logged';

$txt['badbehaviorlog_reverse_direction'] = 'Preokreni hronološki red u spisku';
$txt['badbehaviorlog_filter_only_type'] = 'Only show the logs with this code';