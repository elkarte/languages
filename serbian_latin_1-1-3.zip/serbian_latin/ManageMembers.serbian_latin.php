<?php
// Version: 1.1; ManageMembers

$txt['groups'] = 'Grupe';
$txt['viewing_groups'] = 'Gleda grupe članova';

$txt['membergroups_title'] = 'Upravljanje korisničkim grupama';
$txt['membergroups_description'] = 'Korisničke grupe su grupe članova koji imaju slične dozvole, podešavanja i prava pristupa. Neke korisničke grupe su bazirane na broju poruka koje je korisnik poslao. Možete da dodate nekoga u grupu izmenom njegovog profila.';
$txt['membergroups_modify'] = 'Izmeni';
$txt['membergroups_modify_parent'] = 'Modify parent group';

$txt['membergroups_add_group'] = 'Dodaj grupu';
$txt['membergroups_regular'] = 'Obične grupe';
$txt['membergroups_post'] = 'Grupe zasnovane na broju poruka';
$txt['membergroups_guests_na'] = 'n/d';

$txt['membergroups_group_name'] = 'Ime grupe članova';
$txt['membergroups_new_board'] = 'Vidljivi forumi';
$txt['membergroups_new_board_desc'] = 'Forumi koje članovi grupe mogu da vide.';
$txt['membergroups_new_board_post_groups'] = '<em>Napomena: normalno, grupama zasnovanim na broju poruka nije potreban pristup pošto će im grupa u kojima je član dati pristup.</em>';
$txt['membergroups_new_as_inherit'] = 'nasledi od';
$txt['membergroups_new_as_type'] = 'po tipu';
$txt['membergroups_new_as_copy'] = 'ili zasnovano na';
$txt['membergroups_new_copy_none'] = '(bez)';
$txt['membergroups_can_edit_later'] = 'Možete da ih izmenite kasnije.';

$txt['membergroups_edit_group'] = 'Izmeni grupu';
$txt['membergroups_edit_name'] = 'Ime grupe';
$txt['membergroups_edit_inherit_permissions'] = 'Nasledi dozvole';
$txt['membergroups_edit_inherit_permissions_desc'] = 'Izaberite &quot;Ne&quot; da biste postavili posebne dozvole za ovu grupu.';
$txt['membergroups_edit_inherit_permissions_no'] = 'Ne - koristi jedinstvene dozvole';
$txt['membergroups_edit_inherit_permissions_from'] = 'Nasledi od';
$txt['membergroups_edit_hidden'] = 'Vidljivost';
$txt['membergroups_edit_hidden_no'] = 'Vidljivo';
$txt['membergroups_edit_hidden_boardindex'] = 'Visible - Apart from in group key';
$txt['membergroups_edit_hidden_all'] = 'Nevidljivo';
// Do not use numeric entities in the below string.
$txt['membergroups_edit_hidden_warning'] = 'Da li ste sigurni da želite da onemogućite postavljanje ove grupe kao primarne grupe člana?\\n\\nOvim se grupa može koristiti samo kao dodatna grupa člana. Kod svih članova koji je imaju kao &quot;primarnu&quot; preći će u dodatnu grupu.';
$txt['membergroups_edit_desc'] = 'Opis grupe';
$txt['membergroups_edit_group_type'] = 'Group type';
$txt['membergroups_edit_select_group_type'] = 'Select Group type';
$txt['membergroups_group_type_private'] = 'Privatna <span class="smalltext">(Članstvo mora da bude dodeljeno)</span>';
$txt['membergroups_group_type_protected'] = 'Zaštićena <span class="smalltext">(Samo administratori mogu promeniti podešavanja)</span> ';
$txt['membergroups_group_type_request'] = 'Na zahtev <span class="smalltext">(Korisnik može da zatraži članstvo)</span>';
$txt['membergroups_group_type_free'] = 'Slobodna <span class="smalltext">(Korisnik može da se pridruži ili ode iz grupe kada poželi)</span>';
$txt['membergroups_group_type_post'] = 'Zasnovana na broju poruka <span class="smalltext">(Članstvo zasnovano na broju poruka)</span>';
$txt['membergroups_min_posts'] = 'Potrebno poruka';
$txt['membergroups_online_color'] = 'Boja u spisku prisutnih';
$txt['membergroups_icon_count'] = 'Number of icon images';
$txt['membergroups_icon_image'] = 'Icon image filename';
$txt['membergroups_icon_image_note'] = 'Upload icon images in to the default theme directory to enable selection.<br />Select the icon to change it.';
$txt['membergroups_max_messages'] = 'Najveći broj privatnih poruka';
$txt['membergroups_max_messages_note'] = '(0 = neograničeno)';
$txt['membergroups_max_messages_desc'] = 'Here you can set the limit of personal messages a user can keep on the server.<br />
To allow store an unlimited number of personal messages, you can set the value to 0';
$txt['membergroups_edit_save'] = 'Sačuvaj';
$txt['membergroups_delete'] = 'Obriši';
$txt['membergroups_confirm_delete'] = 'Are you sure you want to delete this group?';

$txt['membergroups_members_title'] = 'Prikazujem članove grupe';
$txt['membergroups_members_group_members'] = 'Članovi grupe';
$txt['membergroups_members_no_members'] = 'Ova grupe je trenutno prazna';
$txt['membergroups_members_add_title'] = 'Dodaj člana ovoj grupi';
$txt['membergroups_members_add_desc'] = 'Spisak članova za dodavanje';
$txt['membergroups_members_add'] = 'Dodaj članove';
$txt['membergroups_members_remove'] = 'Ukloni iz grupe';
$txt['membergroups_members_last_active'] = 'Poslednji put aktivan';
$txt['membergroups_members_additional_only'] = 'Dodaj samo kao dodatnu grupu.';
$txt['membergroups_members_group_moderators'] = 'Urednici grupe';
$txt['membergroups_members_description'] = 'Opis';
// Use javascript escaping in the below.
$txt['membergroups_members_deadmin_confirm'] = 'Da li ste sigurni da želite da uklonite sebe iz grupe administratora?';

$txt['membergroups_postgroups'] = 'Grupe zasnovane na broju poruka';
$txt['membergroups_settings'] = 'Podešavanja grupa članova';
$txt['groups_manage_membergroups'] = 'Grupe kojima je dozvoljeno da vrše izmenu grupa članova';
$txt['membergroups_select_permission_type'] = 'Izaberite profil dozvola';
$txt['membergroups_images_url'] = '{theme URL}/images/group_icons/';
$txt['membergroups_select_visible_boards'] = 'Prikaži forume';
$txt['membergroups_members_top'] = 'Korisnici';
$txt['membergroups_name'] = 'Ime';
$txt['membergroups_icons'] = 'Ikonice';

$txt['admin_browse_approve'] = 'Članovi čiji nalozi čekaju na odobrenje';
$txt['admin_browse_approve_desc'] = 'Odavde možete da upravljate svim članovima čiji nalozi čekaju na odobrenje.';
$txt['admin_browse_activate'] = 'Članovi čiji nalozi čekaju na aktivaciju';
$txt['admin_browse_activate_desc'] = 'Ova stranica prikazuje spisak svih članova koji još uvek nisu aktivirali svoje naloge na ovom forumu.';
$txt['admin_browse_awaiting_approval'] = 'Awaiting Approval [%1$d]';
$txt['admin_browse_awaiting_activate'] = 'Awaiting Activation [%1$d]';

$txt['admin_browse_username'] = 'Korisničko ime';
$txt['admin_browse_email'] = 'Imejl adresa';
$txt['admin_browse_ip'] = 'IP adresa';
$txt['admin_browse_registered'] = 'Registrovan';
$txt['admin_browse_id'] = 'ID';
$txt['admin_browse_with_selected'] = 'Sa izabranim';
$txt['admin_browse_no_members_approval'] = 'Trenutno nema članova koji čekaju na odobrenje.';
$txt['admin_browse_no_members_activate'] = 'Nema članova koji još uvek nisu aktivirali svoje naloge.';

// Don't use entities in the below strings, except the main ones. (lt, gt, quot.)
$txt['admin_browse_warn'] = 'sve izabrane članove?';
$txt['admin_browse_outstanding_warn'] = 'sve zahvaćene članove?';
$txt['admin_browse_w_approve'] = 'Odobri';
$txt['admin_browse_w_activate'] = 'Aktiviraj';
$txt['admin_browse_w_delete'] = 'Obriši';
$txt['admin_browse_w_reject'] = 'Reject (Delete)';
$txt['admin_browse_w_remind'] = 'Podseti';
$txt['admin_browse_w_approve_deletion'] = 'Odobri (obriši naloge)';
$txt['admin_browse_w_email'] = 'i pošalji imejl';
$txt['admin_browse_w_approve_require_activate'] = 'Approve and require activation';

$txt['admin_browse_filter_by'] = 'Filtriraj po';
$txt['admin_browse_filter_show'] = 'Prikazujem';
$txt['admin_browse_filter_type_0'] = 'Unactivated new accounts';
$txt['admin_browse_filter_type_2'] = 'Unactivated email changes';
$txt['admin_browse_filter_type_3'] = 'Unapproved new accounts';
$txt['admin_browse_filter_type_4'] = 'Unapproved account deletions';
$txt['admin_browse_filter_type_5'] = 'Neodobrene naloge mladih korisnika';

$txt['admin_browse_outstanding'] = 'Izvanredni članovi';
$txt['admin_browse_outstanding_days_1'] = 'Nad svim članovima koji su se registrovali pre više od';
$txt['admin_browse_outstanding_days_2'] = 'dana';
$txt['admin_browse_outstanding_perform'] = 'Izvrši sledeće akcije';
$txt['admin_browse_outstanding_go'] = 'Izvrši akciju';

$txt['check_for_duplicate'] = 'Check for duplicates';
$txt['dont_check_for_duplicate'] = 'Don\'t check for duplicates';
$txt['duplicates'] = 'Dvostruke';

$txt['not_activated'] = 'Nije aktiviran';