<?php
// Version: 1.1; Who

$txt['who_hidden'] = '<em>hmm... nemam pojma, izvinite</em>';
$txt['who_admin'] = 'Gleda admin panel';
$txt['who_moderate'] = 'Gleda modetator panel';
$txt['who_generic'] = 'Gleda %1$s';
$txt['who_unknown'] = '<em>Nepoznata akcija</em>';
$txt['who_user'] = 'Korisnik';
$txt['who_time'] = 'Vreme';
$txt['who_action'] = 'Akcija';
$txt['who_show1'] = 'Prikaži ';
$txt['who_show_members_only'] = 'samo članove';
$txt['who_show_guests_only'] = 'samo goste';
$txt['who_show_spiders_only'] = 'samo pauke';
$txt['who_show_all'] = 'sve';
$txt['who_no_online_spiders'] = 'Trenutno nema prisutnih pauka.';
$txt['who_no_online_guests'] = 'Trenutni nema prisutnih gostiju.';
$txt['who_no_online_members'] = 'Trenutno nema prisutnih članova.';

$txt['whospider_login'] = 'Gleda stranicu za prijavljivanje.';
$txt['whospider_register'] = 'Gleda stranicu za registraciju.';
$txt['whospider_reminder'] = 'Gleda stranicu za podsećanje na lozinku.';

$txt['whoall_activate'] = 'Aktivira svoj nalog.';
$txt['whoall_buddy'] = 'Menja listu prijatelja.';
$txt['whoall_coppa'] = 'Popunjava forumu pristanka roditelja/staratelja.';
$txt['whoall_credits'] = 'Gleda Credits stranicu.';
$txt['whoall_emailuser'] = 'Šalje mejl drugom članu.';
$txt['whoall_groups'] = 'Gleda stranicu grupe članova.';
$txt['whoall_help'] = 'Čita <a href="{help_url}">stranicu pomoći</a>.';
$txt['whoall_quickhelp'] = 'Čita administratorske stranice pomoći.';
$txt['whoall_pm'] = 'Čita svoje privatne poruke.';
$txt['whoall_auth'] = 'Prijavljuje se na forum.';
$txt['whoall_login'] = 'Gleda stranicu za prijavljivanje.';
$txt['whoall_login2'] = 'Gleda stranicu za prijavljivanje.';
$txt['whoall_logout'] = 'Odjavljuje se sa foruma.';
$txt['whoall_markasread'] = 'Označava teme pročitanim.';
$txt['whoall_mentions'] = 'Čita ko ga je sve spomenuo.';
$txt['whoall_modifykarma_applaud'] = 'Povećava ugled člana.';
$txt['whoall_modifykarma_smite'] = 'Smanjuje reputaciju korisnika.';
$txt['whoall_news'] = 'Čita vesti.';
$txt['whoall_notify'] = 'Menja svoja podešavanja o obaveštavanju.';
$txt['whoall_notifyboard'] = 'Menja svoja podešavanja o obaveštavanju.';
$txt['whoall_openidreturn'] = 'Prijavljuje se koristeći OpenID';
$txt['whoall_quickmod'] = 'Uređuje forum.';
$txt['whoall_recent'] = 'Čita <a href="{recent_url}">listu nedavnih tema</a>.';
$txt['whoall_register'] = 'Registruje nalog na forumu.';
$txt['whoall_reminder'] = 'Zahteva novu lozinku.';
$txt['whoall_reporttm'] = 'Prijavljuje temu uredniku.';
$txt['whoall_spellcheck'] = 'Koristi proveru pravopisa.';
$txt['whoall_unread'] = 'Čita nepročitane teme od svoje poslednje posete.';
$txt['whoall_unreadreplies'] = 'Čita nepročitane odgovore od svoje poslednje posete.';
$txt['whoall_who'] = 'Čita <a href="{who_url}">ko je online</a>.';

$txt['whoall_collapse_collapse'] = 'Skuplja kategoriju.';
$txt['whoall_collapse_expand'] = 'Proširuje kategoriju.';
$txt['whoall_pm_removeall'] = 'Uklanja sve svoje privatne poruke.';
$txt['whoall_pm_send'] = 'Šalje privatnu poruku.';
$txt['whoall_pm_send2'] = 'Šalje privatnu poruku.';

$txt['whotopic_announce'] = 'Objavljuje temu &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_attachapprove'] = 'Odobrava priloženu datoteku.';
$txt['whotopic_dlattach'] = 'Gleda priloženu datoteku.';
$txt['whotopic_deletemsg'] = 'Briše poruku.';
$txt['whotopic_editpoll'] = 'Ažurira anketu u &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_editpoll2'] = 'Ažurira anketu u &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_jsmodify'] = 'Ažurira poruku u &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_likes'] = 'Lajkuje poruku u temi &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lock'] = 'Zaključava temu &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_lockvoting'] = 'Zaključava anketu u &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_mergetopics'] = 'Kombinuje temu &quot;<a href="%1$s">%2$s</a>&quot; sa nekom drugom temom.';
$txt['whotopic_movetopic'] = 'Premešta temu &quot;<a href="%1$s">%2$s</a>&quot; u drugi forum.';
$txt['whotopic_movetopic2'] = 'Premešta temu &quot;<a href="%1$s">%2$s</a>&quot; u drugi forum.';
$txt['whotopic_post'] = 'Postuje u <a href="%1$s">%2$s</a>.';
$txt['whotopic_post2'] = 'Postuje u <a href="%1$s">%2$s</a>.';
$txt['whotopic_printpage'] = 'Štampa temu &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_quickmod2'] = 'Moderiše temu <a href="%1$s">%2$s</a>.';
$txt['whotopic_poll_remove'] = 'Udaljava anketu iz &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_removetopic2'] = 'Udaljava temu <a href="%1$s">%2$s</a>.';
$txt['whotopic_sendtopic'] = 'Šalje temu &quot;<a href="%1$s">%2$s</a>&quot; prijatelju.';
$txt['whotopic_splittopics'] = 'Rastavlja temu &quot;<a href="%1$s">%2$s</a>&quot; u dve teme.';
$txt['whotopic_sticky'] = 'Zakačio temu &quot;<a href="%1$s">%2$s</a>&quot;.';
$txt['whotopic_unwatch'] = 'Prestao je pratiti temu.';
$txt['whotopic_vote'] = 'Glasa u <a href="%1$s">%2$s</a>.';
$txt['whotopic_watch'] = 'Počeo je pratiti temu.';

$txt['whopost_quotefast'] = 'Citira post iz &quot;<a href="%1$s">%2$s</a>&quot;.';

$txt['whoadmin_editagreement'] = 'Uređuje sporazum o registraciji.';
$txt['whoadmin_featuresettings'] = 'Uređuje mogućnosti i opcije foruma.';
$txt['whoadmin_modlog'] = 'Gleda dnevnik uređivanja.';
$txt['whoadmin_serversettings'] = 'Menja podešavanja foruma.';
$txt['whoadmin_packageget'] = 'Preuzima pakete.';
$txt['whoadmin_packages'] = 'Gleda menadžer paketa.';
$txt['whoadmin_permissions'] = 'Uređuje dozvole na forumu.';
$txt['whoadmin_pgdownload'] = 'Preuzima paket.';
$txt['whoadmin_theme'] = 'Menja podešavanja teme.';
$txt['whoadmin_trackip'] = 'Prati IP adresu.';

$txt['whoallow_manageboards'] = 'Menja podešavanja foruma i kategorija.';
$txt['whoallow_admin'] = 'Čita <a href="{admin_url}">administracijski panel</a>.';
$txt['whoallow_ban'] = 'Menja spisak zabrana.';
$txt['whoallow_boardrecount'] = 'Prebrojava broj poruka i tema na forumu.';
$txt['whoallow_calendar'] = 'Gleda <a href="{calendar_url}">kalendar</a>.';
$txt['whoallow_editnews'] = 'Uređuje vesti.';
$txt['whoallow_mailing'] = 'Šalje mejl sa foruma.';
$txt['whoallow_maintain'] = 'Izvodi rutinsko održavanje foruma.';
$txt['whoallow_manageattachments'] = 'Upravlja priloženim datotekama.';
$txt['whoallow_moderate'] = 'Čita <a href="{moderate_url}">čita moderacijski panel</a>.';
$txt['whoallow_memberlist'] = 'Gleda <a href="{memberlist_url}">listu korisnika</a>.';
$txt['whoallow_optimizetables'] = 'Optimizuje tabele u bazi podataka.';
$txt['whoallow_repairboards'] = 'Popravlja tabele u bazi podataka.';
$txt['whoallow_search'] = '<a href="{search_url}">Pretražuje</a> forum.';
$txt['whoallow_search_results'] = 'Gleda rezultate pretrage.';
$txt['whoallow_setcensor'] = 'Menja cenzurisane reči.';
$txt['whoallow_setreserve'] = 'Menja rezervisana imena.';
$txt['whoallow_stats'] = 'Čita <a href="{stats_url}">statistiku foruma</a>.';
$txt['whoallow_viewErrorLog'] = 'Gleda dnevnik grešaka.';
$txt['whoallow_viewmembers'] = 'Gleda spisak članova.';

$txt['who_topic'] = 'Čita temu <a href="%1$s">%2$s</a>.';
$txt['who_board'] = 'Čita forum <a href="%1$s">%2$s</a>.';
$txt['who_index'] = 'Čita početnu stranicu foruma <a href="{script_url}">{forum_name}</a>.';
$txt['who_viewprofile'] = 'Gleda profil od <a href="%1$s">%2$s</a>.';
$txt['who_profile'] = 'Ažurira profil od <a href="%1$s">%2$s</a>.';
$txt['who_post'] = 'Objavljuje novu temu u <a href="%1$s">%2$s</a>.';
$txt['who_poll'] = 'Objavljuje novu anketu u <a href="%1$s">%2$s</a>.';
$txt['who_topicbyemail'] = 'Počinje novu temu putem eMail-a u <a href="%1$s">%2$s</a>.';

$txt['whotopic_postbyemail'] = 'Postuje putem eMail-a u <a href="%1$s">%2$s</a>.';
$txt['whoall_pm_byemail'] = 'Šalje privatnu poruku putem eMail-a.';

// Credits text
$txt['credits'] = 'Zasluge';
$txt['credits_intro'] = 'ElkArte je 100% besplatan i open-source. Mi ohrabrujemo i podržavamo aktivnu, otvorenu zajednicu koja prihvata doprinose iz javnosti. Želimo da zahvalimo svima koji su podržali projekat kodom, povratnim informacijama, prijavama grešaka, mišljenima, zato što sve ovo ne bi bilo moguće bez vas. Takodje specialno želimo osvetliti <a href="https://github.com/SimpleMachines" target="_blank" class="new_win">SMF</a>, projekat od kojeg je nastao ElkArte.';
$txt['credits_contributors'] = 'Saradnici i dobrovoljci';
$txt['credits_and'] = 'i';
$txt['credits_copyright'] = 'Prava kopiranja';
$txt['credits_forum'] = 'Forum';
$txt['credits_addons'] = 'Dodaci';
$txt['credits_software_graphics'] = 'Softver/Grafika';
$txt['credits_software'] = 'Softver';
$txt['credits_graphics'] = 'Grafika';
$txt['credits_fonts'] = 'Fontovi';
$txt['credits_groups_contrib'] = 'Saradnici i dobrovoljci';
$txt['credits_contrib_list'] = 'Za potpunu listu svih koji su pomogli u stvaranju Elkarte, molimo vas da pogledate na oficialnoj GitHub <a href="https://github.com/elkarte/Elkarte/graphs/contributors" target="_blank" class="new_win">listi saradnika i dobrovoljaca.</a>';
$txt['credits_license'] = 'Licensa';
$txt['credits_copyright'] = 'Prava kopiranja';
$txt['credits_version'] = 'Verzija';
// Replace "English" with the name of this language pack in the string below.
$txt['credits_groups_translators'] = 'Prevodiocima';
$txt['credits_translators_message'] = 'Hvala vam za vaš trud koji je omogućio svim ljudima širom planete da koriste ElkArte.  Za kompletnu listu pogledajte Transifex <a href="https://www.transifex.com/organization/elkarte/dashboard" target="_blank" class="new_win">listu saradnika i dobrovoljaca.</a>';

// Overrides the already defined strings to get clean results in the table
$txt['today'] = '%1$s';
$txt['yesterday'] = '%1$s';