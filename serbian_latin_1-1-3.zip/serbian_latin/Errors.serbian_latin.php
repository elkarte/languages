<?php
// Version: 1.1; Errors

$txt['no_access'] = 'Sorry, we can\'t let you access this section. We can\'t even tell you if it exists. You\'re welcome to visit the main page and choose your way from there.';
$txt['not_guests'] = 'Sorry, this action is not available to guests.';

$txt['mods_only'] = 'Only moderators can use the direct remove function, please remove this message through the modify feature.';
$txt['no_name'] = 'You didn\'t fill the name field out. We can\'t let you continue without a name, sorry.';
$txt['no_email'] = 'You didn\'t fill the email field out. We can\'t let you continue without an email, sorry.';
$txt['topic_locked'] = 'Tema je zaključana. Nemate dozvolu da šaljete ili izmenjujete poruke...';
$txt['no_password'] = 'Polje za lozinku je prazno';
$txt['passwords_dont_match'] = 'Lozinke nisu iste.';
$txt['register_to_use'] = 'Morate da se registrujete pre nego što počnete da koristite ovu mogućnost.';
$txt['username_reserved'] = 'The user name you tried to use contains the reserved name \'%1$s\'. Please try another user name.';
$txt['numbers_one_to_nine'] = 'Polje prihvata samo brojeve od 0 do 9';
$txt['not_a_user'] = 'Korisnik čiji profil želite da pogledate ne postoji.';
$txt['not_a_topic'] = 'Tema ne postoji u ovom forumu.';
$txt['not_approved_topic'] = 'Ova tema još nije odobrena.';
$txt['email_in_use'] = 'Tu imejl adresu (%s) već koristi jedan registrovan član. Ako mislite da je ovo greška, posetite stranicu za prijavljivanje i upotrebite podsetnik za lozinku sa tom adresom.';

$txt['didnt_select_vote'] = 'Niste izabrali opciju za glasanje.';
$txt['poll_error'] = 'Something isn\'t working, sorry: either that poll doesn\'t exist, the poll has been locked, or you tried to vote twice.';
$txt['locked_by_admin'] = 'Zaključano je od strane administratora. Nemate dozvolu da je odključate.';
$txt['not_enough_posts_karma'] = 'Nemate dovoljno poruka da biste mogli da menjate ugled. Potrebno vam je najmanje %1$d.';
$txt['cant_change_own_karma'] = 'Nemate dozvolu da menjate svoj ugled.';
$txt['karma_wait_time'] = 'Ne možete da ponovo promenite ugled u sledećih %1$s %2$s.';
$txt['feature_disabled'] = 'Ova opcija je onemogućena.';
$txt['feature_no_exists'] = 'Sorry, this feature doesn\'t exist.';
$txt['couldnt_connect'] = 'Ne mogu da se povežem sa serverom ili ne mogu da pronađem datoteku.';
$txt['no_board'] = 'Forum koji ste precizirali ne postoji';
$txt['no_message'] = 'The message is no longer available';
$txt['no_topic_id'] = 'Precizirali ste neispravan ID teme.';
$txt['split_first_post'] = 'Ne možete da podelite temu kod prve poruke.';
$txt['topic_one_post'] = 'Tema sadrži samo jednu poruku i ne može biti podeljena.';
$txt['no_posts_selected'] = 'Nema izabranih poruka';
$txt['selected_all_posts'] = 'Ne mogu da podelim temu. Izabrali ste sve poruke.';
$txt['cant_find_messages'] = 'Ne mogu da pronađem poruke.';
$txt['cant_find_user_email'] = 'Ne mogu da pronađem korisnikovu imejl adresu.';
$txt['cant_insert_topic'] = 'Ne mogu da umetnem temu.';
$txt['session_timeout'] = 'Your session timed out while posting. Please go back and try again.';
$txt['session_timeout_file_upload'] = 'Your session timed out while uploading the file. Please try again.';
$txt['no_files_uploaded'] = 'There are no files to upload.';
$txt['session_verify_fail'] = 'Session verification failed. Please try logging out and back in again, and then try again.';
$txt['verify_url_fail'] = 'Unable to verify referring URL: %1$s. Please go back and try again.';
$txt['token_verify_fail'] = 'Token verification failed. Please go back and try again.';
$txt['guest_vote_disabled'] = 'Gosti ne mogu da glasaju u ovoj anketi.';

$txt['cannot_access_mod_center'] = 'Nemate dozvolu da pristupite uređivačkom centru.';
$txt['cannot_admin_forum'] = 'Nemate dozvolu da administrirate ovaj forum.';
$txt['cannot_announce_topic'] = 'Nije vam dozvoljeno da objavljujete teme na ovom forumu.';
$txt['cannot_approve_posts'] = 'Nemate dozvolu da odobravate stavke.';
$txt['cannot_post_unapproved_attachments'] = 'Nemate dozvolu da postavljate neodobrene priložene datoteke.';
$txt['cannot_post_unapproved_topics'] = 'Nemate dozvolu da postavljate neodobrene teme.';
$txt['cannot_post_unapproved_replies_own'] = 'Nemate dozvolu da šaljete neodobrene odgovore na svoje teme.';
$txt['cannot_post_unapproved_replies_any'] = 'Nemate dozvolu da šaljete neodobrene odgovore na teme ostalih korisnika.';
$txt['cannot_calendar_edit_any'] = 'Ne možete da uređujete događaje.';
$txt['cannot_calendar_edit_own'] = 'Nemate dovoljne privilegije da izmenite sopstvene događaje.';
$txt['cannot_calendar_post'] = 'Postavljanje događaja nije dozvoljeno.';
$txt['cannot_calendar_view'] = 'Nemate dozvolu da pogledate kalendar.';
$txt['cannot_remove_any'] = 'Nemate dozvolu da obrišete bilo koju temu u ovom forumu.';
$txt['cannot_remove_own'] = 'Nije vam dozvoljeno da brišete svoje poruke u ovom forumu.';
$txt['cannot_edit_news'] = 'Nije vam dozvoljeno da uređujete vesti na ovom forumu.';
$txt['cannot_pm_read'] = 'Ne možete da čitate svoje privatne poruke.';
$txt['cannot_pm_send'] = 'Nemate dozvolu za slanje privatnih poruka.';
$txt['cannot_karma_edit'] = 'Nije vam dozvoljeno da menjate ugled drugih ljudi.';
$txt['cannot_like_posts'] = 'You are not allowed to like messages in this board.';
$txt['cannot_lock_any'] = 'Nemate dozvolu da zaključate bilo koju temu na ovom forumu.';
$txt['cannot_lock_own'] = 'Ne možete da zaključavate sopstvene teme na ovom forumu.';
$txt['cannot_make_sticky'] = 'You don\'t have permission to pin this topic.';
$txt['cannot_manage_attachments'] = 'Nije vam dozvoljeno da uređujete priložene datoteke i avatare.';
$txt['cannot_manage_bans'] = 'Nije vam dozvoljeno da menjate spisak zabrana.';
$txt['cannot_manage_boards'] = 'Nije vam dozvoljeno da upravljate forumima i kategorijama.';
$txt['cannot_manage_membergroups'] = 'You don\'t have permission to modify or assign member groups.';
$txt['cannot_manage_permissions'] = 'Nije vam dozvoljeno da menjate dozvole.';
$txt['cannot_manage_smileys'] = 'Nije vam dozvoljeno da upravljate smajlijima i ikonama poruka.';
$txt['cannot_mark_any_notify'] = 'Nemate potrebne dozvole da biste dobijali obaveštenja sa ove teme.';
$txt['cannot_mark_notify'] = 'Nije vam dozvoljeno da tražite obaveštenja iz ovog foruma.';
$txt['cannot_merge_any'] = 'Nije vam dozvoljeno da spajate teme na jednom od izabranih foruma.';
$txt['cannot_moderate_forum'] = 'Nije vam dozvoljeno da uređujete ovaj forum.';
$txt['cannot_moderate_board'] = 'Nije vam dozvoljeno da uređujete ovaj potforum.';
$txt['cannot_modify_any'] = 'Nemate dozvolu da menjate bilo koje poruke.';
$txt['cannot_modify_own'] = 'Nemate dozvolu da menjate sopstvene poruke.';
$txt['cannot_modify_replies'] = 'Ne možete da izmenite ovu poruku iako je odgovor na vašu temu.';
$txt['cannot_move_own'] = 'Nemate dozvolu da premeštate svoje teme u ovom forumu.';
$txt['cannot_move_any'] = 'Nemate dozvolu da premeštate teme u ovaj forum.';
$txt['cannot_poll_add_own'] = 'Nemate dozvolu da dodajete glasanja svojim temama u ovom forumu.';
$txt['cannot_poll_add_any'] = 'Nemate dozvolu da dodate glasanje ovoj temi.';
$txt['cannot_poll_edit_own'] = 'Ne možete da izmenite ovo glasanje iako ste ga vi postavili.';
$txt['cannot_poll_edit_any'] = 'Zabranjena vam je izmena glasanja u ovom forumu.';
$txt['cannot_poll_lock_own'] = 'Nemate dozvolu da zaključavate svoja glasanja u ovom forumu.';
$txt['cannot_poll_lock_any'] = 'Nemate dozvolu da zaključavate glasanja.';
$txt['cannot_poll_post'] = 'Nije vam dozvoljeno da postavljate glasanja u ovom forumu.';
$txt['cannot_poll_remove_own'] = 'Nemate dozvolu da uklonite ovo glasanje iz vaše teme.';
$txt['cannot_poll_remove_any'] = 'Nije vam dozvoljeno da uklanjate glasanja iz ovog foruma.';
$txt['cannot_poll_view'] = 'Nemate dozvolu da pogledate glasanja u ovom forumu.';
$txt['cannot_poll_vote'] = 'Ne možete da glasate u ovom forumu.';
$txt['cannot_post_attachment'] = 'Nemate dozvolu da ovde prilažete datoteke.';
$txt['cannot_post_new'] = 'Ne možete da postavljate nove teme u ovom forumu.';
$txt['cannot_post_new_board'] = 'Sorry, you cannot post new topics in the board %1$s.';
$txt['cannot_post_reply_any'] = 'Nemate dozvolu da odgovarate na teme u ovom forumu.';
$txt['cannot_post_reply_own'] = 'Nije vam dozvoljeno da odgovarate čak ni na sopstvene teme u ovom forumu.';
$txt['cannot_profile_remove_own'] = 'Nije vam dozvoljeno da obrišete svoj nalog.';
$txt['cannot_profile_remove_any'] = 'You don\'t have the appropriate permissions to remove accounts.';
$txt['cannot_profile_extra_any'] = 'Nije vam dozvoljeno da menjate podešavanja profila.';
$txt['cannot_profile_identity_any'] = 'Nije vam dozvoljeno da menjate podešavanja naloga.';
$txt['cannot_profile_title_any'] = 'Ne možete da menjate prilagođene nazive drugih ljudi.';
$txt['cannot_profile_extra_own'] = 'Nemate dovoljne privilegije za izmenu podataka u profilu.';
$txt['cannot_profile_identity_own'] = 'Trenutno ne možete da promenite svoj identitet.';
$txt['cannot_profile_title_own'] = 'Nije vam dozvoljeno da menjate svoj prilagođeni naziv.';
$txt['cannot_profile_set_avatar'] = 'You are not permitted to change your avatar.';
$txt['cannot_profile_view_own'] = 'Ne možete da pogledate svoj profil.';
$txt['cannot_profile_view_any'] = 'Nemate dozvolu da gledate profile korisnika.';
$txt['cannot_delete_own'] = 'Ouch, sorry, you cannot delete your posts on this board.';
$txt['cannot_delete_replies'] = 'Ne možete da uklonite ove poruke iako su odgovori na vašu temu.';
$txt['cannot_delete_any'] = 'Ouch, sorry, you cannot delete posts in this board.';
$txt['cannot_report_any'] = 'Nije vam dozvoljeno da prijavljujete poruke u ovom forumu.';
$txt['cannot_search_posts'] = 'Nije vam dozvoljeno da pretražujete poruke u ovom forumu.';
$txt['cannot_send_mail'] = 'Nemate dozvolu da svima pošaljete mejlove.';
$txt['cannot_issue_warning'] = 'Nemate dozvolu da izdajete upozorenja članovima.';
$txt['cannot_send_topic'] = 'Administrator je onemogućio slanje tema na ovom forumu.';
$txt['cannot_send_email_to_members'] = 'Sorry, but the administrator has disallowed sending emails on this board.';
$txt['cannot_split_any'] = 'Deoba bilo kojih tema nije dozvoljena u ovom forumu.';
$txt['cannot_view_attachments'] = 'Nije vam dozvoljeno da preuzmete ili pregledate priložene datoteke u ovom forumu.';
$txt['cannot_view_mlist'] = 'You can\'t view the member list because you don\'t have permission to.';
$txt['cannot_view_stats'] = 'Nemate dozvolu da pogledate statistike foruma.';
$txt['cannot_who_view'] = 'Nemate dozvolu da pogledate spisak prisutnih korisnika.';
$txt['cannot_like_posts_stats'] = 'Sorry - you don\'t have the proper permissions to view the Like posts stats.';

$txt['no_theme'] = ' We can\'t find that theme.';
$txt['theme_dir_wrong'] = 'Direktorijum podrazumevane teme je pogrešan. Ispravite ga klikom na ovaj tekst.';
$txt['registration_disabled'] = 'Registracija korisnika je trenutno onemogućena.';
$txt['registration_agreement_missing'] = 'The registration agreement file, agreement.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_privacy_policy_missing'] = 'The privacy policy file, privacypolicy.txt, is either missing or empty.  Registrations will be disabled until this is fixed';
$txt['registration_no_secret_question'] = 'Tajno pitanje za ovog člana nije postavljeno.';
$txt['poll_range_error'] = 'Glasanje mora da traje duže od 0 dana.';
$txt['delFirstPost'] = 'You are not allowed to delete the first post in a topic.<p>If you want to delete this topic, click on the Remove link, or ask a moderator/administrator to do it for you.</p>';
$txt['login_cookie_error'] = 'Niste mogli da se prijavite. Proverite podešavanja kolačića.';
$txt['incorrect_answer'] = 'Niste odgovorili tačno na svoje pitanje. Vratite se nazad da biste probali ponovo ili se vratite dve stranice unazad da biste koristili podrazumevanu metodu za dobijanje lozinke.';
$txt['no_mods'] = 'Nema pronađenih urednika!';
$txt['parent_not_found'] = 'Struktura foruma je pokvarena: ne mogu da pronađem roditeljski forum';
$txt['modify_post_time_passed'] = 'Ne možete da izmenite ovu temu jer je dozvoljeno vreme za izmenu isteklo.';

$txt['calendar_off'] = 'Trenutno ne možete da pristupite kalendaru jer je onemogućen.';
$txt['calendar_export_off'] = 'You cannot export calendar events because that feature is currently disabled.';
$txt['invalid_month'] = 'Pogrešna vrednost za mesec.';
$txt['invalid_year'] = 'Pogrešna vrednost za godinu.';
$txt['invalid_day'] = 'Pogrešna vrednost za dan.';
$txt['event_month_missing'] = 'Nedostaje mesec događaja.';
$txt['event_year_missing'] = 'Nedostaje godina događaja.';
$txt['event_day_missing'] = 'Nedostaje dan događaja.';
$txt['event_title_missing'] = 'Nedostaje naslov događaja.';
$txt['invalid_date'] = 'Pogrešan datum.';
$txt['no_event_title'] = 'Niste uneli naslov događaja.';
$txt['missing_board_id'] = 'Nedostaje ID foruma.';
$txt['missing_topic_id'] = 'Nedostaje ID teme.';
$txt['topic_doesnt_exist'] = 'Tema ne postoji.';
$txt['not_your_topic'] = 'Niste vlasnik ove teme.';
$txt['board_doesnt_exist'] = 'Forum ne postoji.';
$txt['no_span'] = 'Opcija kojom se dozvoljava da događaj traje više dana je trenutno onemogućena.';
$txt['invalid_days_numb'] = 'Pogrešan broj dana za trajanje događaja.';

$txt['moveto_noboards'] = 'Nema foruma u koje biste mogli da premestite temu!';
$txt['topic_already_moved'] = 'This topic %1$s has been moved to the board %2$s, please check its new location before moving it again.';

$txt['already_activated'] = 'We\'d love to process your request, but your account has already been activated.';
$txt['still_awaiting_approval'] = 'Vaš nalog i dalje čeka na odobrenje od strane administratora.';

$txt['invalid_email'] = 'Pogrešna imejl adresa / opseg imejl adresa.<br />Primer ispravne imejl adrese: zao.korisnik@los-sajt.com.<br />Primer ispravnog opsega imejl adresa: *@*.los-sajt.com';
$txt['invalid_expiration_date'] = 'Datum isteka nije ispravan.';
$txt['invalid_hostname'] = 'Pogrešno ime domaćina / opseg imena domaćina.<br />Primer ispravnog imena domaćina: proxy4.los-sajt.com<br />Primer ispravnog opsega imena domaćina: *.los-sajt.com';
$txt['invalid_ip'] = 'Pogrešna IP adresa / opseg IP adresa.<br />Primer ispravne IP adrese: 127.0.0.1<br />Primer ispravnog opsega IP adresa: 127.0.0-20.*';
$txt['invalid_tracking_ip'] = 'IP adresa / opseg nije validan.<br />Primer validne IP adrese: 127.0.0.1<br />Primer validnog IP opsega: 127.0.0.*';
$txt['invalid_username'] = 'Ime člana nije nađeno';
$txt['no_user_selected'] = 'Member not found';
$txt['no_ban_admin'] = 'Hey! We can\'t let you ban an admin. If you are certain about this, demote them first!';
$txt['no_bantype_selected'] = 'Nije izabran tip zabrane';
$txt['ban_not_found'] = 'Zabrana nije nađena';
$txt['ban_unknown_restriction_type'] = 'Tip zabrane nije poznat';
$txt['ban_name_empty'] = 'Ime zabrane je ostalo prazno.';
$txt['ban_id_empty'] = 'Dang, sorry. We tried to find this ban ID, but it can\'t be found.';
$txt['ban_group_id_empty'] = 'A ban group needs a group ID, and this group didn\'t have any.';
$txt['ban_no_triggers'] = 'Did you forget to select ban triggers? We need at least one, and we haven\'t got any.';
$txt['ban_ban_item_empty'] = 'Ban trigger not found';
$txt['impossible_insert_new_bangroup'] = 'An error occurred while inserting the new ban';

$txt['like_heading_error'] = 'Error in Likes';
$txt['like_wait_time'] = 'Sorry, you can\'t repeat a like action without waiting %1$s %2$s.';
$txt['like_unlike_error'] = 'Oops, there was an error while liking/unliking the post';
$txt['cant_like_yourself'] = 'Liking your own posts ... it\'s like laughing at your own jokes when there is no one else around  ... lol ... Wait did I just lol myself?';

$txt['ban_name_exists'] = 'Ime ove zabrane već postoji. Izaberite drugo ime.';
$txt['ban_trigger_already_exists'] = 'Ovaj okidač (%1$s) već postoji u %2$s. ';
$txt['attach_check_nag'] = 'Unable to continue due to incomplete data (%1$s).';

$txt['recycle_no_valid_board'] = 'Nije izabran ispravan forum za reciklirane teme';
$txt['post_already_deleted'] = 'The topic or message has already been moved to the recycle board. Are you sure you want to delete it completely?<br />If so follow <a href="%1$s">this link</a>';

$txt['login_threshold_fail'] = 'Nemate više šansi za prijavljivanje.  Pokušajte ponovo kasnije.';
$txt['login_threshold_brute_fail'] = 'Sorry, but you\'ve reached your login attempts threshold.  Please wait 30 seconds and try again.';

$txt['who_off'] = 'We would love to let you peek at Who\'s Online, but unfortunately right now it\'s disabled.';

$txt['merge_create_topic_failed'] = 'Dang, sorry. We tried, we really did, but creating a new topic failed.';
$txt['merge_need_more_topics'] = 'Merge topics requires at least two topics to merge, but we didn\'t get two. Please try again.';

$txt['post_WaitTime_broken'] = 'Poruka sa vaše IP adrese je poslata pre manje od %d sekundi. Pokušajte ponovo kasnije.';
$txt['register_WaitTime_broken'] = 'Upravo ste se registrovali pre %d sekundi!';
$txt['login_WaitTime_broken'] = 'Moraćete da sačekate oko %d sekundi pre nego što se ponovo prijavite.';
$txt['pm_WaitTime_broken'] = 'Zadnja privatna poruka sa vaše IP adrese je poslata pre manje od %d sekundi. Pokušajte ponovo kasnije.';
$txt['reporttm_WaitTime_broken'] = 'Zadnja tema je prijavljena sa vaše IP adrese pre manje od %d sekundi. Pokušajte ponovo kasnije.';
$txt['sendtopic_WaitTime_broken'] = 'Zadnja tema sa vaše IP adrese je poslata pre manje od %d sekundi. Pokušajte ponovo kasnije.';
$txt['sendmail_WaitTime_broken'] = 'Zadnji mejl sa vaše IP adrese je poslat pre manje od %d sekundi. Pokušajte ponovo kasnije.';
$txt['search_WaitTime_broken'] = 'Vaša zadnja pretraga je bila pre manje od %d sekundi. Pokušajte ponovo kasnije.';
$txt['remind_WaitTime_broken'] = 'Your last reminder was less than %1$d seconds ago. Please try again later.';
$txt['contact_WaitTime_broken'] = 'The last time you tried to use the contact form was less than %1$d seconds ago. Please try again later.';

$txt['topic_gone'] = 'We tried very hard to find the topic or board you are looking for, but it\'s nowhere to be found. It appears to be either missing or off limits to you.';
$txt['theme_edit_missing'] = 'We tried very hard to find the file you are trying to edit, but it can\'t be found.';

$txt['no_dump_database'] = 'Sorry, we can\'t let you make database backups. Only administrators can.';
$txt['pm_not_yours'] = 'Privatna poruka koju pokušavate da citirate ne pripada vama ili ne postoji. Vratite se nazad i pokušajte ponovo.';
$txt['mangled_post'] = 'Zabrljani podaci u formi - vratite se nazad i pokušajte ponovo.';
$txt['too_many_groups'] = 'Sorry, you selected too many groups, please remove some.';
$txt['post_upload_error'] = 'The post data is missing. This error could be caused by trying to submit a file larger than allowed by the server.  Please contact your administrator if this problem continues.';
$txt['quoted_post_deleted'] = 'Poruka koju pokušavate da citirate ne postoji, obrisana je ili više nije vidljiva za vas.';
$txt['pm_too_many_per_hour'] = 'Prekoračili ste broj (%d) dozvoljenih privatnih poruka po satu.';
$txt['labels_too_many'] = '%s već ima najveći broj dozvoljenih odeljaka!';

$txt['register_only_once'] = 'Nije vam dozvoljeno da registrujte više naloga u isto vreme sa istog računara.';
$txt['admin_setting_coppa_require_contact'] = 'Morate da unesete ili adresu ili broj faksa za stupanje u kontakt sa roditeljem/starateljem ukoliko je potrebno.';

$txt['error_long_name'] = 'Ime koje ste pokušali da upotrebite je predugačko.';
$txt['error_no_name'] = 'Niste precizirali ime.';
$txt['error_bad_name'] = 'Ime koje ste podneli ne možete da upotrebite pošto je rezervisano.';
$txt['error_no_email'] = 'Niste precizirali imejl adresu.';
$txt['error_bad_email'] = 'Podneli ste neispravnu imejl adresu.';
$txt['error_email'] = 'email address';
$txt['error_message'] = 'poruka';
$txt['error_no_event'] = 'Niste precizirali naziv događaja.';
$txt['error_no_subject'] = 'Niste uneli naslov teme.';
$txt['error_no_question'] = 'Niste uneli pitanja za ovo glasanje.';
$txt['error_no_message'] = 'Niste uneli telo poruke.';
$txt['error_long_message'] = 'Poruka je prevazišla maksimalnu dozvoljenu dužinu (%s znakova).';
$txt['error_no_comment'] = 'Polje za komentar je ostavljeno prazno.';
$txt['error_post_too_long'] = 'Your message is too long. Please enter a maximum of 255 characters.';
$txt['error_session_timeout'] = 'Vaša sesija je istekla tokom slanja poruke. Probajte da ponovo pošaljete poruku.';
$txt['error_no_to'] = 'Niste precizirali primaoca.';
$txt['error_bad_to'] = 'Jedan ili više \'za\'-primaoca nije nađen.';
$txt['error_bad_bcc'] = 'Jedan ili više \'bcc\'-primaoca nije nađen.';
$txt['error_form_already_submitted'] = 'You already submitted this post!  You might have accidentally double clicked or refreshed the page.';
$txt['error_poll_few'] = 'Morate da ponudite barem dve opcije!';
$txt['error_poll_many'] = 'You must have no more than 256 choices.';
$txt['error_need_qr_verification'] = 'Molimo, popunite sekciju za verifikaciju ispod, da bi kompletirali vaš post.';
$txt['error_wrong_verification_code'] = 'Slova koja ste uneli se ne poklapaju sa onim prikazanim na slici.';
$txt['error_wrong_verification_answer'] = 'Niste tačno odgovorili na pitanja o verifikaciji.';
$txt['error_need_verification_code'] = 'Unesite kod za potvrdu da biste videli rezultate.';
$txt['error_bad_file'] = 'Sorry, but the file specified could not be opened: %1$s';
$txt['error_bad_line'] = 'Linija koju ste precizirali je pogrešna.';
$txt['error_draft_not_saved'] = 'There was an error saving the draft';
$txt['error_name_in_use'] = 'The name %1$s is already in use by another member.';

$txt['smiley_not_found'] = 'Smajli nije nađen.';
$txt['smiley_has_no_code'] = 'Niste precizirali kod za ovaj smajli.';
$txt['smiley_has_no_filename'] = 'No file name for this smiley was given.';
$txt['smiley_not_unique'] = 'Smajli sa tim kodom već postoji.';
$txt['smiley_set_already_exists'] = 'Postavka smajlija sa tim URL-om već postoji';
$txt['smiley_set_not_found'] = 'Postavka smajlija nije nađena';
$txt['smiley_set_dir_not_found'] = 'The directory of the smiley set %1$s is either invalid or cannot be accessed';
$txt['smiley_set_path_already_used'] = 'URL postavke smajlija se već koristi od strane druge postavke smajlija.';
$txt['smiley_set_unable_to_import'] = 'Nisam mogao da uvezem postavku smajlija. Ili je direktorijum pogrešan ili mu se ne može pristupiti.';

$txt['smileys_upload_error'] = 'Nisam mogao da dostavim datoteku.';
$txt['smileys_upload_error_blank'] = 'All smiley sets must have an image.';
$txt['smileys_upload_error_name'] = 'All smileys must have the same file name.'; // TODO: rephrase this. can be misunderstood.
$txt['smileys_upload_error_illegal'] = 'Ilegalan tip.';

$txt['search_invalid_weights'] = 'Search weights are not configured properly. At least one weight should be configured to be non-zero. Please report this error to an administrator.';

$txt['package_no_file'] = 'Ne mogu da nađem datoteku paketa!';
$txt['packageget_unable'] = 'Nisam mogao da se povežem na server. Probajte da koristite <a href="%s" target="_blank">ovaj URL</a> umesto prethodnog.';
$txt['not_valid_server'] = 'Sorry, packages can only be downloaded like this from servers you have first authorized.';
$txt['package_cant_uninstall'] = 'Ovaj paket ili nikada nije bilo instaliran ili je već deinstaliran - sada ga ne možete deinstalirati.';
$txt['package_cant_download'] = 'You cannot download or install new packages because the &quot;packages&quot; directory or one of the files in it are not writable!';
$txt['package_upload_error_nofile'] = 'Niste izabrali paket za dostavljanje.';
$txt['package_upload_error_failed'] = 'Nisam mogao da dostavim paket. Proverite dozvole direktorijuma!';
$txt['package_upload_error_exists'] = 'The file you are uploading already exists on the server. Please delete it first, then try again.';
$txt['package_upload_already_exists'] = 'The package you are trying to upload already exists on the server under file name: %1$s';
$txt['package_upload_error_supports'] = 'Menadžer paketa trenutno podržava samo ove tipove datoteka: %1$s.';
$txt['package_upload_error_broken'] = 'Paket niste dostavili uspešno zbog sledeće greške:<br />&quot;%1$s&quot;';

$txt['package_get_error_not_found'] = 'The package you are trying to install cannot be located. You may want to manually upload the package to your &quot;packages&quot; directory.';
$txt['package_get_error_missing_xml'] = 'Paket koji pokušavate da instalirate nema package-info.xml fajl koji mora biti u root-u paketa koji dostavljate.';
$txt['package_get_error_is_zero'] = 'Although the package was downloaded to the server it appears to be empty. Please check the &quot;packages&quot; directory, and the &quot;temp&quot; sub-directory are both writable. If you continue to experience this problem you should try extracting the package on your PC and uploading the extracted files into a subdirectory in your &quot;packages&quot; directory and try again. For example, if the package was called shout.tar.gz you should:<br />1) Download the package to your local PC and extract its files.<br />2) Create a new directory in your &quot;packages&quot; folder using an FTP client, in this example you may call it "shout".<br />3) Upload all the files from the extracted package to this directory.<br />4) Go back to the package manager browse page. The package will be automatically found.';
$txt['package_get_error_packageinfo_corrupt'] = 'Unable to find any valid information within the package-info.xml file included within the package. There may be an error in the add-on, or the package may be corrupt.';
$txt['package_get_error_is_theme'] = 'You can\'t install a theme from this section, please use the <a href="{MANAGETHEMEURL}">Theme Management</a> page to upload it';

$txt['no_membergroup_selected'] = 'No member group selected';
$txt['membergroup_does_not_exist'] = 'The member group doesn\'t exist or is invalid.';

$txt['at_least_one_admin'] = 'Mora da postoji najmanje jedan administrator na forumu!';

$txt['error_functionality_not_windows'] = 'Žao nam je, ova opcija trenutno nije dostupna za servere koje pokreće Windows.';

// Don't use entities in the below string.
$txt['attachment_not_found'] = 'Priložena datoteka nije nađena';

$txt['error_no_boards_selected'] = 'No valid boards were selected.';
$txt['error_invalid_search_string'] = 'Did you forget to enter something to search for?';
$txt['error_invalid_search_string_blacklist'] = 'Your search query contained trivial words. Please try again with a different query.';
$txt['error_search_string_small_words'] = 'Svaka reč mora da ima najmanje dva znaka.';
$txt['error_query_not_specific_enough'] = 'Vaš upit nije bio dovoljno precizan. Probajte da koristite veće reči ili ne toliko česte fraze.';
$txt['error_no_messages_in_time_frame'] = 'Poruke u izabranom vremenskom okviru nisu pronađene.';
$txt['error_no_labels_selected'] = 'No labels were selected.';
$txt['error_no_search_daemon'] = 'Ne mogu da pristupim programu za pretragu';

$txt['profile_errors_occurred'] = 'The following errors occurred when trying to update your profile';
$txt['profile_error_bad_offset'] = 'Vremensko odstupanje je preveliko';
$txt['profile_error_no_name'] = 'Polje za ime je ostavljeno prazno';
$txt['profile_error_digits_only'] = 'Polje \'broj poruka\' može da sadrži samo cifre.';
$txt['profile_error_name_taken'] = 'The selected user name/display name has already been taken';
$txt['profile_error_name_too_long'] = 'Ime koje ste izabrali je predugo. Ne bi trebalo da bude duže od 60 znakova.';
$txt['profile_error_no_email'] = 'Polje za imejl adresu je ostavljeno prazno';
$txt['profile_error_bad_email'] = 'Niste uneli ispravnu imejl adresu';
$txt['profile_error_email_taken'] = 'Jedan korisnik je već registrovan sa tom imejl adresom';
$txt['profile_error_no_password'] = 'Niste uneli svoju lozinku';
$txt['profile_error_bad_new_password'] = 'Nove lozinke koje ste uneli se ne poklapaju';
$txt['profile_error_bad_password'] = 'Lozinka koju ste uneli je pogrešna';
$txt['profile_error_bad_avatar'] = 'Avatar koji ste izabrali je prevelik ili nije avatar';
$txt['profile_error_password_short'] = 'Your password must be at least %1$s characters long.';
$txt['profile_error_password_restricted_words'] = 'Your password must not contain your user name, email address or other commonly used words.';
$txt['profile_error_password_chars'] = 'Vaša lozinka mora da bude sastavljena od velikih i malih slova kao i brojeva.';
$txt['profile_error_already_requested_group'] = 'Već imate otvoren zahtev za ovu grupu!';
$txt['profile_error_openid_in_use'] = 'Drugi korisnik koristi taj OpenID url za prijavljivanje';
$txt['profile_error_signature_not_yet_saved'] = 'The signature has not been saved.';
$txt['profile_error_personal_text_too_long'] = 'The personal text is too long.';
$txt['profile_error_user_title_too_long'] = 'The custom title is too long.';

$txt['mysql_error_space'] = ' - proverite veličinu za skladištenje baze ili kontaktirajte administratora.';

$txt['icon_not_found'] = 'Slika ikone nije pronađena u podrazumevanoj temi - uverite se da je slika dostavljena i pokušajte ponovo.';
$txt['icon_after_itself'] = 'The icon cannot be positioned after itself.';
$txt['icon_name_too_long'] = 'Icon file names cannot be more than 16 characters long';

$txt['name_censored'] = 'Ime koje ste pokušali da upotrebite, %s, sadrži reči koje su cenzurisane. Probajte sa drugim imenom.';

$txt['poll_already_exists'] = 'A topic can only have one poll associated with it.';
$txt['poll_not_found'] = 'Nema glasanja povezanog sa ovom temom!';

$txt['error_while_adding_poll'] = 'Sledeća greška ili greške su se dogodile prilikom dodavanja ovog glasanja';
$txt['error_while_editing_poll'] = 'Sledeća greška ili greške su se dogodile prilikom izmene ovog glasanja';

$txt['loadavg_search_disabled'] = 'Zbog velikog opterećenja servera, funkcija za pretragu je automatski i privremeno onemogućena. Probajte ponovo malo kasnije.';
$txt['loadavg_generic_disabled'] = 'Zbog velikog opterećenja servera, ova mogućnost je trenutno onemogućena.';
$txt['loadavg_allunread_disabled'] = 'The server\'s resources are temporarily under a too high demand to find all the topics you have not read.';
$txt['loadavg_unreadreplies_disabled'] = 'Server je trenutno pod velikim opterećenjem. Probajte ponovo malo kasnije.';
$txt['loadavg_show_posts_disabled'] = 'Pokušajte ponovo malo kasnije. Pretraga za porukama ovog člana trenutno nije dostupna zbog velikog opterećenja servera.';
$txt['loadavg_unread_disabled'] = 'The server\'s resources are temporarily under a too high demand to list out the topics you have not read.';
$txt['loadavg_userstats_disabled'] = 'Please try again later.  This member\'s statistics are not currently available due to high load on the server.';

$txt['cannot_edit_permissions_inherited'] = 'You cannot edit inherited permissions directly, you must either edit the parent group or edit the member group inheritance.';

$txt['mc_no_modreport_specified'] = 'Morate da precizirate izveštaj koji želite da pogledate.';
$txt['mc_no_modreport_found'] = 'Traženi izveštaj ne postoji ili je izvan vašeg domašaja';

$txt['st_cannot_retrieve_file'] = 'Ne mogu da dobavim datoteku %1$s.';
$txt['admin_file_not_found'] = 'Ne mogu da učitam traženu datoteku: %1$s.';

$txt['themes_none_selectable'] = 'Barem jedna tema mora da bude izaberljiva.';
$txt['themes_default_selectable'] = 'Podrazumevana tema foruma mora da bude izaberljiva tema.';
$txt['ignoreboards_disallowed'] = 'Opcija za ignorisanje foruma nije omogućena.';

$txt['mboards_delete_error'] = 'No category selected.';
$txt['mboards_delete_board_error'] = 'No board selected.';
$txt['mboards_delete_board_has_posts'] = 'Selected board still has posts and/or topics.';

$txt['mboards_parent_own_child_error'] = 'You can not make a parent its own child.';
$txt['mboards_board_own_child_error'] = 'You can not make a board its own child.';

$txt['smileys_upload_error_notwritable'] = 'Sledeći direktorijumi smajlija nisu otvoreni za pisanje: %1$s';
$txt['smileys_upload_error_types'] = 'Slika može da ima samo sledeće ekstenzije: %1$s.';

$txt['change_email_success'] = 'Vaša imejl adresa je promenjena a novi aktivacioni mejl je poslat na nju.';
$txt['resend_email_success'] = 'Novi aktivacioni mejl je uspešno poslat.';

$txt['custom_option_need_name'] = 'The profile option must have a name.';
$txt['custom_option_not_unique'] = 'Field name is not unique.';
$txt['custom_option_regex_error'] = 'The regex you entered is not valid';

$txt['warning_no_reason'] = 'Morate da unesete razlog za izmenu upozoravanja člana.';
$txt['warning_notify_blank'] = 'Izabrali ste da obavestite korisnika ali niste popunili naslov/tekst poruke.';

$txt['cannot_connect_doc_site'] = 'Could not connect to the documentation site. Please check that your server configuration allows external internet connections and try again later.';

$txt['movetopic_no_reason'] = 'Morate uneti razlog za pomeranje teme, ili ukloniti oznaku u opciji \'pošalji preusmeravajuću temu\'.';
$txt['movetopic_no_board'] = 'You must choose a board to move the topic to.';

$txt['splittopic_no_reason'] = 'You must enter a reason for splitting the topic, or uncheck the option to \'post a redirection message\'.';

// OpenID error strings
$txt['openid_server_bad_response'] = 'Zatražena indetifikacija nije rezultirala tačnim informacijama.';
$txt['openid_return_no_mode'] = 'The identity provider did not respond with the Open ID mode.';
$txt['openid_not_resolved'] = 'Provajder za identitet nije odobrio vaš zahtev.';
$txt['openid_no_assoc'] = 'Nije moguće pronaći traćenu povezanost sa provajderom identiteta.';
$txt['openid_sig_invalid'] = 'Potpis provajdera identiteta nije validan.';
$txt['openid_load_data'] = 'Nije moguće učitati podatke vašeg zahteva za prijavu. Molimo pokušajte ponovo.';
$txt['openid_not_verified'] = 'The supplied OpenID has not been verified yet.  Please log in to verify.';

$txt['error_custom_field_too_long'] = 'Polje &quot;%1$s&quot; ne sme da bude duže od %1$d znakova.';
$txt['error_custom_field_invalid_email'] = 'Polje &quot;%1$s&quot; mora da bude ispravna imejl adresa.';
$txt['error_custom_field_not_number'] = 'Polje &quot;%1$s&quot; prihvata samo brojeve.';
$txt['error_custom_field_inproper_format'] = 'Polje &quot;%1$s&quot; je pogrešnog formata.';
$txt['error_custom_field_empty'] = 'Polje &quot;%1$s&quot; ne sme da bude prazno.';

$txt['email_no_template'] = 'Nisam mogao da nađem &quot;%1$s&quot; imejl predložak .';

$txt['search_api_missing'] = 'The search API could not be found. Please contact the admin to check they have uploaded the correct files.';
$txt['search_api_not_compatible'] = 'The selected search API the forum is using is out of date - falling back to standard search. Please check the file %1$s.';

// Restore topic/posts
$txt['cannot_restore_first_post'] = 'Ne možete da vratite prvu poruku u ovoj temi.';
$txt['restored_disabled'] = 'Vraćanje tema je onemogućeno.';
$txt['restore_not_found'] = 'The following messages could not be restored; the original topic may have been removed: %1$s You will need to move these manually.';

$txt['error_invalid_dir'] = 'Direktorijum koji ste uneli nije ispravan.';

// Admin/dispatching strings
$txt['error_sa_not_set'] = 'The Sub-action you requested is not defined';

// Drag / Drop sort errors
$txt['no_sortable_items'] = 'No sortable items were found';

$txt['error_invalid_notification_id'] = 'An addon is trying to register a notification method with an existing ID. IDs lower than 5 are protected and cannot be used by addons. If the ID is higher, then two addons may be sharing the same ID.';
