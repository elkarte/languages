<?php
// Version: 1.1; ManagePaid

// Symbols.
$txt['usd_symbol'] = '$%1.2f';
$txt['eur_symbol'] = '&euro;%1.2f';
$txt['gbp_symbol'] = '&pound;%1.2f';

$txt['usd'] = 'Američki dolar ($)';
$txt['eur'] = 'Evro (&euro;)';
$txt['gbp'] = 'Britanska funta (&pound;)';
$txt['other'] = 'Drugo';

$txt['paid_username'] = 'Korisničko ime';

$txt['paid_subscriptions_desc'] = 'Ovde možete da dodajete, uklanjate ili izmenite načine za plaćanje pretplate na vašem forumu.';
$txt['paid_subs_settings'] = 'Podešavanja';
$txt['paid_subs_settings_desc'] = 'Ovde možete da izmenite sve metode plaćanja dostupne vašim korisnicima.';
$txt['paid_subs_view'] = 'Pogledaj pretplate';
$txt['paid_subs_view_desc'] = 'Ovde možete da vidite sve dostupne pretplate.';

// Setting type strings.
$txt['paid_enabled'] = 'Omogući plaćene pretplate';
$txt['paid_enabled_desc'] = 'Ovo mora da bude uključeno da bi se plaćene pretplate koristile na vašem forumu.';
$txt['paid_email'] = 'Pošalji mejlove sa obaveštenjima';
$txt['paid_email_desc'] = 'Obaveštava administratore kada se pretplata automatski promeni.';
$txt['paid_email_to'] = 'Imejl za obaveštavanje';
$txt['paid_email_to_desc'] = 'Spisak adresa odvojenih zapetom na koje će se, pored administratorskih adresa, slati obaveštenje.';
$txt['paidsubs_test'] = 'Omogući mod testiranja';
$txt['paidsubs_test_desc'] = 'Ovo će postaviti opciju plaćenih pretplata u &quot;mod testiranja&quot; koji će, gdegod je to to moguće, koristiti sandbox metodu plaćanja u paypal-u i sl. Nemojte da omogućavate ukoliko ne znate šta radite!';
$txt['paidsubs_test_confirm'] = 'Jeste li sigurni da želite da omogućite test mod?';
$txt['paid_email_no'] = 'Nemoj da šalješ obaveštenja';
$txt['paid_email_error'] = 'Obavesti kada pretplata ne uspe';
$txt['paid_email_all'] = 'Obavesti prilikom svih automatskih promena pretplate';
$txt['paid_currency'] = 'Izaberite valutu';
$txt['paid_currency_code'] = 'Kod valute';
$txt['paid_currency_code_desc'] = 'Kod koji koriste provajderi naplate';
$txt['paid_currency_symbol'] = 'Simbol koji koristi metoda za plaćanje';
$txt['paid_currency_symbol_desc'] = 'Koristite \'%1.2f\' da biste precizirali gde se nalazi broj. Na primer: $%1.2f, %1.2f dinara itd.';

$txt['paypal_email'] = 'Imejl adresa za pretplatu';
$txt['paypal_email_desc'] = 'Ostavite prazno ukoliko ne želite da koristite paypal.';

$txt['authorize_id'] = 'Authorize.net Install ID';
$txt['authorize_id_desc'] = 'Install ID koji je generisao Authorize.net. Ostavite prazno ako ne koristite Authorize.net';
$txt['authorize_transid'] = 'Authorize.Net Transaction ID';

$txt['2co_id'] = '2checkout.com ID instalacije';
$txt['2co_id_desc'] = 'Instal ID koji je generisao 2co.com. Ostavite prazno ako ne koristite 2co.com';
$txt['2co_password'] = '2checkout.com Tajna reč/kod';
$txt['2co_password_desc'] = 'Vaša 2checkout tajna reč.';
$txt['2co_password_wrong'] = 'Vaša 2checkout tajna reč/kod nije prihaćena.';

$txt['paid_settings_save'] = 'Sačuvaj';

$txt['paid_note'] = '<strong class="alert">Napomena:</strong><br />Da bi plaćene pretplate bile automatski ažurirane za vaše korisnike, moraćete
	podesiti povratni URL link za svaki od načina uplate. Za sve načine uplate, ovaj povratni URL trebabi biti podešen kao:<br /><br />
	&nbsp;&nbsp;&bull;&nbsp;&nbsp;<strong>{board_url}/subscriptions.php</strong><br /><br />
	Možete izmeniti link za PayPal direktno <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ipn-notify" target="_blank">klikom na ovaj link</a>.<br />
	Za ostale gatewaye/provajdere (ako su instalirani) ovo možete naći u vašem korisničkom panelu, obično ispod termina &quot;Return URL&quot;, &quot;Callback URL&quot; ili &quot;Povratni URL&quot;.';

// View subscription strings.
$txt['paid_name'] = 'Ime';
$txt['paid_status'] = 'Status';
$txt['paid_cost'] = 'Cena';
$txt['paid_duration'] = 'Trajanje';
$txt['paid_active'] = 'Aktivna';
$txt['paid_pending'] = 'Čeka se na plaćanje';
$txt['paid_finished'] = 'Završena';
$txt['paid_total'] = 'Ukupno';
$txt['paid_is_active'] = 'Aktiviran';
$txt['paid_none_yet'] = 'Još uvek niste dodali nijednu pretplatu.';
$txt['paid_none_ordered'] = 'Nemate plaćenih pretplata';
$txt['paid_payments_pending'] = 'Čeka se na plaćanje';
$txt['paid_order'] = 'Poredak';

$txt['yes'] = 'Da';
$txt['no'] = 'Ne';

// Add/Edit/Delete subscription.
$txt['paid_add_subscription'] = 'Dodaj novu pretplatu';
$txt['paid_edit_subscription'] = 'Izmeni pretplatu';
$txt['paid_delete_subscription'] = 'Obriši pretplatu';

$txt['paid_mod_name'] = 'Ime pretplate';
$txt['paid_mod_desc'] = 'Opis';
$txt['paid_mod_reminder'] = 'Pošalji mejl za podsećanje';
$txt['paid_mod_reminder_desc'] = 'Broj dana pre isteka pretplate kada treba poslati podsećanje. (0 za onemogućeno)';
$txt['paid_mod_email'] = 'Mejl koji se šalje nakon završetka';
$txt['paid_mod_email_desc'] = 'Gde je {NAME} ime člana; {FORUM} ime zajednice. Naslov mejla treba da bude u prvoj liniji. Ostavite prazno ukoliko ne želite da šaljete obaveštenja mejlom.';
$txt['paid_mod_cost_usd'] = 'Cena (USD)';
$txt['paid_mod_cost_eur'] = 'Cena (EUR)';
$txt['paid_mod_cost_gbp'] = 'Cena (GBP)';
$txt['paid_mod_cost_blank'] = 'Ostavite prazno ukoliko ne želite da koristite ovu valutu.';
$txt['paid_mod_span'] = 'Dužina pretplate';
$txt['paid_mod_span_days'] = 'Dana';
$txt['paid_mod_span_weeks'] = 'Nedelja';
$txt['paid_mod_span_months'] = 'Meseci';
$txt['paid_mod_span_years'] = 'Godina';
$txt['paid_mod_active'] = 'Aktivna';
$txt['paid_mod_active_desc'] = 'Pretplata mora da bude aktivna da bi novi članovi mogli da je kupe.';
$txt['paid_mod_prim_group'] = 'Primarna grupa nakon pretplate';
$txt['paid_mod_prim_group_desc'] = 'Primarna grupa u koju treba staviti korisnika kada se pretplati.';
$txt['paid_mod_add_groups'] = 'Dodatne grupe nakon pretplate';
$txt['paid_mod_add_groups_desc'] = 'Dodatne grupe u koje treba dodati korisnika kada se pretplati.';
$txt['paid_mod_no_group'] = 'Bez promene';
$txt['paid_mod_edit_note'] = 'Napomena: pošto ova grupa sadrži postojeće pretplatnike, podešavanja grupe ne mogu da budu promenjena!';
$txt['paid_mod_delete_warning'] = '<strong>UPOZORENJE</strong><br /><br />Ako obrišete ovu pretplatu, svi trenutno pretplaćeni korisnici će izgubiti sva prava pristupa koja su dobili ovom pretplatom. Ukoliko niste sigurni da želite da uradite ovo, bolje samo deaktivirajte pretplatu a nemojte je brisati.<br />';
$txt['paid_mod_repeatable'] = 'Dozvoli korisniku da automatski obnovi ovu pretplatu';
$txt['paid_mod_allow_partial'] = 'Dozvoli delimičnu pretplatu';
$txt['paid_mod_allow_partial_desc'] = 'Ukoliko je ova opcija omogućena, u slučaju da korisnik plati manju sumu nego što je potrebno, biće mu uključena pretplata u trajanju zavisno od procenta sume koju je platio.';
$txt['paid_mod_fixed_price'] = 'Pretplata za fiksnu cenu i period';
$txt['paid_mod_flexible_price'] = 'Cena pretplate zavisi od naručene dužine';
$txt['paid_mod_price_breakdown'] = 'Cene fleksibilne pretplate';
$txt['paid_mod_price_breakdown_desc'] = 'Podesite koliko će pretplata koštati zavisno od dužine perioda na koji se korisnici pretplate. Na primer, pretplata može da košta 12 dolara za jedan mesec, ali samo 100 dolara za godinu dana. Ukoliko ne želite da definišete cenu za određeni period vremena, ostavite polje prazno.';
$txt['flexible'] = 'Fleksibilno';

$txt['paid_per_day'] = 'Cena po danu';
$txt['paid_per_week'] = 'Cena po nedelji';
$txt['paid_per_month'] = 'Cena po mesecu';
$txt['paid_per_year'] = 'Cena po godini';
$txt['day'] = 'Dan';
$txt['week'] = 'Nedelja';
$txt['month'] = 'Mesec';
$txt['year'] = 'Godina';

// View subscribed users.
$txt['viewing_users_subscribed'] = 'Pregled korisnika';
$txt['view_users_subscribed'] = 'Pregled korisnika pretplaćenih na: &quot;%1$s&quot;';
$txt['no_subscribers'] = 'Trenutno nema korisnika pretplaćenih na ovu uslugu.';
$txt['add_subscriber'] = 'Dodaj novog pretplatnika';
$txt['edit_subscriber'] = 'Izmeni pretplatnika';
$txt['delete_selected'] = 'Obriši izabrano';
$txt['complete_selected'] = 'Završi izabrano';

// @todo These strings are used in conjunction with JavaScript.  Use numeric entities.
$txt['delete_are_sure'] = 'Da li ste sigurni da želite da obrišete sve unose izabranih pretplata?';
$txt['complete_are_sure'] = 'Da li ste sigurni da želite da završite sve izabrane pretplate?';

$txt['start_date'] = 'Vreme početka';
$txt['end_date'] = 'Vreme završetka';
$txt['start_date_and_time'] = 'Početni datum i vreme';
$txt['end_date_and_time'] = 'Završni datum i vreme';
$txt['one_username'] = 'Unesite samo jedno korisničko ime.';
$txt['minute'] = 'Minut';
$txt['error_member_not_found'] = 'Ne mogu da pronađem izabranog člana';
$txt['member_already_subscribed'] = 'Član je već pretplaćen na ovu uslugu. Izmenite njegovu postojeću pretplatu.';
$txt['search_sub'] = 'Pronađi korisnika';

// Make payment.
$txt['paid_confirm_payment'] = 'Potvrdi plaćanje';
$txt['paid_confirm_desc'] = 'Da biste izvršili plaćanje, proverite detalje koje se nalaze ispod i kliknite na &quot;Naruči&quot;';
$txt['paypal'] = 'PayPal';
$txt['paid_confirm_paypal'] = 'Da biste platili preko <a href="http://www.paypal.com">PayPal</a>-a kliknite na dugme koje se nalazi ispod. Bićete preusmereni na PayPal sajt da biste izvršili uplatu.';
$txt['paid_paypal_order'] = 'Naruči preko PayPal-a';
$txt['authorize'] = 'Authorize.Net';
$txt['paid_confirm_authorize'] = 'Da biste platili preko <a href="http://www.authorize.net">Authorize.Net</a> kliknite na dugme koje se nalazi ispod. Bićete preusmereni na Authorize.Net sajt da biste izvršili uplatu.';
$txt['paid_authorize_order'] = 'Naruči preko Authorize.Net-a';
$txt['2co'] = '2checkout';
$txt['paid_confirm_2co'] = 'Da biste platili preko <a href="http://www.2com.com">2co.com</a> kliknite na dugme koje se nalazi ispod. Bićete preusmereni na 2co.com da biste izvršili uplatu.';
$txt['paid_2co_order'] = 'Naruči preko 2co.com-a';
$txt['paid_done'] = 'Plaćanje završeno';
$txt['paid_done_desc'] = 'Hvala vam što ste izvršili uplatu. Čim transakcija bude potvrđena, vaša pretplata će biti aktivirana.';
$txt['paid_sub_return'] = 'Vrati se na pretplate';
$txt['paid_current_desc'] = 'Ispod se nalazi spisak svih vaših trenutnih i prethodnih pretplata. Da biste produžili postojeću pretplatu, izaberite je iz spiska.';
$txt['paid_admin_add'] = 'Dodaj ovu pretplatu';

$txt['paid_not_set_currency'] = 'Još niste podesili svoju valutu. Uradite to u podešavanjima pre nego što nastavite.';
$txt['paid_no_cost_value'] = 'Morate da unesete cenu i dužinu trajanja pretplate.';
$txt['paid_all_freq_blank'] = 'Morate da unesete cenu makar za jedan od četiri perioda.';

// Some error strings.
$txt['paid_no_data'] = 'Poslati su neispravni podaci do skripte.';

$txt['paypal_could_not_connect'] = 'Nisam mogao da se povežem sa PayPal serverom';
$txt['paypal_currency_unkown'] = 'Kod/šifra valute sa PayPal-a (%1$s) se ne poklapa sa kodom u vašim podešavanjima (%2$s)';
$txt['paid_sub_not_active'] = 'Ova pretplata više ne prima nove korisnike!';
$txt['paid_disabled'] = 'Plaćene pretplate su trenutno onemogućene!';
$txt['paid_unknown_transaction_type'] = 'Nepoznat tip transakcije za plaćenu pretplatu.';
$txt['paid_empty_member'] = 'Nisam mogao da pronađem odgovarajući ID člana';
$txt['paid_could_not_find_member'] = 'Nisam mogao da pronađem člana sa ID-om: %1$d';
$txt['paid_count_not_find_subscription'] = 'Nisam mogao da pronađem pretplatu sa člana sa ID-om: %1$s, ID pretplate: %2$s';
$txt['paid_count_not_find_subscription_log'] = 'Nisam mogao da pronađem unos u dnevniku pretplata za člana sa ID-om: %1$s, ID pretplate: %2$s';
$txt['paid_count_not_find_outstanding_payment'] = 'Nisam mogao da pronađem pretplatu na čekanju za člana sa ID-om: %1$s, ID pretplate: %2$s tako da ignorišem';
$txt['paid_admin_not_setup_gateway'] = 'Administrator još nije završio sa podešavanjem plaćene pretplate. Pokušajte ponovo malo kasnije.';
$txt['paid_make_recurring'] = 'Napravi ovo pretplatom koja se obnavlja';

$txt['subscriptions'] = 'Pretplate';
$txt['subscription'] = 'Pretplata';
$txt['subscribers'] = 'Pretplatnici';
$txt['paid_subs_desc'] = 'Ispod se nalazi spisak svih pretplate dostupnih na ovom sajtu.';
$txt['paid_subs_none'] = 'Trenutno nema dostupnih plaćenih pretplata!';

$txt['paid_current'] = 'Postojeće pretplate';
$txt['pending_payments'] = 'Čeka na plaćanje';
$txt['pending_payments_desc'] = 'Ova član je pokušao da napravi sledeća plaćanja za ovu pretplatu ali potvrda plaćanja još uvek nije poslata forumu. Ukoliko ste sigurni da je ovo plaćanje primljeno, kliknite na &quot;prihvati&quot; da biste aktivirali pretplatu. Možete da kliknete i na &quot;ukloni&quot; da obrišete sve reference na ovo plaćanje.';
$txt['pending_payments_value'] = 'Vrednost';
$txt['pending_payments_accept'] = 'Prihvati';
$txt['pending_payments_remove'] = 'Ukloni';