<?php
// Version: 1.1; ManageScheduledTasks

$txt['scheduled_tasks_title'] = 'Planirani zadaci';
$txt['scheduled_tasks_header'] = 'Svi planirani zadaci';
$txt['scheduled_tasks_name'] = 'Ime zadatka';
$txt['scheduled_tasks_next_time'] = 'Vreme sledećeg pokretanja';
$txt['scheduled_tasks_regularity'] = 'Učestalost';
$txt['scheduled_tasks_enabled'] = 'Omogućen';
$txt['scheduled_tasks_run_now'] = 'Pokreni sada';
$txt['scheduled_tasks_save_changes'] = 'Sačuvaj promene';
$txt['scheduled_tasks_time_offset'] = '<strong>Note:</strong> All times given below are <em>server time</em> and do not take any time offsets setup within the admin panel into account.';
$txt['scheduled_tasks_were_run'] = 'Svi izabrani zadaci su završeni.';
$txt['scheduled_tasks_were_run_errors'] = 'The following errors occurred while running the scheduled tasks:';

$txt['scheduled_tasks_na'] = 'Nije dostupno';
$txt['scheduled_task_approval_notification'] = 'Obaveštenja o odobrenju';
$txt['scheduled_task_desc_approval_notification'] = 'Šalje mejlove svim urednicima i obaveštava o temama koje čekaju odobrenje.';
$txt['scheduled_task_auto_optimize'] = 'Optimizuj bazu podataka';
$txt['scheduled_task_desc_auto_optimize'] = 'Optimizuje bazu podataka da bi uklonio probleme sa fragmentacijom.';
$txt['scheduled_task_daily_maintenance'] = 'Dnevno održavanje';
$txt['scheduled_task_desc_daily_maintenance'] = 'Pokreće neophodno dnevno održavanje foruma - ne bi trebalo onemogućavati.';
$txt['scheduled_task_daily_digest'] = 'Obaveštenja: dnevni pregled';
$txt['scheduled_task_desc_daily_digest'] = 'Šalje mejlove sa dnevnim pregledima svim pretplatnicima.';
$txt['scheduled_task_weekly_digest'] = 'Obaveštenja: nedeljni pregled';
$txt['scheduled_task_desc_weekly_digest'] = 'Šalje mejlove sa nedeljnim pregledima svim pretplatnicima.';
$txt['scheduled_task_birthdayemails'] = 'Slanje rođendanskih mejlova';
$txt['scheduled_task_desc_birthdayemails'] = 'Šalje mejlove sa rođendanskim čestitkama.';
$txt['scheduled_task_weekly_maintenance'] = 'Nedeljno održavanje';
$txt['scheduled_task_desc_weekly_maintenance'] = 'Pokreće neophodno nedeljno održavanje foruma - ne bi trebalo onemogućavati.';
$txt['scheduled_task_paid_subscriptions'] = 'Provera plaćenih pretplata';
$txt['scheduled_task_desc_paid_subscriptions'] = 'Šalje neophodna obaveštenja o pretplati i uklanja istekle plaćene pretplate.';
$txt['scheduled_task_remove_topic_redirect'] = 'Remove MOVED: Redirection Topics';
$txt['scheduled_task_desc_remove_topic_redirect'] = 'Deletes "MOVED:" topic notifications as specified when the moved notice was created.';
$txt['scheduled_task_remove_temp_attachments'] = 'Remove Temporary Attachment Files';
$txt['scheduled_task_desc_remove_temp_attachments'] = 'Deletes temporary files created while attaching a file to a post that for any reason weren\'t renamed or deleted before.';
$txt['scheduled_task_remove_old_drafts'] = 'Remove Old Drafts';
$txt['scheduled_task_desc_remove_old_drafts'] = 'Deletes drafts older than the number of days defined in the draft settings in the admin panel.';
$txt['scheduled_task_remove_old_followups'] = 'Remove Old Follow-ups';
$txt['scheduled_task_desc_remove_old_followups'] = 'Deletes follow-up entries still present in the database, but pointing to non-existent topics.';
$txt['scheduled_task_maillist_fetch_IMAP'] = 'Fetch Emails from IMAP';
$txt['scheduled_task_desc_maillist_fetch_IMAP'] = 'Fetches emails for the mailing list feature from an IMAP box and processes them.';
$txt['scheduled_task_user_access_mentions'] = 'Users Mentions Access';
$txt['scheduled_task_desc_user_access_mentions'] = 'Verify users access to each board and set accessibility to related mentions accordingly.';

$txt['scheduled_task_reg_starting'] = 'Počinje u %1$s';
$txt['scheduled_task_reg_repeating'] = 'ponavlja se svakih %1$d %2$s';
$txt['scheduled_task_reg_unit_m'] = 'minut(a)';
$txt['scheduled_task_reg_unit_h'] = 'sat(i)';
$txt['scheduled_task_reg_unit_d'] = 'dan(a)';
$txt['scheduled_task_reg_unit_w'] = 'nedelja(e)';

$txt['scheduled_task_edit'] = 'Izmeni planirani zadatak';
$txt['scheduled_task_edit_repeat'] = 'Ponovi zadatak svakih';
$txt['scheduled_task_edit_pick_unit'] = 'Izaberi jedinicu';
$txt['scheduled_task_edit_interval'] = 'Interval';
$txt['scheduled_task_edit_start_time'] = 'Vreme početka';
$txt['scheduled_task_edit_start_time_desc'] = 'Vreme kada će zadatak biti pokrenut prvi put (sati:minuta)';
$txt['scheduled_task_time_offset'] = 'Početno vreme se odnosi na vreme na serveru a ne na vaše vreme. Trenutno serversko vreme je: %1$s';

$txt['scheduled_view_log'] = 'Pogledaj dnevnik';
$txt['scheduled_log_empty'] = 'Trenutno nema zapisa u dnevniku zadataka.';
$txt['scheduled_log_time_run'] = 'Vreme pokretanja';
$txt['scheduled_log_time_taken'] = 'Vreme trajanja';
$txt['scheduled_log_time_taken_seconds'] = '%1$d sekundi';
$txt['scheduled_log_completed'] = 'Task completed';
$txt['scheduled_log_empty_log'] = 'Clear Log';
$txt['scheduled_log_empty_log_confirm'] = 'Are you sure you want to completely clear the log?';